<?php

declare(strict_types=1);

use GlpiPlugin\Glpiacessivel\Infrastructure\Compliance\SchemaManager;

require_once dirname(__DIR__) . '/hook.php';

function plugin_glpiacessivel_uninstall_sql(): bool
{
    global $DB;
    $schema = new SchemaManager($DB);
    return $schema->uninstall();
}

