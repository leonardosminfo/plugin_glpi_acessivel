<?php

declare(strict_types=1);

namespace GlpiPlugin\Glpiacessivel\Security;

final class SessionContextGuard
{
    public const GROUP_CONTEXT_LOAD_CONFIRMED_SESSION_KEY = 'glpiacessivel_group_context_load_confirmed_v1';

    /**
     * @return array<string, mixed>
     */
    public function ensureReady(): array
    {
        $before = $this->status();
        $beforeSignature = $this->diagnosticSignature($before);
        if (empty($before['is_authenticated'])) {
            return $before + ['normalization_attempted' => false, 'normalization_changed' => false];
        }

        if (!empty($before['session_ready'])) {
            if (($_SESSION[self::GROUP_CONTEXT_LOAD_CONFIRMED_SESSION_KEY] ?? null) !== false) {
                return $before + ['normalization_attempted' => false, 'normalization_changed' => false];
            }

            $this->tryNativeGroupLoad();
            $after = $this->status();
            $after['normalization_attempted'] = true;
            $after['normalization_changed'] = $beforeSignature !== $this->diagnosticSignature($after);
            return $after;
        }

        $this->tryNativeNormalization();
        $after = $this->status();
        $after['normalization_attempted'] = true;
        $after['normalization_changed'] = $beforeSignature !== $this->diagnosticSignature($after);

        return $after;
    }

    /**
     * @return array<string, mixed>
     */
    public function status(): array
    {
        $userId = $this->currentUserId();
        $profiles = $this->profileIds();
        $activeProfileId = (int) ($_SESSION['glpiactiveprofile']['id'] ?? 0);
        $activeEntityValue = $_SESSION['glpiactive_entity'] ?? null;
        $activeEntities = $_SESSION['glpiactiveentities'] ?? [];
        $hasActiveEntity = $activeEntityValue !== null || (is_array($activeEntities) && $activeEntities !== []);
        $profileInterface = trim((string) ($_SESSION['glpiactiveprofile']['interface'] ?? ''));

        $issueCode = 'ready';
        if ($userId <= 0) {
            $issueCode = 'not_logged';
        } elseif (!empty($_SESSION['glpi_password_expired'])) {
            $issueCode = 'password_expired_partial';
        } elseif ($profiles === []) {
            $issueCode = 'missing_profiles';
        } elseif ($activeProfileId <= 0 || !in_array($activeProfileId, $profiles, true)) {
            $issueCode = 'missing_active_profile';
        } elseif (!$hasActiveEntity) {
            $issueCode = 'missing_active_entities';
        } elseif (!$this->hasUsableCurrentInterface($profileInterface)) {
            $issueCode = 'no_current_interface';
        }

        $entityId = is_numeric($activeEntityValue) ? (int) $activeEntityValue : 0;
        $sessionReady = $issueCode === 'ready';

        return [
            'is_authenticated' => $userId > 0,
            'session_ready' => $sessionReady,
            'context_valid' => $sessionReady,
            'issue_code' => $issueCode,
            'user_id_present' => $userId > 0,
            'profile_id' => $activeProfileId,
            'profile_count' => count($profiles),
            'profile_interface' => $profileInterface,
            'entity_id' => $entityId,
            'active_entity_value' => $activeEntityValue === null ? '' : (string) $activeEntityValue,
            'has_active_entities' => $hasActiveEntity,
            'active_entities_count' => is_array($activeEntities) ? count($activeEntities) : 0,
            'csrf_available' => method_exists('Session', 'getNewCSRFToken'),
        ];
    }

    private function tryNativeNormalization(): void
    {
        $userId = $this->currentUserId();
        if ($userId <= 0 || !empty($_SESSION['glpi_password_expired'])) {
            return;
        }

        if ($this->profileIds() === [] && method_exists('Session', 'initEntityProfiles')) {
            try {
                \Session::initEntityProfiles($userId);
            } catch (\Throwable $e) {
                // Keep degraded mode; do not synthesize GLPI session internals.
            }
        }

        if ((int) ($_SESSION['glpiactiveprofile']['id'] ?? 0) <= 0 && method_exists('Session', 'changeProfile')) {
            $profileId = $this->preferredProfileId();
            if ($profileId > 0) {
                try {
                    \Session::changeProfile($profileId);
                } catch (\Throwable $e) {
                    // Keep degraded mode; the native API rejected normalization.
                }
            }
        }

        if (!$this->hasActiveEntityScope() && method_exists('Session', 'changeActiveEntities')) {
            $entity = $this->preferredEntityScope();
            if ($entity !== null) {
                try {
                    if ($entity['id'] === 'all') {
                        \Session::changeActiveEntities('all');
                    } else {
                        \Session::changeActiveEntities((int) $entity['id'], (bool) $entity['recursive']);
                    }
                } catch (\Throwable $e) {
                    // Keep degraded mode; the native API rejected normalization.
                }
            }
        }

        $this->tryNativeGroupLoad();
    }

    private function tryNativeGroupLoad(): void
    {
        if (!$this->hasActiveEntityScope() || !method_exists('Session', 'loadGroups')) {
            return;
        }

        try {
            \Session::loadGroups();
            $_SESSION[self::GROUP_CONTEXT_LOAD_CONFIRMED_SESSION_KEY] = true;
        } catch (\Throwable $e) {
            // Preserve the page context but make group-scoped reads fail closed.
            $_SESSION[self::GROUP_CONTEXT_LOAD_CONFIRMED_SESSION_KEY] = false;
        }
    }

    private function currentUserId(): int
    {
        if (class_exists('Session') && method_exists('Session', 'getLoginUserID')) {
            try {
                return max(0, (int) \Session::getLoginUserID());
            } catch (\Throwable $e) {
                // Fall through to the legacy session key.
            }
        }

        return max(0, (int) ($_SESSION['glpiID'] ?? 0));
    }

    /** @return int[] */
    private function profileIds(): array
    {
        $ids = [];
        foreach ((array) ($_SESSION['glpiprofiles'] ?? []) as $id => $profile) {
            $profileId = is_numeric($id) ? (int) $id : (int) (is_array($profile) ? ($profile['id'] ?? 0) : 0);
            if ($profileId > 0) {
                $ids[] = $profileId;
            }
        }

        return array_values(array_unique($ids));
    }

    private function preferredProfileId(): int
    {
        $profiles = $this->profileIds();
        if ($profiles === []) {
            return 0;
        }

        $defaultProfileId = (int) ($_SESSION['glpidefaultprofile'] ?? 0);
        if ($defaultProfileId > 0 && in_array($defaultProfileId, $profiles, true)) {
            return $defaultProfileId;
        }

        return (int) $profiles[0];
    }

    private function hasActiveEntityScope(): bool
    {
        if (array_key_exists('glpiactive_entity', $_SESSION)) {
            return true;
        }

        return is_array($_SESSION['glpiactiveentities'] ?? null) && $_SESSION['glpiactiveentities'] !== [];
    }

    /** @return array{id:int|string,recursive:bool}|null */
    private function preferredEntityScope(): ?array
    {
        $entities = [];
        foreach ((array) ($_SESSION['glpiactiveprofile']['entities'] ?? []) as $entity) {
            if (!is_array($entity)) {
                continue;
            }

            $entityId = (int) ($entity['id'] ?? -1);
            if ($entityId < 0) {
                continue;
            }

            $entities[] = [
                'id' => $entityId,
                'recursive' => !empty($entity['is_recursive']),
            ];
        }

        if ($entities === []) {
            return null;
        }

        if (count($entities) > 1) {
            return ['id' => 'all', 'recursive' => true];
        }

        return $entities[0];
    }

    private function hasUsableCurrentInterface(string $profileInterface): bool
    {
        if (method_exists('Session', 'getCurrentInterface')) {
            try {
                return trim((string) \Session::getCurrentInterface()) !== '';
            } catch (\Throwable $e) {
                return false;
            }
        }

        return true;
    }

    /** @param array<string, mixed> $status */
    private function diagnosticSignature(array $status): string
    {
        return implode('|', [
            (string) ($status['issue_code'] ?? ''),
            (string) ($status['profile_id'] ?? 0),
            (string) ($status['active_entity_value'] ?? ''),
            (string) ($status['active_entities_count'] ?? 0),
            ($_SESSION[self::GROUP_CONTEXT_LOAD_CONFIRMED_SESSION_KEY] ?? null) === true
                ? 'groups_loaded'
                : (($_SESSION[self::GROUP_CONTEXT_LOAD_CONFIRMED_SESSION_KEY] ?? null) === false
                    ? 'groups_failed'
                    : 'groups_legacy'),
        ]);
    }
}
