<?php

declare(strict_types=1);

namespace GlpiPlugin\Glpiacessivel\UI\Controller;

use GlpiPlugin\Glpiacessivel\Infrastructure\Audit\AuditQueryService;
use GlpiPlugin\Glpiacessivel\Support\Url;
use GlpiPlugin\Glpiacessivel\UI\View\View;

final class AuditController extends BaseController
{
    public static function index(): void
    {
        self::requireLogin();
        $authorization = self::container()->auditAuthorization();
        if (!$authorization->canRead()) {
            self::denyAccess(
                __('Auditoria indisponível', 'glpiacessivel'),
                __('Seu perfil não possui o direito específico para consultar a trilha de auditoria.', 'glpiacessivel'),
                'audit.view.denied'
            );
            return;
        }

        $filters = self::filters($_GET);
        $cursor = self::cursor($_GET['cursor'] ?? '');
        try {
            $result = self::container()->auditQueryService()->search(
                $filters,
                $cursor !== '' ? $cursor : null,
                AuditQueryService::DEFAULT_PAGE_SIZE
            );
        } catch (\Throwable $e) {
            if (str_starts_with($e->getMessage(), 'audit_cursor_')) {
                self::setMessage(
                    'error',
                    __('A paginação expirou após mudança de contexto. A primeira página foi carregada novamente.', 'glpiacessivel')
                );
                $result = self::container()->auditQueryService()->search(
                    $filters,
                    null,
                    AuditQueryService::DEFAULT_PAGE_SIZE
                );
            } else {
                throw $e;
            }
        }

        self::container()->auditLogger()->log('audit.view', [
            'rows' => count($result['rows']),
            'has_ticket_filter' => !empty($filters['ticket_id']),
            'has_user_filter' => !empty($filters['user_id']),
            'has_action_filter' => !empty($filters['action']),
        ]);

        View::render('audit/index', [
            'title' => __('Trilha de auditoria operacional', 'glpiacessivel'),
            'rows' => $result['rows'],
            'next_cursor' => $result['next_cursor'],
            'has_more' => $result['has_more'],
            'filters' => $filters,
            'from' => substr((string) $result['from'], 0, 10),
            'to' => substr((string) $result['to'], 0, 10),
            'audit_mode' => self::container()->configService()->getAuditMode(),
            'can_export' => $authorization->canExport(),
            'csrf_token' => self::csrf()->token(),
        ]);
    }

    public static function export(): void
    {
        self::requireLogin();
        $authorization = self::container()->auditAuthorization();
        if (!$authorization->canExport()) {
            self::denyAccess(
                __('Exportação indisponível', 'glpiacessivel'),
                __('Seu perfil não possui o direito específico para exportar auditoria.', 'glpiacessivel'),
                'audit.export.denied'
            );
            return;
        }
        try {
            self::csrf()->validateRequest();
        } catch (\Throwable) {
            if (!headers_sent()) {
                http_response_code(403);
            }
            echo __('A sessão expirou. Recarregue a página de auditoria.', 'glpiacessivel');
            return;
        }
        if (!self::admitExport()) {
            if (!headers_sent()) {
                http_response_code(429);
                header('Retry-After: 3600');
            }
            echo __('Limite temporário de exportações atingido. Tente novamente mais tarde.', 'glpiacessivel');
            return;
        }

        $filters = self::filters($_POST);
        $result = self::container()->auditQueryService()->search($filters, null, 100);
        self::container()->auditLogger()->log('audit.export', [
            'rows' => count($result['rows']),
            'bounded' => true,
        ]);

        if (!headers_sent()) {
            header('Content-Type: text/csv; charset=UTF-8');
            header('Content-Disposition: attachment; filename="glpiacessivel-auditoria.csv"');
            header('X-Content-Type-Options: nosniff');
            header('Cache-Control: no-store, private');
        }
        $output = fopen('php://output', 'wb');
        if ($output === false) {
            return;
        }
        fwrite($output, "\xEF\xBB\xBF");
        fputcsv($output, ['Data e hora', 'Evento', 'Resultado', 'Chamado', 'Entidade', 'Usuário'], ';');
        foreach ($result['rows'] as $row) {
            fputcsv($output, [
                self::csvCell((string) ($row['created_at'] ?? '')),
                self::csvCell((string) ($row['action_label'] ?? '')),
                self::csvCell((string) ($row['result'] ?? '')),
                (int) ($row['tickets_id'] ?? 0),
                (int) ($row['entities_id'] ?? 0),
                (int) ($row['users_id'] ?? 0),
            ], ';');
        }
        fclose($output);
    }

    /** @param array<string,mixed> $source @return array<string,mixed> */
    private static function filters(array $source): array
    {
        $date = static fn($value): string => preg_match('/\A\d{4}-\d{2}-\d{2}\z/D', (string) $value) === 1
            ? (string) $value
            : '';
        $action = trim((string) ($source['action'] ?? ''));
        if (preg_match('/\A[a-z0-9_.-]{1,120}\z/D', $action) !== 1) {
            $action = '';
        }

        return [
            'from' => $date($source['from'] ?? ''),
            'to' => $date($source['to'] ?? ''),
            'action' => $action,
            'ticket_id' => max(0, (int) ($source['ticket_id'] ?? 0)),
            'user_id' => max(0, (int) ($source['user_id'] ?? 0)),
        ];
    }

    private static function cursor(mixed $value): string
    {
        $cursor = trim((string) $value);
        return preg_match('/\A[A-Za-z0-9_.-]{1,1000}\z/D', $cursor) === 1 ? $cursor : '';
    }

    private static function admitExport(): bool
    {
        $now = time();
        $values = array_values(array_filter(
            (array) ($_SESSION['glpiacessivel_audit_exports'] ?? []),
            static fn($value): bool => is_int($value) && $value > ($now - 3600)
        ));
        if (count($values) >= 2) {
            return false;
        }
        $values[] = $now;
        $_SESSION['glpiacessivel_audit_exports'] = $values;
        return true;
    }

    private static function csvCell(string $value): string
    {
        return preg_match('/\A[=+\-@]/', $value) === 1 ? "'" . $value : $value;
    }
}
