<?php

declare(strict_types=1);

namespace GlpiPlugin\Glpiacessivel\UI\Controller;

use GlpiPlugin\Glpiacessivel\Security\CsrfGuard;
use GlpiPlugin\Glpiacessivel\Security\SessionContextGuard;
use GlpiPlugin\Glpiacessivel\Support\Container;
use GlpiPlugin\Glpiacessivel\Support\Url;
use GlpiPlugin\Glpiacessivel\UI\View\View;

abstract class BaseController
{
    protected static function requireLogin(): void
    {
        $guard = new SessionContextGuard();
        $status = $guard->ensureReady();
        \Session::checkLoginUser();

        if (!empty($status['session_ready'])) {
            return;
        }

        self::container()->auditLogger()->log('session.context_blocked', [
            'issue_code' => (string) ($status['issue_code'] ?? 'unknown'),
            'profile_id' => (int) ($status['profile_id'] ?? 0),
            'entity_id' => (int) ($status['entity_id'] ?? 0),
            'request_method' => (string) ($_SERVER['REQUEST_METHOD'] ?? 'GET'),
            'request_uri' => (string) ($_SERVER['REQUEST_URI'] ?? ''),
        ]);
        self::setMessage(
            'error',
            __('Não foi possível confirmar seu perfil e sua unidade no GLPI. O portal tentará recuperar seu acesso antes de abrir esta função.', 'glpiacessivel')
        );
        \Html::redirect(Url::plugin('front/acessivel.php?session=recover'));
        exit;
    }

    protected static function requireModuleEnabled(string $module): bool
    {
        $policy = self::container()->portalModulePolicy();
        if ($policy->isEnabled($module)) {
            return true;
        }

        self::container()->auditLogger()->log('module.access_blocked', [
            'module' => $module,
            'configured_state' => $policy->getConfiguredState($module),
            'effective_state' => $policy->getEffectiveState($module),
            'request_method' => (string) ($_SERVER['REQUEST_METHOD'] ?? 'GET'),
            'request_uri' => (string) ($_SERVER['REQUEST_URI'] ?? ''),
            'profile_id' => (int) ($_SESSION['glpiactiveprofile']['id'] ?? 0),
            'entity_id' => (int) ($_SESSION['glpiactive_entity'] ?? 0),
        ]);

        if (!headers_sent()) {
            http_response_code(403);
        }

        View::render('errors/unavailable', [
            'title' => __('Funcionalidade indisponível', 'glpiacessivel'),
            'message' => __('Esta funcionalidade foi desativada temporariamente pelo administrador do portal.', 'glpiacessivel'),
            'return_url' => Url::plugin('front/acessivel.php'),
        ]);

        return false;
    }
    protected static function csrf(): CsrfGuard
    {
        return new CsrfGuard();
    }

    protected static function validateCsrfOrRedirect(
        string $returnUrl,
        string $auditEvent,
        bool $preserveToken = false
    ): bool {
        try {
            self::csrf()->validateRequest($preserveToken);
            return true;
        } catch (\Throwable $e) {
            self::container()->auditLogger()->log($auditEvent, [
                'error' => get_class($e),
                'message' => mb_substr($e->getMessage(), 0, 250, 'UTF-8'),
                'request_method' => (string) ($_SERVER['REQUEST_METHOD'] ?? 'GET'),
                'request_uri' => (string) ($_SERVER['REQUEST_URI'] ?? ''),
                'profile_id' => (int) ($_SESSION['glpiactiveprofile']['id'] ?? 0),
                'entity_id' => (int) ($_SESSION['glpiactive_entity'] ?? 0),
            ]);
            self::setMessage(
                'error',
                __('Sua sessão expirou ou a página ficou desatualizada. Recarregue a página e tente novamente.', 'glpiacessivel')
            );
            \Html::redirect($returnUrl);
            return false;
        }
    }

    protected static function container(): Container
    {
        return Container::get();
    }

    /**
     * @param array<string, mixed> $auditContext
     */
    protected static function denyAccess(
        string $title,
        string $message,
        string $auditEvent,
        array $auditContext = []
    ): void {
        self::container()->auditLogger()->log($auditEvent, $auditContext + [
            'profile_id' => (int) ($_SESSION['glpiactiveprofile']['id'] ?? 0),
            'entity_id' => (int) ($_SESSION['glpiactive_entity'] ?? 0),
        ]);

        if (!headers_sent()) {
            http_response_code(403);
        }

        View::render('errors/permission', [
            'title' => $title,
            'message' => $message,
            'alert_title' => __('Acesso bloqueado pelo GLPI', 'glpiacessivel'),
            'alert_message' => __('Entre com um perfil autorizado ou solicite acesso ao administrador do GLPI.', 'glpiacessivel'),
            'return_url' => Url::plugin('front/acessivel.php'),
        ]);
    }

    protected static function setMessage(string $type, string $message): void
    {
        $_SESSION['glpiacessivel_flash'] = ['type' => $type, 'message' => $message];
    }
}
