<?php

declare(strict_types=1);

namespace GlpiPlugin\Glpiacessivel\UI\Controller;

use GlpiPlugin\Glpiacessivel\Application\AdvancedTicketSearchRequest;
use GlpiPlugin\Glpiacessivel\Application\ConfigService;
use GlpiPlugin\Glpiacessivel\Application\TicketSearchStateStore;
use GlpiPlugin\Glpiacessivel\Application\TicketListStateStore;
use GlpiPlugin\Glpiacessivel\Domain\Ticket\NativeSearchValidationException;
use GlpiPlugin\Glpiacessivel\Infrastructure\Search\GlpiResourceSelectorProvider;
use GlpiPlugin\Glpiacessivel\Infrastructure\Search\TicketListCapacityGuard;
use GlpiPlugin\Glpiacessivel\Infrastructure\Search\TicketListRateLimiter;
use GlpiPlugin\Glpiacessivel\Infrastructure\Security\GlpiSessionContextSnapshot;
use GlpiPlugin\Glpiacessivel\Security\InputSanitizer;
use GlpiPlugin\Glpiacessivel\Security\SessionContextGuard;
use GlpiPlugin\Glpiacessivel\Support\UploadedFileMapper;
use GlpiPlugin\Glpiacessivel\Support\FormValidationException;
use GlpiPlugin\Glpiacessivel\Support\I18n;
use GlpiPlugin\Glpiacessivel\Support\Url;
use GlpiPlugin\Glpiacessivel\UI\Presenter\TicketSearchSummaryPresenter;
use GlpiPlugin\Glpiacessivel\UI\View\View;

final class TicketController extends BaseController
{
    private const ADVANCED_SEARCH_ERROR_SESSION_KEY = 'glpiacessivel_advanced_search_error_v2';
    private const PII_REVEAL_TTL_SECONDS = 300;
    private const CRITICAL_CONFIRM_TTL_SECONDS = 300;
    private const CRITICAL_CONFIRM_SESSION_KEY = 'glpiacessivel_ticket_critical_confirmations';

    public static function index(): void
    {
        self::requireLogin();
        if (!self::requireModuleEnabled(ConfigService::MODULE_TICKETS)) {
            return;
        }
        if (!self::container()->authorization()->canViewTickets()) {
            self::denyAccess(
                __('Chamados indisponíveis para este perfil', 'glpiacessivel'),
                __('O perfil ativo não possui permissão para consultar a lista de chamados.', 'glpiacessivel'),
                'ticket.list.access_denied'
            );
            return;
        }

        if (($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'POST') {
            self::processAdvancedSearchPost();
            return;
        }

        $sanitizer = new InputSanitizer();
        $savedSearchState = SavedTicketSearchController::indexState($_GET);
        $savedFilters = (array) ($savedSearchState['filters'] ?? []);
        $savedSearchService = self::container()->savedTicketSearchService();
        $advancedSearchCatalog = [];
        $advancedContextRevision = '';
        $advancedSearchState = [];
        $advancedSearchToken = '';
        $frequentFilterPresentation = ['status_mode' => 'normal'];
        $appliedSearchSummary = [
            'active' => false,
            'source' => '',
            'heading' => '',
            'saved_search_name' => '',
            'sections' => [],
            'warnings' => [],
            'plain_text' => '',
        ];
        $advancedErrorCode = self::consumeAdvancedSearchError();

        try {
            $advancedSearchCatalog = $savedSearchService->searchCatalog();
            $advancedContextRevision = self::advancedCatalogRevision($advancedSearchCatalog);
        } catch (\Throwable $e) {
            $advancedErrorCode = self::advancedFailureCode(
                $e,
                'native_search_catalog_unavailable'
            );
            self::auditAdvancedFailure('get_catalog', $advancedErrorCode, $e);
        }

        $filters = [
            'scope' => $sanitizer->enum($_GET['scope'] ?? ($savedFilters['scope'] ?? 'all'), ['all', 'mine', 'group'], 'all'),
            'status' => $sanitizer->text($_GET['status'] ?? ($savedFilters['status'] ?? ''), 4),
            'q' => $sanitizer->text($_GET['q'] ?? ($savedFilters['q'] ?? ''), 120),
            'group_id' => max(0, $sanitizer->int($_GET['group_id'] ?? ($savedFilters['group_id'] ?? 0), 0)),
            'group_by' => $sanitizer->enum($_GET['group_by'] ?? ($savedFilters['group_by'] ?? 'none'), ['none', 'group'], 'none'),
            'page' => max(1, $sanitizer->int($_GET['page'] ?? 1, 1)),
            'page_size' => $sanitizer->int($_GET['page_size'] ?? ($savedFilters['page_size'] ?? 20), 20),
            'sort' => $sanitizer->enum($_GET['sort'] ?? ($savedFilters['sort'] ?? 'date_mod'), ['id', 'name', 'status', 'priority', 'date', 'date_mod'], 'date_mod'),
            'direction' => $sanitizer->enum($_GET['direction'] ?? ($savedFilters['direction'] ?? 'DESC'), ['ASC', 'DESC'], 'DESC'),
            'columns' => \GlpiPlugin\Glpiacessivel\Infrastructure\Repository\SavedTicketSearchRepository::normalizePortalFilters([
                'columns' => $_GET['columns'] ?? ($savedFilters['columns'] ?? []),
            ])['columns'],
        ];
        $filters['columns'] = self::validatedPresentationColumns(
            (array) $filters['columns'],
            $advancedSearchCatalog
        );
        foreach (
            [
            'native_criteria',
            'native_metacriteria',
            'native_sort',
            'native_order',
            'native_is_deleted',
            'native_saved_search_id',
            'native_parameters',
            ] as $nativeKey
        ) {
            if (array_key_exists($nativeKey, $savedFilters)) {
                $filters[$nativeKey] = $savedFilters[$nativeKey];
            }
        }
        if (is_array($savedSearchState['active'] ?? null)) {
            $filters['scope'] = (string) ($savedFilters['scope'] ?? 'all');
            $filters['status'] = '';
            $filters['q'] = (string) ($savedFilters['q'] ?? '');
            $filters['group_id'] = 0;
            $filters['group_by'] = 'none';
            $filters['sort'] = 'date_mod';
            $filters['direction'] = 'DESC';
            $savedColumns = array_key_exists('columns', $savedFilters)
                ? (array) $savedFilters['columns']
                : (array) \GlpiPlugin\Glpiacessivel\Infrastructure\Repository\SavedTicketSearchRepository::normalizePortalFilters([])['columns'];
            $filters['columns'] = self::validatedPresentationColumns(
                $savedColumns,
                $advancedSearchCatalog
            );
        }
        $draftFrequentFilters = [
            'status' => (string) ($filters['status'] ?? ''),
            'group_id' => (int) ($filters['group_id'] ?? 0),
        ];
        if (!empty($savedSearchState['invalid'])) {
            $filters['saved_search_invalid'] = true;
        }

        $requestedAdvancedToken = is_string($_GET['advanced_search_token'] ?? null)
            ? trim((string) $_GET['advanced_search_token'])
            : '';
        if ($requestedAdvancedToken !== '') {
            try {
                if ($advancedContextRevision === '') {
                    throw new NativeSearchValidationException(
                        'native_search_context_stale',
                        'catalog.context_revision'
                    );
                }
                $storedState = (new TicketSearchStateStore())->resolve(
                    $requestedAdvancedToken,
                    $advancedContextRevision
                );
                if ($storedState === null) {
                    throw new NativeSearchValidationException(
                        'native_search_token_invalid',
                        'advanced_search_token'
                    );
                }
                $wrapper = self::advancedStateWrapper($storedState);
                $definition = $savedSearchService->validateDefinition($wrapper['definition']);
                $filters = self::applyAdvancedDefinitionToFilters(
                    $filters,
                    $definition,
                    $wrapper['page_size'],
                    $wrapper['presentation']
                );
                $draftFrequentFilters = $wrapper['frequent_filters'];
                $focusResults = is_string($_GET['focus'] ?? null)
                    && $_GET['focus'] === 'results';
                $advancedSearchState = self::advancedBuilderState(
                    self::editorDefinitionWithoutFrequentFilters(
                        $definition,
                        $draftFrequentFilters,
                        $advancedSearchCatalog
                    ),
                    true,
                    $focusResults
                );
                $appliedSearchSummary = (new TicketSearchSummaryPresenter())->present(
                    $definition,
                    $advancedSearchCatalog,
                    [],
                    $filters
                );
                $advancedSearchState['summary'] = $appliedSearchSummary['plain_text'];
                $advancedSearchToken = $requestedAdvancedToken;
                $advancedErrorCode = '';
                $savedSearchState['selected'] = '';
                $savedSearchState['active'] = null;
                $savedSearchState['invalid'] = false;
            } catch (\Throwable $e) {
                $advancedErrorCode = self::advancedFailureCode(
                    $e,
                    'native_search_token_invalid'
                );
                self::auditAdvancedFailure('get_token', $advancedErrorCode, $e);
            }
        } elseif (
            $advancedErrorCode === ''
            && $advancedContextRevision !== ''
            && is_array($savedSearchState['active'] ?? null)
            && in_array(
                (string) ($savedSearchState['active']['capability'] ?? ''),
                ['editable', 'executable_read_only'],
                true
            )
        ) {
            try {
                $definition = (array) ($savedSearchState['active']['definition'] ?? []);
                if (!array_key_exists('columns', $definition)) {
                    $definition['columns'] = (array) ($filters['columns'] ?? []);
                }
                $definition = $savedSearchService->validateDefinition($definition);
                $statusProjection = self::projectSavedStatusFilter(
                    $definition,
                    $advancedSearchCatalog
                );
                if ($statusProjection['mode'] === 'simple') {
                    $draftFrequentFilters['status'] = $statusProjection['value'];
                    $definitionForEditor = self::definitionWithoutProjectedStatus(
                        $definition,
                        $statusProjection
                    );
                    $frequentFilterPresentation['status_mode'] = 'saved_simple';
                } elseif ($statusProjection['mode'] === 'advanced') {
                    $definitionForEditor = $definition;
                    $frequentFilterPresentation['status_mode'] = 'saved_advanced';
                } else {
                    $definitionForEditor = $definition;
                }
                $nativePageSize = (int) ($filters['page_size'] ?? 20);
                $filters['page_size'] = in_array($nativePageSize, [10, 20, 50, 100], true)
                    ? $nativePageSize
                    : 20;
                $filters['columns'] = (array) ($definition['columns'] ?? $filters['columns'] ?? []);
                $editable = (string) ($savedSearchState['active']['capability'] ?? '') === 'editable';
                $advancedSearchState = self::advancedBuilderState($definitionForEditor, $editable, false);
                $appliedSearchSummary = (new TicketSearchSummaryPresenter())->present(
                    $definition,
                    $advancedSearchCatalog,
                    (array) $savedSearchState['active'],
                    $filters
                );
                $advancedSearchState['summary'] = $appliedSearchSummary['plain_text'];
            } catch (\Throwable $e) {
                self::auditAdvancedFailure(
                    'native_builder',
                    'native_search_saved_builder_unavailable',
                    $e
                );
            }
        }

        if ($advancedErrorCode !== '') {
            $advancedSearchState = [
                'error_codes' => [$advancedErrorCode],
                'errors' => [self::advancedErrorMessage($advancedErrorCode)],
                'focus_results' => false,
                'editable' => true,
            ];
            $advancedSearchToken = '';
        }
        if (
            is_array($savedSearchState['active'] ?? null)
            && (string) ($savedSearchState['active']['capability'] ?? '') === 'native_only'
        ) {
            $frequentFilterPresentation['status_mode'] = 'saved_native_only';
        }
        $filters = self::failClosedAdvancedTokenFilters(
            $filters,
            $requestedAdvancedToken,
            $advancedErrorCode
        );
        $filters['saved_search'] = (string) ($savedSearchState['selected'] ?? '');

        $service = self::container()->ticketService();
        $config = self::container()->configService();
        $asyncResults = ['enabled' => false];
        if ($config->isTicketAsyncListEnabled()) {
            try {
                $snapshot = (new GlpiSessionContextSnapshot())->snapshot();
                $stateToken = (new TicketListStateStore())->issue($filters, $snapshot['revision']);
                $result = [
                    'items' => [],
                    'total' => null,
                    'total_state' => 'pending',
                    'page' => (int) ($filters['page'] ?? 1),
                    'page_size' => (int) ($filters['page_size'] ?? 20),
                    'has_previous' => (int) ($filters['page'] ?? 1) > 1,
                    'has_more' => false,
                    'backend' => 'async_pending',
                    'backend_reason' => 'client_fetch_pending',
                ];
                $asyncResults = [
                    'enabled' => true,
                    'contract_version' => 2,
                    'page' => (int) ($filters['page'] ?? 1),
                    'url' => Url::plugin('front/ticket.results.php'),
                    'state_token' => $stateToken,
                    'context_revision' => $snapshot['revision'],
                    'request_timeout_ms' => 5000,
                    'native_fallback_url' => (string) (($GLOBALS['CFG_GLPI']['root_doc'] ?? '') . '/front/ticket.php'),
                ];
            } catch (\Throwable $e) {
                self::container()->auditLogger()->log('ticket.results.async_shell_failed', [
                    'exception' => get_class($e),
                ]);
                // Never fall back to the potentially expensive synchronous list
                // after an async bootstrap failure. Keep the shell usable and
                // expose the native GLPI list as the safe operational fallback.
                $result = [
                    'items' => [],
                    'total' => null,
                    'total_state' => 'unavailable',
                    'page' => (int) ($filters['page'] ?? 1),
                    'page_size' => (int) ($filters['page_size'] ?? 20),
                    'has_previous' => (int) ($filters['page'] ?? 1) > 1,
                    'has_more' => false,
                    'backend' => 'async_bootstrap_failed',
                    'backend_reason' => 'temporarily_unavailable',
                ];
                $asyncResults = [
                    'enabled' => true,
                    'contract_version' => 2,
                    'bootstrap_error' => 'temporarily_unavailable',
                    'native_fallback_url' => (string) (($GLOBALS['CFG_GLPI']['root_doc'] ?? '') . '/front/ticket.php'),
                ];
            }
        } else {
            $capacityGuard = null;
            $capacityLeaseId = '';
            $knownEmptyGroupScope = self::isKnownEmptyCurrentGroupScope($filters);
            if (!$knownEmptyGroupScope) {
                $rate = (new TicketListRateLimiter(
                    $config->getTicketListRateLimit(),
                    $config->getTicketListRateWindowSeconds(),
                    $config->getTicketListRateBurst()
                ))->consume();
                if (empty($rate['allowed'])) {
                    $retryAfter = max(1, (int) ($rate['retry_after'] ?? 1));
                    if (!headers_sent()) {
                        http_response_code(429);
                        header('Retry-After: ' . (string) $retryAfter);
                    }
                    $result = [
                        'items' => [],
                        'total' => null,
                        'total_state' => 'unavailable',
                        'page' => (int) ($filters['page'] ?? 1),
                        'page_size' => (int) ($filters['page_size'] ?? 20),
                        'has_previous' => (int) ($filters['page'] ?? 1) > 1,
                        'has_more' => false,
                        'backend' => 'rate_limited',
                        'backend_reason' => 'rate_limited',
                        'retry_after' => $retryAfter,
                    ];
                }
            }
            if (!isset($result) && !$knownEmptyGroupScope && $config->isTicketListCapacityGuardEnabled()) {
                $capacityGuard = new TicketListCapacityGuard(
                    $config->getTicketListCapacityMaxConcurrent(),
                    $config->getTicketListCapacityLeaseSeconds(),
                    $config->getTicketListCapacityRetryAfterSeconds(),
                    $config->getTicketListCapacityBackend()
                );
                $capacity = $capacityGuard->acquire();
                if (empty($capacity['allowed'])) {
                    $retryAfter = max(1, (int) ($capacity['retry_after'] ?? 1));
                    $reason = (string) ($capacity['reason'] ?? 'capacity_backend_error');
                    $isCapacityContention = in_array($reason, [
                        'capacity_limit_reached',
                        'user_context_in_flight',
                    ], true);
                    if (!headers_sent()) {
                        http_response_code($isCapacityContention ? 429 : 503);
                        header('Retry-After: ' . (string) $retryAfter);
                    }
                    $result = [
                        'items' => [],
                        'total' => null,
                        'total_state' => 'unavailable',
                        'page' => (int) ($filters['page'] ?? 1),
                        'page_size' => (int) ($filters['page_size'] ?? 20),
                        'has_previous' => (int) ($filters['page'] ?? 1) > 1,
                        'has_more' => false,
                        'backend' => 'capacity_guard_blocked',
                        'backend_reason' => $reason,
                        'retry_after' => $retryAfter,
                    ];
                } else {
                    $capacityLeaseId = (string) ($capacity['lease_id'] ?? '');
                }
            }
            if (!isset($result)) {
                $capacityOutcome = null;
                try {
                    try {
                        $result = $service->list($filters);
                        $capacityOutcome = self::capacityOutcome($result);
                    } catch (\Throwable $e) {
                        $capacityOutcome = false;
                        throw $e;
                    }
                } finally {
                    if ($capacityGuard instanceof TicketListCapacityGuard && $capacityLeaseId !== '') {
                        $capacityGuard->release($capacityLeaseId, $capacityOutcome);
                    }
                }
            }
        }
        $result['contract_version'] = 2;
        $groupOptions = $service->groupFilterOptions();
        $appliedSearchSummary = self::completeFrequentFilterSummary(
            $appliedSearchSummary,
            $filters,
            $groupOptions,
            $requestedAdvancedToken,
            is_array($savedSearchState['active'] ?? null)
        );
        $groupedItems = self::groupTicketsByGroup((array) ($result['items'] ?? []), (string) $filters['scope'], (string) $filters['group_by']);
        $canCreateTicket = self::container()->portalModulePolicy()->isVisible(ConfigService::MODULE_TICKET_CREATE)
            && self::container()->authorization()->canCreateTickets();

        View::render('tickets/list', [
            'title' => __('Chamados', 'glpiacessivel'),
            'result' => $result,
            'filters' => $filters,
            'group_options' => $groupOptions,
            'grouped_items' => $groupedItems,
            'can_create_ticket' => $canCreateTicket,
            'saved_search_catalog' => (array) ($savedSearchState['catalog'] ?? []),
            'selected_saved_search' => (string) ($savedSearchState['selected'] ?? ''),
            'active_saved_search' => is_array($savedSearchState['active'] ?? null) ? $savedSearchState['active'] : null,
            'saved_search_invalid' => !empty($savedSearchState['invalid']),
            'showOperationalDiagnostics' => self::container()->authorization()->canViewOperationalDiagnostics(),
            'advanced_search_catalog' => $advancedSearchCatalog,
            'advanced_search_state' => $advancedSearchState,
            'advanced_search_token' => $advancedSearchToken,
            'draft_frequent_filters' => $draftFrequentFilters,
            'frequent_filter_presentation' => $frequentFilterPresentation,
            'applied_search_summary' => $appliedSearchSummary,
            'csrf_token' => self::csrf()->token(),
            'ticket_results_async' => $asyncResults,
        ]);
    }

    /** @param array<string,mixed> $filters */
    private static function isKnownEmptyCurrentGroupScope(array $filters): bool
    {
        return (string) ($filters['scope'] ?? '') === 'group'
            && (int) ($filters['group_id'] ?? 0) <= 0
            && ($_SESSION[SessionContextGuard::GROUP_CONTEXT_LOAD_CONFIRMED_SESSION_KEY] ?? null) !== false
            && array_key_exists('glpigroups', $_SESSION)
            && is_array($_SESSION['glpigroups'])
            && $_SESSION['glpigroups'] === [];
    }

    /**
     * Complete only an ordinary list summary. Saved and advanced searches
     * already carry a validated native definition and must remain the sole
     * source of truth for their own summary.
     *
     * @param array<string,mixed> $summary
     * @param array<string,mixed> $filters
     * @param array<int,array<string,mixed>> $groupOptions
     * @return array<string,mixed>
     */
    private static function completeFrequentFilterSummary(
        array $summary,
        array $filters,
        array $groupOptions,
        string $requestedAdvancedToken,
        bool $hasActiveSavedSearch
    ): array {
        if (
            (string) ($summary['source'] ?? '') !== ''
            || $requestedAdvancedToken !== ''
            || $hasActiveSavedSearch
        ) {
            return $summary;
        }

        return (new TicketSearchSummaryPresenter())->presentFrequentFilters(
            $filters,
            $groupOptions
        );
    }

    /** @param array<string,mixed> $result */
    private static function capacityOutcome(array $result): ?bool
    {
        if ((string) ($result['backend'] ?? '') === 'search_api') {
            return true;
        }
        return in_array((string) ($result['backend_reason'] ?? ''), [
            'bounded_search_execution_unavailable',
            'bounded_search_execution_failed',
            'bounded_search_plan_failed',
        ], true) ? false : null;
    }

    public static function create(): void
    {
        self::requireLogin();
        if (!self::requireModuleEnabled(ConfigService::MODULE_TICKET_CREATE)) {
            return;
        }
        if (!self::container()->authorization()->canCreateTickets()) {
            self::denyAccess(
                __('Criação de chamado indisponível para este perfil', 'glpiacessivel'),
                __('O perfil ativo não possui permissão para criar chamados.', 'glpiacessivel'),
                'ticket.create.access_denied'
            );
            return;
        }

        if (($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'POST') {
            self::csrf()->validateRequest(true);
            self::storeCreate();
            return;
        }

        self::renderCreateForm(self::defaultCreateValues(), []);
    }

    public static function detail(): void
    {
        self::requireLogin();
        if (!self::requireModuleEnabled(ConfigService::MODULE_TICKETS)) {
            return;
        }
        if (!self::container()->authorization()->canViewTickets()) {
            self::denyAccess(
                __('Chamado indisponível para este perfil', 'glpiacessivel'),
                __('O perfil ativo não possui permissão para consultar chamados.', 'glpiacessivel'),
                'ticket.detail.access_denied'
            );
            return;
        }

        $sanitizer = new InputSanitizer();
        $ticketId = max(1, $sanitizer->int($_GET['id'] ?? 0));

        $service = self::container()->ticketService();
        $ticket = $service->detail($ticketId, self::getRevealedFields($ticketId));
        if ($ticket === null) {
            self::container()->auditLogger()->log('ticket.detail.denied', [
                'reason' => 'not_found_or_not_authorized',
            ], $ticketId);
            self::setMessage(
                'error',
                __('Chamado não encontrado ou sem acesso no perfil e entidade atuais.', 'glpiacessivel')
            );
            \Html::redirect(Url::plugin('front/tickets.php?scope=mine'));
            return;
        }

        View::render('tickets/detail', [
            'title' => __('Detalhe do chamado', 'glpiacessivel'),
            'ticket' => $ticket,
            'csrf_token' => self::csrf()->token(true),
            'csrf_tokens' => [
                'followup' => self::csrf()->token(true),
                'task' => self::csrf()->token(true),
                'solution' => self::csrf()->token(true),
                'status' => self::csrf()->token(true),
                'general_update' => self::csrf()->token(true),
                'routing' => self::csrf()->token(true),
                'requester_decision' => self::csrf()->token(true),
                'solution_decision' => self::csrf()->token(true),
                'pii_reveal' => self::csrf()->token(true),
            ],
            'critical_confirmations' => self::ticketCriticalConfirmationTokens($ticketId),
            'solution_decision_operation_id' => bin2hex(random_bytes(16)),
        ]);
    }

    public static function action(): void
    {
        self::requireLogin();
        if (!self::requireModuleEnabled(ConfigService::MODULE_TICKETS)) {
            return;
        }

        $sanitizer = new InputSanitizer();
        $ticketId = $sanitizer->int($_POST['ticket_id'] ?? 0);

        $redirectAnchor = '';
        try {
            $csrfPreserveToken = in_array(
                (string) ($_POST['action'] ?? ''),
                ['solution_approve', 'solution_refuse'],
                true
            );
            self::csrf()->validateRequest($csrfPreserveToken);
        } catch (\Throwable $e) {
            self::container()->auditLogger()->log('csrf.failed', [
                'endpoint' => 'ticket.action',
                'exception' => get_class($e),
                'action_name' => (string) ($_POST['action'] ?? ''),
            ], $ticketId);

            self::setMessage(
                'error',
                __('Sua sessão expirou ou o token de segurança venceu. Recarregue o chamado e tente novamente.', 'glpiacessivel')
            );
            \Html::redirect(Url::plugin('front/tickets.php?id=' . $ticketId));
            return;
        }

        if ($ticketId < 1) {
            self::container()->auditLogger()->log('ticket.action.blocked', [
                'reason' => 'invalid_ticket_id',
                'action_name' => (string) ($_POST['action'] ?? ''),
            ]);
            self::setMessage('error', __('Chamado inválido. Reabra o chamado e tente novamente.', 'glpiacessivel'));
            \Html::redirect(Url::plugin('front/tickets.php'));
            return;
        }

        $action = $sanitizer->enum($_POST['action'] ?? '', ['followup', 'task', 'solution', 'status', 'general_update', 'routing', 'requester_decision', 'solution_approve', 'solution_refuse', 'pii_reveal'], '');
        $content = $sanitizer->text($_POST['content'] ?? '', 16000);
        $status = $sanitizer->int($_POST['status'] ?? 0);
        $decision = $sanitizer->int($_POST['decision'] ?? 0, 0);
        $routingReason = $sanitizer->text($_POST['routing_reason'] ?? '', 255);
        $routingRevision = $sanitizer->text($_POST['routing_revision'] ?? '', 64);
        $generalRevision = $sanitizer->text($_POST['expected_revision'] ?? '', 64);
        $solutionDecisionRevision = $sanitizer->text($_POST['solution_decision_revision'] ?? '', 64);
        $solutionDecisionOperationId = $sanitizer->text($_POST['solution_decision_operation_id'] ?? '', 32);
        $generalUpdateReason = $sanitizer->text($_POST['update_reason'] ?? '', 255);
        $criticalConfirmationToken = $sanitizer->text($_POST['critical_confirmation_token'] ?? '', 512);
        $generalUpdateInput = [];
        foreach (['name' => 255, 'content' => 16000] as $field => $maximumLength) {
            if (array_key_exists($field, $_POST)) {
                $generalUpdateInput[$field] = $sanitizer->text($_POST[$field], $maximumLength);
            }
        }
        foreach (
            [
                'type',
                'itilcategories_id',
                'locations_id',
                'requesttypes_id',
                'urgency',
                'impact',
                'priority',
            ] as $field
        ) {
            if (array_key_exists($field, $_POST)) {
                $generalUpdateInput[$field] = max(0, $sanitizer->int($_POST[$field], 0));
            }
        }
        $followupTemplateId = max(0, $sanitizer->int($_POST['itilfollowuptemplates_id'] ?? 0, 0));
        $taskTemplateId = max(0, $sanitizer->int($_POST['tasktemplates_id'] ?? 0, 0));
        $solutionTemplateId = max(0, $sanitizer->int($_POST['solutiontemplates_id'] ?? 0, 0));
        $submittedSolutionTypeId = array_key_exists('solutiontypes_id', $_POST)
            ? max(0, $sanitizer->int($_POST['solutiontypes_id'], 0))
            : 0;
        $solutionTypeId = $submittedSolutionTypeId > 0 ? $submittedSolutionTypeId : null;
        $followupIsPrivate = $sanitizer->enum(
            $_POST['followup_is_private'] ?? '0',
            ['0', '1'],
            '0'
        ) === '1' ? 1 : 0;
        $piiField = $sanitizer->enum(
            $_POST['pii_field'] ?? '',
            ['requester_email', 'requester_phone', 'requester_mobile'],
            ''
        );
        $piiReason = $sanitizer->text($_POST['pii_reason'] ?? '', 255);
        $taskInput = [
            'state' => max(0, $sanitizer->int($_POST['task_state'] ?? 0, 0)),
            'taskcategories_id' => max(0, $sanitizer->int($_POST['taskcategories_id'] ?? 0, 0)),
            'users_id_tech' => max(0, $sanitizer->int($_POST['task_users_id_tech'] ?? 0, 0)),
            'groups_id_tech' => max(0, $sanitizer->int($_POST['task_groups_id_tech'] ?? 0, 0)),
            'actiontime' => max(0, $sanitizer->int($_POST['task_actiontime'] ?? 0, 0)),
            'begin' => $sanitizer->text($_POST['task_begin'] ?? '', 32),
            'end' => $sanitizer->text($_POST['task_end'] ?? '', 32),
            'is_private' => $sanitizer->enum(
                $_POST['task_is_private'] ?? '0',
                ['0', '1'],
                '0'
            ) === '1' ? 1 : 0,
        ];

        if (self::isCriticalTicketAction($action)) {
            try {
                self::validateTicketCriticalConfirmation($ticketId, $action, $_POST);
            } catch (\Throwable $e) {
                self::container()->auditLogger()->log('ticket.critical_confirmation.blocked', [
                    'action' => $action,
                    'reason' => $e->getMessage(),
                ], $ticketId);
                self::setMessage('error', __('Confirme a ação crítica na tela antes de executar.', 'glpiacessivel'));
                \Html::redirect(Url::plugin('front/tickets.php?id=' . $ticketId));
                return;
            }
        }

        $service = self::container()->ticketService();

        try {
            $ok = false;
            $successMessage = __('Ação executada com sucesso.', 'glpiacessivel');
            switch ($action) {
                case 'followup':
                    $followupIsPrivate = $service->resolveFollowupPrivacy(
                        $ticketId,
                        $followupTemplateId,
                        $followupIsPrivate
                    );
                    $ok = $service->addFollowup(
                        $ticketId,
                        $content,
                        UploadedFileMapper::map('followup_filename'),
                        $followupTemplateId,
                        $followupIsPrivate
                    );
                    $successMessage = $followupIsPrivate === 1
                        ? sprintf(__('Nota interna privada adicionada ao chamado #%d.', 'glpiacessivel'), $ticketId)
                        : sprintf(__('Resposta pública adicionada ao chamado #%d.', 'glpiacessivel'), $ticketId);
                    break;
                case 'task':
                    $ok = $service->addTask(
                        $ticketId,
                        $content,
                        $taskInput,
                        UploadedFileMapper::map('task_filename'),
                        $taskTemplateId
                    );
                    $successMessage = !empty($taskInput['is_private'])
                        ? sprintf(__('Tarefa interna privada adicionada ao chamado #%d.', 'glpiacessivel'), $ticketId)
                        : sprintf(__('Tarefa pública adicionada ao chamado #%d.', 'glpiacessivel'), $ticketId);
                    break;
                case 'solution':
                    $ok = $service->addSolution(
                        $ticketId,
                        $content,
                        $solutionTemplateId,
                        $solutionTypeId,
                        $criticalConfirmationToken
                    );
                    $successMessage = sprintf(
                        __('Solução adicionada ao chamado #%d e estado confirmado no GLPI.', 'glpiacessivel'),
                        $ticketId
                    );
                    break;
                case 'status':
                    if ($status <= 0) {
                        throw new FormValidationException([[
                            'field' => 'status',
                            'code' => 'status_required',
                            'message' => __('Selecione um novo status antes de continuar.', 'glpiacessivel'),
                        ]]);
                    }
                    $ok = $service->changeStatus($ticketId, $status);
                    break;
                case 'general_update':
                    if (preg_match('/\A[a-f0-9]{64}\z/D', $generalRevision) !== 1) {
                        throw new FormValidationException([[
                            'field' => 'general_fields',
                            'code' => 'ticket_general_context_stale',
                            'message' => __('Os dados atuais do chamado não puderam ser conferidos. Recarregue a página antes de editar.', 'glpiacessivel'),
                        ]]);
                    }
                    if ($generalUpdateInput === []) {
                        throw new FormValidationException([[
                            'field' => 'general_fields',
                            'code' => 'ticket_general_fields_empty',
                            'message' => __('Nenhum campo editável foi enviado.', 'glpiacessivel'),
                        ]]);
                    }
                    $outcome = $service->updateGeneralFields(
                        $ticketId,
                        $generalUpdateInput,
                        $generalRevision,
                        $generalUpdateReason
                    );
                    $outcomeStatus = (string) ($outcome['status'] ?? 'rejected');
                    if ($outcomeStatus === 'verified') {
                        $ok = true;
                        $successMessage = __('Dados do chamado atualizados e confirmados pelo GLPI.', 'glpiacessivel');
                    } elseif ($outcomeStatus === 'unchanged') {
                        $ok = true;
                        $successMessage = __('Nenhuma alteração foi necessária; os dados do chamado já estavam atualizados.', 'glpiacessivel');
                    } elseif ($outcomeStatus === 'context_stale') {
                        throw new FormValidationException([[
                            'field' => 'general_fields',
                            'code' => 'ticket_general_context_stale',
                            'message' => __('O chamado foi alterado por outra pessoa. Recarregue a página, confira os dados atuais e tente novamente.', 'glpiacessivel'),
                        ]]);
                    } elseif ($outcomeStatus === 'uncertain') {
                        throw new FormValidationException([[
                            'field' => 'general_fields',
                            'code' => 'ticket_general_update_uncertain',
                            'message' => __('A atualização pode ter sido registrada, mas o GLPI não confirmou todos os campos. Não envie novamente; recarregue o chamado para conferir.', 'glpiacessivel'),
                        ]], '', [
                            'partial_success' => true,
                            'ticket_id' => $ticketId,
                        ]);
                    } else {
                        throw new FormValidationException([[
                            'field' => 'general_fields',
                            'code' => 'ticket_general_update_rejected',
                            'message' => __('O GLPI recusou a atualização. Confira suas permissões e os valores informados.', 'glpiacessivel'),
                        ]]);
                    }
                    $redirectAnchor = '#editar-dados-chamado';
                    break;
                case 'routing':
                    if (preg_match('/\A[a-f0-9]{64}\z/D', $routingRevision) !== 1) {
                        throw new FormValidationException([[
                            'field' => 'routing_actors',
                            'code' => 'routing_context_stale',
                            'message' => __('A atribuição atual não pôde ser conferida. Recarregue a página antes de alterar os atores.', 'glpiacessivel'),
                        ]]);
                    }
                    $ok = $service->escalateTicketRouting(
                        $ticketId,
                        self::routingActorIdsFromPost('_users_id_assign'),
                        self::routingActorIdsFromPost('_users_id_observer'),
                        $routingReason,
                        self::routingActorIdsFromPost('_groups_id_assign'),
                        self::routingActorIdsFromPost('_groups_id_observer'),
                        $routingRevision,
                        self::routingActorIdsFromPost('_users_id_requester'),
                        self::routingActorIdsFromPost('_groups_id_requester'),
                        self::routingActorIdsFromPost('_suppliers_id_assign')
                    );
                    $redirectAnchor = '#roteamento-ticket';
                    break;
                case 'requester_decision':
                    $ok = $service->registerRequesterDecision($ticketId, $decision, $content);
                    break;
                case 'solution_approve':
                    if (preg_match('/\A[a-f0-9]{64}\z/D', $solutionDecisionRevision) !== 1) {
                        throw new FormValidationException([[
                            'field' => 'solution_decision',
                            'code' => 'solution_decision_context_stale',
                            'message' => __('A solução atual não pôde ser conferida. Recarregue o chamado e revise a decisão.', 'glpiacessivel'),
                        ]]);
                    }
                    $decisionOutcome = $service->approveSolution(
                        $ticketId,
                        $content,
                        UploadedFileMapper::map('solution_decision_filename'),
                        $solutionDecisionRevision,
                        $solutionDecisionOperationId
                    );
                    $ok = (string) ($decisionOutcome['status'] ?? '') === 'verified';
                    $successMessage = sprintf(
                        __('Solução aprovada. O chamado #%d foi fechado pelo GLPI.', 'glpiacessivel'),
                        $ticketId
                    );
                    $redirectAnchor = '#chamado-fechado';
                    break;
                case 'solution_refuse':
                    if (trim($content) === '') {
                        throw new FormValidationException([[
                            'field' => 'solution_decision_comment',
                            'code' => 'solution_refusal_reason_required',
                            'message' => __('Informe o motivo da recusa da solução.', 'glpiacessivel'),
                        ]]);
                    }
                    if (preg_match('/\A[a-f0-9]{64}\z/D', $solutionDecisionRevision) !== 1) {
                        throw new FormValidationException([[
                            'field' => 'solution_decision',
                            'code' => 'solution_decision_context_stale',
                            'message' => __('A solução atual não pôde ser conferida. Recarregue o chamado e revise a decisão.', 'glpiacessivel'),
                        ]]);
                    }
                    $decisionOutcome = $service->refuseSolution(
                        $ticketId,
                        $content,
                        UploadedFileMapper::map('solution_decision_filename'),
                        $solutionDecisionRevision,
                        $solutionDecisionOperationId
                    );
                    $ok = (string) ($decisionOutcome['status'] ?? '') === 'verified';
                    $successMessage = sprintf(
                        __('Solução recusada. O chamado #%d foi reaberto como %s pelo GLPI.', 'glpiacessivel'),
                        $ticketId,
                        self::ticketStatusLabel((int) ($decisionOutcome['ticket_status'] ?? 0))
                    );
                    $redirectAnchor = '#detalhe-ticket';
                    break;
                case 'pii_reveal':
                    if ($piiField === '') {
                        throw new \RuntimeException('Selecione o dado que precisa ser revelado.');
                    }
                    $service->revealPii($ticketId, $piiField, $piiReason);
                    self::grantTemporaryReveal($ticketId, $piiField);
                    $ok = true;
                    break;
            }

            self::setMessage(
                $ok ? 'success' : 'error',
                $ok ? $successMessage : __('Não foi possível executar a ação.', 'glpiacessivel')
            );
        } catch (FormValidationException $e) {
            $actionAnchor = [
                'general_update' => '#editar-dados-chamado',
                'routing' => '#roteamento-ticket',
                'solution' => '#itil-panel-solution',
                'solution_approve' => '#decisao-solucao',
                'solution_refuse' => '#decisao-solucao',
            ];
            $redirectAnchor = $actionAnchor[$action] ?? $redirectAnchor;
            $metadata = $e->metadata();
            $partialSuccess = !empty($metadata['partial_success']);
            $messages = array_values(array_unique(array_filter(array_map(
                static fn(array $error): string => trim((string) ($error['message'] ?? '')),
                $e->errors()
            ))));
            $message = implode(' ', $messages);
            if ($message === '') {
                $message = $partialSuccess && $action === 'solution'
                    ? __('A solução pode ter sido registrada, mas o status final não foi confirmado. Não envie novamente; atualize e verifique o chamado.', 'glpiacessivel')
                    : ($partialSuccess
                        ? __('A ação foi registrada, mas um ou mais anexos não foram confirmados. Não envie a ação novamente.', 'glpiacessivel')
                        : __('Não foi possível concluir a ação. Revise os dados e tente novamente.', 'glpiacessivel'));
            }

            if (empty($metadata['audit_recorded'])) {
                self::container()->auditLogger()->log('ticket.action.validation_failed', [
                    'action' => $action,
                    'partial_success' => $partialSuccess,
                    'created_itemtype' => (string) ($metadata['created_itemtype'] ?? ''),
                    'created_item_id' => (int) ($metadata['created_item_id'] ?? 0),
                    'error_codes' => array_values(array_unique(array_map(
                        static fn(array $error): string => (string) ($error['code'] ?? 'validation_failed'),
                        $e->errors()
                    ))),
                ], $ticketId);
            }
            self::setMessage('error', $message);
            if ($action === 'solution' && $partialSuccess) {
                $redirectAnchor = '#solution-operation-state';
            } elseif (!isset($actionAnchor[$action])) {
                $redirectAnchor = $partialSuccess ? '#timeline-ticket' : '';
            }
        } catch (\Throwable $e) {
            $actionAnchor = [
                'general_update' => '#editar-dados-chamado',
                'routing' => '#roteamento-ticket',
                'solution_approve' => '#decisao-solucao',
                'solution_refuse' => '#decisao-solucao',
            ];
            $redirectAnchor = $actionAnchor[$action] ?? $redirectAnchor;
            self::container()->auditLogger()->log('ticket.action.failed', [
                'action' => $action,
                'exception_class' => get_class($e),
                'error_code' => self::safeErrorCode($e),
            ], $ticketId);
            self::setMessage(
                'error',
                in_array($action, ['solution', 'solution_approve', 'solution_refuse'], true)
                    ? __('Não foi possível registrar a solução com segurança. Atualize o chamado e verifique o estado antes de tentar novamente.', 'glpiacessivel')
                    : __('Não foi possível concluir a ação. Nenhum detalhe técnico foi exibido por segurança.', 'glpiacessivel')
            );
        }

        \Html::redirect(Url::plugin('front/tickets.php?id=' . $ticketId) . $redirectAnchor);
    }

    private static function ticketStatusLabel(int $status): string
    {
        return match ($status) {
            1 => __('Novo', 'glpiacessivel'),
            2 => __('Em atendimento (atribuído)', 'glpiacessivel'),
            3 => __('Em atendimento (planejado)', 'glpiacessivel'),
            4 => __('Pendente', 'glpiacessivel'),
            5 => __('Solucionado', 'glpiacessivel'),
            6 => __('Fechado', 'glpiacessivel'),
            default => __('estado definido pelo GLPI', 'glpiacessivel'),
        };
    }

    /**
     * A missing routing field means "leave this role unchanged". The detail
     * form posts a zero-valued sentinel for every rendered multi-select so an
     * explicitly cleared role is still represented as an empty array.
     *
     * @return int[]|null
     */
    private static function routingActorIdsFromPost(string $field): ?array
    {
        $allowed = [
            '_users_id_assign',
            '_users_id_observer',
            '_users_id_requester',
            '_groups_id_assign',
            '_groups_id_observer',
            '_groups_id_requester',
            '_suppliers_id_assign',
        ];
        if (!in_array($field, $allowed, true) || !array_key_exists($field, $_POST)) {
            return null;
        }

        $submitted = array_values(array_unique(array_filter(
            array_map('intval', (array) $_POST[$field]),
            static fn(int $id): bool => $id > 0
        )));
        if (count($submitted) > GlpiResourceSelectorProvider::MAX_SELECTED_IDS) {
            throw new FormValidationException([[
                'field' => 'routing_actors',
                'code' => 'routing_actor_limit',
                'message' => I18n::translate('Um ou mais atores não são elegíveis no contexto atual.'),
            ]]);
        }

        return $submitted;
    }

    private static function safeErrorCode(\Throwable $exception): string
    {
        $candidate = trim($exception->getMessage());
        return preg_match('/\A[a-z][a-z0-9_.-]{0,63}\z/D', $candidate) === 1
            ? $candidate
            : 'ticket_action_failed';
    }

    /**
     * @return array<string, string>
     */
    private static function ticketCriticalConfirmationTokens(int $ticketId): array
    {
        self::purgeExpiredTicketCriticalConfirmations();
        $actions = ['general_update', 'routing', 'solution', 'status', 'requester_decision', 'solution_approve', 'solution_refuse'];
        $tokens = [];
        foreach ($actions as $action) {
            $token = bin2hex(random_bytes(16));
            $tokens[$action] = $token;
            $_SESSION[self::CRITICAL_CONFIRM_SESSION_KEY][$token] = [
                'ticket_id' => $ticketId,
                'action' => $action,
                'user_id' => (int) ($_SESSION['glpiID'] ?? 0),
                'expires_at' => time() + self::CRITICAL_CONFIRM_TTL_SECONDS,
            ];
        }

        return $tokens;
    }

    private static function isCriticalTicketAction(string $action): bool
    {
        return in_array($action, ['general_update', 'routing', 'solution', 'status', 'requester_decision', 'solution_approve', 'solution_refuse'], true);
    }

    /**
     * @param array<string, mixed> $post
     */
    private static function validateTicketCriticalConfirmation(int $ticketId, string $action, array $post): void
    {
        if ((string) ($post['critical_confirmed'] ?? '') !== '1') {
            throw new \RuntimeException('missing_confirmation_flag');
        }

        $token = (string) ($post['critical_confirmation_token'] ?? '');
        $state = is_array($_SESSION[self::CRITICAL_CONFIRM_SESSION_KEY] ?? null)
            ? $_SESSION[self::CRITICAL_CONFIRM_SESSION_KEY]
            : [];
        $confirmation = is_array($state[$token] ?? null) ? $state[$token] : null;

        if ($token === '' || $confirmation === null) {
            throw new \RuntimeException('invalid_confirmation_token');
        }
        if ((int) ($confirmation['expires_at'] ?? 0) < time()) {
            throw new \RuntimeException('expired_confirmation_token');
        }
        if ((int) ($confirmation['ticket_id'] ?? 0) !== $ticketId || (string) ($confirmation['action'] ?? '') !== $action) {
            throw new \RuntimeException('confirmation_scope_mismatch');
        }
        if ((int) ($confirmation['user_id'] ?? 0) !== (int) ($_SESSION['glpiID'] ?? 0)) {
            throw new \RuntimeException('confirmation_user_mismatch');
        }
        if (in_array($action, ['solution_approve', 'solution_refuse'], true)) {
            $operationId = (string) ($post['solution_decision_operation_id'] ?? '');
            $revision = (string) ($post['solution_decision_revision'] ?? '');
            if (
                preg_match('/\A[a-f0-9]{32}\z/D', $operationId) !== 1
                || preg_match('/\A[a-f0-9]{64}\z/D', $revision) !== 1
            ) {
                throw new \RuntimeException('confirmation_scope_mismatch');
            }

            $boundOperationId = (string) ($confirmation['operation_id'] ?? '');
            $boundRevision = (string) ($confirmation['revision'] ?? '');
            if ($boundOperationId !== '' || $boundRevision !== '') {
                if (
                    $boundOperationId === ''
                    || $boundRevision === ''
                    || !hash_equals($boundOperationId, $operationId)
                    || !hash_equals($boundRevision, $revision)
                ) {
                    throw new \RuntimeException('confirmation_scope_mismatch');
                }
            } elseif (isset($confirmation['used_at'])) {
                // Tokens used before the operation binding was introduced are
                // intentionally invalidated instead of being rebound on replay.
                throw new \RuntimeException('confirmation_scope_mismatch');
            } else {
                $_SESSION[self::CRITICAL_CONFIRM_SESSION_KEY][$token]['operation_id'] = $operationId;
                $_SESSION[self::CRITICAL_CONFIRM_SESSION_KEY][$token]['revision'] = $revision;
            }
            $_SESSION[self::CRITICAL_CONFIRM_SESSION_KEY][$token]['used_at'] = time();
        } else {
            unset($_SESSION[self::CRITICAL_CONFIRM_SESSION_KEY][$token]);
        }
    }

    private static function purgeExpiredTicketCriticalConfirmations(): void
    {
        $state = is_array($_SESSION[self::CRITICAL_CONFIRM_SESSION_KEY] ?? null)
            ? $_SESSION[self::CRITICAL_CONFIRM_SESSION_KEY]
            : [];
        $now = time();
        foreach ($state as $token => $confirmation) {
            if (!is_array($confirmation) || (int) ($confirmation['expires_at'] ?? 0) < $now) {
                unset($state[$token]);
            }
        }
        $_SESSION[self::CRITICAL_CONFIRM_SESSION_KEY] = $state;
    }

    /**
     * @return string[]
     */
    private static function getRevealedFields(int $ticketId): array
    {
        $state = $_SESSION['glpiacessivel_pii_reveal'] ?? [];
        $ticketState = $state[$ticketId] ?? null;
        if (!is_array($ticketState)) {
            return [];
        }

        $expiresAt = (int) ($ticketState['expires_at'] ?? 0);
        if ($expiresAt < time()) {
            unset($_SESSION['glpiacessivel_pii_reveal'][$ticketId]);
            return [];
        }

        $fields = $ticketState['fields'] ?? [];
        if (!is_array($fields)) {
            return [];
        }

        return array_values(array_intersect($fields, ['requester_email', 'requester_phone', 'requester_mobile']));
    }

    private static function grantTemporaryReveal(int $ticketId, string $field): void
    {
        if (!isset($_SESSION['glpiacessivel_pii_reveal']) || !is_array($_SESSION['glpiacessivel_pii_reveal'])) {
            $_SESSION['glpiacessivel_pii_reveal'] = [];
        }

        $entry = $_SESSION['glpiacessivel_pii_reveal'][$ticketId] ?? ['fields' => []];
        if (!is_array($entry)) {
            $entry = ['fields' => []];
        }

        $fields = $entry['fields'] ?? [];
        if (!is_array($fields)) {
            $fields = [];
        }
        if (!in_array($field, $fields, true)) {
            $fields[] = $field;
        }

        $_SESSION['glpiacessivel_pii_reveal'][$ticketId] = [
            'fields' => $fields,
            'expires_at' => time() + self::PII_REVEAL_TTL_SECONDS,
        ];
    }

    private static function processAdvancedSearchPost(): void
    {
        try {
            self::csrf()->validateRequest(true);
        } catch (\Throwable $e) {
            self::storeAdvancedFailure('post_csrf', 'native_search_csrf_failed', $e);
            \Html::redirect(Url::plugin('front/tickets.php?search_mode=advanced'));
            return;
        }

        $redirectUrl = Url::plugin('front/tickets.php?search_mode=advanced');
        try {
            $advanced = self::advancedPostPayload($_POST);
            $service = self::container()->savedTicketSearchService();
            $catalog = $service->searchCatalog();
            $catalogRevision = self::advancedCatalogRevision($catalog);
            $translated = (new AdvancedTicketSearchRequest())->translate($advanced);
            if (!hash_equals($catalogRevision, (string) $translated['context_revision'])) {
                throw new NativeSearchValidationException(
                    'native_search_context_stale',
                    'advanced.context_revision'
                );
            }

            $definition = self::compileFrequentFilters(
                (array) $translated['definition'],
                (array) $translated['frequent_filters'],
                $catalog
            );
            $definition = $service->validateDefinition($definition);
            self::container()->remoteSearchValueAuthorizer()->authorize(
                $definition,
                $catalogRevision
            );
            $token = (new TicketSearchStateStore())->issue([
                'definition' => $definition,
                'page_size' => (int) $translated['page_size'],
                'presentation' => self::advancedPresentationState(
                    (array) $translated['presentation']
                ),
                'frequent_filters' => self::validatedFrequentFilters(
                    (array) $translated['frequent_filters']
                ),
            ], $catalogRevision);
            unset($_SESSION[self::ADVANCED_SEARCH_ERROR_SESSION_KEY]);
            $redirectUrl = Url::plugin('front/tickets.php?' . http_build_query([
                'advanced_search_token' => $token,
                'focus' => 'results',
            ], '', '&', PHP_QUERY_RFC3986));
        } catch (\Throwable $e) {
            $code = self::advancedFailureCode($e, 'native_search_request_invalid');
            self::storeAdvancedFailure('post_validate', $code, $e);
        }

        \Html::redirect($redirectUrl);
    }

    /**
     * @param array<string,mixed> $post
     * @return array<string,mixed>
     */
    private static function advancedPostPayload(array $post): array
    {
        $allowedKeys = [
            '_glpi_csrf_token',
            'search_mode',
            'advanced_schema_version',
            'advanced_request_complete',
            'advanced',
            'q',
            'scope',
            'status',
            'group_id',
            'group_by',
        ];
        foreach (array_keys($post) as $key) {
            if (!is_string($key) || !in_array($key, $allowedKeys, true)) {
                throw new NativeSearchValidationException(
                    'native_search_parameter_unsupported',
                    'request'
                );
            }
        }

        if (($post['search_mode'] ?? null) !== 'advanced') {
            throw new NativeSearchValidationException(
                'native_search_mode_unsupported',
                'search_mode'
            );
        }
        $schemaVersion = $post['advanced_schema_version'] ?? null;
        if (!is_string($schemaVersion) || !in_array($schemaVersion, ['2', '3'], true)) {
            throw new NativeSearchValidationException(
                'native_search_schema_unsupported',
                'advanced_schema_version'
            );
        }
        if (($post['advanced_request_complete'] ?? null) !== '1') {
            throw new NativeSearchValidationException(
                'native_search_request_incomplete',
                'advanced_request_complete'
            );
        }
        if (!is_array($post['advanced'] ?? null)) {
            throw new NativeSearchValidationException(
                'native_search_request_invalid',
                'advanced'
            );
        }
        if ($schemaVersion === '3' && (!array_key_exists('q', $post) || !array_key_exists('scope', $post))) {
            throw new NativeSearchValidationException(
                'native_search_request_incomplete',
                'request'
            );
        }

        $query = $post['q'] ?? '';
        $validUtf8 = is_string($query) && (
            function_exists('mb_check_encoding')
                ? mb_check_encoding($query, 'UTF-8')
                : preg_match('//u', $query) === 1
        );
        if (
            !$validUtf8
            || mb_strlen((string) $query, 'UTF-8') > 120
            || preg_match('/[\x00-\x1F\x7F]/u', (string) $query) === 1
        ) {
            throw new NativeSearchValidationException(
                'native_search_text_invalid',
                'q'
            );
        }
        $scope = $post['scope'] ?? 'all';
        if (!is_string($scope) || !in_array($scope, ['all', 'mine', 'group'], true)) {
            throw new NativeSearchValidationException(
                'native_search_scope_unsupported',
                'scope'
            );
        }

        $advanced = $post['advanced'];
        $advanced['text'] = trim((string) $query);
        $advanced['scope'] = $scope;
        $advanced['status'] = $post['status'] ?? '';
        $advanced['group_id'] = $post['group_id'] ?? '0';
        $advanced['group_by'] = $post['group_by'] ?? 'none';
        return $advanced;
    }

    /**
     * Compile the simple controls into the same native AST as advanced rules.
     * Field identifiers come only from the current server-built GLPI catalog.
     *
     * @param array<string,mixed> $definition
     * @param array<string,mixed> $frequentFilters
     * @param array<string,mixed> $catalog
     * @return array<string,mixed>
     */
    private static function compileFrequentFilters(
        array $definition,
        array $frequentFilters,
        array $catalog
    ): array {
        if (
            array_keys($frequentFilters) !== ['status', 'group_id']
            || !is_string($frequentFilters['status'] ?? null)
            || !is_int($frequentFilters['group_id'] ?? null)
            || $frequentFilters['group_id'] < 0
        ) {
            throw new NativeSearchValidationException(
                'native_search_frequent_filters_invalid',
                'advanced.frequent_filters'
            );
        }
        if (!is_array($definition['criteria'] ?? null) || !array_is_list($definition['criteria'])) {
            throw new NativeSearchValidationException(
                'native_search_criteria_invalid',
                'definition.criteria'
            );
        }

        $criteria = $definition['criteria'];
        $requested = [];
        if ($frequentFilters['status'] !== '') {
            $requested[] = ['identifier' => 'status', 'value' => $frequentFilters['status']];
        }
        if ($frequentFilters['group_id'] > 0) {
            $requested[] = ['identifier' => 'group', 'value' => (string) $frequentFilters['group_id']];
        }
        foreach ($requested as $filter) {
            $criteria[] = [
                'link' => 'AND',
                'field' => self::frequentFilterField(
                    $catalog,
                    $filter['identifier']
                ),
                'searchtype' => 'equals',
                'value' => $filter['value'],
            ];
        }
        $definition['criteria'] = $criteria;
        return $definition;
    }

    /** @param array<string,mixed> $catalog */
    private static function frequentFilterField(array $catalog, string $identifier): int
    {
        $optionId = 0;
        foreach ((array) ($catalog['columns'] ?? []) as $column) {
            if (
                is_array($column)
                && !empty($column['available'])
                && (string) ($column['identifier'] ?? $column['key'] ?? '') === $identifier
            ) {
                $optionId = (int) ($column['option_id'] ?? 0);
                break;
            }
        }
        if ($optionId < 1) {
            throw new NativeSearchValidationException(
                'native_search_frequent_field_unavailable',
                'catalog.columns.' . $identifier
            );
        }

        foreach ((array) ($catalog['options'] ?? []) as $option) {
            if (!is_array($option) || (int) ($option['id'] ?? 0) !== $optionId) {
                continue;
            }
            $allowsEquals = false;
            foreach ((array) ($option['operators'] ?? []) as $operator) {
                if (is_array($operator) && (string) ($operator['value'] ?? '') === 'equals') {
                    $allowsEquals = true;
                    break;
                }
            }
            if (
                $allowsEquals
                && (
                    $identifier !== 'group'
                    || (string) (((array) ($option['value'] ?? []))['mode'] ?? '') === 'remote'
                )
            ) {
                return $optionId;
            }
            break;
        }

        throw new NativeSearchValidationException(
            'native_search_frequent_field_unavailable',
            'catalog.options.' . $identifier
        );
    }

    /**
     * Project only an unambiguous native status equality into the simplified
     * control. Complex semantics remain represented by the advanced builder.
     *
     * @param array<string,mixed> $definition
     * @param array<string,mixed> $catalog
     * @return array{mode:'none'|'simple'|'advanced',value:string,index:int}
     */
    private static function projectSavedStatusFilter(array $definition, array $catalog): array
    {
        try {
            $statusField = self::frequentFilterField($catalog, 'status');
        } catch (\Throwable) {
            return ['mode' => 'advanced', 'value' => '', 'index' => -1];
        }
        $criteria = is_array($definition['criteria'] ?? null)
            ? array_values($definition['criteria'])
            : [];
        $matches = [];
        $hasComplexConnector = false;
        $hasNestedStatus = false;
        foreach ($criteria as $index => $criterion) {
            if (!is_array($criterion)) {
                return ['mode' => 'advanced', 'value' => '', 'index' => -1];
            }
            $link = strtoupper(trim((string) ($criterion['link'] ?? 'AND')));
            if ($link !== 'AND') {
                $hasComplexConnector = true;
            }
            if (array_key_exists('criteria', $criterion)) {
                if (self::criterionTreeContainsField((array) $criterion['criteria'], $statusField)) {
                    $hasNestedStatus = true;
                }
                continue;
            }
            if ((int) ($criterion['field'] ?? 0) === $statusField) {
                $matches[] = ['index' => $index, 'criterion' => $criterion];
            }
        }

        if ($matches === [] && !$hasNestedStatus) {
            return ['mode' => 'none', 'value' => '', 'index' => -1];
        }
        if ($hasNestedStatus || $hasComplexConnector || count($matches) !== 1) {
            return ['mode' => 'advanced', 'value' => '', 'index' => -1];
        }

        $match = $matches[0];
        $criterion = $match['criterion'];
        $value = trim((string) ($criterion['value'] ?? ''));
        if (
            strtolower(trim((string) ($criterion['searchtype'] ?? ''))) !== 'equals'
            || preg_match('/\A[1-9]\d*\z/D', $value) !== 1
            || !array_key_exists(
                (int) $value,
                \GlpiPlugin\Glpiacessivel\Support\TicketStatusLabels::all()
            )
        ) {
            return ['mode' => 'advanced', 'value' => '', 'index' => -1];
        }

        return [
            'mode' => 'simple',
            'value' => $value,
            'index' => (int) $match['index'],
        ];
    }

    /** @param array<int,mixed> $criteria */
    private static function criterionTreeContainsField(array $criteria, int $field): bool
    {
        foreach ($criteria as $criterion) {
            if (!is_array($criterion)) {
                continue;
            }
            if (array_key_exists('criteria', $criterion)) {
                if (self::criterionTreeContainsField((array) $criterion['criteria'], $field)) {
                    return true;
                }
                continue;
            }
            if ((int) ($criterion['field'] ?? 0) === $field) {
                return true;
            }
        }

        return false;
    }

    /**
     * @param array<string,mixed> $definition
     * @param array{mode:string,value:string,index:int} $projection
     * @return array<string,mixed>
     */
    private static function definitionWithoutProjectedStatus(array $definition, array $projection): array
    {
        if (($projection['mode'] ?? '') !== 'simple') {
            return $definition;
        }
        $index = (int) ($projection['index'] ?? -1);
        $criteria = is_array($definition['criteria'] ?? null)
            ? array_values($definition['criteria'])
            : [];
        if (!array_key_exists($index, $criteria)) {
            throw new NativeSearchValidationException(
                'native_search_token_invalid',
                'definition.criteria'
            );
        }
        unset($criteria[$index]);
        $definition['criteria'] = array_values($criteria);
        return $definition;
    }

    /**
     * @param string[] $selected
     * @param array<string,mixed> $catalog
     * @return string[]
     */
    private static function validatedPresentationColumns(array $selected, array $catalog): array
    {
        $allowed = [];
        $required = [];
        foreach ((array) ($catalog['columns'] ?? []) as $column) {
            if (!is_array($column) || empty($column['available'])) {
                continue;
            }
            $identifier = trim((string) ($column['identifier'] ?? $column['key'] ?? ''));
            if ($identifier === '' || preg_match('/\A[a-z][a-z0-9_]{0,63}\z/D', $identifier) !== 1) {
                continue;
            }
            $allowed[$identifier] = true;
            if (!empty($column['required'])) {
                $required[$identifier] = true;
            }
        }

        $normalized = [];
        foreach ($selected as $column) {
            $identifier = is_scalar($column) ? trim((string) $column) : '';
            if ($identifier !== '' && isset($allowed[$identifier]) && !in_array($identifier, $normalized, true)) {
                $normalized[] = $identifier;
            }
        }
        foreach (array_keys($required) as $identifier) {
            if (!in_array($identifier, $normalized, true)) {
                array_unshift($normalized, $identifier);
            }
        }
        if ($normalized === []) {
            foreach (['id', 'name'] as $identifier) {
                if (isset($allowed[$identifier])) {
                    $normalized[] = $identifier;
                }
            }
        }
        return $normalized;
    }

    /** @param array<string,mixed> $catalog */
    private static function advancedCatalogRevision(array $catalog): string
    {
        $revision = $catalog['context_revision'] ?? null;
        if (
            !is_string($revision)
            || preg_match('/\A[a-f0-9]{64}\z/D', $revision) !== 1
        ) {
            throw new NativeSearchValidationException(
                'native_search_context_stale',
                'catalog.context_revision'
            );
        }
        return $revision;
    }

    /**
     * Never replace an expired or context-stale advanced search with the
     * broader default list. The repository already treats this internal flag
     * as an exact fail-closed empty result in both synchronous and async flows.
     *
     * @param array<string,mixed> $filters
     * @return array<string,mixed>
     */
    private static function failClosedAdvancedTokenFilters(
        array $filters,
        string $requestedToken,
        string $errorCode
    ): array {
        if ($requestedToken !== '' && $errorCode !== '') {
            $filters['saved_search_invalid'] = true;
        }

        return $filters;
    }

    /**
     * @param array<string,mixed> $state
     * @return array{
     *   definition:array<string,mixed>,
     *   page_size:int,
     *   presentation:array{group_by:string},
     *   frequent_filters:array{status:string,group_id:int}
     * }
     */
    private static function advancedStateWrapper(array $state): array
    {
        $keys = array_keys($state);
        $legacy = $keys === ['definition', 'page_size'];
        $previous = $keys === ['definition', 'page_size', 'presentation'];
        $current = $keys === [
            'definition',
            'page_size',
            'presentation',
            'frequent_filters',
        ];
        if (
            (!$legacy && !$previous && !$current)
            || !is_array($state['definition'] ?? null)
            || !is_int($state['page_size'] ?? null)
            || !in_array($state['page_size'], [10, 20, 50, 100], true)
        ) {
            throw new NativeSearchValidationException(
                'native_search_token_invalid',
                'advanced_search_token'
            );
        }
        return [
            'definition' => $state['definition'],
            'page_size' => $state['page_size'],
            'presentation' => self::advancedPresentationState(
                $legacy ? ['group_by' => 'none'] : (array) $state['presentation']
            ),
            'frequent_filters' => $current
                ? self::validatedFrequentFilters((array) $state['frequent_filters'])
                : ['status' => '', 'group_id' => 0],
        ];
    }

    /**
     * @param array<string,mixed> $frequentFilters
     * @return array{status:string,group_id:int}
     */
    private static function validatedFrequentFilters(array $frequentFilters): array
    {
        $status = $frequentFilters['status'] ?? null;
        $groupId = $frequentFilters['group_id'] ?? null;
        if (
            array_keys($frequentFilters) !== ['status', 'group_id']
            || !is_string($status)
            || (
                $status !== ''
                && (
                    preg_match('/\A[1-9]\d*\z/D', $status) !== 1
                    || !array_key_exists((int) $status, \GlpiPlugin\Glpiacessivel\Support\TicketStatusLabels::all())
                )
            )
            || !is_int($groupId)
            || $groupId < 0
        ) {
            throw new NativeSearchValidationException(
                'native_search_frequent_filters_invalid',
                'advanced.frequent_filters'
            );
        }

        return ['status' => $status, 'group_id' => $groupId];
    }

    /**
     * @param array<string,mixed> $presentation
     * @return array{group_by:string}
     */
    private static function advancedPresentationState(array $presentation): array
    {
        if (
            array_keys($presentation) !== ['group_by']
            || !is_string($presentation['group_by'] ?? null)
            || !in_array($presentation['group_by'], ['none', 'group'], true)
        ) {
            throw new NativeSearchValidationException(
                'native_search_presentation_invalid',
                'advanced.presentation'
            );
        }
        return ['group_by' => $presentation['group_by']];
    }

    /**
     * Remove from the editable builder only the exact suffix generated from
     * the frequent controls. The effective native definition remains intact.
     *
     * @param array<string,mixed> $definition
     * @param array{status:string,group_id:int} $frequentFilters
     * @param array<string,mixed> $catalog
     * @return array<string,mixed>
     */
    private static function editorDefinitionWithoutFrequentFilters(
        array $definition,
        array $frequentFilters,
        array $catalog
    ): array {
        $frequentFilters = self::validatedFrequentFilters($frequentFilters);
        $expectedSuffix = [];
        if ($frequentFilters['status'] !== '') {
            $expectedSuffix[] = [
                'link' => 'AND',
                'field' => self::frequentFilterField($catalog, 'status'),
                'searchtype' => 'equals',
                'value' => $frequentFilters['status'],
            ];
        }
        if ($frequentFilters['group_id'] > 0) {
            $expectedSuffix[] = [
                'link' => 'AND',
                'field' => self::frequentFilterField($catalog, 'group'),
                'searchtype' => 'equals',
                'value' => (string) $frequentFilters['group_id'],
            ];
        }
        if ($expectedSuffix === []) {
            return $definition;
        }

        $criteria = $definition['criteria'] ?? null;
        if (!is_array($criteria) || !array_is_list($criteria)) {
            throw new NativeSearchValidationException(
                'native_search_token_invalid',
                'advanced_search_token'
            );
        }
        $suffixOffset = count($criteria) - count($expectedSuffix);
        if ($suffixOffset < 0) {
            throw new NativeSearchValidationException(
                'native_search_token_invalid',
                'advanced_search_token'
            );
        }
        foreach ($expectedSuffix as $index => $expected) {
            if (($criteria[$suffixOffset + $index] ?? null) !== $expected) {
                throw new NativeSearchValidationException(
                    'native_search_token_invalid',
                    'advanced_search_token'
                );
            }
        }

        $definition['criteria'] = array_slice($criteria, 0, $suffixOffset);
        return $definition;
    }

    /**
     * @param array<string,mixed> $filters
     * @param array<string,mixed> $definition
     * @return array<string,mixed>
     */
    private static function applyAdvancedDefinitionToFilters(
        array $filters,
        array $definition,
        int $pageSize,
        array $presentation = ['group_by' => 'none']
    ): array {
        foreach (['criteria', 'metacriteria', 'sort', 'order', 'columns'] as $key) {
            if (!is_array($definition[$key] ?? null)) {
                throw new NativeSearchValidationException(
                    'native_search_definition_invalid',
                    'definition.' . $key
                );
            }
        }
        $text = $definition['text'] ?? null;
        $scope = $definition['scope'] ?? null;
        if (!is_string($text) || !is_string($scope) || !in_array($scope, ['all', 'mine', 'group'], true)) {
            throw new NativeSearchValidationException(
                'native_search_definition_invalid',
                'definition.scope'
            );
        }
        $isDeleted = $definition['is_deleted'] ?? null;
        if (!is_int($isDeleted) || !in_array($isDeleted, [0, 1], true)) {
            throw new NativeSearchValidationException(
                'native_search_definition_invalid',
                'definition.is_deleted'
            );
        }
        if (!in_array($pageSize, [10, 20, 50, 100], true)) {
            throw new NativeSearchValidationException(
                'native_search_page_size_unsupported',
                'page_size'
            );
        }
        $presentation = self::advancedPresentationState($presentation);

        unset(
            $filters['native_saved_search_id'],
            $filters['native_parameters'],
            $filters['saved_search_invalid']
        );
        $filters['scope'] = $scope;
        $filters['status'] = '';
        $filters['q'] = $text;
        $filters['group_id'] = 0;
        $filters['group_by'] = $presentation['group_by'];
        $filters['sort'] = 'date_mod';
        $filters['direction'] = 'DESC';
        $filters['native_criteria'] = $definition['criteria'];
        $filters['native_metacriteria'] = $definition['metacriteria'];
        $filters['native_sort'] = $definition['sort'];
        $filters['native_order'] = $definition['order'];
        $filters['native_is_deleted'] = $isDeleted;
        $filters['columns'] = $definition['columns'];
        $filters['page_size'] = $pageSize;

        return $filters;
    }

    /**
     * @param array<string,mixed> $definition
     * @return array<string,mixed>
     */
    private static function advancedBuilderState(
        array $definition,
        bool $editable,
        bool $focusResults
    ): array {
        return [
            'text' => (string) ($definition['text'] ?? ''),
            'scope' => (string) ($definition['scope'] ?? 'all'),
            'criteria' => (array) ($definition['criteria'] ?? []),
            'metacriteria' => (array) ($definition['metacriteria'] ?? []),
            'sort' => (array) ($definition['sort'] ?? []),
            'order' => (array) ($definition['order'] ?? []),
            'is_deleted' => (int) ($definition['is_deleted'] ?? 0),
            'columns' => (array) ($definition['columns'] ?? []),
            'editable' => $editable,
            'focus_results' => $focusResults,
        ];
    }

    private static function advancedFailureCode(\Throwable $exception, string $fallback): string
    {
        if ($exception instanceof NativeSearchValidationException) {
            $reason = $exception->reasonCode();
            if (preg_match('/\Anative_search_[a-z0-9_]{1,80}\z/D', $reason) === 1) {
                return $reason;
            }
        }
        return $fallback;
    }

    private static function advancedErrorMessage(string $code): string
    {
        $messages = [
            'native_search_csrf_failed' => __(
                'Sua sessão expirou. Recarregue a lista antes de aplicar a busca avançada.',
                'glpiacessivel'
            ),
            'native_search_request_incomplete' => __(
                'A busca avançada não foi recebida por completo. Revise os critérios e tente novamente.',
                'glpiacessivel'
            ),
            'native_search_context_stale' => __(
                'Os campos de pesquisa mudaram para o perfil ou entidade atual. Recarregue e revise a busca.',
                'glpiacessivel'
            ),
            'native_search_remote_value_not_authorized' => __(
                'Um valor selecionado não está disponível para o perfil ou entidade atual. Revise a busca.',
                'glpiacessivel'
            ),
            'native_search_remote_context_unavailable' => __(
                'Não foi possível confirmar os valores selecionados no contexto atual. Recarregue e tente novamente.',
                'glpiacessivel'
            ),
            'native_search_remote_rate_limited' => __(
                'Muitos valores foram confirmados em pouco tempo. Aguarde e tente aplicar a busca novamente.',
                'glpiacessivel'
            ),
            'native_search_remote_values_limit_exceeded' => __(
                'A busca possui valores selecionados demais para uma única aplicação. Reduza os critérios.',
                'glpiacessivel'
            ),
            'native_search_token_invalid' => __(
                'A busca avançada expirou ou pertence a outro contexto. Aplique os critérios novamente.',
                'glpiacessivel'
            ),
            'native_search_catalog_unavailable' => __(
                'A busca avançada está temporariamente indisponível neste contexto.',
                'glpiacessivel'
            ),
        ];
        return $messages[$code] ?? __(
            'Não foi possível aplicar a busca avançada. Revise os campos indicados e tente novamente.',
            'glpiacessivel'
        );
    }

    private static function storeAdvancedFailure(
        string $phase,
        string $code,
        \Throwable $exception
    ): void {
        $_SESSION[self::ADVANCED_SEARCH_ERROR_SESSION_KEY] = $code;
        self::auditAdvancedFailure($phase, $code, $exception);
    }

    private static function consumeAdvancedSearchError(): string
    {
        $code = $_SESSION[self::ADVANCED_SEARCH_ERROR_SESSION_KEY] ?? '';
        unset($_SESSION[self::ADVANCED_SEARCH_ERROR_SESSION_KEY]);
        return is_string($code)
            && preg_match('/\Anative_search_[a-z0-9_]{1,80}\z/D', $code) === 1
                ? $code
                : '';
    }

    private static function auditAdvancedFailure(
        string $phase,
        string $code,
        \Throwable $exception
    ): void {
        self::container()->auditLogger()->log('ticket.advanced_search.failed', [
            'phase' => $phase,
            'error_code' => $code,
            'exception' => get_class($exception),
        ]);
    }

    private static function storeCreate(): void
    {
        $sanitizer = new InputSanitizer();
        $actorValues = [];
        $actorErrors = [];
        foreach (
            [
            '_users_id_assign',
            '_users_id_observer',
            '_groups_id_assign',
            '_groups_id_observer',
            ] as $actorField
        ) {
            try {
                $actorValues[$actorField] = self::routingActorIdsFromPost($actorField) ?? [];
            } catch (FormValidationException $e) {
                $actorValues[$actorField] = [];
                $actorErrors = array_merge($actorErrors, $e->errors());
            }
        }
        $values = [
            'name' => $sanitizer->text($_POST['name'] ?? '', 255),
            'content' => $sanitizer->text($_POST['content'] ?? '', 16000),
            'type' => $sanitizer->int($_POST['type'] ?? self::incidentType(), self::incidentType()),
            'itilcategories_id' => max(0, $sanitizer->int($_POST['itilcategories_id'] ?? 0, 0)),
            'locations_id' => max(0, $sanitizer->int($_POST['locations_id'] ?? 0, 0)),
            'requesttypes_id' => max(0, $sanitizer->int($_POST['requesttypes_id'] ?? 1, 1)),
            'externalid' => $sanitizer->text($_POST['externalid'] ?? '', 255),
            'tickettemplates_id' => max(0, $sanitizer->int($_POST['tickettemplates_id'] ?? 0, 0)),
            'requester_user_id' => max(0, $sanitizer->int($_POST['requester_user_id'] ?? 0, 0)),
            'urgency' => $sanitizer->int($_POST['urgency'] ?? 3, 3),
            'impact' => $sanitizer->int($_POST['impact'] ?? 3, 3),
            '_users_id_assign' => $actorValues['_users_id_assign'],
            '_users_id_observer' => $actorValues['_users_id_observer'],
            '_groups_id_assign' => $actorValues['_groups_id_assign'],
            '_groups_id_observer' => $actorValues['_groups_id_observer'],
        ];

        $errors = $actorErrors;
        try {
            $values = UploadedFileMapper::mergeInto($values, UploadedFileMapper::map('filename'));
        } catch (\Throwable $e) {
            $errors[] = self::formError('filename', 'upload_error', $e->getMessage());
        }
        if ($values['name'] === '') {
            $errors[] = self::formError('name', 'required', 'Informe o título do chamado.');
        }
        if ($values['content'] === '') {
            $errors[] = self::formError('content', 'required', 'Informe a descrição do chamado.');
        }
        if (!in_array($values['type'], [self::incidentType(), self::demandType()], true)) {
            $errors[] = self::formError('type', 'invalid', 'Tipo de chamado inválido.');
        }
        if (!in_array($values['urgency'], [1, 2, 3, 4, 5], true)) {
            $errors[] = self::formError('urgency', 'invalid', 'Urgência inválida.');
        }
        if (!in_array($values['impact'], [1, 2, 3, 4, 5], true)) {
            $errors[] = self::formError('impact', 'invalid', 'Impacto inválido.');
        }

        if ($errors !== []) {
            self::renderCreateForm($values, $errors);
            return;
        }

        try {
            $ticketId = self::container()->ticketService()->create($values);
            self::setMessage('success', 'Chamado registrado com sucesso.');
        } catch (FormValidationException $e) {
            self::renderCreateForm($values, $e->errors(), $e->metadata());
            return;
        } catch (\Throwable $e) {
            self::renderCreateForm($values, [self::formError('', 'create_failed', 'Não foi possível registrar o chamado. Revise os dados e tente novamente.')]);
            return;
        }

        \Html::redirect(Url::plugin('front/tickets.php?id=' . $ticketId));
    }

    /**
     * @return array{field:string, code:string, message:string}
     */
    private static function formError(string $field, string $code, string $message): array
    {
        return [
            'field' => $field,
            'code' => $code,
            'message' => $message,
        ];
    }

    private static function renderCreateForm(array $values, array $errors, array $submissionMetadata = []): void
    {
        try {
            $context = self::container()->ticketService()->creationContext($values);
        } catch (\Throwable $e) {
            self::container()->auditLogger()->log('ticket.create.context_denied', [
                'exception_class' => get_class($e),
                'error_code' => self::safeErrorCode($e),
            ]);
            self::denyAccess(
                __('Criação de chamado indisponível para este perfil', 'glpiacessivel'),
                __('Não foi possível preparar a criação de chamado no perfil e na entidade atuais.', 'glpiacessivel'),
                'ticket.create.context_denied'
            );
            return;
        }

        View::render('tickets/create', [
            'title' => __('Novo chamado', 'glpiacessivel'),
            'csrf_token' => self::csrf()->token(true),
            'values' => $values,
            'errors' => $errors,
            'submission_metadata' => $submissionMetadata,
            'context' => $context,
            'native_create_ticket_url' => self::nativeCreateTicketUrl(),
        ]);
    }

    private static function defaultCreateValues(): array
    {
        return [
            'name' => '',
            'content' => '',
            'type' => self::incidentType(),
            'itilcategories_id' => 0,
            'locations_id' => 0,
            'requesttypes_id' => 1,
            'externalid' => '',
            'tickettemplates_id' => 0,
            'requester_user_id' => 0,
            'urgency' => 3,
            'impact' => 3,
            '_users_id_assign' => [],
            '_users_id_observer' => [],
            '_groups_id_assign' => [],
            '_groups_id_observer' => [],
        ];
    }

    private static function incidentType(): int
    {
        return defined(\Ticket::class . '::INCIDENT_TYPE') ? (int) \Ticket::INCIDENT_TYPE : 1;
    }

    private static function demandType(): int
    {
        return defined(\Ticket::class . '::DEMAND_TYPE') ? (int) \Ticket::DEMAND_TYPE : 2;
    }

    private static function nativeCreateTicketUrl(): string
    {
        if (class_exists('\Ticket') && method_exists('\Ticket', 'getFormURL')) {
            return (string) \Ticket::getFormURL(false);
        }

        return Url::core('front/ticket.form.php');
    }

    /**
     * @param array<int, array<string, mixed>> $items
     * @return array<int, array{id:int,label:string}>
     */
    private static function extractGroupOptions(array $items): array
    {
        $map = [];
        foreach ($items as $item) {
            foreach ((array) ($item['group_ids'] ?? []) as $index => $id) {
                $id = (int) $id;
                if ($id <= 0) {
                    continue;
                }
                $name = (string) (((array) ($item['group_names'] ?? []))[$index] ?? ('Grupo ' . $id));
                $map[$id] = $name;
            }
        }

        asort($map);
        $options = [];
        foreach ($map as $id => $label) {
            $options[] = ['id' => (int) $id, 'label' => (string) $label];
        }

        return $options;
    }

    /**
     * @param array<int, array<string, mixed>> $items
     * @return array<string, array<int, array<string, mixed>>>
     */
    private static function groupTicketsByGroup(array $items, string $scope, string $groupBy): array
    {
        if ($groupBy !== 'group') {
            return [];
        }

        $grouped = [];
        foreach ($items as $item) {
            $key = trim((string) ($item['primary_group_name'] ?? ''));
            if ($key === '') {
                $key = 'Sem grupo';
            }
            if (!isset($grouped[$key])) {
                $grouped[$key] = [];
            }
            $grouped[$key][] = $item;
        }

        ksort($grouped, SORT_NATURAL | SORT_FLAG_CASE);
        return $grouped;
    }
}
