<?php

declare(strict_types=1);

namespace GlpiPlugin\Glpiacessivel\UI\Controller;

use GlpiPlugin\Glpiacessivel\Application\ConfigService;
use GlpiPlugin\Glpiacessivel\Application\TicketListStateStore;
use GlpiPlugin\Glpiacessivel\Infrastructure\Search\TicketListCapacityGuard;
use GlpiPlugin\Glpiacessivel\Infrastructure\Search\TicketListRateLimiter;
use GlpiPlugin\Glpiacessivel\Infrastructure\Security\GlpiSessionContextSnapshot;
use GlpiPlugin\Glpiacessivel\Security\SessionContextGuard;
use GlpiPlugin\Glpiacessivel\Support\I18n;
use GlpiPlugin\Glpiacessivel\Support\TicketStatusLabels;
use GlpiPlugin\Glpiacessivel\Support\Url;

final class TicketResultController extends BaseController
{
    private static int $responseVersion = 2;

    public static function fetch(): void
    {
        self::$responseVersion = 2;
        $requestStartedAt = microtime(true);
        $memoryStartedBytes = memory_get_usage(true);
        $requestId = '';
        $capacityBackend = 'not_acquired';
        $capacityCircuitState = 'not_acquired';
        $capacityLeaseReleased = false;
        $capacityCircuitOutcomeRecorded = true;
        $admissionDurationMs = 0;
        $applicationDurationMs = 0;
        if (!self::isSameOrigin()) {
            self::respond(403, 'origin_not_allowed');
            return;
        }

        $session = (new SessionContextGuard())->ensureReady();
        if (empty($session['is_authenticated'])) {
            self::respond(401, 'session_expired');
            return;
        }
        if (empty($session['session_ready'])) {
            self::respond(409, 'context_stale');
            return;
        }
        if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST') {
            if (!headers_sent()) {
                header('Allow: POST');
            }
            self::respond(405, 'method_not_allowed');
            return;
        }
        $contentType = strtolower(trim((string) ($_SERVER['CONTENT_TYPE'] ?? '')));
        if (preg_match('/\Aapplication\/json(?:\s*;\s*charset=utf-8)?\z/D', $contentType) !== 1) {
            self::respond(415, 'unsupported_media_type');
            return;
        }

        $config = self::container()->configService();
        if (
            !$config->isTicketAsyncListEnabled()
            || !self::container()->portalModulePolicy()->isEnabled(ConfigService::MODULE_TICKETS)
            || !self::container()->authorization()->canViewTickets()
        ) {
            self::respond(403, 'forbidden');
            return;
        }

        try {
            self::csrf()->validateRequest(true);
        } catch (\Throwable $e) {
            self::respond(403, 'invalid_security_token');
            return;
        }

        try {
            try {
                $request = self::request();
            } catch (\InvalidArgumentException | \JsonException $e) {
                self::respond(422, 'invalid_request');
                return;
            }
            self::$responseVersion = $request['version'];
            $requestId = $request['request_id'];
            $snapshot = (new GlpiSessionContextSnapshot())->snapshot();
            if (!hash_equals($snapshot['revision'], $request['context_revision'])) {
                self::respond(409, 'context_stale', ['request_id' => $request['request_id']]);
                return;
            }
            $filters = (new TicketListStateStore())->resolve(
                $request['state_token'],
                $snapshot['revision']
            );
            if ($filters === null) {
                self::respond(422, 'state_expired', ['request_id' => $request['request_id']]);
                return;
            }

            $admissionStartedAt = microtime(true);
            $knownEmptyGroupScope = self::isKnownEmptyCurrentGroupScope($filters);
            $ratePolicy = self::safeRatePolicyMetrics($config);
            $rate = null;
            if (!$knownEmptyGroupScope) {
                $rate = (new TicketListRateLimiter(
                    $ratePolicy['rate_limit'],
                    $ratePolicy['rate_window_seconds'],
                    $ratePolicy['rate_burst']
                ))->consume();
                if (!$rate['allowed']) {
                    if (!headers_sent()) {
                        header('Retry-After: ' . (string) $rate['retry_after']);
                    }
                }
            }

            // The token bucket is the final mutation of the PHP session. Free
            // its lock before auditing or checking global capacity so fast
            // rejections cannot serialize requests from the same browser.
            if (session_status() === PHP_SESSION_ACTIVE && !session_write_close()) {
                throw new \RuntimeException('ticket_results_session_release_failed');
            }
            if (is_array($rate) && empty($rate['allowed'])) {
                self::auditOperationalOutcome(
                    'ticket.results.async_rejected',
                    [
                        'request_id' => $requestId,
                        'http_status' => 429,
                        'outcome_code' => 'rate_limited',
                        'retry_after' => max(1, (int) ($rate['retry_after'] ?? 1)),
                        'admission_duration_ms' => self::elapsedMilliseconds($admissionStartedAt),
                    ] + self::safeFilterMetrics($filters) + $ratePolicy,
                    $requestStartedAt,
                    $memoryStartedBytes
                );
                self::respond(429, 'rate_limited', ['request_id' => $request['request_id']]);
                return;
            }

            $startedAt = microtime(true);
            $capacityBackend = 'disabled';
            $capacityCircuitState = 'disabled';
            $capacityGuard = null;
            $capacityLeaseId = '';
            if (!$knownEmptyGroupScope && $config->isTicketListCapacityGuardEnabled()) {
                $capacityGuard = new TicketListCapacityGuard(
                    $config->getTicketListCapacityMaxConcurrent(),
                    $config->getTicketListCapacityLeaseSeconds(),
                    $config->getTicketListCapacityRetryAfterSeconds(),
                    $config->getTicketListCapacityBackend()
                );
                $capacity = $capacityGuard->acquire($snapshot['revision']);
                $capacityBackend = (string) ($capacity['backend'] ?? 'unknown');
                $capacityCircuitState = (string) ($capacity['circuit_state'] ?? 'unknown');
                if (empty($capacity['allowed'])) {
                    $retryAfter = max(1, (int) ($capacity['retry_after'] ?? 1));
                    if (!headers_sent()) {
                        header('Retry-After: ' . (string) $retryAfter);
                    }
                    $reason = (string) ($capacity['reason'] ?? 'capacity_backend_error');
                    $isCapacityContention = in_array($reason, [
                        'capacity_limit_reached',
                        'user_context_in_flight',
                    ], true);
                    $status = $isCapacityContention ? 429 : 503;
                    $outcomeCode = $isCapacityContention ? 'capacity_limited' : 'capacity_unavailable';
                    self::auditOperationalOutcome('ticket.results.async_rejected', [
                        'request_id' => $requestId,
                        'http_status' => $status,
                        'outcome_code' => $outcomeCode,
                        'capacity_backend' => $capacityBackend,
                        'capacity_circuit_state' => $capacityCircuitState,
                        'capacity_reason' => $reason,
                        'retry_after' => $retryAfter,
                        'admission_duration_ms' => self::elapsedMilliseconds($admissionStartedAt),
                    ], $requestStartedAt, $memoryStartedBytes);
                    self::respond(
                        $status,
                        $outcomeCode,
                        ['request_id' => $request['request_id']]
                    );
                    return;
                }
                $capacityLeaseId = (string) ($capacity['lease_id'] ?? '');
            }
            $admissionDurationMs = self::elapsedMilliseconds($admissionStartedAt);

            $capacityOutcome = null;
            $applicationStartedAt = microtime(true);
            try {
                try {
                    $result = self::container()->ticketService()->list($filters);
                    $capacityOutcome = self::capacityOutcome($result);
                } catch (\Throwable $e) {
                    $capacityOutcome = false;
                    throw $e;
                }
            } finally {
                $applicationDurationMs = self::elapsedMilliseconds($applicationStartedAt);
                if ($capacityGuard instanceof TicketListCapacityGuard && $capacityLeaseId !== '') {
                    $capacityLeaseReleased = $capacityGuard->release(
                        $capacityLeaseId,
                        $capacityOutcome
                    );
                    $capacityCircuitOutcomeRecorded = $capacityGuard->lastCircuitOutcomeRecorded();
                }
            }
            $items = [];
            foreach ((array) ($result['items'] ?? []) as $item) {
                if (!is_array($item)) {
                    continue;
                }
                $ticketId = (int) ($item['id'] ?? 0);
                $priority = (int) ($item['priority'] ?? 0);
                $status = (int) ($item['status'] ?? 0);
                $item['detail_url'] = Url::plugin('front/tickets.php?id=' . $ticketId);
                $item['status_label'] = TicketStatusLabels::label($status);
                $item['status_class'] = self::statusClass($status);
                $item['priority_label'] = self::priorityLabel($priority);
                $item['priority_class'] = self::priorityClass($priority);
                $items[] = self::projectResultItem($item, $filters);
            }
            $result['items'] = $items;
            try {
                $result = self::normalizeResult($result, $request['version']);
            } catch (\UnexpectedValueException $e) {
                self::respond(409, 'contract_upgrade_required', [
                    'request_id' => $request['request_id'],
                ]);
                return;
            }

            $outcomeCode = self::operationalOutcomeCode($result);
            self::container()->auditLogger()->log('ticket.results.async', [
                'request_id' => $request['request_id'],
                'count' => count($items),
                'duration_ms' => (int) round((microtime(true) - $startedAt) * 1000),
                'backend' => (string) ($result['backend'] ?? 'unknown'),
                'capacity_backend' => $capacityBackend,
                'capacity_circuit_state' => $capacityCircuitState,
                'capacity_lease_released' => $capacityLeaseReleased,
                'capacity_circuit_outcome_recorded' => $capacityCircuitOutcomeRecorded,
                'admission_duration_ms' => $admissionDurationMs,
                'application_duration_ms' => $applicationDurationMs,
                'http_status' => 200,
                'outcome_code' => $outcomeCode,
            ] + self::safeFilterMetrics($filters)
                + self::safeBackendMetrics($result)
                + self::runtimeMetrics($requestStartedAt, $memoryStartedBytes));
            self::respond(200, '', [
                'request_id' => $request['request_id'],
                'context_revision' => $snapshot['revision'],
                'result' => $result,
            ]);
        } catch (\Throwable $e) {
            self::container()->auditLogger()->log('ticket.results.async_failed', [
                'exception' => get_class($e),
                'request_id' => $requestId,
                'http_status' => 503,
                'outcome_code' => 'temporarily_unavailable',
                'capacity_backend' => $capacityBackend,
                'capacity_circuit_state' => $capacityCircuitState,
                'capacity_lease_released' => $capacityLeaseReleased,
                'capacity_circuit_outcome_recorded' => $capacityCircuitOutcomeRecorded,
                'admission_duration_ms' => $admissionDurationMs,
                'application_duration_ms' => $applicationDurationMs,
            ] + self::runtimeMetrics($requestStartedAt, $memoryStartedBytes));
            if (!headers_sent()) {
                header('Retry-After: 5');
            }
            self::respond(503, 'temporarily_unavailable');
        }
    }

    /** @param array<string,mixed> $context */
    private static function auditOperationalOutcome(
        string $event,
        array $context,
        float $startedAt,
        int $memoryStartedBytes
    ): void {
        self::container()->auditLogger()->log(
            $event,
            $context + self::runtimeMetrics($startedAt, $memoryStartedBytes)
        );
    }

    /** @return array<string,int|string> */
    private static function runtimeMetrics(float $startedAt, int $memoryStartedBytes): array
    {
        $memoryCurrentBytes = max(0, memory_get_usage(true));
        $memoryPeakBytes = max(0, memory_get_peak_usage(true));

        return [
            'duration_ms' => self::elapsedMilliseconds($startedAt),
            'memory_started_bytes' => max(0, $memoryStartedBytes),
            'memory_current_bytes' => $memoryCurrentBytes,
            'memory_peak_bytes' => $memoryPeakBytes,
            'memory_delta_bytes' => max(0, $memoryCurrentBytes - $memoryStartedBytes),
            'memory_peak_delta_bytes' => max(0, $memoryPeakBytes - $memoryStartedBytes),
            'plugin_version' => defined('PLUGIN_GLPIACESSIVEL_VERSION')
                ? (string) constant('PLUGIN_GLPIACESSIVEL_VERSION')
                : 'unknown',
            'glpi_version' => defined('GLPI_VERSION') ? (string) constant('GLPI_VERSION') : 'unknown',
            'php_version' => PHP_VERSION,
        ];
    }

    private static function elapsedMilliseconds(float $startedAt): int
    {
        return max(0, (int) round((microtime(true) - $startedAt) * 1000));
    }

    /** @param array<string,mixed> $filters @return array<string,int> */
    private static function safeFilterMetrics(array $filters): array
    {
        return [
            'page' => max(1, (int) ($filters['page'] ?? 1)),
            'page_size' => max(1, min(50, (int) ($filters['page_size'] ?? 20))),
            'criteria_count' => count((array) ($filters['native_criteria'] ?? [])),
            'metacriteria_count' => count((array) ($filters['native_metacriteria'] ?? [])),
            'sort_count' => count((array) ($filters['native_sort'] ?? [])),
        ];
    }

    /** @return array<string,int> */
    private static function safeRatePolicyMetrics(ConfigService $config): array
    {
        return [
            'rate_limit' => $config->getTicketListRateLimit(),
            'rate_window_seconds' => $config->getTicketListRateWindowSeconds(),
            'rate_burst' => $config->getTicketListRateBurst(),
        ];
    }

    /** @param array<string,mixed> $result @return array<string,int|string> */
    private static function safeBackendMetrics(array $result): array
    {
        $diagnostics = is_array($result['backend_diagnostics'] ?? null)
            ? $result['backend_diagnostics']
            : [];
        $stages = is_array($diagnostics['stage_durations_ms'] ?? null)
            ? $diagnostics['stage_durations_ms']
            : [];

        $adapter = is_string($diagnostics['search_adapter'] ?? null)
            ? $diagnostics['search_adapter']
            : '';
        if (!in_array($adapter, ['glpi10_search_sql', 'glpi11_search_sql'], true)) {
            $adapter = 'unknown';
        }
        $totalState = is_string($result['total_state'] ?? null)
            ? $result['total_state']
            : '';
        if (!in_array($totalState, ['deferred', 'pending', 'exact', 'unavailable', 'lower_bound'], true)) {
            $totalState = 'unknown';
        }

        return [
            'native_search_duration_ms' => max(0, (int) ($stages['native_search'] ?? 0)),
            'batch_hydration_duration_ms' => max(0, (int) ($stages['batch_hydration'] ?? 0)),
            'search_adapter' => $adapter,
            'total_state' => $totalState,
        ];
    }

    /** @return array{version:int,state_token:string,context_revision:string,request_id:string} */
    private static function request(): array
    {
        $raw = file_get_contents('php://input');
        if (!is_string($raw) || strlen($raw) > 4096) {
            throw new \InvalidArgumentException('invalid_request');
        }
        $input = json_decode($raw, true, 16, JSON_THROW_ON_ERROR);
        if (!is_array($input)) {
            throw new \InvalidArgumentException('invalid_request');
        }
        $allowed = ['contract', 'version', 'state_token', 'context_revision', 'request_id'];
        foreach (array_keys($input) as $key) {
            if (!is_string($key) || !in_array($key, $allowed, true)) {
                throw new \InvalidArgumentException('invalid_request');
            }
        }
        $version = $input['version'] ?? null;
        if (($input['contract'] ?? null) !== 'ticket_results' || !in_array($version, [1, 2], true)) {
            throw new \InvalidArgumentException('invalid_contract');
        }
        $stateToken = is_string($input['state_token'] ?? null) ? $input['state_token'] : '';
        $contextRevision = is_string($input['context_revision'] ?? null) ? $input['context_revision'] : '';
        $requestId = is_string($input['request_id'] ?? null) ? $input['request_id'] : '';
        if (
            preg_match('/\A[a-f0-9]{48}\z/D', $stateToken) !== 1
            || preg_match('/\A[a-f0-9]{64}\z/D', $contextRevision) !== 1
            || preg_match('/\A[a-zA-Z0-9_-]{8,80}\z/D', $requestId) !== 1
        ) {
            throw new \InvalidArgumentException('invalid_request');
        }

        return [
            'version' => $version,
            'state_token' => $stateToken,
            'context_revision' => $contextRevision,
            'request_id' => $requestId,
        ];
    }

    private static function isSameOrigin(): bool
    {
        $fetchSite = strtolower(trim((string) ($_SERVER['HTTP_SEC_FETCH_SITE'] ?? '')));
        if ($fetchSite !== '' && !in_array($fetchSite, ['same-origin', 'none'], true)) {
            return false;
        }
        $origin = trim((string) ($_SERVER['HTTP_ORIGIN'] ?? ''));
        if ($origin === '') {
            return true;
        }
        $originParts = parse_url($origin);
        if (!is_array($originParts) || !is_string($originParts['host'] ?? null)) {
            return false;
        }
        $originHost = strtolower((string) $originParts['host']);
        if (isset($originParts['port'])) {
            $originHost .= ':' . (int) $originParts['port'];
        }
        $requestHost = strtolower(trim((string) ($_SERVER['HTTP_HOST'] ?? '')));
        if ($requestHost === '' || !hash_equals($requestHost, $originHost)) {
            return false;
        }
        $requestIsHttps = !empty($_SERVER['HTTPS']) && strtolower((string) $_SERVER['HTTPS']) !== 'off';
        return strtolower((string) ($originParts['scheme'] ?? '')) === ($requestIsHttps ? 'https' : 'http');
    }

    /** @param array<string,mixed> $filters */
    private static function isKnownEmptyCurrentGroupScope(array $filters): bool
    {
        return (string) ($filters['scope'] ?? '') === 'group'
            && (int) ($filters['group_id'] ?? 0) <= 0
            && ($_SESSION[SessionContextGuard::GROUP_CONTEXT_LOAD_CONFIRMED_SESSION_KEY] ?? null) !== false
            && array_key_exists('glpigroups', $_SESSION)
            && is_array($_SESSION['glpigroups'])
            && $_SESSION['glpigroups'] === [];
    }

    /** @param array<string,mixed> $result */
    private static function capacityOutcome(array $result): ?bool
    {
        if ((string) ($result['backend'] ?? '') === 'search_api') {
            return true;
        }
        return in_array((string) ($result['backend_reason'] ?? ''), [
            'bounded_search_execution_unavailable',
            'bounded_search_execution_failed',
            'bounded_search_plan_failed',
        ], true) ? false : null;
    }

    /** @param array<string,mixed> $result */
    private static function operationalOutcomeCode(array $result): string
    {
        $backendReason = (string) ($result['backend_reason'] ?? '');
        if ($backendReason === 'bounded_search_hydration_relation_limit_exceeded') {
            return $backendReason;
        }
        if ((string) ($result['total_state'] ?? '') === 'unavailable') {
            return 'results_unavailable';
        }

        return 'ok';
    }

    /** @param array<string, mixed> $data */
    private static function respond(int $status, string $error = '', array $data = []): void
    {
        if (!headers_sent()) {
            http_response_code($status);
            header('Content-Type: application/json; charset=UTF-8');
            header('Cache-Control: private, no-store');
            header('Pragma: no-cache');
            header('X-Content-Type-Options: nosniff');
        }
        $payload = [
            'contract' => 'ticket_results',
            'version' => self::$responseVersion,
            'success' => $status >= 200 && $status < 300,
        ] + $data;
        if ($error !== '') {
            $payload['error'] = $error;
        }
        $json = json_encode($payload, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
        echo is_string($json)
            ? $json
            : sprintf(
                '{"contract":"ticket_results","version":%d,"success":false,"error":"encoding_failed"}',
                self::$responseVersion
            );
    }

    /**
     * V2 never derives an unknown total or navigation state from legacy fields.
     * V1 remains available only for an explicitly legacy result with an exact
     * total and page count.
     *
     * @param array<string,mixed> $result
     * @return array<string,mixed>
     */
    private static function normalizeResult(array $result, int $version): array
    {
        $items = $result['items'] ?? null;
        $page = $result['page'] ?? null;
        $pageSize = $result['page_size'] ?? null;
        if (
            !is_array($items)
            || !is_int($page)
            || $page < 1
            || !is_int($pageSize)
            || $pageSize < 1
            || count($items) > $pageSize
        ) {
            throw new \UnexpectedValueException('invalid_result_contract');
        }

        if ($version === 1) {
            if (
                array_key_exists('total_state', $result)
                || !is_int($result['total'] ?? null)
                || (int) $result['total'] < 0
                || !is_int($result['pages'] ?? null)
                || (int) $result['pages'] < 1
            ) {
                throw new \UnexpectedValueException('legacy_contract_unavailable');
            }
            return $result;
        }

        $totalState = $result['total_state'] ?? null;
        $allowedTotalStates = ['deferred', 'pending', 'exact', 'unavailable', 'lower_bound'];
        if (
            $pageSize > 50
            || array_filter($items, static fn($item): bool => !is_array($item)) !== []
            ||
            !is_string($totalState)
            || !in_array($totalState, $allowedTotalStates, true)
            || !is_bool($result['has_previous'] ?? null)
            || !is_bool($result['has_more'] ?? null)
            || (bool) $result['has_previous'] !== ($page > 1)
            || ($items === [] && !empty($result['has_more']))
        ) {
            throw new \UnexpectedValueException('invalid_result_contract');
        }

        if (in_array($totalState, ['exact', 'lower_bound'], true)) {
            $total = $result['total'] ?? null;
            $lastItem = $items === [] ? 0 : (($page - 1) * $pageSize) + count($items);
            if (!is_int($total) || $total < $lastItem) {
                throw new \UnexpectedValueException('invalid_result_contract');
            }
        } elseif (!array_key_exists('total', $result) || $result['total'] !== null) {
            throw new \UnexpectedValueException('invalid_result_contract');
        }

        return $result;
    }

    private static function statusClass(int $status): string
    {
        return [1 => 'new', 2 => 'assigned', 3 => 'planned', 4 => 'pending', 5 => 'solved', 6 => 'closed'][$status]
            ?? 'neutral';
    }

    private static function priorityLabel(int $priority): string
    {
        $labels = [
            1 => I18n::translate('Muito baixa'),
            2 => I18n::translate('Baixa'),
            3 => I18n::translate('Média'),
            4 => I18n::translate('Alta'),
            5 => I18n::translate('Muito alta'),
            6 => I18n::translate('Crítica'),
        ];
        return $labels[$priority]
            ?? sprintf(I18n::translate('Prioridade %d'), $priority);
    }

    private static function priorityClass(int $priority): string
    {
        if ($priority >= 5) {
            return 'critical';
        }
        if ($priority === 4) {
            return 'high';
        }
        return $priority === 3 ? 'medium' : 'low';
    }

    /**
     * Keep the HTTP response aligned with the columns the user is authorised
     * to display. Batch hydration may use additional relations internally, but
     * unrequested actors, labels, relational IDs and ticket content must not
     * cross the JSON boundary.
     *
     * @param array<string,mixed> $item
     * @param array<string,mixed> $filters
     * @return array<string,mixed>
     */
    private static function projectResultItem(array $item, array $filters): array
    {
        $columns = array_values(array_filter(
            array_map(
                static fn($column): string => is_scalar($column) ? trim((string) $column) : '',
                (array) ($filters['columns'] ?? [])
            ),
            static fn(string $column): bool => $column !== ''
        ));
        if ($columns === []) {
            $columns = ['id', 'name', 'status', 'priority', 'group', 'date_mod'];
        }
        $selected = array_fill_keys($columns, true);
        $projected = [
            'id' => (int) ($item['id'] ?? 0),
            'name' => (string) ($item['name'] ?? ''),
            'detail_url' => (string) ($item['detail_url'] ?? ''),
        ];

        $mappings = [
            'date' => ['date'],
            'date_mod' => ['date_mod'],
            'time_to_resolve' => ['time_to_resolve'],
            'requester' => ['requester_name'],
            'assignee' => ['assignee_name'],
            'category' => ['category_name'],
            'entity' => ['entity_name'],
            'location' => ['location_name'],
            'status' => ['status', 'status_label', 'status_class'],
            'priority' => ['priority', 'priority_label', 'priority_class'],
        ];
        foreach ($mappings as $column => $fields) {
            if (!isset($selected[$column])) {
                continue;
            }
            foreach ($fields as $field) {
                $projected[$field] = $item[$field] ?? '';
            }
        }

        $needsGroup = isset($selected['group'])
            || (
                ($filters['group_by'] ?? '') === 'group'
                && in_array((string) ($filters['scope'] ?? ''), ['mine', 'group'], true)
            );
        if ($needsGroup) {
            $projected['primary_group_name'] = (string) ($item['primary_group_name'] ?? 'Sem grupo');
        }

        return $projected;
    }
}
