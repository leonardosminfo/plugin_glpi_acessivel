<?php

declare(strict_types=1);

namespace GlpiPlugin\Glpiacessivel\UI\Controller;

use GlpiPlugin\Glpiacessivel\Infrastructure\Audit\AuditRights;
use GlpiPlugin\Glpiacessivel\Support\Url;

final class AuditProfileController extends BaseController
{
    public static function save(): void
    {
        self::requireLogin();
        $update = defined('UPDATE') ? (int) constant('UPDATE') : 4;
        if (!method_exists('\Session', 'haveRight') || !\Session::haveRight('profile', $update)) {
            self::denyAccess(
                __('Sem permissão', 'glpiacessivel'),
                __('Seu perfil não pode alterar direitos de outros perfis.', 'glpiacessivel'),
                'audit.rights.denied'
            );
            return;
        }
        if (!self::validateCsrfOrRedirect(Url::core('front/profile.php'), 'audit.rights.csrf_rejected')) {
            return;
        }

        $profileId = max(0, (int) ($_POST['profiles_id'] ?? 0));
        if (
            $profileId <= 0
            || !class_exists('\ProfileRight')
            || !method_exists('\ProfileRight', 'updateProfileRights')
        ) {
            self::setMessage('error', __('Perfil inválido.', 'glpiacessivel'));
            \Html::redirect(Url::core('front/profile.php'));
            return;
        }

        $posted = is_array($_POST['rights'] ?? null) ? $_POST['rights'] : [];
        $read = defined('READ') ? (int) constant('READ') : 1;
        $rights = [];
        foreach (AuditRights::all() as $right) {
            $rights[$right] = ((string) ($posted[$right] ?? '0')) === '1' ? $read : 0;
        }
        if (\ProfileRight::updateProfileRights($profileId, $rights) === false) {
            self::setMessage('error', __('Não foi possível atualizar os direitos de auditoria.', 'glpiacessivel'));
            \Html::redirect(Url::core('front/profile.form.php?id=' . $profileId));
            return;
        }
        self::container()->auditLogger()->log('audit.rights.updated', [
            'target_profile_id' => $profileId,
            'enabled_count' => count(array_filter($rights)),
        ]);
        self::setMessage('success', __('Direitos de auditoria atualizados.', 'glpiacessivel'));
        \Html::redirect(Url::core('front/profile.form.php?id=' . $profileId));
    }
}
