<?php

declare(strict_types=1);

namespace GlpiPlugin\Glpiacessivel\UI\Controller;

use GlpiPlugin\Glpiacessivel\Application\ConfigService;
use GlpiPlugin\Glpiacessivel\Security\SessionContextGuard;
use GlpiPlugin\Glpiacessivel\Support\ItilTemplateResolutionException;

final class TicketTemplateController extends BaseController
{
    private const CONTRACT = 'itil_template';
    private const VERSION = 1;
    private const MAX_BODY_BYTES = 2048;

    public static function preview(): void
    {
        $requestId = self::requestId();
        if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST') {
            if (!headers_sent()) {
                header('Allow: POST');
            }
            self::respond(405, 'method_not_allowed', null, $requestId);
            return;
        }
        if (!self::isJsonContentType()) {
            self::respond(415, 'unsupported_media_type', null, $requestId);
            return;
        }
        if (!self::isSameOrigin()) {
            self::respond(403, 'origin_not_allowed', null, $requestId);
            return;
        }

        $session = (new SessionContextGuard())->ensureReady();
        if (empty($session['is_authenticated'])) {
            self::respond(401, 'session_expired', null, $requestId);
            return;
        }
        if (empty($session['session_ready'])) {
            self::respond(409, 'context_stale', null, $requestId);
            return;
        }
        if (
            !self::container()->portalModulePolicy()->isEnabled(ConfigService::MODULE_TICKETS)
            || !self::container()->authorization()->canViewTickets()
        ) {
            self::respond(403, 'forbidden', null, $requestId);
            return;
        }

        try {
            self::csrf()->validateRequest(true);
        } catch (\Throwable $e) {
            self::container()->auditLogger()->log('csrf.failed', [
                'endpoint' => 'ticket.template',
                'exception' => get_class($e),
                'request_id' => $requestId,
            ]);
            self::respond(403, 'invalid_security_token', null, $requestId);
            return;
        }

        try {
            $request = self::request();
        } catch (\Throwable) {
            self::respond(422, 'invalid_request', null, $requestId);
            return;
        }

        try {
            $result = self::container()->ticketService()->previewItilTemplate(
                $request['ticket_id'],
                $request['kind'],
                $request['template_id']
            );
            self::respond(200, '', $result, $requestId);
        } catch (\InvalidArgumentException) {
            self::respond(422, 'invalid_request', null, $requestId);
        } catch (ItilTemplateResolutionException $e) {
            self::container()->auditLogger()->log('ticket.itil_template.preview_rejected', [
                'kind' => $request['kind'],
                'template_id' => $request['template_id'],
                'stage' => $e->reasonCode(),
                'request_id' => $requestId,
            ], $request['ticket_id']);
            self::respond(404, 'template_not_available', null, $requestId);
        } catch (\RuntimeException) {
            self::respond(404, 'template_not_available', null, $requestId);
        } catch (\Throwable $e) {
            self::container()->auditLogger()->log('ticket.itil_template.preview_failed', [
                'kind' => $request['kind'],
                'template_id' => $request['template_id'],
                'exception' => get_class($e),
                'request_id' => $requestId,
            ], $request['ticket_id']);
            self::respond(503, 'temporarily_unavailable', null, $requestId);
        }
    }

    /** @return array{ticket_id:int,kind:string,template_id:int} */
    private static function request(): array
    {
        $contentLength = (int) ($_SERVER['CONTENT_LENGTH'] ?? 0);
        if ($contentLength < 0 || $contentLength > self::MAX_BODY_BYTES) {
            throw new \InvalidArgumentException('invalid_request');
        }
        $raw = file_get_contents('php://input', false, null, 0, self::MAX_BODY_BYTES + 1);
        if (!is_string($raw) || $raw === '' || strlen($raw) > self::MAX_BODY_BYTES) {
            throw new \InvalidArgumentException('invalid_request');
        }
        $input = json_decode($raw, true, 8, JSON_THROW_ON_ERROR);
        if (!is_array($input) || array_is_list($input)) {
            throw new \InvalidArgumentException('invalid_request');
        }
        $allowed = ['contract', 'version', 'ticket_id', 'kind', 'template_id'];
        foreach (array_keys($input) as $key) {
            if (!is_string($key) || !in_array($key, $allowed, true)) {
                throw new \InvalidArgumentException('invalid_request');
            }
        }
        if (
            ($input['contract'] ?? null) !== self::CONTRACT
            || ($input['version'] ?? null) !== self::VERSION
            || !is_int($input['ticket_id'] ?? null)
            || !is_int($input['template_id'] ?? null)
            || !is_string($input['kind'] ?? null)
            || !in_array($input['kind'], ['followup', 'task', 'solution'], true)
            || $input['ticket_id'] <= 0
            || $input['template_id'] <= 0
        ) {
            throw new \InvalidArgumentException('invalid_request');
        }

        return [
            'ticket_id' => $input['ticket_id'],
            'kind' => $input['kind'],
            'template_id' => $input['template_id'],
        ];
    }

    private static function isJsonContentType(): bool
    {
        return preg_match(
            '/\Aapplication\/json(?:\s*;\s*charset=utf-8)?\z/D',
            strtolower(trim((string) ($_SERVER['CONTENT_TYPE'] ?? '')))
        ) === 1;
    }

    private static function isSameOrigin(): bool
    {
        $fetchSite = strtolower(trim((string) ($_SERVER['HTTP_SEC_FETCH_SITE'] ?? '')));
        if ($fetchSite !== '' && !in_array($fetchSite, ['same-origin', 'none'], true)) {
            return false;
        }
        $origin = trim((string) ($_SERVER['HTTP_ORIGIN'] ?? ''));
        if ($origin === '') {
            return true;
        }
        $parts = parse_url($origin);
        if (!is_array($parts) || !is_string($parts['host'] ?? null)) {
            return false;
        }
        $originHost = strtolower($parts['host']);
        if (isset($parts['port'])) {
            $originHost .= ':' . (int) $parts['port'];
        }
        $requestHost = strtolower(trim((string) ($_SERVER['HTTP_HOST'] ?? '')));
        if ($requestHost === '' || !hash_equals($requestHost, $originHost)) {
            return false;
        }
        $scheme = strtolower((string) ($parts['scheme'] ?? ''));
        $https = !empty($_SERVER['HTTPS']) && strtolower((string) $_SERVER['HTTPS']) !== 'off';
        return $scheme === ($https ? 'https' : 'http');
    }

    /** @param array<string,mixed>|null $result */
    private static function respond(
        int $status,
        string $errorCode = '',
        ?array $result = null,
        string $requestId = ''
    ): void {
        if (!headers_sent()) {
            http_response_code($status);
            header('Content-Type: application/json; charset=UTF-8');
            header('Cache-Control: private, no-store');
            header('Pragma: no-cache');
            header('X-Content-Type-Options: nosniff');
        }
        $payload = [
            'contract' => self::CONTRACT,
            'version' => self::VERSION,
            'success' => $status >= 200 && $status < 300,
            'result' => $result,
            'request_id' => $requestId,
            'error' => $errorCode === '' ? null : [
                'code' => $errorCode,
                'request_id' => $requestId,
            ],
        ];
        $json = json_encode($payload, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
        echo is_string($json) ? $json : '{"contract":"itil_template","version":1,"success":false,"result":null,"error":{"code":"encoding_failed"}}';
    }

    private static function requestId(): string
    {
        try {
            return bin2hex(random_bytes(8));
        } catch (\Throwable) {
            return substr(hash('sha256', microtime(true) . ':' . getmypid()), 0, 16);
        }
    }
}
