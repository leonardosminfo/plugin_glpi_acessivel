<?php

declare(strict_types=1);

namespace GlpiPlugin\Glpiacessivel\UI\Controller;

use GlpiPlugin\Glpiacessivel\Application\ConfigService;
use GlpiPlugin\Glpiacessivel\Security\InputSanitizer;
use GlpiPlugin\Glpiacessivel\UI\View\View;

final class KnowledgeController extends BaseController
{
    public static function index(): void
    {
        self::requireLogin();
        if (!self::requireModuleEnabled(ConfigService::MODULE_KNOWLEDGE)) {
            return;
        }

        $sanitizer = new InputSanitizer();
        $requestedPublic = $sanitizer->text($_GET['public'] ?? '', 8);
        $canViewFullKb = self::container()->authorization()->canViewKnowledgeBaseFull();
        $filters = [
            'query' => $sanitizer->text($_GET['q'] ?? '', 120),
            'category_id' => max(0, $sanitizer->int($_GET['category'] ?? 0, 0)),
            'public_only' => $requestedPublic === '1' || !$canViewFullKb,
            'page' => max(1, $sanitizer->int($_GET['page'] ?? 1, 1)),
            'page_size' => 10,
            'article_id' => max(0, $sanitizer->int($_GET['article'] ?? 0, 0)),
        ];

        $overview = self::container()->knowledgeBaseService()->overview($filters);

        View::render('knowledge/index', [
            'title' => __('Base de conhecimento', 'glpiacessivel'),
            'overview' => $overview,
        ]);
    }
}
