<?php

declare(strict_types=1);

namespace GlpiPlugin\Glpiacessivel\UI\Controller;

use GlpiPlugin\Glpiacessivel\Security\InputSanitizer;
use GlpiPlugin\Glpiacessivel\Support\Url;

final class ContextController extends BaseController
{
    public static function switch(): void
    {
        self::requireLogin();

        $method = strtoupper((string) ($_SERVER['REQUEST_METHOD'] ?? 'GET'));
        if ($method === 'GET') {
            self::confirmSwitch();
            return;
        }
        if ($method !== 'POST') {
            self::redirect303(Url::plugin('front/acessivel.php'));
        }

        self::csrf()->validateRequest();

        $sanitizer = new InputSanitizer();
        $profileId = max(0, $sanitizer->int($_POST['profile_id'] ?? 0, 0));
        $entityValue = trim((string) ($_POST['entity_id'] ?? 'current'));
        $returnTo = self::container()->contextService()->safeReturnTo((string) ($_POST['return_to'] ?? ''));

        try {
            $pending = self::container()->contextService()->beginConfirmedSwitch(
                $profileId,
                $entityValue,
                $returnTo
            );
            $confirmationUrl = Url::plugin(
                'front/context.php?context_confirmation=' . rawurlencode((string) $pending['confirmation_token'])
            );
            if (!self::container()->contextService()->commitSession()) {
                self::container()->auditLogger()->log('context.switch.commit_failed', [
                    'profile_id' => $profileId,
                    'entity_value' => $entityValue,
                ]);
            }
            self::redirect303($confirmationUrl);
        } catch (\Throwable $e) {
            self::container()->auditLogger()->log('context.switch.failed', [
                'profile_id' => $profileId,
                'entity_value' => $entityValue,
                'error' => $e->getMessage(),
            ]);
            self::setMessage('error', __('Não foi possível alterar entidade ou perfil. Verifique se o contexto selecionado está permitido para seu usuário.', 'glpiacessivel'));
            self::container()->contextService()->commitSession();
            self::redirect303($returnTo);
        }
    }

    private static function confirmSwitch(): void
    {
        $token = trim((string) ($_GET['context_confirmation'] ?? ''));
        if ($token === '') {
            self::redirect303(Url::plugin('front/acessivel.php'));
        }

        $confirmation = self::container()->contextService()->confirmContextSwitch($token);
        $context = (array) ($confirmation['context'] ?? []);
        if (!empty($confirmation['confirmed'])) {
            $message = !empty($confirmation['profile_changed'])
                ? sprintf(
                    __('Perfil alterado para %s. Entidade ativa: %s.', 'glpiacessivel'),
                    (string) ($context['current_profile_name'] ?? ''),
                    (string) ($context['current_entity_name'] ?? '')
                )
                : sprintf(
                    __('Entidade ativa alterada para %s.', 'glpiacessivel'),
                    (string) ($context['current_entity_name'] ?? '')
                );
            if (!empty($confirmation['entity_selection_adjusted'])) {
                $message .= ' ' . __('O GLPI selecionou uma entidade permitida para o novo perfil. Revise a lista de entidades se precisar alterar esse contexto.', 'glpiacessivel');
            }
            self::setMessage('success', $message);
        } else {
            self::setMessage(
                'error',
                __('O GLPI não confirmou a alteração de perfil ou entidade. O contexto anterior foi preservado.', 'glpiacessivel')
            );
        }

        $returnTo = self::container()->contextService()->safeReturnTo((string) ($confirmation['return_to'] ?? ''));
        self::container()->contextService()->commitSession();
        self::redirect303($returnTo);
    }

    private static function redirect303(string $url): void
    {
        if (!headers_sent()) {
            http_response_code(303);
            header('Location: ' . $url);
        }
        exit;
    }
}
