<?php

declare(strict_types=1);

namespace GlpiPlugin\Glpiacessivel\UI\View;

final class View
{
    public static function render(string $template, array $data = []): void
    {
        $templatePath = __DIR__ . '/../../../templates/' . $template . '.php';
        if (!is_file($templatePath)) {
            throw new \RuntimeException('Template não encontrado: ' . $template);
        }

        self::sendNoStoreHeaders();

        extract($data, EXTR_SKIP);
        $glpiacessivelStandaloneLayout = self::shouldUseStandaloneLayout($template);
        require __DIR__ . '/../../../templates/layout/header.php';
        require $templatePath;
        require __DIR__ . '/../../../templates/layout/footer.php';
    }

    private static function shouldUseStandaloneLayout(string $template): bool
    {
        if (str_starts_with($template, 'config/')) {
            return false;
        }

        if (!function_exists('plugin_glpiacessivel_get_accessibility_mode')) {
            return false;
        }

        return plugin_glpiacessivel_get_accessibility_mode() !== 'embedded';
    }

    private static function sendNoStoreHeaders(): void
    {
        if (headers_sent()) {
            return;
        }

        header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
        header('Pragma: no-cache');
        header('Expires: 0');
    }
}
