<?php

declare(strict_types=1);

namespace GlpiPlugin\Glpiacessivel\Support;

final class ItilTemplateResolutionException extends \RuntimeException
{
    private string $reasonCode;

    public function __construct(string $reasonCode)
    {
        parent::__construct('template_not_available');
        $this->reasonCode = $reasonCode;
    }

    public function reasonCode(): string
    {
        return $this->reasonCode;
    }
}
