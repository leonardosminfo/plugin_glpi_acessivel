<?php

declare(strict_types=1);

namespace GlpiPlugin\Glpiacessivel\Support;

final class GlpiCompatibility
{
    private const PUBLIC_STATELESS_REGEX = '#^/front/faq\.php$#';
    private const LEGACY_NO_CHECK_REGEX = '#^/front/(acessivel|faq|runtime-config\.js)\.php$#';

    public static function boot(): void
    {
        self::registerStatelessPublicPaths();
    }

    public static function init(array &$pluginHooks): void
    {
        $csrfHook = class_exists('\Glpi\Plugin\Hooks')
            ? \Glpi\Plugin\Hooks::CSRF_COMPLIANT
            : 'csrf_compliant';
        $pluginHooks[$csrfHook]['glpiacessivel'] = true;

        Bootstrap::init();
        self::registerLegacyPublicAccess();
        self::registerAnonymousAssets($pluginHooks);
    }

    private static function registerLegacyPublicAccess(): void
    {
        if (!class_exists('\Glpi\Http\Firewall')) {
            return;
        }

        try {
            \Glpi\Http\Firewall::addPluginStrategyForLegacyScripts(
                'glpiacessivel',
                self::LEGACY_NO_CHECK_REGEX,
                \Glpi\Http\Firewall::STRATEGY_NO_CHECK
            );
        } catch (\Throwable $e) {
            // Mantem compatibilidade com GLPI 10 sem quebrar a ativacao.
        }
    }

    private static function registerAnonymousAssets(array &$pluginHooks): void
    {
        if (defined('GLPI_VERSION') && version_compare(GLPI_VERSION, '10.0.18', '>=')) {
            $pluginHooks['add_css_anonymous_page']['glpiacessivel'] = 'assets/css/glpiacessivel.css';
        }
    }

    private static function registerStatelessPublicPaths(): void
    {
        if (!class_exists('\Glpi\Http\SessionManager')) {
            return;
        }

        if (!method_exists('\Glpi\Http\SessionManager', 'registerPluginStatelessPath')) {
            return;
        }

        try {
            \Glpi\Http\SessionManager::registerPluginStatelessPath(
                'glpiacessivel',
                self::PUBLIC_STATELESS_REGEX
            );
        } catch (\Throwable $e) {
            // Nao interrompe o boot em branches sem a mesma assinatura interna.
        }
    }
}
