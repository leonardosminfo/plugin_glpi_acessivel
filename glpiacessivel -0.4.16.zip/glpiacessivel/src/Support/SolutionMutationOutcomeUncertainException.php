<?php

declare(strict_types=1);

namespace GlpiPlugin\Glpiacessivel\Support;

final class SolutionMutationOutcomeUncertainException extends \RuntimeException
{
    public function __construct(
        private int $solutionId = 0,
        ?\Throwable $previous = null,
        private bool $sharedMarkerPersisted = false
    ) {
        parent::__construct('solution_mutation_outcome_uncertain', 0, $previous);
    }

    public function solutionId(): int
    {
        return max(0, $this->solutionId);
    }

    public function sharedMarkerPersisted(): bool
    {
        return $this->sharedMarkerPersisted;
    }
}
