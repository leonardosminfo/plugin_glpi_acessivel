<?php

declare(strict_types=1);

namespace GlpiPlugin\Glpiacessivel\Support;

final class Url
{
    public static function plugin(string $path = ''): string
    {
        global $CFG_GLPI;

        $root = (string) ($CFG_GLPI['root_doc'] ?? '');
        return $root . '/plugins/glpiacessivel/' . ltrim($path, '/');
    }

    public static function asset(string $path = ''): string
    {
        global $CFG_GLPI;

        $root = (string) ($CFG_GLPI['root_doc'] ?? '');
        return $root . '/plugins/glpiacessivel/' . ltrim($path, '/');
    }

    public static function core(string $path = ''): string
    {
        global $CFG_GLPI;

        $root = (string) ($CFG_GLPI['root_doc'] ?? '');
        return $root . '/' . ltrim($path, '/');
    }
}
