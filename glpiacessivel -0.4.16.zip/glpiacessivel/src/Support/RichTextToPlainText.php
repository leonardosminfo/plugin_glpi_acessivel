<?php

declare(strict_types=1);

namespace GlpiPlugin\Glpiacessivel\Support;

/**
 * Deterministic, inert projection of GLPI/TinyMCE HTML into a textarea value.
 * It never evaluates entities as markup and never fetches external resources.
 */
final class RichTextToPlainText
{
    public const MAX_INPUT_BYTES = 65536;
    public const MAX_OUTPUT_BYTES = 16000;

    /** @return array{text:string,lossy:bool} */
    public function convert(string $html): array
    {
        if (strlen($html) > self::MAX_INPUT_BYTES) {
            throw new \LengthException('rich_text_input_too_large');
        }
        if (trim($html) === '') {
            return ['text' => '', 'lossy' => false];
        }
        if (!class_exists('\DOMDocument')) {
            throw new \RuntimeException('rich_text_dom_unavailable');
        }

        $previous = libxml_use_internal_errors(true);
        try {
            $document = new \DOMDocument('1.0', 'UTF-8');
            $loaded = $document->loadHTML(
                '<?xml encoding="UTF-8"><div id="glpiacessivel-rich-root">' . $html . '</div>',
                LIBXML_NONET | LIBXML_NOERROR | LIBXML_NOWARNING | LIBXML_COMPACT
            );
            if (!$loaded) {
                throw new \RuntimeException('rich_text_parse_failed');
            }
            $root = $document->getElementById('glpiacessivel-rich-root');
            if (!$root instanceof \DOMElement) {
                throw new \RuntimeException('rich_text_parse_failed');
            }

            $lossy = false;
            foreach (['script', 'style', 'template', 'noscript', 'iframe', 'object', 'embed', 'svg', 'math'] as $tag) {
                $nodes = [];
                foreach ($root->getElementsByTagName($tag) as $node) {
                    $nodes[] = $node;
                }
                foreach ($nodes as $node) {
                    $node->parentNode?->removeChild($node);
                    $lossy = true;
                }
            }

            $text = $this->childrenText($root, $lossy);
            $text = str_replace(["\r\n", "\r", "\u{00A0}"], ["\n", "\n", ' '], $text);
            $lines = array_map(
                static function (string $line): string {
                    $line = preg_replace('/ {2,}/u', ' ', $line) ?? $line;
                    $line = preg_replace('/ *\t */u', "\t", $line) ?? $line;
                    return rtrim($line, " \t");
                },
                explode("\n", $text)
            );
            $text = trim(implode("\n", $lines));
            $text = preg_replace('/\n{3,}/u', "\n\n", $text) ?? $text;
            if (strlen($text) > self::MAX_OUTPUT_BYTES) {
                throw new \LengthException('rich_text_output_too_large');
            }

            return ['text' => $text, 'lossy' => $lossy];
        } finally {
            libxml_clear_errors();
            libxml_use_internal_errors($previous);
        }
    }

    private function childrenText(\DOMNode $parent, bool &$lossy): string
    {
        $text = '';
        foreach ($parent->childNodes as $child) {
            $text .= $this->nodeText($child, $lossy);
        }
        return $text;
    }

    private function nodeText(\DOMNode $node, bool &$lossy): string
    {
        if ($node instanceof \DOMText) {
            return $node->nodeValue ?? '';
        }
        if (!$node instanceof \DOMElement) {
            return '';
        }

        $tag = strtolower($node->tagName);
        if ($tag === 'br') {
            return "\n";
        }
        if ($tag === 'img') {
            $lossy = true;
            $alt = trim($node->getAttribute('alt'));
            return $alt === '' ? '[Imagem]' : '[Imagem: ' . $alt . ']';
        }

        $content = $this->childrenText($node, $lossy);
        if ($tag === 'a') {
            $label = trim($content);
            $href = trim($node->getAttribute('href'));
            if ($href !== '' && preg_match('/\A(?:https?:\/\/|mailto:)/i', $href) === 1 && $href !== $label) {
                return $label === '' ? $href : $label . ' (' . $href . ')';
            }
            return $label;
        }
        if ($tag === 'li') {
            return '- ' . trim($content) . "\n";
        }
        if (in_array($tag, ['td', 'th'], true)) {
            return trim($content) . "\t";
        }
        if ($tag === 'tr') {
            return rtrim($content, "\t \n") . "\n";
        }
        if (in_array($tag, ['p', 'div', 'section', 'article', 'header', 'footer', 'blockquote', 'pre', 'h1', 'h2', 'h3', 'h4', 'h5', 'h6', 'ul', 'ol', 'table'], true)) {
            return trim($content) . "\n\n";
        }

        return $content;
    }
}
