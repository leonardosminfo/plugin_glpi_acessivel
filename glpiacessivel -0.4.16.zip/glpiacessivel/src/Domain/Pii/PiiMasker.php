<?php

declare(strict_types=1);

namespace GlpiPlugin\Glpiacessivel\Domain\Pii;

final class PiiMasker
{
    public function maskEmail(?string $email): string
    {
        $email = trim((string) $email);
        if ($email === '' || !str_contains($email, '@')) {
            return '';
        }

        [$user, $domain] = explode('@', $email, 2);
        if (strlen($user) <= 2) {
            return '*@' . $domain;
        }

        return substr($user, 0, 2) . str_repeat('*', max(1, strlen($user) - 2)) . '@' . $domain;
    }

    public function maskPhone(?string $phone): string
    {
        $digits = preg_replace('/\D+/', '', (string) $phone);
        if ($digits === '' || strlen($digits) < 4) {
            return '';
        }

        return str_repeat('*', max(0, strlen($digits) - 4)) . substr($digits, -4);
    }

    public function maskText(?string $value): string
    {
        $value = trim((string) $value);
        if ($value === '') {
            return '';
        }

        if (strlen($value) <= 3) {
            return str_repeat('*', strlen($value));
        }

        return substr($value, 0, 2) . str_repeat('*', strlen($value) - 3) . substr($value, -1);
    }
}
