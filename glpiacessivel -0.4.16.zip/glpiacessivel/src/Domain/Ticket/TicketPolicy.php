<?php

declare(strict_types=1);

namespace GlpiPlugin\Glpiacessivel\Domain\Ticket;

final class TicketPolicy
{
    /**
     * @return int[]
     */
    public function getAllowedTransitions(int $status): array
    {
        if ($status === $this->solvedStatus() || $status === $this->closedStatus()) {
            return [];
        }

        $known = $this->getKnownStatuses();
        if ($known === []) {
            return [];
        }

        return array_values(array_filter(
            $known,
            static fn(int $candidate): bool => $candidate !== $status
        ));
    }

    public function isTransitionAllowed(int $from, int $to): bool
    {
        return in_array($to, $this->getAllowedTransitions($from), true);
    }

    /**
     * @return int[]
     */
    private function getKnownStatuses(): array
    {
        if (class_exists('\Ticket') && method_exists('\Ticket', 'getAllStatusArray')) {
            $statusArray = (array) \Ticket::getAllStatusArray();
            $known = [];
            foreach (array_keys($statusArray) as $status) {
                $intStatus = (int) $status;
                if ($intStatus > 0) {
                    $known[] = $intStatus;
                }
            }

            if ($known !== []) {
                sort($known);
                return array_values(array_unique($known));
            }
        }

        // Conservative fallback for very old/custom contexts.
        return [1, 2, 3, 4, 5, 6];
    }

    private function solvedStatus(): int
    {
        return defined('\CommonITILObject::SOLVED') ? (int) \CommonITILObject::SOLVED : 5;
    }

    private function closedStatus(): int
    {
        return defined('\CommonITILObject::CLOSED') ? (int) \CommonITILObject::CLOSED : 6;
    }
}
