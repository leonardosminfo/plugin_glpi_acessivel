<?php

declare(strict_types=1);

namespace GlpiPlugin\Glpiacessivel\Domain\Ticket;

/**
 * Closed set of value shapes accepted by native ticket search criteria.
 */
enum SearchValueKind: string
{
    case NONE = 'none';
    case TEXT = 'text';
    case INTEGER = 'integer';
    case DECIMAL = 'decimal';
    case DATE = 'date';
    case DATETIME = 'datetime';
    case BOOLEAN = 'boolean';
    case LOCAL_SELECT = 'local_select';
    case REMOTE_SELECT = 'remote_select';
}
