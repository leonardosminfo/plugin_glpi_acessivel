<?php

declare(strict_types=1);

namespace GlpiPlugin\Glpiacessivel\Domain\Ticket;

/**
 * Validates and canonicalizes a criterion value without trusting the browser.
 */
final class SearchCriterionValueValidator
{
    /** @param mixed $value */
    public function validate($value, SearchOperatorValueContract $contract): string
    {
        if ($contract->kind() === SearchValueKind::NONE) {
            if ($value !== $contract->canonicalValue()) {
                throw new \InvalidArgumentException('search_none_value_invalid');
            }
            return '';
        }

        if (is_bool($value)) {
            $value = $value ? '1' : '0';
        } elseif (is_int($value)) {
            $value = (string) $value;
        } elseif (!is_string($value)) {
            throw new \InvalidArgumentException('search_value_type_invalid');
        }

        $this->assertSafeString($value, $contract->maxBytes());
        if ($value === '' && !$contract->allowEmpty()) {
            throw new \InvalidArgumentException('search_value_empty');
        }

        switch ($contract->kind()) {
            case SearchValueKind::TEXT:
                return $value;

            case SearchValueKind::INTEGER:
                if (preg_match('/\A(?:0|[1-9][0-9]*)\z/D', $value) !== 1) {
                    throw new \InvalidArgumentException('search_integer_invalid');
                }
                return $value;

            case SearchValueKind::DECIMAL:
                if (preg_match('/\A-?(?:0|[1-9][0-9]*)(?:\.[0-9]+)?\z/D', $value) !== 1) {
                    throw new \InvalidArgumentException('search_decimal_invalid');
                }
                return $value;

            case SearchValueKind::DATE:
                if (!$this->matchesDate($value, 'Y-m-d')) {
                    throw new \InvalidArgumentException('search_date_invalid');
                }
                return $value;

            case SearchValueKind::DATETIME:
                return $this->canonicalDatetime($value);

            case SearchValueKind::BOOLEAN:
                if (!in_array($value, ['0', '1'], true)) {
                    throw new \InvalidArgumentException('search_boolean_invalid');
                }
                return $value;

            case SearchValueKind::LOCAL_SELECT:
                $allowed = array_column($contract->options(), 'value');
                if (!in_array($value, $allowed, true)) {
                    throw new \InvalidArgumentException('search_local_value_denied');
                }
                return $value;

            case SearchValueKind::REMOTE_SELECT:
                if (preg_match('/\A[1-9][0-9]*\z/D', $value) !== 1) {
                    throw new \InvalidArgumentException('search_remote_id_invalid');
                }
                return $value;

            case SearchValueKind::NONE:
                // Handled before scalar normalization.
                return '';
        }
    }

    private function assertSafeString(string $value, int $maxBytes): void
    {
        $validUtf8 = function_exists('mb_check_encoding')
            ? mb_check_encoding($value, 'UTF-8')
            : preg_match('//u', $value) === 1;
        if (
            strlen($value) > $maxBytes
            || preg_match('/[\x00-\x1F\x7F]/', $value) === 1
            || !$validUtf8
        ) {
            throw new \InvalidArgumentException('search_value_unsafe');
        }
    }

    private function matchesDate(string $value, string $format): bool
    {
        $date = \DateTimeImmutable::createFromFormat('!' . $format, $value);
        $errors = \DateTimeImmutable::getLastErrors();
        return $date !== false
            && ($errors === false || ($errors['warning_count'] === 0 && $errors['error_count'] === 0))
            && $date->format($format) === $value;
    }

    private function canonicalDatetime(string $value): string
    {
        foreach (['Y-m-d H:i:s', 'Y-m-d H:i', 'Y-m-d\TH:i:s', 'Y-m-d\TH:i'] as $format) {
            if (!$this->matchesDate($value, $format)) {
                continue;
            }
            $date = \DateTimeImmutable::createFromFormat('!' . $format, $value);
            if ($date !== false) {
                return $date->format('Y-m-d H:i:s');
            }
        }
        throw new \InvalidArgumentException('search_datetime_invalid');
    }
}
