<?php

declare(strict_types=1);

namespace GlpiPlugin\Glpiacessivel\Domain\Ticket;

/**
 * Contextual contract for one GLPI Search Option.
 */
final class SearchFieldContract
{
    /** @var array<string,SearchOperatorValueContract> */
    private array $operators = [];

    /**
     * @param SearchOperatorValueContract[] $operators
     */
    public function __construct(
        private string $itemtype,
        private int $fieldId,
        private string $field,
        private string $table,
        private string $linkfield,
        private string $datatype,
        array $operators
    ) {
        if ($this->itemtype === '' || $this->fieldId < 1 || $operators === []) {
            throw new \InvalidArgumentException('search_field_contract_invalid');
        }
        foreach ($operators as $contract) {
            if (!$contract instanceof SearchOperatorValueContract) {
                throw new \InvalidArgumentException('search_operator_contract_invalid');
            }
            if (isset($this->operators[$contract->operator()])) {
                throw new \InvalidArgumentException('search_operator_contract_duplicate');
            }
            $this->operators[$contract->operator()] = $contract;
        }
    }

    public function itemtype(): string
    {
        return $this->itemtype;
    }

    public function fieldId(): int
    {
        return $this->fieldId;
    }

    public function field(): string
    {
        return $this->field;
    }

    public function table(): string
    {
        return $this->table;
    }

    public function linkfield(): string
    {
        return $this->linkfield;
    }

    public function datatype(): string
    {
        return $this->datatype;
    }

    /** @return array<string,SearchOperatorValueContract> */
    public function operators(): array
    {
        return $this->operators;
    }

    /** @return array<string,array<string,mixed>> */
    public function validationMap(): array
    {
        $map = [];
        foreach ($this->operators as $operator => $contract) {
            $map[$operator] = $contract->toArray();
        }
        return $map;
    }
}
