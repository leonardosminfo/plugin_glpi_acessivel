<?php

declare(strict_types=1);

namespace GlpiPlugin\Glpiacessivel\Domain\Ticket;

/**
 * Safe validation failure for an untrusted native ticket-search definition.
 *
 * The message contains only a stable reason code. The rejected field or value
 * must never be appended to it because this exception may be audited or shown
 * in operational diagnostics.
 */
final class NativeSearchValidationException extends \InvalidArgumentException
{
    public function __construct(
        private string $reasonCode,
        private string $fieldPath = ''
    ) {
        parent::__construct($reasonCode);
    }

    public function reasonCode(): string
    {
        return $this->reasonCode;
    }

    public function fieldPath(): string
    {
        return $this->fieldPath;
    }
}
