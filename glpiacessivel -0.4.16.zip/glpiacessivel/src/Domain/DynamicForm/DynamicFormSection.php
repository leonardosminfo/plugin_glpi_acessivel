<?php

declare(strict_types=1);

namespace GlpiPlugin\Glpiacessivel\Domain\DynamicForm;

final class DynamicFormSection
{
    public function __construct(
        private string $id,
        private string $title,
        private int $order = 0,
        private string $description = ''
    ) {
    }

    public function id(): string
    {
        return $this->id;
    }

    /**
     * @return array<string, mixed>
     */
    public function toArray(): array
    {
        return [
            'id' => $this->id,
            'title' => $this->title,
            'order' => $this->order,
            'description' => $this->description,
        ];
    }
}
