<?php

declare(strict_types=1);

namespace GlpiPlugin\Glpiacessivel\Domain\DynamicForm;

/**
 * Normalized capability contract shared by GLPI 11 Service Catalog and
 * Formcreator integrations. It deliberately separates rendering from submit.
 */
final class FormCapability
{
    /** @param array<string, string> $areas @param string[] $blockers @param array<string, mixed> $diagnostics */
    public function __construct(
        private string $source,
        private string $submissionMode,
        private array $areas,
        private array $blockers = [],
        private array $diagnostics = []
    ) {
    }

    /**
     * @param array<string, mixed> $readiness
     * @param array<int, array<string, mixed>> $matrix
     */
    public static function fromReadiness(
        string $source,
        array $readiness,
        array $matrix,
        bool $nativeDelegated
    ): self {
        $areas = [];
        foreach ($matrix as $item) {
            if (!is_array($item) || (string) ($item['area'] ?? '') === '') {
                continue;
            }
            $areas[(string) $item['area']] = (string) ($item['status'] ?? 'unknown');
        }

        $ready = !empty($readiness['ready']);
        $ownSubmissionEnabled = !empty($readiness['own_submission_enabled']);
        $submissionMode = $ownSubmissionEnabled && $ready
            ? 'own'
            : ($nativeDelegated && $ready ? 'native_delegated' : 'native_fallback');

        return new self(
            $source,
            $submissionMode,
            $areas,
            array_values(array_filter(array_map('strval', (array) ($readiness['blocked_areas'] ?? [])))),
            [
                'ready' => $ready,
                'own_submission_enabled' => $ownSubmissionEnabled,
                'native_delegated' => $nativeDelegated,
                'decision' => (string) ($readiness['decision'] ?? 'native_fallback_required'),
            ]
        );
    }

    public function allowsOwnSubmission(): bool
    {
        return $this->submissionMode === 'own' && $this->blockers === [];
    }

    /** @return array<string, mixed> */
    public function toArray(): array
    {
        return [
            'source' => $this->source,
            'submission_mode' => $this->submissionMode,
            'own_submission_allowed' => $this->allowsOwnSubmission(),
            'areas' => $this->areas,
            'blockers' => $this->blockers,
            'diagnostics' => $this->diagnostics,
        ];
    }
}
