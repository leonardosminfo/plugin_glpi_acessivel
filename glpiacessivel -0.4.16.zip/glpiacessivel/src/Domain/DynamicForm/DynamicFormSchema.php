<?php

declare(strict_types=1);

namespace GlpiPlugin\Glpiacessivel\Domain\DynamicForm;

final class DynamicFormSchema
{
    /** @var DynamicFormSection[] */
    private array $sections;
    /** @var DynamicFormField[] */
    private array $fields;
    /** @var DynamicFormCondition[] */
    private array $conditions;

    /**
     * @param DynamicFormSection[] $sections
     * @param DynamicFormField[] $fields
     * @param DynamicFormCondition[] $conditions
     * @param array<string, mixed> $capabilities
     * @param array<string, mixed> $fallback
     * @param array<string, mixed> $metadata
     */
    public function __construct(
        private string $id,
        private string $source,
        private string $version,
        private string $title,
        array $sections,
        array $fields,
        array $conditions = [],
        private array $capabilities = [],
        private array $fallback = [],
        private array $metadata = []
    ) {
        $this->sections = array_values($sections);
        $this->fields = array_values($fields);
        $this->conditions = array_values($conditions);
    }

    public function id(): string
    {
        return $this->id;
    }

    public function source(): string
    {
        return $this->source;
    }

    /**
     * @return DynamicFormField[]
     */
    public function fields(): array
    {
        return $this->fields;
    }

    public function fieldByNativeName(string $name): ?DynamicFormField
    {
        foreach ($this->fields as $field) {
            if ($field->nativeField() === $name || $field->name() === $name || $field->id() === $name) {
                return $field;
            }
        }

        return null;
    }

    /**
     * @return string[]
     */
    public function nativeFieldNames(): array
    {
        return array_values(array_unique(array_map(
            static fn(DynamicFormField $field): string => $field->nativeField(),
            $this->fields
        )));
    }

    public function requiresNativeFallback(): bool
    {
        return !empty($this->fallback['required']);
    }

    /**
     * @return array<string, mixed>
     */
    public function toArray(): array
    {
        return [
            'id' => $this->id,
            'source' => $this->source,
            'version' => $this->version,
            'title' => $this->title,
            'sections' => array_map(static fn(DynamicFormSection $section): array => $section->toArray(), $this->sections),
            'fields' => array_map(static fn(DynamicFormField $field): array => $field->toArray(), $this->fields),
            'conditions' => array_map(static fn(DynamicFormCondition $condition): array => $condition->toArray(), $this->conditions),
            'capabilities' => $this->capabilities,
            'fallback' => $this->fallback,
            'metadata' => $this->metadata,
            'native_fields' => $this->nativeFieldNames(),
        ];
    }
}
