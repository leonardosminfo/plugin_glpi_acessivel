<?php

declare(strict_types=1);

namespace GlpiPlugin\Glpiacessivel\Domain\Security;

use GlpiPlugin\Glpiacessivel\Infrastructure\Audit\AuditRights;

final class AuditAuthorization
{
    public function canRead(): bool
    {
        return $this->hasRight(AuditRights::READ);
    }

    public function canReadSensitive(): bool
    {
        return $this->canRead() && $this->hasRight(AuditRights::SENSITIVE);
    }

    public function canExport(): bool
    {
        return $this->canRead() && $this->hasRight(AuditRights::EXPORT);
    }

    public function canReadGlobal(): bool
    {
        return $this->canRead() && $this->hasRight(AuditRights::GLOBAL);
    }

    /** @param array<string,mixed> $row */
    public function canReadRow(array $row, bool $sensitive = false): bool
    {
        if (!$this->canRead() || ($sensitive && !$this->canReadSensitive())) {
            return false;
        }

        $scope = (string) ($row['scope_kind'] ?? 'legacy');
        $ticketId = (int) ($row['tickets_id'] ?? 0);
        if ($scope === 'global') {
            return $this->canReadGlobal();
        }

        $entityId = (int) ($row['resource_entities_id'] ?? $row['entities_id'] ?? -1);
        if (!$this->hasActiveEntity($entityId)) {
            return false;
        }

        return $ticketId <= 0 || $this->canReadTicket($ticketId);
    }

    /** @return list<int> */
    public function activeEntities(): array
    {
        $active = [];
        try {
            $values = method_exists('\Session', 'getActiveEntities')
                ? \Session::getActiveEntities()
                : (array) ($_SESSION['glpiactiveentities'] ?? []);
            foreach ((array) $values as $key => $value) {
                $candidate = is_numeric($value) ? (int) $value : (is_numeric($key) ? (int) $key : -1);
                if ($candidate >= 0) {
                    $active[$candidate] = $candidate;
                }
            }
        } catch (\Throwable) {
            return [];
        }

        return array_values($active);
    }

    private function hasRight(string $right): bool
    {
        if (!method_exists('\Session', 'haveRight')) {
            return false;
        }

        try {
            return (bool) \Session::haveRight($right, defined('READ') ? (int) constant('READ') : 1);
        } catch (\Throwable) {
            return false;
        }
    }

    private function hasActiveEntity(int $entityId): bool
    {
        return $entityId >= 0 && in_array($entityId, $this->activeEntities(), true);
    }

    private function canReadTicket(int $ticketId): bool
    {
        if ($ticketId <= 0 || !class_exists('\Ticket')) {
            return false;
        }

        try {
            $ticket = new \Ticket();
            return method_exists($ticket, 'can')
                && method_exists($ticket, 'getFromDB')
                && $ticket->can($ticketId, defined('READ') ? (int) constant('READ') : 1)
                && $ticket->getFromDB($ticketId);
        } catch (\Throwable) {
            return false;
        }
    }
}
