<?php

declare(strict_types=1);

namespace GlpiPlugin\Glpiacessivel\Domain\Security;

final class Authorization
{
    public function canViewPortal(): bool
    {
        return $this->canViewTickets()
            || $this->canCreateTickets()
            || $this->canViewKnowledgeBase()
            || $this->canUseForms()
            || $this->canReadAudit();
    }

    public function canViewTickets(): bool
    {
        if (class_exists('\Ticket') && method_exists('\Session', 'haveRightsOr')) {
            $rights = [];
            foreach (['READMY', 'READALL', 'READGROUP', 'READASSIGN', 'READNEWTICKET'] as $constant) {
                $constantName = \Ticket::class . '::' . $constant;
                if (defined($constantName)) {
                    $rights[] = (int) constant($constantName);
                }
            }

            if (defined('READ')) {
                $rights[] = READ;
            }

            $rights = array_values(array_unique($rights));
            if ($rights !== [] && \Session::haveRightsOr('ticket', $rights)) {
                return true;
            }
        }

        if (class_exists('\Ticket') && method_exists('\Ticket', 'canView')) {
            return (bool) \Ticket::canView();
        }

        return method_exists('\Session', 'haveRight') && defined('READ') && (bool) \Session::haveRight('ticket', READ);
    }

    public function canUpdateTickets(): bool
    {
        if (class_exists('\Ticket') && method_exists('\Ticket', 'canUpdate')) {
            return (bool) \Ticket::canUpdate();
        }

        return (bool) \Session::haveRight('ticket', UPDATE);
    }

    public function canCreateTickets(): bool
    {
        if (class_exists('\Ticket') && method_exists('\Ticket', 'canCreate')) {
            return (bool) \Ticket::canCreate();
        }

        return (bool) \Session::haveRight('ticket', CREATE);
    }
    /**
     * Coarse access to the request catalog. This intentionally does not depend
     * on Ticket::CREATE: native forms and Formcreator own their access policies
     * and may target item types other than Ticket.
     */
    public function canAccessFormsCatalog(): bool
    {
        if (!$this->isLoggedIn()) {
            return false;
        }

        $serviceCatalog = '\Glpi\Form\ServiceCatalog\ServiceCatalog';
        if (class_exists($serviceCatalog)) {
            if (!method_exists($serviceCatalog, 'canView')) {
                return false;
            }

            try {
                return (bool) $serviceCatalog::canView();
            } catch (\Throwable) {
                return false;
            }
        }

        if (
            defined('GLPI_VERSION')
            && version_compare((string) constant('GLPI_VERSION'), '11.0.0', '>=')
        ) {
            return false;
        }

        return $this->formcreatorRequestCatalogAvailable();
    }

    /**
     * Backward-compatible semantic alias used by the portal and menu layer.
     */
    public function canUseForms(): bool
    {
        return $this->canAccessFormsCatalog();
    }

    /**
     * Reauthorize one exact native form in the active session context.
     *
     * @param array<string,scalar|null> $urlParameters
     */
    public function canAccessForm(string $source, int $id, array $urlParameters = []): bool
    {
        if ($id <= 0 || !$this->canAccessFormsCatalog()) {
            return false;
        }

        return match ($source) {
            'formcreator_glpi10' => $this->canAccessFormcreatorForm($id),
            'glpi11_service_catalog' => $this->canAccessGlpi11Form($id, $urlParameters),
            default => false,
        };
    }
    public function canViewFormDiagnostics(): bool
    {
        return $this->canManagePluginConfiguration();
    }

    /**
     * Technical portal diagnostics are restricted to administrators/configuration managers.
     * Keep this semantic alias for screens that are not form-specific.
     */
    public function canViewOperationalDiagnostics(): bool
    {
        return $this->canManagePluginConfiguration();
    }

    /**
     * Diagnostic data follows a native capability, never a profile name or id.
     * Missing APIs, constants and runtime errors fail closed for GLPI 10/11.
     */
    private function canManagePluginConfiguration(): bool
    {
        if (!method_exists('\Session', 'haveRight') || !defined('UPDATE')) {
            return false;
        }

        try {
            return (bool) \Session::haveRight('config', UPDATE);
        } catch (\Throwable) {
            return false;
        }
    }

    public function canCreateFollowup(): bool
    {
        return (bool) (\Session::haveRight('followup', CREATE) || \Session::haveRight('ticket', UPDATE));
    }

    public function canRevealPii(): bool
    {
        return (bool) (\Session::haveRight('config', UPDATE) || \Session::haveRight('ticket', UPDATE));
    }

    public function canReadAudit(): bool
    {
        return (new AuditAuthorization())->canRead();
    }

    public function canReadSensitiveAudit(): bool
    {
        return (new AuditAuthorization())->canReadSensitive();
    }

    public function canExportAudit(): bool
    {
        return (new AuditAuthorization())->canExport();
    }

    public function canReadGlobalAudit(): bool
    {
        return (new AuditAuthorization())->canReadGlobal();
    }

    public function canViewKnowledgeBase(): bool
    {
        if (class_exists('\KnowbaseItem') && method_exists('\KnowbaseItem', 'canView') && (bool) \KnowbaseItem::canView()) {
            return true;
        }

        if (method_exists('\Session', 'haveRightsOr') && class_exists('\KnowbaseItem') && defined('READ')) {
            $rights = [
                READ,
            ];
            if (defined(\KnowbaseItem::class . '::READFAQ')) {
                $rights[] = \KnowbaseItem::READFAQ;
            }

            return (bool) \Session::haveRightsOr('knowbase', $rights);
        }

        if (method_exists('\Session', 'haveRight') && defined('READ') && \Session::haveRight('knowbase', READ)) {
            return true;
        }

        return class_exists('\KnowbaseItem')
            && defined(\KnowbaseItem::class . '::READFAQ')
            && \Session::haveRight('knowbase', \KnowbaseItem::READFAQ);
    }

    public function canViewKnowledgeBaseFull(): bool
    {
        if (method_exists('\Session', 'haveRight')) {
            return (bool) \Session::haveRight('knowbase', READ);
        }

        return $this->canViewKnowledgeBase();
    }

    public function canViewCockpit(): bool
    {
        return $this->canViewTickets();
    }

    public function canUseChatbot(): bool
    {
        return $this->canViewTickets() || $this->canCreateTickets() || $this->canViewKnowledgeBase() || $this->canUseForms();
    }

    private function isLoggedIn(): bool
    {
        try {
            return method_exists('\Session', 'getLoginUserID')
                ? (int) \Session::getLoginUserID() > 0
                : isset($_SESSION['glpiID']) && (int) $_SESSION['glpiID'] > 0;
        } catch (\Throwable) {
            return false;
        }
    }

    private function formcreatorRequestCatalogAvailable(): bool
    {
        if (!class_exists('\PluginFormcreatorForm')) {
            return false;
        }

        if (!class_exists('\Plugin') || !method_exists('\Plugin', 'isActivated')) {
            return false;
        }

        try {
            $plugin = new \Plugin();
            return (bool) call_user_func([$plugin, 'isActivated'], 'formcreator');
        } catch (\Throwable) {
            return false;
        }
    }

    private function canAccessFormcreatorForm(int $id): bool
    {
        if (
            !class_exists('\PluginFormcreatorForm')
            || !method_exists('\PluginFormcreatorForm', 'getFromDB')
            || !method_exists('\PluginFormcreatorForm', 'canViewForRequest')
        ) {
            return false;
        }

        try {
            $form = new \PluginFormcreatorForm();
            return $form->getFromDB($id) === true && $form->canViewForRequest() === true;
        } catch (\Throwable) {
            return false;
        }
    }

    /** @param array<string,scalar|null> $urlParameters */
    private function canAccessGlpi11Form(int $id, array $urlParameters): bool
    {
        $formClass = '\Glpi\Form\Form';
        $managerClass = '\Glpi\Form\AccessControl\FormAccessControlManager';
        $parametersClass = '\Glpi\Form\AccessControl\FormAccessParameters';
        if (
            !class_exists($formClass)
            || !method_exists($formClass, 'getById')
            || !class_exists($managerClass)
            || !method_exists($managerClass, 'getInstance')
            || !class_exists($parametersClass)
            || !method_exists('\Session', 'getCurrentSessionInfo')
        ) {
            return false;
        }

        try {
            $form = $formClass::getById($id);
            if (!$form instanceof $formClass) {
                return false;
            }

            $rightName = is_string($formClass::$rightname ?? null)
                ? (string) $formClass::$rightname
                : 'form';
            $readRight = defined('READ') ? (int) constant('READ') : 1;
            $bypass = method_exists('\Session', 'haveRight')
                && (bool) \Session::haveRight($rightName, $readRight);
            $session = $bypass ? null : \Session::getCurrentSessionInfo();
            if (!$bypass && $session === null) {
                return false;
            }

            $parameters = new $parametersClass($session, $urlParameters, $bypass);
            $manager = $managerClass::getInstance();
            return method_exists($manager, 'canAnswerForm')
                && (bool) $manager->canAnswerForm($form, $parameters);
        } catch (\Throwable) {
            return false;
        }
    }
}
