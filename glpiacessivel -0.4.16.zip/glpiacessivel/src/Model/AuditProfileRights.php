<?php

declare(strict_types=1);

namespace GlpiPlugin\Glpiacessivel\Model;

use GlpiPlugin\Glpiacessivel\Infrastructure\Audit\AuditRights;
use GlpiPlugin\Glpiacessivel\Security\CsrfGuard;
use GlpiPlugin\Glpiacessivel\Support\Url;

final class AuditProfileRights extends \CommonDBTM
{
    protected static $notable = true;

    public static function getTypeName($nb = 0): string
    {
        return __('Auditoria do GLPI Acessível', 'glpiacessivel');
    }

    public function getTabNameForItem($item, $withtemplate = 0): string
    {
        unset($withtemplate);
        return $item instanceof \Profile ? self::getTypeName() : '';
    }

    public static function displayTabContentForItem($item, $tabnum = 1, $withtemplate = 0): bool
    {
        unset($tabnum, $withtemplate);
        if (!$item instanceof \Profile || !method_exists($item, 'getID')) {
            return false;
        }

        $profileId = (int) $item->getID();
        $rights = class_exists('\ProfileRight') && method_exists('\ProfileRight', 'getProfileRights')
            ? \ProfileRight::getProfileRights($profileId, AuditRights::all())
            : [];
        $canEdit = method_exists('\Session', 'haveRight')
            && \Session::haveRight('profile', defined('UPDATE') ? (int) constant('UPDATE') : 4);
        $read = defined('READ') ? (int) constant('READ') : 1;

        echo '<section class="glpiacessivel-card" aria-labelledby="glpiacessivel-audit-rights-title">';
        echo '<h2 id="glpiacessivel-audit-rights-title">'
            . htmlspecialchars(self::getTypeName(), ENT_QUOTES, 'UTF-8') . '</h2>';
        echo '<p>' . htmlspecialchars(
            __('Esses direitos controlam a trilha persistente. Eles não são concedidos por nome de perfil, atualização de chamados ou revelação de dados pessoais.', 'glpiacessivel'),
            ENT_QUOTES,
            'UTF-8'
        ) . '</p>';
        echo '<form method="post" action="'
            . htmlspecialchars(Url::plugin('front/audit.profile.form.php'), ENT_QUOTES, 'UTF-8') . '">';
        echo '<input type="hidden" name="_glpi_csrf_token" value="'
            . htmlspecialchars((new CsrfGuard())->token(), ENT_QUOTES, 'UTF-8') . '" />';
        echo '<input type="hidden" name="profiles_id" value="' . $profileId . '" />';
        echo '<fieldset><legend>'
            . htmlspecialchars(__('Direitos de auditoria', 'glpiacessivel'), ENT_QUOTES, 'UTF-8') . '</legend>';
        foreach (AuditRights::labels() as $name => $label) {
            $id = 'glpiacessivel-right-' . preg_replace('/[^a-z0-9_-]/i', '-', $name);
            $checked = (((int) ($rights[$name] ?? 0)) & $read) === $read;
            echo '<div class="glpiacessivel-checkbox-row">';
            echo '<input type="hidden" name="rights['
                . htmlspecialchars($name, ENT_QUOTES, 'UTF-8') . ']" value="0" />';
            echo '<input id="' . htmlspecialchars($id, ENT_QUOTES, 'UTF-8')
                . '" type="checkbox" name="rights[' . htmlspecialchars($name, ENT_QUOTES, 'UTF-8')
                . ']" value="1"' . ($checked ? ' checked' : '') . ($canEdit ? '' : ' disabled') . ' />';
            echo '<label for="' . htmlspecialchars($id, ENT_QUOTES, 'UTF-8') . '">'
                . htmlspecialchars($label, ENT_QUOTES, 'UTF-8') . '</label></div>';
        }
        echo '</fieldset>';
        if ($canEdit) {
            echo '<button type="submit">'
                . htmlspecialchars(__('Salvar direitos', 'glpiacessivel'), ENT_QUOTES, 'UTF-8') . '</button>';
        }
        echo '</form></section>';
        return true;
    }
}
