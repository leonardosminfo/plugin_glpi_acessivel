<?php

declare(strict_types=1);

namespace GlpiPlugin\Glpiacessivel\Application;

use GlpiPlugin\Glpiacessivel\Domain\Security\Authorization;
use GlpiPlugin\Glpiacessivel\Infrastructure\Audit\AuditLogger;
use GlpiPlugin\Glpiacessivel\Infrastructure\Repository\NativeSavedSearchGateway;
use GlpiPlugin\Glpiacessivel\Infrastructure\Security\IdempotencyLedger;

final class SavedTicketSearchService
{
    public function __construct(
        private NativeSavedSearchGateway $gateway,
        private Authorization $authorization,
        private AuditLogger $auditLogger
    ) {
    }

    /** @return array<string,mixed> */
    public function catalog(string $query = '', string $cursor = '', int $pageSize = 25): array
    {
        $this->ensureAllowed();
        $page = $this->gateway->page($query, $cursor, $pageSize);
        $defaultKey = '';
        $defaultItem = null;
        $defaultId = $this->gateway->defaultId();
        if ($defaultId > 0) {
            $default = $this->gateway->getAuthorized($defaultId);
            $defaultItem = $default;
            if ($default !== null && (string) ($default['capability'] ?? '') !== 'native_only') {
                $defaultKey = 'native:' . $defaultId;
            }
        }

        return [
            'native' => (array) $page['items'],
            'default_key' => $defaultKey,
            'default_item' => $defaultItem,
            'capabilities' => $this->gateway->capabilities(),
            'next_cursor' => (string) $page['next_cursor'],
            'has_more' => (bool) $page['has_more'],
            'page_size' => (int) $page['page_size'],
            'query' => (string) $page['query'],
        ];
    }

    /** @return array<string,mixed> */
    public function searchCatalog(): array
    {
        $this->ensureAllowed();
        return $this->gateway->searchCatalog();
    }

    /** @return array<string,mixed> */
    public function validationContext(): array
    {
        $this->ensureAllowed();
        return $this->gateway->validationContext(true);
    }

    /** @param array<string,mixed> $definition @return array<string,mixed> */
    public function validateDefinition(array $definition): array
    {
        $this->ensureAllowed();
        return $this->gateway->validateDefinition($definition);
    }

    /** @return array{view:array<string,mixed>,filters:array<string,mixed>}|null */
    public function resolve(string $key): ?array
    {
        $this->ensureAllowed();
        if (preg_match('/^native:(\d+)$/', $key, $matches) !== 1) {
            return null;
        }
        $id = (int) $matches[1];
        $view = $this->gateway->getAuthorized($id);
        if ($view === null) {
            return null;
        }

        $filters = ['native_saved_search_id' => $id];
        if ((string) ($view['capability'] ?? '') !== 'native_only') {
            try {
                $definition = (array) ($view['definition'] ?? []);
                $definition['version'] = 3;
                $definition['text'] = '';
                $definition['scope'] = 'all';
                $definition = $this->gateway->validateDefinition($definition);
                $filters['native_criteria'] = (array) $definition['criteria'];
                $filters['native_metacriteria'] = (array) $definition['metacriteria'];
                $filters['native_sort'] = (array) $definition['sort'];
                $filters['native_order'] = (array) $definition['order'];
                $filters['native_is_deleted'] = (int) $definition['is_deleted'];
                $filters['q'] = (string) $definition['text'];
                $filters['scope'] = (string) $definition['scope'];
                if (array_key_exists('columns', $definition)) {
                    $filters['columns'] = (array) $definition['columns'];
                }
                $nativePageSize = (int) ($view['page_size'] ?? 0);
                if (in_array($nativePageSize, [10, 20, 50, 100], true)) {
                    $filters['page_size'] = $nativePageSize;
                }
                $view['definition'] = $definition;
            } catch (\Throwable $e) {
                $view['capability'] = 'native_only';
                $reasons = (array) ($view['capability_reasons'] ?? []);
                $reasons[] = 'native_context_validation_failed';
                $view['capability_reasons'] = array_values(array_unique($reasons));
            }
        }

        return ['view' => $view, 'filters' => $filters];
    }

    /** @return array<string,mixed> */
    public function buildSimpleDefinition(array $filters): array
    {
        $this->ensureAllowed();
        return $this->gateway->buildSimpleDefinition($filters);
    }

    /**
     * @param callable():int $mutation
     * @return array{status:string,result_id:int}
     */
    public function mutateIdempotently(
        IdempotencyLedger $ledger,
        string $scope,
        string $idempotencyKey,
        string $requestHash,
        callable $mutation
    ): array {
        $this->ensureAllowed();
        return $this->gateway->mutateIdempotently(
            $ledger,
            $scope,
            $idempotencyKey,
            $requestHash,
            $mutation
        );
    }

    /** @param array<string,mixed> $options */
    public function create(
        string $name,
        array $definition,
        bool $isDefault = false,
        array $options = []
    ): int {
        $this->ensureAllowed();
        if ($isDefault) {
            $options['set_default'] = true;
        }
        $id = $this->gateway->create($name, $definition, $options);
        $this->auditLogger->log('ticket.saved_search.native.create', [
            'saved_search_id' => $id,
            'is_private' => !array_key_exists('is_private', $options) || !empty($options['is_private']),
            'set_default' => !empty($options['set_default']),
        ]);
        return $id;
    }

    /** @param array<string,mixed> $options */
    public function update(
        int $id,
        string $name,
        array $definition,
        string $expectedFingerprint = '',
        array $options = []
    ): bool {
        $this->ensureAllowed();
        $updated = $this->gateway->update(
            $id,
            $name,
            $definition,
            $expectedFingerprint,
            $options
        );
        $this->auditLogger->log('ticket.saved_search.native.update', [
            'saved_search_id' => $id,
            'updated' => $updated,
            'visibility_changed' => array_key_exists('is_private', $options),
            'default_changed' => array_key_exists('set_default', $options),
        ]);
        return $updated;
    }

    /** @param array<string,mixed> $options */
    public function updateMetadata(
        int $id,
        string $name,
        string $expectedFingerprint = '',
        array $options = []
    ): bool {
        $this->ensureAllowed();
        $updated = $this->gateway->updateMetadata(
            $id,
            $name,
            $expectedFingerprint,
            $options
        );
        $this->auditLogger->log('ticket.saved_search.native.update_metadata', [
            'saved_search_id' => $id,
            'updated' => $updated,
            'default_changed' => array_key_exists('set_default', $options),
        ]);
        return $updated;
    }
    public function delete(int $id, string $expectedFingerprint = ''): bool
    {
        $this->ensureAllowed();
        $deleted = $this->gateway->delete($id, $expectedFingerprint);
        $this->auditLogger->log('ticket.saved_search.native.delete', [
            'saved_search_id' => $id,
            'deleted' => $deleted,
        ]);
        return $deleted;
    }

    public function setDefault(int $id, string $expectedFingerprint = ''): bool
    {
        $this->ensureAllowed();
        $updated = $this->gateway->setDefault($id, $expectedFingerprint);
        $this->auditLogger->log('ticket.saved_search.native.default', [
            'saved_search_id' => $id,
            'updated' => $updated,
        ]);
        return $updated;
    }

    public function unsetDefault(int $id, string $expectedFingerprint = ''): bool
    {
        $this->ensureAllowed();
        $updated = $this->gateway->unsetDefault($id, $expectedFingerprint);
        $this->auditLogger->log('ticket.saved_search.native.unset_default', [
            'saved_search_id' => $id,
            'updated' => $updated,
        ]);
        return $updated;
    }

    private function ensureAllowed(): void
    {
        if (!$this->authorization->canViewTickets()) {
            throw new \RuntimeException('saved_search_access_denied');
        }
    }
}
