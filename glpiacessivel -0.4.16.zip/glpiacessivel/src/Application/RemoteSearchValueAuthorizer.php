<?php

declare(strict_types=1);

namespace GlpiPlugin\Glpiacessivel\Application;

use GlpiPlugin\Glpiacessivel\Domain\Ticket\NativeSearchValidationException;
use GlpiPlugin\Glpiacessivel\Infrastructure\Search\GlpiSearchValueProvider;
use GlpiPlugin\Glpiacessivel\Infrastructure\Search\GlpiSearchValueRateLimiter;

/**
 * Revalidates remote criterion identifiers before an advanced search is stored.
 *
 * Field type, backing model, ACL, entity restrictions and labels are recovered
 * exclusively from the current server-side GLPI Search Option catalog.
 */
final class RemoteSearchValueAuthorizer
{
    private const MAX_REMOTE_VALUES = 50;

    public function __construct(
        private GlpiSearchValueProvider $provider,
        private GlpiSearchValueRateLimiter $rateLimiter
    ) {
    }

    /** @param array<string,mixed> $definition */
    public function authorize(array $definition, string $contextRevision): void
    {
        try {
            $this->provider->assertContextRevision($contextRevision);
        } catch (\InvalidArgumentException) {
            throw new NativeSearchValidationException(
                'native_search_context_stale',
                'advanced.context_revision'
            );
        }

        /** @var array<string,array{itemtype:string,field:int,id:int,path:string}> $references */
        $references = [];
        $this->collectCriteria(
            (array) ($definition['criteria'] ?? []),
            'Ticket',
            'definition.criteria',
            $references
        );
        $this->collectCriteria(
            (array) ($definition['metacriteria'] ?? []),
            '',
            'definition.metacriteria',
            $references
        );

        if ($references === []) {
            return;
        }
        if (count($references) > self::MAX_REMOTE_VALUES) {
            throw new NativeSearchValidationException(
                'native_search_remote_values_limit_exceeded',
                'definition.criteria'
            );
        }

        $rate = $this->rateLimiter->consume(count($references), 'authorization');
        if (!$rate['allowed']) {
            throw new NativeSearchValidationException(
                $rate['reason'] === 'rate_limited'
                    ? 'native_search_remote_rate_limited'
                    : 'native_search_remote_context_unavailable',
                'definition.criteria'
            );
        }

        foreach ($references as $reference) {
            $authorized = $this->provider->authorizeSelectedId(
                $reference['itemtype'],
                $reference['field'],
                $reference['id']
            );
            if ($authorized !== true) {
                throw new NativeSearchValidationException(
                    $authorized === null
                        ? 'native_search_remote_field_unsupported'
                        : 'native_search_remote_value_not_authorized',
                    $reference['path']
                );
            }
        }
    }

    /**
     * @param array<int,mixed> $criteria
     * @param array<string,array{itemtype:string,field:int,id:int,path:string}> $references
     */
    private function collectCriteria(
        array $criteria,
        string $defaultItemtype,
        string $basePath,
        array &$references
    ): void {
        foreach ($criteria as $index => $criterion) {
            $path = $basePath . '.' . $index;
            if (!is_array($criterion)) {
                throw new NativeSearchValidationException(
                    'native_search_remote_criterion_invalid',
                    $path
                );
            }
            if (is_array($criterion['criteria'] ?? null)) {
                $this->collectCriteria(
                    array_values($criterion['criteria']),
                    $defaultItemtype,
                    $path . '.criteria',
                    $references
                );
                continue;
            }

            $declaredItemtype = is_string($criterion['itemtype'] ?? null)
                ? trim((string) $criterion['itemtype'])
                : '';
            $itemtype = $declaredItemtype !== ''
                ? $declaredItemtype
                : $defaultItemtype;
            $field = $criterion['field'] ?? null;
            if ($itemtype === 'Ticket' && in_array($field, ['all', 'view'], true)) {
                continue;
            }
            if (
                $itemtype === ''
                || (!is_int($field) && !(is_string($field) && ctype_digit($field)))
                || (int) $field < 1
            ) {
                throw new NativeSearchValidationException(
                    'native_search_remote_criterion_invalid',
                    $path
                );
            }
            $field = (int) $field;
            if (!$this->provider->isRemoteField($itemtype, $field)) {
                continue;
            }

            $operator = $criterion['searchtype'] ?? null;
            if (!is_string($operator)) {
                throw new NativeSearchValidationException(
                    'native_search_remote_operator_invalid',
                    $path . '.searchtype'
                );
            }
            try {
                $this->provider->assertOperator($itemtype, $field, $operator);
            } catch (\InvalidArgumentException) {
                throw new NativeSearchValidationException(
                    'native_search_remote_operator_not_authorized',
                    $path . '.searchtype'
                );
            }

            if (in_array($operator, ['empty', 'notempty'], true)) {
                if (($criterion['value'] ?? null) !== '') {
                    throw new NativeSearchValidationException(
                        'native_search_remote_value_invalid',
                        $path . '.value'
                    );
                }
                continue;
            }

            $id = $this->remoteId($criterion['value'] ?? null, $path . '.value');
            $key = hash('sha256', $itemtype . "\0" . $field . "\0" . $id);
            $references[$key] = [
                'itemtype' => $itemtype,
                'field' => $field,
                'id' => $id,
                'path' => $path . '.value',
            ];
        }
    }

    private function remoteId(mixed $value, string $path): int
    {
        if (
            (!is_int($value) && !is_string($value))
            || preg_match('/\A[1-9]\d*\z/D', (string) $value) !== 1
            || strlen((string) $value) > 10
        ) {
            throw new NativeSearchValidationException(
                'native_search_remote_value_invalid',
                $path
            );
        }

        $id = (int) $value;
        if ($id < 1) {
            throw new NativeSearchValidationException(
                'native_search_remote_value_invalid',
                $path
            );
        }

        return $id;
    }
}
