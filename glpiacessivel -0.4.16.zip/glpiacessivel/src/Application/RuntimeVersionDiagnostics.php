<?php

declare(strict_types=1);

namespace GlpiPlugin\Glpiacessivel\Application;

/**
 * Read-only diagnostics for safe, operator-driven upgrades.
 * It never downloads packages, writes files or controls PHP-FPM.
 */
final class RuntimeVersionDiagnostics
{
    public function __construct(private ?string $pluginRoot = null)
    {
        $this->pluginRoot ??= dirname(__DIR__, 2);
    }

    /** @return array<string, string|bool> */
    public function inspect(): array
    {
        $loaded = defined('PLUGIN_GLPIACESSIVEL_VERSION')
            ? (string) constant('PLUGIN_GLPIACESSIVEL_VERSION')
            : 'unknown';
        $disk = $this->readDiskVersion();
        $state = $disk === null ? 'marker_missing_or_invalid' : 'loaded_version_unknown';
        if ($disk !== null && $loaded !== 'unknown') {
            $comparison = version_compare($disk, $loaded);
            $state = $comparison > 0
                ? 'package_update_pending'
                : ($comparison < 0 ? 'package_rollback_pending' : 'current');
        }
        if (
            function_exists('plugin_glpiacessivel_runtime_is_stale')
            && plugin_glpiacessivel_runtime_is_stale()
        ) {
            $state = 'runtime_stale';
        }

        $opcacheEnabled = filter_var(ini_get('opcache.enable'), FILTER_VALIDATE_BOOLEAN);
        if (function_exists('opcache_get_status')) {
            try {
                $status = @opcache_get_status(false);
                if (is_array($status) && array_key_exists('opcache_enabled', $status)) {
                    $opcacheEnabled = !empty($status['opcache_enabled']);
                }
            } catch (\Throwable $e) {
                // The INI value remains the least-privileged fallback.
            }
        }

        return [
            'loaded_version' => $loaded,
            'disk_version' => $disk ?? 'unknown',
            'state' => $state,
            'runtime_epoch_consistent' => function_exists('plugin_glpiacessivel_runtime_epoch_is_consistent')
                ? plugin_glpiacessivel_runtime_epoch_is_consistent()
                : false,
            'opcache_enabled' => $opcacheEnabled,
            'opcache_validate_timestamps' => filter_var(
                ini_get('opcache.validate_timestamps'),
                FILTER_VALIDATE_BOOLEAN
            ),
            'opcache_invalidate_available' => function_exists('opcache_invalidate'),
            'preload_enabled' => trim((string) ini_get('opcache.preload')) !== '',
            'update_channel' => 'glpi_marketplace',
        ];
    }

    private function readDiskVersion(): ?string
    {
        $root = realpath((string) $this->pluginRoot);
        if (!is_string($root) || $root === '') {
            return null;
        }
        $path = $root . DIRECTORY_SEPARATOR . 'VERSION';
        if (!is_file($path) || !is_readable($path)) {
            return null;
        }
        $size = @filesize($path);
        if (!is_int($size) || $size < 1 || $size > 128) {
            return null;
        }
        $contents = @file_get_contents($path, false, null, 0, 129);
        if (!is_string($contents) || $contents === '' || strlen($contents) > 128 || str_contains($contents, "\0")) {
            return null;
        }
        $version = trim($contents);
        return preg_match('/\A[0-9]+(?:\.[0-9]+){1,3}(?:[-+][0-9A-Za-z.-]+)?\z/D', $version) === 1
            ? $version
            : null;
    }
}
