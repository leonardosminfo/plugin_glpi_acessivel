<?php

declare(strict_types=1);

namespace GlpiPlugin\Glpiacessivel\Application;

use GlpiPlugin\Glpiacessivel\Domain\Ticket\NativeSearchDefinitionValidator;
use GlpiPlugin\Glpiacessivel\Domain\Ticket\NativeSearchValidationException;
use GlpiPlugin\Glpiacessivel\Support\TicketStatusLabels;

/**
 * Translates the accessible form contract into the canonical native AST.
 *
 * This translator is intentionally strict and does not sanitize by omission.
 * Native field/operator authorization remains the responsibility of
 * NativeSearchDefinitionValidator with a server-built GLPI context.
 */
final class AdvancedTicketSearchRequest
{
    /** @var string[] */
    private const KEYS = [
        'action',
        'criteria',
        'global_rules',
        'sorts',
        'deleted_scope',
        'page_size',
        'columns',
        'focus',
        'context_revision',
        'text',
        'scope',
        'status',
        'group_id',
        'group_by',
    ];

    /**
     * @param array<string,mixed> $advanced
     * @return array{
     *     definition:array<string,mixed>,
     *     page_size:int,
     *     focus_results:bool,
     *     context_revision:string,
     *     frequent_filters:array{status:string,group_id:int},
     *     presentation:array{group_by:string}
     * }
     */
    public function translate(array $advanced): array
    {
        $this->assertExactKeys($advanced, self::KEYS, 'advanced');
        if (($advanced['action'] ?? null) !== 'search') {
            $this->fail('native_search_action_unsupported', 'advanced.action');
        }
        $contextRevision = $advanced['context_revision'] ?? null;
        if (
            !is_string($contextRevision)
            || preg_match('/\A[a-f0-9]{64}\z/D', $contextRevision) !== 1
        ) {
            $this->fail('native_search_context_stale', 'advanced.context_revision');
        }
        $criteria = $this->optionalList(
            $advanced,
            'criteria',
            'advanced.criteria',
            'native_search_criteria_invalid'
        );

        $metacriteria = $this->optionalList(
            $advanced,
            'global_rules',
            'advanced.global_rules'
        );
        foreach ($metacriteria as $index => $criterion) {
            if (!is_array($criterion)) {
                $this->fail('native_search_meta_criterion_invalid', 'advanced.global_rules.' . $index);
            }
            $this->assertExactKeys(
                $criterion,
                ['link', 'itemtype', 'field', 'searchtype', 'value'],
                'advanced.global_rules.' . $index
            );
        }

        $sortRows = $this->optionalList($advanced, 'sorts', 'advanced.sorts');
        $sort = [];
        $order = [];
        foreach ($sortRows as $index => $row) {
            $path = 'advanced.sorts.' . $index;
            if (!is_array($row)) {
                $this->fail('native_search_sort_invalid', $path);
            }
            $this->assertExactKeys($row, ['field', 'direction'], $path);
            if (!array_key_exists('field', $row) || !array_key_exists('direction', $row)) {
                $this->fail('native_search_sort_invalid', $path);
            }
            $sort[] = $row['field'];
            $order[] = $row['direction'];
        }

        $deletedScope = (string) ($advanced['deleted_scope'] ?? 'active');
        if (!in_array($deletedScope, ['active', 'deleted'], true)) {
            $this->fail('native_search_deleted_scope_unsupported', 'advanced.deleted_scope');
        }

        $pageSize = $advanced['page_size'] ?? 20;
        if (
            (!is_int($pageSize) && !(is_string($pageSize) && ctype_digit($pageSize)))
            || !in_array((int) $pageSize, [10, 20, 50, 100], true)
        ) {
            $this->fail('native_search_page_size_unsupported', 'advanced.page_size');
        }

        $columns = $this->optionalList($advanced, 'columns', 'advanced.columns');
        foreach ($columns as $index => $column) {
            if (!is_string($column) && !is_int($column)) {
                $this->fail('native_search_columns_invalid', 'advanced.columns.' . $index);
            }
        }

        $focus = (string) ($advanced['focus'] ?? '');
        if (!in_array($focus, ['', 'results'], true)) {
            $this->fail('native_search_focus_unsupported', 'advanced.focus');
        }

        $text = $advanced['text'] ?? '';
        $validUtf8 = is_string($text) && (
            function_exists('mb_check_encoding')
                ? mb_check_encoding($text, 'UTF-8')
                : preg_match('//u', $text) === 1
        );
        if (
            !$validUtf8
            || mb_strlen((string) $text, 'UTF-8') > 120
            || preg_match('/[\x00-\x1F\x7F]/u', (string) $text) === 1
        ) {
            $this->fail('native_search_text_invalid', 'advanced.text');
        }
        $text = trim((string) $text);

        $scope = $advanced['scope'] ?? 'all';
        if (!is_string($scope) || !in_array($scope, ['all', 'mine', 'group'], true)) {
            $this->fail('native_search_scope_unsupported', 'advanced.scope');
        }

        $status = $advanced['status'] ?? '';
        if (
            !is_string($status)
            || (
                $status !== ''
                && (
                    preg_match('/\A[1-9]\d*\z/D', $status) !== 1
                    || !array_key_exists((int) $status, TicketStatusLabels::all())
                )
            )
        ) {
            $this->fail('native_search_status_unsupported', 'advanced.status');
        }

        $groupId = $advanced['group_id'] ?? '0';
        if (
            !is_string($groupId)
            || preg_match('/\A(?:0|[1-9]\d{0,9})\z/D', $groupId) !== 1
        ) {
            $this->fail('native_search_group_unsupported', 'advanced.group_id');
        }

        $groupBy = $advanced['group_by'] ?? 'none';
        if (!is_string($groupBy) || !in_array($groupBy, ['none', 'group'], true)) {
            $this->fail('native_search_grouping_unsupported', 'advanced.group_by');
        }

        $definition = [
            'version' => NativeSearchDefinitionValidator::VERSION,
            'itemtype' => 'Ticket',
            'text' => $text,
            'scope' => $scope,
            'criteria' => $criteria,
            'metacriteria' => $metacriteria,
            'sort' => $sort,
            'order' => $order,
            'is_deleted' => $deletedScope === 'deleted' ? 1 : 0,
            'columns' => $columns,
        ];

        return [
            'definition' => $definition,
            'page_size' => (int) $pageSize,
            'focus_results' => $focus === 'results',
            'context_revision' => $contextRevision,
            'frequent_filters' => [
                'status' => $status,
                'group_id' => (int) $groupId,
            ],
            'presentation' => [
                'group_by' => $groupBy,
            ],
        ];
    }

    /**
     * @param mixed $value
     * @return array<int,mixed>
     */
    private function listOrEmpty($value, string $path): array
    {
        if (!is_array($value) || !array_is_list($value)) {
            $this->fail('native_search_parameter_unsupported', $path);
        }
        return $value;
    }

    /**
     * Browsers omit list-valued controls when the form contains no rows. Only
     * genuine absence is normalized; an explicitly submitted malformed value
     * remains a fail-closed request.
     *
     * @param array<string,mixed> $input
     * @return array<int,mixed>
     */
    private function optionalList(
        array $input,
        string $key,
        string $path,
        string $reason = 'native_search_parameter_unsupported'
    ): array {
        if (!array_key_exists($key, $input)) {
            return [];
        }
        $value = $input[$key];
        if (!is_array($value) || !array_is_list($value)) {
            $this->fail($reason, $path);
        }
        return $value;
    }

    /**
     * @param array<mixed,mixed> $value
     * @param string[] $allowed
     */
    private function assertExactKeys(array $value, array $allowed, string $path): void
    {
        foreach (array_keys($value) as $key) {
            if (!is_string($key) || !in_array($key, $allowed, true)) {
                $this->fail('native_search_parameter_unsupported', $path);
            }
        }
    }

    private function fail(string $reasonCode, string $path): never
    {
        throw new NativeSearchValidationException($reasonCode, $path);
    }
}
