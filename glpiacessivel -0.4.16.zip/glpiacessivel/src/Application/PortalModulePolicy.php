<?php

declare(strict_types=1);

namespace GlpiPlugin\Glpiacessivel\Application;

final class PortalModulePolicy
{
    public function __construct(private ConfigService $config)
    {
    }

    public function getConfiguredState(string $module): string
    {
        return $this->config->getPortalModuleState($module);
    }

    public function getEffectiveState(string $module): string
    {
        $state = $this->getConfiguredState($module);
        if ($module !== ConfigService::MODULE_COCKPIT) {
            return $state;
        }

        $ticketsState = $this->getConfiguredState(ConfigService::MODULE_TICKETS);
        if ($ticketsState === ConfigService::MODULE_STATE_DISABLED) {
            return ConfigService::MODULE_STATE_DISABLED;
        }

        if (
            $ticketsState === ConfigService::MODULE_STATE_HIDDEN
            && $state === ConfigService::MODULE_STATE_AVAILABLE
        ) {
            return ConfigService::MODULE_STATE_HIDDEN;
        }

        return $state;
    }

    public function isEnabled(string $module): bool
    {
        return $this->getEffectiveState($module) !== ConfigService::MODULE_STATE_DISABLED;
    }

    public function isVisible(string $module): bool
    {
        return $this->getEffectiveState($module) === ConfigService::MODULE_STATE_AVAILABLE;
    }

    /** @return array<string, string> */
    public function getEffectiveStates(): array
    {
        $states = [];
        foreach (ConfigService::PORTAL_MODULES as $module) {
            $states[$module] = $this->getEffectiveState($module);
        }

        return $states;
    }

    public function requiredModuleForIntent(string $intent): ?string
    {
        if ($intent === 'ticket_criar_guiado') {
            return ConfigService::MODULE_TICKET_CREATE;
        }

        if ($intent === 'kb_recomendar_contextual') {
            return ConfigService::MODULE_KNOWLEDGE;
        }

        if (
            $intent === 'mine_tickets'
            || $intent === 'comunicacao_usuario'
            || str_starts_with($intent, 'ticket_')
        ) {
            return ConfigService::MODULE_TICKETS;
        }

        return null;
    }

    public function isIntentEnabled(string $intent): bool
    {
        $module = $this->requiredModuleForIntent($intent);
        return $module === null || $this->isEnabled($module);
    }
}
