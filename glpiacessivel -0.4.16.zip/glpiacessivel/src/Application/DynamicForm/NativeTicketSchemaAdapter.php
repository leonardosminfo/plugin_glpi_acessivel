<?php

declare(strict_types=1);

namespace GlpiPlugin\Glpiacessivel\Application\DynamicForm;

use GlpiPlugin\Glpiacessivel\Domain\DynamicForm\DynamicFormAdapterInterface;
use GlpiPlugin\Glpiacessivel\Domain\DynamicForm\DynamicFormField;
use GlpiPlugin\Glpiacessivel\Domain\DynamicForm\DynamicFormSchema;
use GlpiPlugin\Glpiacessivel\Domain\DynamicForm\DynamicFormSection;
use GlpiPlugin\Glpiacessivel\Domain\DynamicForm\DynamicFormSubmissionResult;
use GlpiPlugin\Glpiacessivel\Support\I18n;
use GlpiPlugin\Glpiacessivel\Support\Url;

class NativeTicketSchemaAdapter implements DynamicFormAdapterInterface
{
    public const SOURCE = 'native_ticket';
    private const SCHEMA_VERSION = '1.1';

    public function source(): string
    {
        return self::SOURCE;
    }

    /**
     * @param array<string, mixed> $context
     */
    public function supports(array $context): bool
    {
        return true;
    }

    /**
     * @param array<string, mixed> $context
     */
    public function getSchema(array $context): DynamicFormSchema
    {
        $requirements = is_array($context['field_requirements'] ?? null) ? $context['field_requirements'] : [];
        $fields = [
            $this->field('name', 'name', 'text', I18n::translate('Título'), 'main', $requirements, true, false, false, [], ['maxlength' => 255]),
            $this->field('content', 'content', 'textarea', I18n::translate('Descrição'), 'main', $requirements, true, false, false, [], ['maxlength' => 16000]),
            $this->field('filename', '_filename', 'file', I18n::translate('Anexos'), 'main', $requirements, false, false, true, [], ['glpi_document_item_required' => true]),
            $this->field('type', 'type', 'select', I18n::translate('Tipo'), 'properties', $requirements, true, false, false, $this->options($context['type_options'] ?? [])),
            $this->field('itilcategories_id', 'itilcategories_id', 'select', I18n::translate('Categoria'), 'properties', $requirements, false, false, false, $this->options($context['categories'] ?? [])),
            $this->field('tickettemplates_id', 'tickettemplates_id', 'select', I18n::translate('Modelo de chamado'), 'properties', $requirements, false, false, false, $this->options($context['ticket_templates'] ?? []), [], 'ticket_template'),
            $this->field('locations_id', 'locations_id', 'select', I18n::translate('Localização'), 'properties', $requirements, false, false, false, $this->options($context['locations'] ?? [])),
            $this->field('requesttypes_id', 'requesttypes_id', 'select', I18n::translate('Origem da requisição'), 'properties', $requirements, false, false, false, $this->options($context['request_source_options'] ?? [])),
            $this->field('externalid', 'externalid', 'text', I18n::translate('ID externo'), 'properties', $requirements, false, false, false, [], ['maxlength' => 255]),
            $this->field('urgency', 'urgency', 'select', I18n::translate('Urgência'), 'priority', $requirements, false, false, false, $this->options($context['urgency_options'] ?? [])),
            $this->field('impact', 'impact', 'select', I18n::translate('Impacto'), 'priority', $requirements, false, false, false, $this->options($context['impact_options'] ?? [])),
            $this->field('groups_assign', '_groups_id_assign', 'multiselect', I18n::translate('Grupo técnico'), 'routing', $requirements, false, false, true, $this->options($context['assignable_groups'] ?? [])),
            $this->field('groups_observer', '_groups_id_observer', 'multiselect', I18n::translate('Grupo observador'), 'routing', $requirements, false, false, true, $this->options($context['observer_groups'] ?? [])),
            $this->field('users_assign', '_users_id_assign', 'multiselect', I18n::translate('Técnico atribuído'), 'routing', $requirements, false, false, true, $this->options($context['assignable_users'] ?? [])),
            $this->field('users_observer', '_users_id_observer', 'multiselect', I18n::translate('Observador'), 'routing', $requirements, false, false, true, $this->options($context['observer_users'] ?? [])),
        ];

        $fallbackReasons = [];
        if (!empty($context['requires_native_fallback'])) {
            $fallbackReasons = array_values(array_filter(array_map('strval', (array) ($context['native_fallback_reasons'] ?? []))));
        }
        $advisoryReasons = array_values(array_filter(array_map('strval', (array) ($context['portal_limitations'] ?? []))));
        if (!empty($context['service_catalog']['available'])) {
            $advisoryReasons[] = (string) ($context['service_catalog']['message'] ?? I18n::translate('Alguns formulários do Catálogo de Serviços do GLPI 11 precisam ser concluídos em página completa.'));
        }

        return new DynamicFormSchema(
            $this->schemaId($context),
            self::SOURCE,
            self::SCHEMA_VERSION,
            I18n::translate('Abertura de chamado'),
            [
                new DynamicFormSection('main', I18n::translate('Chamado'), 10, I18n::translate('Dados principais da solicitação.')),
                new DynamicFormSection('properties', I18n::translate('Propriedades'), 20, I18n::translate('Dados do chamado e contexto operacional.')),
                new DynamicFormSection('priority', I18n::translate('Prioridade'), 30, I18n::translate('Urgência, impacto e pré-visualização.')),
                new DynamicFormSection('routing', I18n::translate('Atores e encaminhamento'), 40, I18n::translate('Participantes e grupos permitidos pelo GLPI.')),
            ],
            $fields,
            [],
            $this->capabilities(),
            [
                'required' => $fallbackReasons !== [],
                'reasons' => $fallbackReasons,
                'advisory_reasons' => $advisoryReasons,
                'native_url' => $this->nativeUrl(),
            ],
            [
                'entity_id' => (int) ($context['entity_id'] ?? 0),
                'entity_name' => (string) ($context['entity_name'] ?? ''),
                'requester_name' => (string) ($context['requester_name'] ?? ''),
                'glpi_version' => defined('GLPI_VERSION') ? (string) GLPI_VERSION : 'unknown',
            ]
        );
    }

    /**
     * @param array<string, mixed> $answers
     * @return array<int, array{field:string, code:string, message:string}>
     */
    public function validate(array $answers, DynamicFormSchema $schema): array
    {
        $errors = [];
        foreach ($schema->fields() as $field) {
            if (!$field->isVisible() || $field->isDisabled()) {
                continue;
            }
            $name = $field->nativeField();
            $value = $answers[$name] ?? null;

            if ($field->isRequired() && !$field->isReadonly() && !$this->hasValue($value)) {
                $errors[] = $this->error(
                    $name,
                    'required',
                    sprintf(I18n::translate('Informe %s.'), mb_strtolower($field->label(), 'UTF-8'))
                );
                continue;
            }

            if (!$this->hasValue($value) || $field->isReadonly()) {
                continue;
            }

            $constraints = $field->constraints();
            if (isset($constraints['maxlength']) && is_scalar($value) && mb_strlen((string) $value, 'UTF-8') > (int) $constraints['maxlength']) {
                $errors[] = $this->error(
                    $name,
                    'maxlength',
                    sprintf(
                        I18n::translate('%1$s deve ter no máximo %2$d caracteres.'),
                        $field->label(),
                        (int) $constraints['maxlength']
                    )
                );
            }

            if ($field->hasAllowedOptions()) {
                $allowed = array_fill_keys($field->allowedOptionIds(), true);
                $values = $field->isMultiple() ? (array) $value : [$value];
                foreach ($values as $item) {
                    $item = (string) $item;
                    if ($item === '' || $item === '0') {
                        continue;
                    }
                    if (!isset($allowed[$item])) {
                        $errors[] = $this->error(
                            $name,
                            'invalid_option',
                            sprintf(I18n::translate('%s inválido para o contexto atual.'), $field->label())
                        );
                        break;
                    }
                }
            }
        }

        return $errors;
    }

    /**
     * @param array<string, mixed> $answers
     */
    public function submit(array $answers, DynamicFormSchema $schema): DynamicFormSubmissionResult
    {
        return new DynamicFormSubmissionResult(false, [], '', [[
            'field' => '',
            'code' => 'adapter_submit_not_enabled',
            'message' => I18n::translate('A submissão dinâmica ainda não está habilitada para este adaptador.'),
        ]]);
    }

    public function nativeUrl(): string
    {
        return Url::core('/front/ticket.form.php');
    }

    /**
     * @return array<string, mixed>
     */
    public function capabilities(): array
    {
        return [
            'source_of_truth' => 'glpi_core',
            'server_side_schema_reload_required' => true,
            'submits_via_native_engine' => true,
            'supports_ticket_template_projection' => false,
            'supports_formcreator_submission' => false,
            'supports_service_catalog_submission' => false,
            'supports_document_item_validation' => true,
        ];
    }

    /**
     * @param array<string, mixed> $requirements
     * @param array<int, array<string, mixed>> $options
     * @param array<string, mixed> $constraints
     */
    protected function field(
        string $id,
        string $name,
        string $type,
        string $label,
        string $section,
        array $requirements,
        bool $requiredByDefault = false,
        bool $readonlyByDefault = false,
        bool $multiple = false,
        array $options = [],
        array $constraints = [],
        string $source = self::SOURCE
    ): DynamicFormField {
        $metadata = is_array($requirements[$name] ?? null) ? $requirements[$name] : [];
        if ($metadata === [] && $id !== $name && is_array($requirements[$id] ?? null)) {
            $metadata = $requirements[$id];
        }

        return new DynamicFormField(
            $id,
            $name,
            $type,
            (string) ($metadata['label'] ?? $label),
            $section,
            !empty($metadata['required']) || $requiredByDefault,
            array_key_exists('visible', $metadata) ? !empty($metadata['visible']) : true,
            !empty($metadata['readonly']) || $readonlyByDefault,
            !empty($metadata['disabled']),
            $multiple,
            $metadata['default'] ?? null,
            $options,
            $constraints,
            $source,
            $name,
            (string) ($metadata['description'] ?? ''),
            $metadata
        );
    }

    /**
     * @param mixed $rows
     * @return array<int, array{id:int|string, label:string, metadata:array<string, mixed>}>
     */
    protected function options(mixed $rows): array
    {
        if (!is_array($rows)) {
            return [];
        }

        $options = [];
        foreach ($rows as $row) {
            if (!is_array($row)) {
                continue;
            }
            $id = $row['id'] ?? null;
            if ($id === null || $id === '') {
                continue;
            }
            $label = (string) ($row['label'] ?? $row['name'] ?? ('#' . $id));
            $metadata = $row;
            unset($metadata['id'], $metadata['label'], $metadata['name']);
            $options[] = [
                'id' => is_numeric($id) ? (int) $id : (string) $id,
                'label' => $label,
                'metadata' => $metadata,
            ];
        }

        return $options;
    }

    /**
     * @param array<string, mixed> $context
     */
    protected function schemaId(array $context): string
    {
        $parts = [
            $this->source(),
            (string) ($context['entity_id'] ?? 0),
            (string) ($context['selected_ticket_template']['id'] ?? 0),
            defined('GLPI_VERSION') ? (string) GLPI_VERSION : 'unknown',
            defined('PLUGIN_GLPIACESSIVEL_VERSION') ? (string) PLUGIN_GLPIACESSIVEL_VERSION : 'dev',
        ];

        return hash('sha256', implode('|', $parts));
    }

    /**
     * @return array{field:string, code:string, message:string}
     */
    protected function error(string $field, string $code, string $message): array
    {
        return [
            'field' => $field,
            'code' => $code,
            'message' => $message,
        ];
    }

    private function hasValue(mixed $value): bool
    {
        if (is_array($value)) {
            return array_values(array_filter($value, static fn($item): bool => trim((string) $item) !== '' && trim((string) $item) !== '0')) !== [];
        }

        return trim((string) $value) !== '' && trim((string) $value) !== '0';
    }
}
