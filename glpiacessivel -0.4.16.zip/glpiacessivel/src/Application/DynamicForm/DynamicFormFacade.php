<?php

declare(strict_types=1);

namespace GlpiPlugin\Glpiacessivel\Application\DynamicForm;

use GlpiPlugin\Glpiacessivel\Domain\DynamicForm\DynamicFormAdapterInterface;
use GlpiPlugin\Glpiacessivel\Domain\DynamicForm\DynamicFormSchema;
use GlpiPlugin\Glpiacessivel\Domain\DynamicForm\DynamicFormSubmissionResult;
use GlpiPlugin\Glpiacessivel\Support\I18n;

final class DynamicFormFacade
{
    /** @var array<string, DynamicFormAdapterInterface> */
    private array $adapters = [];

    private FormSubmissionGate $submissionGate;

    /**
     * @param DynamicFormAdapterInterface[]|null $adapters
     */
    public function __construct(?array $adapters = null, ?FormSubmissionGate $submissionGate = null)
    {
        if ($adapters === null) {
            $adapters = [
                new NativeTicketSchemaAdapter(),
                new TicketTemplateSchemaAdapter(),
                new ServiceCatalogSchemaAdapter(),
                new FormcreatorSchemaAdapter(),
            ];
        }

        foreach ($adapters as $adapter) {
            $this->adapters[$adapter->source()] = $adapter;
        }

        $this->submissionGate = $submissionGate ?? new FormSubmissionGate();
    }

    /** @param array<string, mixed> $context */
    public function ticketCreationSchema(array $context): DynamicFormSchema
    {
        $adapter = $this->resolveTicketCreationAdapter($context);
        return $adapter->getSchema($context);
    }

    /** @param array<string, mixed> $context */
    public function formSchema(string $source, array $context): DynamicFormSchema
    {
        $context['source'] = $source;
        return $this->adapter($source)->getSchema($context);
    }

    /**
     * @param array<string, mixed> $context
     * @param array<string, mixed> $answers
     */
    public function submitForm(string $source, array $context, array $answers): DynamicFormSubmissionResult
    {
        $schema = $this->formSchema($source, $context);
        if (!$this->submissionGate->inspect($schema)['allowed']) {
            return $this->submissionGate->reject($schema);
        }

        return $this->adapter($source)->submit($answers, $schema);
    }

    /**
     * @param array<string, mixed> $context
     * @param array<string, mixed> $answers
     * @return array<int, array{field:string, code:string, message:string}>
     */
    public function validateTicketCreation(array $context, array $answers): array
    {
        $schema = $this->ticketCreationSchema($context);
        if ($schema->requiresNativeFallback()) {
            $schemaArray = $schema->toArray();
            $reasons = array_values(array_filter(array_map('strval', (array) ($schemaArray['fallback']['reasons'] ?? []))));
            return [[
                'field' => 'tickettemplates_id',
                'code' => 'native_fallback_required',
                'message' => $reasons[0] ?? I18n::translate(
                    'Este formulário exige recursos ainda não disponíveis nesta página. Abra-o em página completa.'
                ),
            ]];
        }

        return $this->adapter($schema->source())->validate($answers, $schema);
    }

    /** @param array<string, mixed> $context */
    public function resolveTicketCreationAdapter(array $context): DynamicFormAdapterInterface
    {
        if (
            isset($this->adapters[TicketTemplateSchemaAdapter::SOURCE])
            && $this->adapters[TicketTemplateSchemaAdapter::SOURCE]->supports($context)
        ) {
            return $this->adapters[TicketTemplateSchemaAdapter::SOURCE];
        }

        return $this->adapter(NativeTicketSchemaAdapter::SOURCE);
    }

    public function adapter(string $source): DynamicFormAdapterInterface
    {
        if (!isset($this->adapters[$source])) {
            throw new \RuntimeException(I18n::translate('Adaptador de formulário dinâmico indisponível: ') . $source);
        }

        return $this->adapters[$source];
    }
}
