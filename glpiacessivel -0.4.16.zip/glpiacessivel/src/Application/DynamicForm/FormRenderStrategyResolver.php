<?php

declare(strict_types=1);

namespace GlpiPlugin\Glpiacessivel\Application\DynamicForm;

use GlpiPlugin\Glpiacessivel\Application\ConfigService;

/**
 * Chooses presentation only after FormService has resolved and authorized the form.
 * This class is deliberately side-effect free: it is never an authorization boundary.
 */
final class FormRenderStrategyResolver
{
    public const ACCESSIBLE_NATIVE_DELEGATED = 'accessible_native_delegated';
    public const NATIVE_IFRAME = 'native_iframe';
    public const NATIVE_LINK = 'native_link';

    /**
     * @param array<string, mixed> $formView
     * @return array{strategy:string,source:string,form_id:int,blockers:array<string,string>}
     */
    public function resolve(array $formView, string $configuredMode): array
    {
        $form = is_array($formView['form'] ?? null) ? $formView['form'] : [];
        $schema = is_array($formView['schema'] ?? null) ? $formView['schema'] : [];
        $metadata = is_array($schema['metadata'] ?? null) ? $schema['metadata'] : [];
        $capabilities = is_array($schema['capabilities'] ?? null) ? $schema['capabilities'] : [];
        $readiness = is_array($capabilities['own_submission_readiness'] ?? null)
            ? $capabilities['own_submission_readiness']
            : [];
        $submitContract = is_array($capabilities['native_submit_contract'] ?? null)
            ? $capabilities['native_submit_contract']
            : [];
        $blockers = is_array($readiness['blockers'] ?? null) ? $readiness['blockers'] : [];
        $source = (string) ($form['source'] ?? '');
        $formId = (int) ($metadata['form_id'] ?? $submitContract['form_id'] ?? $form['id'] ?? 0);
        $nativeUrl = trim((string) ($form['native_url'] ?? ''));
        $supportedSource = in_array($source, ['glpi11_service_catalog', 'formcreator_glpi10'], true);

        if (
            $configuredMode === ConfigService::FORMS_NATIVE_FLOW_PLUGIN_CONVERTED_CALLBACK
            && !empty($submitContract['enabled'])
            && !empty($readiness['ready'])
            && $supportedSource
            && $formId > 0
        ) {
            return $this->decision(self::ACCESSIBLE_NATIVE_DELEGATED, $source, $formId, []);
        }

        if (
            $configuredMode !== ConfigService::FORMS_NATIVE_FLOW_LINK
            && $supportedSource
            && $formId > 0
            && $nativeUrl !== ''
        ) {
            return $this->decision(self::NATIVE_IFRAME, $source, $formId, $blockers);
        }

        return $this->decision(self::NATIVE_LINK, $source, $formId, $blockers);
    }

    /**
     * @param array<string, string> $blockers
     * @return array{strategy:string,source:string,form_id:int,blockers:array<string,string>}
     */
    private function decision(string $strategy, string $source, int $formId, array $blockers): array
    {
        return [
            'strategy' => $strategy,
            'source' => $source,
            'form_id' => $formId,
            'blockers' => $blockers,
        ];
    }
}
