<?php

declare(strict_types=1);

namespace GlpiPlugin\Glpiacessivel\Application\DynamicForm;

use GlpiPlugin\Glpiacessivel\Domain\DynamicForm\DynamicFormAdapterInterface;
use GlpiPlugin\Glpiacessivel\Domain\DynamicForm\DynamicFormCondition;
use GlpiPlugin\Glpiacessivel\Domain\DynamicForm\DynamicFormField;
use GlpiPlugin\Glpiacessivel\Domain\DynamicForm\DynamicFormSchema;
use GlpiPlugin\Glpiacessivel\Domain\DynamicForm\DynamicFormSection;
use GlpiPlugin\Glpiacessivel\Domain\DynamicForm\DynamicFormSubmissionResult;
use GlpiPlugin\Glpiacessivel\Domain\DynamicForm\FormCapability;
use GlpiPlugin\Glpiacessivel\Support\I18n;

final class ServiceCatalogSchemaAdapter implements DynamicFormAdapterInterface
{
    public const SOURCE = 'glpi11_service_catalog';

    public function source(): string
    {
        return self::SOURCE;
    }

    /** @param array<string, mixed> $context */
    public function supports(array $context): bool
    {
        return (string) ($context['source'] ?? $context['form']['source'] ?? '') === self::SOURCE;
    }

    /** @param array<string, mixed> $context */
    public function getSchema(array $context): DynamicFormSchema
    {
        $form = is_array($context['form'] ?? null) ? $context['form'] : [];
        $id = (int) ($form['id'] ?? $context['id'] ?? 0);
        $title = (string) ($form['name'] ?? sprintf(I18n::translate('Formulário #%d'), $id));
        $nativeUrl = (string) ($form['native_url'] ?? '');
        $detectedApis = $this->detectedApis();
        if (is_array($context['detected_apis'] ?? null)) {
            $detectedApis = array_merge($detectedApis, $context['detected_apis']);
        }
        $projected = $this->projectNativeSchema($id, $form);
        $sections = $projected['sections'];
        $fields = $projected['fields'];
        $conditions = $projected['conditions'];
        $unsupported = $projected['unsupported'];
        $hasProjectedFields = count($fields) > 1;
        $submissionReadiness = $this->ownSubmissionReadiness($id, $fields, $conditions, $unsupported, $detectedApis);
        $canSubmitThroughNativeContract = !empty($submissionReadiness['ready']);
        $compatibilityMatrix = $this->compatibilityMatrix($detectedApis, $projected);
        $capabilityContract = FormCapability::fromReadiness(
            self::SOURCE,
            $submissionReadiness,
            $compatibilityMatrix,
            $canSubmitThroughNativeContract
        );

        return new DynamicFormSchema(
            'glpi11_service_catalog:' . $id,
            self::SOURCE,
            '1.2',
            $title,
            $sections,
            $fields,
            $conditions,
            [
                'source_of_truth' => 'glpi11_service_catalog',
                'renders_own_fields' => $hasProjectedFields,
                'submits_via_native_engine' => true,
                'supports_service_catalog_submission' => $canSubmitThroughNativeContract,
                'supports_formcreator_submission' => false,
                'supports_document_item_validation' => false,
                'detected_apis' => $detectedApis,
                'compatibility_matrix' => $compatibilityMatrix,
                'own_submission_readiness' => $submissionReadiness,
                'capability_contract' => $capabilityContract->toArray(),
                'native_submit_contract' => [
                    'enabled' => $canSubmitThroughNativeContract,
                    'form_id' => $id,
                    'submit_endpoint' => '/Form/SubmitAnswers',
                    'validate_endpoint' => '/Form/ValidateAnswers',
                    'condition_endpoint' => '/Form/Condition/Engine',
                    'input_name_pattern' => 'answers_{question_id}',
                    'engine' => 'glpi11_core',
                ],
                'projected_field_count' => count($fields),
                'native_assisted_field_count' => $this->nativeAssistedFieldCount($fields),
                'unsupported_field_count' => count($unsupported),
                'minimum_supported_field_types' => ['text', 'textarea', 'select', 'radio', 'checkbox', 'multiselect', 'date', 'datetime', 'number', 'email', 'file', 'hidden', 'native_reference'],
            ],
            [
                'required' => !$canSubmitThroughNativeContract,
                'reasons' => [
                    $canSubmitThroughNativeContract
                        ? I18n::translate('O portal pode validar e enviar este formulário pelo GLPI 11, preservando permissões, condições, validações e destinos do Catálogo de Serviços.')
                        : ($hasProjectedFields
                        ? I18n::translate('O formulário pode ser exibido para leitura e preenchimento acessível, mas o envio permanece no Catálogo de Serviços até a homologação de destinos, validações e anexos.')
                        : I18n::translate('O Catálogo de Serviços do GLPI 11 permanece em página completa até a homologação de campos, condições, destinos, anexos, validações e permissões.')),
                ],
                'advisory_reasons' => [
                    I18n::translate('O portal pode listar e abrir o item quando o Catálogo de Serviços confirma a visibilidade no contexto atual.'),
                    I18n::translate('O envio pelo GLPI 11 usa os serviços oficiais de validação e registro; se eles não estiverem disponíveis, a página completa permanece obrigatória.'),
                ],
                'native_url' => $nativeUrl,
            ],
            [
                'form_id' => $id,
                'source_label' => (string) ($form['source_label'] ?? 'Service Catalog GLPI 11'),
                'entity_id' => (int) ($form['entity_id'] ?? 0),
                'is_recursive' => !empty($form['is_recursive']),
                'native_url' => $nativeUrl,
                'compatibility_status' => $canSubmitThroughNativeContract ? 'native_delegated_submission_ready' : $this->compatibilityStatus($hasProjectedFields, $fields, $unsupported),
                'compatibility_matrix' => $compatibilityMatrix,
                'capability_contract' => $capabilityContract->toArray(),
                'unsupported_questions' => $unsupported,
            ]
        );
    }

    /**
     * @param array<string, mixed> $answers
     * @return array<int, array{field:string, code:string, message:string}>
     */
    public function validate(array $answers, DynamicFormSchema $schema): array
    {
        return [[
            'field' => '',
            'code' => 'native_fallback_required',
            'message' => I18n::translate('Este formulário deve ser concluído no Catálogo de Serviços do GLPI 11 nesta etapa.'),
        ]];
    }

    /** @param array<string, mixed> $answers */
    public function submit(array $answers, DynamicFormSchema $schema): DynamicFormSubmissionResult
    {
        return new DynamicFormSubmissionResult(false, [], '', $this->validate($answers, $schema));
    }

    public function nativeUrl(): string
    {
        return 'ServiceCatalog';
    }

    /** @return array<string, mixed> */
    public function capabilities(): array
    {
        $detectedApis = $this->detectedApis();

        return [
            'source_of_truth' => 'glpi11_service_catalog',
            'renders_own_fields' => false,
            'submits_via_native_engine' => true,
            'supports_service_catalog_submission' => false,
            'supports_formcreator_submission' => false,
            'supports_document_item_validation' => false,
            'detected_apis' => $detectedApis,
            'compatibility_matrix' => $this->compatibilityMatrix($detectedApis, ['fields' => [], 'unsupported' => []]),
            'own_submission_readiness' => $this->ownSubmissionReadiness(0, [], [], [], $detectedApis),
            'capability_contract' => FormCapability::fromReadiness(
                self::SOURCE,
                $this->ownSubmissionReadiness(0, [], [], [], $detectedApis),
                $this->compatibilityMatrix($detectedApis, ['fields' => [], 'unsupported' => []]),
                false
            )->toArray(),
            'minimum_supported_field_types' => ['text', 'textarea', 'select', 'radio', 'checkbox', 'multiselect', 'date', 'datetime', 'number', 'email', 'file', 'hidden', 'native_reference'],
        ];
    }

    /**
     * @param array<string, mixed> $form
     * @return array{sections:array<int, DynamicFormSection>, fields:array<int, DynamicFormField>, conditions:array<int, DynamicFormCondition>, unsupported:array<int, array<string, string>>}
     */
    private function projectNativeSchema(int $formId, array $form): array
    {
        $sections = [new DynamicFormSection(
            'metadata',
            I18n::translate('Identificação do item'),
            10,
            I18n::translate('Dados seguros para exibição no portal acessível.')
        )];
        $fields = [new DynamicFormField(
            'catalog_item_title',
            'catalog_item_title',
            'text',
            I18n::translate('Formulário do catálogo'),
            'metadata',
            false,
            true,
            true,
            true,
            false,
            (string) ($form['name'] ?? sprintf(I18n::translate('Formulário #%d'), $formId)),
            [],
            ['readonly_projection' => true],
            self::SOURCE,
            'catalog_item_title',
            I18n::translate('Título retornado pelo Catálogo de Serviços.'),
            ['projection_only' => true]
        )];
        $conditions = [];
        $unsupported = [];

        $rawSections = $this->rawSections($formId, $form);
        foreach ($rawSections as $index => $rawSection) {
            $sectionId = (string) ($rawSection['id'] ?? ('section_' . ($index + 1)));
            $sections[] = new DynamicFormSection(
                'section_' . $sectionId,
                trim((string) ($rawSection['name'] ?? I18n::translate('Seção') . ' ' . ($index + 1)))
                    ?: I18n::translate('Seção') . ' ' . ($index + 1),
                (int) ($rawSection['rank'] ?? (($index + 1) * 10)),
                trim((string) ($rawSection['description'] ?? ''))
            );

            $sectionConditions = $this->portableConditionsForTarget($rawSection, 'section_' . $sectionId, 'section', 'glpi11_section_condition_' . $sectionId);
            if ($sectionConditions !== []) {
                array_push($conditions, ...$sectionConditions);
            } elseif ($this->hasConditions($rawSection)) {
                $conditions[] = new DynamicFormCondition(
                    'section_conditions_' . $sectionId,
                    'section_' . $sectionId,
                    'native_fallback',
                    ['engine' => 'glpi11_service_catalog', 'reason' => 'section_conditions_not_projected', 'target_type' => 'section'],
                    false,
                    I18n::translate('Esta seção possui condições que exigem o Catálogo de Serviços até a homologação.')
                );
            }

            foreach ((array) ($rawSection['questions'] ?? []) as $questionIndex => $rawQuestion) {
                if (!is_array($rawQuestion)) {
                    continue;
                }
                $field = $this->fieldFromQuestion($rawQuestion, 'section_' . $sectionId, $questionIndex);
                if ($field === null) {
                    $unsupported[] = [
                        'id' => (string) ($rawQuestion['id'] ?? ''),
                        'label' => (string) ($rawQuestion['name'] ?? ''),
                        'type' => (string) ($rawQuestion['type'] ?? ''),
                    ];
                    continue;
                }
                $fields[] = $field;

                $portableConditions = $this->portableConditionsFromQuestion($rawQuestion, $field, 'glpi11_condition_' . (string) ($rawQuestion['id'] ?? $questionIndex));
                if ($portableConditions !== []) {
                    array_push($conditions, ...$portableConditions);
                } elseif ($this->hasConditions($rawQuestion)) {
                    $conditions[] = new DynamicFormCondition(
                        'question_conditions_' . (string) ($rawQuestion['id'] ?? $questionIndex),
                        $field->name(),
                        'native_fallback',
                        ['engine' => 'glpi11_service_catalog', 'reason' => 'question_conditions_not_projected'],
                        false,
                        I18n::translate('Esta pergunta possui condições que exigem o Catálogo de Serviços até a homologação.')
                    );
                }
            }
        }

        if ($conditions === []) {
            $conditions[] = new DynamicFormCondition(
                'glpi11_native_submit',
                '*',
                'native_fallback',
                ['engine' => 'glpi11_service_catalog', 'reason' => 'submit_not_homologated'],
                false,
                I18n::translate('A apresentação acessível pode exibir os campos compatíveis, mas o envio ainda usa o Catálogo de Serviços.')
            );
        }

        return ['sections' => $sections, 'fields' => $fields, 'conditions' => $conditions, 'unsupported' => $unsupported];
    }

    /**
     * @param array<string, mixed> $form
     * @return array<int, array<string, mixed>>
     */
    private function rawSections(int $formId, array $form): array
    {
        if (isset($form['sections']) && is_array($form['sections'])) {
            return array_values(array_filter($form['sections'], 'is_array'));
        }

        if ($formId <= 0 || !class_exists('\\Glpi\\Form\\Form')) {
            return [];
        }

        try {
            $nativeForm = new \Glpi\Form\Form();
            if (!$nativeForm->getFromDB($formId) || !method_exists($nativeForm, 'getSections')) {
                return [];
            }
            $sections = [];
            foreach ($nativeForm->getSections() as $section) {
                $questions = [];
                if (method_exists($section, 'getQuestions')) {
                    foreach ($section->getQuestions() as $question) {
                        $questions[] = $this->questionObjectToArray($question);
                    }
                }
                $sections[] = [
                    'id' => (int) ($section->fields['id'] ?? 0),
                    'name' => (string) ($section->fields['name'] ?? ''),
                    'description' => (string) ($section->fields['description'] ?? ''),
                    'rank' => (int) ($section->fields['rank'] ?? 0),
                    'conditions' => (string) ($section->fields['conditions'] ?? ''),
                    'questions' => $questions,
                ];
            }
            return $sections;
        } catch (\Throwable $e) {
            return [];
        }
    }

    /** @return array<string, mixed> */
    private function questionObjectToArray(object $question): array
    {
        $type = (string) ($question->fields['type'] ?? '');
        $typeName = $type;
        try {
            if (method_exists($question, 'getQuestionType') && ($questionType = $question->getQuestionType())) {
                $typeName = get_class($questionType);
            }
        } catch (\Throwable $e) {
            $typeName = $type;
        }

        return [
            'id' => (int) ($question->fields['id'] ?? 0),
            'uuid' => (string) ($question->fields['uuid'] ?? ''),
            'name' => (string) ($question->fields['name'] ?? ''),
            'description' => (string) ($question->fields['description'] ?? ''),
            'type' => $typeName,
            'default_value' => $this->decodeJsonish($question->fields['default_value'] ?? null),
            'extra_data' => $this->decodeJsonish($question->fields['extra_data'] ?? null),
            'required' => !empty($question->fields['is_mandatory']) || !empty($question->fields['required']) || $this->hasConditions(['validation_conditions' => $question->fields['validation_conditions'] ?? '']),
            'conditions' => (string) ($question->fields['conditions'] ?? ''),
            'validation_conditions' => (string) ($question->fields['validation_conditions'] ?? ''),
            'vertical_rank' => (int) ($question->fields['vertical_rank'] ?? 0),
            'horizontal_rank' => (int) ($question->fields['horizontal_rank'] ?? 0),
        ];
    }

    /** @param array<string, mixed> $question */
    private function fieldFromQuestion(array $question, string $sectionId, int $index): ?DynamicFormField
    {
        $nativeType = (string) ($question['type'] ?? '');
        $type = $this->mapQuestionType($nativeType);
        if ($type === '') {
            return null;
        }

        $id = (string) ($question['id'] ?? ($index + 1));
        $name = (string) ($question['uuid'] ?? '') !== '' ? (string) $question['uuid'] : 'question_' . $id;
        $label = trim((string) ($question['name'] ?? '')) ?: 'Pergunta ' . ($index + 1);
        $options = $this->questionOptions($question);
        $nativeAssisted = $type === 'native_reference';
        $multiple = $type === 'multiselect' || (!empty($question['multiple']));
        $description = trim((string) ($question['description'] ?? ''));
        if ($nativeAssisted) {
            $description = trim($description . ' ' . $this->nativeAssistedDescription());
        }

        return new DynamicFormField(
            'question_' . $id,
            $name,
            $type,
            $label,
            $sectionId,
            !empty($question['required']),
            true,
            $nativeAssisted,
            $nativeAssisted,
            $multiple,
            $question['default_value'] ?? null,
            $options,
            $this->constraintsForType($type),
            self::SOURCE,
            $name,
            $description,
            [
                'native_question_id' => $id,
                'native_input_name' => 'answers_' . $id,
                'native_question_type' => $nativeType,
                'render_only_until_native_submit' => true,
                'native_assisted' => $nativeAssisted,
            ]
        );
    }

    private function mapQuestionType(string $nativeType): string
    {
        $lower = strtolower($nativeType);
        return match (true) {
            str_contains($lower, 'shorttext') => 'text',
            str_contains($lower, 'longtext') => 'textarea',
            str_contains($lower, 'email') => 'email',
            str_contains($lower, 'number') => 'number',
            str_contains($lower, 'datetime') => 'datetime',
            str_contains($lower, 'date') => 'date',
            str_contains($lower, 'file') => 'file',
            str_contains($lower, 'radio') => 'radio',
            str_contains($lower, 'checkbox') => 'checkbox',
            str_contains($lower, 'dropdown') => 'select',
            str_contains($lower, 'urgency') => 'select',
            str_contains($lower, 'requesttype') => 'select',
            $this->isNativeReferenceQuestionType($lower) => 'native_reference',
            default => '',
        };
    }

    private function isNativeReferenceQuestionType(string $lowerNativeType): bool
    {
        foreach (['userdevice', 'observer', 'requester', 'assignee', 'itemdropdown', 'item', 'category'] as $token) {
            if (str_contains($lowerNativeType, $token)) {
                return true;
            }
        }

        return false;
    }

    private function nativeAssistedDescription(): string
    {
        return I18n::translate('Este campo depende de seletores, permissões ou opções do GLPI. Revise-o e conclua o formulário em página completa para preservar a entidade e as validações.');
    }

    /** @param array<string, mixed> $question @return array<int, array<string, mixed>> */
    private function questionOptions(array $question): array
    {
        $extra = is_array($question['extra_data'] ?? null) ? $question['extra_data'] : [];
        $rawOptions = is_array($question['options'] ?? null) ? $question['options'] : ($extra['options'] ?? []);
        if (!is_array($rawOptions)) {
            return [];
        }
        $options = [];
        foreach ($rawOptions as $key => $option) {
            if (is_array($option)) {
                $label = (string) ($option['label'] ?? $option['name'] ?? $option['value'] ?? $key);
                $value = (string) ($option['id'] ?? $option['value'] ?? $key);
            } else {
                $label = (string) $option;
                $value = (string) $key;
            }
            if ($label !== '') {
                $options[] = ['id' => $value, 'label' => $label];
            }
        }
        return $options;
    }

    /** @return array<string, mixed> */
    private function constraintsForType(string $type): array
    {
        return match ($type) {
            'email' => ['format' => 'email'],
            'number' => ['numeric' => true],
            'file' => ['native_upload_required' => true],
            'native_reference' => ['native_engine_required' => true],
            default => [],
        };
    }

    /**
     * @param array<string, mixed> $question
     * @return array<int, DynamicFormCondition>
     */
    private function portableConditionsFromQuestion(array $question, DynamicFormField $field, string $prefix): array
    {
        return $this->portableConditionsForTarget($question, $field->name(), 'field', $prefix);
    }

    /**
     * @param array<string, mixed> $item
     * @return array<int, DynamicFormCondition>
     */
    private function portableConditionsForTarget(array $item, string $target, string $targetType, string $prefix): array
    {
        $rawConditions = $item['portable_conditions'] ?? $item['dynamic_conditions'] ?? null;
        if (!is_array($rawConditions)) {
            return [];
        }

        $conditions = [];
        foreach (array_values($rawConditions) as $index => $rawCondition) {
            if (!is_array($rawCondition)) {
                continue;
            }

            $effect = (string) ($rawCondition['effect'] ?? $rawCondition['action'] ?? 'show');
            if (!in_array($effect, ['show', 'hide', 'require', 'disable'], true)) {
                continue;
            }

            $expression = $this->normalizePortableExpression($rawCondition);
            if ($expression === []) {
                continue;
            }
            if ($targetType !== 'field') {
                $expression['target_type'] = $targetType;
            }

            $conditions[] = new DynamicFormCondition(
                $prefix . '_' . (string) ($index + 1),
                $target,
                $effect,
                $expression,
                true,
                ''
            );
        }

        return $conditions;
    }

    /**
     * @param array<string, mixed> $rawCondition
     * @return array<string, mixed>
     */
    private function normalizePortableExpression(array $rawCondition): array
    {
        $expression = is_array($rawCondition['expression'] ?? null) ? $rawCondition['expression'] : $rawCondition;
        return $this->normalizePortableExpressionNode($expression);
    }

    /**
     * @param array<string, mixed> $node
     * @return array<string, mixed>
     */
    private function normalizePortableExpressionNode(array $node): array
    {
        foreach (['all', 'any'] as $groupKey) {
            if (!isset($node[$groupKey]) || !is_array($node[$groupKey])) {
                continue;
            }
            $children = [];
            foreach ($node[$groupKey] as $child) {
                if (!is_array($child)) {
                    continue;
                }
                $normalized = $this->normalizePortableExpressionNode($child);
                if ($normalized !== []) {
                    $children[] = $normalized;
                }
            }
            return $children !== [] ? [$groupKey => $children] : [];
        }

        if (isset($node['not']) && is_array($node['not'])) {
            $normalized = $this->normalizePortableExpressionNode($node['not']);
            return $normalized !== [] ? ['not' => $normalized] : [];
        }

        $sourceField = (string) ($node['field'] ?? $node['source_field'] ?? $node['question'] ?? '');
        $operator = (string) ($node['operator'] ?? 'equals');
        if ($sourceField === '' || !in_array($operator, ['equals', 'not_equals', 'empty', 'not_empty', 'contains', 'in', 'not_in'], true)) {
            return [];
        }

        return [
            'field' => $sourceField,
            'operator' => $operator,
            'value' => $node['value'] ?? null,
            'values' => is_array($node['values'] ?? null) ? array_values($node['values']) : [],
        ];
    }
    /** @param array<string, mixed> $item */
    private function hasConditions(array $item): bool
    {
        foreach (['conditions', 'validation_conditions', 'submit_button_conditions'] as $key) {
            $value = $item[$key] ?? '';
            if (is_array($value) && $value !== []) {
                return true;
            }
            if (is_string($value)) {
                $trimmed = trim($value);
                if ($trimmed !== '' && $trimmed !== '[]' && $trimmed !== '{}') {
                    return true;
                }
            }
        }
        return false;
    }

    private function decodeJsonish(mixed $value): mixed
    {
        if (!is_string($value) || trim($value) === '') {
            return $value;
        }
        $decoded = json_decode($value, true);
        return json_last_error() === JSON_ERROR_NONE ? $decoded : $value;
    }

    /**
     * @param array<string, bool> $detectedApis
     * @param array<string, mixed> $projected
     * @return array<int, array{area:string,status:string,message:string,fallback_required:bool}>
     */
    private function compatibilityMatrix(array $detectedApis, array $projected): array
    {
        $hasCoreForm = !empty($detectedApis['Glpi\\Form\\Form']);
        $hasCatalog = !empty($detectedApis['ServiceCatalogManager']);
        $hasAccess = !empty($detectedApis['FormAccessParameters']);
        $fields = (array) ($projected['fields'] ?? []);
        $fieldCount = count($fields);
        $unsupportedCount = count((array) ($projected['unsupported'] ?? []));
        $nativeAssistedCount = $this->nativeAssistedFieldCount($fields);
        $conditions = (array) ($projected['conditions'] ?? []);
        $supportedConditionCount = 0;
        $nativeConditionCount = 0;
        foreach ($conditions as $condition) {
            if (!$condition instanceof DynamicFormCondition) {
                continue;
            }
            if ($condition->isSupported()) {
                $supportedConditionCount++;
            } else {
                $nativeConditionCount++;
            }
        }

        $projectedFieldCount = max(0, $fieldCount - 1);
        $fieldCountLabel = sprintf(
            I18n::plural('%d campo', '%d campos', $projectedFieldCount === 1 ? 1 : 2),
            $projectedFieldCount
        );
        $assistedTypeCountLabel = sprintf(
            I18n::plural(
                '%d tipo assistido pelo GLPI',
                '%d tipos assistidos pelo GLPI',
                $nativeAssistedCount === 1 ? 1 : 2
            ),
            $nativeAssistedCount
        );
        $unsupportedTypeCountLabel = sprintf(
            I18n::plural('%d tipo não suportado', '%d tipos não suportados', $unsupportedCount === 1 ? 1 : 2),
            $unsupportedCount
        );

        return [[
            'area' => 'field_types',
            'status' => $this->fieldTypesStatus($fieldCount, $unsupportedCount, $nativeAssistedCount, $hasCoreForm),
            'message' => $fieldCount > 1
                ? sprintf(
                    I18n::translate('Estrutura projetada com %1$s, %2$s e %3$s.'),
                    $fieldCountLabel,
                    $assistedTypeCountLabel,
                    $unsupportedTypeCountLabel
                )
                : I18n::translate('Classes de formulários do GLPI 11 detectadas; nenhum campo dinâmico foi projetado para este item.'),
            'fallback_required' => $unsupportedCount > 0 || $nativeAssistedCount > 0,
        ], [
            'area' => 'conditions',
            'status' => $supportedConditionCount > 0 ? ($nativeConditionCount > 0 ? 'portable_partial' : 'portable_supported') : 'native_engine_required',
            'message' => $supportedConditionCount > 0
                ? sprintf(I18n::translate('Condições portáveis suportadas: %d. Condições não normalizadas: %d. Regras de envio, destino e validação condicional continuam no GLPI.'), $supportedConditionCount, $nativeConditionCount)
                : I18n::translate('Condições de visibilidade, obrigatoriedade e validação permanecem no GLPI até que a equivalência seja homologada.'),
            'fallback_required' => true,
        ], [
            'area' => 'targets',
            'status' => 'native_engine_required',
            'message' => I18n::translate('Destinos de chamado, mudança ou problema e roteamentos condicionais ainda não são enviados pelo portal.'),
            'fallback_required' => true,
        ], [
            'area' => 'attachments',
            'status' => 'native_engine_required',
            'message' => I18n::translate('Campos de arquivo dependem da validação e da vinculação realizadas pelo Catálogo de Serviços.'),
            'fallback_required' => true,
        ], [
            'area' => 'validations',
            'status' => 'native_engine_required',
            'message' => I18n::translate('As validações do servidor do Catálogo de Serviços ainda não foram normalizadas em {field, code, message}.'),
            'fallback_required' => true,
        ], [
            'area' => 'permissions',
            'status' => $hasCatalog && $hasAccess ? 'native_acl_detected' : 'native_acl_partial',
            'message' => I18n::translate('A listagem e a abertura continuam sendo revalidadas pelas APIs do GLPI, pela entidade, pelo perfil e pela sessão.'),
            'fallback_required' => !$hasCatalog || !$hasAccess,
        ], [
            'area' => 'apis',
            'status' => $hasCoreForm && $hasCatalog ? 'detected' : 'partial',
            'message' => I18n::translate('As APIs detectadas são registradas para homologação no GLPI 11, sem habilitar envio direto pelo portal.'),
            'fallback_required' => true,
        ], [
            'area' => 'fallback',
            'status' => 'required',
            'message' => I18n::translate('A página completa permanece obrigatória para o envio até que campos, condições, destinos, anexos, validações e permissões sejam homologados.'),
            'fallback_required' => true,
        ]];
    }

    /** @param array<int, DynamicFormField> $fields */
    /**
     * @param array<int, DynamicFormField> $fields
     * @param array<int, DynamicFormCondition> $conditions
     * @param array<int, array<string, string>> $unsupported
     * @param array<string, bool> $detectedApis
     * @return array<string, mixed>
     */
    private function ownSubmissionReadiness(int $formId, array $fields, array $conditions, array $unsupported, array $detectedApis): array
    {
        $blockedAreas = [];
        $requiredApis = [
            'Glpi\\Form\\Form' => I18n::translate('Classe base de formulários do GLPI 11 ausente.'),
            'FormAccessParameters' => I18n::translate('Contrato de controle de acesso do formulário não detectado.'),
            'SubmitAnswerController' => I18n::translate('Serviço /Form/SubmitAnswers não detectado.'),
            'ValidateAnswerController' => I18n::translate('Serviço /Form/ValidateAnswers não detectado.'),
            'ConditionEngineController' => I18n::translate('Serviço /Form/Condition/Engine não detectado.'),
            'AnswersHandler' => I18n::translate('Processador de respostas e destinos não detectado.'),
            'EndUserInputNameProvider' => I18n::translate('Contrato de nomes answers_{question_id} não detectado.'),
        ];

        foreach ($requiredApis as $api => $message) {
            if (empty($detectedApis[$api])) {
                $blockedAreas['api_' . strtolower((string) preg_replace('/[^a-z0-9]+/i', '_', $api))] = $message;
            }
        }

        if ($formId <= 0) {
            $blockedAreas['form_id'] = I18n::translate('Identificador do formulário do GLPI 11 indisponível.');
        }

        if ($unsupported !== []) {
            $blockedAreas['unsupported_fields'] = I18n::translate('Há campos ou perguntas sem mapeamento seguro na apresentação acessível.');
        }

        foreach ($conditions as $condition) {
            if (!$condition instanceof DynamicFormCondition || $condition->isSupported()) {
                continue;
            }
            $conditionData = $condition->toArray();
            if ((string) ($conditionData['id'] ?? '') === 'glpi11_native_submit') {
                continue;
            }
            $blockedAreas['complex_or_native_conditions'] = I18n::translate('Condições ainda não normalizadas exigem o Catálogo de Serviços oficial.');
            break;
        }

        $answerableQuestionCount = 0;
        foreach ($fields as $field) {
            if (!$field instanceof DynamicFormField) {
                continue;
            }
            $data = $field->toArray();
            $metadata = is_array($data['metadata'] ?? null) ? $data['metadata'] : [];
            if (!empty($metadata['projection_only'])) {
                continue;
            }

            $answerableQuestionCount++;
            $fieldType = (string) ($data['type'] ?? '');
            $nativeQuestionId = (int) ($metadata['native_question_id'] ?? 0);
            if ($nativeQuestionId <= 0) {
                $blockedAreas['native_question_ids'] = I18n::translate('Nem todos os campos exibidos possuem o identificador necessário para enviar answers_{question_id}.');
            }
            if (!empty($metadata['native_assisted']) || $fieldType === 'native_reference') {
                $blockedAreas['native_reference_fields'] = I18n::translate('Campos de referência dependem de seletores e permissões do GLPI: atores, observadores, dispositivos, recursos, grupos, LDAP, etiquetas e objetos do GLPI.');
            }
            if ($fieldType === 'file') {
                $blockedAreas['attachments'] = I18n::translate('Os anexos do Catálogo de Serviços exigem o envio oficial com _answers_{id}, _prefix_answers_{id} e _tag_answers_{id}; mantenha a página completa até a homologação.');
            }
            if (!empty($data['disabled']) && empty($metadata['native_assisted'])) {
                $blockedAreas['disabled_fields'] = I18n::translate('Há campos indisponíveis na apresentação acessível que podem ser obrigatórios no GLPI.');
            }
        }

        if ($answerableQuestionCount === 0) {
            $blockedAreas['answerable_fields'] = I18n::translate('Nenhuma pergunta disponível pode ser enviada com segurança pelo portal.');
        }

        $ready = $blockedAreas === [];

        return [
            'ready' => $ready,
            'decision' => $ready ? 'native_delegated_submission' : 'native_fallback_required',
            'feature_flag' => 'glpiacessivel_glpi11_native_delegated_submission',
            'delegation_model' => 'submit_to_glpi11_core_endpoints',
            'required_green_areas' => [
                'field_types',
                'conditions',
                'targets',
                'validations',
                'permissions',
                'apis',
                'accessibility',
            ],
            'blocked_areas' => array_keys($blockedAreas),
            'blockers' => $blockedAreas,
            'native_contract' => [
                'submit_endpoint' => '/Form/SubmitAnswers',
                'validate_endpoint' => '/Form/ValidateAnswers',
                'condition_endpoint' => '/Form/Condition/Engine',
                'input_name_pattern' => 'answers_{question_id}',
            ],
        ];
    }

    private function nativeAssistedFieldCount(array $fields): int
    {
        $count = 0;
        foreach ($fields as $field) {
            if (!$field instanceof DynamicFormField) {
                continue;
            }
            $data = $field->toArray();
            if (!empty($data['metadata']['native_assisted'])) {
                $count++;
            }
        }

        return $count;
    }

    /** @param array<int, DynamicFormField> $fields */
    private function compatibilityStatus(bool $hasProjectedFields, array $fields, array $unsupported): string
    {
        if (!$hasProjectedFields || $unsupported !== []) {
            return 'native_fallback_required';
        }

        return $this->nativeAssistedFieldCount($fields) > 0 ? 'projected_with_native_assist' : 'renderer_candidate';
    }

    private function fieldTypesStatus(int $fieldCount, int $unsupportedCount, int $nativeAssistedCount, bool $hasCoreForm): string
    {
        if ($fieldCount <= 1) {
            return $hasCoreForm ? 'partial' : 'api_missing';
        }
        if ($unsupportedCount > 0) {
            return 'partial';
        }
        if ($nativeAssistedCount > 0) {
            return 'projected_with_native_assist';
        }

        return 'projected';
    }
    /** @return array<string, bool> */
    private function detectedApis(): array
    {
        return [
            'Glpi\\Form\\Form' => class_exists('\\Glpi\\Form\\Form'),
            'ServiceCatalogManager' => class_exists('\\Glpi\\Form\\ServiceCatalog\\ServiceCatalogManager'),
            'ItemRequest' => class_exists('\\Glpi\\Form\\ServiceCatalog\\ItemRequest'),
            'FormAccessParameters' => class_exists('\\Glpi\\Form\\AccessControl\\FormAccessParameters'),
            'SubmitAnswerController' => class_exists('\\Glpi\\Controller\\Form\\SubmitAnswerController'),
            'ValidateAnswerController' => class_exists('\\Glpi\\Controller\\Form\\ValidateAnswerController'),
            'ConditionEngineController' => class_exists('\\Glpi\\Controller\\Form\\Condition\\EngineController'),
            'AnswersHandler' => class_exists('\\Glpi\\Form\\AnswersHandler\\AnswersHandler'),
            'EndUserInputNameProvider' => class_exists('\\Glpi\\Form\\EndUserInputNameProvider'),
        ];
    }
}
