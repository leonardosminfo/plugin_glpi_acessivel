<?php

declare(strict_types=1);

namespace GlpiPlugin\Glpiacessivel\Application;

use GlpiPlugin\Glpiacessivel\Domain\Security\Authorization;
use GlpiPlugin\Glpiacessivel\Infrastructure\Audit\AuditLogger;
use GlpiPlugin\Glpiacessivel\Support\I18n;
use GlpiPlugin\Glpiacessivel\Support\TextNormalizer;

final class ChatbotService
{
    private const INTENT_VERSION = '2.6.2';
    private const SESSION_KEY = 'glpiacessivel_chatbot_context';
    private const PENDING_ACTION_TTL_SECONDS = 300;

    /**
     * Stemming conservador por dominio. Evita stemmer generico para nao
     * transformar termos tecnicos parecidos em acoes GLPI indevidas.
     */
    private const INTENT_CONCEPT_LEXICON = [
        'possessive_user' => ['meu', 'meus', 'minha', 'minhas', 'me'],
        'ticket' => ['chamado', 'chamados', 'chamad', 'ticket', 'tickets', 'protocolo', 'protocolos', 'solicitacao', 'solicitacoes', 'demanda', 'demandas'],
        'query' => ['consultar', 'consulta', 'consultando', 'ver', 'listar', 'lista', 'buscar', 'busca', 'pesquisar', 'pesquisa', 'mostrar', 'acompanhar'],
        'open' => ['abrir', 'abertura', 'abrindo', 'criar', 'criacao', 'registrar', 'registro', 'novo', 'nova'],
        'problem' => ['problema', 'problemas', 'erro', 'erros', 'falha', 'falhas', 'dificuldade', 'dificuldades', 'duvida', 'duvidas', 'nao', 'indisponivel'],
        'kb' => ['faq', 'kb', 'base', 'conhecimento', 'artigo', 'artigos', 'orientacao', 'orientacoes', 'manual', 'manuais'],
        'followup' => ['followup', 'acompanhamento', 'acompanhamentos', 'andamento', 'responder', 'resposta', 'comentario', 'comentar', 'atualizacao'],
        'task' => ['tarefa', 'tarefas', 'atividade', 'atividades', 'planejar', 'execucao'],
        'solution' => ['solucao', 'solucoes', 'solucionar', 'solucionado', 'resolver', 'resolucao', 'encerrar', 'fechar', 'fechamento'],
        'assignment' => ['escalonar', 'escalonamento', 'encaminhar', 'encaminhamento', 'atribuir', 'atribuicao', 'grupo', 'tecnico', 'responsavel'],
        'classification' => ['reclassificar', 'classificar', 'classificacao', 'categoria', 'categorias', 'trocar', 'alterar', 'mudar'],
        'priority' => ['priorizar', 'prioridade', 'urgencia', 'urgente', 'impacto', 'critico', 'critica', 'severidade'],
        'sla' => ['sla', 'prazo', 'prazos', 'vencimento', 'vence', 'vencido', 'tempo'],
        'human' => ['humano', 'atendente', 'operador', 'central', 'telefone', 'telefonica'],
        'audit' => ['auditoria', 'auditar', 'log', 'historico', 'trilha'],
        'message_user' => ['mensagem', 'comunicar', 'avisar', 'notificar', 'usuario', 'requerente'],
    ];

    /** @var TicketService */
    private $ticketService;
    /** @var KnowledgeBaseService */
    private $knowledgeBaseService;
    /** @var AuditLogger */
    private $auditLogger;
    /** @var Authorization */
    private $authorization;
    /** @var ConfigService */
    private $configService;
    /** @var PortalModulePolicy */
    private $modulePolicy;
    /** @var ChatbotPlaybookService */
    private $playbookService;
    /** @var array<string, mixed> */
    private $lastIntentDebug = [];

    public function __construct(
        TicketService $ticketService,
        KnowledgeBaseService $knowledgeBaseService,
        AuditLogger $auditLogger,
        Authorization $authorization,
        ConfigService $configService,
        PortalModulePolicy $modulePolicy,
        ChatbotPlaybookService $playbookService
    ) {
        $this->ticketService = $ticketService;
        $this->knowledgeBaseService = $knowledgeBaseService;
        $this->auditLogger = $auditLogger;
        $this->authorization = $authorization;
        $this->configService = $configService;
        $this->modulePolicy = $modulePolicy;
        $this->playbookService = $playbookService;
    }

    public function handlePrompt(string $prompt): array
    {
        $rawPrompt = $this->stripWrappingQuotes(trim($prompt));
        $cleanPrompt = $this->normalizeText($rawPrompt);

        if ($cleanPrompt === '') {
            return $this->welcomeResponse('empty');
        }

        if ($this->isCancelPrompt($cleanPrompt)) {
            $this->clearConversationContext();
            return $this->response(
                'conversation_cancelled',
                'Fluxo atual cancelado. Posso retomar com outra solicitação.',
                1.0,
                [],
                [
                    'Pergunte sobre seus chamados',
                    'Descreva um problema para eu consultar a base de conhecimento',
                    'Diga "abrir chamado" para iniciar um novo registro',
                ]
            );
        }

        if ($this->isGreetingPrompt($cleanPrompt)) {
            $this->clearConversationContext();
            return $this->welcomeResponse();
        }

        if ($this->isGenericProblemStarter($cleanPrompt)) {
            $this->clearConversationContext();
        }

        $activeContext = $this->getConversationContext();
        if ($activeContext !== null) {
            $contextIntent = $this->intentForConversationContext($activeContext);
            if ($contextIntent !== '' && !$this->modulePolicy->isIntentEnabled($contextIntent)) {
                $this->clearConversationContext();
                return $this->moduleUnavailableResponse($contextIntent, 1.0, 'conversation_context');
            }
        }
        if ($activeContext !== null && $this->shouldResumeConversation($activeContext, $cleanPrompt)) {
            try {
                return $this->resumeConversation($activeContext, $rawPrompt, $cleanPrompt);
            } catch (\Throwable $e) {
                $this->clearConversationContext();
                $this->auditLogger->log('chatbot.context.error', [
                    'state' => (string) ($activeContext['state'] ?? ''),
                    'error' => get_class($e),
                    'message' => mb_substr($e->getMessage(), 0, 500, 'UTF-8'),
                    'file' => basename($e->getFile()),
                    'line' => $e->getLine(),
                ]);

                return $this->handoffResponse('Ocorreu um erro ao continuar a conversa atual.');
            }
        }

        $intent = $this->detectIntent($cleanPrompt);
        $this->lastIntentDebug = is_array($intent['debug'] ?? null) ? $intent['debug'] : [];
        $this->auditLogger->log('chatbot.intent.detected', [
            'intent' => $intent['name'],
            'confidence' => $intent['confidence'],
            'prompt_len' => strlen($rawPrompt),
        ]);
        $this->recordDetectedIntentMetrics($intent);
        if (!$this->modulePolicy->isIntentEnabled((string) $intent['name'])) {
            return $this->moduleUnavailableResponse(
                (string) $intent['name'],
                (float) $intent['confidence'],
                'detected_intent'
            );
        }

        $playbookShortcut = $this->tryApprovedPlaybookShortcut(
            $cleanPrompt,
            (string) $intent['name'],
            (float) $intent['confidence']
        );
        if ($playbookShortcut !== null) {
            return $playbookShortcut;
        }

        if ((float) $intent['confidence'] < 0.55) {
            return $this->clarificationResponse((float) $intent['confidence']);
        }

        if (!$this->configService->isChatbotIntentEnabled((string) $intent['name'])) {
            $this->logChatbotMetric('fallback', [
                'intent' => (string) $intent['name'],
                'confidence' => (float) $intent['confidence'],
                'outcome' => 'intent_disabled',
                'reason_code' => 'disabled_intent',
            ]);

            return $this->response(
                'intent_disabled',
                'Esta intenção do chatbot foi desativada na configuração do plugin.',
                (float) $intent['confidence'],
                ['intent' => $intent['name']],
                ['Solicite essa ação ao atendimento humano.'],
                true
            );
        }

        if (!$this->isAllowedIntent((string) $intent['name'])) {
            $this->logChatbotMetric('permission_denied', [
                'intent' => (string) $intent['name'],
                'confidence' => (float) $intent['confidence'],
                'outcome' => 'blocked_by_acl',
                'reason_code' => 'permission_denied',
            ]);

            return $this->response(
                'intent_denied',
                'Seu perfil no GLPI não permite executar essa ação.',
                (float) $intent['confidence'],
                ['intent' => $intent['name']],
                [
                    'Tente "meus chamados" ou "chamado 123"',
                    'Confira se entidade e perfil ativos estão corretos',
                ]
            );
        }

        if ($this->requiresExplicitConfirmation((string) $intent['name'])) {
            return $this->startIntentConfirmation((string) $intent['name'], $rawPrompt, $cleanPrompt, (float) $intent['confidence']);
        }

        try {
            return $this->dispatch((string) $intent['name'], $rawPrompt, $cleanPrompt, (float) $intent['confidence']);
        } catch (\Throwable $e) {
            $this->auditLogger->log('chatbot.intent.error', [
                'intent' => $intent['name'],
                'error' => get_class($e),
                'message_len' => strlen($e->getMessage()),
            ]);

            return $this->handoffResponse('Ocorreu um erro ao processar essa solicitação no fluxo automático.');
        }
    }

    private function dispatch(string $intent, string $rawPrompt, string $cleanPrompt, float $confidence): array
    {
        return match ($intent) {
            'mine_tickets' => $this->handleMineTickets($confidence),
            'ticket_lookup' => $this->handleTicketLookup($cleanPrompt, $confidence),
            'ticket_criar_guiado' => $this->handleTicketCreateGuided($rawPrompt, $cleanPrompt, $confidence),
            'ticket_triagem_inicial' => $this->handleTicketTriage($cleanPrompt, $confidence),
            'ticket_escalonar' => $this->handleTicketEscalate($cleanPrompt, $confidence),
            'ticket_reclassificar' => $this->handleTicketReclassify($cleanPrompt, $confidence),
            'ticket_priorizar' => $this->handleTicketPrioritize($cleanPrompt, $confidence),
            'ticket_sla_status' => $this->handleTicketSlaStatus($cleanPrompt, $confidence),
            'ticket_followup_operacional' => $this->handleTicketFollowup($rawPrompt, $cleanPrompt, $confidence),
            'ticket_encerrar_com_validacao' => $this->handleTicketCloseValidation($rawPrompt, $cleanPrompt, $confidence),
            'kb_recomendar_contextual' => $this->handleKnowledgeRecommendation($cleanPrompt, $confidence),
            'comunicacao_usuario' => $this->handleUserCommunication($rawPrompt, $cleanPrompt, $confidence),
            'auditoria_consulta' => $this->handleAuditConsult($cleanPrompt, $confidence),
            'handoff_humano' => $this->handoffResponse('Solicitação direcionada para atendimento humano.'),
            default => $this->handoffResponse('Solicitação não mapeada no roteador de intenções.'),
        };
    }


    /** @param array<string, mixed> $context */
    private function intentForConversationContext(array $context): string
    {
        $intent = trim((string) ($context['intent'] ?? ''));
        if ($intent !== '') {
            return $intent;
        }

        $state = (string) ($context['state'] ?? '');
        if (str_starts_with($state, 'ticket_create')) {
            return 'ticket_criar_guiado';
        }

        if (str_starts_with($state, 'kb_')) {
            return 'kb_recomendar_contextual';
        }

        return '';
    }

    private function moduleUnavailableResponse(string $intent, float $confidence, string $outcome): array
    {
        $module = $this->modulePolicy->requiredModuleForIntent($intent);
        $this->auditLogger->log('chatbot.intent.blocked', [
            'intent' => $intent,
            'module' => (string) ($module ?? ''),
            'module_state' => $module === null ? '' : $this->modulePolicy->getEffectiveState($module),
            'confidence' => $confidence,
            'outcome' => $outcome,
        ]);
        $this->logChatbotMetric('permission_denied', [
            'intent' => $intent,
            'confidence' => $confidence,
            'outcome' => 'blocked_by_module',
            'reason_code' => 'module_disabled',
            'source' => $outcome,
        ]);

        return $this->response(
            'module_unavailable',
            'Esta funcionalidade não está disponível no portal no momento.',
            $confidence,
            ['intent' => $intent, 'module' => $module],
            ['Use uma das funcionalidades disponíveis ou solicite atendimento humano.'],
            true
        );
    }
    private function intentRiskLevel(string $intent): string
    {
        return ChatbotIntentPolicy::riskLevel($intent);
    }

    private function requiresExplicitConfirmation(string $intent): bool
    {
        return ChatbotIntentPolicy::requiresConfirmation($intent);
    }

    private function startIntentConfirmation(string $intent, string $rawPrompt, string $cleanPrompt, float $confidence): array
    {
        $ticketId = $this->extractTicketId($cleanPrompt);
        $pendingAction = $this->buildPendingAction($intent, $rawPrompt, $cleanPrompt, $confidence, $ticketId);
        $responseAction = $this->pendingActionForResponse($pendingAction);
        $riskLevel = (string) $pendingAction['risk_level'];

        $this->saveConversationContext([
            'state' => 'intent_confirmation',
            'pending_action' => $pendingAction,
            'intent' => $intent,
            'ticket_id' => $ticketId,
            'risk_level' => $riskLevel,
            'created_at' => time(),
            'expires_at' => (int) $pendingAction['expires_at'],
        ]);

        $this->auditLogger->log('chatbot.intent.confirmation_required', [
            'intent' => $intent,
            'ticket_id' => $ticketId,
            'confidence' => $confidence,
            'risk_level' => $riskLevel,
            'action_hash' => $pendingAction['action_hash'],
            'expires_at' => $pendingAction['expires_at'],
            'strong_confirmation' => $riskLevel === 'critical' ? 1 : 0,
        ], $ticketId > 0 ? $ticketId : null);

        $answer = $this->confirmationPromptForIntent($intent, $ticketId);
        $nextSteps = [
                'Responda "não" ou "cancelar" para interromper',
        ];
        if ($riskLevel === 'critical') {
            $answer .= ' Para confirmar, responda exatamente "' . $responseAction['confirmation_phrase'] . '".';
            array_unshift($nextSteps, 'Responda exatamente "' . $responseAction['confirmation_phrase'] . '" para executar');
        } else {
            array_unshift($nextSteps, 'Responda "sim" ou "confirmar" para executar');
        }

        return $this->response(
            'intent_confirmation_required',
            $answer,
            $confidence,
            [
                'pending_intent' => $intent,
                'ticket_id' => $ticketId,
                'risk_level' => $riskLevel,
                'action_preview' => $responseAction,
                'pending_action' => $responseAction,
            ],
            $nextSteps
        );
    }

    /**
     * @return array<string, mixed>
     */
    private function buildPendingAction(string $intent, string $rawPrompt, string $cleanPrompt, float $confidence, int $ticketId): array
    {
        $riskLevel = $this->intentRiskLevel($intent);
        $nonce = bin2hex(random_bytes(16));
        $createdAt = time();
        $expiresAt = $createdAt + self::PENDING_ACTION_TTL_SECONDS;
        $confirmationCode = $riskLevel === 'critical' ? (string) random_int(1000, 9999) : '';
        $payload = [
            'intent' => $intent,
            'ticket_id' => $ticketId > 0 ? $ticketId : null,
            'risk_level' => $riskLevel,
            'confidence' => round($confidence, 2),
            'user_id' => (int) ($_SESSION['glpiID'] ?? 0),
            'entity_id' => (int) ($_SESSION['glpiactive_entity'] ?? 0),
            'profile_id' => (int) ($_SESSION['glpiactiveprofile']['id'] ?? 0),
            'prompt_hash' => hash('sha256', $cleanPrompt),
            'created_at' => $createdAt,
            'expires_at' => $expiresAt,
        ];

        return [
            'intent' => $intent,
            'ticket_id' => $ticketId,
            'risk_level' => $riskLevel,
            'raw_prompt' => $rawPrompt,
            'clean_prompt' => $cleanPrompt,
            'confidence' => $confidence,
            'payload' => $payload,
            'nonce' => $nonce,
            'action_hash' => $this->pendingActionHash($payload, $nonce),
            'confirmation_code_hash' => $confirmationCode !== '' ? $this->confirmationCodeHash($confirmationCode, $nonce) : '',
            'confirmation_phrase' => $confirmationCode !== '' ? ('confirmar ' . $confirmationCode) : '',
            'created_at' => $createdAt,
            'expires_at' => $expiresAt,
        ];
    }

    /**
     * @param array<string, mixed> $pendingAction
     * @return array<string, mixed>
     */
    private function pendingActionForResponse(array $pendingAction): array
    {
        $payload = is_array($pendingAction['payload'] ?? null) ? $pendingAction['payload'] : [];
        return [
            'intent' => (string) ($pendingAction['intent'] ?? ''),
            'ticket_id' => (int) ($pendingAction['ticket_id'] ?? 0) > 0 ? (int) ($pendingAction['ticket_id'] ?? 0) : null,
            'risk_level' => (string) ($pendingAction['risk_level'] ?? 'read'),
            'requires_confirmation' => true,
            'requires_strong_confirmation' => (string) ($pendingAction['risk_level'] ?? '') === 'critical',
            'confirmation_phrase' => (string) ($pendingAction['confirmation_phrase'] ?? ''),
            'expires_at' => (int) ($pendingAction['expires_at'] ?? 0),
            'ttl_seconds' => max(0, (int) ($pendingAction['expires_at'] ?? 0) - time()),
            'action_hash' => (string) ($pendingAction['action_hash'] ?? ''),
            'payload' => [
                'intent' => (string) ($payload['intent'] ?? ''),
                'ticket_id' => $payload['ticket_id'] ?? null,
                'risk_level' => (string) ($payload['risk_level'] ?? ''),
                'confidence' => (float) ($payload['confidence'] ?? 0),
                'entity_id' => (int) ($payload['entity_id'] ?? 0),
                'profile_id' => (int) ($payload['profile_id'] ?? 0),
            ],
        ];
    }

    /**
     * @param array<string, mixed> $payload
     */
    private function pendingActionHash(array $payload, string $nonce): string
    {
        return hash('sha256', json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) . '|' . $nonce . '|' . (string) session_id());
    }

    private function confirmationCodeHash(string $confirmationCode, string $nonce): string
    {
        return hash('sha256', $confirmationCode . '|' . $nonce . '|' . (string) session_id());
    }

    /**
     * @param array<string, mixed> $context
     * @return array<string, mixed>
     */
    private function validatePendingAction(array $context): array
    {
        $pendingAction = is_array($context['pending_action'] ?? null) ? $context['pending_action'] : [];
        if ($pendingAction === []) {
            throw new \RuntimeException('Acao pendente ausente.');
        }

        $payload = is_array($pendingAction['payload'] ?? null) ? $pendingAction['payload'] : [];
        $nonce = (string) ($pendingAction['nonce'] ?? '');
        $storedHash = (string) ($pendingAction['action_hash'] ?? '');
        $expiresAt = (int) ($pendingAction['expires_at'] ?? 0);
        if ($payload === [] || $nonce === '' || $storedHash === '') {
            throw new \RuntimeException('Acao pendente incompleta.');
        }
        if ($expiresAt < time()) {
            throw new \RuntimeException('Acao pendente expirada.');
        }
        if (!hash_equals($storedHash, $this->pendingActionHash($payload, $nonce))) {
            throw new \RuntimeException('Acao pendente adulterada.');
        }

        return $pendingAction;
    }

    /**
     * @param array<string, mixed> $pendingAction
     */
    private function isStrongConfirmationPrompt(string $cleanPrompt, array $pendingAction): bool
    {
        $phrase = (string) ($pendingAction['confirmation_phrase'] ?? '');
        $nonce = (string) ($pendingAction['nonce'] ?? '');
        $codeHash = (string) ($pendingAction['confirmation_code_hash'] ?? '');
        if ($phrase === '' || $nonce === '' || $codeHash === '') {
            return false;
        }

        if ($cleanPrompt !== $phrase) {
            return false;
        }

        $code = trim(substr($phrase, strlen('confirmar')));
        return $code !== '' && hash_equals($codeHash, $this->confirmationCodeHash($code, $nonce));
    }

    private function confirmationPromptForIntent(string $intent, int $ticketId): string
    {
        $target = $ticketId > 0 ? (' no chamado #' . $ticketId) : '';
        return match ($intent) {
            'ticket_escalonar' => 'Confirme se deseja aplicar o escalonamento' . $target . '.',
            'ticket_reclassificar' => 'Confirme se deseja reclassificar o chamado' . $target . '.',
            'ticket_priorizar' => 'Confirme se deseja alterar urgência, impacto ou prioridade' . $target . '.',
            'ticket_followup_operacional' => 'Confirme se deseja registrar um acompanhamento' . $target . '.',
            'ticket_encerrar_com_validacao' => 'Confirme se deseja registrar solução ou encerramento' . $target . '.',
            'comunicacao_usuario' => 'Confirme se deseja preparar a comunicação operacional' . $target . '.',
            default => 'Confirme se deseja executar esta ação operacional' . $target . '.',
        };
    }

    private function tryApprovedPlaybookShortcut(string $prompt, string $intentName, float $confidence): ?array
    {
        if ($prompt === '') {
            return null;
        }

        if ($this->isExplicitKeyRoutePrompt($prompt, $intentName)) {
            $this->lastIntentDebug['playbook_shortcut_skipped'] = [
                'reason' => 'explicit_key_route',
                'source_intent' => $intentName,
            ];

            return null;
        }

        $protectedIntents = [
            'mine_tickets',
            'ticket_lookup',
            'ticket_criar_guiado',
            'ticket_followup_operacional',
            'ticket_encerrar_com_validacao',
            'ticket_escalonar',
            'ticket_reclassificar',
            'ticket_priorizar',
            'ticket_sla_status',
            'auditoria_consulta',
            'comunicacao_usuario',
        ];
        if (in_array($intentName, $protectedIntents, true) && $confidence >= 0.72) {
            return null;
        }

        if (
            !$this->modulePolicy->isIntentEnabled('kb_recomendar_contextual')
            || !$this->configService->isChatbotIntentEnabled('kb_recomendar_contextual')
        ) {
            return null;
        }

        if (!$this->isAllowedIntent('kb_recomendar_contextual')) {
            return null;
        }

        $playbook = $this->playbookService->matchApprovedPlaybook($prompt, 'kb_recomendar_contextual')
            ?? $this->playbookService->matchApprovedPlaybook($prompt);
        if ($playbook === null) {
            return null;
        }

        $this->lastIntentDebug['playbook_shortcut'] = [
            'id' => (int) ($playbook['id'] ?? 0),
            'score' => (float) ($playbook['match_score'] ?? 0.0),
            'source_intent' => $intentName,
        ];
        $this->auditLogger->log('chatbot.playbook.shortcut', [
            'playbook_id' => (int) ($playbook['id'] ?? 0),
            'score' => (float) ($playbook['match_score'] ?? 0.0),
            'source_intent' => $intentName,
        ]);

        return $this->handlePlaybookRecommendation($playbook, $prompt, max($confidence, 0.7));
    }

    private function isExplicitKeyRoutePrompt(string $prompt, string $intentName): bool
    {
        $normalized = preg_replace('/\s+/', ' ', trim($prompt));
        $normalized = is_string($normalized) ? $normalized : trim($prompt);
        if ($normalized === '') {
            return false;
        }

        $exactCommands = [
            'meus chamados',
            'meu chamados',
            'meus chamado',
            'meu chamado',
            'meus tickets',
            'meu ticket',
            'minhas solicitacoes',
            'minha solicitacao',
            'consultar chamados',
            'listar chamados',
            'abrir chamado',
            'novo chamado',
            'criar chamado',
            'registrar chamado',
            'abrir ticket',
            'novo ticket',
            'consultar faq',
            'abrir faq',
            'faq',
            'base de conhecimento',
            'consultar base',
            'consultar base de conhecimento',
            'buscar base de conhecimento',
            'pesquisar base de conhecimento',
            'resolver problema',
            'tenho um problema',
        ];
        if (in_array($normalized, $exactCommands, true)) {
            return true;
        }

        if (preg_match('/^(ticket|chamado)\s*#?\s*\d+$/u', $normalized) === 1) {
            return true;
        }

        if (
            $intentName === 'mine_tickets'
            && preg_match('/^(meu|minha|meus|minhas)?\s*(chamado|chamados|ticket|tickets|solicitacao|solicitacoes)$/u', $normalized) === 1
        ) {
            return true;
        }

        if (
            $intentName === 'ticket_criar_guiado'
            && preg_match('/^(abrir|criar|registrar|novo|nova)\s+(chamado|ticket|solicitacao)$/u', $normalized) === 1
        ) {
            return true;
        }

        if (
            $intentName === 'kb_recomendar_contextual'
            && preg_match('/^(consultar|buscar|pesquisar|abrir|ver)?\s*(a\s+)?(base de conhecimento|base|faq|kb)$/u', $normalized) === 1
        ) {
            return true;
        }

        if ($intentName === 'ticket_lookup' && $this->extractTicketId($normalized) > 0) {
            return true;
        }

        return false;
    }

    /**
     * @return array{name:string, confidence:float, debug:array<string, mixed>}
     */
    private function detectIntent(string $prompt): array
    {
        $rules = [
            ['name' => 'handoff_humano', 'weight' => 100, 'patterns' => ['atendente humano', 'humano', 'operador humano', 'suporte humano', 'central telefonica']],
            ['name' => 'ticket_escalonar', 'weight' => 92, 'patterns' => ['escalonar', 'encaminhar', 'atribuir ticket', 'atribuir chamado', 'grupo responsavel', 'grupo tecnico', 'tecnico responsavel']],
            ['name' => 'ticket_reclassificar', 'weight' => 88, 'patterns' => ['reclassificar', 'mudar categoria', 'alterar categoria', 'trocar categoria', 'classificar chamado']],
            ['name' => 'ticket_followup_operacional', 'weight' => 90, 'patterns' => ['followup', 'acompanhamento', 'registrar andamento', 'responder chamado', 'adicionar resposta', 'comentar chamado']],
            ['name' => 'ticket_encerrar_com_validacao', 'weight' => 90, 'patterns' => ['encerrar ticket', 'fechar ticket', 'registrar solucao', 'encerrar chamado', 'solucionar chamado', 'adicionar solucao']],
            ['name' => 'ticket_priorizar', 'weight' => 86, 'patterns' => ['priorizar', 'prioridade', 'urgencia', 'impacto', 'critico', 'critica']],
            ['name' => 'ticket_sla_status', 'weight' => 86, 'patterns' => ['sla', 'prazo', 'vencimento', 'tempo para solucao', 'tempo de solucao']],
            ['name' => 'ticket_criar_guiado', 'weight' => 86, 'patterns' => ['abrir chamado', 'novo chamado', 'criar chamado', 'registrar chamado', 'abrir ticket', 'nova solicitacao']],
            ['name' => 'ticket_triagem_inicial', 'weight' => 82, 'patterns' => ['triagem', 'classificacao inicial', 'classificar demanda']],
            ['name' => 'mine_tickets', 'weight' => 90, 'patterns' => ['meus chamados', 'meu chamados', 'meus chamado', 'meu chamado', 'meus tickets', 'meu tickets', 'meu ticket', 'chamados meus', 'minhas solicitacoes', 'minha solicitacao', 'minhas demandas', 'minha demanda', 'ver meus chamados', 'consultar meus chamados', 'listar meus chamados']],
            ['name' => 'ticket_lookup', 'weight' => 76, 'patterns' => ['ticket', 'chamado #', 'chamado ', 'protocolo']],
            ['name' => 'kb_recomendar_contextual', 'weight' => 84, 'patterns' => ['faq', 'base de conhecimento', 'kb', 'artigo', 'problema', 'tenho problema', 'tenho um problema', 'estou com problema', 'preciso de ajuda', 'quero ajuda', 'nao consigo', 'nao estou conseguindo', 'nao conecta', 'nao abre', 'nao funciona', 'sem conexao', 'sem acesso', 'fora do ar', 'travando', 'lento', 'bloqueado', 'expirado', 'erro', 'falha', 'dificuldade', 'duvida', 'nao resolveu', 'nao adiantou', 'como resolver', 'orientacao', 'vpn', 'office', 'impressora', 'certificado', 'senha']],
            ['name' => 'comunicacao_usuario', 'weight' => 82, 'patterns' => ['mensagem usuario', 'comunicar usuario', 'resposta para usuario', 'avisar usuario']],
            ['name' => 'auditoria_consulta', 'weight' => 80, 'patterns' => ['auditoria', 'trilha', 'log de acao', 'historico de auditoria']],
        ];

        $entities = $this->extractIntentEntities($prompt);
        $concepts = $this->extractIntentConcepts($prompt);
        $candidates = [];
        foreach ($rules as $rule) {
            $score = 0;
            $matches = [];
            foreach ($rule['patterns'] as $pattern) {
                if (str_contains($prompt, (string) $pattern)) {
                    $matches[] = (string) $pattern;
                    $score += (int) $rule['weight'];
                }
            }

            $intent = (string) $rule['name'];
            if (($entities['ticket_id'] ?? 0) > 0 && str_starts_with($intent, 'ticket_')) {
                $score += 14;
            }
            if (($entities['ticket_id'] ?? 0) > 0 && $intent === 'ticket_lookup' && $matches !== []) {
                $score += 24;
            }
            if (($entities['urgency'] ?? 0) > 0 && $intent === 'ticket_priorizar') {
                $score += 18;
            }
            if (($entities['impact'] ?? 0) > 0 && $intent === 'ticket_priorizar') {
                $score += 18;
            }
            if (($entities['category_id'] ?? 0) > 0 && $intent === 'ticket_reclassificar') {
                $score += 18;
            }
            if (str_contains($prompt, ':') && in_array($intent, ['ticket_followup_operacional', 'ticket_encerrar_com_validacao'], true)) {
                $score += 10;
            }
            if ($intent === 'mine_tickets' && $this->hasConcepts($concepts, ['possessive_user', 'ticket'])) {
                $matches[] = 'stemming:consulta_possessiva_chamados';
                $score += $this->hasConcept($concepts, 'query') ? 110 : 96;
            }
            if ($intent === 'ticket_criar_guiado' && $this->hasConcepts($concepts, ['open', 'ticket'])) {
                $matches[] = 'stemming:abertura_chamado';
                $score += 92;
            }
            if ($intent === 'ticket_criar_guiado' && $this->hasConcepts($concepts, ['open', 'problem'])) {
                $matches[] = 'stemming:abertura_problema';
                $score += 72;
            }
            if ($intent === 'kb_recomendar_contextual' && $this->hasConcept($concepts, 'problem')) {
                $matches[] = 'stemming:problema_orientacao';
                $score += $this->hasConcept($concepts, 'kb') ? 96 : 72;
            }
            if ($intent === 'kb_recomendar_contextual' && $this->hasConcepts($concepts, ['query', 'kb'])) {
                $matches[] = 'stemming:consulta_base_conhecimento';
                $score += 94;
            }
            if ($intent === 'ticket_followup_operacional' && $this->hasConcepts($concepts, ['followup', 'ticket'])) {
                $matches[] = 'stemming:acompanhamento_ticket';
                $score += 84;
            }
            if ($intent === 'ticket_encerrar_com_validacao' && $this->hasConcepts($concepts, ['solution', 'ticket'])) {
                $matches[] = 'stemming:solucao_ticket';
                $score += 84;
            }
            if ($intent === 'ticket_escalonar' && $this->hasConcepts($concepts, ['assignment', 'ticket'])) {
                $matches[] = 'stemming:atribuicao_ticket';
                $score += 80;
            }
            if ($intent === 'ticket_reclassificar' && $this->hasConcepts($concepts, ['classification', 'ticket'])) {
                $matches[] = 'stemming:classificacao_ticket';
                $score += 76;
            }
            if ($intent === 'ticket_priorizar' && $this->hasConcept($concepts, 'priority')) {
                $matches[] = 'stemming:prioridade';
                $score += 74;
            }
            if ($intent === 'ticket_sla_status' && $this->hasConcept($concepts, 'sla')) {
                $matches[] = 'stemming:sla_prazo';
                $score += 74;
            }
            if ($intent === 'handoff_humano' && $this->hasConcept($concepts, 'human')) {
                $matches[] = 'stemming:atendimento_humano';
                $score += 82;
            }
            if ($intent === 'auditoria_consulta' && $this->hasConcept($concepts, 'audit')) {
                $matches[] = 'stemming:auditoria';
                $score += 78;
            }
            if ($intent === 'comunicacao_usuario' && $this->hasConcept($concepts, 'message_user')) {
                $matches[] = 'stemming:comunicacao_usuario';
                $score += 76;
            }

            if ($score > 0) {
                $candidates[] = [
                    'intent' => $intent,
                    'score' => $score,
                    'matches' => $matches,
                    'enabled' => $this->configService->isChatbotIntentEnabled($intent),
                    'allowed' => $this->isAllowedIntent($intent),
                ];
            }
        }

        usort($candidates, static function (array $left, array $right): int {
            return (int) $right['score'] <=> (int) $left['score'];
        });

        $selected = $candidates[0] ?? null;
        if ($selected === null) {
            return [
                'name' => 'fallback',
                'confidence' => 0.35,
                'debug' => [
                    'engine' => 'weighted_rules',
                    'entities' => $entities,
                    'concepts' => $concepts,
                    'candidates' => [],
                    'decision' => 'fallback_no_candidate',
                ],
            ];
        }

        $score = (int) $selected['score'];
        $confidence = min(0.99, max(0.56, $score / 120));

        return [
            'name' => (string) $selected['intent'],
            'confidence' => $confidence,
            'debug' => [
                'engine' => 'weighted_rules',
                'entities' => $entities,
                'concepts' => $concepts,
                'selected' => $selected,
                'candidates' => array_slice($candidates, 0, 5),
                'decision' => 'highest_score',
            ],
        ];
    }

    private function isAllowedIntent(string $intent): bool
    {
        return ChatbotIntentPolicy::isAllowed($intent, $this->authorization);
    }

    private function handleMineTickets(float $confidence): array
    {
        $tickets = $this->ticketService->list([
            'scope' => 'mine',
            'page' => 1,
            'page_size' => 5,
            'sort' => 'date_mod',
            'direction' => 'DESC',
        ]);

        $items = array_map([$this, 'ticketSummary'], $tickets['items'] ?? []);
        $this->auditLogger->log('chatbot.intent.mine_tickets', ['total' => $tickets['total']]);

        return $this->response(
            'mine_tickets',
            sprintf(
                I18n::plural(
                    'Encontrei %d chamado no contexto ativo exibido nesta tela. A tabela abaixo mostra os principais dados para abrir o detalhe quando precisar.',
                    'Encontrei %d chamados no contexto ativo exibido nesta tela. A tabela abaixo mostra os principais dados para abrir o detalhe quando precisar.',
                    (int) $tickets['total']
                ),
                (int) $tickets['total']
            ),
            $confidence,
            [
                'total' => (int) ($tickets['total'] ?? 0),
                'tickets' => $items,
            ],
            [
                'Use "chamado <id>" para abrir um chamado específico',
                'Se faltar algum chamado, confira se entidade e perfil ativos estão corretos',
            ]
        );
    }

    private function handleTicketLookup(string $prompt, float $confidence): array
    {
        $ticketId = $this->extractTicketId($prompt);
        if ($ticketId <= 0) {
            return $this->response(
                'ticket_lookup',
                'Informe o número do chamado. Exemplo: "chamado 123".',
                $confidence
            );
        }

        $ticket = $this->ticketService->detail($ticketId, []);
        if ($ticket === null) {
            return $this->response(
                'ticket_lookup',
                'Não encontrei esse chamado no contexto ativo exibido nesta tela.',
                $confidence,
                [],
                [
                    'Confira se entidade e perfil ativos estão corretos',
                    'Verifique se o número do chamado foi digitado corretamente',
                ]
            );
        }

        $this->auditLogger->log('chatbot.intent.ticket_lookup', [], $ticketId);
        $statusLabel = $this->statusLabel((int) ($ticket['status'] ?? 0));

        return $this->response(
            'ticket_lookup',
            sprintf('Chamado #%d: %s (%s).', $ticketId, (string) ($ticket['name'] ?? ''), $statusLabel),
            $confidence,
            [
                'ticket' => $this->ticketSummary($ticket),
            ],
            ['Use "prazo do chamado ' . $ticketId . '" para verificar o prazo.']
        );
    }

    private function handleTicketCreateGuided(string $rawPrompt, string $cleanPrompt, float $confidence): array
    {
        if ($this->isOpenTicketCommandOnly($cleanPrompt)) {
            return $this->startTicketCreateCollection($confidence);
        }

        $draft = $this->extractTicketDraft($rawPrompt, $cleanPrompt, []);
        if (trim((string) ($draft['content'] ?? '')) === '') {
            return $this->startTicketCreateCollection($confidence);
        }

        return $this->safeContinueTicketDraftConversation($draft, $confidence);
    }

    private function startTicketCreateCollection(float $confidence): array
    {
        $this->saveConversationContext([
            'state' => 'ticket_create_collect',
            'draft' => [],
        ]);

        return $this->response(
            'ticket_criar_guiado',
            'Descreva o problema em uma frase ou pequeno parágrafo. Exemplo: "Não consigo acessar a VPN da unidade desde 8h, erro de autenticação".',
            $confidence,
            [
                'stage' => 'collect_problem',
                'example' => 'Não consigo imprimir no setor financeiro. A impressora retorna erro de fila parada desde ontem.',
            ],
            [
                'Inclua o que aconteceu',
                'Informe desde quando ocorre',
                'Se possível, cite mensagem de erro e área afetada',
            ]
        );
    }

    private function handleTicketTriage(string $prompt, float $confidence): array
    {
        $urgency = $this->extractIntFromPrompt($prompt, 'urgencia', 3, 1, 5);
        $impact = $this->extractIntFromPrompt($prompt, 'impacto', 3, 1, 5);
        $score = $urgency + $impact;
        $priorityBand = match (true) {
            $score <= 4 => 'baixa',
            $score <= 6 => 'media',
            $score <= 8 => 'alta',
            default => 'critica',
        };

        $answer = sprintf(
            'Triagem inicial sugerida: urgência %d, impacto %d e prioridade %s.',
            $urgency,
            $impact,
            $priorityBand
        );

        return $this->response(
            'ticket_triagem_inicial',
            $answer,
            $confidence,
            [
                'urgencia' => $urgency,
                'impacto' => $impact,
                'prioridade_sugerida' => $priorityBand,
                'checklist' => [
                    'Confirmar categoria correta',
                    'Validar abrangência (usuário único ou serviço inteiro)',
                    'Registrar evidências no texto do chamado',
                ],
            ],
            [
                'Use "priorizar chamado <id> urgência: <1-5> impacto: <1-5>" para aplicar.',
            ]
        );
    }

    private function handleTicketEscalate(string $prompt, float $confidence): array
    {
        $ticketId = $this->extractTicketId($prompt);
        if ($ticketId <= 0) {
            return $this->response(
                'ticket_escalonar',
                'Informe o chamado para encaminhar. Exemplo: "encaminhar chamado 123 para usuários 5,9".',
                $confidence
            );
        }

        $assignees = $this->extractIdsAfterKeyword($prompt, ['usuarios', 'tecnicos', 'atribuir']);
        $watchers = $this->extractIdsAfterKeyword($prompt, ['observadores', 'watchers']);
        if ($assignees === [] && $watchers === []) {
            $context = $this->ticketService->creationContext();
            $candidates = array_slice((array) ($context['assignable_users'] ?? []), 0, 10);
            return $this->response(
                'ticket_escalonar',
                'Informe os IDs dos atores para escalonamento.',
                $confidence,
                [
                'formato_exemplo' => 'encaminhar chamado ' . $ticketId . ' para usuários 5,9 observadores 12',
                    'usuarios_sugeridos' => $candidates,
                ]
            );
        }

        $ok = $this->ticketService->escalateTicketRouting(
            $ticketId,
            $assignees === [] ? null : $assignees,
            $watchers === [] ? null : $watchers,
            'chatbot'
        );
        if (!$ok) {
            return $this->handoffResponse('Não foi possível concluir o escalonamento automático.');
        }

        $this->auditLogger->log('chatbot.intent.ticket_escalonar', [
            'assignees_count' => count($assignees),
            'watchers_count' => count($watchers),
        ], $ticketId);

        return $this->response(
            'ticket_escalonar',
            sprintf('Encaminhamento aplicado no chamado #%d.', $ticketId),
            $confidence,
            [
                'ticket_id' => $ticketId,
                'assignees' => $assignees,
                'watchers' => $watchers,
            ]
        );
    }

    private function handleTicketReclassify(string $prompt, float $confidence): array
    {
        $ticketId = $this->extractTicketId($prompt);
        $categoryId = $this->extractIntFromPrompt($prompt, 'categoria', 0, 0, 999999);
        if ($ticketId <= 0 || $categoryId <= 0) {
            return $this->response(
                'ticket_reclassificar',
                'Informe chamado e categoria. Exemplo: "reclassificar chamado 123 categoria 45 tipo incidente".',
                $confidence
            );
        }

        $type = null;
        if (str_contains($prompt, 'tipo incidente')) {
            $type = $this->getTypeIdByLabel('incidente', 1);
        } elseif (str_contains($prompt, 'tipo requisicao') || str_contains($prompt, 'tipo solicitacao')) {
            $type = $this->getTypeIdByLabel('requis', 2);
        }

        $ok = $this->ticketService->reclassifyTicket($ticketId, $categoryId, $type, 'chatbot');
        if (!$ok) {
            return $this->handoffResponse('Não foi possível concluir a reclassificação automática.');
        }

        $this->auditLogger->log('chatbot.intent.ticket_reclassificar', [
            'itilcategories_id' => $categoryId,
            'type' => $type ?? 0,
        ], $ticketId);

        return $this->response(
            'ticket_reclassificar',
            sprintf('Chamado #%d reclassificado para categoria %d.', $ticketId, $categoryId),
            $confidence,
            [
                'ticket_id' => $ticketId,
                'itilcategories_id' => $categoryId,
                'type' => $type,
            ]
        );
    }

    private function handleTicketPrioritize(string $prompt, float $confidence): array
    {
        $ticketId = $this->extractTicketId($prompt);
        $urgency = $this->extractIntFromPrompt($prompt, 'urgencia', 0, 0, 5);
        $impact = $this->extractIntFromPrompt($prompt, 'impacto', 0, 0, 5);
        if ($ticketId <= 0 || $urgency <= 0 || $impact <= 0) {
            return $this->response(
                'ticket_priorizar',
                'Informe chamado, urgência e impacto. Exemplo: "priorizar chamado 123 urgência 4 impacto 5".',
                $confidence
            );
        }

        $ok = $this->ticketService->reprioritizeTicket($ticketId, $urgency, $impact, 'chatbot');
        if (!$ok) {
            return $this->handoffResponse('Não foi possível aplicar priorização automática.');
        }

        $score = $urgency + $impact;
        $priorityBand = match (true) {
            $score <= 4 => 'baixa',
            $score <= 6 => 'media',
            $score <= 8 => 'alta',
            default => 'critica',
        };

        $this->auditLogger->log('chatbot.intent.ticket_priorizar', [
            'urgency' => $urgency,
            'impact' => $impact,
            'priority_band' => $priorityBand,
        ], $ticketId);

        return $this->response(
            'ticket_priorizar',
            sprintf('Priorização aplicada no chamado #%d (%s).', $ticketId, $priorityBand),
            $confidence,
            [
                'ticket_id' => $ticketId,
                'urgencia' => $urgency,
                'impacto' => $impact,
                'prioridade_sugerida' => $priorityBand,
            ]
        );
    }

    private function handleTicketSlaStatus(string $prompt, float $confidence): array
    {
        $ticketId = $this->extractTicketId($prompt);
        if ($ticketId <= 0) {
            return $this->response(
                'ticket_sla_status',
                'Informe o chamado para consultar o prazo. Exemplo: "prazo do chamado 123".',
                $confidence
            );
        }

        $ticket = $this->ticketService->detail($ticketId, []);
        if ($ticket === null) {
            return $this->response(
                'ticket_sla_status',
                'Chamado não encontrado no contexto ativo exibido nesta tela.',
                $confidence,
                [],
                [
                    'Confira se entidade e perfil ativos estão corretos',
                    'Verifique se o número do chamado foi digitado corretamente',
                ]
            );
        }

        $deadline = $this->extractSlaDeadline($ticket);
        $risk = $this->computeSlaRisk($deadline);

        $this->auditLogger->log('chatbot.intent.ticket_sla_status', [
            'risk' => $risk['risk_level'],
            'has_deadline' => $deadline !== null ? 1 : 0,
        ], $ticketId);

        return $this->response(
            'ticket_sla_status',
            sprintf('Situação do prazo do chamado #%d: %s.', $ticketId, $risk['label']),
            $confidence,
            [
                'ticket_id' => $ticketId,
                'status' => $this->statusLabel((int) ($ticket['status'] ?? 0)),
                'deadline' => $deadline,
                'risk_level' => $risk['risk_level'],
                'risk_label' => $risk['label'],
                'hours_to_deadline' => $risk['hours_to_deadline'],
            ],
            $risk['next_steps']
        );
    }

    private function handleTicketFollowup(string $rawPrompt, string $cleanPrompt, float $confidence): array
    {
        $ticketId = $this->extractTicketId($cleanPrompt);
        if ($ticketId <= 0) {
            return $this->response(
                'ticket_followup_operacional',
                'Informe o chamado e o texto do acompanhamento.',
                $confidence,
                ['formato_exemplo' => 'acompanhamento chamado 123: Usuário validou teste em estação reserva']
            );
        }

        $content = $this->extractMessageAfterColon($rawPrompt);
        if ($content === '') {
            $content = 'Atualização operacional registrada via chatbot.';
        }

        $ok = $this->ticketService->addFollowup($ticketId, $content);
        if (!$ok) {
            return $this->handoffResponse('Não foi possível registrar o acompanhamento automaticamente.');
        }

        $this->auditLogger->log('chatbot.intent.ticket_followup_operacional', [
            'content_len' => strlen($content),
        ], $ticketId);

        return $this->response(
            'ticket_followup_operacional',
            sprintf(I18n::translate('Acompanhamento registrado no chamado #%d.'), $ticketId),
            $confidence,
            ['ticket_id' => $ticketId]
        );
    }

    private function handleTicketCloseValidation(string $rawPrompt, string $cleanPrompt, float $confidence): array
    {
        $ticketId = $this->extractTicketId($cleanPrompt);
        if ($ticketId <= 0) {
            return $this->response(
                'ticket_encerrar_com_validacao',
                'Informe o chamado para encerramento. Exemplo: "encerrar chamado 123 solução: texto".',
                $confidence
            );
        }

        $solution = $this->extractMessageAfterKeyword($rawPrompt, ['solucao', 'solução', 'solution']);
        if ($solution === '') {
            return $this->response(
                'ticket_encerrar_com_validacao',
                'Validação prévia concluída. Falta apenas o texto de solução para encerrar.',
                $confidence,
                [
                    'checklist' => [
                        'Confirmar que o usuário foi comunicado',
                        'Registrar evidência de teste/validação',
                        'Informar causa raiz e ação aplicada',
                    ],
                    'formato_exemplo' => 'encerrar chamado ' . $ticketId . ' solução: Ajustado perfil e validado com usuário',
                ]
            );
        }

        $ok = $this->ticketService->addSolution($ticketId, $solution);
        if (!$ok) {
            return $this->handoffResponse('Não foi possível encerrar automaticamente no fluxo atual.');
        }

        $this->auditLogger->log('chatbot.intent.ticket_encerrar_com_validacao', [
            'solution_len' => strlen($solution),
        ], $ticketId);

        return $this->response(
            'ticket_encerrar_com_validacao',
            sprintf('Solução registrada no chamado #%d. O chamado foi movido para resolvido quando permitido pelo GLPI.', $ticketId),
            $confidence,
            ['ticket_id' => $ticketId],
            ['Solicite validação do requisitante para fechamento final.']
        );
    }

    private function handleKnowledgeRecommendation(string $prompt, float $confidence): array
    {
        $query = $this->buildKnowledgeQuery($prompt);
        if ($this->isGenericKnowledgePrompt($prompt, $query)) {
            $this->saveConversationContext([
                'state' => 'kb_clarification',
                'query' => '',
                'attempts' => 0,
            ]);

            return $this->response(
                'kb_recomendar_contextual',
                'Sobre qual assunto você quer consultar a base de conhecimento? Exemplos: certificado digital, VPN, Office 365, impressora, acesso ao sistema.',
                $confidence,
                [
                    'clarification_required' => true,
                    'examples' => ['certificado digital', 'VPN', 'Office 365', 'impressora', 'acesso ao sistema'],
                ],
                [
                    'Informe o sistema, serviço ou erro que deseja pesquisar',
                    'Se preferir, descreva o problema em uma frase',
                ]
            );
        }

        $playbook = $this->playbookService->matchApprovedPlaybook($query, 'kb_recomendar_contextual')
            ?? $this->playbookService->matchApprovedPlaybook($query);
        if ($playbook !== null) {
            return $this->handlePlaybookRecommendation($playbook, $query, $confidence);
        }

        $articles = $this->knowledgeBaseService->search($query, 5);
        $this->auditLogger->log('chatbot.intent.kb_recomendar_contextual', [
            'query_len' => strlen($query),
            'total' => count($articles),
        ]);

        if ($articles !== []) {
            $articleSummaries = array_map([$this, 'articleSummary'], $articles);
            $this->saveConversationContext([
                'state' => 'kb_feedback',
                'query' => $query,
                'articles' => $articleSummaries,
                'attempts' => 1,
                'created_at' => time(),
            ]);

            return $this->response(
                'kb_recomendar_contextual',
                sprintf(
                    I18n::plural(
                        'Encontrei %d artigo que pode ajudar no seu problema.',
                        'Encontrei %d artigos que podem ajudar no seu problema.',
                        count($articles)
                    ),
                    count($articles)
                ),
                $confidence,
                [
                    'query' => $query,
                    'articles' => $articleSummaries,
                    'kb_feedback_expected' => true,
                ],
                [
                    'Leia o artigo mais aderente ao seu caso',
                'Responda "resolveu" se a orientação foi suficiente',
                'Se não resolver, responda "não resolveu" para eu iniciar um chamado com esse contexto',
                ]
            );
        }

        $this->saveConversationContext([
            'state' => 'kb_clarification',
            'query' => $query,
            'attempts' => 1,
        ]);

        return $this->response(
            'kb_recomendar_contextual',
            'Não encontrei um artigo com essa descrição inicial. Explique em mais um detalhe o que ocorre, o serviço afetado ou a mensagem de erro.',
            $confidence,
            [
                'query' => $query,
                'clarification_required' => true,
                'example' => 'Exemplo: ao acessar a VPN aparece erro de autenticação 691 apenas para usuários da filial.',
            ],
            [
                'Informe o sistema ou serviço afetado',
                'Se houver, cite mensagem de erro',
                'Se preferir, diga "abrir chamado" para eu iniciar um rascunho guiado',
            ]
        );
    }

    private function handleUserCommunication(string $rawPrompt, string $cleanPrompt, float $confidence): array
    {
        $ticketId = $this->extractTicketId($cleanPrompt);
        $ticket = $ticketId > 0 ? $this->ticketService->detail($ticketId, []) : null;
        $statusLabel = $ticket !== null ? $this->statusLabel((int) ($ticket['status'] ?? 0)) : I18n::translate('em análise');
        $title = $ticket !== null ? (string) ($ticket['name'] ?? ('Chamado #' . $ticketId)) : 'seu chamado';

        $message = "Olá! Atualização sobre $title: no momento o status e \"$statusLabel\". "
            . I18n::translate('Nossa equipe segue atuando e retornará com novo posicionamento assim que houver avanços.');

        $this->auditLogger->log('chatbot.intent.comunicacao_usuario', [
            'has_ticket' => $ticket !== null ? 1 : 0,
        ], $ticketId > 0 ? $ticketId : null);

        return $this->response(
            'comunicacao_usuario',
            'Mensagem sugerida pronta para envio ao requisitante.',
            $confidence,
            [
                'ticket_id' => $ticketId > 0 ? $ticketId : null,
                'mensagem' => $message,
            ]
        );
    }

    private function handleAuditConsult(string $prompt, float $confidence): array
    {
        $ticketId = $this->extractTicketId($prompt);
        $rows = $this->auditLogger->recentActions(10, $ticketId > 0 ? $ticketId : null);
        $this->auditLogger->log('chatbot.intent.auditoria_consulta', [
            'ticket_filter' => $ticketId > 0 ? 1 : 0,
            'rows' => count($rows),
        ], $ticketId > 0 ? $ticketId : null);

        return $this->response(
            'auditoria_consulta',
            sprintf(
                I18n::plural(
                    'Retornei %d registro recente de auditoria.',
                    'Retornei %d registros recentes de auditoria.',
                    count($rows)
                ),
                count($rows)
            ),
            $confidence,
            ['rows' => $rows],
            ['Use o número do chamado para uma consulta específica.']
        );
    }

    /**
     * @param mixed $context
     */
    private function summarizeConversationContext($context): string
    {
        if (!is_array($context) || $context === []) {
            return 'Sem contexto conversacional ativo.';
        }

        $parts = [];
        $state = trim((string) ($context['state'] ?? ''));
        $intent = trim((string) ($context['intent'] ?? ''));
        $query = trim((string) ($context['query'] ?? ''));
        $ticketId = (int) ($context['ticket_id'] ?? 0);

        if ($state !== '') {
            $parts[] = 'estado=' . $state;
        }
        if ($intent !== '') {
            $parts[] = 'intent=' . $intent;
        }
        if ($ticketId > 0) {
            $parts[] = 'ticket=#' . $ticketId;
        }
        if ($query !== '') {
            $parts[] = 'consulta=' . mb_substr($query, 0, 120, 'UTF-8');
        }

        return $parts !== [] ? implode('; ', $parts) : 'Contexto ativo sem campos que possam ser resumidos.';
    }

    /**
     * @param mixed $context
     * @return array<string, mixed>
     */
    private function handoffContextSnapshot($context): array
    {
        $articles = is_array($context) && is_array($context['articles'] ?? null) ? $context['articles'] : [];
        return [
            'entity_id' => (int) ($_SESSION['glpiactive_entity'] ?? 0),
            'profile_id' => (int) ($_SESSION['glpiactiveprofile']['id'] ?? 0),
            'ticket_id' => is_array($context) ? ((int) ($context['ticket_id'] ?? 0) ?: null) : null,
            'state' => is_array($context) ? (string) ($context['state'] ?? '') : '',
            'intent' => is_array($context) ? (string) ($context['intent'] ?? '') : '',
            'confidence' => is_array($context) ? round((float) ($context['confidence'] ?? 0), 2) : 0.0,
            'query' => is_array($context) ? mb_substr(trim((string) ($context['query'] ?? '')), 0, 180, 'UTF-8') : '',
            'article_count' => count($articles),
        ];
    }


    /**
     * @param array<string, mixed> $intent
     */
    private function recordDetectedIntentMetrics(array $intent): void
    {
        $name = (string) ($intent['name'] ?? '');
        $confidence = (float) ($intent['confidence'] ?? 0.0);
        $debug = is_array($intent['debug'] ?? null) ? $intent['debug'] : [];

        if ($name === 'fallback') {
            $this->logChatbotMetric('fallback', [
                'intent' => $name,
                'confidence' => $confidence,
                'outcome' => 'clarification_required',
                'reason_code' => $this->intentDecisionReasonCode($debug),
            ]);
        }

        if ($confidence < 0.55) {
            $this->logChatbotMetric('low_confidence', [
                'intent' => $name,
                'confidence' => $confidence,
                'outcome' => 'clarification_required',
                'reason_code' => $this->intentDecisionReasonCode($debug),
            ]);
        }
    }

    /**
     * @param array<string, mixed> $payload
     */
    private function logChatbotMetric(string $event, array $payload = [], ?int $ticketId = null): void
    {
        $confidence = isset($payload['confidence']) ? (float) $payload['confidence'] : 0.0;
        $metricTicketId = (int) ($payload['ticket_id'] ?? ($ticketId ?? 0));

        $this->auditLogger->log('chatbot.metric', [
            'event' => $event,
            'conversation_id' => $this->chatbotConversationId(),
            'user_id' => (int) ($_SESSION['glpiID'] ?? 0),
            'entity_id' => (int) ($_SESSION['glpiactive_entity'] ?? 0),
            'profile_id' => (int) ($_SESSION['glpiactiveprofile']['id'] ?? 0),
            'intent' => (string) ($payload['intent'] ?? ''),
            'confidence' => round($confidence, 2),
            'confidence_bucket' => $this->confidenceBucket($confidence),
            'outcome' => (string) ($payload['outcome'] ?? $event),
            'requires_handoff' => !empty($payload['requires_handoff']) ? 1 : 0,
            'ticket_id' => $metricTicketId,
            'article_id' => (int) ($payload['article_id'] ?? 0),
            'article_count' => (int) ($payload['article_count'] ?? 0),
            'deflected' => isset($payload['deflected']) ? (int) $payload['deflected'] : 0,
            'reason_code' => (string) ($payload['reason_code'] ?? ''),
        ], $metricTicketId > 0 ? $metricTicketId : $ticketId);
    }

    private function chatbotConversationId(): string
    {
        $key = 'glpiacessivel_chatbot_conversation_id';
        if (!isset($_SESSION[$key]) || !is_string($_SESSION[$key]) || $_SESSION[$key] === '') {
            try {
                $_SESSION[$key] = bin2hex(random_bytes(8));
            } catch (\Throwable $e) {
                $_SESSION[$key] = substr(hash('sha256', uniqid('chatbot', true) . '|' . (string) ($_SESSION['glpiID'] ?? 0)), 0, 16);
            }
        }

        return (string) $_SESSION[$key];
    }

    private function confidenceBucket(float $confidence): string
    {
        if ($confidence < 0.55) {
            return 'low';
        }

        if ($confidence < 0.8) {
            return 'medium';
        }

        return 'high';
    }

    /**
     * @param array<string, mixed> $debug
     */
    private function intentDecisionReasonCode(array $debug): string
    {
        $decision = (string) ($debug['decision'] ?? '');
        if ($decision !== '') {
            return $decision;
        }

        return 'processing_error';
    }

    private function handoffReasonCode(string $reason): string
    {
        $normalized = $this->normalizeText($reason);
        if (str_contains($normalized, 'permiss')) {
            return 'permission_denied';
        }
        if (str_contains($normalized, 'nao mapead') || str_contains($normalized, 'nao e suportad')) {
            return 'unsupported_intent';
        }
        if (str_contains($normalized, 'erro') || str_contains($normalized, 'falha')) {
            return 'processing_error';
        }
        if (str_contains($normalized, 'humano')) {
            return 'user_requested_handoff';
        }

        return 'handoff_required';
    }

    private function handoffResponse(string $reason): array
    {
        $activeContext = $this->getConversationContext();
        $ticketId = is_array($activeContext) ? (int) ($activeContext['ticket_id'] ?? 0) : 0;
        $payload = [
            'reason' => $reason,
            'reason_normalized' => $this->normalizeText($reason),
            'reason_len' => strlen($reason),
            'ticket_id' => $ticketId,
            'conversation_state' => is_array($activeContext) ? (string) ($activeContext['state'] ?? '') : '',
            'pending_intent' => is_array($activeContext) ? (string) ($activeContext['intent'] ?? '') : '',
            'confidence' => is_array($activeContext) ? round((float) ($activeContext['confidence'] ?? 0), 2) : 0.0,
            'summary' => $this->summarizeConversationContext($activeContext),
            'context' => $this->handoffContextSnapshot($activeContext),
            'destination' => 'central_de_servicos',
            'user_id' => (int) ($_SESSION['glpiID'] ?? 0),
            'entity_id' => (int) ($_SESSION['glpiactive_entity'] ?? 0),
            'profile_id' => (int) ($_SESSION['glpiactiveprofile']['id'] ?? 0),
        ];
        $this->auditLogger->log('chatbot.intent.handoff_humano', $payload, $ticketId > 0 ? $ticketId : null);
        $this->logChatbotMetric('handoff', [
            'intent' => $payload['pending_intent'] !== '' ? $payload['pending_intent'] : 'handoff_humano',
            'confidence' => (float) $payload['confidence'],
            'outcome' => 'handoff',
            'requires_handoff' => true,
            'ticket_id' => $ticketId,
            'reason_code' => $this->handoffReasonCode($reason),
        ], $ticketId > 0 ? $ticketId : null);

        return $this->response(
            'handoff_humano',
            $reason . ' Recomendo continuidade com atendimento individualizado.',
            0.99,
            [
                'handoff' => [
                    'reason' => $reason,
                    'reason_normalized' => $payload['reason_normalized'],
                    'ticket_id' => $ticketId,
                    'summary' => $payload['summary'],
                    'intent' => $payload['pending_intent'],
                    'confidence' => $payload['confidence'],
                    'conversation_state' => $payload['conversation_state'],
                    'pending_intent' => $payload['pending_intent'],
                    'destination' => $payload['destination'],
                    'context' => $payload['context'],
                ],
            ],
            [
                'Escolher atendimento via central telefônica ou aqui mesmo',
                'Para abrir conosco, basta dizer "abrir chamado" para iniciar a coleta guiada',
                'Se houver número do chamado anterior, informe para contextualizar',
            ],
            true
        );
    }

    /**
     * Usa somente roteiros previamente aprovados por administrador.
     * A varredura gera sugestoes, mas a execucao no chatbot depende desta curadoria.
     *
     * @param array<string, mixed> $playbook
     */
    private function handlePlaybookRecommendation(array $playbook, string $query, float $confidence): array
    {
        $questions = array_values(array_filter(array_map(
            static fn($value): string => trim((string) $value),
            (array) ($playbook['questions'] ?? [])
        )));
        $kbArticles = array_slice(array_values((array) ($playbook['kb_articles'] ?? [])), 0, 10);
        $summary = trim((string) (($playbook['content']['answer_summary'] ?? '') ?: ''));
        $name = trim((string) ($playbook['name'] ?? 'roteiro aprovado'));
        $articles = [];
        foreach ($kbArticles as $article) {
            if (!is_array($article)) {
                continue;
            }

            $id = (int) ($article['id'] ?? 0);
            if ($id <= 0) {
                continue;
            }

            $authorizedArticle = $this->knowledgeBaseService->getArticle($id);
            if ($authorizedArticle === null) {
                continue;
            }

            $articles[] = [
                'id' => $id,
                'name' => (string) ($authorizedArticle['name'] ?? ('Artigo #' . $id)),
                'summary' => (string) ($authorizedArticle['summary'] ?? $summary),
                'category' => (string) ($authorizedArticle['category'] ?? ($playbook['category_hint'] ?? '')),
                'source' => 'playbook',
                'playbook_id' => (int) ($playbook['id'] ?? 0),
                'playbook_name' => $name,
            ];
        }

        $answer = 'Encontrei um roteiro aprovado que pode orientar esse atendimento: ' . $name . '.';
        if ($summary !== '') {
            $answer .= ' ' . mb_substr($summary, 0, 280, 'UTF-8');
        }
        if ($articles !== []) {
            $answer .= ' ' . I18n::translate('Também vinculei o artigo associado para leitura completa.');
        }

        $nextSteps = [];
        foreach (array_slice($questions, 0, 2) as $question) {
            $nextSteps[] = 'Validar: ' . $question;
        }
        if ($articles !== []) {
            $nextSteps[] = 'Abrir o artigo associado na base de conhecimento';
        }
        $nextSteps[] = 'Se não resolver, diga "abrir chamado" para iniciar a coleta guiada';

        $this->auditLogger->log('chatbot.playbook.matched', [
            'playbook_id' => (int) ($playbook['id'] ?? 0),
            'score' => (float) ($playbook['match_score'] ?? 0.0),
            'query_len' => strlen($query),
        ]);

        return $this->response(
            'kb_recomendar_contextual',
            $answer,
            max($confidence, (float) ($playbook['match_score'] ?? 0.7)),
            [
                'query' => $query,
                'articles' => $articles,
                'kb_article_ids' => array_values(array_filter(array_map(
                    static fn(array $article): int => (int) ($article['id'] ?? 0),
                    $articles
                ))),
                'playbook' => [
                    'id' => (int) ($playbook['id'] ?? 0),
                    'name' => $name,
                    'score' => (float) ($playbook['match_score'] ?? 0.0),
                    'questions' => $questions,
                    'kb_articles' => $kbArticles,
                    'category_hint' => (string) ($playbook['category_hint'] ?? ''),
                    'summary' => $summary,
                ],
            ],
            $nextSteps
        );
    }

    private function clarificationResponse(float $confidence): array
    {
        $this->auditLogger->log('chatbot.intent.clarification', ['confidence' => $confidence]);

        return $this->response(
            'clarification_needed',
            'Não consegui identificar com segurança o que você precisa. Posso ajudar se você reformular em uma das opções abaixo.',
            $confidence,
            [
                'examples' => [
                    'meus chamados',
                    'chamado 123',
                    'tenho um problema na VPN',
                    'abrir chamado',
                    'consultar base de conhecimento',
                ],
            ],
            [
                'Diga "meus chamados" para listar seus chamados',
                'Diga "abrir chamado" para iniciar a coleta guiada',
                'Descreva o problema para eu procurar orientações na base de conhecimento',
            ]
        );
    }

    private function response(
        string $intent,
        string $answer,
        float $confidence,
        array $data = [],
        array $nextSteps = [],
        bool $requiresHandoff = false
    ): array {
        $debug = $this->lastIntentDebug;
        // The response boundary is the final safeguard for public copy. Internal
        // intent tokens and payload keys remain unchanged; only user-facing
        // answer and guidance strings are sent through the plugin domain.
        $answer = I18n::translate($answer);
        $nextSteps = array_map(
            static fn($step): string => I18n::translate((string) $step),
            $nextSteps
        );
        return [
            'intent_version' => self::INTENT_VERSION,
            'intent' => $intent,
            'confidence' => round($confidence, 2),
            'requires_handoff' => $requiresHandoff,
            'answer' => $answer,
            'speech_text' => $this->buildSpeechText($intent, $answer, $data, $nextSteps, $requiresHandoff),
            'next_steps' => array_values($nextSteps),
            'data' => $data,
            'debug' => $debug,
        ];
    }

    /**
     * Texto otimizado para sintetizador de voz: curto, sem JSON e sem depender da
     * representacao visual em tabelas/cards.
     */
    private function buildSpeechText(string $intent, string $answer, array $data, array $nextSteps, bool $requiresHandoff): string
    {
        $parts = [$answer];

        if ($intent === 'mine_tickets' && isset($data['total'])) {
            $parts[] = sprintf('Total encontrado: %d chamado(s).', (int) $data['total']);
            $tickets = is_array($data['tickets'] ?? null) ? array_slice($data['tickets'], 0, 3) : [];
            foreach ($tickets as $ticket) {
                $parts[] = sprintf(
                    'Chamado %s, %s, status %s.',
                    (string) ($ticket['id'] ?? ''),
                    (string) ($ticket['name'] ?? ''),
                    (string) ($ticket['status'] ?? '')
                );
            }
        } elseif ($intent === 'ticket_lookup' && is_array($data['ticket'] ?? null)) {
            $ticket = $data['ticket'];
            $parts[] = sprintf(
                'Resumo: chamado %s, %s, status %s, prioridade %s.',
                (string) ($ticket['id'] ?? ''),
                (string) ($ticket['name'] ?? ''),
                (string) ($ticket['status'] ?? ''),
                (string) ($ticket['priority'] ?? '')
            );
        } elseif ($intent === 'kb_recomendar_contextual' && is_array($data['playbook'] ?? null)) {
            $playbook = $data['playbook'];
            $parts[] = 'Roteiro sugerido: ' . (string) ($playbook['name'] ?? '') . '.';
            $summary = trim((string) ($playbook['summary'] ?? ''));
            if ($summary !== '') {
                $parts[] = mb_substr($summary, 0, 180, 'UTF-8') . '.';
            }
        } elseif ($intent === 'kb_recomendar_contextual' && is_array($data['articles'] ?? null)) {
            $articles = array_slice($data['articles'], 0, 3);
            foreach ($articles as $article) {
                $parts[] = 'Artigo sugerido: ' . (string) ($article['name'] ?? '');
            }
        } elseif ($intent === 'ticket_criar_guiado' && is_array($data['draft'] ?? null)) {
            $draft = $data['draft'];
            $parts[] = 'Rascunho de chamado em andamento.';
            if (!empty($draft['titulo'])) {
                $parts[] = 'Título: ' . (string) $draft['titulo'] . '.';
            }
            if (!empty($draft['prioridade_prevista'])) {
                $parts[] = 'Prioridade prevista: ' . (string) $draft['prioridade_prevista'] . '.';
            }
        }

        if ($requiresHandoff) {
            $parts[] = 'Essa conversa requer continuidade com atendimento humano.';
        }

        if ($nextSteps !== []) {
            $parts[] = 'Próximo passo: ' . (string) $nextSteps[0] . '.';
        }

        return trim(preg_replace('/\s+/', ' ', implode(' ', array_filter($parts))) ?? $answer);
    }

    private function resumeConversation(array $context, string $rawPrompt, string $cleanPrompt): array
    {
        return match ((string) ($context['state'] ?? '')) {
            'kb_clarification' => $this->resumeKnowledgeClarification($context, $cleanPrompt),
            'kb_feedback' => $this->resumeKnowledgeFeedback($context, $cleanPrompt),
            'intent_confirmation' => $this->resumeIntentConfirmation($context, $cleanPrompt),
            'ticket_create_collect',
            'ticket_create_ready' => $this->resumeTicketCreation($context, $rawPrompt, $cleanPrompt),
            default => $this->handoffResponse('O estado atual da conversa não é suportado.'),
        };
    }

    private function resumeIntentConfirmation(array $context, string $cleanPrompt): array
    {
        try {
            $pendingAction = $this->validatePendingAction($context);
        } catch (\Throwable $e) {
            $this->clearConversationContext();
            $this->auditLogger->log('chatbot.intent.pending_action_invalid', [
                'reason' => $e->getMessage(),
                'intent' => (string) ($context['intent'] ?? ''),
            ]);
            return $this->handoffResponse('Não consegui recuperar uma ação pendente válida para confirmação.');
        }

        $intent = (string) ($pendingAction['intent'] ?? '');
        if ($intent === '' || !$this->requiresExplicitConfirmation($intent)) {
            $this->clearConversationContext();
            return $this->handoffResponse('Não consegui recuperar a ação pendente para confirmação.');
        }

        $ticketId = (int) ($pendingAction['ticket_id'] ?? 0);
        $riskLevel = (string) ($pendingAction['risk_level'] ?? $this->intentRiskLevel($intent));
        if ($this->isDenialPrompt($cleanPrompt)) {
            $this->clearConversationContext();
            $this->auditLogger->log('chatbot.intent.confirmation_denied', [
                'intent' => $intent,
                'ticket_id' => $ticketId,
                'risk_level' => $riskLevel,
                'action_hash' => (string) ($pendingAction['action_hash'] ?? ''),
            ], $ticketId > 0 ? $ticketId : null);

            return $this->response(
                'intent_confirmation_denied',
                'Ação cancelada. Não fiz alterações no chamado.',
                1.0,
                ['pending_intent' => $intent, 'risk_level' => $riskLevel],
                ['Você pode iniciar outra consulta ou pedir atendimento humano']
            );
        }

        $confirmed = $riskLevel === 'critical'
            ? $this->isStrongConfirmationPrompt($cleanPrompt, $pendingAction)
            : $this->isConfirmationPrompt($cleanPrompt);
        if (!$confirmed) {
            $responseAction = $this->pendingActionForResponse($pendingAction);
            $nextSteps = ['Responda "não" ou "cancelar" para interromper'];
            $message = 'Preciso de confirmação antes de executar essa ação operacional.';
            if ($riskLevel === 'critical') {
                $message = 'Esta ação crítica exige confirmação forte. Responda exatamente "' . $responseAction['confirmation_phrase'] . '".';
                array_unshift($nextSteps, 'Responda exatamente "' . $responseAction['confirmation_phrase'] . '" para executar');
            } else {
                array_unshift($nextSteps, 'Responda "sim" ou "confirmar" para executar');
            }

            return $this->response(
                'intent_confirmation_required',
                $message,
                1.0,
                [
                    'pending_intent' => $intent,
                    'ticket_id' => $ticketId,
                    'risk_level' => $riskLevel,
                    'action_preview' => $responseAction,
                    'pending_action' => $responseAction,
                ],
                $nextSteps
            );
        }

        $rawPrompt = (string) ($pendingAction['raw_prompt'] ?? '');
        $savedCleanPrompt = (string) ($pendingAction['clean_prompt'] ?? '');
        $confidence = (float) ($pendingAction['confidence'] ?? 1.0);
        $this->clearConversationContext();
        $this->auditLogger->log('chatbot.intent.confirmed', [
            'intent' => $intent,
            'ticket_id' => $ticketId,
            'risk_level' => $riskLevel,
            'action_hash' => (string) ($pendingAction['action_hash'] ?? ''),
        ], $ticketId > 0 ? $ticketId : null);

        return $this->dispatch($intent, $rawPrompt, $savedCleanPrompt, $confidence);
    }

    private function resumeKnowledgeFeedback(array $context, string $cleanPrompt): array
    {
        $query = trim((string) ($context['query'] ?? ''));
        if ($this->isKnowledgeResolvedPrompt($cleanPrompt)) {
            $this->clearConversationContext();
            $this->auditLogger->log('chatbot.kb.feedback', [
                'resolved' => 1,
                'query_len' => strlen($query),
            ]);
            $this->auditLogger->log('chatbot.kb.deflection', [
                'outcome' => 'resolved_without_ticket',
                'deflected' => 1,
                'query_len' => strlen($query),
                'article_count' => is_array($context['articles'] ?? null) ? count($context['articles']) : 0,
            ]);
            $this->logChatbotMetric('kb_deflection', [
                'intent' => 'kb_recomendar_contextual',
                'confidence' => 1.0,
                'outcome' => 'resolved_without_ticket',
                'deflected' => 1,
                'article_count' => is_array($context['articles'] ?? null) ? count($context['articles']) : 0,
                'reason_code' => 'user_confirmed_resolved',
            ]);

            return $this->response(
                'kb_feedback_resolved',
                'Obrigado pelo retorno. Registrei que a orientação da base resolveu a necessidade.',
                1.0,
                [
                    'query' => $query,
                    'kb_resolved' => true,
                    'kb_deflection' => [
                        'outcome' => 'resolved_without_ticket',
                        'deflected' => true,
                    ],
                ],
                ['Se precisar de outro assunto, descreva o problema ou diga "meus chamados"']
            );
        }

        if (!$this->isKnowledgeUnresolvedPrompt($cleanPrompt)) {
            return $this->response(
                'kb_feedback_pending',
                'A orientação da base resolveu o problema?',
                1.0,
                [
                    'query' => $query,
                    'articles' => is_array($context['articles'] ?? null) ? $context['articles'] : [],
                ],
                [
                    'Responda "resolveu" se não precisar abrir chamado',
                    'Responda "não resolveu" para abrir chamado com esse contexto',
                ]
            );
        }

        $this->auditLogger->log('chatbot.kb.feedback', [
            'resolved' => 0,
            'query_len' => strlen($query),
        ]);
        $this->auditLogger->log('chatbot.kb.deflection', [
            'outcome' => 'ticket_draft_started',
            'deflected' => 0,
            'query_len' => strlen($query),
            'article_count' => is_array($context['articles'] ?? null) ? count($context['articles']) : 0,
        ]);
        $this->logChatbotMetric('kb_deflection', [
            'intent' => 'kb_recomendar_contextual',
            'confidence' => 1.0,
            'outcome' => 'ticket_draft_started',
            'deflected' => 0,
            'article_count' => is_array($context['articles'] ?? null) ? count($context['articles']) : 0,
            'reason_code' => 'user_confirmed_unresolved',
        ]);
        $this->clearConversationContext();

        $description = 'Tentativa de autoatendimento pela base de conhecimento não resolveu.';
        if ($query !== '') {
            $description .= ' Assunto pesquisado: ' . $query . '.';
        }
        $draft = [
            'name' => $query !== '' ? $this->suggestTitleFromDescription($query) : 'Problema não resolvido pela base de conhecimento',
            'content' => $description,
            'source' => 'chatbot_kb',
            'kb_deflection' => [
                'outcome' => 'ticket_draft_started',
                'deflected' => false,
            ],
        ];

        return $this->safeContinueTicketDraftConversation($draft, 1.0);
    }

    private function resumeKnowledgeClarification(array $context, string $cleanPrompt): array
    {
        $previous = trim((string) ($context['query'] ?? ''));
        if (str_contains($cleanPrompt, 'abrir chamado') && $this->authorization->canCreateTickets()) {
            $seed = $previous !== '' ? $previous : $cleanPrompt;
            $draft = $this->extractTicketDraft($seed, $this->normalizeText($seed), []);
            return $this->safeContinueTicketDraftConversation($draft, 0.92);
        }

        $query = trim($previous . ' ' . $this->buildKnowledgeQuery($cleanPrompt));
        $playbookQuery = trim($query !== '' ? $query : $cleanPrompt);
        $playbook = $this->playbookService->matchApprovedPlaybook($playbookQuery, 'kb_recomendar_contextual')
            ?? $this->playbookService->matchApprovedPlaybook($cleanPrompt, 'kb_recomendar_contextual')
            ?? $this->playbookService->matchApprovedPlaybook($playbookQuery)
            ?? $this->playbookService->matchApprovedPlaybook($cleanPrompt);

        if ($playbook !== null) {
            $this->clearConversationContext();
            return $this->handlePlaybookRecommendation($playbook, $playbookQuery, 0.92);
        }

        $articles = $this->knowledgeBaseService->search($query, 5);

        if ($articles !== []) {
            $this->clearConversationContext();
            return $this->response(
                'kb_recomendar_contextual',
                sprintf('Com esse detalhamento encontrei %d artigo(s) que podem ajudar.', count($articles)),
                0.92,
                [
                    'query' => $query,
                    'articles' => array_map([$this, 'articleSummary'], $articles),
                ],
                [
                    'Valide se o artigo resolve o problema',
                    'Se não resolver, posso iniciar a abertura guiada de chamado',
                ]
            );
        }

        $this->clearConversationContext();
        return $this->response(
            'kb_recomendar_contextual',
            'Ainda não encontrei um artigo aderente. Esse fluxo foi direcionado para atendimento individualizado: você pode escolher atendimento via central telefônica ou responder "abrir chamado" para eu montar o texto inicial do chamado com você.',
            0.9,
            [
                'query' => $query,
                'contact_channel' => 'central telefônica',
                'open_ticket_available' => $this->authorization->canCreateTickets(),
            ],
            [
                'Escolher atendimento via central telefônica ou aqui mesmo',
                'Para abrir conosco, basta dizer "abrir chamado" para iniciar a coleta guiada',
                'Se houver número do chamado anterior, informe para contextualizar',
            ],
            true
        );
    }

    private function resumeTicketCreation(array $context, string $rawPrompt, string $cleanPrompt): array
    {
        $draft = is_array($context['draft'] ?? null) ? (array) $context['draft'] : [];

        if ((string) ($context['state'] ?? '') === 'ticket_create_ready' && $this->isConfirmationPrompt($cleanPrompt)) {
            $ticketId = $this->ticketService->create($this->ticketInputFromDraft($draft));
            $this->clearConversationContext();
            $this->auditLogger->log('chatbot.intent.ticket_create_guided', [
                'title_len' => strlen((string) ($draft['name'] ?? '')),
                'description_len' => strlen((string) ($draft['content'] ?? '')),
            ], $ticketId);
            $this->logChatbotMetric('ticket_create_success', [
                'intent' => 'ticket_criar_guiado',
                'confidence' => 0.96,
                'outcome' => 'success',
                'ticket_id' => $ticketId,
                'reason_code' => 'glpi_ticket_id_created',
            ], $ticketId);

            return $this->response(
                'ticket_criar_guiado',
                sprintf('Chamado #%d criado com sucesso a partir do rascunho guiado.', $ticketId),
                0.96,
                [
                    'ticket_id' => $ticketId,
                    'ticket' => [
                        'id' => $ticketId,
                        'name' => (string) ($draft['name'] ?? ''),
                        'status' => 'Novo',
                        'priority' => $this->priorityLabelFromUrgencyImpact((int) ($draft['urgency'] ?? 3), (int) ($draft['impact'] ?? 3)),
                    ],
                ],
                ['Use "chamado ' . $ticketId . '" para acompanhar o andamento.']
            );
        }

        $awaitingField = (string) ($context['awaiting_field'] ?? '');
        if ($awaitingField !== '') {
            $draft = $this->applyAwaitingFieldAnswer($draft, $awaitingField, $rawPrompt, $cleanPrompt, $context);
        }

        $draft = $this->extractTicketDraft($rawPrompt, $cleanPrompt, $draft);
        return $this->safeContinueTicketDraftConversation($draft, 0.9);
    }

    private function safeContinueTicketDraftConversation(array $draft, float $confidence): array
    {
        if (!$this->modulePolicy->isIntentEnabled('ticket_criar_guiado')) {
            $this->clearConversationContext();
            return $this->moduleUnavailableResponse('ticket_criar_guiado', $confidence, 'ticket_draft');
        }

        try {
            return $this->continueTicketDraftConversation($draft, $confidence);
        } catch (\Throwable $e) {
            $this->auditLogger->log('chatbot.ticket_draft.safe_fallback', [
                'error' => get_class($e),
                'message' => mb_substr($e->getMessage(), 0, 500, 'UTF-8'),
                'file' => basename($e->getFile()),
                'line' => $e->getLine(),
                'title_len' => strlen((string) ($draft['name'] ?? '')),
                'description_len' => strlen((string) ($draft['content'] ?? '')),
            ]);
            $this->logChatbotMetric('fallback', [
                'intent' => 'ticket_criar_guiado',
                'confidence' => $confidence,
                'outcome' => 'safe_ticket_draft_fallback',
                'reason_code' => 'safe_ticket_draft_fallback',
            ]);

            return $this->ticketDraftFallbackResponse($draft, $confidence);
        }
    }

    private function ticketDraftFallbackResponse(array $draft, float $confidence): array
    {
        $missing = $this->missingTicketDraftFields($draft, []);
        $awaitingField = (string) ($missing[0] ?? 'descricao');
        $this->saveConversationContext([
            'state' => 'ticket_create_collect',
            'draft' => $draft,
            'awaiting_field' => $awaitingField,
            'category_suggestions' => [],
        ]);

        $presentation = [
            'titulo' => (string) ($draft['name'] ?? ''),
            'descricao' => (string) ($draft['content'] ?? ''),
            'tipo' => ((int) ($draft['type'] ?? 1)) === 2 ? 'Requisição' : 'Incidente',
            'urgencia' => (int) ($draft['urgency'] ?? 0) > 0 ? $this->scaleLabel((int) $draft['urgency']) : 'Pendente',
            'impacto' => (int) ($draft['impact'] ?? 0) > 0 ? $this->scaleLabel((int) $draft['impact']) : 'Pendente',
            'prioridade_prevista' => ((int) ($draft['urgency'] ?? 0) > 0 && (int) ($draft['impact'] ?? 0) > 0)
                ? $this->priorityLabelFromUrgencyImpact((int) $draft['urgency'], (int) $draft['impact'])
                : 'Pendente',
            'categoria' => 'Não informada',
            'categorias_sugeridas' => [],
            'texto_gerado' => '',
        ];

        return $this->response(
            'ticket_criar_guiado',
            'Consegui manter o rascunho, mas não consegui consultar categorias automaticamente agora. Vamos continuar a coleta guiada.',
            $confidence,
            [
                'stage' => 'collect_missing',
                'draft' => $presentation,
                'awaiting_field' => $awaitingField,
                'category_lookup_error' => true,
            ],
            $this->missingFieldNextSteps($missing)
        );
    }

    private function continueTicketDraftConversation(array $draft, float $confidence): array
    {
        $categorySuggestions = [];

        try {
            $draft = $this->classifyTicketDraft($draft);
        } catch (\Throwable $e) {
            $this->auditLogger->log('chatbot.ticket_draft.classify_error', [
                'error' => get_class($e),
                'message' => mb_substr($e->getMessage(), 0, 500, 'UTF-8'),
            ]);
        }

        try {
            $categorySuggestions = $this->suggestCategoriesForText($this->categorySearchText($draft), (int) ($draft['type'] ?? 1));
            $draft = $this->applyCategorySuggestionWhenConfident($draft, $categorySuggestions);
        } catch (\Throwable $e) {
            $this->auditLogger->log('chatbot.ticket_draft.category_error', [
                'error' => get_class($e),
                'message' => mb_substr($e->getMessage(), 0, 500, 'UTF-8'),
            ]);
            $categorySuggestions = [];
        }

        $missing = $this->missingTicketDraftFields($draft, $categorySuggestions);

        if ($missing !== []) {
            $awaitingField = (string) $missing[0];
            $this->saveConversationContext([
                'state' => 'ticket_create_collect',
                'draft' => $draft,
                'awaiting_field' => $awaitingField,
                'category_suggestions' => $categorySuggestions,
            ]);

            return $this->response(
                'ticket_criar_guiado',
                $this->missingFieldPrompt($missing, $categorySuggestions),
                $confidence,
                [
                    'stage' => 'collect_missing',
                    'draft' => $this->formatDraftForPresentation($draft, $categorySuggestions, false),
                    'awaiting_field' => $awaitingField,
                ],
                $this->missingFieldNextSteps($missing)
            );
        }

        $draft['generated_text'] = $this->buildGeneratedTicketText($draft, $categorySuggestions);
        $this->saveConversationContext([
            'state' => 'ticket_create_ready',
            'draft' => $draft,
        ]);

        return $this->response(
            'ticket_criar_guiado',
            'Montei o rascunho do chamado. Revise os dados abaixo. Se estiver correto, responda "confirmar abertura".',
            $confidence,
            [
                'stage' => 'ready_for_confirmation',
                'draft' => $this->formatDraftForPresentation($draft, $categorySuggestions, true),
            ],
            [
                'Responder "confirmar abertura" para criar o chamado',
                'Responder com ajuste, por exemplo: "urgência 5" ou "categoria 12"',
                'Responder "cancelar" para encerrar o fluxo',
            ]
        );
    }

    private function ticketSummary(array $ticket): array
    {
        return [
            'id' => (int) ($ticket['id'] ?? 0),
            'name' => (string) ($ticket['name'] ?? ''),
            'status' => $this->statusLabel((int) ($ticket['status'] ?? 0)),
            'priority' => $this->priorityLabel((int) ($ticket['priority'] ?? 0)),
            'urgency' => $this->scaleLabel((int) ($ticket['urgency'] ?? 0)),
            'impact' => $this->scaleLabel((int) ($ticket['impact'] ?? 0)),
            'date_mod' => (string) ($ticket['date_mod'] ?? ''),
        ];
    }

    private function articleSummary(array $article): array
    {
        return [
            'id' => (int) ($article['id'] ?? 0),
            'name' => (string) ($article['assunto'] ?? $article['name'] ?? ''),
            'category' => (string) ($article['category'] ?? ''),
            'summary' => (string) ($article['summary'] ?? ''),
            'date_mod' => (string) ($article['date_mod'] ?? ''),
        ];
    }

    private function statusLabel(int $status): string
    {
        return \GlpiPlugin\Glpiacessivel\Support\TicketStatusLabels::label($status);
    }

    private function priorityLabel(int $priority): string
    {
        $labels = [
            1 => 'Muito baixa',
            2 => 'Baixa',
            3 => 'Média',
            4 => 'Alta',
            5 => 'Muito alta',
            6 => 'Crítica',
        ];

        return $labels[$priority] ?? ('Prioridade ' . $priority);
    }

    private function scaleLabel(int $value): string
    {
        $labels = [
            1 => 'Muito baixa',
            2 => 'Baixa',
            3 => 'Média',
            4 => 'Alta',
            5 => 'Muito alta',
        ];

        return $labels[$value] ?? (string) $value;
    }

    private function buildKnowledgeQuery(string $prompt): string
    {
        $query = trim($this->removeWords($prompt, [
            'faq',
            'base de conhecimento',
            'kb',
            'artigo',
            'artigos',
            'consultar',
            'pesquisar',
            'procurar',
            'buscar',
            'recomendar',
            'tenho um problema',
            'estou com problema',
            'nao consigo',
            'nao estou conseguindo',
            'duvida',
            'abrir chamado',
        ]));

        return $query;
    }

    /**
     * @return array{ticket_id:int, urgency:int, impact:int, category_id:int, has_problem_signal:bool, has_write_signal:bool}
     */
    private function extractIntentEntities(string $prompt): array
    {
        return [
            'ticket_id' => $this->extractTicketId($prompt),
            'urgency' => $this->extractIntFromPrompt($prompt, 'urgencia', 0, 0, 5),
            'impact' => $this->extractIntFromPrompt($prompt, 'impacto', 0, 0, 5),
            'category_id' => $this->extractIntFromPrompt($prompt, 'categoria', 0, 0, 999999),
            'has_problem_signal' => $this->containsAny($prompt, [
                'problema',
                'erro',
                'falha',
                'nao consigo',
                'nao estou conseguindo',
                'dificuldade',
            ]),
            'has_write_signal' => $this->containsAny($prompt, [
                'registrar',
                'adicionar',
                'alterar',
                'mudar',
                'fechar',
                'encerrar',
                'criar',
                'abrir',
                'atribuir',
                'escalonar',
            ]),
        ];
    }

    private function extractTicketId(string $prompt): int
    {
        if (preg_match('/(?:ticket|chamado)\s*#?\s*(\d{1,9})/iu', $prompt, $matches) === 1) {
            return (int) $matches[1];
        }

        return 0;
    }

    private function extractIntFromPrompt(string $prompt, string $field, int $default, int $min, int $max): int
    {
        $regex = '/\b' . preg_quote($field, '/') . '\b\s*[:=]?\s*(\d{1,3})/iu';
        if (preg_match($regex, $prompt, $matches) !== 1) {
            return $default;
        }

        $value = (int) $matches[1];
        return min($max, max($min, $value));
    }

    private function extractTypeFromPrompt(string $prompt, array $kv): int
    {
        $rawType = trim((string) ($kv['tipo'] ?? $kv['type'] ?? ''));
        if ($rawType === '') {
            if (str_contains($prompt, 'requisicao') || str_contains($prompt, 'solicitacao')) {
                return 2;
            }
            return 1;
        }

        if (is_numeric($rawType)) {
            return max(1, (int) $rawType);
        }

        $rawType = $this->normalizeText($rawType);
        if (str_contains($rawType, 'requis') || str_contains($rawType, 'solicit')) {
            return $this->getTypeIdByLabel('requis', 2);
        }

        return $this->getTypeIdByLabel('incidente', 1);
    }

    private function getTypeIdByLabel(string $needle, int $default): int
    {
        $context = $this->ticketService->creationContext();
        foreach (($context['type_options'] ?? []) as $option) {
            $label = $this->normalizeText((string) ($option['label'] ?? ''));
            if (str_contains($label, $needle)) {
                return (int) ($option['id'] ?? $default);
            }
        }

        return $default;
    }

    private function parseKeyValues(string $prompt): array
    {
        $prompt = str_replace(["\n", '|'], ';', $prompt);
        $parts = array_filter(array_map('trim', explode(';', $prompt)));
        $data = [];
        foreach ($parts as $part) {
            if (preg_match('/^([a-zA-Z\p{L}_\s]+)\s*[:=]\s*(.+)$/u', $part, $matches) !== 1) {
                continue;
            }
            $key = $this->normalizeText(trim($matches[1]));
            $data[$key] = trim($matches[2]);
        }

        return $data;
    }

    /**
     * @param string[] $keywords
     * @return int[]
     */
    private function extractIdsAfterKeyword(string $prompt, array $keywords): array
    {
        foreach ($keywords as $keyword) {
            $regex = '/\b' . preg_quote($keyword, '/') . '\b\s*[:=]?\s*([\d,\s]+)/iu';
            if (preg_match($regex, $prompt, $matches) === 1) {
                $raw = preg_split('/[,\s]+/', trim((string) $matches[1])) ?: [];
                $ids = array_values(array_unique(array_filter(array_map('intval', $raw), static fn(int $id): bool => $id > 0)));
                if ($ids !== []) {
                    return $ids;
                }
            }
        }

        return [];
    }

    private function extractMessageAfterColon(string $prompt): string
    {
        $parts = explode(':', $prompt, 2);
        if (count($parts) < 2) {
            return '';
        }

        return trim($parts[1]);
    }

    /**
     * @param string[] $keywords
     */
    private function extractMessageAfterKeyword(string $prompt, array $keywords): string
    {
        foreach ($keywords as $keyword) {
            $regex = '/\b' . preg_quote($keyword, '/') . '\b\s*[:=]\s*(.+)$/iu';
            if (preg_match($regex, $prompt, $matches) === 1) {
                return trim((string) $matches[1]);
            }
        }

        return $this->extractMessageAfterColon($prompt);
    }

    /**
     * @param string[] $words
     */
    private function removeWords(string $text, array $words): string
    {
        $result = $text;
        foreach ($words as $word) {
            $result = preg_replace('/\b' . preg_quote($word, '/') . '\b/iu', ' ', $result) ?? $result;
        }

        return trim(preg_replace('/\s+/', ' ', $result) ?? $result);
    }

    /**
     * @return array<string, array{count:int, terms:string[]}>
     */
    private function extractIntentConcepts(string $prompt): array
    {
        $tokens = preg_split('/\s+/', $prompt) ?: [];
        $concepts = [];

        foreach ($tokens as $rawToken) {
            $token = preg_replace('/[^a-z0-9#]/i', '', $this->normalizeText((string) $rawToken)) ?? '';
            if ($token === '' || strlen($token) < 2) {
                continue;
            }

            foreach (self::INTENT_CONCEPT_LEXICON as $concept => $terms) {
                if (!$this->tokenMatchesConcept($token, $terms)) {
                    continue;
                }

                if (!isset($concepts[$concept])) {
                    $concepts[$concept] = ['count' => 0, 'terms' => []];
                }
                $concepts[$concept]['count']++;
                if (!in_array($token, $concepts[$concept]['terms'], true)) {
                    $concepts[$concept]['terms'][] = $token;
                }
            }
        }

        return $concepts;
    }

    /**
     * @param array<string, array{count:int, terms:string[]}> $concepts
     */
    private function hasConcept(array $concepts, string $concept): bool
    {
        return isset($concepts[$concept]) && (int) $concepts[$concept]['count'] > 0;
    }

    /**
     * @param array<string, array{count:int, terms:string[]}> $concepts
     * @param string[] $requiredConcepts
     */
    private function hasConcepts(array $concepts, array $requiredConcepts): bool
    {
        foreach ($requiredConcepts as $concept) {
            if (!$this->hasConcept($concepts, $concept)) {
                return false;
            }
        }

        return true;
    }

    /**
     * @param string[] $terms
     */
    private function tokenMatchesConcept(string $token, array $terms): bool
    {
        $stems = $this->controlledStems($token);

        foreach ($terms as $term) {
            $normalizedTerm = preg_replace('/[^a-z0-9#]/i', '', $this->normalizeText($term)) ?? '';
            if ($normalizedTerm === '') {
                continue;
            }

            foreach ($stems as $stem) {
                if ($stem === $normalizedTerm) {
                    return true;
                }

                if (strlen($stem) >= 5 && strlen($normalizedTerm) >= 5 && levenshtein($stem, $normalizedTerm) <= 1) {
                    return true;
                }

                if (
                    strlen($stem) >= 6 && strlen($normalizedTerm) >= 6
                    && (str_starts_with($stem, $normalizedTerm) || str_starts_with($normalizedTerm, $stem))
                ) {
                    return true;
                }
            }
        }

        return false;
    }

    /**
     * @return string[]
     */
    private function controlledStems(string $token): array
    {
        $stems = [$token];

        if (strlen($token) > 4 && str_ends_with($token, 's')) {
            $stems[] = substr($token, 0, -1);
        }

        $suffixes = ['ando', 'endo', 'indo', 'coes', 'cao', 'mentos', 'mento', 'mente'];
        foreach ($suffixes as $suffix) {
            if (strlen($token) > strlen($suffix) + 3 && str_ends_with($token, $suffix)) {
                $stems[] = substr($token, 0, -strlen($suffix));
            }
        }

        return array_values(array_unique(array_filter($stems, static fn(string $stem): bool => $stem !== '')));
    }

    /**
     * @param string[] $needles
     */
    private function containsAny(string $text, array $needles): bool
    {
        foreach ($needles as $needle) {
            if (str_contains($text, $needle)) {
                return true;
            }
        }

        return false;
    }

    private function hasPossessiveTicketQuery(string $prompt): bool
    {
        $tokens = preg_split('/\s+/', $prompt) ?: [];
        $tokens = array_values(array_filter(array_map('trim', $tokens), static fn(string $token): bool => $token !== ''));

        if ($tokens === []) {
            return false;
        }

        $hasPossessive = $this->containsApproxToken($tokens, ['meu', 'meus', 'minha', 'minhas'], 1);
        $hasTicketWord = $this->containsApproxToken($tokens, [
            'chamado',
            'chamados',
            'ticket',
            'tickets',
            'solicitacao',
            'solicitacoes',
            'demanda',
            'demandas',
        ], 2);

        return $hasPossessive && $hasTicketWord;
    }

    /**
     * @param string[] $tokens
     * @param string[] $needles
     */
    private function containsApproxToken(array $tokens, array $needles, int $maxDistance): bool
    {
        foreach ($tokens as $token) {
            $token = preg_replace('/[^a-z0-9#]/i', '', $this->normalizeText((string) $token)) ?? '';
            if ($token === '' || strlen($token) < 3) {
                continue;
            }

            foreach ($needles as $needle) {
                if ($token === $needle || str_contains($token, $needle) || str_contains($needle, $token)) {
                    return true;
                }

                if (levenshtein($token, $needle) <= $maxDistance) {
                    return true;
                }
            }
        }

        return false;
    }

    private function normalizeText(string $value): string
    {
        $value = $this->stripWrappingQuotes($value);
        $value = mb_strtolower(trim($value), 'UTF-8');
        $converted = iconv('UTF-8', 'ASCII//TRANSLIT//IGNORE', $value);
        if ($converted !== false) {
            $value = $converted;
        }

        $value = preg_replace('/\s+/', ' ', $value) ?? $value;
        return $this->stripWrappingQuotes($value);
    }

    private function stripWrappingQuotes(string $value): string
    {
        $previous = null;
        $value = trim($value);
        while ($previous !== $value) {
            $previous = $value;
            $value = trim($value, " \t\n\r\0\x0B\"'`");
        }

        return $value;
    }

    private function isOpenTicketCommandOnly(string $prompt): bool
    {
        return in_array($this->stripWrappingQuotes($prompt), [
            'abrir chamado',
            'novo chamado',
            'criar chamado',
            'registrar chamado',
            'abrir ticket',
            'nova solicitacao',
        ], true);
    }

    private function extractSlaDeadline(array $ticket): ?string
    {
        foreach (['time_to_resolve', 'internal_time_to_resolve', 'due_date'] as $field) {
            $value = trim((string) ($ticket[$field] ?? ''));
            if ($value === '' || $value === '0000-00-00 00:00:00') {
                continue;
            }
            if (strtotime($value) !== false) {
                return $value;
            }
        }

        return null;
    }

    private function computeSlaRisk(?string $deadline): array
    {
        if ($deadline === null) {
            return [
                'risk_level' => 'unknown',
                'label' => 'Sem prazo configurado',
                'hours_to_deadline' => null,
                'next_steps' => ['Verifique se há prazo definido para esse tipo de chamado.'],
            ];
        }

        $now = time();
        $deadlineTs = strtotime($deadline) ?: 0;
        $hours = (int) floor(($deadlineTs - $now) / 3600);

        if ($hours < 0) {
            return [
                'risk_level' => 'violated',
                'label' => 'Prazo ultrapassado',
                'hours_to_deadline' => $hours,
                'next_steps' => ['Escalonar imediatamente e registrar justificativa de violação.'],
            ];
        }
        if ($hours <= 4) {
            return [
                'risk_level' => 'critical',
                'label' => 'Risco crítico de violação',
                'hours_to_deadline' => $hours,
                'next_steps' => ['Priorizar ação técnica imediata e comunicar o requisitante.'],
            ];
        }
        if ($hours <= 24) {
            return [
                'risk_level' => 'attention',
                'label' => 'Risco moderado de violação',
                'hours_to_deadline' => $hours,
                'next_steps' => ['Registre uma atualização no chamado e revise a fila de atendimento.'],
            ];
        }

        return [
            'risk_level' => 'ok',
            'label' => 'Dentro do prazo',
            'hours_to_deadline' => $hours,
            'next_steps' => ['Mantenha o acompanhamento normal do chamado.'],
        ];
    }

    private function shouldResumeConversation(array $context, string $cleanPrompt): bool
    {
        if ($cleanPrompt === '') {
            return false;
        }

        $overridePatterns = [
            'meus chamados',
            'ticket ',
            'chamado ',
            'faq',
            'base de conhecimento',
            'kb',
            'artigo',
            'orientacao',
            'sla',
            'auditoria',
            'escalonar',
            'reclassificar',
            'priorizar',
            'followup',
            'encerrar ticket',
            'humano',
            'tenho um problema',
            'estou com problema',
            'resolver problema',
            'abrir chamado',
            'novo chamado',
            'criar chamado',
            'registrar chamado',
            'abrir ticket',
            'nova solicitacao',
        ];

        foreach ($overridePatterns as $pattern) {
            if (str_contains($cleanPrompt, $pattern)) {
                return false;
            }
        }

        $state = (string) ($context['state'] ?? '');
        return in_array($state, ['kb_clarification', 'kb_feedback', 'intent_confirmation', 'ticket_create_collect', 'ticket_create_ready'], true);
    }

    private function welcomeResponse(string $intent = 'saudacao'): array
    {
        $chatbotName = $this->configService->getChatbotDisplayName();
        return $this->response(
            $intent,
            sprintf(
                I18n::translate('Olá, sou %s. Posso consultar chamados, entender prazos, procurar orientações na base de conhecimento, montar um novo chamado e apoiar ações operacionais permitidas pelo seu perfil.'),
                $chatbotName
            ),
            1.0,
            [],
            [
                'Diga "meus chamados" para consultar seus chamados',
                'Diga "base de conhecimento" para eu perguntar o assunto da pesquisa',
                'Diga "abrir chamado" para iniciar um registro guiado',
                'Descreva um problema para eu procurar orientações antes de abrir chamado',
            ]
        );
    }

    private function getConversationContext(): ?array
    {
        $context = $_SESSION[self::SESSION_KEY] ?? null;
        return is_array($context) ? $context : null;
    }

    private function saveConversationContext(array $context): void
    {
        $_SESSION[self::SESSION_KEY] = $context;
    }

    private function clearConversationContext(): void
    {
        unset($_SESSION[self::SESSION_KEY]);
    }

    private function isCancelPrompt(string $prompt): bool
    {
        return in_array($prompt, ['cancelar', 'cancelar fluxo', 'parar', 'sair'], true);
    }

    private function isGreetingPrompt(string $prompt): bool
    {
        if (in_array($prompt, ['oi', 'ola', 'bom dia', 'boa tarde', 'boa noite', 'hello'], true)) {
            return true;
        }

        return (bool) preg_match('/^(oi|ola|bom dia|boa tarde|boa noite|hello)(\b|,|!|\.)/iu', $prompt);
    }

    private function isGenericProblemStarter(string $prompt): bool
    {
        return in_array($prompt, [
            'tenho um problema',
            'tenho problema',
            'estou com problema',
            'resolver problema',
            'problema',
            'erro',
            'falha',
            'duvida',
            'preciso de ajuda',
            'quero ajuda',
        ], true);
    }

    private function isKnowledgeResolvedPrompt(string $prompt): bool
    {
        return in_array($prompt, ['resolveu', 'resolvido', 'sim resolveu', 'deu certo', 'funcionou'], true);
    }

    private function isKnowledgeUnresolvedPrompt(string $prompt): bool
    {
        return $this->containsAny($prompt, ['nao resolveu', 'n?o resolveu', 'nao funcionou', 'n?o funcionou', 'continua', 'ainda acontece', 'abrir chamado']);
    }

    private function isGenericKnowledgePrompt(string $prompt, string $query): bool
    {
        $query = trim($query);
        if ($query !== '' && !in_array($query, ['problema', 'erro', 'falha', 'duvida', 'dificuldade'], true)) {
            return false;
        }

        return $this->containsAny($prompt, [
            'faq',
            'base de conhecimento',
            'kb',
            'artigo',
            'artigos',
            'orientacao',
            'orientacoes',
            'problema',
            'tenho problema',
            'tenho um problema',
            'estou com problema',
            'preciso de ajuda',
            'quero ajuda',
        ]);
    }

    private function isConfirmationPrompt(string $prompt): bool
    {
        return in_array($prompt, ['sim', 's', 'yes', 'confirmar', 'confirmo', 'confirmar abertura', 'pode abrir', 'abrir agora', 'pode executar', 'executar agora'], true);
    }

    private function isDenialPrompt(string $prompt): bool
    {
        return in_array($prompt, ['nao', 'n?o', 'n', 'cancelar', 'cancela', 'nao executar', 'n?o executar', 'deixa quieto'], true);
    }

    private function extractTicketDraft(string $rawPrompt, string $cleanPrompt, array $existingDraft): array
    {
        $draft = $existingDraft;
        $kv = $this->parseKeyValues($rawPrompt);

        $title = trim((string) ($kv['titulo'] ?? $kv['title'] ?? ''));
        if ($title !== '') {
            $draft['name'] = $title;
        }

        $description = trim((string) ($kv['descricao'] ?? $kv['description'] ?? ''));
        if ($description !== '') {
            $draft['content'] = $description;
        }

        if (!isset($draft['content']) || trim((string) $draft['content']) === '') {
            $freeText = $this->extractOpenTicketFreeText($rawPrompt);
            if ($freeText !== '') {
                $draft['content'] = $freeText;
            }
        }

        if ((!isset($draft['name']) || trim((string) $draft['name']) === '') && !empty($draft['content'])) {
            $draft['name'] = $this->suggestTitleFromDescription((string) $draft['content']);
        }

        $type = $this->extractTypeFromPrompt($cleanPrompt, $kv);
        if ($type > 0) {
            $draft['type'] = $type;
            if (($kv['tipo'] ?? $kv['type'] ?? '') !== '') {
                $draft['type_confidence'] = 1.0;
                $draft['type_reason'] = 'informado pelo usuário';
            }
        }

        $urgency = $this->extractIntFromPrompt($cleanPrompt, 'urgencia', 0, 0, 5);
        if ($urgency > 0) {
            $draft['urgency'] = $urgency;
            $draft['urgency_confidence'] = 1.0;
            $draft['urgency_reason'] = 'informada pelo usuário';
        }

        $impact = $this->extractIntFromPrompt($cleanPrompt, 'impacto', 0, 0, 5);
        if ($impact > 0) {
            $draft['impact'] = $impact;
            $draft['impact_confidence'] = 1.0;
            $draft['impact_reason'] = 'informado pelo usuário';
        }

        $categoryId = $this->extractIntFromPrompt($cleanPrompt, 'categoria', 0, 0, 999999);
        if ($categoryId > 0) {
            $draft['itilcategories_id'] = $categoryId;
            $draft['category_confidence'] = 1.0;
            $draft['category_reason'] = 'informada pelo usuário';
        }

        if (str_contains($cleanPrompt, 'requisicao') || str_contains($cleanPrompt, 'solicitacao')) {
            $draft['type'] = $this->getTypeIdByLabel('requis', 2);
            $draft['type_confidence'] = 0.9;
            $draft['type_reason'] = 'palavra-chave de requisição';
        } elseif (str_contains($cleanPrompt, 'incidente')) {
            $draft['type'] = $this->getTypeIdByLabel('incidente', 1);
            $draft['type_confidence'] = 0.9;
            $draft['type_reason'] = 'palavra-chave de incidente';
        }

        if (!isset($draft['type'])) {
            $draft['type'] = 1;
        }

        return $draft;
    }

    private function extractOpenTicketFreeText(string $rawPrompt): string
    {
        $rawPrompt = $this->stripWrappingQuotes($rawPrompt);
        $freeText = preg_replace(
            '/^(abrir chamado|novo chamado|criar chamado|registrar chamado|abrir ticket|nova solicitacao|tenho um problema(?: com| no| na)?|estou com problema(?: com| no| na)?|nao consigo)\s*/iu',
            '',
            $rawPrompt
        ) ?? '';
        $freeText = trim($freeText);
        if ($freeText === '' || mb_strlen($freeText, 'UTF-8') < 8) {
            return '';
        }

        return $freeText;
    }

    private function classifyTicketDraft(array $draft): array
    {
        $text = $this->categorySearchText($draft);
        $normalized = $this->normalizeText($text);

        if (!isset($draft['type_confidence']) || (float) $draft['type_confidence'] < 0.8) {
            $type = $this->inferTicketType($normalized);
            if ($type['confidence'] > (float) ($draft['type_confidence'] ?? 0.0)) {
                $draft['type'] = (int) $type['value'];
                $draft['type_confidence'] = (float) $type['confidence'];
                $draft['type_reason'] = (string) $type['reason'];
            }
        }

        if ((int) ($draft['urgency'] ?? 0) <= 0) {
            $urgency = $this->inferUrgency($normalized);
            if ((int) $urgency['value'] > 0 && (float) $urgency['confidence'] >= 0.65) {
                $draft['urgency'] = (int) $urgency['value'];
                $draft['urgency_confidence'] = (float) $urgency['confidence'];
                $draft['urgency_reason'] = (string) $urgency['reason'];
            }
        }

        if ((int) ($draft['impact'] ?? 0) <= 0) {
            $impact = $this->inferImpact($normalized);
            if ((int) $impact['value'] > 0 && (float) $impact['confidence'] >= 0.65) {
                $draft['impact'] = (int) $impact['value'];
                $draft['impact_confidence'] = (float) $impact['confidence'];
                $draft['impact_reason'] = (string) $impact['reason'];
            }
        }

        return $draft;
    }

    private function categorySearchText(array $draft): string
    {
        return trim((string) ($draft['name'] ?? '') . ' ' . (string) ($draft['content'] ?? ''));
    }

    private function inferTicketType(string $text): array
    {
        if ($this->containsAny($text, ['solicitar', 'solicitacao', 'requisicao', 'liberar acesso', 'novo acesso', 'instalar', 'configurar', 'criar usuario', 'permissao'])) {
            return [
                'value' => $this->getTypeIdByLabel('requis', 2),
                'confidence' => 0.78,
                'reason' => 'sinais de requisição',
            ];
        }

        if ($this->containsAny($text, ['erro', 'falha', 'nao funciona', 'nao consigo', 'indisponivel', 'parado', 'problema', 'autenticacao', 'queda'])) {
            return [
                'value' => $this->getTypeIdByLabel('incidente', 1),
                'confidence' => 0.82,
                'reason' => 'sinais de incidente',
            ];
        }

        return [
            'value' => $this->getTypeIdByLabel('incidente', 1),
            'confidence' => 0.35,
            'reason' => 'padrão conservador',
        ];
    }

    private function inferUrgency(string $text): array
    {
        if ($this->containsAny($text, ['parada critica', 'servico parado', 'producao parada', 'audiencia', 'sessao de julgamento', 'plantao', 'prazo hoje'])) {
            return ['value' => 5, 'confidence' => 0.86, 'reason' => 'sinal de parada critica ou prazo imediato'];
        }

        if ($this->containsAny($text, ['nao consigo trabalhar', 'nao consigo acessar', 'indisponivel', 'desde 8h', 'desde hoje', 'urgente', 'muitos usuarios'])) {
            return ['value' => 4, 'confidence' => 0.7, 'reason' => 'sinal de bloqueio operacional'];
        }

        if ($this->containsAny($text, ['erro', 'falha', 'problema', 'dificuldade'])) {
            return ['value' => 3, 'confidence' => 0.55, 'reason' => 'sinal generico de problema'];
        }

        return ['value' => 0, 'confidence' => 0.0, 'reason' => 'sem sinal suficiente'];
    }

    private function inferImpact(string $text): array
    {
        if ($this->containsAny($text, ['todos os usuarios', 'toda unidade', 'unidade inteira', 'sistema inteiro', 'varios usuarios', 'muitos usuarios', 'servico essencial'])) {
            return ['value' => 5, 'confidence' => 0.86, 'reason' => 'abrangencia ampla'];
        }

        if ($this->containsAny($text, ['minha equipe', 'meu setor', 'setor inteiro', 'equipe', 'departamento'])) {
            return ['value' => 3, 'confidence' => 0.75, 'reason' => 'abrangencia de equipe ou setor'];
        }

        if ($this->containsAny($text, ['so eu', 'apenas eu', 'somente eu', 'meu usuario', 'minha maquina'])) {
            return ['value' => 1, 'confidence' => 0.85, 'reason' => 'impacto individual'];
        }

        return ['value' => 0, 'confidence' => 0.0, 'reason' => 'sem sinal suficiente'];
    }

    private function suggestTitleFromDescription(string $description): string
    {
        $description = trim(preg_replace('/\s+/', ' ', $description) ?? $description);
        $title = mb_substr($description, 0, 80, 'UTF-8');

        $sentenceEnd = mb_strpos($title, '.', 0, 'UTF-8');
        if ($sentenceEnd !== false && $sentenceEnd >= 12) {
            $title = mb_substr($title, 0, $sentenceEnd, 'UTF-8');
        }

        return trim($title, " \t\n\r\0\x0B.;:-");
    }

    private function applyAwaitingFieldAnswer(array $draft, string $field, string $rawPrompt, string $cleanPrompt, array $context): array
    {
        $answer = $rawPrompt;
        if ($answer === '') {
            return $draft;
        }

        if ($field === 'urgencia') {
            $value = $this->extractStandaloneScale($cleanPrompt);
            if ($value <= 0) {
                $inferred = $this->inferUrgency($cleanPrompt);
                $value = (float) ($inferred['confidence'] ?? 0.0) >= 0.65 ? (int) ($inferred['value'] ?? 0) : 0;
            }
            if ($value > 0) {
                $draft['urgency'] = $value;
                $draft['urgency_confidence'] = 1.0;
                $draft['urgency_reason'] = 'resposta ao campo solicitado';
            }
            return $draft;
        }

        if ($field === 'impacto') {
            $value = $this->extractStandaloneScale($cleanPrompt);
            if ($value <= 0) {
                $inferred = $this->inferImpact($cleanPrompt);
                $value = (float) ($inferred['confidence'] ?? 0.0) >= 0.65 ? (int) ($inferred['value'] ?? 0) : 0;
            }
            if ($value > 0) {
                $draft['impact'] = $value;
                $draft['impact_confidence'] = 1.0;
                $draft['impact_reason'] = 'resposta ao campo solicitado';
            }
            return $draft;
        }

        if ($field === 'titulo') {
            $draft['name'] = $this->suggestTitleFromDescription($answer);
            return $draft;
        }

        if ($field === 'descricao') {
            $draft['content'] = $answer;
            if (trim((string) ($draft['name'] ?? '')) === '') {
                $draft['name'] = $this->suggestTitleFromDescription($answer);
            }
            return $draft;
        }

        if ($field === 'categoria') {
            $suggestions = is_array($context['category_suggestions'] ?? null) ? (array) $context['category_suggestions'] : [];
            $category = $this->resolveCategoryChoice($cleanPrompt, $suggestions);
            if ($category !== null) {
                $draft['itilcategories_id'] = (int) ($category['id'] ?? 0);
                $draft['category_label'] = (string) ($category['label'] ?? '');
                $draft['category_confidence'] = 1.0;
                $draft['category_reason'] = 'escolhida pelo usuário';
            }
        }

        return $draft;
    }

    private function extractStandaloneScale(string $prompt): int
    {
        if (preg_match('/\b([1-5])\b/u', $prompt, $matches) === 1) {
            return (int) $matches[1];
        }

        return 0;
    }

    private function resolveCategoryChoice(string $prompt, array $suggestions): ?array
    {
        $value = $this->extractStandaloneScale($prompt);
        if ($value > 0 && isset($suggestions[$value - 1])) {
            return (array) $suggestions[$value - 1];
        }

        if (preg_match('/\b(\d{1,9})\b/u', $prompt, $matches) === 1) {
            $id = (int) $matches[1];
            foreach ($suggestions as $category) {
                if ((int) ($category['id'] ?? 0) === $id) {
                    return (array) $category;
                }
            }
        }

        $normalized = $this->normalizeText($prompt);
        foreach ($suggestions as $category) {
            $label = $this->normalizeText((string) ($category['label'] ?? ''));
            if ($label !== '' && (str_contains($label, $normalized) || str_contains($normalized, $label))) {
                return (array) $category;
            }
        }

        return null;
    }

    private function missingTicketDraftFields(array $draft, array $categorySuggestions = []): array
    {
        $missing = [];
        if (trim((string) ($draft['name'] ?? '')) === '') {
            $missing[] = 'titulo';
        }
        if (trim((string) ($draft['content'] ?? '')) === '') {
            $missing[] = 'descricao';
        }
        if ((int) ($draft['urgency'] ?? 0) <= 0) {
            $missing[] = 'urgencia';
        }
        if ((int) ($draft['impact'] ?? 0) <= 0) {
            $missing[] = 'impacto';
        }
        $bestCategoryConfidence = (float) ($categorySuggestions[0]['confidence'] ?? 0.0);
        if ((int) ($draft['itilcategories_id'] ?? 0) <= 0 && $bestCategoryConfidence >= 0.45 && $bestCategoryConfidence < 0.75) {
            $missing[] = 'categoria';
        }

        return $missing;
    }

    private function missingFieldPrompt(array $missing, array $categorySuggestions = []): string
    {
        if (in_array('descricao', $missing, true)) {
            return 'Preciso que você descreva o problema. Exemplo: "Não consigo acessar o e-mail corporativo desde as 9h; o erro informa senha inválida".';
        }
        if (in_array('urgencia', $missing, true)) {
            return 'Qual a urgência de 1 a 5? Exemplo: 1 = pouco urgente, 3 = média, 5 = parada crítica.';
        }
        if (in_array('impacto', $missing, true)) {
            return 'Qual o impacto de 1 a 5? Exemplo: 1 = um usuário, 3 = uma equipe, 5 = serviço essencial parado.';
        }
        if (in_array('titulo', $missing, true)) {
            return 'Informe um título curto para o chamado. Exemplo: "Falha de acesso a VPN".';
        }
        if (in_array('categoria', $missing, true)) {
            $options = [];
            foreach (array_slice($categorySuggestions, 0, 3) as $index => $category) {
                $options[] = sprintf('%d. %s', $index + 1, (string) ($category['label'] ?? ''));
            }

            return 'Encontrei categorias possíveis para esse problema. Responda com o número da melhor opção: ' . implode('; ', $options) . '.';
        }

        return 'Preciso de mais dados para concluir o rascunho do chamado.';
    }

    private function missingFieldNextSteps(array $missing): array
    {
        $steps = [];
        if (in_array('urgencia', $missing, true)) {
            $steps[] = 'Responder com "urgência 1" até "urgência 5"';
        }
        if (in_array('impacto', $missing, true)) {
            $steps[] = 'Responder com "impacto 1" até "impacto 5"';
        }
        if (in_array('descricao', $missing, true)) {
            $steps[] = 'Descrever o erro, o serviço afetado e quando começou';
        }
        if (in_array('titulo', $missing, true)) {
            $steps[] = 'Informar um título curto e objetivo';
        }
        if (in_array('categoria', $missing, true)) {
            $steps[] = 'Responder com o número da categoria sugerida ou informar outra categoria';
        }

        $steps[] = 'Se quiser parar, responda "cancelar"';
        return $steps;
    }

    private function buildGeneratedTicketText(array $draft, array $categorySuggestions): string
    {
        $lines = [
            'Resumo do problema: ' . trim((string) ($draft['name'] ?? '')),
            'Descrição detalhada: ' . trim((string) ($draft['content'] ?? '')),
            'Tipo sugerido: ' . (((int) ($draft['type'] ?? 1)) === $this->getTypeIdByLabel('requis', 2) ? 'Requisição' : 'Incidente'),
            'Urgência: ' . $this->scaleLabel((int) ($draft['urgency'] ?? 3)),
            'Impacto: ' . $this->scaleLabel((int) ($draft['impact'] ?? 3)),
            'Prioridade prevista: ' . $this->priorityLabelFromUrgencyImpact((int) ($draft['urgency'] ?? 3), (int) ($draft['impact'] ?? 3)),
        ];

        if ((int) ($draft['itilcategories_id'] ?? 0) > 0) {
            $label = trim((string) ($draft['category_label'] ?? ''));
            $lines[] = 'Categoria: ' . ($label !== '' ? $label : (string) ($draft['itilcategories_id'] ?? 0));
        } elseif ($categorySuggestions !== []) {
            $lines[] = 'Categoria sugerida para avaliação: ' . (string) ($categorySuggestions[0]['label'] ?? '');
        }

        return implode("\n", $lines);
    }

    private function applyCategorySuggestionWhenConfident(array $draft, array $categorySuggestions): array
    {
        if ((int) ($draft['itilcategories_id'] ?? 0) > 0 || $categorySuggestions === []) {
            return $draft;
        }

        $best = $categorySuggestions[0];
        $confidence = (float) ($best['confidence'] ?? 0.0);
        if ($confidence >= 0.75 && (int) ($best['id'] ?? 0) > 0) {
            $draft['itilcategories_id'] = (int) $best['id'];
            $draft['category_label'] = (string) ($best['label'] ?? '');
            $draft['category_confidence'] = $confidence;
            $draft['category_reason'] = (string) ($best['reason'] ?? 'categoria sugerida por similaridade');
        }

        return $draft;
    }

    private function suggestCategoriesForText(string $text, int $type, int $limit = 5): array
    {
        if ($text === '') {
            return [];
        }

        $context = $this->ticketService->creationContext();
        $normalizedText = $this->normalizeText($text);
        $terms = $this->expandedCategoryTerms($normalizedText);
        $scored = [];

        foreach (($context['categories'] ?? []) as $category) {
            $label = TextNormalizer::fromGlpi((string) ($category['label'] ?? $category['completename'] ?? $category['name'] ?? ''));
            if ($label === '') {
                continue;
            }

            $isIncident = !empty($category['is_incident']);
            $isRequest = !empty($category['is_request']);
            if (($type === 1 && !$isIncident) || ($type === 2 && !$isRequest)) {
                continue;
            }

            $normalizedLabel = $this->normalizeText($label);
            $score = 0.0;
            $reasons = [];
            if (mb_strlen($normalizedText, 'UTF-8') >= 8 && str_contains($normalizedLabel, $normalizedText)) {
                $score += 6.0;
                $reasons[] = 'frase exata na categoria';
            }

            foreach ($terms as $term) {
                $weight = (float) ($term['weight'] ?? 1.0);
                $value = (string) ($term['value'] ?? '');
                if ($value === '') {
                    continue;
                }
                if (str_contains($normalizedLabel, $value)) {
                    $score += $weight;
                    $reasons[] = 'termo ' . $value;
                }
            }

            if ($score <= 0) {
                continue;
            }

            if (str_contains($normalizedLabel, '>')) {
                $score += 0.5;
            }

            $confidence = min(0.98, $score / 8.0);
            $scored[] = [
                'id' => (int) ($category['id'] ?? 0),
                'label' => $label,
                'score' => round($score, 2),
                'confidence' => round($confidence, 2),
                'reason' => implode(', ', array_slice(array_values(array_unique($reasons)), 0, 4)),
            ];
        }

        usort($scored, static function (array $left, array $right): int {
            if ((float) $left['score'] === (float) $right['score']) {
                return strcmp((string) $left['label'], (string) $right['label']);
            }

            return (float) $right['score'] <=> (float) $left['score'];
        });

        return array_slice($scored, 0, $limit);
    }

    private function expandedCategoryTerms(string $normalizedText): array
    {
        $terms = [];
        foreach (array_values(array_unique(array_filter(explode(' ', $normalizedText), static fn(string $term): bool => strlen($term) >= 4))) as $term) {
            $terms[$term] = ['value' => $term, 'weight' => 2.0];
        }

        foreach ($this->categorySynonyms() as $signal => $synonyms) {
            if (!str_contains($normalizedText, $signal)) {
                continue;
            }
            foreach ($synonyms as $synonym) {
                $terms[$synonym] = ['value' => $synonym, 'weight' => 4.0];
            }
        }

        return array_values($terms);
    }

    private function categorySynonyms(): array
    {
        return [
            'vpn' => ['vpn', 'rede', 'acesso remoto', 'remoto'],
            'forticlient' => ['vpn', 'rede', 'acesso remoto'],
            'office' => ['office', '365', 'email', 'outlook'],
            '365' => ['office', '365', 'email', 'outlook'],
            'outlook' => ['email', 'outlook', 'office'],
            'email' => ['email', 'correio', 'outlook'],
            'certificado' => ['certificado', 'token', 'assinatura'],
            'assinatura' => ['certificado', 'assinatura', 'token'],
            'impressora' => ['impressora', 'impressao', 'scanner'],
            'imprimir' => ['impressora', 'impressao'],
            'scanner' => ['scanner', 'digitalizacao', 'impressora'],
            'sei' => ['sei', 'processo'],
            'eproc' => ['eproc', 'processo'],
            'pje' => ['pje', 'processo'],
            'senha' => ['senha', 'autenticacao', 'login'],
            'login' => ['login', 'acesso', 'autenticacao'],
            'autenticacao' => ['autenticacao', 'login', 'senha'],
        ];
    }

    private function formatDraftForPresentation(array $draft, array $categorySuggestions, bool $ready): array
    {
        $categoryLabel = trim((string) ($draft['category_label'] ?? ''));
        $categoryInfo = (int) ($draft['itilcategories_id'] ?? 0) > 0
            ? ($categoryLabel !== '' ? $categoryLabel : (string) ($draft['itilcategories_id'] ?? ''))
            : 'Não informada';

        return [
            'titulo' => (string) ($draft['name'] ?? ''),
            'descricao' => (string) ($draft['content'] ?? ''),
            'tipo' => (((int) ($draft['type'] ?? 1)) === $this->getTypeIdByLabel('requis', 2)) ? 'Requisição' : 'Incidente',
            'urgencia' => (int) ($draft['urgency'] ?? 0) > 0 ? $this->scaleLabel((int) $draft['urgency']) : 'Pendente',
            'impacto' => (int) ($draft['impact'] ?? 0) > 0 ? $this->scaleLabel((int) $draft['impact']) : 'Pendente',
            'prioridade_prevista' => ((int) ($draft['urgency'] ?? 0) > 0 && (int) ($draft['impact'] ?? 0) > 0)
                ? $this->priorityLabelFromUrgencyImpact((int) $draft['urgency'], (int) $draft['impact'])
                : 'Pendente',
            'categoria' => $categoryInfo,
            'confianca_categoria' => (float) ($draft['category_confidence'] ?? 0.0) > 0
                ? (string) round((float) $draft['category_confidence'] * 100) . '%'
                : 'Não calculada',
            'categorias_sugeridas' => $categorySuggestions,
            'texto_gerado' => $ready ? (string) ($draft['generated_text'] ?? '') : '',
        ];
    }

    private function ticketInputFromDraft(array $draft): array
    {
        $input = [
            'name' => trim((string) ($draft['name'] ?? '')),
            'content' => trim((string) ($draft['content'] ?? '')),
            'type' => (int) ($draft['type'] ?? 1),
            'urgency' => (int) ($draft['urgency'] ?? 3),
            'impact' => (int) ($draft['impact'] ?? 3),
        ];

        if ((int) ($draft['itilcategories_id'] ?? 0) > 0) {
            $input['itilcategories_id'] = (int) $draft['itilcategories_id'];
        }

        return $input;
    }

    private function priorityLabelFromUrgencyImpact(int $urgency, int $impact): string
    {
        $score = $urgency + $impact;
        return match (true) {
            $score <= 4 => 'Baixa',
            $score <= 6 => 'Média',
            $score <= 8 => 'Alta',
            default => 'Crítica',
        };
    }
}
