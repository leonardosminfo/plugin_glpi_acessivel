<?php

declare(strict_types=1);

namespace GlpiPlugin\Glpiacessivel\Application;

use GlpiPlugin\Glpiacessivel\Infrastructure\Audit\AuditLogger;
use GlpiPlugin\Glpiacessivel\Infrastructure\Repository\PlaybookRepository;
use GlpiPlugin\Glpiacessivel\Infrastructure\Repository\TicketRepository;
use GlpiPlugin\Glpiacessivel\Support\TextNormalizer;

final class ChatbotPlaybookService
{
    private const MATCH_STOPWORDS = [
        'a', 'o', 'os', 'as', 'de', 'da', 'do', 'das', 'dos', 'e', 'em', 'no', 'na',
        'nos', 'nas', 'um', 'uma', 'uns', 'umas', 'para', 'por', 'com', 'sem', 'que',
        'meu', 'minha', 'meus', 'minhas', 'tenho', 'preciso', 'quero', 'favor', 'ajuda',
        'problema', 'erro', 'falha', 'nao', 'esta', 'estou', 'sou', 'ao', 'aos',
    ];

    private const TERM_SYNONYMS = [
        'vpn' => ['vpn', 'forticlient', 'forti', 'remoto', 'mfa', 'token', 'conexao', 'conecta', 'autenticacao'],
        'office' => ['office', 'office365', 'microsoft', 'm365', 'outlook', 'teams', 'onedrive', 'email', 'caixa', 'postal'],
        'impressora' => ['impressora', 'scanner', 'multifuncional', 'imprimir', 'impressao', 'toner', 'fila'],
        'senha' => ['senha', 'login', 'conta', 'bloqueado', 'bloqueada', 'expirada', 'trocar', 'reset'],
        'certificado' => ['certificado', 'assinatura', 'token', 'a1', 'a3', 'pje', 'sei'],
        'rede' => ['rede', 'internet', 'wifi', 'wi', 'fi', 'cabo', 'conexao', 'lento', 'instavel'],
        'glpi' => ['glpi', 'chamado', 'ticket', 'status', 'prazo', 'acompanhar', 'solicitacao'],
    ];

    /** @var TicketRepository */
    private $ticketRepository;
    /** @var PlaybookRepository */
    private $playbookRepository;
    /** @var AuditLogger */
    private $auditLogger;

    public function __construct(
        TicketRepository $ticketRepository,
        PlaybookRepository $playbookRepository,
        AuditLogger $auditLogger
    ) {
        $this->ticketRepository = $ticketRepository;
        $this->playbookRepository = $playbookRepository;
        $this->auditLogger = $auditLogger;
    }

    public function runInitialKnowledgeScan(array $options = []): array
    {
        $limit = min(200, max(10, (int) ($options['limit'] ?? 80)));
        $publicOnly = (bool) ($options['public_only'] ?? true);
        $jobId = $this->playbookRepository->createJob('kb_initial', [
            'source_scope' => $publicOnly ? 'kb_public' : 'kb_profile',
            'limit' => $limit,
            'public_only' => $publicOnly,
        ]);

        $processed = 0;
        $suggestions = 0;

        try {
            $articles = $this->ticketRepository->scanKnowledgeArticles($publicOnly, $limit);
            foreach ($articles as $article) {
                $processed++;
                $payload = $this->suggestionFromKnowledgeArticle($article);
                if ($payload === null) {
                    continue;
                }

                $this->playbookRepository->createSuggestion($jobId, $payload);
                $suggestions++;
            }

            $this->playbookRepository->finishJob(
                $jobId,
                'completed',
                $processed,
                $suggestions,
                'Varredura inicial da base concluída.'
            );
            $this->auditLogger->log('chatbot.playbook.scan.kb_initial', [
                'processed' => $processed,
                'suggestions' => $suggestions,
                'public_only' => $publicOnly,
            ]);

            return [
                'job_id' => $jobId,
                'processed' => $processed,
                'suggestions' => $suggestions,
                'status' => 'completed',
            ];
        } catch (\Throwable $e) {
            $this->playbookRepository->finishJob($jobId, 'failed', $processed, $suggestions, get_class($e));
            $this->auditLogger->log('chatbot.playbook.scan.failed', [
                'job_id' => $jobId,
                'error' => get_class($e),
            ]);

            return [
                'job_id' => $jobId,
                'processed' => $processed,
                'suggestions' => $suggestions,
                'status' => 'failed',
            ];
        }
    }

    public function listPendingSuggestions(int $limit = 80): array
    {
        return $this->playbookRepository->listSuggestions('pending', $limit);
    }

    public function listApprovedPlaybooks(int $limit = 120): array
    {
        return $this->playbookRepository->listPlaybooks($limit);
    }

    public function updateSuggestion(int $id, array $input): bool
    {
        $existing = $this->playbookRepository->getSuggestion($id);
        if ($existing === null || (string) ($existing['status'] ?? '') !== 'pending') {
            return false;
        }

        $payload = $this->playbookPayloadFromInput($input, $existing);
        $payload['title'] = $payload['name'];
        $payload['confidence'] = (float) ($existing['confidence'] ?? 0.7);

        $updated = $this->playbookRepository->updateSuggestion($id, $payload);
        if ($updated) {
            $this->auditLogger->log('chatbot.playbook.suggestion.updated', [
                'author_user_id' => (int) ($_SESSION['glpiID'] ?? 0),
                'suggestion_id' => $id,
                'kb_articles_count' => count((array) ($payload['kb_articles'] ?? [])),
            ]);
        }

        return $updated;
    }

    public function approveSuggestion(int $id): ?int
    {
        $playbookId = $this->playbookRepository->approveSuggestion($id);
        if ($playbookId !== null) {
            $this->auditLogger->log('chatbot.playbook.approved', [
                'author_user_id' => (int) ($_SESSION['glpiID'] ?? 0),
                'suggestion_id' => $id,
                'playbook_id' => $playbookId,
            ]);
        }

        return $playbookId;
    }

    public function rejectSuggestion(int $id): bool
    {
        $result = $this->playbookRepository->rejectSuggestion($id);
        if ($result) {
            $this->auditLogger->log('chatbot.playbook.rejected', [
                'author_user_id' => (int) ($_SESSION['glpiID'] ?? 0),
                'suggestion_id' => $id,
            ]);
        }

        return $result;
    }

    public function importApprovedPlaybooks(array $items): int
    {
        $result = $this->importPlaybooks($items, 'active');
        $count = (int) $result['active'] + (int) $result['inactive'];

        return $count;
    }

    public function importPlaybooks(array $items, string $defaultStatus = 'active'): array
    {
        $result = $this->playbookRepository->importPlaybooks($items, $defaultStatus);
        $this->auditLogger->log('chatbot.playbook.imported', [
            'author_user_id' => (int) ($_SESSION['glpiID'] ?? 0),
            'active' => (int) ($result['active'] ?? 0),
            'inactive' => (int) ($result['inactive'] ?? 0),
            'pending' => (int) ($result['pending'] ?? 0),
            'skipped' => (int) ($result['skipped'] ?? 0),
        ]);

        return $result;
    }

    public function createPlaybook(array $input): array
    {
        $status = $this->normalizeStatus((string) ($input['status'] ?? 'active'));
        $payload = $this->playbookPayloadFromInput($input);

        if ($payload['name'] === '') {
            return ['status' => 'invalid', 'id' => 0];
        }

        if ($status === 'pending') {
            $suggestionId = $this->playbookRepository->createSuggestion(0, [
                'source_type' => 'manual',
                'title' => $payload['name'],
                'intent' => $payload['intent'],
                'confidence' => 0.7,
                'keywords' => $payload['keywords'],
                'questions' => $payload['questions'],
                'kb_articles' => $payload['kb_articles'],
                'category_hint' => $payload['category_hint'],
                'group_hint' => $payload['group_hint'],
                'ticket_template' => $payload['ticket_template'],
                'content' => $payload['content'],
                'status' => 'pending',
            ]);
            $this->auditLogger->log('chatbot.playbook.created_pending', [
                'author_user_id' => (int) ($_SESSION['glpiID'] ?? 0),
                'suggestion_id' => $suggestionId,
            ]);

            return ['status' => 'pending', 'id' => $suggestionId];
        }

        $playbookId = $this->playbookRepository->createPlaybook($payload, $status === 'active');
        $this->auditLogger->log('chatbot.playbook.created', [
            'author_user_id' => (int) ($_SESSION['glpiID'] ?? 0),
            'playbook_id' => $playbookId,
            'status' => $status,
            'kb_articles_count' => count($payload['kb_articles']),
        ]);

        return ['status' => $status, 'id' => $playbookId];
    }

    public function updatePlaybook(int $id, array $input): bool
    {
        $existing = $this->playbookRepository->getPlaybook($id);
        if ($existing === null) {
            return false;
        }

        $status = $this->normalizeStatus((string) ($input['status'] ?? 'active'));
        if ($status === 'pending') {
            return $this->returnPlaybookToPending($id);
        }

        $payload = $this->playbookPayloadFromInput($input, $existing);
        $payload['is_active'] = $status === 'active' ? 1 : 0;

        $updated = $this->playbookRepository->updatePlaybook($id, $payload);
        if ($updated) {
            $this->auditLogger->log('chatbot.playbook.updated', [
                'author_user_id' => (int) ($_SESSION['glpiID'] ?? 0),
                'playbook_id' => $id,
                'status' => $status,
                'kb_articles_count' => count((array) ($payload['kb_articles'] ?? [])),
            ]);
        }

        return $updated;
    }

    public function deletePlaybook(int $id): bool
    {
        $deleted = $this->playbookRepository->deletePlaybook($id);
        if ($deleted) {
            $this->auditLogger->log('chatbot.playbook.deleted', [
                'author_user_id' => (int) ($_SESSION['glpiID'] ?? 0),
                'playbook_id' => $id,
            ]);
        }

        return $deleted;
    }

    public function returnPlaybookToPending(int $id): bool
    {
        $existing = $this->playbookRepository->getPlaybook($id);
        if ($existing === null) {
            return false;
        }

        $suggestionId = $this->playbookRepository->createSuggestion(0, [
            'source_type' => 'manual_review',
            'title' => (string) ($existing['name'] ?? ''),
            'intent' => (string) ($existing['intent'] ?? 'kb_recomendar_contextual'),
            'confidence' => 0.7,
            'keywords' => (array) ($existing['keywords'] ?? []),
            'questions' => (array) ($existing['questions'] ?? []),
            'kb_articles' => (array) ($existing['kb_articles'] ?? []),
            'category_hint' => (string) ($existing['category_hint'] ?? ''),
            'group_hint' => (string) ($existing['group_hint'] ?? ''),
            'ticket_template' => (array) ($existing['ticket_template'] ?? []),
            'content' => (array) ($existing['content'] ?? []),
            'status' => 'pending',
        ]);

        $deleted = $this->playbookRepository->deletePlaybook($id);
        if ($deleted) {
            $this->auditLogger->log('chatbot.playbook.returned_to_pending', [
                'author_user_id' => (int) ($_SESSION['glpiID'] ?? 0),
                'playbook_id' => $id,
                'suggestion_id' => $suggestionId,
            ]);
        }

        return $deleted;
    }

    public function exportApprovedPlaybooks(): array
    {
        return $this->playbookRepository->exportApprovedPlaybooks();
    }

    public function matchApprovedPlaybook(string $text, string $intent = ''): ?array
    {
        $normalized = $this->normalize($text);
        if ($normalized === '') {
            return null;
        }

        $terms = $this->meaningfulTerms($normalized);
        $expandedTerms = $this->expandTerms($terms);
        $best = null;
        $bestScore = 0.0;

        foreach ($this->playbookRepository->listActivePlaybooks(200) as $playbook) {
            if ($intent !== '' && trim((string) ($playbook['intent'] ?? '')) !== $intent) {
                continue;
            }

            $keywords = $this->normalizedList($this->playbookSearchTerms($playbook));
            $questions = $this->normalizedList((array) ($playbook['questions'] ?? []));
            $score = $this->scoreMatch($normalized, $terms, $expandedTerms, $keywords, $questions);
            if ($score > $bestScore) {
                $bestScore = $score;
                $best = $playbook;
            }
        }

        if ($best === null || $bestScore < 0.28) {
            return null;
        }

        $best['match_score'] = round($bestScore, 2);
        $best['match_terms'] = array_slice($terms, 0, 8);
        return $best;
    }

    private function suggestionFromKnowledgeArticle(array $article): ?array
    {
        $title = TextNormalizer::fromGlpi((string) ($article['name'] ?? ''));
        if ($title === '') {
            return null;
        }

        $content = TextNormalizer::fromGlpi((string) ($article['content_text'] ?? $article['answer_text'] ?? $article['answer'] ?? ''));
        $summary = trim(mb_substr($content, 0, 500, 'UTF-8'));
        $keywords = $this->extractKeywords($title . ' ' . $content);
        if ($keywords === []) {
            $keywords = $this->terms($this->normalize($title));
        }

        return [
            'source_type' => 'kb',
            'title' => $title,
            'intent' => 'kb_recomendar_contextual',
            'confidence' => 0.75,
            'keywords' => array_slice($keywords, 0, 18),
            'questions' => [
                'Como resolver ' . $title . '?',
                'Tenho problema com ' . $title,
                'Preciso de orientação sobre ' . $title,
            ],
            'kb_articles' => [[
                'id' => (int) ($article['id'] ?? 0),
                'name' => $title,
            ]],
            'category_hint' => (string) ($article['category'] ?? ''),
            'content' => [
                'answer_summary' => $summary,
                'source_date_mod' => (string) ($article['date_mod'] ?? ''),
                'source_type' => 'knowledge_base',
            ],
        ];
    }

    private function extractKeywords(string $text): array
    {
        $stopwords = [
            'para', 'pela', 'pelo', 'com', 'sem', 'uma', 'umas', 'uns', 'dos', 'das', 'que',
            'como', 'sobre', 'esse', 'essa', 'este', 'esta', 'voce', 'usuario', 'glpi',
            'base', 'conhecimento', 'artigo', 'faq', 'problema', 'orientacao',
        ];

        $terms = $this->terms($this->normalize($text));
        $terms = array_values(array_filter($terms, static function (string $term) use ($stopwords): bool {
            return strlen($term) >= 4 && !in_array($term, $stopwords, true);
        }));

        $counts = [];
        foreach ($terms as $term) {
            $counts[$term] = ($counts[$term] ?? 0) + 1;
        }
        arsort($counts);

        return array_keys($counts);
    }

    private function scoreMatch(string $normalized, array $terms, array $expandedTerms, array $keywords, array $questions): float
    {
        $terms = $this->textList($terms);
        $expandedTerms = $this->textList($expandedTerms);
        $keywords = $this->textList($keywords);
        $questions = $this->textList($questions);

        $score = 0.0;
        foreach ($questions as $question) {
            if ($question !== '' && (str_contains($normalized, $question) || str_contains($question, $normalized))) {
                $score += $normalized === $question ? 0.75 : 0.55;
            }
        }

        $keywordHits = 0;
        $phrasePartialHits = 0;
        $documentTerms = [];
        foreach ($keywords as $keyword) {
            if ($keyword === '') {
                continue;
            }

            $keywordTerms = $this->meaningfulTerms($keyword);
            foreach ($keywordTerms as $term) {
                $documentTerms[$this->stemTerm($term)] = true;
            }

            if (in_array($keyword, $terms, true) || str_contains($normalized, $keyword) || str_contains($keyword, $normalized)) {
                $keywordHits++;
                continue;
            }

            $phraseHits = 0;
            foreach ($keywordTerms as $term) {
                $stem = $this->stemTerm($term);
                if (
                    in_array($term, $expandedTerms, true)
                    || in_array($stem, $expandedTerms, true)
                    || $this->fuzzyTermHit($term, $expandedTerms)
                ) {
                    $keywordHits++;
                    $phraseHits++;
                }
            }

            if ($phraseHits >= 2) {
                $phrasePartialHits++;
            }
        }

        if ($keywordHits > 0) {
            $score += min(0.78, 0.32 + (($keywordHits - 1) * 0.12));
            $coverage = $keywordHits / max(1, min(count($documentTerms), 8));
            $score += min(0.28, $coverage * 0.28);
        }

        if ($phrasePartialHits > 0) {
            $score += min(0.18, $phrasePartialHits * 0.06);
        }

        $queryHits = 0;
        $documentTermList = array_keys($documentTerms);
        foreach ($terms as $term) {
            $stem = $this->stemTerm($term);
            if (
                isset($documentTerms[$stem])
                || isset($documentTerms[$term])
                || $this->fuzzyTermHit($term, $documentTermList)
            ) {
                $queryHits++;
            }
        }

        if ($terms !== [] && $queryHits > 0) {
            $score += min(0.24, ($queryHits / max(1, count($terms))) * 0.24);
        }

        return min(1.0, $score);
    }

    /**
     * Build searchable evidence from the approved roteiro itself.
     * This keeps chatbot routing data-driven instead of hardcoded by topic.
     */
    private function playbookSearchTerms(array $playbook): array
    {
        $terms = [];
        $this->collectTextValues((array) ($playbook['keywords'] ?? []), $terms);
        $this->collectTextValues((array) ($playbook['questions'] ?? []), $terms);
        foreach (['name', 'category_hint', 'group_hint'] as $field) {
            $value = trim((string) ($playbook[$field] ?? ''));
            if ($value !== '') {
                $terms[] = $value;
            }
        }

        foreach ((array) ($playbook['kb_articles'] ?? []) as $article) {
            if (!is_array($article)) {
                continue;
            }

            $id = (int) ($article['id'] ?? 0);
            $name = trim((string) ($article['name'] ?? ''));
            if ($id > 0) {
                $terms[] = 'artigo ' . $id;
            }
            if ($name !== '') {
                $terms[] = $name;
            }
        }

        $this->collectTextValues((array) ($playbook['content'] ?? []), $terms);
        $this->collectTextValues((array) ($playbook['ticket_template'] ?? []), $terms);

        return $terms;
    }

    private function collectTextValues(array $values, array &$terms): void
    {
        foreach ($values as $value) {
            if (is_array($value)) {
                $this->collectTextValues($value, $terms);
                continue;
            }

            if (is_scalar($value) && !is_bool($value)) {
                $text = trim((string) $value);
                if ($text !== '') {
                    $terms[] = $text;
                }
            }
        }
    }

    private function textList(array $items): array
    {
        $texts = [];
        $this->collectTextValues($items, $texts);

        $result = [];
        foreach ($texts as $text) {
            $value = trim((string) $text);
            if ($value === '') {
                continue;
            }
            // IDs isolados e flags numericas nao ajudam o matcher semantico.
            if (ctype_digit($value) && strlen($value) < 3) {
                continue;
            }
            $result[] = $value;
        }

        return array_values(array_unique($result));
    }

    private function normalizedList(array $items): array
    {
        $normalized = [];
        foreach ($this->textList($items) as $item) {
            $value = $this->normalize($item);
            if ($value !== '') {
                $normalized[] = $value;
            }
        }

        return array_values(array_unique($normalized));
    }

    private function normalize(string $text): string
    {
        $text = TextNormalizer::fromGlpi($text);
        $text = mb_strtolower($text, 'UTF-8');
        $converted = iconv('UTF-8', 'ASCII//TRANSLIT//IGNORE', $text);
        if (is_string($converted)) {
            $text = $converted;
        }
        $text = preg_replace('/[^a-z0-9\s]+/i', ' ', $text) ?? $text;
        return trim(preg_replace('/\s+/', ' ', $text) ?? $text);
    }

    private function terms(string $normalized): array
    {
        if ($normalized === '') {
            return [];
        }

        return array_values(array_unique(array_filter(explode(' ', $normalized))));
    }

    private function meaningfulTerms(string $normalized): array
    {
        return array_values(array_filter($this->terms($normalized), static function (string $term): bool {
            return strlen($term) >= 2 && !in_array($term, self::MATCH_STOPWORDS, true);
        }));
    }

    private function expandTerms(array $terms): array
    {
        $expanded = [];
        foreach ($this->textList($terms) as $term) {
            $term = $this->normalize($term);
            if ($term === '') {
                continue;
            }
            $expanded[] = $term;
            $expanded[] = $this->stemTerm($term);

            foreach (self::TERM_SYNONYMS as $canonical => $synonyms) {
                if ($term === $canonical || in_array($term, $synonyms, true)) {
                    $expanded[] = $canonical;
                    foreach ($synonyms as $synonym) {
                        $expanded[] = $synonym;
                        $expanded[] = $this->stemTerm($synonym);
                    }
                }
            }
        }

        return array_values(array_unique(array_filter($expanded)));
    }

    private function stemTerm(string $term): string
    {
        $term = trim($term);
        if ($term === '') {
            return '';
        }

        $suffixes = ['mente', 'idades', 'idade', 'acoes', 'acao', 'coes', 'ando', 'endo', 'indo', 'ados', 'adas', 'ado', 'ada', 'icos', 'icas', 'ico', 'ica', 's'];
        foreach ($suffixes as $suffix) {
            if (strlen($term) > strlen($suffix) + 3 && substr($term, -strlen($suffix)) === $suffix) {
                return substr($term, 0, -strlen($suffix));
            }
        }

        return $term;
    }

    private function fuzzyTermHit(string $term, array $expandedTerms): bool
    {
        $term = trim($term);
        if ($term === '' || strlen($term) < 5) {
            return false;
        }

        foreach ($this->textList($expandedTerms) as $candidate) {
            $candidate = trim($candidate);
            if ($candidate === '' || strlen($candidate) < 5 || abs(strlen($candidate) - strlen($term)) > 2) {
                continue;
            }

            if (levenshtein($term, $candidate) <= 1) {
                return true;
            }

            similar_text($term, $candidate, $percent);
            if ($percent >= 86.0) {
                return true;
            }
        }

        return false;
    }

    private function listFromInput($value): array
    {
        if (is_array($value)) {
            $items = $value;
        } else {
            $items = preg_split('/[\r\n,;]+/', (string) $value) ?: [];
        }

        return array_values(array_filter(array_map(static function ($item): string {
            return trim((string) $item);
        }, $items), static function (string $item): bool {
            return $item !== '';
        }));
    }

    private function playbookPayloadFromInput(array $input, array $existing = []): array
    {
        $content = (array) ($existing['content'] ?? []);
        foreach (
            [
            'answer_summary' => 'answer_summary',
            'first_steps' => 'first_steps',
            'when_open_ticket' => 'when_open_ticket',
            'required_data' => 'required_data',
            ] as $inputKey => $contentKey
        ) {
            if (!array_key_exists($inputKey, $input)) {
                continue;
            }
            $value = trim((string) ($input[$inputKey] ?? ''));
            if ($value !== '') {
                $content[$contentKey] = $value;
            } else {
                unset($content[$contentKey]);
            }
        }

        return [
            'name' => trim((string) ($input['name'] ?? '')),
            'intent' => trim((string) ($input['intent'] ?? 'kb_recomendar_contextual')),
            'keywords' => $this->listFromInput($input['keywords'] ?? []),
            'questions' => $this->listFromInput($input['questions'] ?? []),
            'kb_articles' => $this->kbArticlesFromInput($input['kb_articles'] ?? ($existing['kb_articles'] ?? [])),
            'category_hint' => trim((string) ($input['category_hint'] ?? '')),
            'group_hint' => trim((string) ($input['group_hint'] ?? '')),
            'ticket_template' => (array) ($existing['ticket_template'] ?? []),
            'content' => $content,
        ];
    }

    private function kbArticlesFromInput($value): array
    {
        if (is_array($value)) {
            $items = $value;
        } else {
            $items = preg_split('/[\r\n]+/', (string) $value) ?: [];
        }

        $articles = [];
        foreach ($items as $item) {
            if (is_array($item)) {
                $id = (int) ($item['id'] ?? 0);
                $name = trim((string) ($item['name'] ?? ''));
            } else {
                $line = trim((string) $item);
                if ($line === '') {
                    continue;
                }
                $parts = preg_split('/\s*[|;-]\s*/', $line, 2) ?: [$line];
                $id = ctype_digit((string) ($parts[0] ?? '')) ? (int) $parts[0] : 0;
                $name = $id > 0 ? trim((string) ($parts[1] ?? '')) : $line;
            }

            if ($id <= 0 && $name === '') {
                continue;
            }

            $articles[] = [
                'id' => $id,
                'name' => $name,
            ];
            if (count($articles) >= 20) {
                break;
            }
        }

        return $articles;
    }

    private function normalizeStatus(string $status): string
    {
        $status = strtolower(trim($status));
        if (in_array($status, ['pending', 'pendente', 'review', 'analise'], true)) {
            return 'pending';
        }
        if (in_array($status, ['inactive', 'inativo', 'disabled', '0'], true)) {
            return 'inactive';
        }

        return 'active';
    }
}
