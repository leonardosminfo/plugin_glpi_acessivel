<?php

declare(strict_types=1);

namespace GlpiPlugin\Glpiacessivel\Application;

use GlpiPlugin\Glpiacessivel\Support\I18n;
use GlpiPlugin\Glpiacessivel\Support\Url;

final class ConfigService
{
    public const DEFAULT_CHATBOT_DISPLAY_NAME = 'Assistente';
    private const LEGACY_CHATBOT_DISPLAY_NAME = 'Ti' . 'Ajuda';
    public const CHATBOT_DISPLAY_NAME_MAX_LENGTH = 60;
    public const MODULE_TICKET_CREATE = 'ticket_create';
    public const MODULE_FORMS = 'forms';
    public const MODULE_TICKETS = 'tickets';
    public const MODULE_COCKPIT = 'cockpit';
    public const MODULE_KNOWLEDGE = 'knowledge';
    public const MODULE_CHATBOT = 'chatbot';
    public const MODULE_PLAYBOOKS = 'playbooks';
    public const PORTAL_MODULES = [
        self::MODULE_TICKET_CREATE,
        self::MODULE_FORMS,
        self::MODULE_TICKETS,
        self::MODULE_COCKPIT,
        self::MODULE_KNOWLEDGE,
        self::MODULE_CHATBOT,
        self::MODULE_PLAYBOOKS,
    ];
    public const MODULE_STATE_AVAILABLE = 'available';
    public const MODULE_STATE_HIDDEN = 'hidden';
    public const MODULE_STATE_DISABLED = 'disabled';
    public const MODULE_STATES = [
        self::MODULE_STATE_AVAILABLE,
        self::MODULE_STATE_HIDDEN,
        self::MODULE_STATE_DISABLED,
    ];
    public const MODULE_PRESETS = [
        'complete' => [
            self::MODULE_TICKET_CREATE => self::MODULE_STATE_AVAILABLE,
            self::MODULE_FORMS => self::MODULE_STATE_AVAILABLE,
            self::MODULE_TICKETS => self::MODULE_STATE_AVAILABLE,
            self::MODULE_COCKPIT => self::MODULE_STATE_AVAILABLE,
            self::MODULE_KNOWLEDGE => self::MODULE_STATE_AVAILABLE,
            self::MODULE_CHATBOT => self::MODULE_STATE_AVAILABLE,
            self::MODULE_PLAYBOOKS => self::MODULE_STATE_AVAILABLE,
        ],
        'presentation_basic' => [
            self::MODULE_TICKET_CREATE => self::MODULE_STATE_DISABLED,
            self::MODULE_FORMS => self::MODULE_STATE_DISABLED,
            self::MODULE_TICKETS => self::MODULE_STATE_DISABLED,
            self::MODULE_COCKPIT => self::MODULE_STATE_DISABLED,
            self::MODULE_KNOWLEDGE => self::MODULE_STATE_AVAILABLE,
            self::MODULE_CHATBOT => self::MODULE_STATE_AVAILABLE,
            self::MODULE_PLAYBOOKS => self::MODULE_STATE_HIDDEN,
        ],
        'read_only_demo' => [
            self::MODULE_TICKET_CREATE => self::MODULE_STATE_DISABLED,
            self::MODULE_FORMS => self::MODULE_STATE_DISABLED,
            self::MODULE_TICKETS => self::MODULE_STATE_AVAILABLE,
            self::MODULE_COCKPIT => self::MODULE_STATE_AVAILABLE,
            self::MODULE_KNOWLEDGE => self::MODULE_STATE_AVAILABLE,
            self::MODULE_CHATBOT => self::MODULE_STATE_AVAILABLE,
            self::MODULE_PLAYBOOKS => self::MODULE_STATE_HIDDEN,
        ],
        'self_service_pilot' => [
            self::MODULE_TICKET_CREATE => self::MODULE_STATE_AVAILABLE,
            self::MODULE_FORMS => self::MODULE_STATE_AVAILABLE,
            self::MODULE_TICKETS => self::MODULE_STATE_AVAILABLE,
            self::MODULE_COCKPIT => self::MODULE_STATE_HIDDEN,
            self::MODULE_KNOWLEDGE => self::MODULE_STATE_AVAILABLE,
            self::MODULE_CHATBOT => self::MODULE_STATE_AVAILABLE,
            self::MODULE_PLAYBOOKS => self::MODULE_STATE_HIDDEN,
        ],
        'technical_pilot' => [
            self::MODULE_TICKET_CREATE => self::MODULE_STATE_HIDDEN,
            self::MODULE_FORMS => self::MODULE_STATE_HIDDEN,
            self::MODULE_TICKETS => self::MODULE_STATE_AVAILABLE,
            self::MODULE_COCKPIT => self::MODULE_STATE_AVAILABLE,
            self::MODULE_KNOWLEDGE => self::MODULE_STATE_AVAILABLE,
            self::MODULE_CHATBOT => self::MODULE_STATE_AVAILABLE,
            self::MODULE_PLAYBOOKS => self::MODULE_STATE_HIDDEN,
        ],
    ];
    public const ACCESSIBILITY_MODE_PORTAL = 'portal';
    public const ACCESSIBILITY_MODE_EMBEDDED = 'embedded';
    public const ACCESSIBILITY_MODE_HYBRID = 'hybrid';
    public const AUTHENTICATION_ENTRY_NATIVE_ONLY = 'native_only';
    public const AUTHENTICATION_ENTRY_ACCESSIBLE_BRIDGE = 'accessible_bridge';
    public const AUTHENTICATION_ENTRY_STRICT_AUTHENTICATED_PORTAL = 'strict_authenticated_portal';
    public const AUTHENTICATION_ENTRY_KNOWN_MODES = [
        self::AUTHENTICATION_ENTRY_NATIVE_ONLY,
        self::AUTHENTICATION_ENTRY_ACCESSIBLE_BRIDGE,
        self::AUTHENTICATION_ENTRY_STRICT_AUTHENTICATED_PORTAL,
    ];
    public const AUTHENTICATION_ENTRY_SUPPORTED_MODES = [
        self::AUTHENTICATION_ENTRY_NATIVE_ONLY,
        self::AUTHENTICATION_ENTRY_ACCESSIBLE_BRIDGE,
    ];
    public const CHATBOT_INTENTS = [
        'mine_tickets',
        'ticket_lookup',
        'ticket_criar_guiado',
        'ticket_triagem_inicial',
        'ticket_escalonar',
        'ticket_reclassificar',
        'ticket_priorizar',
        'ticket_sla_status',
        'ticket_followup_operacional',
        'ticket_encerrar_com_validacao',
        'kb_recomendar_contextual',
        'comunicacao_usuario',
        'auditoria_consulta',
        'handoff_humano',
    ];
    public const CHATBOT_STT_ENGINES = ['vosklet', 'none'];
    public const CHATBOT_TTS_ENGINES = ['browser_native', 'piper_wasm', 'none'];
    public const CHATBOT_FLOATING_SCOPES = ['plugin_only', 'all_logged_pages', 'disabled'];
    public const CHATBOT_VOICE_ASSET_MODES = ['local_preferred', 'local_only', 'external_only'];
    public const FORMS_NATIVE_FLOW_EMBEDDED = 'native_embedded';
    public const FORMS_NATIVE_FLOW_EMBEDDED_MINIMAL = 'native_embedded_minimal';
    public const FORMS_NATIVE_FLOW_LINK = 'native_link';
    public const FORMS_NATIVE_FLOW_PLUGIN_CONVERTED_CALLBACK = 'plugin_converted_with_native_callback';
    public const FORMS_NATIVE_FLOW_MODES = [
        self::FORMS_NATIVE_FLOW_EMBEDDED,
        self::FORMS_NATIVE_FLOW_EMBEDDED_MINIMAL,
        self::FORMS_NATIVE_FLOW_LINK,
        self::FORMS_NATIVE_FLOW_PLUGIN_CONVERTED_CALLBACK,
    ];
    public const SUPPORTED_LOCALES = ['pt_BR', 'en_GB'];
    public const VLIBRAS_SCOPES = ['disabled', 'public_only', 'plugin_pages', 'all_pages'];
    public const TICKET_LIST_CAPACITY_BACKENDS = ['apcu', 'external'];
    public const TICKET_LIST_CAPACITY_MAX_CONCURRENT_MIN = 1;
    public const TICKET_LIST_CAPACITY_MAX_CONCURRENT_MAX = 10;
    public const TICKET_LIST_CAPACITY_MAX_CONCURRENT_DEFAULT = 2;
    public const TICKET_LIST_CAPACITY_LEASE_SECONDS_MIN = 8;
    public const TICKET_LIST_CAPACITY_LEASE_SECONDS_MAX = 30;
    public const TICKET_LIST_CAPACITY_LEASE_SECONDS_DEFAULT = 8;
    public const TICKET_LIST_CAPACITY_RETRY_AFTER_MIN = 1;
    public const TICKET_LIST_CAPACITY_RETRY_AFTER_MAX = 60;
    public const TICKET_LIST_CAPACITY_RETRY_AFTER_DEFAULT = 5;
    public const TICKET_LIST_RATE_LIMIT_MIN = 1;
    public const TICKET_LIST_RATE_LIMIT_MAX = 30;
    public const TICKET_LIST_RATE_LIMIT_DEFAULT = 30;
    public const TICKET_LIST_RATE_WINDOW_MIN = 10;
    public const TICKET_LIST_RATE_WINDOW_MAX = 300;
    public const TICKET_LIST_RATE_WINDOW_DEFAULT = 60;
    public const TICKET_LIST_RATE_BURST_MIN = 1;
    public const TICKET_LIST_RATE_BURST_MAX = 5;
    public const TICKET_LIST_RATE_BURST_DEFAULT = 5;
    public const AUDIT_RETENTION_BATCH_SIZE_MIN = 100;
    public const AUDIT_RETENTION_BATCH_SIZE_MAX = 5000;
    public const AUDIT_RETENTION_BATCH_SIZE_DEFAULT = 500;
    public const AUDIT_MODE_FULL = 'full';
    public const AUDIT_MODE_CRITICAL = 'critical';
    public const AUDIT_MODE_DISABLED = 'disabled';
    public const AUDIT_MODES = [
        self::AUDIT_MODE_FULL,
        self::AUDIT_MODE_CRITICAL,
        self::AUDIT_MODE_DISABLED,
    ];
    private const DEFAULT_STT_SCRIPT_EXTERNAL_URL = 'https://cdn.jsdelivr.net/gh/msqr1/Vosklet@1.2.1/Examples/Vosklet.js';
    private const DEFAULT_STT_MODEL_EXTERNAL_URL = 'https://alphacephei.com/vosk/models/vosk-model-small-pt-0.3.zip';
    private const DEFAULT_TTS_SCRIPT_EXTERNAL_URL = 'https://esm.run/@mintplex-labs/piper-tts-web';
    private const DEFAULT_STT_SCRIPT_LOCAL_PATH = 'public/assets/vendor/vosklet/Vosklet.js';
    private const DEFAULT_STT_MODEL_LOCAL_PATH = 'public/assets/voice/vosk/pt-BR/vosk-model-small-pt-0.3.zip';
    private const DEFAULT_TTS_SCRIPT_LOCAL_PATH = 'public/assets/vendor/piper/piper-tts-web.js';
    private const LEGACY_TTS_SCRIPT_LOCAL_PATH = 'public/assets/vendor/piper/piper-tts-web.mjs';
    private const DEFAULT_TTS_ONNX_RUNTIME_LOCAL_PATH = 'public/assets/vendor/onnxruntime-web/1.18.0/ort.esm.js';
    private const LEGACY_TTS_ONNX_RUNTIME_LOCAL_PATH_JS = 'public/assets/vendor/onnxruntime-web/1.18.0/ort.min.js';
    private const LEGACY_TTS_ONNX_RUNTIME_LOCAL_PATH_MJS = 'public/assets/vendor/onnxruntime-web/1.18.0/ort.min.mjs';
    private const DEFAULT_TTS_ONNX_WASM_LOCAL_PATH = 'public/assets/vendor/onnxruntime-web/1.18.0';
    private const DEFAULT_TTS_PIPER_WASM_LOCAL_PATH = 'public/assets/vendor/piper-wasm/1.0.0/piper_phonemize.wasm';
    private const DEFAULT_TTS_PIPER_DATA_LOCAL_PATH = 'public/assets/vendor/piper-wasm/1.0.0/piper_phonemize.data';
    private const DEFAULT_TTS_VOICE_MODEL_LOCAL_PATH = 'public/assets/voice/piper/pt-BR/faber-medium/pt_BR-faber-medium.onnx';
    private const DEFAULT_TTS_VOICE_CONFIG_LOCAL_PATH = 'public/assets/voice/piper/pt-BR/faber-medium/pt_BR-faber-medium.onnx.json';
    private const DEFAULT_TTS_ONNX_RUNTIME_EXTERNAL_URL = 'https://cdn.jsdelivr.net/npm/onnxruntime-web@1.18.0/+esm';
    private const DEFAULT_TTS_ONNX_WASM_EXTERNAL_URL = 'https://cdnjs.cloudflare.com/ajax/libs/onnxruntime-web/1.18.0/';
    private const DEFAULT_TTS_PIPER_WASM_EXTERNAL_URL = 'https://cdn.jsdelivr.net/npm/@diffusionstudio/piper-wasm@1.0.0/build/piper_phonemize.wasm';
    private const DEFAULT_TTS_PIPER_DATA_EXTERNAL_URL = 'https://cdn.jsdelivr.net/npm/@diffusionstudio/piper-wasm@1.0.0/build/piper_phonemize.data';

    public function migrateLegacyVoiceAssetPaths(): void
    {
        $pathMap = [
            'chatbot_stt_script_local_path' => self::DEFAULT_STT_SCRIPT_LOCAL_PATH,
            'chatbot_stt_model_local_path' => self::DEFAULT_STT_MODEL_LOCAL_PATH,
            'chatbot_tts_script_local_path' => self::DEFAULT_TTS_SCRIPT_LOCAL_PATH,
            'chatbot_tts_onnx_runtime_local_path' => self::DEFAULT_TTS_ONNX_RUNTIME_LOCAL_PATH,
            'chatbot_tts_onnx_wasm_local_path' => self::DEFAULT_TTS_ONNX_WASM_LOCAL_PATH,
            'chatbot_tts_piper_wasm_local_path' => self::DEFAULT_TTS_PIPER_WASM_LOCAL_PATH,
            'chatbot_tts_piper_data_local_path' => self::DEFAULT_TTS_PIPER_DATA_LOCAL_PATH,
            'chatbot_tts_voice_model_local_path' => self::DEFAULT_TTS_VOICE_MODEL_LOCAL_PATH,
            'chatbot_tts_voice_config_local_path' => self::DEFAULT_TTS_VOICE_CONFIG_LOCAL_PATH,
        ];

        foreach ($pathMap as $key => $default) {
            $current = $this->getValue($key, $default);
            $normalized = $this->normalizePluginRelativePath($current, $default);
            if ($normalized !== $current) {
                $this->setValue($key, $normalized);
            }
        }
    }

    public function migrateLegacyVoiceDefaults(): void
    {
        if ($this->getValue('chatbot_tts_browser_native_migration_applied', '0') === '1') {
            return;
        }

        if ($this->getValue('chatbot_tts_engine', 'piper_wasm') === 'piper_wasm') {
            $this->setValue('chatbot_tts_engine', 'browser_native');
        }

        $this->setValue('chatbot_tts_browser_native_migration_applied', '1');
    }

    public function isChatbotEnabled(): bool
    {
        return $this->getPortalModuleState(self::MODULE_CHATBOT) !== self::MODULE_STATE_DISABLED;
    }


    public function getChatbotDisplayName(): string
    {
        $name = $this->sanitizeChatbotDisplayName(
            $this->getValue('chatbot_display_name', self::DEFAULT_CHATBOT_DISPLAY_NAME)
        );

        return $name === self::LEGACY_CHATBOT_DISPLAY_NAME
            ? self::DEFAULT_CHATBOT_DISPLAY_NAME
            : $name;
    }

    public function sanitizeChatbotDisplayName(string $name): string
    {
        $name = strip_tags($name);
        $name = preg_replace('/[\x00-\x1F\x7F]+/u', ' ', $name) ?? '';
        $name = preg_replace('/[\x{061C}\x{200E}\x{200F}\x{202A}-\x{202E}\x{2066}-\x{2069}]/u', '', $name) ?? '';
        $name = trim(preg_replace('/\s+/u', ' ', $name) ?? '');
        if ($name === '') {
            return self::DEFAULT_CHATBOT_DISPLAY_NAME;
        }

        return function_exists('mb_substr')
            ? mb_substr($name, 0, self::CHATBOT_DISPLAY_NAME_MAX_LENGTH, 'UTF-8')
            : substr($name, 0, self::CHATBOT_DISPLAY_NAME_MAX_LENGTH);
    }

    public function getAccessibilityMode(): string
    {
        $mode = $this->getValue('accessibility_mode', self::ACCESSIBILITY_MODE_HYBRID);
        if ($mode === 'global') {
            return self::ACCESSIBILITY_MODE_EMBEDDED;
        }

        if (
            !in_array($mode, [
            self::ACCESSIBILITY_MODE_PORTAL,
            self::ACCESSIBILITY_MODE_EMBEDDED,
            self::ACCESSIBILITY_MODE_HYBRID,
            ], true)
        ) {
            return self::ACCESSIBILITY_MODE_HYBRID;
        }

        return $mode;
    }

    public function getAuthenticationEntryMode(): string
    {
        try {
            $mode = $this->getValue('authentication_entry_mode', self::AUTHENTICATION_ENTRY_NATIVE_ONLY);
        } catch (\Throwable $e) {
            return self::AUTHENTICATION_ENTRY_NATIVE_ONLY;
        }

        return $this->sanitizeAuthenticationEntryMode($mode);
    }

    public function sanitizeAuthenticationEntryMode(string $mode): string
    {
        $mode = trim($mode);
        return in_array($mode, self::AUTHENTICATION_ENTRY_SUPPORTED_MODES, true)
            ? $mode
            : self::AUTHENTICATION_ENTRY_NATIVE_ONLY;
    }

    public function isAccessibleLoginBridgeEnabled(): bool
    {
        return $this->getAuthenticationEntryMode() === self::AUTHENTICATION_ENTRY_ACCESSIBLE_BRIDGE;
    }

    public function isLoginAccessibilityNoticeEnabled(): bool
    {
        try {
            return $this->getValue('show_login_accessibility_notice', '0') === '1';
        } catch (\Throwable $e) {
            return false;
        }
    }

    public function getAuditRetentionDays(): int
    {
        $days = (int) $this->getValue('audit_retention_days', '365');
        return min(3650, max(30, $days));
    }

    public function getAuditRetentionBatchSize(): int
    {
        return $this->getBoundedIntConfig(
            'audit_retention_batch_size',
            self::AUDIT_RETENTION_BATCH_SIZE_DEFAULT,
            self::AUDIT_RETENTION_BATCH_SIZE_MIN,
            self::AUDIT_RETENTION_BATCH_SIZE_MAX
        );
    }

    public function getAuditMode(): string
    {
        try {
            $mode = trim($this->getValue('audit_mode', self::AUDIT_MODE_CRITICAL));
        } catch (\Throwable) {
            return self::AUDIT_MODE_CRITICAL;
        }

        return in_array($mode, self::AUDIT_MODES, true)
            ? $mode
            : self::AUDIT_MODE_CRITICAL;
    }

    public function isAuditDisabledAllowed(): bool
    {
        return defined('GLPIACESSIVEL_ALLOW_AUDIT_DISABLED')
            && constant('GLPIACESSIVEL_ALLOW_AUDIT_DISABLED') === true;
    }

    public function sanitizeAuditMode(string $mode, ?string $fallback = null): string
    {
        $fallback = in_array($fallback, self::AUDIT_MODES, true)
            ? (string) $fallback
            : self::AUDIT_MODE_CRITICAL;
        if (!in_array($mode, self::AUDIT_MODES, true)) {
            return $fallback;
        }
        if ($mode === self::AUDIT_MODE_DISABLED && !$this->isAuditDisabledAllowed()) {
            return $fallback;
        }

        return $mode;
    }

    public function getPluginFallbackLocale(): string
    {
        $value = $this->normalizeLocale($this->getValue('plugin_fallback_locale', I18n::FALLBACK_LOCALE));
        return in_array($value, self::SUPPORTED_LOCALES, true) ? $value : I18n::FALLBACK_LOCALE;
    }

    public function getVlibrasScope(): string
    {
        $value = $this->getValue('vlibras_scope', 'plugin_pages');
        return in_array($value, self::VLIBRAS_SCOPES, true) ? $value : 'plugin_pages';
    }

    public function isFormsEnabled(): bool
    {
        return $this->getPortalModuleState(self::MODULE_FORMS) !== self::MODULE_STATE_DISABLED;
    }

    public function getPortalModuleState(string $module): string
    {
        if (!in_array($module, self::PORTAL_MODULES, true)) {
            return self::MODULE_STATE_DISABLED;
        }

        $configured = trim($this->getValue('module_' . $module . '_state', ''));
        if (in_array($configured, self::MODULE_STATES, true)) {
            return $configured;
        }

        if ($module === self::MODULE_FORMS && $this->getValue('forms_enabled', '1') === '0') {
            return self::MODULE_STATE_DISABLED;
        }

        if ($module === self::MODULE_CHATBOT && $this->getValue('chatbot_enabled', '1') === '0') {
            return self::MODULE_STATE_DISABLED;
        }

        return self::MODULE_STATE_AVAILABLE;
    }

    /** @return array<string, string> */
    public function getPortalModuleStates(): array
    {
        $states = [];
        foreach (self::PORTAL_MODULES as $module) {
            $states[$module] = $this->getPortalModuleState($module);
        }

        return $states;
    }

    /**
     * @param array<string, mixed> $states
     * @return array<string, string>
     */
    public function sanitizePortalModuleStates(array $states): array
    {
        $sanitized = [];
        foreach (self::PORTAL_MODULES as $module) {
            $state = (string) ($states[$module] ?? $this->getPortalModuleState($module));
            $sanitized[$module] = in_array($state, self::MODULE_STATES, true)
                ? $state
                : $this->getPortalModuleState($module);
        }

        return $sanitized;
    }

    /** @param array<string, mixed> $states */
    public function setPortalModuleStates(array $states): void
    {
        $states = $this->sanitizePortalModuleStates($states);
        foreach ($states as $module => $state) {
            $this->setValue('module_' . $module . '_state', $state);
        }

        $this->setValue('forms_enabled', $states[self::MODULE_FORMS] === self::MODULE_STATE_DISABLED ? '0' : '1');
        $this->setValue('chatbot_enabled', $states[self::MODULE_CHATBOT] === self::MODULE_STATE_DISABLED ? '0' : '1');
    }

    /** @return array<string, string> */
    public function getPortalModulePreset(string $preset): array
    {
        return self::MODULE_PRESETS[$preset] ?? self::MODULE_PRESETS['complete'];
    }

    public function isPiiMaskingEnabled(): bool
    {
        return $this->getValue('pii_masking_enabled', '0') === '1';
    }

    public function getFormsNativeFlowMode(): string
    {
        $value = $this->getValue('forms_native_flow_mode', self::FORMS_NATIVE_FLOW_EMBEDDED);
        return in_array($value, self::FORMS_NATIVE_FLOW_MODES, true) ? $value : self::FORMS_NATIVE_FLOW_EMBEDDED;
    }

    public function isFormsNativeEmbedEnabled(): bool
    {
        return in_array($this->getFormsNativeFlowMode(), [
            self::FORMS_NATIVE_FLOW_EMBEDDED,
            self::FORMS_NATIVE_FLOW_EMBEDDED_MINIMAL,
        ], true);
    }

    /**
     * Presentation-only rollout switch. Authorization and submission remain
     * entirely in GLPI/Formcreator and must never depend on this value.
     */
    public function isFormcreatorMinimalEmbedEnabled(): bool
    {
        try {
            return $this->getValue('formcreator_minimal_embed_enabled', '0') === '1';
        } catch (\Throwable $e) {
            return false;
        }
    }

    /**
     * Presentation-only bridge. It never changes the native form controls,
     * values, submission route, CSRF token or GLPI authorization decision.
     */
    public function isNativeFormAccessibilityBridgeEnabled(): bool
    {
        try {
            return $this->getValue('native_form_accessibility_bridge_enabled', '0') === '1';
        } catch (\Throwable $e) {
            return false;
        }
    }

    /**
     * The progressive list is the safe default when no explicit setting exists.
     * Administrators can still disable it, and the switch is never an
     * authorization boundary.
     */
    public function isTicketAsyncListEnabled(): bool
    {
        try {
            return $this->getValue('ticket_async_list_enabled', '1') === '1';
        } catch (\Throwable $e) {
            return true;
        }
    }

    public function isTicketListCapacityGuardEnabled(): bool
    {
        try {
            return $this->getValue('ticket_list_capacity_guard_enabled', '1') === '1';
        } catch (\Throwable $e) {
            return true;
        }
    }

    public function getTicketListCapacityBackend(): string
    {
        try {
            $backend = trim($this->getValue('ticket_list_capacity_backend', 'apcu'));
        } catch (\Throwable $e) {
            return 'apcu';
        }

        return in_array($backend, self::TICKET_LIST_CAPACITY_BACKENDS, true)
            ? $backend
            : 'apcu';
    }

    public function getTicketListCapacityMaxConcurrent(): int
    {
        return $this->getBoundedIntConfig(
            'ticket_list_capacity_max_concurrent',
            self::TICKET_LIST_CAPACITY_MAX_CONCURRENT_DEFAULT,
            self::TICKET_LIST_CAPACITY_MAX_CONCURRENT_MIN,
            self::TICKET_LIST_CAPACITY_MAX_CONCURRENT_MAX
        );
    }

    public function getTicketListCapacityLeaseSeconds(): int
    {
        return $this->getBoundedIntConfig(
            'ticket_list_capacity_lease_seconds',
            self::TICKET_LIST_CAPACITY_LEASE_SECONDS_DEFAULT,
            self::TICKET_LIST_CAPACITY_LEASE_SECONDS_MIN,
            self::TICKET_LIST_CAPACITY_LEASE_SECONDS_MAX
        );
    }

    public function getTicketListCapacityRetryAfterSeconds(): int
    {
        return $this->getBoundedIntConfig(
            'ticket_list_capacity_retry_after_seconds',
            self::TICKET_LIST_CAPACITY_RETRY_AFTER_DEFAULT,
            self::TICKET_LIST_CAPACITY_RETRY_AFTER_MIN,
            self::TICKET_LIST_CAPACITY_RETRY_AFTER_MAX
        );
    }

    public function getTicketListRateLimit(): int
    {
        return $this->getBoundedIntConfig(
            'ticket_list_rate_limit',
            self::TICKET_LIST_RATE_LIMIT_DEFAULT,
            self::TICKET_LIST_RATE_LIMIT_MIN,
            self::TICKET_LIST_RATE_LIMIT_MAX
        );
    }

    public function getTicketListRateWindowSeconds(): int
    {
        return $this->getBoundedIntConfig(
            'ticket_list_rate_window_seconds',
            self::TICKET_LIST_RATE_WINDOW_DEFAULT,
            self::TICKET_LIST_RATE_WINDOW_MIN,
            self::TICKET_LIST_RATE_WINDOW_MAX
        );
    }

    public function getTicketListRateBurst(): int
    {
        $burst = $this->getBoundedIntConfig(
            'ticket_list_rate_burst',
            self::TICKET_LIST_RATE_BURST_DEFAULT,
            self::TICKET_LIST_RATE_BURST_MIN,
            self::TICKET_LIST_RATE_BURST_MAX
        );

        return min($burst, $this->getTicketListRateLimit());
    }

    public function isResourceSelectorEnabled(): bool
    {
        try {
            return $this->getValue('resource_selector_enabled', '0') === '1';
        } catch (\Throwable $e) {
            return false;
        }
    }

    public function isResourceSelectorCreateEnabled(): bool
    {
        if (!$this->isResourceSelectorEnabled()) {
            return false;
        }
        try {
            return $this->getValue('resource_selector_create_enabled', '0') === '1';
        } catch (\Throwable $e) {
            return false;
        }
    }

    public function isResourceSelectorRoutingEnabled(): bool
    {
        if (!$this->isResourceSelectorEnabled()) {
            return false;
        }
        try {
            return $this->getValue('resource_selector_routing_enabled', '0') === '1';
        } catch (\Throwable $e) {
            return false;
        }
    }

    public function isFormCatalogV2Enabled(): bool
    {
        try {
            return $this->getValue('form_catalog_v2_enabled', '0') === '1';
        } catch (\Throwable $e) {
            return false;
        }
    }

    /** @return array<string, mixed> */
    public function getI18nDiagnostics(): array
    {
        return [
            'language_policy' => 'inherit_glpi',
            'glpi_session_locale' => (string) ($_SESSION['glpilanguage'] ?? ($_SESSION['glpi_language'] ?? '')),
            'effective_locale' => I18n::locale(),
            'html_lang' => I18n::htmlLang(),
            'fallback_locale' => $this->getPluginFallbackLocale(),
            'available_locales' => I18n::availableLocales(),
            'catalog_status' => I18n::catalogStatus(),
            'javascript_catalog_messages' => count(I18n::javascriptMessageSources()),
            'domain' => I18n::DOMAIN,
        ];
    }

    /** @return array<string, mixed> */
    public function getOperationalDiagnostics(): array
    {
        $voiceAssets = $this->getResolvedVoiceAssets();
        $voiceSources = [];
        foreach ($voiceAssets as $key => $value) {
            if (str_ends_with((string) $key, 'Source')) {
                $voiceSources[$key] = $value;
            }
        }

        return [
            'plugin_version' => defined('PLUGIN_GLPIACESSIVEL_VERSION') ? (string) PLUGIN_GLPIACESSIVEL_VERSION : 'unknown',
            'glpi_version' => defined('GLPI_VERSION') ? (string) GLPI_VERSION : 'unknown',
            'php_version' => PHP_VERSION,
            'accessibility_mode' => $this->getAccessibilityMode(),
            'authentication_entry_mode' => $this->getAuthenticationEntryMode(),
            'show_login_accessibility_notice' => $this->isLoginAccessibilityNoticeEnabled() ? '1' : '0',
            'portal_module_states' => $this->getPortalModuleStates(),
            'forms_enabled' => $this->isFormsEnabled() ? '1' : '0',
            'pii_masking_enabled' => $this->isPiiMaskingEnabled() ? '1' : '0',
            'forms_native_flow_mode' => $this->getFormsNativeFlowMode(),
            'formcreator_minimal_embed_enabled' => $this->isFormcreatorMinimalEmbedEnabled()
                ? '1'
                : '0',
            'native_form_accessibility_bridge_enabled' => $this->isNativeFormAccessibilityBridgeEnabled()
                ? '1'
                : '0',
            'ticket_async_list_enabled' => $this->isTicketAsyncListEnabled() ? '1' : '0',
            'ticket_list_capacity_guard_enabled' => $this->isTicketListCapacityGuardEnabled() ? '1' : '0',
            'ticket_list_capacity_backend' => $this->getTicketListCapacityBackend(),
            'ticket_list_capacity_max_concurrent' => $this->getTicketListCapacityMaxConcurrent(),
            'ticket_list_capacity_lease_seconds' => $this->getTicketListCapacityLeaseSeconds(),
            'ticket_list_capacity_retry_after_seconds' => $this->getTicketListCapacityRetryAfterSeconds(),
            'ticket_list_rate_limit' => $this->getTicketListRateLimit(),
            'ticket_list_rate_window_seconds' => $this->getTicketListRateWindowSeconds(),
            'ticket_list_rate_burst' => $this->getTicketListRateBurst(),
            'resource_selector_enabled' => $this->isResourceSelectorEnabled() ? '1' : '0',
            'resource_selector_create_enabled' => $this->isResourceSelectorCreateEnabled() ? '1' : '0',
            'resource_selector_routing_enabled' => $this->isResourceSelectorRoutingEnabled() ? '1' : '0',
            'form_catalog_v2_enabled' => $this->isFormCatalogV2Enabled() ? '1' : '0',
            'chatbot_enabled' => $this->isChatbotEnabled() ? '1' : '0',
            'chatbot_display_name' => $this->getChatbotDisplayName(),
            'chatbot_floating_scope' => $this->getChatbotFloatingScope(),
            'vlibras_scope' => $this->getVlibrasScope(),
            'voice_asset_mode' => $this->getChatbotVoiceAssetMode(),
            'voice_sources' => $voiceSources,
            'audit_retention_days' => $this->getAuditRetentionDays(),
            'audit_retention_batch_size' => $this->getAuditRetentionBatchSize(),
            'audit_mode' => $this->getAuditMode(),
            'audit_disabled_allowed' => $this->isAuditDisabledAllowed() ? '1' : '0',
            'runtime_update' => (new RuntimeVersionDiagnostics())->inspect(),
        ];
    }

    /**
     * @return string[]
     */
    public function getChatbotEnabledIntents(): array
    {
        $raw = trim($this->getValue('chatbot_enabled_intents', ''));
        if ($raw === '') {
            return self::CHATBOT_INTENTS;
        }

        $decoded = json_decode($raw, true);
        if (!is_array($decoded)) {
            return self::CHATBOT_INTENTS;
        }

        $enabled = [];
        foreach ($decoded as $intent) {
            $intent = (string) $intent;
            if (in_array($intent, self::CHATBOT_INTENTS, true)) {
                $enabled[] = $intent;
            }
        }

        $enabled = array_values(array_unique($enabled));
        if ($enabled === []) {
            return ['handoff_humano'];
        }

        if (!in_array('handoff_humano', $enabled, true)) {
            $enabled[] = 'handoff_humano';
        }

        return $enabled;
    }

    /**
     * @param string[] $intents
     */
    public function setChatbotEnabledIntents(array $intents): void
    {
        $allowed = [];
        foreach ($intents as $intent) {
            $intent = (string) $intent;
            if (in_array($intent, self::CHATBOT_INTENTS, true)) {
                $allowed[] = $intent;
            }
        }

        $allowed = array_values(array_unique($allowed));
        if ($allowed === []) {
            $allowed = ['handoff_humano'];
        }
        if (!in_array('handoff_humano', $allowed, true)) {
            $allowed[] = 'handoff_humano';
        }

        $this->setValue('chatbot_enabled_intents', json_encode($allowed, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES));
    }

    public function isChatbotIntentEnabled(string $intent): bool
    {
        if ($intent === 'handoff_humano') {
            return true;
        }

        return in_array($intent, $this->getChatbotEnabledIntents(), true);
    }

    public function isChatbotFloatingButtonEnabled(): bool
    {
        return $this->getChatbotFloatingScope() !== 'disabled';
    }

    public function getChatbotFloatingScope(): string
    {
        $scope = trim($this->getValue('chatbot_floating_scope', ''));
        if (in_array($scope, self::CHATBOT_FLOATING_SCOPES, true)) {
            return $scope;
        }

        return $this->getValue('chatbot_floating_button_enabled', '1') === '0'
            ? 'disabled'
            : 'all_logged_pages';
    }

    public function isChatbotVoiceEnabled(): bool
    {
        return $this->getValue('chatbot_voice_enabled', '1') === '1';
    }

    public function getChatbotVoiceLocale(): string
    {
        $value = trim($this->getValue('chatbot_voice_locale', 'pt-BR'));
        if (!preg_match('/^[a-z]{2}(?:-[A-Z]{2})?$/', $value)) {
            return 'pt-BR';
        }

        return $value;
    }

    public function getChatbotSttEngine(): string
    {
        $value = $this->getValue('chatbot_stt_engine', 'vosklet');
        return in_array($value, self::CHATBOT_STT_ENGINES, true) ? $value : 'vosklet';
    }

    public function getChatbotTtsEngine(): string
    {
        $value = $this->getValue('chatbot_tts_engine', 'browser_native');
        return in_array($value, self::CHATBOT_TTS_ENGINES, true) ? $value : 'browser_native';
    }

    public function getChatbotVoiceAssetMode(): string
    {
        $value = $this->getValue('chatbot_voice_asset_mode', 'local_preferred');
        return in_array($value, self::CHATBOT_VOICE_ASSET_MODES, true) ? $value : 'local_preferred';
    }

    public function getChatbotSttScriptUrl(): string
    {
        return $this->sanitizeExternalVoiceUrl(
            $this->getValue('chatbot_stt_script_url', self::DEFAULT_STT_SCRIPT_EXTERNAL_URL),
            self::DEFAULT_STT_SCRIPT_EXTERNAL_URL
        );
    }

    public function getChatbotSttModelUrl(): string
    {
        return $this->sanitizeExternalVoiceUrl(
            $this->getValue('chatbot_stt_model_url', self::DEFAULT_STT_MODEL_EXTERNAL_URL),
            self::DEFAULT_STT_MODEL_EXTERNAL_URL
        );
    }

    public function getChatbotSttModelLabel(): string
    {
        return trim($this->getValue('chatbot_stt_model_label', 'Portugues (Brasil)'));
    }

    public function getChatbotSttModelCacheId(): string
    {
        $value = trim($this->getValue('chatbot_stt_model_cache_id', 'glpi-vosk-ptbr'));
        return $value !== '' ? $value : 'glpi-vosk-ptbr';
    }

    public function getChatbotTtsScriptUrl(): string
    {
        return $this->sanitizeExternalVoiceUrl(
            $this->getValue('chatbot_tts_script_url', self::DEFAULT_TTS_SCRIPT_EXTERNAL_URL),
            self::DEFAULT_TTS_SCRIPT_EXTERNAL_URL
        );
    }

    public function getChatbotTtsVoiceId(): string
    {
        $value = trim($this->getValue('chatbot_tts_voice_id', 'pt_BR-faber-medium'));
        return $value !== '' ? $value : 'pt_BR-faber-medium';
    }

    public function getChatbotSttScriptLocalPath(): string
    {
        return $this->normalizePluginRelativePath(
            $this->getValue('chatbot_stt_script_local_path', self::DEFAULT_STT_SCRIPT_LOCAL_PATH),
            self::DEFAULT_STT_SCRIPT_LOCAL_PATH
        );
    }

    public function getChatbotSttModelLocalPath(): string
    {
        return $this->normalizePluginRelativePath(
            $this->getValue('chatbot_stt_model_local_path', self::DEFAULT_STT_MODEL_LOCAL_PATH),
            self::DEFAULT_STT_MODEL_LOCAL_PATH
        );
    }

    public function getChatbotTtsScriptLocalPath(): string
    {
        return $this->normalizePluginRelativePath(
            $this->getValue('chatbot_tts_script_local_path', self::DEFAULT_TTS_SCRIPT_LOCAL_PATH),
            self::DEFAULT_TTS_SCRIPT_LOCAL_PATH
        );
    }

    public function getChatbotTtsOnnxRuntimeLocalPath(): string
    {
        return $this->normalizePluginRelativePath(
            $this->getValue('chatbot_tts_onnx_runtime_local_path', self::DEFAULT_TTS_ONNX_RUNTIME_LOCAL_PATH),
            self::DEFAULT_TTS_ONNX_RUNTIME_LOCAL_PATH
        );
    }

    public function getChatbotTtsOnnxWasmLocalPath(): string
    {
        return $this->normalizePluginRelativePath(
            $this->getValue('chatbot_tts_onnx_wasm_local_path', self::DEFAULT_TTS_ONNX_WASM_LOCAL_PATH),
            self::DEFAULT_TTS_ONNX_WASM_LOCAL_PATH
        );
    }

    public function getChatbotTtsPiperWasmLocalPath(): string
    {
        return $this->normalizePluginRelativePath(
            $this->getValue('chatbot_tts_piper_wasm_local_path', self::DEFAULT_TTS_PIPER_WASM_LOCAL_PATH),
            self::DEFAULT_TTS_PIPER_WASM_LOCAL_PATH
        );
    }

    public function getChatbotTtsPiperDataLocalPath(): string
    {
        return $this->normalizePluginRelativePath(
            $this->getValue('chatbot_tts_piper_data_local_path', self::DEFAULT_TTS_PIPER_DATA_LOCAL_PATH),
            self::DEFAULT_TTS_PIPER_DATA_LOCAL_PATH
        );
    }

    public function getChatbotTtsVoiceModelLocalPath(): string
    {
        return $this->normalizePluginRelativePath(
            $this->getValue('chatbot_tts_voice_model_local_path', self::DEFAULT_TTS_VOICE_MODEL_LOCAL_PATH),
            self::DEFAULT_TTS_VOICE_MODEL_LOCAL_PATH
        );
    }

    public function getChatbotTtsVoiceConfigLocalPath(): string
    {
        return $this->normalizePluginRelativePath(
            $this->getValue('chatbot_tts_voice_config_local_path', self::DEFAULT_TTS_VOICE_CONFIG_LOCAL_PATH),
            self::DEFAULT_TTS_VOICE_CONFIG_LOCAL_PATH
        );
    }

    public function sanitizeChatbotSttScriptLocalPath(string $path): string
    {
        return $this->normalizePluginRelativePath($path, self::DEFAULT_STT_SCRIPT_LOCAL_PATH);
    }

    public function sanitizeChatbotSttModelLocalPath(string $path): string
    {
        return $this->normalizePluginRelativePath($path, self::DEFAULT_STT_MODEL_LOCAL_PATH);
    }

    public function sanitizeChatbotTtsScriptLocalPath(string $path): string
    {
        return $this->normalizePluginRelativePath($path, self::DEFAULT_TTS_SCRIPT_LOCAL_PATH);
    }

    public function sanitizeChatbotTtsOnnxRuntimeLocalPath(string $path): string
    {
        return $this->normalizePluginRelativePath($path, self::DEFAULT_TTS_ONNX_RUNTIME_LOCAL_PATH);
    }

    public function sanitizeChatbotTtsOnnxWasmLocalPath(string $path): string
    {
        return $this->normalizePluginRelativePath($path, self::DEFAULT_TTS_ONNX_WASM_LOCAL_PATH);
    }

    public function sanitizeChatbotTtsPiperWasmLocalPath(string $path): string
    {
        return $this->normalizePluginRelativePath($path, self::DEFAULT_TTS_PIPER_WASM_LOCAL_PATH);
    }

    public function sanitizeChatbotTtsPiperDataLocalPath(string $path): string
    {
        return $this->normalizePluginRelativePath($path, self::DEFAULT_TTS_PIPER_DATA_LOCAL_PATH);
    }

    public function sanitizeChatbotTtsVoiceModelLocalPath(string $path): string
    {
        return $this->normalizePluginRelativePath($path, self::DEFAULT_TTS_VOICE_MODEL_LOCAL_PATH);
    }

    public function sanitizeChatbotTtsVoiceConfigLocalPath(string $path): string
    {
        return $this->normalizePluginRelativePath($path, self::DEFAULT_TTS_VOICE_CONFIG_LOCAL_PATH);
    }

    public function sanitizeChatbotExternalVoiceUrl(string $url, string $default = ''): string
    {
        return $this->sanitizeExternalVoiceUrl($url, $default);
    }

    /**
     * @return array<string,string>
     */
    public function getResolvedVoiceAssets(): array
    {
        $mode = $this->getChatbotVoiceAssetMode();

        [$sttScriptUrl, $sttScriptSource] = $this->resolveVoiceAsset(
            $this->getChatbotSttScriptLocalPath(),
            $this->getChatbotSttScriptUrl(),
            $mode
        );
        [$sttModelUrl, $sttModelSource] = $this->resolveVoiceAsset(
            $this->getChatbotSttModelLocalPath(),
            $this->getChatbotSttModelUrl(),
            $mode
        );
        [$ttsScriptUrl, $ttsScriptSource] = $this->resolveVoiceAsset(
            $this->getChatbotTtsScriptLocalPath(),
            $this->getChatbotTtsScriptUrl(),
            $mode
        );
        [$ttsOnnxRuntimeUrl, $ttsOnnxRuntimeSource] = $this->resolveVoiceAsset(
            $this->getChatbotTtsOnnxRuntimeLocalPath(),
            self::DEFAULT_TTS_ONNX_RUNTIME_EXTERNAL_URL,
            $mode
        );
        [$ttsOnnxWasmBaseUrl, $ttsOnnxWasmBaseSource] = $this->resolveVoiceDirectoryAsset(
            $this->getChatbotTtsOnnxWasmLocalPath(),
            self::DEFAULT_TTS_ONNX_WASM_EXTERNAL_URL,
            $mode,
            ['ort-wasm.wasm', 'ort-wasm-simd.wasm', 'ort-wasm-simd-threaded.wasm']
        );
        [$ttsPiperWasmUrl, $ttsPiperWasmSource] = $this->resolveVoiceAsset(
            $this->getChatbotTtsPiperWasmLocalPath(),
            self::DEFAULT_TTS_PIPER_WASM_EXTERNAL_URL,
            $mode
        );
        [$ttsPiperDataUrl, $ttsPiperDataSource] = $this->resolveVoiceAsset(
            $this->getChatbotTtsPiperDataLocalPath(),
            self::DEFAULT_TTS_PIPER_DATA_EXTERNAL_URL,
            $mode
        );
        [$ttsVoiceModelUrl, $ttsVoiceModelSource] = $this->resolveVoiceAsset(
            $this->getChatbotTtsVoiceModelLocalPath(),
            '',
            $mode
        );
        [$ttsVoiceConfigUrl, $ttsVoiceConfigSource] = $this->resolveVoiceAsset(
            $this->getChatbotTtsVoiceConfigLocalPath(),
            '',
            $mode
        );

        return [
            'mode' => $mode,
            'sttScriptUrl' => $sttScriptUrl,
            'sttScriptSource' => $sttScriptSource,
            'sttModelUrl' => $sttModelUrl,
            'sttModelSource' => $sttModelSource,
            'ttsScriptUrl' => $ttsScriptUrl,
            'ttsScriptSource' => $ttsScriptSource,
            'ttsOnnxRuntimeUrl' => $ttsOnnxRuntimeUrl,
            'ttsOnnxRuntimeSource' => $ttsOnnxRuntimeSource,
            'ttsOnnxWasmBaseUrl' => $ttsOnnxWasmBaseUrl,
            'ttsOnnxWasmBaseSource' => $ttsOnnxWasmBaseSource,
            'ttsPiperWasmUrl' => $ttsPiperWasmUrl,
            'ttsPiperWasmSource' => $ttsPiperWasmSource,
            'ttsPiperDataUrl' => $ttsPiperDataUrl,
            'ttsPiperDataSource' => $ttsPiperDataSource,
            'ttsVoiceModelUrl' => $ttsVoiceModelUrl,
            'ttsVoiceModelSource' => $ttsVoiceModelSource,
            'ttsVoiceConfigUrl' => $ttsVoiceConfigUrl,
            'ttsVoiceConfigSource' => $ttsVoiceConfigSource,
        ];
    }

    public function setValue(string $key, string $value): void
    {
        global $DB;

        $updatedAt = date('Y-m-d H:i:s');
        $exists = $DB->request([
            'SELECT' => ['id'],
            'FROM' => 'glpi_plugin_glpiacessivel_configs',
            'WHERE' => ['key_name' => $key],
            'LIMIT' => 1,
        ])->current();

        if ($exists) {
            $DB->update('glpi_plugin_glpiacessivel_configs', [
                'value_text' => $value,
                'updated_at' => $updatedAt,
            ], ['id' => (int) $exists['id']]);
            return;
        }

        $DB->insert('glpi_plugin_glpiacessivel_configs', [
            'key_name' => $key,
            'value_text' => $value,
            'updated_at' => $updatedAt,
        ]);
    }

    private function getValue(string $key, string $default): string
    {
        global $DB;

        $result = $DB->request([
            'SELECT' => ['value_text'],
            'FROM' => 'glpi_plugin_glpiacessivel_configs',
            'WHERE' => ['key_name' => $key],
            'LIMIT' => 1,
        ])->current();

        if (!$result) {
            return $default;
        }

        return (string) ($result['value_text'] ?? $default);
    }

    private function getBoundedIntConfig(string $key, int $default, int $minimum, int $maximum): int
    {
        try {
            $value = (int) $this->getValue($key, (string) $default);
        } catch (\Throwable $e) {
            return $default;
        }

        return min($maximum, max($minimum, $value));
    }

    /**
     * @return array{0:string,1:string}
     */
    private function resolveVoiceAsset(string $localPath, string $externalUrl, string $mode): array
    {
        $localUrl = Url::asset($localPath);
        $localExists = $this->pluginRelativeFileExists($localPath);

        if ($mode === 'external_only') {
            return $externalUrl !== '' ? [$externalUrl, 'external'] : ['', 'missing_external'];
        }

        if ($localExists) {
            return [$localUrl, 'local'];
        }

        if ($mode === 'local_only') {
            return ['', 'missing_local'];
        }

        return $externalUrl !== '' ? [$externalUrl, 'external_fallback'] : ['', 'missing_external'];
    }

    /**
     * @param list<string> $requiredAnyFiles
     * @return array{0:string,1:string}
     */
    private function resolveVoiceDirectoryAsset(
        string $localPath,
        string $externalUrl,
        string $mode,
        array $requiredAnyFiles = []
    ): array {
        $localUrl = rtrim(Url::asset($localPath), '/') . '/';
        $localExists = $this->pluginRelativeDirectoryExists($localPath, $requiredAnyFiles);

        if ($mode === 'external_only') {
            return $externalUrl !== '' ? [$externalUrl, 'external'] : ['', 'missing_external'];
        }

        if ($localExists) {
            return [$localUrl, 'local'];
        }

        if ($mode === 'local_only') {
            return ['', 'missing_local'];
        }

        return $externalUrl !== '' ? [$externalUrl, 'external_fallback'] : ['', 'missing_external'];
    }

    private function sanitizeExternalVoiceUrl(string $url, string $default): string
    {
        $url = trim($url);
        if ($url === '') {
            $url = trim($default);
        }

        if ($url === '' || filter_var($url, FILTER_VALIDATE_URL) === false) {
            return '';
        }

        $parts = parse_url($url);
        $scheme = strtolower((string) ($parts['scheme'] ?? ''));
        $host = strtolower((string) ($parts['host'] ?? ''));
        if ($scheme !== 'https' || $host === '') {
            return '';
        }

        $allowedHosts = [
            'cdn.jsdelivr.net',
            'cdnjs.cloudflare.com',
            'alphacephei.com',
            'esm.run',
        ];

        return in_array($host, $allowedHosts, true) ? $url : '';
    }

    private function pluginRelativeFileExists(string $path): bool
    {
        $normalized = $this->normalizePluginRelativePath($path, '');
        if ($normalized === '') {
            return false;
        }

        $root = dirname(__DIR__, 2);
        return is_file($root . DIRECTORY_SEPARATOR . str_replace('/', DIRECTORY_SEPARATOR, $normalized));
    }

    /**
     * @param list<string> $requiredAnyFiles
     */
    private function pluginRelativeDirectoryExists(string $path, array $requiredAnyFiles = []): bool
    {
        $normalized = $this->normalizePluginRelativePath($path, '');
        if ($normalized === '') {
            return false;
        }

        $root = dirname(__DIR__, 2);
        $directory = $root . DIRECTORY_SEPARATOR . str_replace('/', DIRECTORY_SEPARATOR, $normalized);
        if (!is_dir($directory)) {
            return false;
        }

        if ($requiredAnyFiles === []) {
            return true;
        }

        foreach ($requiredAnyFiles as $filename) {
            if (is_file($directory . DIRECTORY_SEPARATOR . $filename)) {
                return true;
            }
        }

        return false;
    }

    private function normalizeLocale(string $locale): string
    {
        $locale = trim(str_replace('-', '_', $locale));
        if ($locale === '') {
            return '';
        }

        if (preg_match('/^[a-z]{2}_[A-Z]{2}$/', $locale) === 1) {
            return $locale;
        }

        $parts = explode('_', $locale, 2);
        if (count($parts) === 2) {
            $locale = strtolower($parts[0]) . '_' . strtoupper($parts[1]);
        }

        return preg_match('/^[a-z]{2}_[A-Z]{2}$/', $locale) === 1 ? $locale : '';
    }

    private function normalizePluginRelativePath(string $path, string $default): string
    {
        $normalized = trim(str_replace('\\', '/', $path));
        $normalized = preg_replace('#^https?://[^/]+/#i', '', $normalized) ?? $normalized;
        $normalized = ltrim($normalized, '/');

        if (preg_match('#(?:^|/)(public/assets/.+)$#i', $normalized, $matches) === 1) {
            $normalized = $matches[1];
        }

        if (str_starts_with($normalized, 'plugins/glpiacessivel/')) {
            $normalized = substr($normalized, strlen('plugins/glpiacessivel/'));
        }

        if ($normalized === self::LEGACY_TTS_SCRIPT_LOCAL_PATH) {
            $normalized = self::DEFAULT_TTS_SCRIPT_LOCAL_PATH;
        }

        if (
            $normalized === self::LEGACY_TTS_ONNX_RUNTIME_LOCAL_PATH_JS
            || $normalized === self::LEGACY_TTS_ONNX_RUNTIME_LOCAL_PATH_MJS
        ) {
            $normalized = self::DEFAULT_TTS_ONNX_RUNTIME_LOCAL_PATH;
        }

        if ($normalized === '' || str_contains($normalized, '..') || str_contains($normalized, '://')) {
            return $default;
        }

        return $normalized;
    }
}
