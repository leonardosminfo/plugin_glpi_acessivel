<?php

declare(strict_types=1);

namespace GlpiPlugin\Glpiacessivel\Application;

use GlpiPlugin\Glpiacessivel\Application\DynamicForm\DynamicFormFacade;
use GlpiPlugin\Glpiacessivel\Domain\Security\Authorization;
use GlpiPlugin\Glpiacessivel\Infrastructure\Audit\AuditLogger;
use GlpiPlugin\Glpiacessivel\Infrastructure\FormCatalog\FormCatalogRequest;
use GlpiPlugin\Glpiacessivel\Infrastructure\Repository\FormRepository;
use GlpiPlugin\Glpiacessivel\Support\I18n;

final class FormService
{
    public function __construct(
        private FormRepository $repository,
        private Authorization $authorization,
        private AuditLogger $auditLogger
    ) {
    }

    /**
     * @return array<string, mixed>
     */
    public function listAvailableForms(?FormCatalogRequest $request = null): array
    {
        if (!$this->authorization->canUseForms()) {
            throw new \RuntimeException(I18n::translate('Usuário sem sessão válida para abrir formulários de solicitação.'));
        }

        // Catalog cards intentionally remain lightweight. Dynamic schemas may
        // read many related tables and are generated only after reauthorization.
        $result = $this->repository->listFormSources($request);
        $formcreatorPage = is_array($result['catalog_page'] ?? null) ? $result['catalog_page'] : [];
        $this->auditLogger->log('forms.list', [
            'count' => count((array) ($result['items'] ?? [])),
            'glpi11_available' => !empty($result['sources']['glpi11_service_catalog']['available']),
            'formcreator_available' => !empty($result['sources']['formcreator_glpi10']['available']),
            'formcreator_state' => (string) ($formcreatorPage['state'] ?? 'not_detected'),
            'formcreator_page' => (int) ($formcreatorPage['page'] ?? 1),
            'formcreator_candidate_count' => (int) ($formcreatorPage['candidate_count'] ?? 0),
            'formcreator_item_count' => (int) ($formcreatorPage['item_count'] ?? 0),
            'formcreator_duration_ms' => (int) ($formcreatorPage['duration_ms'] ?? 0),
            'formcreator_correlation_id' => (string) ($formcreatorPage['correlation_id'] ?? ''),
        ]);

        return $result;
    }

    /**
     * @return array<string, mixed>|null
     */
    public function resolveForm(string $source, int $id): ?array
    {
        if (!$this->authorization->canUseForms()) {
            throw new \RuntimeException(I18n::translate('Usuário sem sessão válida para abrir formulários de solicitação.'));
        }

        $form = $this->repository->resolveForm($source, $id);
        if ($form !== null) {
            $form = $this->enrichForm($form);
        }
        $this->auditLogger->log('forms.open_native_fallback', [
            'source' => $source,
            'form_id' => $id,
            'found' => $form !== null,
        ]);

        return $form;
    }
    /**
     * @param array<string, mixed> $form
     * @return array<string, mixed>
     */
    private function enrichForm(array $form): array
    {
        $source = (string) ($form['source'] ?? '');
        if ($source === '') {
            return $form;
        }

        try {
            $schema = (new DynamicFormFacade())->formSchema($source, ['form' => $form])->toArray();
            $form['dynamic_form_schema'] = $schema;
            $capabilities = is_array($schema['capabilities'] ?? null) ? $schema['capabilities'] : [];
            $metadata = is_array($schema['metadata'] ?? null) ? $schema['metadata'] : [];
            $form['compatibility_status'] = (string) ($metadata['compatibility_status'] ?? (
                !empty($capabilities['renders_own_fields'])
                    ? 'renderer_candidate'
                    : (!empty($schema['fallback']['required']) ? 'native_fallback_required' : 'renderer_candidate')
            ));
            $reasons = array_values(array_filter(array_map('strval', (array) ($schema['fallback']['reasons'] ?? []))));
            $advisories = array_values(array_filter(array_map('strval', (array) ($schema['fallback']['advisory_reasons'] ?? []))));
            $form['compatibility_reasons'] = $reasons;
            $form['compatibility_advisories'] = $advisories;
            $form['compatibility_summary'] = $reasons[0]
                ?? ($advisories[0] ?? I18n::translate('Estrutura do formulário preparada para avaliação de compatibilidade.'));
        } catch (\Throwable $e) {
            $form['compatibility_status'] = 'schema_unavailable';
            $form['compatibility_reasons'] = [I18n::translate(
                'Não foi possível preparar as informações do formulário. Abra-o em página completa para continuar.'
            )];
            $form['compatibility_advisories'] = [];
            $form['compatibility_summary'] = I18n::translate(
                'Não foi possível preparar as informações do formulário. Abra-o em página completa para continuar.'
            );
        }

        return $form;
    }
}
