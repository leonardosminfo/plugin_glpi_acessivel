<?php

declare(strict_types=1);

namespace GlpiPlugin\Glpiacessivel\Infrastructure\FormCatalog;

use GlpiPlugin\Glpiacessivel\Support\TextNormalizer;

/**
 * Authorized Formcreator 2.13 catalog for GLPI 10.
 *
 * The collective query and the per-item decision intentionally remain in
 * Formcreator. This adapter only adds a bounded window and lightweight fields.
 */
final class Formcreator213CatalogGateway implements FormCatalogGateway
{
    private const SOURCE = 'formcreator_glpi10';
    private const FORM_CLASS = '\\PluginFormcreatorForm';
    private const CANDIDATE_CHUNK = 50;
    private const MAX_CURSOR_HISTORY = 100;

    private object|null $database;
    private string $formClass;
    /** @var \Closure():bool|null */
    private ?\Closure $activeChecker;
    /** @var \Closure():string|null */
    private ?\Closure $cursorKeyProvider;
    private ?string $glpiVersion;
    private bool $enabled;
    private FormcreatorNativeUrlResolver $nativeUrlResolver;

    /**
     * Injectable seams are deliberately limited to runtime/capability doubles.
     * Production callers should use the no-argument constructor.
     */
    public function __construct(
        ?object $database = null,
        string $formClass = self::FORM_CLASS,
        ?callable $activeChecker = null,
        ?string $glpiVersion = null,
        ?callable $cursorKeyProvider = null,
        bool $enabled = true,
        ?FormcreatorNativeUrlResolver $nativeUrlResolver = null
    ) {
        $this->database = $database;
        $this->formClass = $formClass;
        $this->activeChecker = $activeChecker !== null ? \Closure::fromCallable($activeChecker) : null;
        $this->glpiVersion = $glpiVersion;
        $this->cursorKeyProvider = $cursorKeyProvider !== null
            ? \Closure::fromCallable($cursorKeyProvider)
            : null;
        $this->enabled = $enabled;
        $this->nativeUrlResolver = $nativeUrlResolver ?? new FormcreatorNativeUrlResolver(
            null,
            $glpiVersion
        );
    }

    /** @return array<string, mixed> */
    public function capabilities(): array
    {
        if (!$this->enabled) {
            $detected = class_exists($this->formClass);
            if (!$detected) {
                return $this->capability(false, false, 'not_detected', 'formcreator_class_missing');
            }
            if (!$this->pluginIsActive()) {
                return $this->capability(true, false, 'inactive', 'formcreator_plugin_inactive');
            }
            return $this->capability(true, false, 'inactive', 'catalog_disabled_by_policy');
        }

        $version = $this->glpiVersion ?? (defined('GLPI_VERSION') ? (string) constant('GLPI_VERSION') : '');
        if ($version !== '' && version_compare($version, '11.0.0', '>=')) {
            return $this->capability(false, false, 'not_detected', 'glpi11_uses_native_catalog');
        }
        if ($version !== '' && version_compare($version, '10.0.0', '<')) {
            return $this->capability(false, false, 'unsupported_contract', 'glpi_version_unsupported');
        }

        if (!class_exists($this->formClass)) {
            return $this->capability(false, false, 'not_detected', 'formcreator_class_missing');
        }

        if (!$this->pluginIsActive()) {
            return $this->capability(true, false, 'inactive', 'formcreator_plugin_inactive');
        }

        if (defined('PLUGIN_FORMCREATOR_VERSION')) {
            $formcreatorVersion = (string) constant('PLUGIN_FORMCREATOR_VERSION');
            if (
                version_compare($formcreatorVersion, '2.13.0', '<')
                || version_compare($formcreatorVersion, '2.14.0', '>=')
            ) {
                return $this->capability(true, false, 'unsupported_contract', 'formcreator_version_unsupported');
            }
        }

        try {
            $list = new \ReflectionMethod($this->formClass, 'getFormListQuery');
            $load = new \ReflectionMethod($this->formClass, 'getFromDB');
            $authorize = new \ReflectionMethod($this->formClass, 'canViewForRequest');
            if (
                !$list->isPublic()
                || !$list->isStatic()
                || $list->getNumberOfRequiredParameters() !== 0
                || !$load->isPublic()
                || $load->isStatic()
                || $load->getNumberOfRequiredParameters() > 1
                || !$authorize->isPublic()
                || $authorize->isStatic()
                || $authorize->getNumberOfRequiredParameters() !== 0
            ) {
                return $this->capability(true, false, 'unsupported_contract', 'formcreator_signature_mismatch');
            }

            $query = $this->formClass::getFormListQuery();
            if (!is_array($query) || !is_string($query['FROM'] ?? null) || !is_array($query['WHERE'] ?? null)) {
                return $this->capability(true, false, 'unsupported_contract', 'formcreator_query_shape_mismatch');
            }
        } catch (\Throwable $e) {
            return $this->capability(true, false, 'unsupported_contract', 'formcreator_contract_probe_failed');
        }

        if ($this->nativeUrlResolver->catalogUrl() === null) {
            return $this->capability(true, false, 'unsupported_contract', 'formcreator_web_root_unresolved');
        }

        return $this->capability(true, true, 'ready', 'formcreator_213_contract_ready');
    }

    /** @return array<string, mixed> */
    public function list(FormCatalogRequest $request): array
    {
        $started = microtime(true);
        $capabilities = $this->capabilities();
        if (empty($capabilities['enabled'])) {
            return $this->emptyPage(
                (string) ($capabilities['state'] ?? 'unsupported_contract'),
                (string) ($capabilities['diagnostic_code'] ?? 'unsupported_contract'),
                $request,
                $started
            );
        }

        $database = $this->database();
        if ($database === null || !method_exists($database, 'request')) {
            return $this->emptyPage('error', 'native_query_failed', $request, $started);
        }

        $cursor = $this->decodeCursor($request->cursor, $request->query);
        if ($cursor === null) {
            return $this->emptyPage('error', 'invalid_cursor', $request, $started);
        }

        $candidateOffset = (int) $cursor['offset'];
        $pageStart = $candidateOffset;
        $page = (int) $cursor['page'];
        $history = (array) $cursor['history'];
        $items = [];
        $seen = [];
        $hasMore = false;
        $partial = false;
        $diagnosticCode = 'catalog_page_ready';

        try {
            $table = $this->formTable();
            while (count($items) <= $request->pageSize) {
                $query = $this->candidateQuery(
                    $table,
                    $request->query,
                    $candidateOffset,
                    max(self::CANDIDATE_CHUNK, $request->pageSize * 2)
                );
                $rows = $database->request($query);
                $rowCount = 0;
                foreach ($rows as $row) {
                    $rowCount++;
                    $rowOffset = $candidateOffset;
                    $candidateOffset++;
                    $id = (int) ($row['id'] ?? $row[$table . '.id'] ?? 0);
                    if ($id <= 0 || isset($seen[$id])) {
                        continue;
                    }
                    $seen[$id] = true;

                    try {
                        $item = $this->loadAuthorized($id);
                    } catch (\Throwable $e) {
                        $partial = true;
                        $diagnosticCode = 'item_authorization_failed';
                        continue;
                    }
                    if ($item === null) {
                        continue;
                    }
                    if (count($items) >= $request->pageSize) {
                        $candidateOffset = $rowOffset;
                        $hasMore = true;
                        break 2;
                    }
                    $items[] = $item;
                }

                $chunkSize = max(self::CANDIDATE_CHUNK, $request->pageSize * 2);
                if ($rowCount < $chunkSize) {
                    break;
                }
            }
        } catch (\Throwable $e) {
            if ($items === []) {
                return $this->emptyPage('error', 'native_query_failed', $request, $started, $page);
            }
            $partial = true;
            $diagnosticCode = 'native_query_failed_after_partial_page';
        }

        $nextCursor = '';
        if ($hasMore) {
            $nextHistory = array_slice(array_merge($history, [$pageStart]), -self::MAX_CURSOR_HISTORY);
            $nextCursor = $this->encodeCursor($candidateOffset, $page + 1, $nextHistory, $request->query);
        }

        $previousCursor = '';
        if ($history !== []) {
            $previousOffset = (int) array_pop($history);
            $previousCursor = $this->encodeCursor($previousOffset, max(1, $page - 1), $history, $request->query);
        }

        $state = $partial ? 'partial' : ($items === [] ? 'ready_empty' : 'ready');
        if ($state === 'ready_empty') {
            $diagnosticCode = 'empty_authorized_result';
        }

        return [
            'items' => $items,
            'state' => $state,
            'diagnostic_code' => $diagnosticCode,
            'correlation_id' => in_array($state, ['error', 'partial'], true) ? $this->correlationId() : '',
            'page' => $page,
            'page_size' => $request->pageSize,
            'has_more' => $hasMore,
            'next_cursor' => $nextCursor,
            'previous_cursor' => $previousCursor,
            'query' => $request->query,
            'duration_ms' => (int) round((microtime(true) - $started) * 1000),
            'candidate_count' => max(0, $candidateOffset - $pageStart),
            'item_count' => count($items),
            'total' => null,
        ];
    }

    /** @return array<string, mixed>|null */
    public function findAuthorized(int $id): ?array
    {
        if ($id <= 0 || empty($this->capabilities()['enabled'])) {
            return null;
        }

        $database = $this->database();
        if ($database === null || !method_exists($database, 'request')) {
            return null;
        }

        try {
            $table = $this->formTable();
            $query = $this->candidateQuery($table, '', 0, 1);
            $query['WHERE']['AND'][] = ["$table.id" => $id];
            $found = false;
            foreach ($database->request($query) as $row) {
                if ((int) ($row['id'] ?? $row[$table . '.id'] ?? 0) === $id) {
                    $found = true;
                    break;
                }
            }
            if (!$found) {
                return null;
            }

            return $this->loadAuthorized($id);
        } catch (\Throwable $e) {
            return null;
        }
    }

    /** @return array<string, mixed> */
    private function candidateQuery(string $table, string $search, int $start, int $limit): array
    {
        $query = $this->formClass::getFormListQuery();
        if (!is_array($query)) {
            throw new \RuntimeException('formcreator_query_shape_mismatch');
        }

        $query['SELECT'] = $this->mergeSelect((array) ($query['SELECT'] ?? []), $table);
        $query['GROUPBY'] = $this->mergeClause((array) ($query['GROUPBY'] ?? []), ["$table.id"]);
        $query['ORDER'] = $this->mergeClause((array) ($query['ORDER'] ?? []), [
            "$table.name ASC",
            "$table.id ASC",
        ]);
        if ($search !== '') {
            if (!isset($query['WHERE']['AND']) || !is_array($query['WHERE']['AND'])) {
                $query['WHERE']['AND'] = [];
            }
            $query['WHERE']['AND'][] = [
                'OR' => [
                    "$table.name" => ['LIKE', '%' . $this->escapeLike($search) . '%'],
                    "$table.description" => ['LIKE', '%' . $this->escapeLike($search) . '%'],
                ],
            ];
        }
        $query['START'] = max(0, $start);
        $query['LIMIT'] = min(100, max(1, $limit));

        return $query;
    }

    /** @param array<mixed> $select @return array<mixed> */
    private function mergeSelect(array $select, string $table): array
    {
        if (array_is_list($select)) {
            return $this->mergeClause($select, ["$table.id"]);
        }

        $columns = array_values(array_map('strval', (array) ($select[$table] ?? [])));
        if (!in_array('id', $columns, true)) {
            $columns[] = 'id';
        }
        $select[$table] = $columns;
        return $select;
    }

    /** @param array<mixed> $existing @param string[] $required @return array<mixed> */
    private function mergeClause(array $existing, array $required): array
    {
        foreach ($required as $entry) {
            if (!in_array($entry, $existing, true)) {
                $existing[] = $entry;
            }
        }
        return $existing;
    }

    /** @return array<string, mixed>|null */
    private function loadAuthorized(int $id): ?array
    {
        $class = $this->formClass;
        $form = new $class();
        if ($form->getFromDB($id) !== true) {
            throw new \RuntimeException('item_load_failed');
        }
        // Formcreator 2.13.x requires a loaded instance and no argument here.
        if ($form->canViewForRequest() !== true) {
            return null;
        }

        return $this->mapLoadedForm($form, $id);
    }

    /** @return array<string, mixed> */
    private function mapLoadedForm(object $form, int $id): array
    {
        $fields = is_array($form->fields ?? null) ? $form->fields : [];
        $name = (string) ($fields['name'] ?? ('Formulario #' . $id));
        $description = (string) ($fields['description'] ?? '');
        [$name, $description] = $this->translateLabels($id, $name, $description);
        $nativeUrl = $this->nativeUrlResolver->displayUrl($id);
        $nativeSubmitUrl = $this->nativeUrlResolver->submitUrl();
        if ($nativeUrl === null) {
            throw new \RuntimeException('formcreator_web_root_unresolved');
        }

        return [
            'id' => $id,
            'source' => self::SOURCE,
            'source_label' => 'Formcreator GLPI 10',
            'visual_kind' => 'formcreator',
            'illustration' => '',
            'name' => TextNormalizer::fromGlpi($name) ?: ('Formulario #' . $id),
            'description' => TextNormalizer::fromGlpi($description),
            'entity_id' => (int) ($fields['entities_id'] ?? 0),
            'is_recursive' => !empty($fields['is_recursive']),
            'native_url' => $nativeUrl,
            'native_submit_url' => $nativeSubmitUrl ?? '',
            'rendering_status' => 'native_fallback',
            'rendering_message' => 'Abertura e submissao pelo motor nativo para preservar '
                . 'condicoes, validacoes, destinos e anexos.',
        ];
    }

    /** @return array{0:string,1:string} */
    private function translateLabels(int $id, string $name, string $description): array
    {
        try {
            if (
                !method_exists($this->formClass, 'getTranslationDomain')
                || !function_exists('__')
            ) {
                return [$name, $description];
            }
            $domain = (string) $this->formClass::getTranslationDomain($id);
            if (method_exists($this->formClass, 'getTranslationFile')) {
                $language = (string) ($_SESSION['glpilanguage'] ?? '');
                $file = (string) $this->formClass::getTranslationFile($id, $language);
                global $TRANSLATE;
                if (
                    $language !== ''
                    && is_file($file)
                    && isset($TRANSLATE)
                    && is_object($TRANSLATE)
                    && method_exists($TRANSLATE, 'addTranslationFile')
                ) {
                    $TRANSLATE->addTranslationFile('phparray', $file, $domain, $language);
                }
            }
            return [(string) __($name, $domain), (string) __($description, $domain)];
        } catch (\Throwable $e) {
            return [$name, $description];
        }
    }

    private function pluginIsActive(): bool
    {
        if ($this->activeChecker !== null) {
            try {
                return (bool) ($this->activeChecker)();
            } catch (\Throwable $e) {
                return false;
            }
        }

        if (!class_exists('\Plugin')) {
            return false;
        }
        try {
            $plugin = new \Plugin();
            return method_exists($plugin, 'isActivated') && (bool) $plugin->isActivated('formcreator');
        } catch (\Throwable $e) {
            return false;
        }
    }

    private function database(): ?object
    {
        if ($this->database !== null) {
            return $this->database;
        }
        global $DB;
        return isset($DB) && is_object($DB) ? $DB : null;
    }

    private function formTable(): string
    {
        if (!method_exists($this->formClass, 'getTable')) {
            throw new \RuntimeException('formcreator_table_unavailable');
        }
        $table = (string) $this->formClass::getTable();
        if (preg_match('/\A[a-zA-Z0-9_]+\z/', $table) !== 1) {
            throw new \RuntimeException('formcreator_table_invalid');
        }
        return $table;
    }

    private function escapeLike(string $value): string
    {
        return str_replace(['\\', '%', '_'], ['\\\\', '\\%', '\\_'], $value);
    }

    /** @return array<string, mixed>|null */
    private function decodeCursor(string $cursor, string $query): ?array
    {
        if ($cursor === '') {
            return ['offset' => 0, 'page' => 1, 'history' => []];
        }
        $parts = explode('.', $cursor, 2);
        if (count($parts) !== 2 || !hash_equals($this->sign($parts[0]), $parts[1])) {
            return null;
        }
        $decoded = $this->base64UrlDecode($parts[0]);
        $payload = $decoded !== null ? json_decode($decoded, true) : null;
        if (!is_array($payload) || (int) ($payload['v'] ?? 0) !== 1) {
            return null;
        }
        if (!hash_equals((string) ($payload['q'] ?? ''), hash('sha256', $query))) {
            return null;
        }
        if (!hash_equals((string) ($payload['ctx'] ?? ''), $this->contextRevision())) {
            return null;
        }
        $offset = (int) ($payload['o'] ?? -1);
        $page = (int) ($payload['p'] ?? 0);
        $history = array_values(array_map('intval', (array) ($payload['h'] ?? [])));
        if ($offset < 0 || $page < 1 || count($history) > self::MAX_CURSOR_HISTORY) {
            return null;
        }
        return ['offset' => $offset, 'page' => $page, 'history' => $history];
    }

    /** @param int[] $history */
    private function encodeCursor(int $offset, int $page, array $history, string $query): string
    {
        $payload = json_encode([
            'v' => 1,
            'o' => max(0, $offset),
            'p' => max(1, $page),
            'h' => array_values(array_map('intval', $history)),
            'q' => hash('sha256', $query),
            'ctx' => $this->contextRevision(),
        ], JSON_UNESCAPED_SLASHES);
        if (!is_string($payload)) {
            return '';
        }
        $encoded = rtrim(strtr(base64_encode($payload), '+/', '-_'), '=');
        return $encoded . '.' . $this->sign($encoded);
    }

    private function sign(string $payload): string
    {
        return hash_hmac('sha256', $payload, $this->cursorKey());
    }

    private function cursorKey(): string
    {
        if ($this->cursorKeyProvider !== null) {
            return (string) ($this->cursorKeyProvider)();
        }
        $applicationKey = defined('GLPIKEY') ? (string) constant('GLPIKEY') : '';
        $sessionKey = session_status() === PHP_SESSION_ACTIVE ? session_id() : '';
        return hash('sha256', $applicationKey . '|' . $sessionKey . '|' . $this->contextRevision());
    }

    private function contextRevision(): string
    {
        $profile = is_array($_SESSION['glpiactiveprofile'] ?? null)
            ? (int) ($_SESSION['glpiactiveprofile']['id'] ?? 0)
            : (int) ($_SESSION['glpiactiveprofile'] ?? 0);
        $entities = array_values(array_map('intval', (array) ($_SESSION['glpiactiveentities'] ?? [])));
        sort($entities);
        return hash('sha256', implode('|', [
            (string) ($_SESSION['glpiID'] ?? 0),
            (string) $profile,
            (string) ($_SESSION['glpiactive_entity'] ?? 0),
            !empty($_SESSION['glpiactive_entity_recursive']) ? '1' : '0',
            implode(',', $entities),
            (string) ($_SESSION['glpilanguage'] ?? ''),
        ]));
    }

    private function base64UrlDecode(string $value): ?string
    {
        $padding = (4 - (strlen($value) % 4)) % 4;
        $decoded = base64_decode(strtr($value . str_repeat('=', $padding), '-_', '+/'), true);
        return is_string($decoded) ? $decoded : null;
    }

    /** @return array<string, mixed> */
    private function capability(bool $available, bool $enabled, string $state, string $code): array
    {
        return [
            'available' => $available,
            'enabled' => $enabled,
            'state' => $state,
            'diagnostic_code' => $code,
            'glpi_version' => $this->glpiVersion
                ?? (defined('GLPI_VERSION') ? (string) constant('GLPI_VERSION') : 'unknown'),
            'formcreator_version' => defined('PLUGIN_FORMCREATOR_VERSION')
                ? (string) constant('PLUGIN_FORMCREATOR_VERSION')
                : 'unknown',
            'native_url' => $this->nativeUrlResolver->catalogUrl() ?? '',
            'native_submit_url' => $this->nativeUrlResolver->submitUrl() ?? '',
        ];
    }

    /** @return array<string, mixed> */
    private function emptyPage(
        string $state,
        string $code,
        FormCatalogRequest $request,
        float $started,
        int $page = 1
    ): array {
        return [
            'items' => [],
            'state' => $state,
            'diagnostic_code' => $code,
            'correlation_id' => in_array($state, ['error', 'partial'], true) ? $this->correlationId() : '',
            'page' => $page,
            'page_size' => $request->pageSize,
            'has_more' => false,
            'next_cursor' => '',
            'previous_cursor' => '',
            'query' => $request->query,
            'duration_ms' => (int) round((microtime(true) - $started) * 1000),
            'candidate_count' => 0,
            'item_count' => 0,
            'total' => null,
        ];
    }

    private function correlationId(): string
    {
        try {
            return bin2hex(random_bytes(8));
        } catch (\Throwable $e) {
            return substr(hash('sha256', (string) microtime(true)), 0, 16);
        }
    }
}
