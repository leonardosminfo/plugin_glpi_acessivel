<?php

declare(strict_types=1);

namespace GlpiPlugin\Glpiacessivel\Infrastructure\FormCatalog;

final class FormCatalogRequest
{
    public string $query;
    public string $cursor;
    public int $pageSize;

    public function __construct(string $query = '', string $cursor = '', int $pageSize = 24)
    {
        $query = trim(strip_tags($query));
        $this->query = function_exists('mb_substr')
            ? mb_substr($query, 0, 120, 'UTF-8')
            : substr($query, 0, 120);
        $this->cursor = substr(trim($cursor), 0, 4000);
        $this->pageSize = min(50, max(1, $pageSize));
    }
}
