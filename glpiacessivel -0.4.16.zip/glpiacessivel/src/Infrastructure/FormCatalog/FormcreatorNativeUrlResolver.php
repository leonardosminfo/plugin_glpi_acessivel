<?php

declare(strict_types=1);

namespace GlpiPlugin\Glpiacessivel\Infrastructure\FormCatalog;

/**
 * Resolves the public Formcreator root from the active GLPI installation.
 *
 * GLPI 10 may expose plugins from either /plugins or /marketplace. The path
 * must therefore come from the native plugin API, never from a browser value
 * or from a guessed filesystem location.
 */
final class FormcreatorNativeUrlResolver
{
    /** @var \Closure():mixed|null */
    private ?\Closure $rootProvider;
    private ?string $glpiVersion;
    private ?string $rootDoc;
    private bool $resolved = false;
    private ?string $resolvedRoot = null;

    public function __construct(
        ?callable $rootProvider = null,
        ?string $glpiVersion = null,
        ?string $rootDoc = null
    ) {
        $this->rootProvider = $rootProvider !== null ? \Closure::fromCallable($rootProvider) : null;
        $this->glpiVersion = $glpiVersion;
        $this->rootDoc = $rootDoc;
    }

    public function catalogUrl(): ?string
    {
        return $this->append('front/formlist.php');
    }

    public function displayUrl(int $formId): ?string
    {
        if ($formId <= 0) {
            return null;
        }

        $url = $this->append('front/formdisplay.php');
        return $url !== null ? $url . '?' . http_build_query(['id' => $formId], '', '&', PHP_QUERY_RFC3986) : null;
    }

    public function submitUrl(): ?string
    {
        return $this->append('ajax/formanswer.php');
    }

    /** @return array{state:string,code:string,root:string} */
    public function diagnostics(): array
    {
        $root = $this->resolveRoot();
        return [
            'state' => $root !== null ? 'ready' : 'unavailable',
            'code' => $root !== null ? 'formcreator_web_root_ready' : 'formcreator_web_root_unresolved',
            // Public web path only. Never expose a filesystem path.
            'root' => $root ?? '',
        ];
    }

    private function append(string $suffix): ?string
    {
        $root = $this->resolveRoot();
        if ($root === null || preg_match('/\A[a-zA-Z0-9_\/-]+\.php\z/', $suffix) !== 1) {
            return null;
        }

        return $root . '/' . ltrim($suffix, '/');
    }

    private function resolveRoot(): ?string
    {
        if ($this->resolved) {
            return $this->resolvedRoot;
        }
        $this->resolved = true;

        $version = $this->glpiVersion ?? (defined('GLPI_VERSION') ? (string) constant('GLPI_VERSION') : '');
        if ($version !== '' && version_compare($version, '11.0.0', '>=')) {
            return null;
        }

        $candidates = [];
        if (defined('FORMCREATOR_ROOTDOC')) {
            $candidates[] = constant('FORMCREATOR_ROOTDOC');
        }
        if ($this->rootProvider !== null) {
            try {
                $candidates[] = ($this->rootProvider)();
            } catch (\Throwable $e) {
                // Fall through to a closed failure.
            }
        } elseif (class_exists('\Plugin') && is_callable(['\Plugin', 'getWebDir'])) {
            try {
                $candidates[] = call_user_func(['\Plugin', 'getWebDir'], 'formcreator');
            } catch (\Throwable $e) {
                // Fall through to a closed failure.
            }
        }

        foreach ($candidates as $candidate) {
            $validated = $this->validateRoot($candidate);
            if ($validated !== null) {
                $this->resolvedRoot = $validated;
                return $validated;
            }
        }

        return null;
    }

    private function validateRoot(mixed $candidate): ?string
    {
        if (!is_string($candidate)) {
            return null;
        }
        $candidate = rtrim(trim($candidate), '/');
        if (
            $candidate === ''
            || $candidate[0] !== '/'
            || str_contains($candidate, '\\')
            || str_contains($candidate, '//')
            || preg_match('/[\x00-\x1F\x7F]/', $candidate) === 1
            || preg_match('#(?:^|/)\.\.?(/|$)#', $candidate) === 1
        ) {
            return null;
        }

        $parts = parse_url($candidate);
        if (
            !is_array($parts)
            || isset($parts['scheme'])
            || isset($parts['host'])
            || isset($parts['query'])
            || isset($parts['fragment'])
            || (string) ($parts['path'] ?? '') !== $candidate
        ) {
            return null;
        }

        $segments = array_values(array_filter(explode('/', $candidate), static fn(string $part): bool => $part !== ''));
        $count = count($segments);
        if ($count < 2 || $segments[$count - 1] !== 'formcreator') {
            return null;
        }
        $parent = $segments[$count - 2];
        if (!in_array($parent, ['plugins', 'marketplace'], true)) {
            return null;
        }

        $rootDoc = $this->rootDoc;
        if ($rootDoc === null) {
            global $CFG_GLPI;
            $rootDoc = (string) ($CFG_GLPI['root_doc'] ?? '');
        }
        $rootDoc = rtrim(trim((string) $rootDoc), '/');
        if ($rootDoc !== '' && $candidate !== $rootDoc && !str_starts_with($candidate, $rootDoc . '/')) {
            return null;
        }

        return $candidate;
    }
}
