<?php

declare(strict_types=1);

namespace GlpiPlugin\Glpiacessivel\Infrastructure\FormCatalog;

interface FormCatalogGateway
{
    /** @return array<string, mixed> */
    public function capabilities(): array;

    /** @return array<string, mixed> */
    public function list(FormCatalogRequest $request): array;

    /** @return array<string, mixed>|null */
    public function findAuthorized(int $id): ?array;
}
