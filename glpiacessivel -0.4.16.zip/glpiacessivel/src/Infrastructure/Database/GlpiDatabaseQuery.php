<?php

declare(strict_types=1);

namespace GlpiPlugin\Glpiacessivel\Infrastructure\Database;

final class GlpiDatabaseQuery
{
    public static function isSupported(object $database): bool
    {
        return is_callable([$database, 'doQuery']) || is_callable([$database, 'query']);
    }

    /** @return mixed */
    public static function execute(object $database, string $sql)
    {
        if (is_callable([$database, 'doQuery'])) {
            return $database->doQuery($sql);
        }

        if (is_callable([$database, 'query'])) {
            return $database->query($sql);
        }

        throw new \RuntimeException('glpi_database_query_not_supported');
    }
}
