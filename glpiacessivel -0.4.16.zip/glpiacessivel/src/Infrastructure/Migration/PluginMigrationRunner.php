<?php

declare(strict_types=1);

namespace GlpiPlugin\Glpiacessivel\Infrastructure\Migration;

use DBmysql;
use GlpiPlugin\Glpiacessivel\Infrastructure\Database\GlpiDatabaseQuery;

final class PluginMigrationRunner
{
    public const TABLE = 'glpi_plugin_glpiacessivel_migrations';
    private const LOCK_NAME = 'glpiacessivel_schema_migrations';

    public function __construct(
        private DBmysql $db,
        private string $charset,
        private string $collation
    ) {
    }

    public function run(string $identifier, string $checksum, callable $migration): bool
    {
        if (!$this->isValidIdentifier($identifier) || preg_match('/\A[a-f0-9]{64}\z/D', $checksum) !== 1) {
            return false;
        }
        if (!$this->acquireLock()) {
            return false;
        }

        try {
            if (!$this->ensureLedger()) {
                return false;
            }
            $existing = $this->find($identifier);
            if ($existing !== null) {
                return hash_equals((string) ($existing['checksum'] ?? ''), $checksum);
            }
            if ($migration() !== true) {
                return false;
            }

            return (bool) $this->db->insert(self::TABLE, [
                'migration_id' => $identifier,
                'checksum' => $checksum,
                'applied_at' => date('Y-m-d H:i:s'),
            ]);
        } catch (\Throwable) {
            return false;
        } finally {
            $this->releaseLock();
        }
    }

    private function ensureLedger(): bool
    {
        return (bool) GlpiDatabaseQuery::execute(
            $this->db,
            "CREATE TABLE IF NOT EXISTS `" . self::TABLE . "` (
                `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
                `migration_id` VARCHAR(120) NOT NULL,
                `checksum` CHAR(64) NOT NULL,
                `applied_at` DATETIME NOT NULL,
                PRIMARY KEY (`id`),
                UNIQUE KEY `uniq_migration_id` (`migration_id`)
            ) ENGINE=InnoDB DEFAULT CHARSET={$this->charset} COLLATE={$this->collation}"
        );
    }

    /** @return array<string,mixed>|null */
    private function find(string $identifier): ?array
    {
        $row = $this->db->request([
            'SELECT' => ['migration_id', 'checksum', 'applied_at'],
            'FROM' => self::TABLE,
            'WHERE' => ['migration_id' => $identifier],
            'LIMIT' => 1,
        ])->current();

        return is_array($row) ? $row : null;
    }

    private function acquireLock(): bool
    {
        try {
            $result = GlpiDatabaseQuery::execute(
                $this->db,
                "SELECT GET_LOCK('" . self::LOCK_NAME . "', 10) AS acquired"
            );
            if ($result === true) {
                return true;
            }
            $row = null;
            if (method_exists($this->db, 'fetchAssoc')) {
                $row = $this->db->fetchAssoc($result);
            } elseif (is_object($result) && method_exists($result, 'fetch_assoc')) {
                $row = $result->fetch_assoc();
            }

            return is_array($row) && (int) ($row['acquired'] ?? 0) === 1;
        } catch (\Throwable) {
            return false;
        }
    }

    private function releaseLock(): void
    {
        try {
            GlpiDatabaseQuery::execute(
                $this->db,
                "SELECT RELEASE_LOCK('" . self::LOCK_NAME . "')"
            );
        } catch (\Throwable) {
            // The database releases advisory locks when the connection closes.
        }
    }

    private function isValidIdentifier(string $identifier): bool
    {
        return preg_match('/\AV[0-9]{4}_[A-Za-z0-9_]{1,100}\z/D', $identifier) === 1;
    }
}
