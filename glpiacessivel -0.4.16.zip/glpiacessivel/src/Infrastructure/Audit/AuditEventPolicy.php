<?php

declare(strict_types=1);

namespace GlpiPlugin\Glpiacessivel\Infrastructure\Audit;

use GlpiPlugin\Glpiacessivel\Application\ConfigService;

final class AuditEventPolicy
{
    private const OPERATIONAL_EVENTS = [
        'ticket.list',
        'ticket.detail',
        'ticket.results.async',
        'ticket.itil_template.preview',
        'forms.list',
        'forms.open_native_fallback',
        'cockpit.view',
        'kb.overview',
        'kb.search',
        'chatbot.metric',
        'chatbot.intent.detected',
        'chatbot.intent.mine_tickets',
        'chatbot.intent.ticket_lookup',
        'chatbot.playbook.matched',
    ];

    private ?string $cachedMode = null;
    private ?bool $cachedPiiProtection = null;

    public function __construct(
        private ?ConfigService $config = null,
        private ?string $forcedMode = null,
        private ?bool $forcedPiiProtection = null
    ) {
    }

    public function mode(): string
    {
        if ($this->forcedMode !== null) {
            return $this->normalizeMode($this->forcedMode);
        }
        if ($this->cachedMode !== null) {
            return $this->cachedMode;
        }

        try {
            $this->cachedMode = ($this->config ?? new ConfigService())->getAuditMode();
        } catch (\Throwable) {
            $this->cachedMode = ConfigService::AUDIT_MODE_CRITICAL;
        }

        return $this->cachedMode;
    }

    public function isPiiProtectionEnabled(): bool
    {
        if ($this->forcedPiiProtection !== null) {
            return $this->forcedPiiProtection;
        }
        if ($this->cachedPiiProtection !== null) {
            return $this->cachedPiiProtection;
        }

        try {
            $this->cachedPiiProtection = ($this->config ?? new ConfigService())->isPiiMaskingEnabled();
        } catch (\Throwable) {
            $this->cachedPiiProtection = false;
        }

        return $this->cachedPiiProtection;
    }

    public function shouldPersist(string $action): bool
    {
        $action = trim($action);
        if ($action === '' || strlen($action) > 120) {
            return false;
        }
        if ($action === 'pii.reveal' && !$this->isPiiProtectionEnabled()) {
            return false;
        }

        $mode = $this->mode();
        if ($mode === ConfigService::AUDIT_MODE_DISABLED) {
            return false;
        }
        if ($mode === ConfigService::AUDIT_MODE_FULL) {
            return true;
        }

        return !$this->isRoutineOperationalEvent($action) || $this->isSecurityEvent($action);
    }

    public function canPersistPiiReveal(): bool
    {
        return $this->isPiiProtectionEnabled()
            && $this->mode() !== ConfigService::AUDIT_MODE_DISABLED;
    }

    public function includeIp(string $action): bool
    {
        return $this->isSecurityEvent($action);
    }

    public function isSecurityEvent(string $action): bool
    {
        return preg_match('/(?:^|\.)(blocked|denied|failed|error|invalid|rejected|csrf)(?:$|\.)/i', $action) === 1
            || str_starts_with($action, 'security.')
            || str_starts_with($action, 'session.context_');
    }

    private function isRoutineOperationalEvent(string $action): bool
    {
        if (in_array($action, self::OPERATIONAL_EVENTS, true)) {
            return true;
        }

        return str_starts_with($action, 'ticket.search_value.')
            && !$this->isSecurityEvent($action);
    }

    private function normalizeMode(string $mode): string
    {
        return in_array($mode, ConfigService::AUDIT_MODES, true)
            ? $mode
            : ConfigService::AUDIT_MODE_CRITICAL;
    }
}
