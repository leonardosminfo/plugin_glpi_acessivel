<?php

declare(strict_types=1);

namespace GlpiPlugin\Glpiacessivel\Infrastructure\Audit;

use DBmysql;
use GlpiPlugin\Glpiacessivel\Domain\Security\AuditAuthorization;

final class AuditQueryService
{
    public const DEFAULT_PAGE_SIZE = 25;
    public const MAX_PAGE_SIZE = 100;
    private const CURSOR_TTL_SECONDS = 300;

    public function __construct(
        private DBmysql $db,
        private AuditAuthorization $authorization
    ) {
    }

    /**
     * @param array<string,mixed> $filters
     * @return array{rows:list<array<string,mixed>>,next_cursor:?string,has_more:bool,from:string,to:string}
     */
    public function search(array $filters = [], ?string $cursor = null, int $limit = self::DEFAULT_PAGE_SIZE): array
    {
        if (!$this->authorization->canRead()) {
            throw new \RuntimeException('audit_read_denied');
        }

        $limit = min(self::MAX_PAGE_SIZE, max(1, $limit));
        [$from, $to] = $this->normalizePeriod($filters);
        $action = $this->normalizeAction((string) ($filters['action'] ?? ''));
        $ticketId = max(0, (int) ($filters['ticket_id'] ?? 0));
        $userId = max(0, (int) ($filters['user_id'] ?? 0));
        $contextFingerprint = $this->contextFingerprint($from, $to, $action, $ticketId, $userId);
        $cursorId = $cursor !== null && $cursor !== ''
            ? $this->decodeCursor($cursor, $contextFingerprint)
            : null;
        $where = [
            ['created_at' => ['>=', $from]],
            ['created_at' => ['<=', $to]],
        ];
        if ($cursorId !== null) {
            $where[] = ['id' => ['<', $cursorId]];
        }

        if ($action !== '') {
            $where[] = ['action' => $action];
        }
        foreach (['tickets_id' => $ticketId, 'users_id' => $userId] as $column => $value) {
            if ($value > 0) {
                $where[] = [$column => $value];
            }
        }

        $fetchLimit = min(401, ($limit * 4) + 1);
        $rows = [];
        $lastScannedId = 0;
        $scanned = 0;
        foreach (
            $this->db->request([
            'SELECT' => [
                'id',
                'users_id',
                'entities_id',
                'resource_entities_id',
                'context_entities_id',
                'scope_kind',
                'tickets_id',
                'action',
                'created_at',
            ],
            'FROM' => 'glpi_plugin_glpiacessivel_auditlogs',
            'WHERE' => $where,
            'ORDER' => ['id DESC'],
            'LIMIT' => $fetchLimit,
            ]) as $row
        ) {
            if (!is_array($row)) {
                continue;
            }
            $scanned++;
            $lastScannedId = max(0, (int) ($row['id'] ?? 0));
            $sensitive = $this->isSensitiveRow($row);
            if (!$this->authorization->canReadRow($row, $sensitive)) {
                continue;
            }

            $rows[] = $this->present($row);
            if (count($rows) > $limit) {
                break;
            }
        }

        $hasMore = count($rows) > $limit || $scanned >= $fetchLimit;
        $nextCursorId = $lastScannedId;
        if (count($rows) > $limit) {
            array_pop($rows);
            $last = end($rows);
            $nextCursorId = (int) ($last['id'] ?? $nextCursorId);
        }

        return [
            'rows' => array_values($rows),
            'next_cursor' => $hasMore && $nextCursorId > 0
                ? $this->encodeCursor($nextCursorId, $contextFingerprint)
                : null,
            'has_more' => $hasMore,
            'from' => $from,
            'to' => $to,
        ];
    }

    /** @param array<string,mixed> $filters @return array{0:string,1:string} */
    private function normalizePeriod(array $filters): array
    {
        $today = new \DateTimeImmutable('today');
        $defaultFrom = $today->modify('-1 day');
        $from = $this->date((string) ($filters['from'] ?? ''), $defaultFrom);
        $to = $this->date((string) ($filters['to'] ?? ''), $today);
        if ($to < $from) {
            [$from, $to] = [$to, $from];
        }
        if ($from->diff($to)->days > 31) {
            $from = $to->modify('-31 days');
        }

        return [$from->format('Y-m-d 00:00:00'), $to->format('Y-m-d 23:59:59')];
    }

    private function date(string $value, \DateTimeImmutable $default): \DateTimeImmutable
    {
        if (preg_match('/\A\d{4}-\d{2}-\d{2}\z/D', $value) !== 1) {
            return $default;
        }
        $date = \DateTimeImmutable::createFromFormat('!Y-m-d', $value);
        return $date instanceof \DateTimeImmutable ? $date : $default;
    }

    private function normalizeAction(string $action): string
    {
        $action = trim($action);
        return preg_match('/\A[a-z0-9_.-]{1,120}\z/D', $action) === 1 ? $action : '';
    }

    /** @param array<string,mixed> $row */
    private function isSensitiveRow(array $row): bool
    {
        return str_starts_with((string) ($row['action'] ?? ''), 'pii.');
    }

    /** @param array<string,mixed> $row @return array<string,mixed> */
    private function present(array $row): array
    {
        $action = (string) ($row['action'] ?? '');
        return [
            'id' => (int) ($row['id'] ?? 0),
            'created_at' => (string) ($row['created_at'] ?? ''),
            'action' => $action,
            'action_label' => $this->actionLabel($action),
            'users_id' => (int) ($row['users_id'] ?? 0),
            'entities_id' => (int) ($row['resource_entities_id'] ?? $row['entities_id'] ?? 0),
            'tickets_id' => (int) ($row['tickets_id'] ?? 0),
            'scope_kind' => (string) ($row['scope_kind'] ?? 'legacy'),
            'result' => $this->resultLabel($action),
        ];
    }

    private function actionLabel(string $action): string
    {
        $labels = [
            'ticket.create' => __('Chamado criado', 'glpiacessivel'),
            'ticket.followup.add' => __('Acompanhamento adicionado', 'glpiacessivel'),
            'ticket.task.add' => __('Tarefa adicionada', 'glpiacessivel'),
            'ticket.solution.add' => __('Solução adicionada', 'glpiacessivel'),
            'ticket.solution.verified' => __('Solução confirmada', 'glpiacessivel'),
            'ticket.solution.rejected' => __('Solução não registrada', 'glpiacessivel'),
            'ticket.solution.partial' => __('Solução requer revisão', 'glpiacessivel'),
            'ticket.status.change' => __('Status do chamado alterado', 'glpiacessivel'),
            'config.update' => __('Configuração do plugin alterada', 'glpiacessivel'),
            'pii.reveal' => __('Dado pessoal protegido consultado', 'glpiacessivel'),
            'audit.view' => __('Trilha de auditoria consultada', 'glpiacessivel'),
            'audit.export' => __('Auditoria exportada', 'glpiacessivel'),
            'audit.rights.updated' => __('Direitos de auditoria alterados', 'glpiacessivel'),
        ];
        if (isset($labels[$action])) {
            return $labels[$action];
        }
        if (preg_match('/(?:blocked|denied|rejected)/', $action) === 1) {
            return __('Ação bloqueada pela política de segurança', 'glpiacessivel');
        }
        if (preg_match('/(?:failed|error|invalid)/', $action) === 1) {
            return __('Operação não concluída', 'glpiacessivel');
        }

        return __('Evento operacional do plugin', 'glpiacessivel');
    }

    private function resultLabel(string $action): string
    {
        if ($action === 'ticket.solution.partial') {
            return __('Requer revisão', 'glpiacessivel');
        }
        if (preg_match('/(?:blocked|denied|rejected)/', $action) === 1) {
            return __('Bloqueado', 'glpiacessivel');
        }
        if (preg_match('/(?:failed|error|invalid)/', $action) === 1) {
            return __('Falhou', 'glpiacessivel');
        }

        return __('Concluído', 'glpiacessivel');
    }

    private function contextFingerprint(
        string $from,
        string $to,
        string $action,
        int $ticketId,
        int $userId
    ): string {
        $entities = $this->authorization->activeEntities();
        sort($entities, SORT_NUMERIC);
        $context = json_encode([
            'from' => $from,
            'to' => $to,
            'action' => $action,
            'ticket_id' => $ticketId,
            'user_id' => $userId,
            'entities' => $entities,
            'recursive' => !empty($_SESSION['glpiactive_entity_recursive']),
        ], JSON_UNESCAPED_SLASHES);
        if (!is_string($context)) {
            throw new \RuntimeException('audit_cursor_context_failed');
        }

        return hash('sha256', $context);
    }

    private function encodeCursor(int $id, string $contextFingerprint): string
    {
        $payload = [
            'id' => $id,
            'uid' => (int) ($_SESSION['glpiID'] ?? 0),
            'profile' => (int) ($_SESSION['glpiactiveprofile']['id'] ?? 0),
            'entity' => (int) ($_SESSION['glpiactive_entity'] ?? 0),
            'context' => $contextFingerprint,
            'exp' => time() + self::CURSOR_TTL_SECONDS,
        ];
        $json = json_encode($payload, JSON_UNESCAPED_SLASHES);
        if (!is_string($json)) {
            throw new \RuntimeException('audit_cursor_encode_failed');
        }
        $encoded = $this->base64UrlEncode($json);
        return $encoded . '.' . hash_hmac('sha256', $encoded, $this->cursorKey());
    }

    private function decodeCursor(string $cursor, string $contextFingerprint): int
    {
        $parts = explode('.', $cursor, 2);
        if (count($parts) !== 2 || !hash_equals(hash_hmac('sha256', $parts[0], $this->cursorKey()), $parts[1])) {
            throw new \RuntimeException('audit_cursor_invalid');
        }
        $decoded = $this->base64UrlDecode($parts[0]);
        $payload = is_string($decoded) ? json_decode($decoded, true) : null;
        if (!is_array($payload)) {
            throw new \RuntimeException('audit_cursor_invalid');
        }
        if (
            (int) ($payload['exp'] ?? 0) < time()
            || (int) ($payload['uid'] ?? -1) !== (int) ($_SESSION['glpiID'] ?? 0)
            || (int) ($payload['profile'] ?? -1) !== (int) ($_SESSION['glpiactiveprofile']['id'] ?? 0)
            || (int) ($payload['entity'] ?? -1) !== (int) ($_SESSION['glpiactive_entity'] ?? 0)
            || !is_string($payload['context'] ?? null)
            || !hash_equals($contextFingerprint, (string) $payload['context'])
        ) {
            throw new \RuntimeException('audit_cursor_context_changed');
        }
        $id = (int) ($payload['id'] ?? 0);
        if ($id <= 0) {
            throw new \RuntimeException('audit_cursor_invalid');
        }

        return $id;
    }

    private function cursorKey(): string
    {
        if (empty($_SESSION['glpiacessivel_audit_cursor_key'])) {
            $_SESSION['glpiacessivel_audit_cursor_key'] = bin2hex(random_bytes(32));
        }
        return (string) $_SESSION['glpiacessivel_audit_cursor_key'];
    }

    private function base64UrlEncode(string $value): string
    {
        return rtrim(strtr(base64_encode($value), '+/', '-_'), '=');
    }

    private function base64UrlDecode(string $value): string|false
    {
        $padding = strlen($value) % 4;
        if ($padding > 0) {
            $value .= str_repeat('=', 4 - $padding);
        }
        return base64_decode(strtr($value, '-_', '+/'), true);
    }
}
