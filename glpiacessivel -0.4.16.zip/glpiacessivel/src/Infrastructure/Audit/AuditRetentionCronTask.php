<?php

declare(strict_types=1);

namespace GlpiPlugin\Glpiacessivel\Infrastructure\Audit;

use GlpiPlugin\Glpiacessivel\Application\ConfigService;

final class AuditRetentionCronTask
{
    /** @return array{description?:string} */
    public static function cronInfo(string $name): array
    {
        if ($name !== 'PurgeAuditLogs') {
            return [];
        }

        return [
            'description' => __('Remove registros de auditoria expirados em lotes limitados.', 'glpiacessivel'),
        ];
    }

    public static function cronPurgeAuditLogs(\CronTask $task): int
    {
        global $DB;

        $config = new ConfigService();
        $service = new AuditRetentionService($DB);
        $deleted = 0;
        $startedAt = microtime(true);
        for ($batch = 0; $batch < 5; $batch++) {
            $result = $service->purgeExpired(
                $config->getAuditRetentionDays(),
                $config->getAuditRetentionBatchSize()
            );
            $deleted += max(0, (int) ($result['deleted'] ?? 0));
            if (empty($result['has_more']) || (microtime(true) - $startedAt) >= 2.0) {
                break;
            }
        }
        if ($deleted > 0 && method_exists($task, 'addVolume')) {
            $task->addVolume($deleted);
        }

        return $deleted > 0 ? 1 : 0;
    }
}
