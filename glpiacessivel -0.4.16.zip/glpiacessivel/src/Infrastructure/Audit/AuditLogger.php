<?php

declare(strict_types=1);

namespace GlpiPlugin\Glpiacessivel\Infrastructure\Audit;

final class AuditLogger
{
    private AuditEventPolicy $policy;
    private AuditPayloadSanitizer $sanitizer;

    public function __construct(
        ?AuditEventPolicy $policy = null,
        ?AuditPayloadSanitizer $sanitizer = null
    ) {
        $this->policy = $policy ?? new AuditEventPolicy();
        $this->sanitizer = $sanitizer ?? new AuditPayloadSanitizer();
    }

    /** @param array<string,mixed> $payload */
    public function log(string $action, array $payload = [], ?int $ticketId = null): void
    {
        global $DB;

        if (!$this->policy->shouldPersist($action)) {
            return;
        }

        try {
            $record = $this->record($action, $payload, $ticketId);
            if (!$DB->insert('glpi_plugin_glpiacessivel_auditlogs', $record)) {
                throw new \RuntimeException('audit_insert_failed');
            }
        } catch (\Throwable $e) {
            $this->logFallback('audit.log.failed', $action, $e, $ticketId);
        }
    }

    public function logPiiReveal(int $ticketId, string $field, ?string $reason = null): void
    {
        global $DB;

        if (!$this->policy->isPiiProtectionEnabled()) {
            return;
        }
        if (!$this->policy->canPersistPiiReveal()) {
            throw new \RuntimeException('pii_reveal_audit_unavailable');
        }
        if (!in_array($field, ['requester_email', 'requester_phone', 'requester_mobile'], true)) {
            throw new \RuntimeException('pii_reveal_field_invalid');
        }

        $userId = (int) ($_SESSION['glpiID'] ?? 0);
        $contextEntityId = (int) ($_SESSION['glpiactive_entity'] ?? 0);
        $createdAt = date('Y-m-d H:i:s');
        $transaction = method_exists($DB, 'beginTransaction')
            && method_exists($DB, 'commit')
            && method_exists($DB, 'rollBack');
        $revealId = 0;

        try {
            if ($transaction && $DB->beginTransaction() === false) {
                throw new \RuntimeException('pii_reveal_transaction_failed');
            }
            if (
                !$DB->insert('glpi_plugin_glpiacessivel_piireveals', [
                'users_id' => $userId,
                'entities_id' => $contextEntityId,
                'tickets_id' => $ticketId,
                'field_name' => $field,
                'reason' => $this->normalizeReason($reason),
                'created_at' => $createdAt,
                ])
            ) {
                throw new \RuntimeException('pii_reveal_ledger_insert_failed');
            }
            if (method_exists($DB, 'insertId')) {
                $revealId = max(0, (int) $DB->insertId());
            }

            $record = $this->record('pii.reveal', [
                'field' => $field,
                'reason_length' => strlen((string) $reason),
            ], $ticketId, $createdAt);
            if (!$DB->insert('glpi_plugin_glpiacessivel_auditlogs', $record)) {
                throw new \RuntimeException('pii_reveal_audit_insert_failed');
            }
            if ($transaction && $DB->commit() === false) {
                throw new \RuntimeException('pii_reveal_commit_failed');
            }
        } catch (\Throwable $e) {
            if ($transaction) {
                try {
                    $DB->rollBack();
                } catch (\Throwable) {
                    // The original failure remains authoritative.
                }
            } elseif ($revealId > 0) {
                try {
                    $DB->delete('glpi_plugin_glpiacessivel_piireveals', ['id' => $revealId]);
                } catch (\Throwable) {
                    // The reveal remains blocked even if compensation fails.
                }
            }
            $this->logFallback('audit.pii_reveal.failed', 'pii.reveal', $e, $ticketId);
            throw new \RuntimeException('pii_reveal_audit_failed', 0, $e);
        }
    }

    /**
     * Legacy compatibility entry point. New presentations use
     * AuditQueryService so all of them share the same authorization.
     *
     * @return list<array<string,mixed>>
     */
    public function recentActions(int $limit = 10, ?int $ticketId = null): array
    {
        global $DB;

        try {
            $authorization = new \GlpiPlugin\Glpiacessivel\Domain\Security\AuditAuthorization();
            $result = (new AuditQueryService($DB, $authorization))->search([
                'ticket_id' => max(0, (int) $ticketId),
            ], null, min(30, max(1, $limit)));
            return $result['rows'];
        } catch (\Throwable $e) {
            $this->logFallback('audit.recent_actions.failed', 'audit.recent_actions', $e, $ticketId);
            return [];
        }
    }

    /** @param array<string,mixed> $payload @return array<string,mixed> */
    private function record(
        string $action,
        array $payload,
        ?int $ticketId,
        ?string $createdAt = null
    ): array {
        $contextEntityId = (int) ($_SESSION['glpiactive_entity'] ?? 0);
        $resourceEntityId = $ticketId !== null && $ticketId > 0
            ? $this->ticketEntityId($ticketId, $contextEntityId)
            : $contextEntityId;
        $scope = $this->scopeFor($action, $ticketId);
        if ($scope === 'global') {
            $resourceEntityId = 0;
        }

        $sanitized = $this->sanitizer->sanitize($payload);
        $encoded = json_encode($sanitized, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
        return [
            'users_id' => (int) ($_SESSION['glpiID'] ?? 0),
            'entities_id' => $contextEntityId,
            'resource_entities_id' => $resourceEntityId,
            'context_entities_id' => $contextEntityId,
            'scope_kind' => $scope,
            'tickets_id' => $ticketId,
            'action' => $action,
            'payload' => is_string($encoded) ? $encoded : '{}',
            'ip' => $this->policy->includeIp($action) ? (string) ($_SERVER['REMOTE_ADDR'] ?? '') : null,
            'created_at' => $createdAt ?? date('Y-m-d H:i:s'),
        ];
    }

    private function scopeFor(string $action, ?int $ticketId): string
    {
        if ($ticketId !== null && $ticketId > 0) {
            return 'ticket';
        }
        if (str_starts_with($action, 'config.') || str_starts_with($action, 'audit.policy.')) {
            return 'global';
        }

        return 'entity';
    }

    private function ticketEntityId(int $ticketId, int $fallback): int
    {
        static $cache = [];
        if (isset($cache[$ticketId])) {
            return $cache[$ticketId];
        }
        if (!class_exists('\Ticket')) {
            return $fallback;
        }

        try {
            $ticket = new \Ticket();
            if (method_exists($ticket, 'getFromDB') && $ticket->getFromDB($ticketId)) {
                $fields = is_array($ticket->fields ?? null) ? $ticket->fields : [];
                return $cache[$ticketId] = max(0, (int) ($fields['entities_id'] ?? $fallback));
            }
        } catch (\Throwable) {
            return $fallback;
        }

        return $fallback;
    }

    private function normalizeReason(?string $reason): string
    {
        $raw = trim((string) $reason);
        return $raw === '' ? '' : '[len=' . strlen($raw) . ']';
    }

    private function logFallback(string $event, string $action, \Throwable $e, ?int $ticketId = null): void
    {
        $message = sprintf(
            "%s action=%s ticket=%s error=%s\n",
            $event,
            $action,
            $ticketId !== null ? (string) $ticketId : '-',
            get_class($e)
        );
        if (class_exists('Toolbox') && method_exists('Toolbox', 'logInFile')) {
            \Toolbox::logInFile('glpiacessivel-audit-errors', $message);
            return;
        }

        error_log('[glpiacessivel] ' . trim($message));
    }
}
