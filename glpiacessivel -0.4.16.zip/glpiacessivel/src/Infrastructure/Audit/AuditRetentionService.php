<?php

declare(strict_types=1);

namespace GlpiPlugin\Glpiacessivel\Infrastructure\Audit;

use DBmysql;

/** Removes expired audit data in bounded, index-friendly batches. */
final class AuditRetentionService
{
    private const TABLES = [
        'glpi_plugin_glpiacessivel_auditlogs',
        'glpi_plugin_glpiacessivel_piireveals',
    ];

    public function __construct(private DBmysql $db)
    {
    }

    /**
     * @return array{deleted:int,has_more:bool,tables:array<string,int>}
     */
    public function purgeExpired(int $retentionDays, int $batchSize): array
    {
        $retentionDays = min(3650, max(30, $retentionDays));
        $batchSize = min(5000, max(100, $batchSize));
        $cutoff = date('Y-m-d H:i:s', time() - ($retentionDays * 86400));
        $deleted = 0;
        $hasMore = false;
        $tables = [];

        foreach (self::TABLES as $table) {
            $ids = $this->expiredIds($table, $cutoff, $batchSize);
            $tableDeleted = count($ids);
            if ($tableDeleted > 0 && !$this->db->delete($table, ['id' => $ids])) {
                throw new \RuntimeException('audit_retention_delete_failed');
            }

            $tables[$table] = $tableDeleted;
            $deleted += $tableDeleted;
            $hasMore = $hasMore || $tableDeleted >= $batchSize;
        }

        return [
            'deleted' => $deleted,
            'has_more' => $hasMore,
            'tables' => $tables,
        ];
    }

    /** @return int[] */
    private function expiredIds(string $table, string $cutoff, int $batchSize): array
    {
        $ids = [];
        $rows = $this->db->request([
            'SELECT' => ['id'],
            'FROM' => $table,
            'WHERE' => ['created_at' => ['<', $cutoff]],
            'ORDER' => ['created_at ASC', 'id ASC'],
            'LIMIT' => $batchSize,
        ]);
        foreach ($rows as $row) {
            $id = (int) ($row['id'] ?? 0);
            if ($id > 0) {
                $ids[$id] = $id;
            }
        }

        return array_values($ids);
    }
}
