<?php

declare(strict_types=1);

namespace GlpiPlugin\Glpiacessivel\Infrastructure\Audit;

final class AuditRights
{
    public const READ = 'plugin_glpiacessivel_audit_read';
    public const SENSITIVE = 'plugin_glpiacessivel_audit_sensitive';
    public const EXPORT = 'plugin_glpiacessivel_audit_export';
    public const GLOBAL = 'plugin_glpiacessivel_audit_global';

    /** @return list<string> */
    public static function all(): array
    {
        return [self::READ, self::SENSITIVE, self::EXPORT, self::GLOBAL];
    }

    /** @return array<string,string> */
    public static function labels(): array
    {
        return [
            self::READ => __('Consultar metadados da auditoria', 'glpiacessivel'),
            self::SENSITIVE => __('Consultar auditoria sensível e de dados pessoais', 'glpiacessivel'),
            self::EXPORT => __('Exportar auditoria autorizada', 'glpiacessivel'),
            self::GLOBAL => __('Consultar eventos globais da auditoria', 'glpiacessivel'),
        ];
    }

    public static function install(): bool
    {
        if (!class_exists('\ProfileRight') || !method_exists('\ProfileRight', 'addProfileRights')) {
            return true;
        }

        try {
            if (\ProfileRight::addProfileRights(self::all()) === false) {
                return false;
            }

            self::bootstrapCurrentProfile();
            return true;
        } catch (\Throwable) {
            return false;
        }
    }

    public static function uninstall(): bool
    {
        if (!class_exists('\ProfileRight') || !method_exists('\ProfileRight', 'deleteProfileRights')) {
            return true;
        }

        try {
            return \ProfileRight::deleteProfileRights(self::all()) !== false;
        } catch (\Throwable) {
            return false;
        }
    }

    private static function bootstrapCurrentProfile(): void
    {
        if (
            !isset($_SESSION['glpiactiveprofile']['id'])
            || !method_exists('\Session', 'haveRight')
            || !method_exists('\ProfileRight', 'updateProfileRights')
        ) {
            return;
        }

        $update = defined('UPDATE') ? (int) constant('UPDATE') : 4;
        if (!\Session::haveRight('profile', $update)) {
            return;
        }

        $profileId = (int) $_SESSION['glpiactiveprofile']['id'];
        if ($profileId <= 0) {
            return;
        }

        $read = defined('READ') ? (int) constant('READ') : 1;
        \ProfileRight::updateProfileRights($profileId, array_fill_keys(self::all(), $read));
    }
}
