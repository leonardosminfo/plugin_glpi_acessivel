<?php

declare(strict_types=1);

namespace GlpiPlugin\Glpiacessivel\Infrastructure\Audit;

final class AuditPayloadSanitizer
{
    private const MAX_DEPTH = 3;
    private const MAX_ITEMS = 32;
    private const MAX_JSON_BYTES = 4096;
    private const SENSITIVE_KEY_PATTERN = '/(?:prompt|content|query|reason|message|request_uri|url|uri|token|cookie|sql|stack|exception|email|phone|mobile|name|filename)/i';

    /** @param array<string,mixed> $payload @return array<string,mixed> */
    public function sanitize(array $payload): array
    {
        $sanitized = $this->sanitizeArray($payload, 0);
        $encoded = json_encode($sanitized, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
        if (!is_string($encoded) || strlen($encoded) > self::MAX_JSON_BYTES) {
            return [
                'payload_truncated' => true,
                'original_field_count' => count($payload),
            ];
        }

        return $sanitized;
    }

    /** @param array<mixed> $values @return array<mixed> */
    private function sanitizeArray(array $values, int $depth): array
    {
        if ($depth >= self::MAX_DEPTH) {
            return ['truncated' => true];
        }

        $result = [];
        $count = 0;
        foreach ($values as $key => $value) {
            if ($count >= self::MAX_ITEMS) {
                $result['truncated'] = true;
                break;
            }

            $safeKey = is_int($key)
                ? $key
                : preg_replace('/[^a-zA-Z0-9_.-]/', '_', substr((string) $key, 0, 80));
            if ($safeKey === null || $safeKey === '') {
                continue;
            }

            if (is_string($safeKey) && preg_match(self::SENSITIVE_KEY_PATTERN, $safeKey) === 1) {
                $result[$safeKey . '_present'] = $value !== null && $value !== '';
                if (is_scalar($value)) {
                    $result[$safeKey . '_length'] = strlen((string) $value);
                }
                $count++;
                continue;
            }

            if (is_array($value)) {
                $result[$safeKey] = $this->sanitizeArray($value, $depth + 1);
            } elseif (is_bool($value) || is_int($value) || is_float($value) || $value === null) {
                $result[$safeKey] = $value;
            } elseif (is_string($value)) {
                $normalized = trim(preg_replace('/[\x00-\x1F\x7F]+/u', ' ', $value) ?? '');
                if (preg_match('/\A[a-zA-Z0-9_.:@\/-]{0,120}\z/D', $normalized) === 1) {
                    $result[$safeKey] = $normalized;
                } else {
                    $result[$safeKey . '_present'] = $normalized !== '';
                    $result[$safeKey . '_length'] = strlen($normalized);
                }
            } else {
                $result[$safeKey . '_type'] = get_debug_type($value);
            }
            $count++;
        }

        return $result;
    }
}
