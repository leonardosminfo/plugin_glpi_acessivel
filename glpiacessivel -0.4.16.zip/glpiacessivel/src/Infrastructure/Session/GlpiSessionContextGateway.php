<?php

declare(strict_types=1);

namespace GlpiPlugin\Glpiacessivel\Infrastructure\Session;

/**
 * Narrow integration boundary for GLPI's native profile/entity session APIs.
 */
final class GlpiSessionContextGateway
{
    public function changeProfile(int $profileId): bool
    {
        if ($profileId <= 0 || !method_exists('\Session', 'changeProfile')) {
            return false;
        }
        \Session::changeProfile($profileId);
        return (int) ($_SESSION['glpiactiveprofile']['id'] ?? 0) === $profileId;
    }

    /** @param int|string $entityId */
    public function changeEntity($entityId, bool $recursive): bool
    {
        if (!method_exists('\Session', 'changeActiveEntities')) {
            return false;
        }
        return \Session::changeActiveEntities($entityId, $recursive) === true;
    }

    /**
     * @return array{
     *   profile_id:int,entity_id:int,entity_value:string,recursive:bool,
     *   active_entities_hash:string,context_fingerprint:string
     * }
     */
    public function snapshot(): array
    {
        $activeEntities = [];
        foreach ((array) ($_SESSION['glpiactiveentities'] ?? []) as $key => $value) {
            $candidate = is_numeric($value) ? (int) $value : (is_numeric($key) ? (int) $key : -1);
            if ($candidate >= 0) {
                $activeEntities[] = $candidate;
            }
        }
        $activeEntities = array_values(array_unique($activeEntities));
        sort($activeEntities, SORT_NUMERIC);

        $allEntities = !empty($_SESSION['glpientity_fullstructure'])
            || ($_SESSION['glpiactive_entity'] ?? null) === 'all';
        $snapshot = [
            'profile_id' => max(0, (int) ($_SESSION['glpiactiveprofile']['id'] ?? 0)),
            'entity_id' => max(0, (int) ($_SESSION['glpiactive_entity'] ?? 0)),
            'entity_value' => $allEntities ? 'all' : (string) max(0, (int) ($_SESSION['glpiactive_entity'] ?? 0)),
            'recursive' => !empty($_SESSION['glpiactive_entity_recursive']),
            'active_entities_hash' => hash('sha256', implode(',', $activeEntities)),
        ];
        $snapshot['context_fingerprint'] = hash('sha256', implode('|', [
            (string) $snapshot['profile_id'],
            $snapshot['entity_value'],
            $snapshot['recursive'] ? '1' : '0',
            $snapshot['active_entities_hash'],
        ]));

        return $snapshot;
    }

    /**
     * Persist all pending writes before a redirect. No session data may be
     * changed by the caller after this method returns true.
     */
    public function commit(): bool
    {
        if (session_status() !== PHP_SESSION_ACTIVE) {
            return false;
        }
        return session_write_close();
    }
}
