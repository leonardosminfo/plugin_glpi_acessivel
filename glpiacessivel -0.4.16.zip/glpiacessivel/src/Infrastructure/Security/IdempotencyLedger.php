<?php

declare(strict_types=1);

namespace GlpiPlugin\Glpiacessivel\Infrastructure\Security;

use DBmysql;

/**
 * Coordination ledger. It never stores search names, filters, URLs, values or
 * definitions. Ordinary reservations are short-lived and callers must reserve
 * and complete them in the same database transaction as the protected native
 * mutation. An uncertain native mutation may additionally leave a persistent,
 * hashed reconciliation marker that is removed only after a verified outcome.
 */
final class IdempotencyLedger
{
    private const TABLE = 'glpi_plugin_glpiacessivel_idempotency';
    private const STATUS_PENDING = 'pending';
    private const STATUS_COMPLETED = 'completed';
    private const STATUS_PARTIAL = 'partial';
    private const DEFAULT_TTL_SECONDS = 900;
    private const MIN_TTL_SECONDS = 60;
    private const MAX_TTL_SECONDS = 3600;

    private DBmysql $db;

    /** @var callable(): int */
    private $clock;

    /** @param callable(): int|null $clock */
    public function __construct(DBmysql $db, ?callable $clock = null)
    {
        $this->db = $db;
        $this->clock = $clock ?? static fn(): int => time();
    }

    public function reserve(
        string $scope,
        string $idempotencyKey,
        string $requestHash,
        int $ttlSeconds = self::DEFAULT_TTL_SECONDS
    ): IdempotencyClaim {
        $this->assertOpaqueInput($scope, 'scope', 1, 512);
        $this->assertOpaqueInput($idempotencyKey, 'key', 16, 512);
        $requestHash = $this->normalizeRequestHash($requestHash);
        $ttlSeconds = min(self::MAX_TTL_SECONDS, max(self::MIN_TTL_SECONDS, $ttlSeconds));

        $now = $this->now();
        if (!$this->purgeExpiredAt($now)) {
            throw new \RuntimeException('idempotency_ledger_cleanup_failed');
        }

        $scopeHash = hash('sha256', $scope);
        $keyHash = hash('sha256', $idempotencyKey);
        $reservationToken = bin2hex(random_bytes(32));
        $tokenHash = hash('sha256', $reservationToken);
        $nowSql = $this->formatTime($now);
        $expiresAt = $this->formatTime($now + $ttlSeconds);
        $insertFailure = null;

        try {
            $inserted = (bool) $this->db->insert(self::TABLE, [
                'scope_hash' => $scopeHash,
                'idempotency_key_hash' => $keyHash,
                'request_hash' => $requestHash,
                'reservation_token_hash' => $tokenHash,
                'status' => self::STATUS_PENDING,
                'result_id' => null,
                'expires_at' => $expiresAt,
                'created_at' => $nowSql,
                'updated_at' => $nowSql,
            ]);
        } catch (\Throwable $e) {
            $inserted = false;
            $insertFailure = $e;
        }

        if ($inserted) {
            return new IdempotencyClaim(
                IdempotencyClaim::ACQUIRED,
                $scopeHash,
                $keyHash,
                $requestHash,
                $reservationToken
            );
        }

        $row = $this->find($scopeHash, $keyHash);
        if ($row === null) {
            throw new \RuntimeException('idempotency_ledger_unavailable', 0, $insertFailure);
        }

        if (!$this->isUnexpired($row, $now)) {
            throw new \RuntimeException('idempotency_ledger_expired_row');
        }

        if (!hash_equals((string) ($row['request_hash'] ?? ''), $requestHash)) {
            return new IdempotencyClaim(
                IdempotencyClaim::CONFLICT,
                $scopeHash,
                $keyHash,
                $requestHash
            );
        }

        $status = (string) ($row['status'] ?? '');
        if ($status === self::STATUS_COMPLETED) {
            if (!isset($row['result_id']) || !is_numeric($row['result_id']) || (int) $row['result_id'] < 0) {
                throw new \RuntimeException('idempotency_ledger_state_invalid');
            }
            $resultId = (int) $row['result_id'];
            return new IdempotencyClaim(
                IdempotencyClaim::REPLAY,
                $scopeHash,
                $keyHash,
                $requestHash,
                '',
                $resultId
            );
        }
        if (in_array($status, [self::STATUS_PENDING, self::STATUS_PARTIAL], true)) {
            return new IdempotencyClaim(
                IdempotencyClaim::IN_PROGRESS,
                $scopeHash,
                $keyHash,
                $requestHash
            );
        }

        throw new \RuntimeException('idempotency_ledger_state_invalid');
    }

    /**
     * Persist a cross-session marker for a native mutation whose final outcome
     * cannot be proved. Only hashes and the optional numeric native result are
     * stored. The marker deliberately has no time-based expiry: it is cleared
     * by explicit reconciliation, not merely by waiting.
     */
    public function recordPartial(
        string $scope,
        string $operationKey,
        string $requestHash,
        int $resultId = 0
    ): bool {
        $this->assertOpaqueInput($scope, 'scope', 1, 512);
        $this->assertOpaqueInput($operationKey, 'key', 16, 512);
        $requestHash = $this->normalizeRequestHash($requestHash);

        $scopeHash = hash('sha256', $scope);
        $keyHash = hash('sha256', $operationKey);
        $nowSql = $this->formatTime($this->now());
        $payload = [
            'status' => self::STATUS_PARTIAL,
            'result_id' => max(0, $resultId),
            'expires_at' => '9999-12-31 23:59:59',
            'updated_at' => $nowSql,
        ];

        $row = $this->find($scopeHash, $keyHash);
        if ($row !== null) {
            if (!hash_equals((string) ($row['request_hash'] ?? ''), $requestHash)) {
                return false;
            }
            $updated = (bool) $this->db->update(self::TABLE, $payload, [
                'scope_hash' => $scopeHash,
                'idempotency_key_hash' => $keyHash,
                'request_hash' => $requestHash,
            ]);
            return $updated && $this->partialRowMatches($scopeHash, $keyHash, $requestHash, $resultId);
        }

        $inserted = false;
        try {
            $inserted = (bool) $this->db->insert(self::TABLE, [
                'scope_hash' => $scopeHash,
                'idempotency_key_hash' => $keyHash,
                'request_hash' => $requestHash,
                'reservation_token_hash' => hash('sha256', bin2hex(random_bytes(32))),
                'status' => self::STATUS_PARTIAL,
                'result_id' => max(0, $resultId),
                'expires_at' => '9999-12-31 23:59:59',
                'created_at' => $nowSql,
                'updated_at' => $nowSql,
            ]);
        } catch (\Throwable) {
            $inserted = false;
        }
        if (!$inserted) {
            // A concurrent request may have inserted the same opaque marker.
            $updated = (bool) $this->db->update(self::TABLE, $payload, [
                'scope_hash' => $scopeHash,
                'idempotency_key_hash' => $keyHash,
                'request_hash' => $requestHash,
            ]);
            if (!$updated) {
                return false;
            }
        }

        return $this->partialRowMatches($scopeHash, $keyHash, $requestHash, $resultId);
    }

    /**
     * Acquire a durable per-resource guard before a native mutation starts.
     * Unlike an ordinary reservation, this row does not expire: an ambiguous
     * operation must remain blocked until its outcome is reconciled.
     */
    public function acquirePartialGuard(
        string $scope,
        string $guardKey,
        string $requestHash,
        int $initialResultId = 0
    ): IdempotencyClaim {
        $this->assertOpaqueInput($scope, 'scope', 1, 512);
        $this->assertOpaqueInput($guardKey, 'key', 16, 512);
        $requestHash = $this->normalizeRequestHash($requestHash);

        $scopeHash = hash('sha256', $scope);
        $keyHash = hash('sha256', $guardKey);
        $reservationToken = bin2hex(random_bytes(32));
        $tokenHash = hash('sha256', $reservationToken);
        $nowSql = $this->formatTime($this->now());
        $insertFailure = null;
        try {
            $inserted = (bool) $this->db->insert(self::TABLE, [
                'scope_hash' => $scopeHash,
                'idempotency_key_hash' => $keyHash,
                'request_hash' => $requestHash,
                'reservation_token_hash' => $tokenHash,
                'status' => self::STATUS_PARTIAL,
                'result_id' => max(0, $initialResultId),
                'expires_at' => '9999-12-31 23:59:59',
                'created_at' => $nowSql,
                'updated_at' => $nowSql,
            ]);
        } catch (\Throwable $e) {
            $inserted = false;
            $insertFailure = $e;
        }
        if ($inserted) {
            return new IdempotencyClaim(
                IdempotencyClaim::ACQUIRED,
                $scopeHash,
                $keyHash,
                $requestHash,
                $reservationToken
            );
        }

        $row = $this->find($scopeHash, $keyHash);
        if ($row === null) {
            throw new \RuntimeException('idempotency_partial_guard_unavailable', 0, $insertFailure);
        }
        if (!hash_equals((string) ($row['request_hash'] ?? ''), $requestHash)) {
            return new IdempotencyClaim(
                IdempotencyClaim::CONFLICT,
                $scopeHash,
                $keyHash,
                $requestHash
            );
        }
        return new IdempotencyClaim(
            IdempotencyClaim::IN_PROGRESS,
            $scopeHash,
            $keyHash,
            $requestHash
        );
    }

    public function updatePartialGuard(IdempotencyClaim $claim, int $resultId): bool
    {
        if (!$claim->isAcquired() || $claim->reservationToken() === '') {
            return false;
        }
        $updated = (bool) $this->db->update(self::TABLE, [
            'result_id' => max(0, $resultId),
            'updated_at' => $this->formatTime($this->now()),
        ], [
            'scope_hash' => $claim->scopeHash(),
            'idempotency_key_hash' => $claim->keyHash(),
            'request_hash' => $claim->requestHash(),
            'reservation_token_hash' => hash('sha256', $claim->reservationToken()),
            'status' => self::STATUS_PARTIAL,
        ]);
        return $updated && $this->partialRowMatches(
            $claim->scopeHash(),
            $claim->keyHash(),
            $claim->requestHash(),
            $resultId
        );
    }

    public function releasePartialGuard(IdempotencyClaim $claim): bool
    {
        if (!$claim->isAcquired() || $claim->reservationToken() === '') {
            return false;
        }
        $deleted = (bool) $this->db->delete(self::TABLE, [
            'scope_hash' => $claim->scopeHash(),
            'idempotency_key_hash' => $claim->keyHash(),
            'request_hash' => $claim->requestHash(),
            'reservation_token_hash' => hash('sha256', $claim->reservationToken()),
            'status' => self::STATUS_PARTIAL,
        ]);
        if (!$deleted) {
            return false;
        }
        return $this->find($claim->scopeHash(), $claim->keyHash()) === null;
    }

    /** @return array{result_id:int,operation_key_hash:string,updated_at:string}|null */
    public function latestPartial(string $scope): ?array
    {
        $this->assertOpaqueInput($scope, 'scope', 1, 512);
        try {
            $row = $this->db->request([
                'FROM' => self::TABLE,
                'WHERE' => [
                    'scope_hash' => hash('sha256', $scope),
                    'status' => self::STATUS_PARTIAL,
                ],
                'ORDER' => ['updated_at DESC', 'id DESC'],
                'LIMIT' => 1,
            ])->current();
        } catch (\Throwable $e) {
            throw new \RuntimeException('idempotency_ledger_unavailable', 0, $e);
        }

        if (!is_array($row) || $row === []) {
            return null;
        }
        return [
            'result_id' => max(0, (int) ($row['result_id'] ?? 0)),
            'operation_key_hash' => (string) ($row['idempotency_key_hash'] ?? ''),
            'updated_at' => (string) ($row['updated_at'] ?? ''),
        ];
    }

    public function clearPartials(string $scope): bool
    {
        $this->assertOpaqueInput($scope, 'scope', 1, 512);
        return (bool) $this->db->delete(self::TABLE, [
            'scope_hash' => hash('sha256', $scope),
            'status' => self::STATUS_PARTIAL,
        ]);
    }

    public function complete(IdempotencyClaim $claim, int $resultId): bool
    {
        if (!$claim->isAcquired() || $claim->reservationToken() === '' || $resultId < 0) {
            return false;
        }

        $now = $this->now();
        $updated = (bool) $this->db->update(self::TABLE, [
            'status' => self::STATUS_COMPLETED,
            'result_id' => $resultId,
            'updated_at' => $this->formatTime($now),
        ], [
            'scope_hash' => $claim->scopeHash(),
            'idempotency_key_hash' => $claim->keyHash(),
            'request_hash' => $claim->requestHash(),
            'reservation_token_hash' => hash('sha256', $claim->reservationToken()),
            'status' => self::STATUS_PENDING,
            'expires_at' => ['>', $this->formatTime($now)],
        ]);
        if (!$updated) {
            return false;
        }

        $row = $this->find($claim->scopeHash(), $claim->keyHash());
        return is_array($row)
            && ($row['status'] ?? null) === self::STATUS_COMPLETED
            && hash_equals((string) ($row['request_hash'] ?? ''), $claim->requestHash())
            && hash_equals(
                (string) ($row['reservation_token_hash'] ?? ''),
                hash('sha256', $claim->reservationToken())
            )
            && (int) ($row['result_id'] ?? -1) === $resultId
            && $this->isUnexpired($row, $now);
    }

    public function release(IdempotencyClaim $claim): bool
    {
        if (!$claim->isAcquired() || $claim->reservationToken() === '') {
            return false;
        }

        $deleted = (bool) $this->db->delete(self::TABLE, [
            'scope_hash' => $claim->scopeHash(),
            'idempotency_key_hash' => $claim->keyHash(),
            'request_hash' => $claim->requestHash(),
            'reservation_token_hash' => hash('sha256', $claim->reservationToken()),
            'status' => self::STATUS_PENDING,
        ]);
        if (!$deleted) {
            return false;
        }

        return $this->find($claim->scopeHash(), $claim->keyHash()) === null;
    }

    public function purgeExpired(): bool
    {
        return $this->purgeExpiredAt($this->now());
    }

    private function purgeExpiredAt(int $now): bool
    {
        return (bool) $this->db->delete(self::TABLE, [
            'expires_at' => ['<', $this->formatTime($now)],
        ]);
    }

    /** @return array<string, mixed>|null */
    private function find(string $scopeHash, string $keyHash): ?array
    {
        try {
            $row = $this->db->request([
                'FROM' => self::TABLE,
                'WHERE' => [
                    'scope_hash' => $scopeHash,
                    'idempotency_key_hash' => $keyHash,
                ],
                'LIMIT' => 1,
            ])->current();
        } catch (\Throwable $e) {
            throw new \RuntimeException('idempotency_ledger_unavailable', 0, $e);
        }

        return is_array($row) && $row !== [] ? $row : null;
    }

    private function partialRowMatches(
        string $scopeHash,
        string $keyHash,
        string $requestHash,
        int $resultId
    ): bool {
        $row = $this->find($scopeHash, $keyHash);
        return is_array($row)
            && ($row['status'] ?? null) === self::STATUS_PARTIAL
            && hash_equals((string) ($row['request_hash'] ?? ''), $requestHash)
            && (int) ($row['result_id'] ?? -1) === max(0, $resultId);
    }

    /** @param array<string, mixed> $row */
    private function isUnexpired(array $row, int $now): bool
    {
        $expiresAt = strtotime((string) ($row['expires_at'] ?? ''));
        return $expiresAt !== false && $expiresAt > $now;
    }

    private function assertOpaqueInput(string $value, string $field, int $minLength, int $maxLength): void
    {
        $length = strlen($value);
        if ($length < $minLength || $length > $maxLength || preg_match('/[\x00-\x1F\x7F]/', $value) === 1) {
            throw new \InvalidArgumentException('idempotency_' . $field . '_invalid');
        }
    }

    private function normalizeRequestHash(string $requestHash): string
    {
        $requestHash = strtolower($requestHash);
        if (strlen($requestHash) !== 64 || !ctype_xdigit($requestHash)) {
            throw new \InvalidArgumentException('idempotency_request_hash_invalid');
        }

        return $requestHash;
    }

    private function now(): int
    {
        return (int) call_user_func($this->clock);
    }

    private function formatTime(int $timestamp): string
    {
        return date('Y-m-d H:i:s', $timestamp);
    }
}
