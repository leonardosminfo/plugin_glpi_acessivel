<?php

declare(strict_types=1);

namespace GlpiPlugin\Glpiacessivel\Infrastructure\Repository;

/**
 * Transitional presentation-filter normalizer.
 *
 * Native saved-search persistence lives exclusively in NativeSavedSearchGateway.
 * This class remains temporarily because the ticket controller still consumes
 * its presentation-only normalizer; it has no database access or CRUD.
 */
final class SavedTicketSearchRepository
{
    /** @return array<string,mixed> */
    public static function normalizePortalFilters(array $filters): array
    {
        $status = (string) ($filters['status'] ?? '');
        $pageSize = (int) ($filters['page_size'] ?? 20);
        $columns = array_values(array_intersect(
            self::stringList($filters['columns'] ?? []),
            [
                'id', 'name', 'status', 'priority', 'group', 'requester', 'assignee',
                'date', 'date_mod', 'category', 'entity', 'location', 'time_to_resolve',
            ]
        ));
        if ($columns === []) {
            $columns = ['id', 'name', 'status', 'priority', 'group', 'date_mod'];
        }
        foreach (['id', 'name'] as $required) {
            if (!in_array($required, $columns, true)) {
                array_unshift($columns, $required);
            }
        }

        return [
            'scope' => in_array((string) ($filters['scope'] ?? ''), ['all', 'mine', 'group'], true)
                ? (string) $filters['scope']
                : 'all',
            'status' => preg_match('/^\d{0,3}$/', $status) === 1
                ? $status
                : '',
            'q' => mb_substr(trim((string) ($filters['q'] ?? '')), 0, 120, 'UTF-8'),
            'group_id' => max(0, (int) ($filters['group_id'] ?? 0)),
            'group_by' => (string) ($filters['group_by'] ?? '') === 'group' ? 'group' : 'none',
            'page_size' => in_array($pageSize, [10, 20, 50, 100], true)
                ? $pageSize
                : 20,
            'sort' => in_array(
                (string) ($filters['sort'] ?? ''),
                ['id', 'name', 'status', 'priority', 'date', 'date_mod'],
                true
            ) ? (string) $filters['sort'] : 'date_mod',
            'direction' => strtoupper((string) ($filters['direction'] ?? '')) === 'ASC' ? 'ASC' : 'DESC',
            'columns' => array_values(array_unique($columns)),
        ];
    }

    /** @return string[] */
    private static function stringList(mixed $value): array
    {
        if (is_string($value)) {
            $value = explode(',', $value);
        }
        if (!is_array($value)) {
            return [];
        }
        return array_values(array_filter(array_map(
            static fn(mixed $item): string => trim((string) $item),
            $value
        )));
    }
}
