<?php

declare(strict_types=1);

namespace GlpiPlugin\Glpiacessivel\Infrastructure\Repository;

final class PlaybookRepository
{
    private const TABLE_JOBS = 'glpi_plugin_glpiacessivel_playbookjobs';
    private const TABLE_SUGGESTIONS = 'glpi_plugin_glpiacessivel_playbooksuggestions';
    private const TABLE_PLAYBOOKS = 'glpi_plugin_glpiacessivel_playbooks';

    public function createJob(string $jobType, array $options = []): int
    {
        global $DB;

        $now = date('Y-m-d H:i:s');
        $DB->insert(self::TABLE_JOBS, [
            'users_id' => $this->currentUserId(),
            'entities_id' => $this->currentEntityId(),
            'job_type' => $jobType,
            'status' => 'running',
            'source_scope' => (string) ($options['source_scope'] ?? 'kb_public'),
            'options_json' => $this->toJson($options),
            'cursor_json' => $this->toJson([]),
            'processed_count' => 0,
            'suggestions_count' => 0,
            'message' => '',
            'started_at' => $now,
            'finished_at' => null,
            'created_at' => $now,
            'updated_at' => $now,
        ]);

        return $this->lastInsertId();
    }

    public function finishJob(int $jobId, string $status, int $processed, int $suggestions, string $message = ''): void
    {
        global $DB;

        if ($jobId <= 0) {
            return;
        }

        $DB->update(self::TABLE_JOBS, [
            'status' => $status,
            'processed_count' => max(0, $processed),
            'suggestions_count' => max(0, $suggestions),
            'message' => mb_substr($message, 0, 250, 'UTF-8'),
            'finished_at' => date('Y-m-d H:i:s'),
            'updated_at' => date('Y-m-d H:i:s'),
        ], array_merge(['id' => $jobId], $this->entityCriteria()));
    }

    public function createSuggestion(int $jobId, array $payload): int
    {
        global $DB;

        $now = date('Y-m-d H:i:s');
        $DB->insert(self::TABLE_SUGGESTIONS, [
            'jobs_id' => max(0, $jobId),
            'entities_id' => $this->currentEntityId(),
            'source_type' => (string) ($payload['source_type'] ?? 'kb'),
            'title' => mb_substr((string) ($payload['title'] ?? ''), 0, 250, 'UTF-8'),
            'intent' => (string) ($payload['intent'] ?? 'kb_recomendar_contextual'),
            'confidence' => (string) round((float) ($payload['confidence'] ?? 0.7), 2),
            'keywords_json' => $this->toJson((array) ($payload['keywords'] ?? [])),
            'questions_json' => $this->toJson((array) ($payload['questions'] ?? [])),
            'kb_articles_json' => $this->toJson((array) ($payload['kb_articles'] ?? [])),
            'category_hint' => mb_substr((string) ($payload['category_hint'] ?? ''), 0, 250, 'UTF-8'),
            'group_hint' => mb_substr((string) ($payload['group_hint'] ?? ''), 0, 250, 'UTF-8'),
            'ticket_template_json' => $this->toJson((array) ($payload['ticket_template'] ?? [])),
            'status' => (string) ($payload['status'] ?? 'pending'),
            'content_json' => $this->toJson((array) ($payload['content'] ?? [])),
            'reviewed_by' => 0,
            'reviewed_at' => null,
            'created_at' => $now,
            'updated_at' => $now,
        ]);

        return $this->lastInsertId();
    }

    public function listSuggestions(string $status = 'pending', int $limit = 50): array
    {
        global $DB;

        $where = $this->entityCriteria();
        if ($status !== 'all') {
            $where['status'] = $status;
        }

        $criteria = [
            'FROM' => self::TABLE_SUGGESTIONS,
            'WHERE' => $where,
            'ORDER' => ['id DESC'],
            'LIMIT' => min(200, max(1, $limit)),
        ];

        return $this->decodeRows($DB->request($criteria));
    }

    public function getSuggestion(int $id): ?array
    {
        global $DB;

        $row = $DB->request([
            'FROM' => self::TABLE_SUGGESTIONS,
            'WHERE' => array_merge(['id' => $id], $this->entityCriteria()),
            'LIMIT' => 1,
        ])->current();

        if (!$row) {
            return null;
        }

        $rows = $this->decodeRows([$row]);
        return $rows[0] ?? null;
    }

    public function updateSuggestion(int $id, array $payload): bool
    {
        global $DB;

        if ($id <= 0) {
            return false;
        }

        return (bool) $DB->update(self::TABLE_SUGGESTIONS, [
            'title' => mb_substr((string) ($payload['title'] ?? $payload['name'] ?? ''), 0, 250, 'UTF-8'),
            'intent' => (string) ($payload['intent'] ?? 'kb_recomendar_contextual'),
            'confidence' => (string) round((float) ($payload['confidence'] ?? 0.7), 2),
            'keywords_json' => $this->toJson((array) ($payload['keywords'] ?? [])),
            'questions_json' => $this->toJson((array) ($payload['questions'] ?? [])),
            'kb_articles_json' => $this->toJson((array) ($payload['kb_articles'] ?? [])),
            'category_hint' => mb_substr((string) ($payload['category_hint'] ?? ''), 0, 250, 'UTF-8'),
            'group_hint' => mb_substr((string) ($payload['group_hint'] ?? ''), 0, 250, 'UTF-8'),
            'ticket_template_json' => $this->toJson((array) ($payload['ticket_template'] ?? [])),
            'content_json' => $this->toJson((array) ($payload['content'] ?? [])),
            'updated_at' => date('Y-m-d H:i:s'),
        ], array_merge([
            'id' => $id,
            'status' => 'pending',
        ], $this->entityCriteria()));
    }

    public function approveSuggestion(int $id): ?int
    {
        global $DB;

        $suggestion = $this->getSuggestion($id);
        if ($suggestion === null || (string) ($suggestion['status'] ?? '') !== 'pending') {
            return null;
        }

        $now = date('Y-m-d H:i:s');
        $claimed = (bool) $DB->update(self::TABLE_SUGGESTIONS, [
            'status' => 'approving',
            'updated_at' => $now,
        ], array_merge([
            'id' => $id,
            'status' => 'pending',
        ], $this->entityCriteria()));
        if (!$claimed || (method_exists($DB, 'affectedRows') && (int) $DB->affectedRows() === 0)) {
            return null;
        }

        try {
            $DB->insert(self::TABLE_PLAYBOOKS, [
                'entities_id' => (int) ($suggestion['entities_id'] ?? 0),
                'name' => (string) ($suggestion['title'] ?? ''),
                'intent' => (string) ($suggestion['intent'] ?? 'kb_recomendar_contextual'),
                'is_active' => 1,
                'source_suggestion_id' => $id,
                'keywords_json' => $this->toJson((array) ($suggestion['keywords'] ?? [])),
                'questions_json' => $this->toJson((array) ($suggestion['questions'] ?? [])),
                'kb_articles_json' => $this->toJson((array) ($suggestion['kb_articles'] ?? [])),
                'category_hint' => (string) ($suggestion['category_hint'] ?? ''),
                'group_hint' => (string) ($suggestion['group_hint'] ?? ''),
                'ticket_template_json' => $this->toJson((array) ($suggestion['ticket_template'] ?? [])),
                'content_json' => $this->toJson((array) ($suggestion['content'] ?? [])),
                'created_at' => $now,
                'updated_at' => $now,
            ]);

            $playbookId = $this->lastInsertId();
            if ($playbookId <= 0) {
                throw new \RuntimeException('Falha ao registrar roteiro aprovado.');
            }

            $DB->update(self::TABLE_SUGGESTIONS, [
                'status' => 'approved',
                'reviewed_by' => $this->currentUserId(),
                'reviewed_at' => $now,
                'updated_at' => $now,
            ], array_merge([
                'id' => $id,
                'status' => 'approving',
            ], $this->entityCriteria()));

            return $playbookId;
        } catch (\Throwable $e) {
            $DB->update(self::TABLE_SUGGESTIONS, [
                'status' => 'pending',
                'updated_at' => date('Y-m-d H:i:s'),
            ], array_merge([
                'id' => $id,
                'status' => 'approving',
            ], $this->entityCriteria()));
            throw $e;
        }
    }
    public function rejectSuggestion(int $id): bool
    {
        global $DB;

        return (bool) $DB->update(self::TABLE_SUGGESTIONS, [
            'status' => 'rejected',
            'reviewed_by' => $this->currentUserId(),
            'reviewed_at' => date('Y-m-d H:i:s'),
            'updated_at' => date('Y-m-d H:i:s'),
        ], array_merge([
            'id' => $id,
            'status' => 'pending',
        ], $this->entityCriteria()));
    }

    public function listActivePlaybooks(int $limit = 100): array
    {
        global $DB;

        return $this->decodeRows($DB->request([
            'FROM' => self::TABLE_PLAYBOOKS,
            'WHERE' => array_merge(['is_active' => 1], $this->entityCriteria()),
            'ORDER' => ['updated_at DESC', 'id DESC'],
            'LIMIT' => min(300, max(1, $limit)),
        ]));
    }

    public function listPlaybooks(int $limit = 100): array
    {
        global $DB;

        return $this->decodeRows($DB->request([
            'FROM' => self::TABLE_PLAYBOOKS,
            'WHERE' => $this->entityCriteria(),
            'ORDER' => ['updated_at DESC', 'id DESC'],
            'LIMIT' => min(300, max(1, $limit)),
        ]));
    }

    public function getPlaybook(int $id): ?array
    {
        global $DB;

        if ($id <= 0) {
            return null;
        }

        $row = $DB->request([
            'FROM' => self::TABLE_PLAYBOOKS,
            'WHERE' => array_merge(['id' => $id], $this->entityCriteria()),
            'LIMIT' => 1,
        ])->current();

        if (!$row) {
            return null;
        }

        $rows = $this->decodeRows([$row]);
        return $rows[0] ?? null;
    }

    public function updatePlaybook(int $id, array $payload): bool
    {
        global $DB;

        if ($id <= 0) {
            return false;
        }

        return (bool) $DB->update(self::TABLE_PLAYBOOKS, [
            'name' => mb_substr((string) ($payload['name'] ?? ''), 0, 250, 'UTF-8'),
            'intent' => (string) ($payload['intent'] ?? 'kb_recomendar_contextual'),
            'is_active' => (int) ($payload['is_active'] ?? 1),
            'keywords_json' => $this->toJson((array) ($payload['keywords'] ?? [])),
            'questions_json' => $this->toJson((array) ($payload['questions'] ?? [])),
            'kb_articles_json' => $this->toJson((array) ($payload['kb_articles'] ?? [])),
            'category_hint' => mb_substr((string) ($payload['category_hint'] ?? ''), 0, 250, 'UTF-8'),
            'group_hint' => mb_substr((string) ($payload['group_hint'] ?? ''), 0, 250, 'UTF-8'),
            'ticket_template_json' => $this->toJson((array) ($payload['ticket_template'] ?? [])),
            'content_json' => $this->toJson((array) ($payload['content'] ?? [])),
            'updated_at' => date('Y-m-d H:i:s'),
        ], array_merge(['id' => $id], $this->entityCriteria()));
    }

    public function createPlaybook(array $payload, bool $active = true): int
    {
        global $DB;

        $now = date('Y-m-d H:i:s');
        $DB->insert(self::TABLE_PLAYBOOKS, [
            'entities_id' => $this->currentEntityId(),
            'name' => mb_substr((string) ($payload['name'] ?? ''), 0, 250, 'UTF-8'),
            'intent' => (string) ($payload['intent'] ?? 'kb_recomendar_contextual'),
            'is_active' => $active ? 1 : 0,
            'source_suggestion_id' => (int) ($payload['source_suggestion_id'] ?? 0),
            'keywords_json' => $this->toJson((array) ($payload['keywords'] ?? [])),
            'questions_json' => $this->toJson((array) ($payload['questions'] ?? [])),
            'kb_articles_json' => $this->toJson((array) ($payload['kb_articles'] ?? [])),
            'category_hint' => mb_substr((string) ($payload['category_hint'] ?? ''), 0, 250, 'UTF-8'),
            'group_hint' => mb_substr((string) ($payload['group_hint'] ?? ''), 0, 250, 'UTF-8'),
            'ticket_template_json' => $this->toJson((array) ($payload['ticket_template'] ?? [])),
            'content_json' => $this->toJson((array) ($payload['content'] ?? [])),
            'created_at' => $now,
            'updated_at' => $now,
        ]);

        return $this->lastInsertId();
    }

    public function deletePlaybook(int $id): bool
    {
        global $DB;

        if ($id <= 0) {
            return false;
        }

        return (bool) $DB->delete(self::TABLE_PLAYBOOKS, array_merge(['id' => $id], $this->entityCriteria()));
    }

    public function importApprovedPlaybooks(array $items): int
    {
        $result = $this->importPlaybooks($items, 'active');
        return (int) $result['active'] + (int) $result['inactive'];
    }

    public function importPlaybooks(array $items, string $defaultStatus = 'active'): array
    {
        global $DB;

        $result = [
            'active' => 0,
            'inactive' => 0,
            'pending' => 0,
            'skipped' => 0,
        ];
        $now = date('Y-m-d H:i:s');
        $defaultStatus = $this->normalizeStatus($defaultStatus);

        foreach ($items as $item) {
            if (!is_array($item)) {
                $result['skipped']++;
                continue;
            }
            $name = trim((string) ($item['name'] ?? $item['title'] ?? ''));
            if ($name === '') {
                $result['skipped']++;
                continue;
            }

            $status = $this->statusFromImportItem($item, $defaultStatus);
            if ($status === 'pending') {
                $this->createSuggestion(0, array_merge($item, [
                    'title' => $name,
                    'status' => 'pending',
                    'source_type' => (string) ($item['source_type'] ?? 'manual_import'),
                ]));
                $result['pending']++;
                continue;
            }

            $this->createPlaybook(array_merge($item, ['name' => $name]), $status === 'active');
            $result[$status === 'active' ? 'active' : 'inactive']++;
        }

        return $result;
    }

    public function exportApprovedPlaybooks(): array
    {
        return array_map(static function (array $row): array {
            return [
                'name' => (string) ($row['name'] ?? ''),
                'intent' => (string) ($row['intent'] ?? ''),
                'status' => ((int) ($row['is_active'] ?? 0)) === 1 ? 'active' : 'inactive',
                'keywords' => (array) ($row['keywords'] ?? []),
                'questions' => (array) ($row['questions'] ?? []),
                'kb_articles' => (array) ($row['kb_articles'] ?? []),
                'category_hint' => (string) ($row['category_hint'] ?? ''),
                'group_hint' => (string) ($row['group_hint'] ?? ''),
                'ticket_template' => (array) ($row['ticket_template'] ?? []),
                'content' => (array) ($row['content'] ?? []),
            ];
        }, $this->listActivePlaybooks(300));
    }

    private function decodeRows(iterable $rows): array
    {
        $decoded = [];
        foreach ($rows as $row) {
            $item = (array) $row;
            $item['keywords'] = $this->fromJson((string) ($item['keywords_json'] ?? '[]'));
            $item['questions'] = $this->fromJson((string) ($item['questions_json'] ?? '[]'));
            $item['kb_articles'] = $this->fromJson((string) ($item['kb_articles_json'] ?? '[]'));
            $item['ticket_template'] = $this->fromJson((string) ($item['ticket_template_json'] ?? '[]'));
            $item['content'] = $this->fromJson((string) ($item['content_json'] ?? '[]'));
            $decoded[] = $item;
        }

        return $decoded;
    }

    private function toJson(array $data): string
    {
        $json = json_encode($data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
        return is_string($json) ? $json : '[]';
    }

    private function fromJson(string $json): array
    {
        $decoded = json_decode($json, true);
        return is_array($decoded) ? $decoded : [];
    }

    private function statusFromImportItem(array $item, string $defaultStatus): string
    {
        if (array_key_exists('is_active', $item)) {
            $value = $item['is_active'];
            return ($value === true || $value === 1 || $value === '1' || $value === 'true') ? 'active' : 'inactive';
        }

        return $this->normalizeStatus((string) ($item['status'] ?? $defaultStatus));
    }

    private function normalizeStatus(string $status): string
    {
        $status = strtolower(trim($status));
        if (in_array($status, ['pending', 'pendente', 'review', 'analise', 'analysis'], true)) {
            return 'pending';
        }
        if (in_array($status, ['inactive', 'inativo', 'disabled', 'desativado', '0'], true)) {
            return 'inactive';
        }

        return 'active';
    }

    private function currentUserId(): int
    {
        return (int) ($_SESSION['glpiID'] ?? 0);
    }

    private function currentEntityId(): int
    {
        $active = $_SESSION['glpiactive_entity'] ?? null;
        if (!is_int($active) && !(is_string($active) && ctype_digit($active))) {
            throw new \RuntimeException('Selecione uma entidade especifica antes de alterar roteiros.');
        }

        return max(0, (int) $active);
    }

    /** @return int[] */
    private function currentEntityIds(): array
    {
        $activeEntities = null;
        if (class_exists('\Session') && method_exists('\Session', 'getActiveEntities')) {
            $activeEntities = \Session::getActiveEntities();
        }
        if (!is_array($activeEntities)) {
            $activeEntities = (array) ($_SESSION['glpiactiveentities'] ?? []);
        }

        $entities = [];
        foreach ($activeEntities as $key => $value) {
            $candidate = is_numeric($value) ? (int) $value : (is_numeric($key) ? (int) $key : -1);
            if ($candidate >= 0) {
                $entities[$candidate] = $candidate;
            }
        }

        if ($entities !== []) {
            return array_values($entities);
        }

        $active = $_SESSION['glpiactive_entity'] ?? null;
        if (is_int($active) || (is_string($active) && ctype_digit($active))) {
            return [max(0, (int) $active)];
        }

        return [-1];
    }

    /** @return array{entities_id:int|int[]} */
    private function entityCriteria(): array
    {
        $entities = $this->currentEntityIds();
        return ['entities_id' => count($entities) === 1 ? $entities[0] : $entities];
    }

    private function lastInsertId(): int
    {
        global $DB;

        if (method_exists($DB, 'insertId')) {
            return (int) $DB->insertId();
        }

        return 0;
    }
}
