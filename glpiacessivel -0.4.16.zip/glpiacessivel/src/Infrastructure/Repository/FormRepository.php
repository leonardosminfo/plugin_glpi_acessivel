<?php

declare(strict_types=1);

namespace GlpiPlugin\Glpiacessivel\Infrastructure\Repository;

use GlpiPlugin\Glpiacessivel\Infrastructure\FormCatalog\FormCatalogGateway;
use GlpiPlugin\Glpiacessivel\Infrastructure\FormCatalog\FormCatalogRequest;
use GlpiPlugin\Glpiacessivel\Infrastructure\FormCatalog\Formcreator213CatalogGateway;
use GlpiPlugin\Glpiacessivel\Support\I18n;
use GlpiPlugin\Glpiacessivel\Support\TextNormalizer;
use GlpiPlugin\Glpiacessivel\Support\Url;

final class FormRepository
{
    private FormCatalogGateway $formcreatorGateway;

    public function __construct(?FormCatalogGateway $formcreatorGateway = null)
    {
        $this->formcreatorGateway = $formcreatorGateway ?? new Formcreator213CatalogGateway();
    }

    /**
     * @return array<string, mixed>
     */
    public function listFormSources(?FormCatalogRequest $request = null): array
    {
        $request ??= new FormCatalogRequest();
        $glpi11 = $this->listGlpi11ServiceCatalogForms();
        if ($request->query !== '') {
            $glpi11['items'] = $this->filterItemsByQuery($glpi11['items'], $request->query);
        }
        $formcreator = $this->formcreatorGateway->list($request);
        $capabilities = $this->formcreatorGateway->capabilities();
        $formcreatorState = (string) ($formcreator['state'] ?? $capabilities['state'] ?? 'error');
        $formcreatorCode = (string) (
            $formcreator['diagnostic_code'] ?? $capabilities['diagnostic_code'] ?? ''
        );
        if ((int) ($formcreator['page'] ?? 1) > 1) {
            // The GLPI 11 catalog is not paginated by this Formcreator cursor.
            // Avoid repeating its cards on every Formcreator page.
            $glpi11['items'] = [];
        }

        return [
            'items' => array_merge($glpi11['items'], $formcreator['items']),
            'query' => $request->query,
            'catalog_page' => $formcreator,
            'sources' => [
                'glpi11_service_catalog' => [
                    'available' => $glpi11['available'],
                    'enabled' => $glpi11['enabled'],
                    'label' => I18n::translate('Catálogo de Serviços / Formulários do GLPI 11'),
                    'native_url' => $this->serviceCatalogUrl(),
                    'message' => $glpi11['message'],
                ],
                'formcreator_glpi10' => [
                    'available' => !empty($capabilities['available']),
                    'enabled' => !empty($capabilities['enabled']),
                    'state' => $formcreatorState,
                    'diagnostic_code' => $formcreatorCode,
                    'correlation_id' => (string) ($formcreator['correlation_id'] ?? ''),
                    'glpi_version' => (string) ($capabilities['glpi_version'] ?? 'unknown'),
                    'formcreator_version' => (string) ($capabilities['formcreator_version'] ?? 'unknown'),
                    'label' => 'Formcreator GLPI 10',
                    'native_url' => (string) ($capabilities['native_url'] ?? ''),
                    'message' => $this->formcreatorStateMessage($formcreatorState, $formcreatorCode),
                ],
            ],
            'fallback_policy' => I18n::translate('O portal lista os formulários permitidos. A abertura e o envio continuam sob responsabilidade do GLPI até que toda a compatibilidade seja homologada.'),
        ];
    }

    /**
     * @return array<string, mixed>|null
     */
    public function resolveForm(string $source, int $id): ?array
    {
        if ($source === 'formcreator_glpi10') {
            return $this->formcreatorGateway->findAuthorized($id);
        }

        if ($source !== 'glpi11_service_catalog') {
            return null;
        }

        $direct = $this->resolveGlpi11FormById($id);
        if ($direct['handled']) {
            return $direct['item'];
        }

        $sourceResult = $this->listGlpi11ServiceCatalogForms();
        foreach ((array) ($sourceResult['items'] ?? []) as $item) {
            if ((string) ($item['source'] ?? '') === $source && (int) ($item['id'] ?? 0) === $id) {
                return $item;
            }
        }

        return null;
    }

    /**
     * Uses the same public access-control components as GLPI 11's renderer.
     * A supported runtime is fail-closed: a denied ID is never reconciled by
     * scanning the catalog afterward. Older/partial fixtures keep the proven
     * catalog path as a compatibility fallback.
     *
     * @return array{handled:bool,item:?array<string,mixed>}
     */
    private function resolveGlpi11FormById(int $id): array
    {
        $formClass = '\Glpi\Form\Form';
        $managerClass = '\Glpi\Form\AccessControl\FormAccessControlManager';
        $parametersClass = '\Glpi\Form\AccessControl\FormAccessParameters';
        if (
            $id <= 0
            || !class_exists($formClass)
            || !method_exists($formClass, 'getById')
            || !class_exists($managerClass)
            || !method_exists($managerClass, 'getInstance')
            || !class_exists($parametersClass)
            || !method_exists('\Session', 'getCurrentSessionInfo')
        ) {
            return ['handled' => false, 'item' => null];
        }

        try {
            $form = $formClass::getById($id);
            if (!$form instanceof $formClass) {
                return ['handled' => true, 'item' => null];
            }

            $bypass = false;
            if (method_exists('\Session', 'haveRight')) {
                $rightName = is_string($formClass::$rightname ?? null)
                    ? (string) $formClass::$rightname
                    : 'form';
                $readRight = defined('READ') ? (int) constant('READ') : 1;
                $bypass = (bool) \Session::haveRight($rightName, $readRight);
            }

            $urlParameters = [];
            foreach ($_GET as $key => $value) {
                if (
                    !is_string($key)
                    || in_array($key, ['id', 'source'], true)
                    || (!is_scalar($value) && $value !== null)
                ) {
                    continue;
                }
                $urlParameters[$key] = $value;
            }
            $session = $bypass ? null : \Session::getCurrentSessionInfo();
            $parameters = new $parametersClass($session, $urlParameters, $bypass);
            $manager = $managerClass::getInstance();
            if (!method_exists($manager, 'canAnswerForm') || !$manager->canAnswerForm($form, $parameters)) {
                return ['handled' => true, 'item' => null];
            }

            return ['handled' => true, 'item' => $this->mapGlpi11Form($form)];
        } catch (\Throwable $e) {
            return ['handled' => false, 'item' => null];
        }
    }

    /**
     * @return array{available:bool, enabled:bool, message:string, items:array<int, array<string, mixed>>}
     */
    private function listGlpi11ServiceCatalogForms(): array
    {
        $available = class_exists('\Glpi\Form\Form')
            || class_exists('\Glpi\Form\ServiceCatalog\ServiceCatalog')
            || $this->tableExists('glpi_forms_forms');
        if (!$available) {
            return [
                'available' => false,
                'enabled' => false,
                'message' => I18n::translate('O Catálogo de Serviços não foi detectado nesta instalação.'),
                'items' => [],
            ];
        }

        if (
            class_exists('\Glpi\Form\ServiceCatalog\ServiceCatalog')
            && method_exists('\Glpi\Form\ServiceCatalog\ServiceCatalog', 'canView')
            && !\Glpi\Form\ServiceCatalog\ServiceCatalog::canView()
        ) {
            return [
                'available' => true,
                'enabled' => false,
                'message' => I18n::translate('O Catálogo de Serviços foi detectado, mas não está disponível para a entidade ou o perfil atual.'),
                'items' => [],
            ];
        }

        $items = $this->readGlpi11FormsFromServiceCatalog();
        return [
            'available' => true,
            'enabled' => true,
            'message' => $items === []
                ? I18n::translate('O Catálogo de Serviços foi detectado, mas não retornou formulários para este contexto. Abra a página completa para pesquisar categorias ou revisar as permissões.')
                : I18n::translate('Formulários retornados pelo Catálogo de Serviços do GLPI 11, respeitando entidade, perfil e controles de acesso.'),
            'items' => $items,
        ];
    }
    /**
     * @return array<int, array<string, mixed>>
     */
    private function readGlpi11FormsFromServiceCatalog(): array
    {
        $managerClass = '\Glpi\Form\ServiceCatalog\ServiceCatalogManager';
        $requestClass = '\Glpi\Form\ServiceCatalog\ItemRequest';
        $parametersClass = '\Glpi\Form\AccessControl\FormAccessParameters';
        if (
            !class_exists($managerClass)
            || !class_exists($requestClass)
            || !class_exists($parametersClass)
            || !class_exists('\Glpi\Form\Form')
            || !method_exists('\Session', 'getCurrentSessionInfo')
        ) {
            return [];
        }

        try {
            $session = \Session::getCurrentSessionInfo();
            if ($session === null) {
                return [];
            }

            $parameters = new $parametersClass($session, [], false);
            $manager = $managerClass::getInstance();
            $items = [];
            $page = 1;
            $pageSize = 80;
            $total = null;
            do {
                $request = new $requestClass($parameters, '', 0, $page, $pageSize);
                $result = (array) $manager->getItems($request);
                $pageItems = (array) ($result['items'] ?? []);
                foreach ($pageItems as $item) {
                    array_push($items, ...$this->mapGlpi11CatalogItem($item));
                }

                if (isset($result['total']) && is_numeric($result['total'])) {
                    $total = max(0, (int) $result['total']);
                }
                $page++;
                $moreByTotal = $total !== null && (($page - 1) * $pageSize) < $total;
                $moreByPageSize = $total === null && count($pageItems) === $pageSize;
            } while (($moreByTotal || $moreByPageSize) && $page <= 100);

            return $this->uniqueForms($items);
        } catch (\Throwable $e) {
            return [];
        }
    }

    /**
     * @return array<int, array<string, mixed>>
     */
    private function mapGlpi11CatalogItem(object $item): array
    {
        if ($item instanceof \Glpi\Form\Form) {
            return [$this->mapGlpi11Form($item)];
        }

        if (
            class_exists('\Glpi\Form\ServiceCatalog\ServiceCatalogCompositeInterface')
            && $item instanceof \Glpi\Form\ServiceCatalog\ServiceCatalogCompositeInterface
            && method_exists($item, 'getChildren')
        ) {
            $forms = [];
            foreach ((array) $item->getChildren() as $child) {
                if (is_object($child)) {
                    array_push($forms, ...$this->mapGlpi11CatalogItem($child));
                }
            }
            return $forms;
        }

        return [];
    }

    /**
     * @return array<string, mixed>
     */
    private function mapGlpi11Form(object $form): array
    {
        $id = method_exists($form, 'getID') ? (int) $form->getID() : (int) ($form->fields['id'] ?? 0);
        $name = method_exists($form, 'getServiceCatalogItemTitle')
            ? (string) $form->getServiceCatalogItemTitle()
            : (string) ($form->fields['name'] ?? sprintf(I18n::translate('Formulário #%d'), $id));
        $description = method_exists($form, 'getServiceCatalogItemDescription')
            ? (string) $form->getServiceCatalogItemDescription()
            : (string) ($form->fields['description'] ?? '');
        $nativeUrl = method_exists($form, 'getServiceCatalogLink')
            ? (string) $form->getServiceCatalogLink()
            : Url::core('Form/Render/' . $id);
        $illustration = method_exists($form, 'getServiceCatalogItemIllustration')
            ? (string) $form->getServiceCatalogItemIllustration()
            : (string) ($form->fields['illustration'] ?? '');

        return [
            'id' => $id,
            'source' => 'glpi11_service_catalog',
            'source_label' => 'Service Catalog GLPI 11',
            'visual_kind' => 'glpi11',
            'illustration' => $illustration,
            'name' => TextNormalizer::fromGlpi($name) ?: sprintf(I18n::translate('Formulário #%d'), $id),
            'description' => TextNormalizer::fromGlpi($description),
            'entity_id' => (int) ($form->fields['entities_id'] ?? 0),
            'is_recursive' => !empty($form->fields['is_recursive']),
            'native_url' => $nativeUrl,
            'rendering_status' => 'native_fallback',
            'rendering_message' => I18n::translate('A abertura e o envio são realizados pelo Catálogo de Serviços para preservar controles de acesso, condições, validações e destinos.'),
        ];
    }

    /**
     * @param array<int, array<string, mixed>> $items
     * @return array<int, array<string, mixed>>
     */
    private function uniqueForms(array $items): array
    {
        $seen = [];
        $unique = [];
        foreach ($items as $item) {
            $id = (int) ($item['id'] ?? 0);
            $key = (string) ($item['source'] ?? '') . ':' . $id;
            if ($id <= 0 || isset($seen[$key])) {
                continue;
            }
            $seen[$key] = true;
            $unique[] = $item;
        }

        return $unique;
    }

    /**
     * @param array<int, array<string, mixed>> $items
     * @return array<int, array<string, mixed>>
     */
    private function filterItemsByQuery(array $items, string $query): array
    {
        $needle = function_exists('mb_strtolower') ? mb_strtolower($query, 'UTF-8') : strtolower($query);
        return array_values(array_filter($items, static function (array $item) use ($needle): bool {
            $haystack = trim((string) ($item['name'] ?? '') . ' ' . (string) ($item['description'] ?? ''));
            $haystack = function_exists('mb_strtolower') ? mb_strtolower($haystack, 'UTF-8') : strtolower($haystack);
            return str_contains($haystack, $needle);
        }));
    }

    private function formcreatorStateMessage(string $state, string $code): string
    {
        if ($code === 'glpi11_uses_native_catalog') {
            return I18n::translate('O GLPI 11 usa o Catálogo de Serviços para esta funcionalidade.');
        }
        if ($code === 'catalog_disabled_by_policy') {
            return I18n::translate('A integração ampliada do Formcreator está desativada. Abra a página completa para continuar.');
        }

        return match ($state) {
            'not_detected' => I18n::translate('O catálogo de formulários não está disponível neste ambiente.'),
            'inactive' => I18n::translate('O catálogo de formulários está desativado neste ambiente.'),
            'unsupported_contract' => I18n::translate('Esta versão do catálogo ainda não é compatível com o portal. Abra a página completa para continuar.'),
            'unavailable_context' => I18n::translate('O catálogo não está disponível para seu perfil e sua entidade atuais.'),
            'ready_empty' => I18n::translate('Nenhum formulário está disponível para seu perfil e sua entidade atuais.'),
            'partial' => I18n::translate('A lista de formulários está incompleta. Tente novamente ou abra a página completa.'),
            'error' => I18n::translate('Não foi possível carregar os formulários agora. Tente novamente.'),
            default => I18n::translate('Formulários autorizados. A abertura e o envio são realizados pelo sistema responsável.'),
        };
    }

    private function serviceCatalogUrl(): string
    {
        return Url::core('ServiceCatalog');
    }

    private function tableExists(string $table): bool
    {
        global $DB;

        return isset($DB) && method_exists($DB, 'tableExists') && (bool) $DB->tableExists($table);
    }
}
