<?php

declare(strict_types=1);

namespace GlpiPlugin\Glpiacessivel\Infrastructure\Search;

interface BoundedTicketSearchAdapterInterface
{
    public function capability(): BoundedTicketSearchCapability;

    public function buildPlan(BoundedTicketSearchRequest $request): BoundedTicketSearchPlan;
}
