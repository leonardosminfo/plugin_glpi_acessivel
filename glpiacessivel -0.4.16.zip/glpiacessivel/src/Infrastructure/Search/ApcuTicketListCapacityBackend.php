<?php

declare(strict_types=1);

namespace GlpiPlugin\Glpiacessivel\Infrastructure\Search;

/**
 * Node-local semaphore backed by APCu. Each slot is acquired atomically and
 * expires automatically if a PHP worker terminates before releasing it.
 */
final class ApcuTicketListCapacityBackend implements TicketListCapacityBackend
{
    private const KEY_PREFIX = 'glpiacessivel:ticket-list-capacity:v1:';
    private const FAILURE_TTL_SECONDS = 300;

    public function name(): string
    {
        return 'apcu';
    }

    public function isAvailable(): bool
    {
        if (
            !function_exists('apcu_add')
            || !function_exists('apcu_fetch')
            || !function_exists('apcu_cas')
            || !function_exists('apcu_delete')
            || !function_exists('apcu_inc')
            || !function_exists('apcu_store')
        ) {
            return false;
        }

        return !function_exists('apcu_enabled') || apcu_enabled();
    }

    public function acquire(
        string $bucket,
        string $contextKey,
        int $maxConcurrent,
        int $leaseSeconds
    ): array {
        if (!$this->isAvailable()) {
            return ['lease_id' => '', 'reason' => 'capacity_backend_unavailable'];
        }

        $maxConcurrent = min(10, max(1, $maxConcurrent));
        $leaseSeconds = min(30, max(5, $leaseSeconds));
        $token = random_int(1, PHP_INT_MAX);
        for ($slot = 1; $slot <= $maxConcurrent; $slot++) {
            $slotKey = $this->slotKey($bucket, $slot);
            if (!apcu_add($slotKey, $token, $leaseSeconds)) {
                continue;
            }

            $contextHash = hash('sha256', $contextKey);
            $contextToken = random_int(1, PHP_INT_MAX);
            if (!apcu_add($this->contextKey($bucket, $contextHash), $contextToken, $leaseSeconds)) {
                $this->releaseToken($slotKey, $token);
                return ['lease_id' => '', 'reason' => 'user_context_in_flight'];
            }

            return [
                'lease_id' => $slot . ':' . $token . ':' . $contextHash . ':' . $contextToken,
                'reason' => 'admitted',
            ];
        }

        return ['lease_id' => '', 'reason' => 'capacity_limit_reached'];
    }

    public function release(string $bucket, string $leaseId): bool
    {
        if (
            !$this->isAvailable()
            || preg_match('/^(\d{1,2}):(\d+):([a-f0-9]{64}):(\d+)$/D', $leaseId, $matches) !== 1
        ) {
            return false;
        }

        $slot = (int) $matches[1];
        $token = (int) $matches[2];
        $contextHash = (string) $matches[3];
        $contextToken = (int) $matches[4];
        if ($slot < 1 || $slot > 10 || $token < 1 || $contextToken < 1) {
            return false;
        }

        $contextReleased = $this->releaseToken(
            $this->contextKey($bucket, $contextHash),
            $contextToken
        );
        $slotReleased = $this->releaseToken($this->slotKey($bucket, $slot), $token);

        return $contextReleased && $slotReleased;
    }

    public function admitCircuit(string $bucket, int $openSeconds, int $leaseSeconds): array
    {
        if (!$this->isAvailable()) {
            return $this->circuitDenied('capacity_backend_unavailable', 1, 'unavailable');
        }

        $now = time();
        $openKey = $this->circuitKey($bucket, 'open');
        $success = false;
        $openUntil = apcu_fetch($openKey, $success);
        if (!$success || !is_int($openUntil)) {
            return $this->circuitAllowed('', 'closed');
        }

        if ($openUntil > $now) {
            return $this->circuitDenied('circuit_open', $openUntil - $now, 'open');
        }

        $probeId = (string) random_int(1, PHP_INT_MAX);
        if (!apcu_add($this->circuitKey($bucket, 'probe'), (int) $probeId, $leaseSeconds)) {
            return $this->circuitDenied('circuit_half_open', 1, 'half_open');
        }

        return $this->circuitAllowed($probeId, 'half_open');
    }

    public function recordCircuitSuccess(string $bucket, string $probeId): bool
    {
        if (!$this->isAvailable()) {
            return false;
        }

        apcu_delete($this->circuitKey($bucket, 'failures'));
        if ($probeId === '') {
            return true;
        }

        if (!$this->releaseToken($this->circuitKey($bucket, 'probe'), (int) $probeId)) {
            return false;
        }
        apcu_delete($this->circuitKey($bucket, 'open'));
        return true;
    }

    public function recordCircuitFailure(
        string $bucket,
        string $probeId,
        int $failureThreshold,
        int $openSeconds
    ): bool {
        if (!$this->isAvailable()) {
            return false;
        }

        $failureThreshold = max(1, $failureThreshold);
        $openSeconds = max(1, $openSeconds);
        if ($probeId !== '') {
            $this->releaseToken($this->circuitKey($bucket, 'probe'), (int) $probeId);
            return $this->openCircuit($bucket, $openSeconds);
        }

        $failureKey = $this->circuitKey($bucket, 'failures');
        if (apcu_add($failureKey, 1, self::FAILURE_TTL_SECONDS)) {
            $failures = 1;
        } else {
            $success = false;
            $failures = apcu_inc($failureKey, 1, $success);
            if (!$success || !is_int($failures)) {
                return false;
            }
        }

        return $failures < $failureThreshold || $this->openCircuit($bucket, $openSeconds);
    }

    public function cancelCircuitProbe(string $bucket, string $probeId): bool
    {
        if ($probeId === '') {
            return true;
        }

        return $this->releaseToken($this->circuitKey($bucket, 'probe'), (int) $probeId);
    }

    private function slotKey(string $bucket, int $slot): string
    {
        return self::KEY_PREFIX . hash('sha256', $bucket) . ':' . $slot;
    }

    private function contextKey(string $bucket, string $contextHash): string
    {
        return self::KEY_PREFIX . hash('sha256', $bucket) . ':context:' . $contextHash;
    }

    private function circuitKey(string $bucket, string $suffix): string
    {
        return self::KEY_PREFIX . hash('sha256', $bucket) . ':circuit:' . $suffix;
    }

    private function releaseToken(string $key, int $token): bool
    {
        if ($token < 1) {
            return false;
        }
        $success = false;
        $current = apcu_fetch($key, $success);
        if (!$success || !is_int($current) || $current !== $token) {
            return false;
        }
        if (!apcu_cas($key, $token, 0)) {
            return false;
        }

        return apcu_delete($key);
    }

    private function openCircuit(string $bucket, int $openSeconds): bool
    {
        apcu_delete($this->circuitKey($bucket, 'failures'));
        $openUntil = time() + $openSeconds;
        return apcu_store(
            $this->circuitKey($bucket, 'open'),
            $openUntil,
            0
        );
    }

    /** @return array{allowed:true,retry_after:0,probe_id:string,state:string,reason:string} */
    private function circuitAllowed(string $probeId, string $state): array
    {
        return [
            'allowed' => true,
            'retry_after' => 0,
            'probe_id' => $probeId,
            'state' => $state,
            'reason' => 'admitted',
        ];
    }

    /** @return array{allowed:false,retry_after:int,probe_id:string,state:string,reason:string} */
    private function circuitDenied(string $reason, int $retryAfter, string $state): array
    {
        return [
            'allowed' => false,
            'retry_after' => max(1, $retryAfter),
            'probe_id' => '',
            'state' => $state,
            'reason' => $reason,
        ];
    }
}
