<?php

declare(strict_types=1);

namespace GlpiPlugin\Glpiacessivel\Infrastructure\Search;

/** Session-scoped token bucket dedicated to ticket result retrieval. */
final class TicketListRateLimiter
{
    private const SESSION_KEY = 'glpiacessivel_ticket_list_rate_v3';
    private const LEGACY_SESSION_KEY = 'glpiacessivel_ticket_list_rate_v2';

    private int $limit;
    private int $windowSeconds;
    private int $burst;

    /** @var callable():float */
    private $clock;

    /** @param null|callable():float $clock */
    public function __construct(int $limit = 30, int $windowSeconds = 60, int $burst = 5, ?callable $clock = null)
    {
        $this->limit = min(30, max(1, $limit));
        $this->windowSeconds = min(300, max(10, $windowSeconds));
        $this->burst = min(5, $this->limit, max(1, $burst));
        $this->clock = $clock ?? static fn(): float => microtime(true);
    }

    /** @return array{allowed:bool,retry_after:int} */
    public function consume(): array
    {
        $now = max(0.0, (float) ($this->clock)());
        unset($_SESSION[self::LEGACY_SESSION_KEY]);
        $policy = $this->limit . ':' . $this->windowSeconds . ':' . $this->burst;
        $bucket = is_array($_SESSION[self::SESSION_KEY] ?? null)
            ? $_SESSION[self::SESSION_KEY]
            : [];
        if (!is_string($bucket['policy'] ?? null) || !hash_equals($policy, $bucket['policy'])) {
            $bucket = [];
        }
        $updatedAt = is_numeric($bucket['updated_at'] ?? null)
            ? (float) $bucket['updated_at']
            : $now;
        $tokens = is_numeric($bucket['tokens'] ?? null)
            ? (float) $bucket['tokens']
            : (float) $this->burst;
        if (!is_finite($updatedAt) || !is_finite($tokens) || $now < $updatedAt) {
            $updatedAt = $now;
            $tokens = (float) $this->burst;
        }

        $refillPerSecond = $this->limit / $this->windowSeconds;
        $tokens = min((float) $this->burst, max(0.0, $tokens) + (($now - $updatedAt) * $refillPerSecond));
        if ($tokens < 1.0) {
            $_SESSION[self::SESSION_KEY] = [
                'policy' => $policy,
                'updated_at' => $now,
                'tokens' => $tokens,
            ];
            return [
                'allowed' => false,
                'retry_after' => max(1, (int) ceil((1.0 - $tokens) / $refillPerSecond)),
            ];
        }

        $_SESSION[self::SESSION_KEY] = [
            'policy' => $policy,
            'updated_at' => $now,
            'tokens' => $tokens - 1.0,
        ];

        return ['allowed' => true, 'retry_after' => 0];
    }
}
