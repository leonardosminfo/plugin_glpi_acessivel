<?php

declare(strict_types=1);

namespace GlpiPlugin\Glpiacessivel\Infrastructure\Search;

use GlpiPlugin\Glpiacessivel\Infrastructure\Database\GlpiDatabaseQuery;

/**
 * Applies a server-side execution budget without rewriting the native GLPI SQL.
 */
final class MySqlMariaDbQueryBudget
{
    public const STATEMENT_TIMEOUT_MILLISECONDS = 3000;
    public const GROUP_CONCAT_MAX_LENGTH = 8194304;
    public const MINIMUM_CAPACITY_LEASE_SECONDS = 8;

    private const DIALECT_MYSQL = 'mysql';
    private const DIALECT_MARIADB = 'mariadb';

    /**
     * @param callable(string):?array<int, int> $executeStatement
     * @return array{ids:?array<int, int>,reason:string,dialect:string}
     */
    public function execute(object $database, string $sql, callable $executeStatement): array
    {
        $dialect = $this->detectDialect($database);
        if ($dialect === null) {
            return $this->failure('database_dialect_unsupported');
        }

        if ($dialect === self::DIALECT_MARIADB) {
            return $this->executeMariaDb($sql, $executeStatement);
        }

        return $this->executeMySql($database, $sql, $executeStatement);
    }

    /**
     * @param callable(string):?array<int, int> $executeStatement
     * @return array{ids:?array<int, int>,reason:string,dialect:string}
     */
    private function executeMariaDb(string $sql, callable $executeStatement): array
    {
        $timeoutSeconds = number_format(
            self::STATEMENT_TIMEOUT_MILLISECONDS / 1000,
            3,
            '.',
            ''
        );
        $budgetedSql = 'SET STATEMENT max_statement_time=' . $timeoutSeconds
            . ', group_concat_max_len=' . self::GROUP_CONCAT_MAX_LENGTH
            . ' FOR ' . $sql;

        try {
            $ids = $executeStatement($budgetedSql);
        } catch (\Throwable $e) {
            return $this->failure('statement_execution_failed', self::DIALECT_MARIADB);
        }

        if (!is_array($ids)) {
            return $this->failure('statement_execution_failed', self::DIALECT_MARIADB);
        }

        return [
            'ids' => $ids,
            'reason' => '',
            'dialect' => self::DIALECT_MARIADB,
        ];
    }

    /**
     * @param callable(string):?array<int, int> $executeStatement
     * @return array{ids:?array<int, int>,reason:string,dialect:string}
     */
    private function executeMySql(object $database, string $sql, callable $executeStatement): array
    {
        $originalGroupConcatLength = $this->readPositiveInteger(
            $database,
            'SELECT @@SESSION.group_concat_max_len AS configured_value'
        );
        if ($originalGroupConcatLength === null) {
            return $this->failure('session_budget_snapshot_failed', self::DIALECT_MYSQL);
        }

        $restoreRequired = $originalGroupConcatLength < self::GROUP_CONCAT_MAX_LENGTH;
        $restored = true;
        $ids = null;
        $reason = '';

        try {
            if (
                $restoreRequired
                && !$this->executeControlStatement(
                    $database,
                    'SET SESSION group_concat_max_len=' . self::GROUP_CONCAT_MAX_LENGTH
                )
            ) {
                $reason = 'session_budget_apply_failed';
            } else {
                $budgetedSql = $this->withMySqlTimeoutHint($sql);
                if ($budgetedSql === null) {
                    $reason = 'statement_budget_apply_failed';
                } else {
                    $ids = $executeStatement($budgetedSql);
                    if (!is_array($ids)) {
                        $reason = 'statement_execution_failed';
                    }
                }
            }
        } catch (\Throwable $e) {
            $ids = null;
            $reason = 'statement_execution_failed';
        } finally {
            if ($restoreRequired) {
                try {
                    $restored = $this->executeControlStatement(
                        $database,
                        'SET SESSION group_concat_max_len=' . $originalGroupConcatLength
                    );
                } catch (\Throwable $e) {
                    $restored = false;
                }
            }
        }

        if (!$restored) {
            return $this->failure('session_budget_restore_failed', self::DIALECT_MYSQL);
        }
        if ($reason !== '' || !is_array($ids)) {
            return $this->failure(
                $reason !== '' ? $reason : 'statement_execution_failed',
                self::DIALECT_MYSQL
            );
        }

        return [
            'ids' => $ids,
            'reason' => '',
            'dialect' => self::DIALECT_MYSQL,
        ];
    }

    private function withMySqlTimeoutHint(string $sql): ?string
    {
        if (preg_match('/\A(\s*SELECT\b)/i', $sql, $matches) !== 1) {
            return null;
        }

        $prefixLength = strlen($matches[1]);
        return substr($sql, 0, $prefixLength)
            . ' /*+ MAX_EXECUTION_TIME(' . self::STATEMENT_TIMEOUT_MILLISECONDS . ') */'
            . substr($sql, $prefixLength);
    }

    private function detectDialect(object $database): ?string
    {
        $version = $this->readScalar($database, 'SELECT VERSION() AS configured_value');
        if (!is_string($version) && !is_numeric($version)) {
            return null;
        }
        $version = (string) $version;
        if (stripos($version, 'mariadb') !== false) {
            if (preg_match('/(\d+\.\d+(?:\.\d+)?)\s*-MariaDB/i', $version, $matches) !== 1) {
                return null;
            }
            $numericVersion = $matches[1];
            return version_compare($numericVersion, '10.2.0', '>=')
                ? self::DIALECT_MARIADB
                : null;
        }
        if (preg_match('/\A\s*(\d+\.\d+(?:\.\d+)?)/', $version, $matches) !== 1) {
            return null;
        }
        return version_compare($matches[1], '5.7.8', '>=')
            ? self::DIALECT_MYSQL
            : null;
    }

    private function readPositiveInteger(object $database, string $sql): ?int
    {
        $value = $this->readScalar($database, $sql);
        if (!is_numeric($value)) {
            return null;
        }
        $value = (int) $value;

        return $value > 0 ? $value : null;
    }

    /** @return mixed */
    private function readScalar(object $database, string $sql)
    {
        $result = GlpiDatabaseQuery::execute($database, $sql);
        if ($result === false) {
            return null;
        }
        $row = $this->fetchRow($database, $result);

        return is_array($row) && array_key_exists('configured_value', $row)
            ? $row['configured_value']
            : null;
    }

    private function executeControlStatement(object $database, string $sql): bool
    {
        return GlpiDatabaseQuery::execute($database, $sql) !== false;
    }

    /** @param mixed $result @return array<string, mixed>|null */
    private function fetchRow(object $database, $result): ?array
    {
        if (method_exists($database, 'fetchAssoc')) {
            $row = $database->fetchAssoc($result);
            return is_array($row) ? $row : null;
        }
        if (is_object($result) && method_exists($result, 'fetch_assoc')) {
            $row = $result->fetch_assoc();
            return is_array($row) ? $row : null;
        }

        return null;
    }

    /** @return array{ids:null,reason:string,dialect:string} */
    private function failure(string $reason, string $dialect = 'unknown'): array
    {
        return [
            'ids' => null,
            'reason' => $reason,
            'dialect' => $dialect,
        ];
    }
}
