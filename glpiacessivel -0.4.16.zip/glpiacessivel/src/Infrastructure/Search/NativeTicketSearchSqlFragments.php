<?php

declare(strict_types=1);

namespace GlpiPlugin\Glpiacessivel\Infrastructure\Search;

final class NativeTicketSearchSqlFragments
{
    private function __construct(
        private string $select,
        private string $from,
        private string $where,
        private string $groupBy,
        private string $having,
        private string $order
    ) {
    }

    /**
     * @param array<string, mixed> $raw
     */
    public static function fromRaw(array $raw): ?self
    {
        $parts = [];
        foreach (['SELECT', 'FROM', 'WHERE', 'GROUPBY', 'HAVING', 'ORDER', 'LIMIT'] as $key) {
            if (!array_key_exists($key, $raw) || !is_string($raw[$key])) {
                return null;
            }
            $parts[$key] = $raw[$key];
        }
        if (
            trim($parts['SELECT']) === ''
            || trim($parts['FROM']) === ''
            || preg_match('/\bAS\s+`?id`?(?=\s*,|\s*$)/i', $parts['SELECT']) !== 1
        ) {
            return null;
        }

        return new self(
            $parts['SELECT'],
            $parts['FROM'],
            $parts['WHERE'],
            $parts['GROUPBY'],
            $parts['HAVING'],
            $parts['ORDER']
        );
    }

    public function withCanonicalLimit(int $offset, int $rowLimit): string
    {
        if ($offset < 0 || $rowLimit < 1) {
            throw new \InvalidArgumentException('The bounded search window must be positive.');
        }

        return $this->select
            . $this->from
            . $this->where
            . $this->groupBy
            . $this->having
            . $this->order
            . ' LIMIT ' . $offset . ', ' . $rowLimit;
    }
}
