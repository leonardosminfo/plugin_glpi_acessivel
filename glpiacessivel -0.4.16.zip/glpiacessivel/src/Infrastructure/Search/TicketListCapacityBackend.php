<?php

declare(strict_types=1);

namespace GlpiPlugin\Glpiacessivel\Infrastructure\Search;

/**
 * Capacity backends must be independent from the GLPI database. Using the
 * saturated database to admit more database work would defeat the guard.
 */
interface TicketListCapacityBackend
{
    public function name(): string;

    public function isAvailable(): bool;

    /** @return array{lease_id:string,reason:string} */
    public function acquire(
        string $bucket,
        string $contextKey,
        int $maxConcurrent,
        int $leaseSeconds
    ): array;

    public function release(string $bucket, string $leaseId): bool;

    /** @return array{allowed:bool,retry_after:int,probe_id:string,state:string,reason:string} */
    public function admitCircuit(string $bucket, int $openSeconds, int $leaseSeconds): array;

    public function recordCircuitSuccess(string $bucket, string $probeId): bool;

    public function recordCircuitFailure(
        string $bucket,
        string $probeId,
        int $failureThreshold,
        int $openSeconds
    ): bool;

    public function cancelCircuitProbe(string $bucket, string $probeId): bool;
}
