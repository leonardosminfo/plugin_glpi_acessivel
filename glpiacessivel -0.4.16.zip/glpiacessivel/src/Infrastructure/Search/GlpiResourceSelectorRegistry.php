<?php

declare(strict_types=1);

namespace GlpiPlugin\Glpiacessivel\Infrastructure\Search;

/**
 * Closed registry of selector purposes. The browser never supplies a table,
 * itemtype, right or native condition.
 */
final class GlpiResourceSelectorRegistry
{
    public const CATEGORY = 'category';
    public const LOCATION = 'location';
    public const REQUESTER_USER = 'requester_user';
    public const REQUESTER_GROUP = 'requester_group';
    public const ASSIGNED_USER = 'assigned_user';
    public const ASSIGNED_GROUP = 'assigned_group';
    public const ASSIGNED_SUPPLIER = 'assigned_supplier';
    public const OBSERVER_USER = 'observer_user';
    public const OBSERVER_GROUP = 'observer_group';
    public const TASK_TECHNICIAN = 'task_technician';
    public const TASK_GROUP = 'task_group';

    public const PURPOSES = [
        self::CATEGORY,
        self::LOCATION,
        self::REQUESTER_USER,
        self::REQUESTER_GROUP,
        self::ASSIGNED_USER,
        self::ASSIGNED_GROUP,
        self::ASSIGNED_SUPPLIER,
        self::OBSERVER_USER,
        self::OBSERVER_GROUP,
        self::TASK_TECHNICIAN,
        self::TASK_GROUP,
    ];

    /** @var array<string,int> */
    private const MINIMUM_QUERY_LENGTHS = [
        self::CATEGORY => 0,
        self::LOCATION => 0,
        self::REQUESTER_USER => 2,
        self::REQUESTER_GROUP => 2,
        self::ASSIGNED_USER => 2,
        self::ASSIGNED_GROUP => 2,
        self::ASSIGNED_SUPPLIER => 2,
        self::OBSERVER_USER => 2,
        self::OBSERVER_GROUP => 2,
        self::TASK_TECHNICIAN => 2,
        self::TASK_GROUP => 2,
    ];

    /**
     * @param array<string,int> $dependencies
     * @return array<string,mixed>
     */
    public function descriptor(string $purpose, array $dependencies = []): array
    {
        if (!in_array($purpose, self::PURPOSES, true)) {
            throw new \InvalidArgumentException('resource_selector_purpose_not_allowed');
        }

        $condition = [];
        $table = '';
        $linkfield = '';
        $itemtype = '';
        $right = null;

        switch ($purpose) {
            case self::CATEGORY:
                $table = 'glpi_itilcategories';
                $linkfield = 'itilcategories_id';
                $itemtype = 'ITILCategory';
                // GLPI 10 and 11 expose the helpdesk visibility flag with this
                // exact native column name. Keep it in the closed registry so
                // the browser cannot influence the database contract.
                $condition = ['is_helpdeskvisible' => 1];
                $ticketType = (int) ($dependencies['ticket_type'] ?? 0);
                if ($ticketType === 1) {
                    $condition['is_incident'] = 1;
                } elseif ($ticketType === 2) {
                    $condition['is_request'] = 1;
                } elseif ($ticketType !== 0) {
                    throw new \InvalidArgumentException('resource_selector_dependency_invalid');
                }
                break;

            case self::LOCATION:
                $table = 'glpi_locations';
                $linkfield = 'locations_id';
                $itemtype = 'Location';
                break;

            case self::REQUESTER_USER:
                $table = 'glpi_users';
                $linkfield = 'users_id';
                $itemtype = 'User';
                // This broad native scope is reachable only after the
                // controller proves the central-interface requester
                // capability. The creation service then revalidates the exact
                // user and Ticket::canDelegateeCreateTicket before mutation.
                $right = 'all';
                break;

            case self::REQUESTER_GROUP:
                $table = 'glpi_groups';
                $linkfield = 'groups_id';
                $itemtype = 'Group';
                $condition = ['is_requester' => 1];
                break;

            case self::ASSIGNED_USER:
            case self::TASK_TECHNICIAN:
                $table = 'glpi_users';
                $linkfield = 'users_id';
                $itemtype = 'User';
                $right = 'own_ticket';
                break;

            case self::OBSERVER_USER:
                $table = 'glpi_users';
                $linkfield = 'users_id';
                $itemtype = 'User';
                // Ticket::getDefaultActorRightSearch() returns the native
                // "all" scope for observers in both GLPI 10 and GLPI 11.
                // Exact IDs are still filtered by the shared eligibility
                // policy before they are returned or mutated.
                $right = 'all';
                break;

            case self::ASSIGNED_GROUP:
                $table = 'glpi_groups';
                $linkfield = 'groups_id';
                $itemtype = 'Group';
                $condition = ['is_assign' => 1];
                break;

            case self::ASSIGNED_SUPPLIER:
                $table = 'glpi_suppliers';
                $linkfield = 'suppliers_id';
                $itemtype = 'Supplier';
                $condition = ['is_active' => 1];
                break;

            case self::OBSERVER_GROUP:
                $table = 'glpi_groups';
                $linkfield = 'groups_id';
                $itemtype = 'Group';
                $condition = ['is_watcher' => 1];
                break;

            case self::TASK_GROUP:
                $table = 'glpi_groups';
                $linkfield = 'groups_id';
                $itemtype = 'Group';
                $condition = ['is_task' => 1];
                break;
        }

        return [
            'id' => 1,
            'table' => $table,
            'linkfield' => $linkfield,
            'value' => [
                'mode' => 'remote',
                'table' => $table,
                'linkfield' => $linkfield,
                'native' => [
                    'itemtype' => $itemtype,
                    'right' => $right,
                    'condition' => $condition,
                    'displaywith' => [],
                    'toadd' => [],
                ],
            ],
        ];
    }

    /** @return string[] */
    public function allowedDependencyKeys(string $purpose): array
    {
        if (!in_array($purpose, self::PURPOSES, true)) {
            throw new \InvalidArgumentException('resource_selector_purpose_not_allowed');
        }

        if ($purpose === self::CATEGORY) {
            return ['ticket_id', 'ticket_type'];
        }
        if ($purpose === self::LOCATION) {
            return ['ticket_id'];
        }
        if (
            in_array($purpose, [
                self::ASSIGNED_USER,
                self::ASSIGNED_GROUP,
                self::ASSIGNED_SUPPLIER,
                self::REQUESTER_USER,
                self::REQUESTER_GROUP,
                self::OBSERVER_USER,
                self::OBSERVER_GROUP,
                self::TASK_TECHNICIAN,
                self::TASK_GROUP,
            ], true)
        ) {
            return ['ticket_id'];
        }

        return [];
    }

    public function requiresQuery(string $purpose): bool
    {
        return $this->minimumQueryLength($purpose) > 0;
    }

    public function minimumQueryLength(string $purpose): int
    {
        if (!array_key_exists($purpose, self::MINIMUM_QUERY_LENGTHS)) {
            throw new \InvalidArgumentException('resource_selector_purpose_not_allowed');
        }

        return self::MINIMUM_QUERY_LENGTHS[$purpose];
    }
}
