<?php

declare(strict_types=1);

namespace GlpiPlugin\Glpiacessivel\Infrastructure\Search;

/** Selects APCu when available and otherwise a process-safe file backend. */
final class LocalTicketListCapacityBackend implements TicketListCapacityBackend
{
    private TicketListCapacityBackend $backend;

    public function __construct(
        ?TicketListCapacityBackend $apcu = null,
        ?FileTicketListCapacityBackend $filesystem = null
    ) {
        $apcu ??= new ApcuTicketListCapacityBackend();
        $this->backend = $apcu->isAvailable()
            ? $apcu
            : ($filesystem ?? new FileTicketListCapacityBackend());
    }

    public function name(): string
    {
        return $this->backend->name();
    }

    public function isAvailable(): bool
    {
        return $this->backend->isAvailable();
    }

    public function acquire(
        string $bucket,
        string $contextKey,
        int $maxConcurrent,
        int $leaseSeconds
    ): array {
        return $this->backend->acquire($bucket, $contextKey, $maxConcurrent, $leaseSeconds);
    }

    public function release(string $bucket, string $leaseId): bool
    {
        return $this->backend->release($bucket, $leaseId);
    }

    public function admitCircuit(string $bucket, int $openSeconds, int $leaseSeconds): array
    {
        return $this->backend->admitCircuit($bucket, $openSeconds, $leaseSeconds);
    }

    public function recordCircuitSuccess(string $bucket, string $probeId): bool
    {
        return $this->backend->recordCircuitSuccess($bucket, $probeId);
    }

    public function recordCircuitFailure(
        string $bucket,
        string $probeId,
        int $failureThreshold,
        int $openSeconds
    ): bool {
        return $this->backend->recordCircuitFailure(
            $bucket,
            $probeId,
            $failureThreshold,
            $openSeconds
        );
    }

    public function cancelCircuitProbe(string $bucket, string $probeId): bool
    {
        return $this->backend->cancelCircuitProbe($bucket, $probeId);
    }
}
