<?php

declare(strict_types=1);

namespace GlpiPlugin\Glpiacessivel\Infrastructure\Search;

final class Glpi11BoundedTicketSearchAdapter extends AbstractGlpiBoundedTicketSearchAdapter
{
    protected function supportedMajor(): int
    {
        return 11;
    }

    protected function adapterName(): string
    {
        return 'glpi11_search_sql';
    }
}
