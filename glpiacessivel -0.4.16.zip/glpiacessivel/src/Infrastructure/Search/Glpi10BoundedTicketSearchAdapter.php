<?php

declare(strict_types=1);

namespace GlpiPlugin\Glpiacessivel\Infrastructure\Search;

final class Glpi10BoundedTicketSearchAdapter extends AbstractGlpiBoundedTicketSearchAdapter
{
    protected function supportedMajor(): int
    {
        return 10;
    }

    protected function adapterName(): string
    {
        return 'glpi10_search_sql';
    }
}
