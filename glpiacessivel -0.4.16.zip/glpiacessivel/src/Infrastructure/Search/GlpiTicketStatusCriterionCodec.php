<?php

declare(strict_types=1);

namespace GlpiPlugin\Glpiacessivel\Infrastructure\Search;

use GlpiPlugin\Glpiacessivel\Domain\Ticket\NativeSearchValidationException;

/**
 * Translate the portal's semantic "not equals" operator to the representation
 * understood by GLPI's special Ticket status SQL branch.
 *
 * GLPI 10/11 derive status negation from the logical link, not from the
 * `notequals` search type. The portal keeps `notequals` in its canonical AST;
 * only native execution and storage use `equals` with an inverted link.
 */
final class GlpiTicketStatusCriterionCodec
{
    /** @var null|array<int|string,mixed> */
    private ?array $resolvedTicketSearchOptions = null;

    /** @return array<int,mixed> */
    public function compileForGlpi(array $criteria, string $defaultItemtype = 'Ticket'): array
    {
        return $this->transform($criteria, $defaultItemtype, true);
    }

    /** @return array<int,mixed> */
    public function restorePortalSemantics(array $criteria, string $defaultItemtype = 'Ticket'): array
    {
        return $this->transform($criteria, $defaultItemtype, false);
    }

    /** @return array<int,mixed> */
    private function transform(array $criteria, string $defaultItemtype, bool $compile): array
    {
        $searchOptions = $this->ticketSearchOptions();
        if ($searchOptions === []) {
            if ($compile && $this->containsSearchType($criteria, 'notequals')) {
                throw new NativeSearchValidationException(
                    'native_search_options_unavailable',
                    'criteria.searchtype'
                );
            }
            return $criteria;
        }

        $transformed = [];
        foreach ($criteria as $key => $criterion) {
            if (!is_array($criterion)) {
                $transformed[$key] = $criterion;
                continue;
            }

            if (array_key_exists('criteria', $criterion) && is_array($criterion['criteria'])) {
                $criterion['criteria'] = $this->transform(
                    $criterion['criteria'],
                    $defaultItemtype,
                    $compile
                );
                $transformed[$key] = $criterion;
                continue;
            }

            $itemtype = trim((string) ($criterion['itemtype'] ?? $defaultItemtype));
            if (!$this->isTicketStatusCriterion($criterion, $itemtype, $searchOptions)) {
                $transformed[$key] = $criterion;
                continue;
            }

            $searchType = strtolower(trim((string) ($criterion['searchtype'] ?? '')));
            $link = strtoupper(trim((string) ($criterion['link'] ?? 'AND')));
            if ($compile && $searchType === 'notequals') {
                $criterion['searchtype'] = 'equals';
                $criterion['link'] = $this->invertLinkNegation($link);
            } elseif (!$compile && $searchType === 'equals' && $this->linkIsNegative($link)) {
                $criterion['searchtype'] = 'notequals';
                $criterion['link'] = $this->invertLinkNegation($link);
            }

            $transformed[$key] = $criterion;
        }

        return $transformed;
    }

    private function containsSearchType(array $criteria, string $expected): bool
    {
        foreach ($criteria as $criterion) {
            if (!is_array($criterion)) {
                continue;
            }
            if (
                is_array($criterion['criteria'] ?? null)
                && $this->containsSearchType($criterion['criteria'], $expected)
            ) {
                return true;
            }
            if (strtolower(trim((string) ($criterion['searchtype'] ?? ''))) === $expected) {
                return true;
            }
        }

        return false;
    }

    /**
     * @param array<string,mixed> $criterion
     * @param array<int|string,mixed> $searchOptions
     */
    private function isTicketStatusCriterion(array $criterion, string $itemtype, array $searchOptions): bool
    {
        if ($itemtype !== 'Ticket' || !is_numeric($criterion['field'] ?? null)) {
            return false;
        }

        $field = (int) $criterion['field'];
        $option = $searchOptions[$field] ?? $searchOptions[(string) $field] ?? null;
        if (!is_array($option)) {
            return false;
        }

        return (string) ($option['table'] ?? '') === $this->ticketTable()
            && (string) ($option['field'] ?? '') === 'status';
    }

    /** @return array<int|string,mixed> */
    private function ticketSearchOptions(): array
    {
        if ($this->resolvedTicketSearchOptions !== null) {
            return $this->resolvedTicketSearchOptions;
        }

        if (!class_exists('\Search') || !method_exists('\Search', 'getOptions')) {
            return $this->resolvedTicketSearchOptions = [];
        }

        try {
            $options = \Search::getOptions('Ticket');
            return $this->resolvedTicketSearchOptions = is_array($options) ? $options : [];
        } catch (\Throwable $e) {
            return $this->resolvedTicketSearchOptions = [];
        }
    }

    private function ticketTable(): string
    {
        if (class_exists('\Ticket') && method_exists('\Ticket', 'getTable')) {
            try {
                $table = trim((string) \Ticket::getTable());
                if ($table !== '') {
                    return $table;
                }
            } catch (\Throwable $e) {
                // Keep the safe native table fallback below.
            }
        }

        return 'glpi_tickets';
    }

    private function linkIsNegative(string $link): bool
    {
        return $link === 'AND NOT' || $link === 'OR NOT';
    }

    private function invertLinkNegation(string $link): string
    {
        $links = [
            'AND' => 'AND NOT',
            'OR' => 'OR NOT',
            'AND NOT' => 'AND',
            'OR NOT' => 'OR',
        ];

        return $links[$link] ?? $link;
    }
}
