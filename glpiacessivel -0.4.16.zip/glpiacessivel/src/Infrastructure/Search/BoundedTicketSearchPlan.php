<?php

declare(strict_types=1);

namespace GlpiPlugin\Glpiacessivel\Infrastructure\Search;

final class BoundedTicketSearchPlan
{
    private function __construct(
        private bool $available,
        private string $sql,
        private string $reason,
        private string $adapter,
        private int $rowLimit
    ) {
    }

    public static function available(string $sql, string $adapter, int $rowLimit): self
    {
        return new self(true, $sql, '', $adapter, $rowLimit);
    }

    public static function unavailable(string $reason, string $adapter = ''): self
    {
        return new self(false, '', $reason, $adapter, 0);
    }

    public function availableInRuntime(): bool
    {
        return $this->available;
    }

    public function sql(): string
    {
        return $this->sql;
    }

    public function reason(): string
    {
        return $this->reason;
    }

    public function adapter(): string
    {
        return $this->adapter;
    }

    public function rowLimit(): int
    {
        return $this->rowLimit;
    }
}
