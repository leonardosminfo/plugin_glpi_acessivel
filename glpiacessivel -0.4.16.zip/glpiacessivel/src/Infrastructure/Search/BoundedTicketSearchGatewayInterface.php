<?php

declare(strict_types=1);

namespace GlpiPlugin\Glpiacessivel\Infrastructure\Search;

interface BoundedTicketSearchGatewayInterface
{
    public function search(BoundedTicketSearchRequest $request): BoundedTicketSearchResult;

    public function capability(): BoundedTicketSearchCapability;
}
