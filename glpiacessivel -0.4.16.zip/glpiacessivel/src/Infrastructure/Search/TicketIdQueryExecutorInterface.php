<?php

declare(strict_types=1);

namespace GlpiPlugin\Glpiacessivel\Infrastructure\Search;

interface TicketIdQueryExecutorInterface
{
    /** @return int[]|null */
    public function fetchIds(string $sql, int $maximumRows): ?array;
}
