<?php

declare(strict_types=1);

namespace GlpiPlugin\Glpiacessivel\Infrastructure\Search;

/**
 * Safe local fallback when APCu is unavailable. Non-blocking file locks are
 * released by the operating system if a PHP worker exits unexpectedly.
 */
final class FileTicketListCapacityBackend implements TicketListCapacityBackend
{
    private const CIRCUIT_LOCK_TIMEOUT_MICROSECONDS = 25000;
    private const CIRCUIT_LOCK_INITIAL_SLEEP_MICROSECONDS = 250;
    private const CIRCUIT_LOCK_MAX_SLEEP_MICROSECONDS = 2000;

    private string $directory;

    /** @var callable():int */
    private $clock;

    /** @var callable(int):void */
    private $sleeper;

    /** @var array<string, array{0:resource,1:resource}> */
    private array $leases = [];

    /**
     * @param null|callable():int $clock
     * @param null|callable(int):void $sleeper
     */
    public function __construct(
        ?string $directory = null,
        ?callable $clock = null,
        ?callable $sleeper = null
    ) {
        $base = $directory;
        if ($base === null || trim($base) === '') {
            $glpiLockDirectory = defined('GLPI_LOCK_DIR')
                ? trim((string) constant('GLPI_LOCK_DIR'))
                : '';
            $base = $glpiLockDirectory !== ''
                && is_dir($glpiLockDirectory)
                && is_writable($glpiLockDirectory)
                    ? $glpiLockDirectory
                    : sys_get_temp_dir();
            $base = rtrim($base, '/\\')
                . DIRECTORY_SEPARATOR
                . 'glpiacessivel-capacity-'
                . substr(hash('sha256', __DIR__), 0, 16);
        }
        $this->directory = rtrim($base, '/\\');
        $this->clock = $clock ?? static fn(): int => time();
        $this->sleeper = $sleeper ?? static function (int $microseconds): void {
            usleep($microseconds);
        };
    }

    public function name(): string
    {
        return 'filesystem';
    }

    public function isAvailable(): bool
    {
        if (is_dir($this->directory)) {
            return is_writable($this->directory);
        }

        return @mkdir($this->directory, 0700, true)
            || (is_dir($this->directory) && is_writable($this->directory));
    }

    public function acquire(
        string $bucket,
        string $contextKey,
        int $maxConcurrent,
        int $leaseSeconds
    ): array {
        unset($leaseSeconds);
        if (!$this->isAvailable()) {
            return ['lease_id' => '', 'reason' => 'capacity_backend_unavailable'];
        }

        $contextHandle = $this->lock($this->path($bucket, 'context-' . hash('sha256', $contextKey)));
        if (!is_resource($contextHandle)) {
            return ['lease_id' => '', 'reason' => 'user_context_in_flight'];
        }

        $maxConcurrent = min(10, max(1, $maxConcurrent));
        for ($slot = 1; $slot <= $maxConcurrent; $slot++) {
            $slotHandle = $this->lock($this->path($bucket, 'slot-' . $slot));
            if (!is_resource($slotHandle)) {
                continue;
            }

            $leaseId = bin2hex(random_bytes(24));
            $this->leases[$leaseId] = [$contextHandle, $slotHandle];
            return ['lease_id' => $leaseId, 'reason' => 'admitted'];
        }

        $this->unlock($contextHandle);
        return ['lease_id' => '', 'reason' => 'capacity_limit_reached'];
    }

    public function release(string $bucket, string $leaseId): bool
    {
        unset($bucket);
        $handles = $this->leases[$leaseId] ?? null;
        if (!is_array($handles)) {
            return false;
        }
        unset($this->leases[$leaseId]);

        $contextReleased = $this->unlock($handles[0]);
        $slotReleased = $this->unlock($handles[1]);
        return $contextReleased && $slotReleased;
    }

    public function admitCircuit(string $bucket, int $openSeconds, int $leaseSeconds): array
    {
        $result = $this->mutateCircuit($bucket, function (array $state) use ($leaseSeconds): array {
            $now = (int) ($this->clock)();
            $openUntil = max(0, (int) ($state['open_until'] ?? 0));
            if ($openUntil > $now) {
                return [$state, $this->circuitDenied('circuit_open', $openUntil - $now, 'open')];
            }
            if ($openUntil <= 0) {
                return [$state, $this->circuitAllowed('', 'closed')];
            }

            $probeExpiresAt = max(0, (int) ($state['probe_expires_at'] ?? 0));
            if ((string) ($state['probe_id'] ?? '') !== '' && $probeExpiresAt > $now) {
                return [$state, $this->circuitDenied('circuit_half_open', 1, 'half_open')];
            }

            $probeId = bin2hex(random_bytes(16));
            $state['probe_id'] = $probeId;
            $state['probe_expires_at'] = $now + min(30, max(5, $leaseSeconds));
            return [$state, $this->circuitAllowed($probeId, 'half_open')];
        });

        return is_array($result)
            ? $result
            : $this->circuitDenied('capacity_backend_error', 1, 'unavailable');
    }

    public function recordCircuitSuccess(string $bucket, string $probeId): bool
    {
        $result = $this->mutateCircuit($bucket, static function (array $state) use ($probeId): array {
            $activeProbe = (string) ($state['probe_id'] ?? '');
            if ($probeId !== '' && !hash_equals($activeProbe, $probeId)) {
                return [$state, false];
            }
            $state['failures'] = 0;
            if ($probeId !== '') {
                $state['open_until'] = 0;
                $state['probe_id'] = '';
                $state['probe_expires_at'] = 0;
            }
            return [$state, true];
        });

        return $result === true;
    }

    public function recordCircuitFailure(
        string $bucket,
        string $probeId,
        int $failureThreshold,
        int $openSeconds
    ): bool {
        $result = $this->mutateCircuit(
            $bucket,
            function (array $state) use ($probeId, $failureThreshold, $openSeconds): array {
                $now = (int) ($this->clock)();
                $activeProbe = (string) ($state['probe_id'] ?? '');
                if ($probeId !== '') {
                    if (!hash_equals($activeProbe, $probeId)) {
                        return [$state, false];
                    }
                    $state = $this->openedState($now, $openSeconds);
                    return [$state, true];
                }

                $failures = max(0, (int) ($state['failures'] ?? 0)) + 1;
                $state['failures'] = $failures;
                if ($failures >= max(1, $failureThreshold)) {
                    $state = $this->openedState($now, $openSeconds);
                }
                return [$state, true];
            }
        );

        return $result === true;
    }

    public function cancelCircuitProbe(string $bucket, string $probeId): bool
    {
        if ($probeId === '') {
            return true;
        }

        $result = $this->mutateCircuit($bucket, static function (array $state) use ($probeId): array {
            if (!hash_equals((string) ($state['probe_id'] ?? ''), $probeId)) {
                return [$state, false];
            }
            $state['probe_id'] = '';
            $state['probe_expires_at'] = 0;
            return [$state, true];
        });

        return $result === true;
    }

    /** @return resource|false */
    private function lock(string $path)
    {
        $handle = fopen($path, 'c+b');
        if (!is_resource($handle)) {
            return false;
        }
        if (!flock($handle, LOCK_EX | LOCK_NB)) {
            fclose($handle);
            return false;
        }

        return $handle;
    }

    /** @param resource $handle */
    private function unlock($handle): bool
    {
        $unlocked = flock($handle, LOCK_UN);
        return fclose($handle) && $unlocked;
    }

    private function path(string $bucket, string $suffix): string
    {
        return $this->directory
            . DIRECTORY_SEPARATOR
            . hash('sha256', $bucket)
            . '-'
            . $suffix
            . '.lock';
    }

    /**
     * @param callable(array<string,mixed>):array{0:array<string,mixed>,1:mixed} $mutation
     */
    private function mutateCircuit(string $bucket, callable $mutation): mixed
    {
        if (!$this->isAvailable()) {
            return false;
        }

        $handle = fopen($this->path($bucket, 'circuit'), 'c+b');
        if (!is_resource($handle)) {
            return false;
        }
        $locked = false;
        try {
            if (!$this->acquireCircuitLock($handle)) {
                return false;
            }
            $locked = true;
            rewind($handle);
            $raw = stream_get_contents($handle, 4096);
            $state = is_string($raw) && $raw !== '' ? json_decode($raw, true) : [];
            if (!is_array($state)) {
                return false;
            }
            [$state, $result] = $mutation($state);
            $encoded = json_encode($state, JSON_UNESCAPED_SLASHES);
            if (!is_string($encoded)) {
                return false;
            }
            rewind($handle);
            $written = ftruncate($handle, 0) ? fwrite($handle, $encoded) : false;
            if ($written !== strlen($encoded) || !fflush($handle)) {
                return false;
            }
            return $result;
        } finally {
            if ($locked) {
                flock($handle, LOCK_UN);
            }
            fclose($handle);
        }
    }

    /** @param resource $handle */
    private function acquireCircuitLock($handle): bool
    {
        $deadline = hrtime(true) + (self::CIRCUIT_LOCK_TIMEOUT_MICROSECONDS * 1000);
        $sleepMicroseconds = self::CIRCUIT_LOCK_INITIAL_SLEEP_MICROSECONDS;
        do {
            if (flock($handle, LOCK_EX | LOCK_NB)) {
                return true;
            }
            $remainingNanoseconds = $deadline - hrtime(true);
            if ($remainingNanoseconds <= 0) {
                return false;
            }
            $remainingMicroseconds = max(1, intdiv($remainingNanoseconds, 1000));
            ($this->sleeper)(min($sleepMicroseconds, $remainingMicroseconds));
            $sleepMicroseconds = min(
                self::CIRCUIT_LOCK_MAX_SLEEP_MICROSECONDS,
                $sleepMicroseconds * 2
            );
        } while (true);
    }

    /** @return array<string,int|string> */
    private function openedState(int $now, int $openSeconds): array
    {
        return [
            'failures' => 0,
            'open_until' => $now + max(1, $openSeconds),
            'probe_id' => '',
            'probe_expires_at' => 0,
        ];
    }

    /** @return array{allowed:true,retry_after:0,probe_id:string,state:string,reason:string} */
    private function circuitAllowed(string $probeId, string $state): array
    {
        return [
            'allowed' => true,
            'retry_after' => 0,
            'probe_id' => $probeId,
            'state' => $state,
            'reason' => 'admitted',
        ];
    }

    /** @return array{allowed:false,retry_after:int,probe_id:string,state:string,reason:string} */
    private function circuitDenied(string $reason, int $retryAfter, string $state): array
    {
        return [
            'allowed' => false,
            'retry_after' => max(1, $retryAfter),
            'probe_id' => '',
            'state' => $state,
            'reason' => $reason,
        ];
    }
}
