<?php

declare(strict_types=1);

namespace GlpiPlugin\Glpiacessivel\Infrastructure\Search;

final class BoundedTicketSearchCapability
{
    private function __construct(
        private bool $available,
        private string $adapter,
        private string $reason
    ) {
    }

    public static function available(string $adapter): self
    {
        return new self(true, $adapter, '');
    }

    public static function unavailable(string $reason, string $adapter = ''): self
    {
        return new self(false, $adapter, $reason);
    }

    public function availableInRuntime(): bool
    {
        return $this->available;
    }

    public function adapter(): string
    {
        return $this->adapter;
    }

    public function reason(): string
    {
        return $this->reason;
    }
}
