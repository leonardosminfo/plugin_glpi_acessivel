<?php

declare(strict_types=1);

namespace GlpiPlugin\Glpiacessivel\Infrastructure\Search;

/**
 * Short-lived, session-bound cursor. It is a continuation marker, never an
 * authorization grant.
 */
final class GlpiResourceSelectorCursor
{
    private const SESSION_KEY = 'glpiacessivel_resource_selector_cursor_key';
    private const MAX_PAGE = 100;

    /** @var \Closure():int */
    private \Closure $clock;

    /** @var null|\Closure():string */
    private ?\Closure $secretProvider;

    public function __construct(?callable $clock = null, ?callable $secretProvider = null)
    {
        $this->clock = $clock === null
            ? static fn(): int => time()
            : \Closure::fromCallable($clock);
        $this->secretProvider = $secretProvider === null
            ? null
            : \Closure::fromCallable($secretProvider);
    }

    /** @param array<string,mixed> $binding */
    public function issue(int $nextPage, array $binding, int $ttlSeconds = 300): string
    {
        if ($nextPage < 2 || $nextPage > self::MAX_PAGE || $ttlSeconds < 30 || $ttlSeconds > 900) {
            throw new \InvalidArgumentException('resource_selector_cursor_invalid');
        }
        $payload = [
            'v' => 1,
            'page' => $nextPage,
            'exp' => ($this->clock)() + $ttlSeconds,
            'binding' => $this->bindingHash($binding),
        ];
        $json = json_encode($payload, JSON_UNESCAPED_SLASHES);
        if (!is_string($json)) {
            throw new \RuntimeException('resource_selector_cursor_unavailable');
        }
        $encoded = $this->base64UrlEncode($json);
        $signature = hash_hmac('sha256', $encoded, $this->secret(), true);

        return $encoded . '.' . $this->base64UrlEncode($signature);
    }

    /** @param array<string,mixed> $binding */
    public function resolve(string $cursor, array $binding): int
    {
        if ($cursor === '' || strlen($cursor) > 1200 || substr_count($cursor, '.') !== 1) {
            throw new \InvalidArgumentException('resource_selector_cursor_invalid');
        }
        [$encoded, $encodedSignature] = explode('.', $cursor, 2);
        $signature = $this->base64UrlDecode($encodedSignature);
        $expected = hash_hmac('sha256', $encoded, $this->secret(), true);
        if ($signature === null || !hash_equals($expected, $signature)) {
            throw new \InvalidArgumentException('resource_selector_cursor_invalid');
        }
        $json = $this->base64UrlDecode($encoded);
        $payload = $json === null ? null : json_decode($json, true);
        if (
            !is_array($payload)
            || ($payload['v'] ?? null) !== 1
            || !is_int($payload['page'] ?? null)
            || !is_int($payload['exp'] ?? null)
            || !is_string($payload['binding'] ?? null)
            || $payload['page'] < 2
            || $payload['page'] > self::MAX_PAGE
            || $payload['exp'] < ($this->clock)()
            || !hash_equals($this->bindingHash($binding), $payload['binding'])
        ) {
            throw new \InvalidArgumentException('resource_selector_cursor_invalid');
        }

        return $payload['page'];
    }

    /** @param array<string,mixed> $binding */
    private function bindingHash(array $binding): string
    {
        ksort($binding);
        $json = json_encode($binding, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
        if (!is_string($json)) {
            throw new \InvalidArgumentException('resource_selector_cursor_invalid');
        }

        return hash_hmac('sha256', $json, $this->secret());
    }

    private function secret(): string
    {
        if ($this->secretProvider !== null) {
            $secret = ($this->secretProvider)();
            if (strlen($secret) < 32) {
                throw new \RuntimeException('resource_selector_cursor_unavailable');
            }
            return $secret;
        }
        $secret = $_SESSION[self::SESSION_KEY] ?? null;
        if (!is_string($secret) || strlen($secret) < 32) {
            try {
                $secret = random_bytes(32);
            } catch (\Throwable $e) {
                throw new \RuntimeException('resource_selector_cursor_unavailable', 0, $e);
            }
            $_SESSION[self::SESSION_KEY] = $secret;
        }

        return $secret;
    }

    private function base64UrlEncode(string $value): string
    {
        return rtrim(strtr(base64_encode($value), '+/', '-_'), '=');
    }

    private function base64UrlDecode(string $value): ?string
    {
        if ($value === '' || preg_match('/\A[A-Za-z0-9_-]+\z/D', $value) !== 1) {
            return null;
        }
        $padding = (4 - strlen($value) % 4) % 4;
        $decoded = base64_decode(strtr($value . str_repeat('=', $padding), '-_', '+/'), true);
        return is_string($decoded) ? $decoded : null;
    }
}
