<?php

declare(strict_types=1);

namespace GlpiPlugin\Glpiacessivel\Infrastructure\Search;

/**
 * Admission control for expensive ticket list searches.
 *
 * The external backend is intentionally an injected contract only. Network
 * clients and credentials must be configured by the deployment, never read
 * implicitly or persisted by this class.
 */
final class TicketListCapacityGuard
{
    public const BACKEND_APCU = 'apcu';
    public const BACKEND_EXTERNAL = 'external';
    public const BACKENDS = [self::BACKEND_APCU, self::BACKEND_EXTERNAL];

    private const BUCKET = 'ticket-list-search';

    public const CIRCUIT_FAILURE_THRESHOLD = 5;
    public const CIRCUIT_OPEN_SECONDS = 30;

    private int $maxConcurrent;
    private int $leaseSeconds;
    private int $retryAfterSeconds;
    private string $backendName;
    private ?TicketListCapacityBackend $backend;

    /** @var array<string,string> lease ID to half-open probe ID */
    private array $activeLeases = [];
    private bool $lastCircuitOutcomeRecorded = true;

    public function __construct(
        int $maxConcurrent = 2,
        int $leaseSeconds = 8,
        int $retryAfterSeconds = 5,
        string $backendName = self::BACKEND_APCU,
        ?TicketListCapacityBackend $externalBackend = null
    ) {
        $this->maxConcurrent = min(10, max(1, $maxConcurrent));
        $this->leaseSeconds = min(
            30,
            max(MySqlMariaDbQueryBudget::MINIMUM_CAPACITY_LEASE_SECONDS, $leaseSeconds)
        );
        $this->retryAfterSeconds = min(60, max(1, $retryAfterSeconds));
        $this->backendName = in_array($backendName, self::BACKENDS, true)
            ? $backendName
            : 'invalid';
        $this->backend = match ($this->backendName) {
            self::BACKEND_APCU => new LocalTicketListCapacityBackend(),
            self::BACKEND_EXTERNAL => $externalBackend,
            default => null,
        };
    }

    /**
     * @return array{
     *     allowed:bool,
     *     retry_after:int,
     *     lease_id:string,
     *     backend:string,
     *     reason:string,
     *     circuit_state:string
     * }
     */
    public function acquire(?string $contextRevision = null): array
    {
        if ($this->backend === null || !$this->backend->isAvailable()) {
            return $this->denied('capacity_backend_unavailable');
        }

        $probeId = '';
        try {
            $circuit = $this->backend->admitCircuit(
                self::BUCKET,
                self::CIRCUIT_OPEN_SECONDS,
                $this->leaseSeconds
            );
            if (!($circuit['allowed'] ?? false)) {
                return $this->denied(
                    is_string($circuit['reason'] ?? null)
                        ? $circuit['reason']
                        : 'capacity_backend_error',
                    max(1, (int) ($circuit['retry_after'] ?? $this->retryAfterSeconds)),
                    is_string($circuit['state'] ?? null) ? $circuit['state'] : 'unavailable'
                );
            }

            $probeId = is_string($circuit['probe_id'] ?? null)
                ? $circuit['probe_id']
                : '';
            $lease = $this->backend->acquire(
                self::BUCKET,
                $this->contextKey($contextRevision),
                $this->maxConcurrent,
                $this->leaseSeconds
            );
        } catch (\Throwable $e) {
            if ($probeId !== '') {
                try {
                    $this->backend->recordCircuitFailure(
                        self::BUCKET,
                        $probeId,
                        self::CIRCUIT_FAILURE_THRESHOLD,
                        self::CIRCUIT_OPEN_SECONDS
                    );
                } catch (\Throwable $ignored) {
                    // The original backend failure remains the admission reason.
                }
            }
            return $this->denied('capacity_backend_error');
        }

        $leaseId = is_string($lease['lease_id'] ?? null) ? $lease['lease_id'] : '';
        if ($leaseId === '') {
            if ($probeId !== '') {
                try {
                    $this->backend->cancelCircuitProbe(self::BUCKET, $probeId);
                } catch (\Throwable $e) {
                    // Admission remains denied even if probe cleanup fails.
                }
            }
            $reason = is_string($lease['reason'] ?? null)
                ? $lease['reason']
                : 'capacity_limit_reached';
            return $this->denied(
                $reason,
                $this->retryAfterSeconds,
                is_string($circuit['state'] ?? null) ? $circuit['state'] : 'closed'
            );
        }

        $this->activeLeases[$leaseId] = $probeId;

        return [
            'allowed' => true,
            'retry_after' => 0,
            'lease_id' => $leaseId,
            'backend' => $this->backend->name(),
            'reason' => 'admitted',
            'circuit_state' => is_string($circuit['state'] ?? null)
                ? $circuit['state']
                : 'closed',
        ];
    }

    /**
     * Releases a lease and records the Search outcome for the circuit breaker.
     *
     * Pass true only after a completed Search backend response and false for a
     * Search failure. A null outcome does not affect a closed circuit, but it
     * reopens a half-open probe because an unknown probe result must fail safe.
     */
    public function release(string $leaseId, ?bool $successful = null): bool
    {
        $this->lastCircuitOutcomeRecorded = false;
        if ($leaseId === '' || $this->backend === null || !$this->backend->isAvailable()) {
            return false;
        }

        $probeId = $this->activeLeases[$leaseId] ?? '';
        unset($this->activeLeases[$leaseId]);

        $circuitRecorded = true;
        try {
            if ($successful === true) {
                $circuitRecorded = $this->backend->recordCircuitSuccess(self::BUCKET, $probeId);
            } elseif ($successful === false || $probeId !== '') {
                $circuitRecorded = $this->backend->recordCircuitFailure(
                    self::BUCKET,
                    $probeId,
                    self::CIRCUIT_FAILURE_THRESHOLD,
                    self::CIRCUIT_OPEN_SECONDS
                );
            }
        } catch (\Throwable $e) {
            $circuitRecorded = false;
        }
        $this->lastCircuitOutcomeRecorded = $circuitRecorded;

        // A circuit backend failure must never prevent the semaphore lease
        // from being released. Otherwise one observability/control-plane
        // error consumes capacity until the TTL expires (or the PHP worker
        // terminates for the filesystem backend), amplifying saturation.
        try {
            $released = $this->backend->release(self::BUCKET, $leaseId);
        } catch (\Throwable $e) {
            $released = false;
        }

        // The return value is exclusively the lease-release outcome. Circuit
        // recording is exposed separately so telemetry cannot report an
        // actually released slot as leaked when only the control plane failed.
        return $released;
    }

    public function lastCircuitOutcomeRecorded(): bool
    {
        return $this->lastCircuitOutcomeRecorded;
    }

    /**
     * @return array{
     *     allowed:false,
     *     retry_after:int,
     *     lease_id:string,
     *     backend:string,
     *     reason:string,
     *     circuit_state:string
     * }
     */
    private function denied(
        string $reason,
        ?int $retryAfter = null,
        string $circuitState = 'unavailable'
    ): array {
        return [
            'allowed' => false,
            'retry_after' => min(60, max(1, $retryAfter ?? $this->retryAfterSeconds)),
            'lease_id' => '',
            'backend' => $this->backend?->name() ?? $this->backendName,
            'reason' => $reason,
            'circuit_state' => $circuitState,
        ];
    }

    private function contextKey(?string $contextRevision): string
    {
        $profile = $_SESSION['glpiactiveprofile'] ?? null;
        if (is_array($profile)) {
            $profile = $profile['id'] ?? null;
        }

        $context = [
            'user_id' => max(0, (int) ($_SESSION['glpiID'] ?? 0)),
            'profile_id' => max(0, (int) $profile),
            'entity_id' => max(0, (int) ($_SESSION['glpiactive_entity'] ?? 0)),
            'recursive' => !empty($_SESSION['glpiactive_entity_recursive']),
            'entities' => $this->normalizeIds($_SESSION['glpiactiveentities'] ?? []),
            'groups' => $this->normalizeIds($_SESSION['glpigroups'] ?? []),
            'revision' => is_string($contextRevision) ? trim($contextRevision) : '',
        ];

        $encoded = json_encode($context, JSON_UNESCAPED_SLASHES);
        return hash('sha256', is_string($encoded) ? $encoded : 'invalid-context');
    }

    /** @return int[] */
    private function normalizeIds(mixed $raw): array
    {
        if (!is_array($raw)) {
            return [];
        }

        $ids = [];
        foreach ($raw as $key => $value) {
            if (is_int($value) || (is_string($value) && ctype_digit($value))) {
                $id = (int) $value;
            } elseif ((is_int($key) || ctype_digit((string) $key)) && is_array($value)) {
                $id = (int) $key;
            } else {
                continue;
            }
            if ($id > 0) {
                $ids[$id] = $id;
            }
        }

        ksort($ids, SORT_NUMERIC);
        return array_values($ids);
    }
}
