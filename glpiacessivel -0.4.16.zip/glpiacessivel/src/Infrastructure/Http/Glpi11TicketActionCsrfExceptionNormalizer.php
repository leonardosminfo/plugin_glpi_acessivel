<?php

// SPDX-License-Identifier: GPL-2.0-or-later

declare(strict_types=1);

namespace GlpiPlugin\Glpiacessivel\Infrastructure\Http;

use GlpiPlugin\Glpiacessivel\Support\Container;
use GlpiPlugin\Glpiacessivel\Support\Url;

/**
 * Gives the accessible solution workflow a contextual, non-repeating recovery
 * when GLPI 11 consumes or rejects the CSRF token before the legacy controller.
 *
 * This listener never validates a token, calls the controller or retries the
 * mutation. Requests outside the exact HTML solution contract keep GLPI's
 * native 403 response.
 */
final class Glpi11TicketActionCsrfExceptionNormalizer
{
    private const ENDPOINT_SUFFIX = '/plugins/glpiacessivel/front/ticket.action.php';
    /** @var string[] */
    private const TARGET_ACTIONS = ['solution', 'solution_approve', 'solution_refuse'];

    /** @var array<int,true> */
    private static array $registeredDispatchers = [];

    public static function register(): void
    {
        if (
            !defined('GLPI_VERSION')
            || version_compare((string) constant('GLPI_VERSION'), '11.0.0', '<')
            || !class_exists('\Symfony\Component\HttpKernel\KernelEvents')
        ) {
            return;
        }

        $kernel = $GLOBALS['kernel'] ?? null;
        if (!is_object($kernel) || !method_exists($kernel, 'getContainer')) {
            return;
        }

        try {
            $container = $kernel->getContainer();
            if (!is_object($container) || !method_exists($container, 'get')) {
                return;
            }
            $dispatcher = $container->get('event_dispatcher');
            if (!is_object($dispatcher) || !method_exists($dispatcher, 'addListener')) {
                return;
            }
            $dispatcherId = spl_object_id($dispatcher);
            if (isset(self::$registeredDispatchers[$dispatcherId])) {
                return;
            }
            $dispatcher->addListener(
                \Symfony\Component\HttpKernel\KernelEvents::EXCEPTION,
                [self::class, 'onKernelException'],
                2048
            );
            self::$registeredDispatchers[$dispatcherId] = true;
        } catch (\Throwable) {
            // Compatibility enhancement only: never interrupt GLPI boot.
        }
    }

    public static function onKernelException(object $event): void
    {
        if (
            !method_exists($event, 'isMainRequest')
            || !$event->isMainRequest()
            || !method_exists($event, 'getRequest')
            || !method_exists($event, 'getThrowable')
            || !method_exists($event, 'setResponse')
        ) {
            return;
        }

        $request = $event->getRequest();
        $throwable = $event->getThrowable();
        $accessDeniedClass = 'Glpi\Exception\Http\AccessDeniedHttpException';
        if (
            !is_object($request)
            || !class_exists($accessDeniedClass)
            || !is_object($throwable)
            || get_class($throwable) !== $accessDeniedClass
            || !self::isNativeCsrfRejection($throwable)
            || !class_exists('\Symfony\Component\HttpFoundation\RedirectResponse')
        ) {
            return;
        }

        $ticketId = self::targetTicketId($request);
        if ($ticketId === null || !isset($_SESSION) || !is_array($_SESSION)) {
            return;
        }

        $message = function_exists('__')
            ? __('Esta nova tentativa não foi executada porque o token de segurança expirou ou já foi usado. O chamado foi recarregado; confira o estado atual antes de tentar novamente.', 'glpiacessivel')
            : 'Esta nova tentativa não foi executada porque o token de segurança expirou ou já foi usado. O chamado foi recarregado; confira o estado atual antes de tentar novamente.';
        $hadPreviousFlash = array_key_exists('glpiacessivel_flash', $_SESSION);
        $previousFlash = $_SESSION['glpiacessivel_flash'] ?? null;

        try {
            $response = new \Symfony\Component\HttpFoundation\RedirectResponse(
                Url::plugin('front/tickets.php?id=' . $ticketId),
                303,
                [
                    'Cache-Control' => 'private, no-store',
                    'Pragma' => 'no-cache',
                    'X-Content-Type-Options' => 'nosniff',
                ]
            );
            $_SESSION['glpiacessivel_flash'] = [
                'type' => 'error',
                'message' => $message,
            ];
            $event->setResponse($response);
        } catch (\Throwable) {
            if ($hadPreviousFlash) {
                $_SESSION['glpiacessivel_flash'] = $previousFlash;
            } else {
                unset($_SESSION['glpiacessivel_flash']);
            }
            return;
        }

        self::audit($ticketId, self::requestParameter($request, 'action'));
    }

    private static function targetTicketId(object $request): ?int
    {
        if (
            !method_exists($request, 'getPathInfo')
            || !method_exists($request, 'getRealMethod')
            || !method_exists($request, 'isXmlHttpRequest')
        ) {
            return null;
        }

        $path = str_replace('\\', '/', (string) $request->getPathInfo());
        if (
            strtoupper((string) $request->getRealMethod()) !== 'POST'
            || $request->isXmlHttpRequest()
            || $path !== self::ENDPOINT_SUFFIX
            || !self::hasHtmlMediaType(self::requestHeader($request, 'Accept'))
            || !self::hasFormContentType(self::requestHeader($request, 'Content-Type'))
            || !in_array(self::requestParameter($request, 'action'), self::TARGET_ACTIONS, true)
        ) {
            return null;
        }

        $rawTicketId = self::requestParameter($request, 'ticket_id');
        if (!is_int($rawTicketId) && !is_string($rawTicketId)) {
            return null;
        }
        $ticketId = filter_var($rawTicketId, FILTER_VALIDATE_INT, [
            'options' => ['min_range' => 1, 'max_range' => PHP_INT_MAX],
        ]);

        return is_int($ticketId) ? $ticketId : null;
    }

    private static function hasHtmlMediaType(string $accept): bool
    {
        foreach (explode(',', strtolower($accept)) as $range) {
            $mediaType = trim(explode(';', $range, 2)[0]);
            if (in_array($mediaType, ['text/html', 'application/xhtml+xml'], true)) {
                return true;
            }
        }

        return false;
    }

    private static function hasFormContentType(string $contentType): bool
    {
        $mediaType = trim(explode(';', strtolower($contentType), 2)[0]);
        return in_array($mediaType, ['application/x-www-form-urlencoded', 'multipart/form-data'], true);
    }

    private static function requestHeader(object $request, string $name): string
    {
        if (!isset($request->headers) || !is_object($request->headers) || !method_exists($request->headers, 'get')) {
            return '';
        }

        return trim((string) ($request->headers->get($name) ?? ''));
    }

    private static function requestParameter(object $request, string $name): mixed
    {
        if (!isset($request->request) || !is_object($request->request) || !method_exists($request->request, 'get')) {
            return null;
        }

        $value = $request->request->get($name);
        return is_scalar($value) ? $value : null;
    }

    private static function isNativeCsrfRejection(object $throwable): bool
    {
        if (!method_exists($throwable, 'getTrace')) {
            return false;
        }

        try {
            foreach ((array) $throwable->getTrace() as $frame) {
                if (
                    is_array($frame)
                    && ($frame['class'] ?? '') === 'Glpi\Kernel\Listener\ControllerListener\CheckCsrfListener'
                    && ($frame['function'] ?? '') === 'onKernelController'
                ) {
                    return true;
                }
            }
        } catch (\Throwable) {
            // Unknown trace shape: preserve the native response.
        }

        return false;
    }

    private static function audit(int $ticketId, string $action): void
    {
        global $DB;

        if (!is_object($DB) || !method_exists($DB, 'insert')) {
            return;
        }

        try {
            Container::get()->auditLogger()->log('security.csrf.failed', [
                'endpoint' => 'ticket.action',
                'action_name' => $action,
                'recovery' => 'html_see_other',
            ], $ticketId);
        } catch (\Throwable) {
            // Recovery must not fail because optional audit persistence failed.
        }
    }
}
