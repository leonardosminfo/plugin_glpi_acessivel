<?php

// SPDX-License-Identifier: GPL-2.0-or-later

declare(strict_types=1);

namespace GlpiPlugin\Glpiacessivel\Infrastructure\Http;

/**
 * Keeps the asynchronous ticket endpoint JSON contract when GLPI 11 rejects
 * an invalid AJAX CSRF token before the legacy plugin controller is invoked.
 */
final class Glpi11TicketResultCsrfExceptionNormalizer
{
    private const ENDPOINT_SUFFIX = '/plugins/glpiacessivel/front/ticket.results.php';

    /** @var array<int,true> */
    private static array $registeredDispatchers = [];

    public static function register(): void
    {
        if (
            !defined('GLPI_VERSION')
            || version_compare((string) constant('GLPI_VERSION'), '11.0.0', '<')
            || !class_exists('\Symfony\Component\HttpKernel\KernelEvents')
        ) {
            return;
        }

        $kernel = $GLOBALS['kernel'] ?? null;
        if (!is_object($kernel) || !method_exists($kernel, 'getContainer')) {
            return;
        }

        try {
            $container = $kernel->getContainer();
            if (!is_object($container) || !method_exists($container, 'get')) {
                return;
            }
            $dispatcher = $container->get('event_dispatcher');
            if (!is_object($dispatcher) || !method_exists($dispatcher, 'addListener')) {
                return;
            }
            $dispatcherId = spl_object_id($dispatcher);
            if (isset(self::$registeredDispatchers[$dispatcherId])) {
                return;
            }
            $dispatcher->addListener(
                \Symfony\Component\HttpKernel\KernelEvents::EXCEPTION,
                [self::class, 'onKernelException'],
                2048
            );
            self::$registeredDispatchers[$dispatcherId] = true;
        } catch (\Throwable) {
            // Compatibility enhancement only: never interrupt GLPI boot.
        }
    }

    public static function onKernelException(object $event): void
    {
        if (
            !method_exists($event, 'isMainRequest')
            || !$event->isMainRequest()
            || !method_exists($event, 'getRequest')
            || !method_exists($event, 'getThrowable')
            || !method_exists($event, 'setResponse')
        ) {
            return;
        }

        $request = $event->getRequest();
        $throwable = $event->getThrowable();
        $accessDeniedClass = 'Glpi\Exception\Http\AccessDeniedHttpException';
        if (
            !is_object($request)
            || !class_exists($accessDeniedClass)
            || !is_object($throwable)
            || get_class($throwable) !== $accessDeniedClass
            || !self::isNativeCsrfRejection($throwable)
            || !self::isTargetRequest($request)
            || !class_exists('\Symfony\Component\HttpFoundation\Response')
        ) {
            return;
        }

        $body = json_encode([
            'contract' => 'ticket_results',
            'version' => 2,
            'success' => false,
            'error' => 'invalid_security_token',
        ], JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
        if (!is_string($body)) {
            return;
        }

        $event->setResponse(new \Symfony\Component\HttpFoundation\Response(
            $body,
            403,
            [
                'Content-Type' => 'application/json; charset=UTF-8',
                'Cache-Control' => 'private, no-store',
                'Pragma' => 'no-cache',
                'X-Content-Type-Options' => 'nosniff',
            ]
        ));
    }

    private static function isTargetRequest(object $request): bool
    {
        if (
            !method_exists($request, 'getPathInfo')
            || !method_exists($request, 'getRealMethod')
            || !method_exists($request, 'isXmlHttpRequest')
        ) {
            return false;
        }

        $path = str_replace('\\', '/', (string) $request->getPathInfo());
        $accept = self::requestHeader($request, 'Accept');
        $contentType = self::requestHeader($request, 'Content-Type');
        return strtoupper((string) $request->getRealMethod()) === 'POST'
            && $request->isXmlHttpRequest()
            && $path === self::ENDPOINT_SUFFIX
            && self::hasJsonMediaType($accept)
            && self::hasJsonContentType($contentType);
    }

    private static function hasJsonMediaType(string $accept): bool
    {
        foreach (explode(',', strtolower($accept)) as $range) {
            $mediaType = trim(explode(';', $range, 2)[0]);
            if ($mediaType === 'application/json') {
                return true;
            }
        }

        return false;
    }

    private static function hasJsonContentType(string $contentType): bool
    {
        return trim(explode(';', strtolower($contentType), 2)[0]) === 'application/json';
    }

    private static function requestHeader(object $request, string $name): string
    {
        if (!isset($request->headers) || !is_object($request->headers) || !method_exists($request->headers, 'get')) {
            return '';
        }

        return trim((string) ($request->headers->get($name) ?? ''));
    }

    private static function isNativeCsrfRejection(object $throwable): bool
    {
        if (!method_exists($throwable, 'getTrace')) {
            return false;
        }

        try {
            foreach ((array) $throwable->getTrace() as $frame) {
                if (
                    is_array($frame)
                    && ($frame['class'] ?? '') === 'Glpi\Kernel\Listener\ControllerListener\CheckCsrfListener'
                    && ($frame['function'] ?? '') === 'onKernelController'
                ) {
                    return true;
                }
            }
        } catch (\Throwable) {
            // Unknown trace shape: preserve the native response.
        }

        return false;
    }
}
