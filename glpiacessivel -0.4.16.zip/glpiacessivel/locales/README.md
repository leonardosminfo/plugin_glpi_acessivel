# Locales

Estrutura inicial de traducoes do plugin `glpiacessivel`.

O plugin usa o dominio de traducao `glpiacessivel`, por meio de chamadas GLPI como `__('Texto', 'glpiacessivel')`.

## Padrao adotado

- Textos visiveis, `aria-label`, mensagens de confirmacao e mensagens de retorno devem passar pelo dominio `glpiacessivel`.
- Valores tecnicos persistidos no banco, como `intent`, `status`, nomes de campos e IDs, nao devem ser traduzidos. Traduza apenas o rotulo exibido.
- Frases com variaveis devem usar placeholders completos, por exemplo `sprintf(__('Aprovar sugestao %s: %s', 'glpiacessivel'), $id, $title)`.
- Evite montar frases por concatenacao de partes traduzidas.

## Estado atual

A internacionalizacao ja cobre a fila de sugestoes pendentes, o shell compartilhado e os textos criticos do chatbot/voz. As demais telas administrativas e conteudos raros ainda devem migrar progressivamente textos literais para o dominio `glpiacessivel`.

## Planejamento consolidado

O plano completo de internacionalizacao do plugin esta em docs/plano-internacionalizacao-plugin.md. Ele complementa o plano anterior do chatbot em docs/plano-internacionalizacao-chatbot.md.

## Validacao

Execute `powershell -ExecutionPolicy Bypass -File tools/i18n-audit.ps1` para verificar alinhamento de msgid e traducoes vazias. O script tenta usar `msgfmt --check --check-format` quando GNU gettext esta instalado. Para uma release lancavel, `msgfmt` deve ser obrigatorio no pipeline e os arquivos `.mo` devem ser recompilados por ele.
