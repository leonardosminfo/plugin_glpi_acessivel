# GLPI Acessível 0.4.4-beta

## Objetivo

Esta beta corrige os bloqueios encontrados na homologação da `0.4.3-beta`: inconsistência entre catálogo e autorização de requerentes, falha `Empty IN`, retorno contraditório da atribuição, conteúdo bruto em modelos de tarefa, solução não confirmada, iframe inválido ainda exposto e telemetria insuficiente de saturação.

O mesmo ZIP e SHA-256 é destinado ao GLPI 10/PHP 8.1 e ao GLPI 11/PHP 8.3. A versão permanece pré-release: aprovação automatizada não substitui carga autenticada via proxy nem homologação manual com tecnologias assistivas.

## Alterações funcionais

- Requerentes e atores usam autorização exata por ID, perfil, entidade e finalidade; a pesquisa nativa serve para descoberta e rótulo, não como prova isolada de permissão.
- Conjuntos vazios são aceitos sem gerar `IN ()` ou `NOT IN ()`.
- A atualização dos quatro papéis de atores usa snapshot e releitura e retorna `unchanged`, `verified`, `rejected` ou `uncertain`; resultado incerto nunca é repetido automaticamente.
- Validação dos seletores e confirmação crítica formam um único fluxo, com revalidação anterior a exatamente um `requestSubmit()`.
- `TaskTemplate` e `SolutionTemplate` são renderizados pelo núcleo do GLPI antes da conversão para texto. Marcadores Twig residuais ou falha de renderização fecham o fluxo com segurança.
- A solução omite tipo zero, executa uma única chamada `ITILSolution::add()` e relê linha, vínculo, autor e estado final.
- Falha terminal do formulário incorporado retira o iframe da visão, foco e árvore acessível; a nova tentativa restaura o estado original antes da revalidação.
- O Service Catalog do GLPI 11 recebe um perfil mínimo próprio e fingerprintado. DOM desconhecido permanece em modo nativo completo.
- A lease de capacidade é liberada mesmo quando o registro do circuito falha. Métricas de tempo, memória, backend, circuito e resultado usam campos limitados e sem conteúdo ou PII.

## Qualidade automatizada

- PHPUnit PHP 8.1: 678 testes e 4.126 asserções.
- PHPUnit PHP 8.3: 678 testes e 4.126 asserções.
- Navegador: 47 testes aprovados, incluindo atores, confirmação, lista assíncrona, Formcreator e Service Catalog.
- PHPStan: sem erros.
- PHPCS: 267 arquivos aprovados.
- Internacionalização: 2.388 mensagens, catálogos e espelhos aprovados.

## Condições ainda obrigatórias

Antes de promover ao ambiente produtivo:

1. instalar o mesmo ZIP nos ambientes GLPI 10 e 11 e registrar seu SHA-256;
2. executar as mutações sintéticas de requerente, quatro papéis, tarefa, acompanhamento e solução;
3. executar a carga autenticada descrita em `performance_review_post_glpit_0.4.3-beta_2026-08-28.md`;
4. confirmar se a topologia é de nó único ou cluster; APCu/arquivo não constitui limite global em cluster;
5. validar teclado, 320 CSS px, zoom, alto contraste, NVDA e JAWS nas jornadas críticas;
6. interromper a promoção em qualquer ampliação de ACL, mutação incerta, `504`, OOM, deadlock ou barreira assistiva.

`session_write_close()` não foi inserido sem prova: direitos, Search, hooks e auditoria ainda dependem do contexto da sessão. Fechamento antecipado exige inventário executável e snapshot imutável antes de ser experimentado.

## Rollback

Preservar o pacote anterior e o backup do diretório. As flags de lista assíncrona, seletores remotos e ponte do formulário permitem desativar isoladamente as funções afetadas. Resultado de mutação incerto deve ser conferido no chamado antes de qualquer nova ação.
