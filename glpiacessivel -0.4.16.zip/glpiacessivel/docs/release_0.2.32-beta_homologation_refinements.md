# GLPI Acessível 0.2.32-beta: refinamentos da homologação

## Objetivo

Esta versão reúne correções identificadas durante a homologação real no GLPI 10, sem ampliar permissões nem substituir os contratos nativos do GLPI e do Formcreator.

## Alterações

- o diálogo de escolha de colunas devolve o foco ao seu acionador quando fechado pelo teclado;
- o filtro de status oferece a condição negativa quando o catálogo autorizado do GLPI permite essa operação;
- a apresentação incorporada do Formcreator reduz apenas a casca visual reconhecida, preservando integralmente o formulário, os campos, o CSRF, as mensagens, os anexos e o envio;
- instalações existentes conservam sua preferência: selecione `Interface GLPI reduzida` ou ative a apresentação mínima na configuração para homologar o novo visual; nenhuma migração altera silenciosamente o modo escolhido;
- qualquer divergência de versão, rota, origem ou estrutura conserva a interface completa e o link alternativo;
- textos visíveis e anunciados recebem acentuação e tradução pelo domínio Gettext do plugin;
- ações sobre pesquisas salvas repetem explicitamente a autorização de leitura de chamados antes do processamento;
- testes de regressão cobrem foco, operadores, linguagem, apresentação incorporada e autorização.

## Segurança e compatibilidade

A versão mantém a sessão, o perfil, a entidade, a recursividade e as ACLs do GLPI como fonte de verdade. A apresentação reduzida do Formcreator é apenas cosmética e não altera URL, action, CSRF, campos, anexos, condições, alvos ou submissão. Falhas de reconhecimento preservam a interface completa.

## Homologação obrigatória

- GLPI 10 e GLPI 11 nos perfis Helpdesk, Self-Service, técnico e administrador;
- Formcreator 2.13 no GLPI 10, com apresentação completa e reduzida;
- busca de chamados com `é` e `não é`, resumo aplicado, pesquisa salva e paginação;
- diálogo de colunas com `Tab`, `Shift+Tab`, `Escape` e restauração de foco;
- teclado, NVDA/JAWS, zoom de 200% e 400% e largura de 320 CSS px;
- confirmação de que formulários mantêm campos, validações, anexos, erros e envio nativos.

## Build

```powershell
.\tools\build-release.ps1 -Output .release_0.2.32-beta_homologation_refinements -Profile marketplace -RequireMsgfmt
.\tools\verify-release.ps1 -Package .release_0.2.32-beta_homologation_refinements\glpiacessivel.zip -ExpectedVersion 0.2.32-beta -PublicProfile
```
