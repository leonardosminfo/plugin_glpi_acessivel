# Plano de testes — GLPI Acessível 0.4.15-beta

## Ambientes

Executar o mesmo código em:

- GLPI 10 local em `http://127.0.0.1:8089`;
- GLPI 11 local em `http://127.0.0.1:8080`;
- perfil Helpdesk/Técnico com direitos nativos compatíveis;
- perfil Self-Service/Leitura sem direitos técnicos, para falha fechada.

Usar somente dados fictícios identificados com o prefixo `QA-0415`. Registrar IDs criados e não apagar dados que não pertençam à homologação.

## A. Decisão nativa da solução

| ID | Cenário | Resultado esperado |
|---|---|---|
| SOLDEC-01 | Abrir chamado solucionado com usuário aprovador | Seção “Decisão sobre a solução” visível conforme ACL nativa |
| SOLDEC-02 | Aprovar sem comentário | Comentário permanece opcional; GLPI aceita a solução e fecha o chamado |
| SOLDEC-03 | Recusar sem motivo | Envio bloqueado, erro associado e foco no comentário |
| SOLDEC-04 | Recusar com motivo | Um acompanhamento público é criado; solução fica recusada e chamado reabre no estado escolhido pelo GLPI |
| SOLDEC-05 | Perfil sem `canApprove()` | Controles não aparecem; motivo da indisponibilidade é apresentado |
| SOLDEC-06 | Perfil sem `canAddFollowups()` | Controles não aparecem e a restrição nativa de acompanhamento é explicada |
| SOLDEC-07 | Duplo envio/retry com mesmo identificador | Uma única mutação; segundo pedido é replay confirmado |
| SOLDEC-08 | Duas decisões concorrentes | Uma vence; a outra recebe estado em andamento/conflito sem duplicação |
| SOLDEC-09 | Revisão alterada em outra sessão | Pedido antigo é recusado antes da mutação |
| SOLDEC-10 | Dois anexos com o mesmo nome | Dois documentos distintos precisam estar vinculados para sucesso |
| SOLDEC-11 | Falha nativa de `ITILFollowup::add()` | Rollback confirmado, sem acompanhamento/status parcial e guard liberado |
| SOLDEC-12 | Queda antes da mutação | Guard órfão só é limpo após janela e prova de baseline inalterado |
| SOLDEC-13 | Falha ambígua depois de iniciar a mutação | Sem retry automático; guard permanece até resultado conclusivo |

Em SOLDEC-02 e SOLDEC-04, conferir também no GLPI nativo: acompanhamento, histórico, notificação aplicável, `ITILSolution.status`, `users_id_approval`, `date_approval`, status e datas do chamado.

## B. Regressão dos checklists de 24 e 31 de agosto

| ID | Jornada | Evidência mínima |
|---|---|---|
| LOGIN-01 | Login por teclado | ordem Login/Senha/Entrar e nomes acessíveis |
| NAV-01 | Navegação principal | landmarks, menu e acesso a Chamados sem timeout |
| NAV-02 | Pesquisa | termo, resultado e foco; pesquisa salva preservada |
| CHAM-01 | Fila de chamados | cabeçalhos e células compreensíveis; paginação progressiva |
| CHAM-02 | Filtro por status | botão explícito, seletor preservado, resumo e foco após aplicar |
| CHAM-03 | Abertura delegada | requerente, categoria elegível, título, descrição e obrigatoriedade |
| CHAM-04 | Detalhe/histórico | requerente, data, status e descrição em ordem linear |
| CHAM-05 | Download de anexo | nome, ação por Enter/Espaço e autorização nativa |
| ATEND-01 | Acompanhamento | modelo opcional, conteúdo legível, envio e confirmação |
| ATEND-03 | Solução | tipo, modelo, descrição, registro nativo e estado Solucionado |
| ATEND-04 | Atribuição | técnico/grupo, sete papéis nativos e nenhuma consulta `IN ()` vazia |
| BC-01 | Pesquisa na base | resultados autorizados e navegáveis |
| BC-02 | Leitura de artigo | títulos, listas e links em sequência lógica |

## C. Acessibilidade e clareza

Para as jornadas A e B:

1. operar somente por teclado, inclusive modal, anexos e paginação;
2. executar Axe/WAVE e separar violações confirmadas de revisão manual;
3. validar reflow em 320 CSS px e zoom de 200%;
4. testar alto contraste e tema noturno;
5. verificar nomes, instruções, mensagens, foco após erro e sucesso;
6. repetir SOLDEC-02, SOLDEC-03 e SOLDEC-04 com NVDA em Firefox e Chrome quando disponível.

Critérios: WCAG 2.2 AA, eMAG aplicável e RGAA como método complementar. Ferramentas automáticas não substituem teclado e leitor de tela.

## D. Desempenho e segurança

- lista autenticada via proxy sem `502/504` e sem materialização ilimitada;
- cinco páginas sequenciais sem falso `429`, respeitando a política configurada;
- detalhe de chamado não solucionado não consulta solução nem reconciliação desnecessariamente;
- nenhuma duplicação em retry, concorrência ou perda de resposta;
- nenhum comentário, nome de anexo, token ou conteúdo livre no ledger/auditoria;
- perfis e entidades devem produzir o mesmo escopo permitido pelo GLPI nativo.

## Saída

Registrar por ambiente: versão do GLPI/PHP/plugin, perfil, entidade, ID fictício, resultado, evidência, impacto e pendência manual. Um item só fica “aprovado” quando o estado no plugin e no GLPI nativo coincide.
