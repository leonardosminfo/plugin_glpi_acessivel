# Plano de testes — GLPI Acessível 0.4.14-beta

## Matriz obrigatória

Executar a mesma árvore de código em GLPI 10/PHP 8.1 e GLPI 11/PHP 8.3.

1. Executar a suíte PHPUnit completa e os testes de navegador existentes.
2. Confirmar o registro separado dos normalizadores HTML de `ticket.action.php` e JSON de `ticket.results.php`.
3. Enviar uma solução válida e confirmar exatamente uma solução, um resultado terminal no ledger e o status definido pelo GLPI.
4. Repetir exatamente o mesmo POST e token no GLPI 11.
5. Confirmar `303`, retorno ao mesmo chamado, mensagem contextual com `role=alert`, foco no alerta e nenhuma segunda mutação.
6. Confirmar que token, descrição e anexos não aparecem na URL, mensagem, cabeçalhos ou auditoria.
7. Repetir a submissão inválida com outro endpoint, ação diferente, AJAX, JSON, ID inválido e `AccessDenied` não originado no `CheckCsrfListener`; o `403` nativo deve permanecer.
8. Repetir o endpoint assíncrono com CSRF inválido; o envelope JSON `ticket_results`, o status `403` e os cabeçalhos de segurança devem permanecer.
9. Comparar contagem de soluções, ledger, auditorias terminais e notificações antes/depois do replay.
10. Validar manualmente com teclado e leitor de tela que a mensagem é anunciada uma vez e que o estado atual do chamado pode ser conferido sem novo envio.

## Critérios de aprovação

- nenhuma repetição automática ou duplicidade;
- nenhuma flexibilização de CSRF;
- nenhuma alteração de persistência ou ACL;
- recuperação contextual somente no contrato permitido;
- regressão zero no GLPI 10 e no endpoint JSON do GLPI 11.
