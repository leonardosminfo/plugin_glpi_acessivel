# Guia de Instalação e Operação

## Pré-requisitos
- GLPI 10.x ou 11.x
- PHP >= 8.1
- Permissão de escrita para instalação de plugin

## Instalação
1. Faça backup do banco de dados e da pasta atual do plugin.
2. Baixe `glpiacessivel.zip` na página de releases do projeto.
3. Extraia o pacote em `GLPI/plugins/glpiacessivel`.
4. Acesse `Configurar > Plugins`.
5. Instale e habilite `GLPI Acessível`.

Para desenvolvimento, o pacote pode ser gerado com `tools/build-release.ps1` usando o perfil apropriado.

O nome tecnico da pasta deve ser exatamente `glpiacessivel`, porque o GLPI associa esse nome as funcoes `plugin_init_glpiacessivel()` e aos caminhos publicos do plugin.

Nao publique a pasta de trabalho diretamente: ela contem `.backup/`, testes e artefatos locais que nao devem ir para producao.

## Operação diária
- Entrada acessivel dedicada: `/plugins/glpiacessivel/front/acessivel.php`
- Chamados: `/plugins/glpiacessivel/front/tickets.php`
- Cockpit: `/plugins/glpiacessivel/front/cockpit.php`
- Base de conhecimento: `/plugins/glpiacessivel/front/knowledge.php`
- Chatbot: `/plugins/glpiacessivel/front/chatbot.php`
- Botao no GLPI padrao: o plugin injeta o link "Acessibilidade" nas paginas padrao autenticadas.

## Modos de acessibilidade
- `portal`: concentra a experiência na entrada acessível dedicada.
- `embedded`: disponibiliza recursos do plugin dentro da navegação padrão do GLPI.
- `hybrid`: combina portal dedicado e integração com o GLPI padrão. É o modo inicial de novas instalações.

Atualizações preservam o modo já configurado.

## Governança
- Revisar logs de auditoria periodicamente.
- Revisar logs de revelação de PII.
- Validar perfis GLPI para segregação de acesso.

## Desinstalação
- Menu de plugins do GLPI: desativar e desinstalar.
- Processo remove tabelas do plugin (`SchemaManager::uninstall`).

