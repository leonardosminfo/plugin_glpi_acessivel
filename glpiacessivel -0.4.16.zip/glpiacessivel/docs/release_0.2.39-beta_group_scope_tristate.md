# GLPI Acessível 0.2.39-beta: escopo de grupos em três estados

## Objetivo

Esta versão corrige a distinção entre dois resultados que não podem ser apresentados da mesma forma: o usuário comprovadamente não pertence a grupos no perfil e na entidade atuais, ou o plugin não conseguiu comprovar o contexto oficial de grupos. A regra vale para GLPI 10 e GLPI 11, na lista de chamados e no indicador **Chamados dos grupos responsáveis**.

## Contrato funcional

O contexto oficial `glpigroups` é resolvido em três resultados operacionais:

| Contexto | Lista com `scope=group` | Indicador `group_open` |
| --- | --- | --- |
| grupos válidos resolvidos | consulta somente os grupos atuais autorizados | contagem exata pela Search API |
| conjunto vazio resolvido | lista vazia exata, backend `scope_empty` | zero exato, disponível, backend `scope_empty` |
| contexto ausente, malformado ou com falha nativa de carga | resultado indisponível, sem inferir vazio | resultado indisponível, sem inferir zero |

No conjunto vazio comprovado, a lista explica: “Você não pertence a nenhum grupo no perfil e na entidade atuais. Por isso, não há chamados de grupos responsáveis para exibir.” O mesmo estado deve ser anunciado na renderização inicial e na atualização assíncrona.

## Compatibilidade e segurança

- GLPI 10 fornece os grupos diretos do contexto ativo; GLPI 11 pode incluir grupos expandidos recursivamente. A implementação normaliza identificadores positivos, remove duplicatas e conserva a lista oficial como única autoridade.
- Uma chave oficial vazia é um resultado válido. A chave legada `glpigroups_assign` não pode transformar esse vazio em associação.
- Uma falha registrada de `Session::loadGroups()` prevalece sobre uma chave vazia residual e mantém o resultado indisponível. Sessões normais do core que já contêm `glpigroups` continuam compatíveis mesmo sem o marcador interno da correção.
- Um `group_id` explícito em `scope=group` precisa pertencer ao conjunto oficial atual. Identificador fora desse conjunto falha fechado como vazio exato e não chega à Search API.
- `group_by=group` organiza a apresentação, mas não cria escopo de autorização. `scope=all` e `scope=mine` continuam com seus contratos próprios.
- Perfil, entidade, recursividade, ACL, Search Options e revalidação do contexto permanecem sob autoridade do GLPI.

## Eficiência e diagnóstico

O vazio comprovado encerra apenas a consulta dependente de grupos. A lista não chama `Search::getDatas`; no cockpit, `group_open` é produzido localmente e as outras quatro métricas continuam suas consultas independentes. Os códigos internos `group_scope_without_current_groups`, `group_scope_group_not_in_current_groups` e `group_scope_context_unavailable` permanecem restritos aos contratos e diagnósticos apropriados.

## Evidência automatizada mínima

- normalização dos formatos oficiais planos observados no GLPI 10 e no GLPI 11;
- ausência comprovada, sessão ausente, valor não-array, entrada malformada e falha marcada da carga nativa;
- `group_id` autorizado e não autorizado, além da separação entre `scope` e `group_by`;
- zero chamadas de busca para a lista vazia exata e quatro, não cinco, para o cockpit com grupos vazios;
- paridade entre estado síncrono e assíncrono, mensagem anunciável e catálogos pt-BR/en-GB;
- preservação dos demais indicadores e escopos.

## Dados, implantação e limites

A correção não cria tabela, coluna, cache persistente nem cópia de grupos ou chamados. A troca da versão invalida o cache dos ativos pelo mecanismo existente. Depois da atualização, limpe os caches do GLPI e do navegador e revalide perfil, entidade e recursividade.

Testes automatizados não substituem a execução em instalações reais com grupos diretos e recursivos, múltiplas entidades, diferentes perfis e tecnologias assistivas. A promoção permanece condicionada ao plano [`test_plan_0.2.39-beta.md`](test_plan_0.2.39-beta.md).
