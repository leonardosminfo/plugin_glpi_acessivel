# GLPI Acessível 0.4.0-beta: lista limitada e proteção de capacidade

## Objetivo

Esta versão substitui o caminho de listagem capaz de materializar conjuntos
completos por uma busca limitada de IDs, paginada e protegida por admissão. A
mudança responde ao `Gateway Timeout` observado ao abrir **Meus chamados** e
preserva o GLPI como autoridade de ACL, critérios, perfil, entidade,
recursividade e grupos.

## Mudanças principais

- adaptadores distintos para GLPI 10 e GLPI 11 constroem a consulta pelo motor
  Search do core e exigem `LIMIT offset,page_size+1` na SQL efetiva;
- o plugin hidrata somente os IDs autorizados da página e usa o registro extra
  apenas para determinar `has_more`;
- o total deixa de bloquear a primeira página e passa a possuir estado explícito
  (`deferred`, `pending`, `exact`, `unavailable` ou `lower_bound`);
- uma capability desconhecida falha fechada e não volta à materialização
  ilimitada por `Search::getDatas()`;
- o endpoint assíncrono aplica limite por usuário/contexto, rate limit e
  capacidade local antes da consulta;
- a interface não converte total ausente em zero e oferece paginação
  Anterior/Próxima sem inventar última página;
- a retenção da auditoria sai do caminho da requisição e passa a usar índices e
  execução em lotes;
- mensagens, foco, retry e `aria-busy` são alinhados aos estados reais de página,
  total, sessão, contexto, permissão, rate limit e indisponibilidade.

## Contrato funcional

Uma página limitada retorna no máximo `page_size` itens e informa
`has_previous`/`has_more`. Enquanto o total não for conhecido, `total` é `null`
e nenhuma quantidade é inferida.

O usuário pode consultar e navegar nas páginas disponíveis sem esperar uma
contagem global. Falha exclusiva do total não invalida os chamados já
carregados.

## Segurança e compatibilidade

- critérios, joins e ACL continuam construídos pelo core do GLPI;
- nenhum SQL alternativo de autorização é mantido pelo plugin;
- filtros, pesquisas salvas e busca avançada são executados somente quando a
  capability da versão é reconhecida;
- IDs devem ser positivos, únicos e pertencer à página autorizada;
- contexto é revalidado antes da resposta;
- falha de adaptador, timeout ou circuito mantém o resultado indisponível e a
  alternativa nativa, sem ampliar escopo;
- GLPI 10 e 11 exigem testes e adapters próprios, mas usam o mesmo artefato do
  plugin.

## Banco, PHP-FPM e auditoria

A paginação limitada reduz materialização, memória e transferência, mas não
substitui o dimensionamento operacional. A versão adiciona admissão e rejeição
rápida para impedir que retries e múltiplas abas ocupem todos os workers ou
conexões.

A retenção da auditoria passa a ser separada da gravação normal. Índices por
data permitem exclusão em lotes sem varredura crescente em cada consulta.

## Acessibilidade

- shell, filtros e fallback permanecem utilizáveis antes do resultado;
- uma única região viva anuncia cada transição relevante;
- `aria-busy` termina em sucesso, vazio, timeout, erro e cancelamento;
- total desconhecido não é anunciado como zero ou “Página 1 de 1”;
- a chegada tardia do total não move foco nem reconstrói a tabela;
- retry usa ação compatível com o erro e preserva foco;
- navegação sem total usa Primeira, Anterior e Próxima, omitindo Última;
- pt_BR/en_GB, teclado, reflow, zoom, contraste e leitores de tela fazem parte
  dos gates da versão.

## Implantação

1. executar a atualização do esquema e confirmar os índices de auditoria;
2. confirmar capability limitada no GLPI correspondente;
3. habilitar a correção primeiro em homologação/canário;
4. acompanhar PHP-FPM, conexões, memória, 429, 503 e 504;
5. só habilitar total exato depois da página limitada estar estável;
6. preservar flags de rollback e alternativa nativa.

Rollback nunca deve reativar silenciosamente a consulta ilimitada. Se a
capability limitada for desligada, a interface apresenta indisponibilidade e
oferece a lista nativa.

## Limites

- o adaptador de baixo nível depende de assinaturas homologadas do core;
- atualizações do GLPI podem exigir nova capability;
- total exato pode permanecer indisponível sob orçamento excedido;
- rate limit e capacidade local não substituem semáforo compartilhado em
  clusters;
- testes automatizados não substituem carga real, slowlog, análise do banco e
  validação assistiva.

## Gate de liberação

A promoção depende integralmente de
[`test_plan_0.4.0-beta.md`](test_plan_0.4.0-beta.md). SQL sem limite, diferença de
IDs, ampliação de ACL, total falso, OOM, 504, anúncio duplicado ou fallback ao
executor ilimitado são `NO-GO`.

## Linha de base automatizada

- PHP 8.1 e 8.3: 582 testes PHPUnit e 3.638 asserções aprovados;
- PHPStan e PHPCS: aprovados sem erros;
- navegador: 40 verificações aprovadas;
- i18n: 2.320 mensagens e catálogos POT/PO/MO aprovados.

Essa linha de base valida o artefato de código. Os gates de SQL observada, carga,
tecnologia assistiva e paridade funcional devem ser executados nos ambientes
GLPI 10 e 11 antes da promoção para produção.
