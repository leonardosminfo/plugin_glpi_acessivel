# Release 0.2.17-beta: consistencia e acessibilidade da busca de chamados

## Objetivo

Esta versao corrige o fluxo principal de pesquisa de chamados e consolida a paridade segura com pesquisas salvas do GLPI 10 e 11. O trabalho foi orientado por teste manual no ambiente GLPI, revisoes independentes de acessibilidade, integracao e seguranca, e regressao automatizada.

## Correcoes funcionais

- a pesquisa textual e a selecao de escopo funcionam mesmo quando nenhuma regra avancada foi adicionada;
- arrays ausentes da submissao HTML real sao normalizados de forma fechada antes da traducao para a AST;
- metacriterios modernos com `meta=1` e `itemtype` aparecem no resumo acessivel da consulta executada;
- o catalogo e a aplicacao de pesquisas salvas usam parametros canonicos e autorizados, inclusive no GLPI 10;
- `list_limit` suportado e restaurado como quantidade de resultados por pagina;
- campos especiais `all` e `view` so sao aceitos quando realmente habilitados pelas Search Options do GLPI;
- pesquisas salvas apenas com ordenacao, colunas ou registros excluidos mantem o estado visual de pesquisa ativa.

## Experiencia e acessibilidade

- os paineis de pesquisas salvas, opcoes de resultado e registros movem o foco ao abrir;
- `Escape` fecha o painel ativo e devolve o foco ao acionador;
- o dialogo de colunas possui identificador e associacao `aria-controls`;
- **Restaurar colunas padrao** recupera ID, titulo, status, prioridade, grupo responsavel e ultima atualizacao;
- o resumo aplicado nao e repetido para o leitor de tela;
- o resumo em edicao deixa de ser reanunciado a cada tecla e passa a atualizar em mudancas completas;
- rotulos, conectores logicos, acentos e a acao **Limpar filtros** foram esclarecidos.

## Robustez e seguranca

- a busca por nome no catalogo de pesquisas salvas usa filtro `LIKE` escapado no banco;
- cada requisicao do catalogo possui orcamento defensivo de ate 1.000 linhas e 250 ms, mantendo ACL e paginacao por cursor;
- cursor adulterado ou invalido volta para a primeira pagina com aviso generico, sem erro 500;
- o autocomplete possui cota global adicional por usuario/sessao/canal, impedindo reinicio do limite pela alternancia de contextos;
- operadores `empty` e `notempty` em campos remotos dispensam consulta de identificador, mas continuam exigindo valor vazio canonico.

## Documentacao permanente

O pacote passa a incluir:

- `docs/solucao_tecnologica.md`, com arquitetura, tecnologias, integracoes e controles;
- `docs/documentacao_funcional_e_organizacao.md`, com funcionalidades, pastas e inventario dos arquivos mantidos pelo projeto.

## Compatibilidade e dados

- GLPI: `>= 10.0` e `< 12.0`;
- PHP: `>= 8.1`;
- nenhuma migracao de banco;
- nenhuma copia local de pesquisas salvas;
- `SavedSearch` do GLPI continua como fonte de verdade.

## Validacao automatizada

- PHPUnit: **348 testes e 1.924 assercoes**;
- interface de busca: **2 de 2 testes de navegador aprovados**;
- PHPStan: **sem erros**;
- PHPCS: **167 de 167 arquivos aprovados**;
- auditoria de traducoes e verificacao estrutural do pacote executadas no gate de release.

## Homologacao recomendada

1. pesquisar apenas por texto, apenas por escopo e pela combinacao dos dois;
2. repetir criterios locais e remotos com `e`, `nao e`, vazio e nao vazio;
3. aplicar pesquisas salvas com criterios, metacriterios, ordenacao, colunas, excluidos e `list_limit`;
4. conferir os resumos com NVDA e JAWS;
5. operar todos os paineis, dialogo de colunas, autocomplete, tabela e paginacao apenas por teclado;
6. repetir a matriz em GLPI 10 e 11 com perfis, entidades, recursividade e volumes representativos.

## Pacote

```powershell
.\tools\build-release.ps1 -Output .release_0.2.17-beta_ticket_search_consistency -Profile marketplace -RequireMsgfmt
.\tools\verify-release.ps1 -Package .release_0.2.17-beta_ticket_search_consistency\glpiacessivel.zip -ExpectedVersion 0.2.17-beta -PublicProfile
```

A versao permanece beta e requer homologacao externa antes de uso amplo em producao.
