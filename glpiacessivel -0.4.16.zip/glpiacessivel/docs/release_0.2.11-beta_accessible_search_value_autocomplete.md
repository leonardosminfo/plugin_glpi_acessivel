# Release 0.2.11-beta: autocomplete acessível nos filtros de chamados

## Objetivo

Esta versão completa a seleção dos valores remotos do construtor de pesquisas.
Campos nativos do GLPI como usuário, grupo, entidade, categoria e localização
podem ser pesquisados pelo nome, sem exigir que a pessoa conheça o identificador
interno do registro.

## Integração com o GLPI 10 e 11

- o catálogo continua derivado das Search Options autorizadas do GLPI;
- o servidor resolve tabela, itemtype, direito, condição, `displaywith` e
  valores adicionais a partir do metadado nativo, nunca de parâmetros do
  navegador;
- a consulta usa os provedores de dropdown do GLPI e um token IDOR nativo;
- perfil, entidade ativa, recursividade e permissões continuam sendo aplicados;
- pesquisas salvas permanecem exclusivamente no `SavedSearch` do GLPI;
- ao abrir uma pesquisa salva, o identificador é resolvido novamente para um
  rótulo legível, sem criar cópia ou cache persistente no plugin.

## Experiência e acessibilidade

- combobox com pesquisa por nome e lista de resultados;
- rótulo visível separado do identificador técnico enviado ao GLPI;
- operação por setas, Home, End, Enter e Escape;
- estados de carregamento, vazio, erro e seleção anunciados por leitor de tela;
- cancelamento de consultas obsoletas, atraso de 300 ms e paginação de 25
  resultados;
- botão para limpar a seleção e link de contingência para a pesquisa nativa;
- reflow, tema noturno, alto contraste e `forced-colors`.

## Segurança e limites

- endpoint somente POST, autenticado, autorizado e protegido por CSRF;
- lista fechada de parâmetros e validação estrita de itemtype, campo, página,
  consulta e identificador;
- limite de 60 requisições por minuto por usuário, perfil e entidade;
- consultas curtas, caracteres de controle, UTF-8 inválido e campos não
  homologados falham de forma fechada;
- metadados de tabela, itemtype, permissão e condição nunca são aceitos do
  cliente;
- tipos de dropdown de plugins são aceitos somente quando o modelo e a tabela
  nativos coincidem; os demais continuam com "Abrir no GLPI";
- tokens simbólicos especiais de alguns campos nativos, como `myself` e
  `mygroups`, são preservados em pesquisas existentes, mas ainda não são
  oferecidos como resultados novos pelo autocomplete;
- o limitador é mantido na sessão PHP; instalações distribuídas podem reforçar
  a proteção usando um armazenamento compartilhado por usuário.

## Validação automatizada

- PHPUnit: 272 testes e 1.314 asserções;
- PHPStan: sem erros;
- PHPCS: sem erros;
- sintaxe PHP e JavaScript: validada;
- ativos fonte e públicos: hashes idênticos;
- fluxo do combobox validado em Chrome headless, incluindo teclado, seleção,
  limpeza e recuperação do valor salvo.
