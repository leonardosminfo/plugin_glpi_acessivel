# GLPI Acessível 0.4.7-beta — tarefas, atores e pesquisas verificáveis

O modo mínimo dos formulários incorporados também recebeu isolamento semântico reversível do chrome nativo validado. O plugin suprime somente os nós oficiais reconhecidos de cabeçalho, sidebar, rodapé e profiler (`#debug-toolbar` no GLPI 10 e `#debug-toolbar-applet` no GLPI 11), inclusive quando inseridos tardiamente, sem alterar o formulário, seus campos ocultos, CSRF, action ou controles funcionais portados ao `body`. Portal, chatbot e VLibras permanecem disponíveis na página externa, mas não são inicializados novamente dentro do iframe; raízes oficiais tardias do VLibras são isoladas para impedir controles e glifos duplicados.

## Objetivo

Fechar as inconsistências encontradas na homologação do perfil de leitura e na revisão conjunta de GLPI 10/11: modelos de tarefa e de chamado, quatro papéis de atores, pesquisas salvas, transições de status, campos fixados por modelo, CSRF assíncrono e respostas acessíveis sob carga.

## Paridade com o GLPI nativo

- Técnico e grupo de tarefa usam propósitos próprios, `own_ticket`, `is_task`, entidade e permissão contextual de criar tarefa.
- A administração de observadores usa `Ticket::canAdminActors()` nas duas versões. A atribuição permanece separada em `canAssign()`.
- A criação pública ou privada de acompanhamento e tarefa é decidida pelo `CREATE` do respectivo objeto nativo com o payload contextual. `SEEPRIVATE` permanece restrito à leitura de itens privados de terceiros.
- O resolvedor de `TaskTemplate` é comum ao catálogo, prévia e gravação. Valida leitura, entidade, recursividade, privacidade, categoria, estado, duração, técnico e grupo.
- Modelo com `pendingreasons_id` não representável falha fechado e deve ser usado no fluxo nativo completo.
- `Planning::INFO = 0` é um estado real, preservado no PHP e no JavaScript; `Planning::TODO` é o padrão obtido da constante nativa.
- Valores predefinidos representáveis do `TicketTemplate` são obtidos das Search Options permitidas pelo GLPI, normalizados por tipo, projetados no formulário e bloqueados com valor oculto equivalente. Título, descrição ou semântica não representável mantêm o fallback nativo.

## Integridade e concorrência

- A tela recebe uma revisão SHA-256 dos quatro conjuntos de atores hidratados.
- Qualquer mutação de atores sem revisão válida é recusada. Após `FOR UPDATE`, o repositório relê o snapshot e rejeita contexto obsoleto antes da primeira escrita.
- Inclusões e remoções são planejadas, autorizadas e aplicadas em transação, seguidas de releitura exata. Resultado incerto não é repetido automaticamente.
- Estado ou permissão alterado entre a exibição e o envio é revalidado pelo GLPI.

## Interface e acessibilidade

- Pesquisa salva simples projeta o status no seletor. Pesquisa avançada ou exclusivamente nativa mantém o seletor bloqueado e nunca se apresenta como `Todos`.
- A mudança de status começa sem opção pré-selecionada, exclui o estado atual e confirma origem e destino.
- A prévia de modelo usa revisão monotônica e aborta ou descarta resposta antiga quando a seleção muda.
- Seletores fixados por modelo usam `disabled`, `aria-readonly`, valor oculto preservado e explicação; o autocomplete não os reativa.
- Após remover um ator, o foco segue para o próximo/anterior botão; sem itens, volta à busca. Ao incluir a última opção, o foco não permanece em controle desabilitado.
- Hidratação incompleta mostra recuperação e não renderiza formulário mutável de atores.
- No GLPI 11, somente a exceção comprovadamente originada no listener CSRF nativo, para o `POST` JSON/XHR do endpoint de resultados, é normalizada como HTTP 403 `ticket_results` V2; outras negações permanecem nativas.

## Desempenho e homologação local

- O catálogo de tarefas carrega o chamado uma vez e cada modelo uma vez, evitando a recarga anterior por item.
- A lista mantém Search nativa limitada a 51 IDs, página máxima de 50, total diferido, hidratação em lote, orçamento combinado de 1.000 relações e proteção de capacidade.
- A sessão PHP é persistida e liberada imediatamente após o token bucket; a admissão global, a auditoria, as rejeições e a Search não mantêm o lock da sessão do navegador.
- Excesso de relações recebe o código operacional `bounded_search_hydration_relation_limit_exceeded`, mesmo mantendo a resposta funcional controlada.
- A fixture permite 55 chamados por padrão e até 10.000 mediante confirmação adicional, cria um `TicketTemplate` nativo verificável, reconcilia pesquisas salvas simples, aninhadas e por grupo responsável e preserva um caso nativo deliberadamente não projetável nas duas versões.
- O usuário sintético de leitura conserva exatamente uma atribuição de perfil controlada; atribuições antigas pertencentes à fixture são removidas dentro da mesma transação e qualquer divergência causa rollback.
- O ensaio `tools/homologation/ticket-results-load.cjs` exige o backend Search limitado, registra cada tentativa, distribui sequências fixas e equilibradas por usuário virtual e testa a recuperação após rejeição controlada sem registrar senha ou cookie. A preparação autenticada ocorre, fora da janela medida, com a concorrência-alvo para separar a rampa fria do servidor da latência do endpoint.

## Limites

Esta beta ainda não comprova cluster com vários nós, backend de capacidade compartilhado, 100 mil chamados, falha por lock em hidratação/auditoria nem certificação assistiva. Esses itens permanecem gates operacionais, não alegações desta versão.

## Rollback

Preservar o diretório anterior completo. A versão não requer migração destrutiva; restaure o pacote anterior e confirme o diagnóstico de versão/runtime. Em cluster, preload ou OPcache restrito, siga a recarga coordenada da infraestrutura.
