# Execução de testes — 0.4.7-beta — 29/08/2026

## Resultado automatizado da árvore-fonte

| Gate | Resultado |
| --- | --- |
| PHPUnit PHP 8.1.31 | 731 testes, 4.495 asserções, aprovado |
| PHPUnit PHP 8.3.14 | 731 testes, 4.495 asserções, aprovado |
| PHPStan | sem erros |
| PHPCS PSR-12 | 272 arquivos, aprovado |
| Navegador | 72 cenários, aprovado |
| Ensaio de carga (unidade) | 4 testes, aprovado |
| Internacionalização | 2.447 mensagens; 2.448 entradas compiladas; POT/PO/MO e espelhos consistentes |

## Contratos adicionais comprovados

- estado de tarefa `0` preservado no serviço, repositório e aplicação DOM;
- acompanhamento não executa lógica de tarefa e a tarefa define o estado antes do payload;
- prévia assíncrona antiga abortada/descartada quando o modelo muda;
- foco previsível após remoção e após inclusão da última opção de ator;
- seleção fixada pelo modelo desabilitada com valor oculto preservado;
- `canAdminActors()` comum aos GLPI 10/11 e criação privada delegada ao `CREATE` nativo;
- mutação de atores sem revisão recusada e contexto obsoleto representado por erro estável;
- pesquisas `saved_simple`, `saved_advanced` e `saved_native_only` com apresentação distinta;
- hidratação incompleta sem controles mutáveis e excesso de relações com código operacional próprio.
- fixture ativa com uma única atribuição de perfil não administrativo, rollback integral em divergências e credenciais rotacionadas sem divulgação;
- contenção do lock de circuito termina com falha fechada dentro do orçamento limitado, sem espera indefinida.
- usuários virtuais conservam uma sessão distinta e sequências equilibradas, impedindo que um trabalhador rápido transforme contenção de capacidade em falso `rate_limited`.
- nos dois renderizadores incorporados, shell, glifos e profiler oficial — inclusive quando inserido após o carregamento — ficam `hidden`, `inert` e `aria-hidden`; a árvore acessível preserva instruções, alertas, campos e envio, sem mudar `action`, CSRF ou campos ocultos.
- widgets globais não são reinicializados no documento filho; fixtures tardias de VLibras (`[vw]` e `[vp]`) ficam fora da árvore e da tabulação, enquanto a instância da página externa permanece disponível.

## Estado da homologação local

As fixtures e a matriz autenticada produzem evidência externa ao ZIP em `.test-results/0.4.7-beta-20260829/`. O resumo deve registrar o SHA do pacote efetivamente instalado nos dois contêineres; os artefatos de tentativas não contêm senha nem cookie de sessão.

## Não alegado

A aprovação automatizada não constitui certificação WCAG/eMAG/RGAA. Cluster, preload, vários pools, 100 mil chamados, locks de auditoria/hidratação e leitor de tela real continuam dependentes de homologação operacional controlada.
