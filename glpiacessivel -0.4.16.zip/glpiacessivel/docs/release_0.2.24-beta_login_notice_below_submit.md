# GLPI Acessivel 0.2.24-beta: aviso abaixo de Entrar

## Resultado

O aviso opcional `Portal Acessivel disponivel apos o login.` passa a aparecer imediatamente depois do botao `Entrar` no formulario nativo do GLPI. A mudanca preserva a ordem real do DOM, beneficiando leitura linear, ampliacao e reflow.

O GLPI 10 e o GLPI 11 oferecem o hook `DISPLAY_LOGIN` em uma coluna auxiliar, mas nao disponibilizam um hook logo depois do submit. Para evitar alteracao do core ou posicionamento apenas visual por CSS, o plugin continua renderizando a nota no hook e registra o reposicionador externo no hook oficial `add_javascript_anonymous_page`, deixando o GLPI resolver e carregar o ativo de mesma origem.

## Fronteira de seguranca

- o formulario e reconhecido pelo campo oficial `#login_name`;
- o submit e procurado somente dentro do formulario ancestral e precisa ter `type="submit"` e `name="submit"`;
- o script nao le valores, nao cria `FormData`, nao envia requisicoes e nao intercepta o submit;
- o aviso continua sem link, botao, campo, foco, `tabindex` ou `aria-live`;
- se a estrutura nao for reconhecida, a nota permanece visivel na area nativa do hook;
- o modo `native_only` continua delegando senha, SSO, CAPTCHA e MFA exclusivamente ao GLPI.

## Acessibilidade

A nota preserva `role="note"`, nome acessivel e icone decorativo. O reposicionamento nao altera foco nem produz anuncio dinamico. Quando movida, a caixa usa largura fluida, quebra segura de texto e nenhum tamanho fixo, para funcionar em largura reduzida e ampliacao.

O posicionamento precisa ser homologado externamente com GLPI 10 e 11, login local e SSO, 320 pixels CSS, zoom de 200% e 400%, cores forcadas, teclado, NVDA e JAWS.

## Compatibilidade e rollback

Nao ha tabela, coluna ou migracao nova. A preferencia existente `show_login_accessibility_notice` continua desativada por padrao. Desativa-la remove a nota e o carregamento do reposicionador no proximo acesso ao login.

O fallback mantem compatibilidade conservadora: falha no ativo ou mudanca inesperada do template nao oculta a mensagem e nao afeta o formulario de autenticacao.

## Verificacao

O gate local foi aprovado com 375 testes PHPUnit e 2.088 assercoes, PHPStan sem erros em 170 arquivos, PHPCS em 169 de 169 arquivos, 7 testes de navegador em 4 arquivos e 567 mensagens Gettext. O verificador do pacote confirmou raiz unica, versao, URL da tag, documentos, ativos identicos de posicionamento e ausencia de caminhos de desenvolvimento.

```powershell
composer qa
npm run test:browser
.\tools\build-release.ps1 -Output .release_0.2.24-beta_login_notice_below_submit -Profile marketplace -RequireMsgfmt
.\tools\verify-release.ps1 -Package .release_0.2.24-beta_login_notice_below_submit\glpiacessivel.zip -ExpectedVersion 0.2.24-beta -PublicProfile
```
