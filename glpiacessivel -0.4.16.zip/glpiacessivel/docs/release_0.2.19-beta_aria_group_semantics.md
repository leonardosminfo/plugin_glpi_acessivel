# Release 0.2.19-beta: semantica ARIA dos grupos de acoes

## Objetivo

Eliminar o resultado `aria-prohibited-attr` apresentado pelo diagnostico local quando os filtros avancados da busca de chamados estavam abertos.

## Causa

O conjunto de botoes para adicionar regra, regra global ou grupo possuia um nome acessivel por `aria-label`, mas permanecia com o papel generico implicito de uma `div`. O Axe classificava a combinacao como uma regra seria que exigia revisao manual.

O mesmo padrao existia no conjunto de acoes de cada pesquisa salva, embora esse painel normalmente permanecesse fechado durante a auditoria.

## Correcao

- declara `role="group"` no conjunto de acoes dos filtros avancados;
- declara `role="group"` no conjunto de acoes das pesquisas salvas;
- preserva os nomes acessiveis que ajudam leitores de tela a compreender o contexto dos botoes;
- adiciona regressao automatizada para impedir o retorno de `aria-label` sobre esses conteineres sem um papel compativel;
- nao altera filtros, pesquisas salvas, permissoes, banco de dados ou integracao com GLPI.

## Validacao manual

1. abrir a lista acessivel de chamados;
2. expandir **Filtros avancados**;
3. executar **Auditar esta pagina**;
4. confirmar que `aria-prohibited-attr` nao e mais listado;
5. abrir **Pesquisas salvas**, executar novamente a auditoria e confirmar o mesmo resultado;
6. conferir por teclado e leitor de tela que os grupos e seus botoes continuam nomeados e operaveis.

## Geracao do pacote

```powershell
.\tools\build-release.ps1 -Output .release_0.2.19-beta_aria_group_semantics -Profile marketplace -RequireMsgfmt
.\tools\verify-release.ps1 -Package .release_0.2.19-beta_aria_group_semantics\glpiacessivel.zip -ExpectedVersion 0.2.19-beta -PublicProfile
```
