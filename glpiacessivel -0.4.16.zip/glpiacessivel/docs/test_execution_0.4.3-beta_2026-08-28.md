# Execução de testes — 0.4.3-beta — 28/08/2026

## Resultado executivo

A implementação automatizável desta revisão foi aprovada nos gates locais de PHP, análise estática, estilo, navegador e internacionalização. A validação ao vivo local confirmou a lista progressiva e os seletores de requerente, atribuição e observação no GLPI 10 e no GLPI 11.

A homologação autenticada no GLPIT gravou somente evidências controladas no chamado `#31` e encontrou bloqueios funcionais na delegação, reconciliação de atores, modelo de tarefa e adição de solução. Portanto, a decisão desta execução é **NO-GO** até correção e reteste desses pontos.

Este relatório não substitui a homologação assistida com usuários, leitor de tela ou a prova de mutação e histórico em uma cópia controlada da base.

## Gates automatizados

| Gate | Resultado |
|---|---|
| PHPUnit — PHP 8.1.31 | aprovado: 668 testes, 4.065 asserções |
| PHPUnit — PHP 8.3.14 | aprovado: 668 testes, 4.065 asserções |
| PHPStan | aprovado, sem erros |
| PHPCS | aprovado: 266 arquivos |
| Navegador | aprovado: 45 testes |
| Gettext/i18n | aprovado: 2.379 mensagens; POT/PO/MO e espelhos consistentes |

## Validação funcional ao vivo

| Ambiente | Cenário | Evidência observada | Resultado |
|---|---|---|---|
| GLPI 10 — `localhost:8089` | lista progressiva | primeira página limitada, sem contagem global obrigatória | aprovado |
| GLPI 11 — `localhost:8080` | lista progressiva | primeira página limitada, sem contagem global obrigatória | aprovado |
| GLPI 10 e 11 | busca delegada por nome ou usuário | `normal` retornado pelo catálogo nativo | aprovado |
| GLPI 10 | grupo responsável e grupo observador | dois grupos de fixture retornados para `QA` | aprovado |
| GLPI 11 | grupo responsável e grupo observador | dois grupos de fixture retornados para `QA` | aprovado |
| GLPI 10 e 11 | técnico atribuído e pessoa observadora | usuário `glpi` retornado para `gl` | aprovado |
| GLPI 10 e 11 | quatro buscas de atores concorrentes | respostas recebidas sem invalidação do token | aprovado |

## Correção de compatibilidade encontrada durante a execução

O GLPI 11 recusava os seletores com HTTP `403` antes do controlador do plugin. O listener CSRF do núcleo só consulta `X-GLPI-CSRF-TOKEN` quando a requisição é identificada como AJAX. O cliente passou a enviar também `X-Requested-With: XMLHttpRequest`; a mesma implementação foi mantida no GLPI 10. Uma regressão de navegador e uma regressão de contrato PHP verificam os dois cabeçalhos.

## Homologação autenticada no GLPIT

Contexto da execução: versão `0.4.3-beta`, usuário autenticado `T212521 — Leonardo`, perfil temporário `Super-Admin` e entidade temporária `JF2R > InternoTi`. Ao final, a sessão foi restaurada para o perfil `Helpdesk` e a entidade `Todas as entidades permitidas`.

Foram habilitados e mantidos ativos os recursos de lista assíncrona, seletor remoto, criação delegada por seletor e roteamento por seletor remoto.

### Evidências aprovadas

| Cenário | Evidência observada | Resultado |
|---|---|---|
| abertura controlada | chamado `#31` criado para o usuário autenticado, com texto de homologação e entidade `JF2R > InternoTi` | aprovado |
| rejeição segura de requerente | a tentativa com `leonardo.reserva`, oferecido pelo catálogo, foi recusada pela revalidação final sem criar chamado | segurança fail-closed aprovada; jornada positiva bloqueada |
| diálogo crítico | confirmação de atribuição abriu com foco em `Cancelar`; `Escape` devolveu o foco ao acionador | aprovado |
| tarefa interna | tarefa privada, concluída e com duração de 15 minutos persistiu na linha do tempo | aprovado |
| acompanhamento | acompanhamento privado com texto controlado persistiu na linha do tempo | aprovado |
| lista progressiva | páginas 1 e 2 sem IDs duplicados; total global dispensado; pesquisa salva `teste1` e busca rápida localizaram o chamado `#31` | aprovado |
| carga autenticada curta | sem HTTP `504`; o limitador respondeu com mensagem acessível após repetição e recuperou a lista depois de 3,5 segundos | aprovado como smoke test |
| formulário incorporado | sidebar e cabeçalho ficaram ocultos; nenhum dos 164 controles externos ao `main` permaneceu visível, focável ou exposto | aprovado por inspeção automatizada |
| ponte de alto contraste | iframe alternou de fundo branco/texto escuro para fundo preto/texto branco e retornou ao padrão | aprovado |
| Axe local | lista e formulário sem violações automatizadas confirmadas; detalhe do chamado sem violação confirmada e com duas regras manuais revisadas | aprovado com ressalva manual |

Os quatro avisos manuais de ARIA apontavam `aria-controls` de comboboxes para `listbox` existentes, ocultos apenas durante o estado recolhido. O aviso de contraste do `textarea#followup` apresentou `0:1` por estar parcialmente encoberto, embora as cores computadas fossem texto `rgb(16, 32, 51)` sobre fundo branco. Não foi confirmada falha nesses cinco elementos.

### Bloqueios encontrados

| Prioridade | Cenário | Evidência | Estado final |
|---|---|---|---|
| bloqueador | atualização conjunta de quatro papéis de atores | grupo responsável, técnico, pessoa observadora e grupo observador resultaram em `Empty IN are not allowed`; nenhum ator foi persistido | pendente de correção |
| bloqueador | consistência após mutação de ator | adicionar ou remover apenas o grupo responsável alterou o chamado e o histórico, mas a interface informou `Revise os atores selecionados.` | estado restaurado sem atribuídos/observadores; pendente de correção |
| alta | criação delegada positiva | `leonardo.reserva` apareceu no catálogo remoto, mas foi recusado pela autorização final tanto em `JF2R` quanto em `JF2R > InternoTi` | pendente de reconciliar catálogo e ACL final |
| alta | modelo de tarefa | o modelo `Frase de fechamento para chamado de N3:` preencheu o `textarea` com HTML e marcadores Twig literais | não gravado; pendente de conversão segura |
| alta | solução | a solução controlada passou pelo diálogo crítico, mas terminou em `Não foi possível executar a ação.`; o chamado continuou `Novo` | nenhuma solução persistida; pendente de correção |
| configuração | modelos organizacionais | não havia modelo de acompanhamento nem modelo de solução disponível para o perfil e a entidade testados | exige fixture/configuração para reteste |

O chamado `#31` permaneceu no estado `Novo`, sem grupo, técnico ou observadores. As tarefas privadas e o acompanhamento privado foram preservados como evidência de homologação.

## Itens que ainda exigem homologação assistida ou infraestrutura dedicada

- repetir a criação delegada positiva depois de reconciliar catálogo remoto, perfil, entidade e ACL final;
- repetir combinações 0/1/N dos quatro papéis depois de corrigir `Empty IN` e a resposta incoerente após mutação;
- disponibilizar fixtures reais de acompanhamento e solução e retestar os três tipos de modelo;
- corrigir a conversão do modelo de tarefa e comprovar texto legível, entidades e quebras de linha;
- corrigir a adição de solução e comprovar conteúdo, autor, histórico e transição de estado;
- executar carga autenticada prolongada em ambiente controlado e registrar p95, p99, memória, PHP-FPM e banco;
- concluir zoom, cores forçadas, NVDA/JAWS e aceitação com usuários.

Qualquer falha de ACL, mutação parcial ou ambígua, perda de ator, HTTP 5xx/504 ou barreira assistiva mantém a liberação como **NO-GO**.
