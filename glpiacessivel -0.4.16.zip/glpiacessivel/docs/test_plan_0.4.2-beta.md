# Plano de testes — 0.4.2-beta

## Gate automatizado

1. Executar PHPUnit completo, análise estática, padrão de código e testes de navegador.
2. Gerar o pacote marketplace e executar `verify-release.ps1 -ExpectedVersion 0.4.2-beta -PublicProfile`.
3. Confirmar que ativos fonte/públicos são idênticos, `VERSION` coincide com os metadados, os três fingerprints coincidem e não existe chamada a `opcache_reset()`.

## GLPI 10 e GLPI 11

Em cada ambiente, executar com perfil técnico autorizado e com perfil sem autorização:

### Modelo de solução

1. Abrir chamado solucionável e aplicar modelo global, de entidade e recursivo.
2. Confirmar texto legível, quebras de linha, entidades HTML e aviso quando a conversão perder formatação.
3. Alterar o texto antes de gravar e confirmar que a edição foi preservada.
4. Selecionar tipo válido; tentar tipo forjado, modelo de outra entidade e acesso direto sem permissão.
5. Conferir `glpi_itilsolutions`, tipo, usuário, histórico e status final nativo.
6. Repetir acompanhamento e tarefa para excluir regressões.

### Formulários

1. Exercitar formulário simples, condicional, com atores, anexo e destino múltiplo.
2. Comparar objeto final criado pelo portal e pelo renderer nativo.
3. No GLPI 11, testar ID inexistente, inativo e bloqueado por política de acesso.
4. Ativar a ponte somente em homologação e verificar tema claro/noturno, alto contraste, 90/100/110/120%, zoom de 200%, reflow em 320 CSS px e `forced-colors`.
5. Confirmar método, ação, nomes, valores, token CSRF e estado do botão antes/depois da ponte.
6. Testar sessão expirada, origem/rota divergente, fingerprint desconhecido e falha de CSS; a página completa deve permanecer disponível.
7. Executar teclado, NVDA/JAWS e axe separadamente no documento pai e no documento interno.

### Atualização e OPcache

1. Instalação limpa e upgrade do pacote anterior com snapshot do banco.
2. Testar `VERSION` igual, novo, anterior, ausente, vazio, maior que 128 bytes e contendo NUL.
3. Na requisição `stale`, confirmar que `hook.php` não foi carregado e que somente arquivos PHP reais dentro do plugin foram considerados.
4. Repetir com OPcache desligado, `validate_timestamps=0/1`, `restrict_api` e preload documentado.
5. Simular duas execuções de migração e interrupção antes do registro; confirmar lock, checksum e idempotência.
6. Em single-node/single-pool, confirmar sequência antigo → refresh → novo sem reiniciar. Para a primeira implantação do mecanismo, executar a última recarga operacional prevista.

## Critérios de aceite

- Nenhuma diferença de ACL ou do objeto final entre o portal e o fluxo nativo.
- Nenhum HTML literal em acompanhamento, tarefa ou solução.
- Nenhuma mutação do contrato do formulário pela ponte acessível.
- Nenhum hook carregado com runtime divergente e nenhuma invalidação externa à pasta do plugin.
- Zero erro/falha no gate automatizado e roteiro manual assistivo aprovado.
