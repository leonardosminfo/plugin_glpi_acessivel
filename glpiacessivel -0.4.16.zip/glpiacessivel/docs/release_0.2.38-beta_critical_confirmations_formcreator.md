# GLPI Acessível 0.2.38-beta: confirmações críticas e homologação Formcreator

## Objetivo

Esta versão corrige o acionamento das confirmações críticas compartilhadas pelo GLPI 10 e pelo GLPI 11 e amplia a homologação do Formcreator 2.13 no GLPI 10.

## Correções

- conecta o controlador de confirmação crítica exatamente uma vez durante a inicialização do JavaScript;
- impede que o anúncio genérico de processamento seja emitido antes de uma confirmação efetiva;
- coloca o foco inicial no botão **Cancelar**, mantém o foco no diálogo e devolve-o ao acionador ao cancelar ou pressionar `Escape`;
- inclui descrição e consequência no nome descritivo do `alertdialog`;
- preserva o botão escolhido, a ação e o token em formulários com múltiplos submitters, como aprovação e recusa de solução;
- mantém o servidor como autoridade: ACL, CSRF, token de uso único e validações continuam inalterados.

## Compatibilidade e implantação

O defeito era comum às duas versões do GLPI e não uma incompatibilidade exclusiva do GLPI 10. O número da versão foi alterado para evitar ambiguidade de cache e permitir comprovar que GLPI 10 e GLPI 11 executam o mesmo artefato.

No GLPI 10, a matriz adicional usa Formcreator 2.13.10 com catálogo ampliado explicitamente habilitado. A apresentação mínima continua opcional e conservadora: qualquer divergência de versão, rota, origem, identificador, CSRF ou estrutura preserva a interface completa.

## Evidência automatizada mínima

- PHPUnit, PHPStan e PHPCS integralmente verdes;
- testes de navegador completos, incluindo o novo contrato de confirmação crítica;
- paridade byte a byte entre `assets/` e `public/assets/`;
- auditoria POT/PO/MO com `msgfmt`;
- pacote público verificado e identificado por SHA-256.

## Limites

Os testes automatizados não substituem a execução assistida com NVDA e JAWS, nem a validação de condições, anexos, targets e ACL em formulários reais. A promoção permanece condicionada ao plano [`test_plan_0.2.38-beta.md`](test_plan_0.2.38-beta.md).
