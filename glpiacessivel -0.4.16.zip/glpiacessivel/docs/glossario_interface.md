# Glossário da interface do GLPI Acessível

Este glossário orienta textos visíveis, nomes acessíveis, mensagens anunciadas e traduções. A terminologia do GLPI nativo prevalece quando ela identifica um objeto ou uma ação oficial. Novos textos devem passar por Gettext e preservar a acentuação do português brasileiro.

| Conceito | Termo recomendado | Evitar | Observação |
|---|---|---|---|
| Registro de atendimento | chamado | ticket, ocorrência | Use `ticket` somente em código ou documentação técnica. |
| Pessoa designada | técnico responsável | atribuído, recurso | Quando houver mais de uma pessoa, use `técnicos responsáveis`. |
| Grupo designado | grupo responsável | grupo atribuído | Não confundir com grupo observador. |
| Pessoa que acompanha | observador | watcher | Preserve o papel oficial do GLPI. |
| Pesquisa armazenada | pesquisa salva | filtro local, lista salva | A fonte de verdade é o próprio GLPI. |
| Conteúdo executado | filtros aplicados | consulta atual | `Consulta em edição` identifica o estado ainda não executado. |
| Momento da apuração | atualizado em | horário do sistema | Informe data, hora e fuso quando disponíveis. |
| Contagem não comprovada | resultado indisponível | zero, sem chamados | Zero é um valor exato; indisponibilidade é um estado diferente. |
| Conjunto autorizado | todos os chamados permitidos | todos os chamados | Deixa claro que as permissões do GLPI continuam ativas. |
| Configuração de tabela | exibição dos resultados | filtro de colunas | Colunas, ordenação, agrupamento e paginação não alteram necessariamente o conjunto encontrado. |
| Ação principal de consulta | Pesquisar | Aplicar, Buscar | Use uma única ação principal na pesquisa de chamados. |
| Alternativa fora do plugin | Abrir no GLPI | modo avançado | Explique quando a representação acessível não puder ser fiel. |

## Regras de redação

- Prefira frases curtas, voz ativa e a ação antes da justificativa.
- Não exponha nomes de classes, códigos de exceção, SQL, caminhos ou detalhes de backend ao usuário comum.
- Diferencie `carregando`, `nenhum resultado`, `resultado indisponível`, `sessão expirada` e `permissão insuficiente`.
- Não anuncie a mesma mudança em duas regiões vivas.
- Use o rótulo do controle na mensagem de erro e explique como corrigir o problema.
- Não dependa apenas de cor, ícone, posição ou pontuação para comunicar estado.
- Verifique a pronúncia no NVDA e no JAWS; uma frase ortograficamente válida ainda pode exigir redação mais natural.

## Processo de revisão

1. inventariar toda string visível ou anunciada do fluxo alterado;
2. confirmar que ela passa por Gettext e usa UTF-8 íntegro;
3. comparar o termo com este glossário e com o GLPI nativo;
4. revisar acentuação, concordância, plural e variáveis inseridas;
5. testar nome acessível, mensagem e pronúncia com tecnologia assistiva;
6. registrar exceções justificadas na nota da versão.
