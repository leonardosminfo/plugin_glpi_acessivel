# Documentação funcional e organização do GLPI Acessível

## Visão funcional

O GLPI Acessível oferece uma interface alternativa e integrada ao GLPI. O usuário continua sujeito ao mesmo login, perfil, entidade, recursividade e permissões. A interface acessível organiza as tarefas mais frequentes sem copiar os dados operacionais para outro sistema.

## Funcionalidades

### Portal e contexto

- entrada acessível com navegação consistente;
- configuração da entrada anônima entre login unificado do GLPI, recomendado, e formulário alternativo de compatibilidade;
- redirecionamento direto ao login oficial do GLPI quando o modo unificado está ativo, preservando SSO, MFA e retorno ao portal;
- nota estática e opcional imediatamente depois de `Entrar` no login nativo, identificada semanticamente, sem link, foco, anúncio intrusivo, formulário ou rota alternativa; uma melhoria progressiva restrita move a nota no DOM e conserva a área do hook como fallback;
- identificação autenticada por login e primeiro nome nativo do GLPI, com fallback para somente o login;
- troca autorizada de perfil e entidade, confirmada somente depois que a nova requisição comprova a persistência da sessão GLPI;
- indicação do contexto ativo;
- atalhos de teclado, tema noturno, alto contraste e ampliação;
- alternativa explícita para abrir a tela nativa do GLPI quando necessário.

### Chamados

- criação assistida com campos autorizados, anexos e validação acessível;
- pesquisa organizada em três etapas progressivas sobre um único estado canônico: busca rápida, filtros e exibição dos resultados; o acesso recorrente a pesquisas salvas permanece separado do formulário principal e reutiliza o mesmo estado quando aplicado;
- uma única ação `Pesquisar`, sem aplicar a consulta em edição antes da confirmação e sem duplicar o estado da pesquisa;
- no GLPI 11, o POST da pesquisa calcula o destino antes da fronteira de redirecionamento e preserva `advanced_search_token` e `focus=results`, evitando que a exceção nativa de redirect seja classificada como falha;
- listagem com pesquisa textual, escopo, critérios, grupos e metacritérios;
- operadores e valores derivados das Search Options do GLPI;
- condições positivas e negativas de status somente quando autorizadas pelo catálogo de operadores do contexto atual;
- autocomplete remoto autorizado para usuários, grupos, categorias e demais dropdowns;
- múltiplas ordenações, quantidade por página e escolha/reordenação de colunas;
- diálogo de colunas com fechamento por teclado e retorno do foco ao acionador;
- exibição autorizada de chamados ativos ou excluídos;
- resumo separado da consulta em edição e da pesquisa aplicada;
- paginação, seleção e abertura do chamado;
- consulta limitada de IDs com adaptadores próprios para GLPI 10 e 11, linha sentinela apenas para detectar a próxima página e hidratação máxima do tamanho autorizado;
- total independente e anulável, sem bloquear a primeira página nem apresentar ausência de contagem como zero;
- limite global de capacidade, uma consulta em voo por usuário/contexto e circuito local para rejeitar sobrecarga antes da Search API;
- detalhe com acompanhamentos, tarefas, solução, documentos e ações permitidas;
- carregamento assíncrono opcional da página de resultados, com estado de carregamento, vazio, expiração e indisponibilidade, sem substituir a página ou perder o link nativo;
- escopo de grupos em três estados: grupos oficiais resolvidos seguem para consulta, ausência oficial comprovada produz lista vazia exata e contexto ausente, malformado ou cuja carga nativa falhou permanece indisponível;
- validação de `group_id` contra os grupos oficiais do perfil e da entidade atuais, com falha fechada e sem consulta quando o identificador não pertence ao conjunto; `group_by` organiza a apresentação sem alterar o escopo;
- fallback nativo sempre visível antes da inicialização assíncrona, limite de espera, nova tentativa por botão e encerramento garantido do estado ocupado quando o ativo ou o endpoint falhar;
- falha na preparação do estado assíncrono encerra em shell degradado e recuperável, sem executar a consulta síncrona pesada como emergência;
- hidratação em lote da página retornada pela Search API, evitando consulta individual por chamado;
- seletores pesquisáveis e paginados para categoria, localização, técnicos, grupos e observadores, com seleção simples ou múltipla e revalidação integral no envio;
- pesquisa vazia ou curta para categoria/localização e mínimo de dois caracteres para pessoas/grupos, com mensagens estruturadas e resumo de validação sincronizado sem deslocar o foco;
- seleção separada de grupos técnicos e grupos observadores, limitada aos grupos elegíveis para cada papel e para a entidade do chamado;
- recuperação dos grupos já vinculados e substituição por papel sem alterar usuários, fornecedores ou outros atores;
- rota canônica `front/tickets.php` para lista e detalhe, evitando a substituição indevida pelo Formcreator em perfis Self-Service; a rota histórica `front/ticket.php` apenas encaminha favoritos antigos antes do bootstrap;
- condição `Status não é` preservada na interface, no resumo e na pesquisa salva, com compilação compatível com a polaridade nativa do GLPI 10 antes da execução;
- escopo `Meus chamados` formado pelos papéis nativos de requisitante, técnico e observador descobertos por metadados, sem identificadores numéricos ou rótulos dependentes do idioma;
- lista e seletores assíncronos traduzidos pelo catálogo compartilhado, mantendo o HTML do servidor como alternativa quando o JavaScript ou a tradução não estiver disponível;
- criação e detalhe com vocabulário canônico pelo contrato Gettext para textos visíveis, nomes acessíveis, confirmações e anúncios, incluindo o gate linguístico global da `0.2.37-beta`;
- contagens de chamados, seleções, erros, anexos, atores e resultados de auditoria com plurais naturais em pt-BR e en-GB, sem construções artificiais com `(s)`;
- mudanças de tema, contraste, alertas e carregamentos comunicadas uma única vez pelas regiões vivas, sem anúncio visual e modal duplicado;
- falhas de sessão ou CSRF apresentadas como orientação para atualizar, entrar novamente ou repetir a ação, sem expor tokens ou detalhes técnicos ao usuário comum;
- criação de chamado redireciona somente depois das fronteiras de exceção, sem alterar a ordem de ACL, CSRF, idempotência e validações.

### Pesquisas salvas

- catálogo paginado das pesquisas autorizadas do GLPI;
- pesquisa por nome;
- aplicação direta da definição nativa;
- criação, renomeação, definição como padrão e exclusão no próprio GLPI;
- mutações selecionam o destino dentro do fluxo protegido e redirecionam somente depois dos `catch`, mantendo compatibilidade com `RedirectException` no GLPI 11;
- classificação conservadora de pesquisas que precisam ser abertas na interface nativa;
- nenhuma cópia ou sincronização local de `SavedSearch`.

### Conhecimento, formulários e atendimento

- consulta acessível da base de conhecimento;
- descoberta e renderização delegada de formulários nativos, Service Catalog e Formcreator quando o contrato é comprovado;
- catálogo público com nome, descrição e uma ação principal, sem expor fonte, versão, motor, renderer, contrato ou razão técnica;
- abertura orientada por tarefa, com uma única região de estado, alternativa permanente em página completa, nova tentativa e foco preservado;
- abertura iniciada pelo catálogo sempre preserva o shell e o menu do portal; o modo de página completa permanece uma alternativa explícita;
- área incorporada com altura responsiva limitada e rolagem própria, evitando realimentação de tamanho entre o iframe e o documento Formcreator;
- incorporação do Service Catalog do GLPI 11 condicionada a mesma origem, rota, ID, método `POST` e endpoint `/Form/SubmitAnswers`; a nova tentativa repete somente o GET, e campos, CSRF, validações e submissão continuam no core;
- diagnósticos de formulários projetados e sanitizados no servidor, ausentes do modelo público e liberados somente a quem possui o direito nativo de atualizar configurações;
- resolução única da instalação Formcreator em `plugins` ou `marketplace`, reutilizada no catálogo, na abertura e no envio, sem caminho fornecido pelo cliente e com alternativa nativa conservadora quando a raiz não puder ser comprovada;
- incorporação mínima opcional do Formcreator 2.13 no GLPI 10, controlada por gate server-side e guardas de origem, rota, ID, versão e estrutura; qualquer divergência preserva a interface nativa completa;
- redução visual limitada à casca reconhecida do Formcreator, sem ocultar campos, ajuda, validações, anexos, mensagens, CSRF ou envio;
- fingerprint vertical institucional versionado, aplicado apenas quando o formulário Formcreator, o identificador, o CSRF e o único envio esperado forem comprovados; qualquer divergência mantém a interface completa;
- chatbot operacional com políticas de intenção, mascaramento de dados e encaminhamento seguro;
- FAQ, cockpit e playbooks para orientar atendimento e operação;
- cockpit com cinco indicadores textuais e acionáveis, calculados pela Search API no contexto autorizado, com período, escopo, horário de referência e detalhamento equivalente na lista de chamados;
- indicadores do cockpit diferenciados visualmente sem depender de cor, com os metadados completos recolhidos em `Detalhes do indicador`;
- estado explícito de resultado indisponível quando uma contagem exata não puder ser comprovada, sem converter falha em zero;
- indicador de chamados dos grupos responsáveis com zero exato somente quando o conjunto oficial de grupos estiver resolvido e vazio; os outros quatro indicadores continuam independentes;
- configuração administrativa e diagnóstico local de acessibilidade, com separação entre violações confirmadas e revisões manuais e detalhes técnicos limitados que não persistem nem transmitem conteúdo da página.
- textos administrativos e diagnósticos de formulários dinâmicos traduzidos pelo mesmo domínio Gettext, mantendo códigos internos apenas nas superfícies autorizadas;

## Fluxo de uma requisição

1. Um arquivo em `front/` carrega o bootstrap do GLPI; na entrada anônima, a política decide entre redirecionamento nativo e ponte compatível antes de preparar o formulário.
2. O controlador confirma sessão, contexto, CSRF quando aplicável e permissão.
3. Um serviço de aplicação coordena o caso de uso.
4. Regras de domínio validam a entrada e o contrato.
5. Um repositório ou adaptador consulta as APIs e tabelas do GLPI.
6. Um presenter prepara informação sem metadados internos.
7. O template gera HTML semântico e os ativos adicionam interação progressiva.

## Organização das pastas

| Pasta | Responsabilidade |
|---|---|
| `front/` | Pontos de entrada HTTP do plugin |
| `src/Application/` | Casos de uso e orquestração |
| `src/Domain/` | Políticas, entidades e contratos de negócio |
| `src/Infrastructure/` | Repositórios, pesquisa, auditoria, segurança e persistência |
| `src/Model/` | Modelos de tabelas próprias do plugin |
| `src/Security/` | CSRF, sanitização e guarda de contexto |
| `src/Support/` | Bootstrap, contêiner, compatibilidade e utilitários |
| `src/UI/` | Controladores, presenters e mecanismo de views |
| `templates/` | Páginas e componentes HTML renderizados no servidor |
| `assets/` | Fontes de CSS, JavaScript, imagens e dependências inventariadas |
| `public/` | Ativos publicados para o navegador |
| `locales/` | Catálogos Gettext |
| `sql/` | Instalação e remoção das tabelas próprias |
| `tests/` | Testes unitários, de integração e navegador |
| `tools/` | Compilação, verificação, i18n, acessibilidade e homologação |
| `docs/` | Arquitetura, operação, segurança, testes, roadmaps e notas de versão |

## Inventário dos arquivos de execução

### Raiz

| Arquivo | Finalidade |
|---|---|
| `setup.php` | Metadados, versão, compatibilidade, inicialização, política cacheada da entrada pré-login e registro do ativo anônimo oficial |
| `hook.php` | Hooks e integração de menu/ativos com o GLPI, incluindo a ponte compatível e o HTML estático do aviso pré-login |
| `glpiacessivel.xml` | Metadados de publicação e compatibilidade |
| `glpiacessivel.png` | Identidade visual em alta resolução usada na documentação |
| `logo.png` | Ícone local otimizado, nativo no GLPI 11 e usado pelo fallback progressivo do cartão ativo no GLPI 10 |
| `composer.json` | Dependências, autoload PSR-4 e comandos de QA PHP |
| `glpiacessivel_chatbot_check.php` | Diagnóstico de requisitos do chatbot |

### Pontos de entrada `front/`

| Arquivo | Finalidade |
|---|---|
| `acessivel.php` | Entrada principal do portal |
| `chatbot.php` | Jornada do chatbot |
| `cockpit.php` | Visão operacional |
| `config.php` | Configuração administrativa |
| `context.php` | Troca autorizada de perfil e entidade |
| `faq.php` | Perguntas frequentes |
| `form.open.php` | Resolução e abertura segura de formulário |
| `form.render.php` | Renderização ou delegação do formulário |
| `forms.php` | Catálogo de formulários |
| `knowledge.php` | Base de conhecimento |
| `playbooks.php` | Playbooks operacionais |
| `runtime-config.js.php` | Configuração JavaScript gerada no contexto da sessão |
| `ticket.action.php` | Ações mutáveis autorizadas sobre chamados |
| `ticket.create.php` | Criação de chamado |
| `ticket.php` | Redirecionador de compatibilidade pré-bootstrap para favoritos e integrações anteriores |
| `tickets.php` | Rota canônica da lista e do detalhe de chamados |
| `ticket.results.php` | Endpoint JSON dos resultados assíncronos da lista |
| `ticket.resource-selector.php` | Endpoint JSON dos seletores remotos de recursos |
| `ticket.saved-search.php` | Mutações de pesquisas salvas nativas |
| `ticket.search-values.php` | Endpoint protegido do autocomplete de filtros |

### Aplicação `src/Application/`

| Arquivo | Finalidade |
|---|---|
| `AdvancedTicketSearchRequest.php` | Traduz a submissão da busca para AST canônica |
| `ChatbotIntentPolicy.php` | Política de intenções permitidas |
| `ChatbotPlaybookService.php` | Integra chatbot e playbooks |
| `ChatbotService.php` | Fluxo conversacional e respostas operacionais |
| `ConfigService.php` | Leitura, gravação e validação fechada dos modos e preferências de configuração |
| `ContextService.php` | Usuário, perfil, entidade e contexto ativo a partir da sessão GLPI |
| `FormService.php` | Catálogo e acesso a formulários |
| `KnowledgeBaseService.php` | Pesquisa e apresentação da base de conhecimento |
| `PortalModulePolicy.php` | Disponibilidade dos módulos do portal |
| `RemoteSearchValueAuthorizer.php` | Reautoriza valores remotos de filtros |
| `SavedTicketSearchService.php` | Casos de uso de pesquisas salvas do GLPI |
| `TicketListStateStore.php` | Estado opaco e temporário da consulta assíncrona |
| `TicketSearchStateStore.php` | Tokens opacos e estado temporário da pesquisa |
| `TicketService.php` | Casos de uso de chamados |

### Formulários dinâmicos `src/Application/DynamicForm/`

| Arquivo | Finalidade |
|---|---|
| `DynamicFormFacade.php` | Seleciona o adaptador de formulário adequado |
| `FormcreatorSchemaAdapter.php` | Adapta Formcreator quando disponível |
| `FormSubmissionGate.php` | Autoriza e valida a submissão |
| `NativeTicketSchemaAdapter.php` | Adapta o formulário nativo de chamado |
| `ServiceCatalogSchemaAdapter.php` | Adapta o Service Catalog do GLPI 11 |
| `TicketTemplateSchemaAdapter.php` | Adapta modelos de chamado |

### Domínio `src/Domain/`

| Arquivo | Finalidade |
|---|---|
| `DynamicForm/DynamicFormAdapterInterface.php` | Contrato dos adaptadores de formulário |
| `DynamicForm/DynamicFormCondition.php` | Condição de exibição/validação |
| `DynamicForm/DynamicFormField.php` | Campo normalizado |
| `DynamicForm/DynamicFormSchema.php` | Esquema versionado do formulário |
| `DynamicForm/DynamicFormSection.php` | Seção normalizada |
| `DynamicForm/DynamicFormSubmissionResult.php` | Resultado da submissão |
| `DynamicForm/FormCapability.php` | Capacidades comprovadas do adaptador |
| `Pii/PiiMasker.php` | Mascaramento de informação pessoal |
| `Security/Authorization.php` | Regras comuns de autorização |
| `Ticket/NativeSearchDefinitionValidator.php` | Valida a AST e parâmetros nativos da busca |
| `Ticket/NativeSearchValidationException.php` | Erro controlado de definição de busca |
| `Ticket/SearchCriterionValueValidator.php` | Valida valores por campo e operador |
| `Ticket/SearchFieldContract.php` | Contrato autorizado de um campo |
| `Ticket/SearchOperatorValueContract.php` | Contrato de valor por operador |
| `Ticket/SearchValueKind.php` | Tipos suportados de valor |
| `Ticket/TicketCreationPolicy.php` | Política de criação de chamado |
| `Ticket/TicketPolicy.php` | Políticas de acesso e ação sobre chamado |

### Infraestrutura `src/Infrastructure/`

| Arquivo | Finalidade |
|---|---|
| `Audit/AuditLogger.php` | Registro de auditoria com minimização de dados, sem executar retenção no caminho da requisição |
| `Audit/AuditRetentionService.php` | Exclusão limitada e indexada de registros vencidos |
| `Audit/AuditRetentionCronTask.php` | Execução periódica em lotes da retenção de auditoria |
| `Search/GlpiBoundedTicketSearchGateway.php` | Orquestra a pesquisa limitada de IDs e falha fechada quando a capability não é reconhecida |
| `Search/Glpi10BoundedTicketSearchAdapter.php` | Adapta o contrato de busca limitada do GLPI 10 |
| `Search/Glpi11BoundedTicketSearchAdapter.php` | Adapta o contrato de busca limitada do GLPI 11 |
| `Search/TicketListCapacityGuard.php` | Controla capacidade, consulta única por usuário/contexto e circuito de falhas |
| `Compliance/SchemaManager.php` | Instalação e evolução do esquema próprio |
| `Repository/FormRepository.php` | Acesso aos formulários disponíveis |
| `Repository/NativeSavedSearchGateway.php` | Integração com `SavedSearch` do GLPI |
| `Repository/PlaybookRepository.php` | Persistência de playbooks e sugestões |
| `Repository/SavedTicketSearchRepository.php` | Compatibilidade histórica de pesquisas |
| `Repository/TicketRepository.php` | Pesquisa, leitura e gravação de chamados via GLPI |
| `FormCatalog/FormCatalogGateway.php` | Contrato fechado das fontes de catálogo de formulários |
| `FormCatalog/FormCatalogRequest.php` | Requisição paginada vinculada ao contexto do catálogo |
| `FormCatalog/Formcreator213CatalogGateway.php` | Adaptador autorizado e paginado do Formcreator 2.13 |
| `FormCatalog/FormcreatorNativeUrlResolver.php` | Resolve e valida no servidor a raiz nativa do Formcreator para catálogo, abertura e envio |
| `Search/GlpiResourceSelectorCursor.php` | Emite e valida cursores opacos dos seletores |
| `Search/GlpiResourceSelectorProvider.php` | Consulta e reautoriza recursos dos chamados |
| `Search/GlpiResourceSelectorRegistry.php` | Allowlist de provedores, dependências e limites |
| `Search/GlpiSearchContractResolver.php` | Resolve o contrato campo/operador/valor |
| `Search/GlpiSearchOptionCatalog.php` | Catálogo contextual de Search Options |
| `Search/GlpiSearchValueProvider.php` | Consulta paginada de valores remotos |
| `Search/GlpiSearchValueRateLimiter.php` | Limites de requisição do autocomplete |
| `Search/GlpiTicketLocalValueCatalog.php` | Valores locais como status e prioridade |
| `Search/GlpiTicketStatusCriterionCodec.php` | Preserva a semântica acessível de Status e compila a polaridade exigida pela Search API nativa |
| `Search/TicketListRateLimiter.php` | Limita chamadas ao endpoint de resultados |
| `Security/GlpiSessionContextSnapshot.php` | Captura a revisão opaca de usuário, perfil, entidade e direitos |
| `Security/IdempotencyClaim.php` | Representa uma reserva idempotente |
| `Security/IdempotencyLedger.php` | Evita repetição de mutações |

### Modelos, segurança e suporte

| Arquivo | Finalidade |
|---|---|
| `src/Model/AuditLog.php` | Modelo do registro de auditoria |
| `src/Model/Config.php` | Modelo de configuração |
| `src/Model/PiiReveal.php` | Modelo de revelação controlada de PII |
| `src/Model/Playbook.php` | Modelo de playbook |
| `src/Model/PlaybookJob.php` | Modelo de execução de playbook |
| `src/Model/PlaybookSuggestion.php` | Modelo de sugestão operacional |
| `src/Security/CsrfGuard.php` | Compatibilidade e verificação CSRF |
| `src/Security/InputSanitizer.php` | Normalização de entrada |
| `src/Security/SessionContextGuard.php` | Confirma contexto da sessão |
| `src/Support/Bootstrap.php` | Carregamento do plugin |
| `src/Support/Container.php` | Resolução das dependências internas |
| `src/Support/FormValidationException.php` | Erros controlados de formulário |
| `src/Support/GlpiCompatibility.php` | Diferenças suportadas entre GLPI 10 e 11 |
| `src/Support/I18n.php` | Tradução Gettext |
| `src/Support/LoginSourceDiscovery.php` | Descoberta das fontes de autenticação |
| `src/Support/RichTextFormatter.php` | Formatação segura de texto rico |
| `src/Support/TextNormalizer.php` | Normalização semântica de texto |
| `src/Support/TicketStatusLabels.php` | Rótulos consistentes de status |
| `src/Support/UploadedFileMapper.php` | Mapeamento seguro de anexos |
| `src/Support/Url.php` | Construção de URLs do plugin |
| `src/Support/ValidationErrorNormalizer.php` | Mensagens de validação apresentáveis |

### Interface `src/UI/`

| Arquivo | Finalidade |
|---|---|
| `Controller/BaseController.php` | Comportamentos comuns dos controladores |
| `Controller/ChatbotController.php` | Controla o chatbot |
| `Controller/CockpitController.php` | Controla o cockpit |
| `Controller/ConfigController.php` | Controla configurações, modos suportados e auditoria de alterações |
| `Controller/ContextController.php` | Controla perfil e entidade |
| `Controller/FormController.php` | Controla formulários, confirma a audiência no servidor e entrega somente a projeção correspondente |
| `Controller/KnowledgeController.php` | Controla conhecimento |
| `Controller/MenuController.php` | Monta a navegação permitida |
| `Controller/PlaybookController.php` | Controla playbooks |
| `Controller/PortalController.php` | Controla a entrada do portal e o redirecionamento anônimo ao login nativo |
| `Controller/SavedTicketSearchController.php` | Lista e gerencia pesquisas salvas |
| `Controller/TicketController.php` | Controla lista, detalhe, criação e ações de chamados |
| `Controller/TicketResultController.php` | Entrega páginas de resultados por contrato JSON autenticado, vinculado ao contexto e sem cache |
| `Controller/TicketResourceSelectorController.php` | Entrega opções paginadas dos provedores fechados de recursos de chamados |
| `Controller/TicketSearchValueController.php` | Controla valores remotos da pesquisa |
| `Presenter/FormExperiencePresenter.php` | Separa estados públicos de diagnósticos administrativos, limita metadados e valida ações locais |
| `Presenter/TicketSearchSummaryPresenter.php` | Produz o resumo acessível da consulta aplicada |
| `View/View.php` | Renderiza templates com dados controlados |

### Templates `templates/`

| Arquivo | Finalidade |
|---|---|
| `layout/header.php` e `layout/footer.php` | Estrutura, navegação, ativos e rodapé comuns |
| `portal/index.php`, `portal/login.php` e `portal/faq.php` | Entrada, autenticação e FAQ |
| `tickets/list.php` | Busca, pesquisas salvas, resumo e tabela de chamados |
| `tickets/create.php` | Criação assistida |
| `tickets/detail.php` | Detalhe e linha do tempo |
| `forms/index.php` e `forms/render.php` | Catálogo e preenchimento em linguagem funcional; diagnósticos administrativos aparecem recolhidos depois da tarefa |
| `knowledge/index.php` | Base de conhecimento |
| `chatbot/index.php` | Interface conversacional |
| `cockpit/index.php` | Indicadores operacionais |
| `playbooks/index.php` | Playbooks e sugestões |
| `config/index.php` | Configuração administrativa, inclusive a política de entrada e o aviso estático de acessibilidade no login |
| `errors/permission.php` e `errors/unavailable.php` | Erros seguros de permissão e indisponibilidade |

### Ativos, traduções e banco

| Arquivo/pasta | Finalidade |
|---|---|
| `assets/css/glpiacessivel.css` | Estilos compartilhados |
| `assets/css/portal.css` | Layout do portal |
| `assets/css/a11y-audit.css` | Interface da auditoria local |
| `assets/js/glpiacessivel.js` | Comportamentos acessíveis, busca e melhoria progressiva guardada do formulário nativo incorporado |
| `assets/js/login-accessibility-notice.js` | Reposiciona a nota depois do submit oficial, sem ler campos, com fallback na área do hook |
| `assets/js/ticket-results.js` | Carrega resultados assíncronos, descarta respostas antigas e preserva o fallback nativo |
| `assets/js/remote-resource-selector.js` | Combobox único, paginado e acessível para recursos de chamados |
| `assets/js/a11y-audit.js` | Execução local do Axe, com timeout, separação de resultados e detalhes técnicos limitados sem persistência |
| `assets/images/readme/` | Capturas públicas da documentação |
| `assets/vendor/axe-core/` | axe-core e licenças inventariadas |
| `public/assets/` | Cópias publicadas e ativos opcionais de voz |
| `locales/glpiacessivel.pot` | Catálogo mestre de mensagens |
| `locales/pt_BR.po` e `locales/pt_BR.mo` | Português do Brasil |
| `locales/en_GB.po` e `locales/en_GB.mo` | Inglês britânico |
| `sql/install.php` | Cria/atualiza estruturas próprias |
| `sql/uninstall.php` | Remove estruturas conforme política do plugin |

## Arquivos de desenvolvimento, qualidade e distribuição

| Arquivo/pasta | Finalidade |
|---|---|
| `tests/unit/` | Testes isolados de contratos, serviços e apresentação |
| `tests/integration/` | Testes de colaboração entre camadas |
| `tests/browser/` | Testes Puppeteer de teclado, foco e componentes |
| `phpunit.xml` | Configuração PHPUnit |
| `phpstan.neon` | Configuração PHPStan |
| `phpcs.xml` | Padrão PHP_CodeSniffer |
| `package.json` e `package-lock.json` | Ferramentas JavaScript de teste |
| `tools/build-release.ps1` | Gera o pacote de distribuição |
| `tools/verify-release.ps1` | Verifica o pacote gerado |
| `tools/compile-locales.ps1` | Compila catálogos Gettext |
| `tools/i18n-audit.ps1` | Verifica consistência das traduções |
| `tools/a11y/` | Captura autenticada e execução Pa11y |
| `tools/homologation/` | Preparação de massa sintética de homologação |
| `tools/phpstan/` | Stubs de compatibilidade com GLPI |
| `README.md` e `README.en.md` | Apresentação e instalação |
| `CHANGELOG.md` | Histórico funcional das versões |
| `SECURITY.md` | Política de segurança e reporte |
| `CONTRIBUTING.md`, `DCO.md` e `AUTHORS.md` | Colaboração, autoria e certificação |
| `LICENSE`, `LICENSE_POLICY.md` e `THIRD_PARTY_NOTICES.md` | Licenças e conformidade de dependências |
| `CITATION.cff` | Citação acadêmica do software |

## Operação e manutenção

- Instalar sempre o ZIP completo e executar a atualização de plugins do GLPI.
- Limpar caches do GLPI e do navegador quando uma versão alterar CSS ou JavaScript.
- Não copiar apenas arquivos isolados entre versões.
- Manter backups do banco e do diretório de plugins antes da atualização.
- Repetir homologação com perfis, entidades, recursividade, GLPI 10/11, teclado e leitores de tela representativos.
- Consultar a nota da versão em `docs/release_<versao>_<tema>.md` para mudanças, testes e limitações específicas.
