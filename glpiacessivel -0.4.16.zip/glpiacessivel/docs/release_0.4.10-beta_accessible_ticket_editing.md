# GLPI Acessível 0.4.10-beta — edição acessível do chamado

Esta versão completa o fluxo pós-abertura dentro do plugin, sem encaminhar o usuário para a interface nativa. Os dados gerais e os atores continuam submetidos às permissões, regras de negócio, entidade, recursividade e objetos nativos do GLPI 10 e 11.

## Dados gerais

O detalhe do chamado apresenta, quando o item e o perfil permitem atualização, título, descrição, tipo, categoria, localização, origem da solicitação, urgência, impacto e prioridade. O servidor aplica somente a lista fechada de campos editáveis, respeita campos obrigatórios e somente leitura do modelo e usa `Ticket->update()`.

O conteúdo HTML existente é convertido para texto legível apenas para edição. Se o usuário não alterar esse texto, o HTML original permanece intacto. Uma alteração explícita volta ao GLPI como HTML escapado e seguro, com quebras de linha preservadas. A atualização é aceita somente após releitura dos valores persistidos.

## Atores e atribuição

O formulário cobre sete conjuntos independentes:

- pessoas e grupos requerentes;
- técnicos, grupos responsáveis e fornecedores atribuídos;
- pessoas e grupos observadores.

Cada bloco é exibido somente com o direito nativo correspondente. Um campo não exibido ou omitido na requisição permanece inalterado; uma lista enviada explicitamente vazia solicita a limpeza daquele papel. Relações anônimas de requerente por e-mail não são apresentadas no seletor e são preservadas pelo servidor.

As alterações usam os payloads dinâmicos de atores processados por `CommonITILObject` nas duas versões do GLPI. O repositório prepara todas as diferenças antes da primeira escrita, abre uma transação, bloqueia a linha do chamado, confere uma revisão SHA-256 dos sete conjuntos, aplica as operações nativas e relê o estado integral. Divergência ou falha provoca rollback; resultado inconclusivo bloqueia repetição automática.

## Acessibilidade e segurança

- confirmação crítica com resumo de inclusões e remoções;
- retorno de foco ao título da seção após PRG;
- mensagens de sucesso e erro em região viva;
- rótulos, ajuda contextual, teclado e remoção com foco previsível;
- nenhum fallback obrigatório para a tela nativa;
- seletores remotos fechados por finalidade e vinculados ao chamado;
- limite de 20 atores por papel e falha fechada diante de hidratação incompleta.

## Atualização

`VERSION`, `setup.php`, XML, CFF, catálogos e o marcador comum de runtime foram atualizados para `0.4.10-beta`. O marcador `20260831-01` permite que a proteção de atualização identifique classes antigas em OPcache e execute a invalidação restrita aos arquivos PHP do plugin, sem tornar um reinício global do PHP-FPM parte do fluxo normal.

## Evidência automatizada

- PHP 8.1 e 8.3: 792 testes PHPUnit e 4.883 asserções em cada runtime;
- PHPStan: 290 arquivos, sem erros;
- PHPCS: 289 arquivos, sem erros;
- navegador: 74 cenários aprovados;
- i18n: 2.580 mensagens e 2.581 entradas de catálogo validadas.

A publicação continua condicionada à homologação real em GLPI 10 e 11, inclusive histórico, notificações, regras de negócio locais e tecnologias assistivas.
