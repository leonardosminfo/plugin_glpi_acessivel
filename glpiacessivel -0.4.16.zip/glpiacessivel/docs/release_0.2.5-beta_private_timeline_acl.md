# 0.2.5-beta - confidencialidade da timeline

## Objetivo

Fechar o bloqueador de confidencialidade encontrado na homologacao real do GLPI 10 com a versao 0.2.4-beta.

## Falha observada

O GLPI pode permitir que o autor consulte o proprio acompanhamento privado por meio da ACL individual do item, mesmo sem o direito global `SEEPRIVATE`. Por isso, delegar somente para `item->can(READ)` nao atendia a politica conservadora do portal acessivel.

## Correcao

- acompanhamentos privados exigem `Session::haveRight('followup', ITILFollowup::SEEPRIVATE)`;
- tarefas privadas exigem `Session::haveRight('task', TicketTask::SEEPRIVATE)`, com fallback para `CommonITILTask::SEEPRIVATE`;
- quando o direito nao existe, a consulta adiciona `is_private = 0` antes de carregar a timeline;
- cada linha e revalidada antes de copiar conteudo, autor, data ou visibilidade;
- a ACL nativa por item permanece obrigatoria como segunda camada;
- falhas de classe, constante, sessao ou permissao resultam em ocultacao do item privado.

## Evidencias automatizadas

- teste de regressao exige pre-filtro, revalidacao `SEEPRIVATE` e ACL nativa por item;
- sintaxe PHP validada em PHP 8.3;
- PHPUnit focado, PHPStan e PHPCS sem falhas.

## Homologacao manual

1. instalar a 0.2.5-beta em GLPI 10 e 11;
2. como Self-Service, abrir chamado que contenha nota privada e confirmar que o item nao aparece;
3. confirmar que contagem, autor, data e conteudo privados tambem nao sao expostos;
4. trocar para perfil com `SEEPRIVATE` e confirmar que o item reaparece identificado como privado;
5. repetir com tarefa privada;
6. validar com NVDA que a timeline anuncia somente os eventos autorizados.