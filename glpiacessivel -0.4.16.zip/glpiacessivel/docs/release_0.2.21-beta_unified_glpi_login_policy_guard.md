# Release 0.2.21-beta: login unificado do GLPI e guarda de politica

## Resultado

Esta versao reduz a superficie pre-autenticacao sem retirar o portal acessivel depois do login. O modo padrao `native_only` deixa usuario, senha, SSO, CAPTCHA e MFA sob responsabilidade exclusiva do GLPI ou de seu provedor de identidade.

## Configuracao entregue

A administracao passa a oferecer **Entrada antes da autenticacao** com duas escolhas:

- **Usar somente o login unificado do GLPI (recomendado):** remove o botao pre-login do plugin e redireciona a URL direta anonima ao login oficial;
- **Permitir formulario acessivel alternativo (compatibilidade):** recupera a ponte anterior para homologacao ou rollback.

A chave persistida e `authentication_entry_mode`. Ausencia, falha de leitura ou valor invalido resultam em `native_only`.

## Evolucao preparada

O dominio conhece `strict_authenticated_portal`, futuro modo de separacao entre redirecionador publico e portal autenticado. Ele nao aparece na interface, nao e aceito pelo controlador e nao pode ser ativado por POST nesta versao. A opcao so podera ser liberada depois que as rotas separadas e a matriz GLPI 10/11 forem implementadas e homologadas.

## Controles de seguranca

- o registro do hook `display_login` depende da politica cacheada;
- o proprio hook repete a verificacao como defesa em profundidade;
- `PortalController` redireciona anonimos antes de preparar o formulario alternativo;
- a URL de retorno continua local ao plugin e codificada uma unica vez;
- a mudanca administrativa exige sessao, permissao `config`, CSRF e enum suportada;
- a auditoria registra somente os modos anterior e atual;
- o atalho ja autenticado permanece separado, pois nao contorna MFA nem cria sessao.

## Compatibilidade e dados

Nao ha nova tabela nem migracao de esquema. A configuracao utiliza a tabela chave/valor existente. O GLPI 10 conserva a rota publica necessaria ao redirecionamento; o GLPI 11 conserva a estrategia de firewall existente. Em ambos, `native_only` impede que o plugin renderize campos de senha para anonimos.

## Validacao automatizada

- PHPUnit: **368 testes e 2.052 assercoes**;
- PHPStan: **sem erros**;
- PHPCS: **169 de 169 arquivos aprovados**;
- navegador: **3 de 3 testes aprovados**;
- i18n: **560 mensagens consistentes**, compiladas e verificadas com `msgfmt`;
- pacote Marketplace verificado quanto a raiz, versao, arquivos obrigatorios, caminhos proibidos e SHA-256.

## Homologacao externa necessaria

Antes da producao, validar no ambiente institucional:

- GLPI 10 e GLPI 11;
- login local, SSO e o provedor MFA escolhido;
- retorno ao portal, sessao expirada e sessao autenticada sem contexto completo;
- acesso direto a `front/acessivel.php` com cookies limpos;
- teclado, foco e leitor de tela no login nativo ou IdP.

## Geracao e verificacao

```powershell
.\tools\build-release.ps1 -Output .release_0.2.21-beta_unified_glpi_login_policy_guard -Profile marketplace -RequireMsgfmt
.\tools\verify-release.ps1 -Package .release_0.2.21-beta_unified_glpi_login_policy_guard\glpiacessivel.zip -ExpectedVersion 0.2.21-beta -PublicProfile
```

O rollback operacional consiste em selecionar `accessible_bridge`; nao exige downgrade, alteracao de URL ou migracao de banco.
