# GLPI Acessível 0.4.12-beta

## Escopo

Esta versão corrige a identificação acessível dos seletores remotos usados na edição de chamados, especialmente nos campos de localização, grupos, técnicos, fornecedores e pessoas observadoras. O ajuste é compatível com GLPI 10 e GLPI 11 e não altera os direitos, os endpoints nem os dados enviados ao servidor.

## Implementação

- cada rótulo visível recebe um identificador único e estável na página;
- o campo de pesquisa é associado ao rótulo por `for` e `aria-labelledby`;
- o `select` nativo mantido oculto recebe um nome acessível explícito;
- o campo alternativo, exibido quando o componente remoto não pode ser iniciado, preserva o mesmo nome acessível;
- referências ARIA e identificadores duplicados são evitados mesmo quando vários seletores são renderizados no mesmo formulário.

O comportamento funcional permanece nativo: permissões, entidade, recursividade, valores, pesquisa remota, seleção e submissão continuam sendo processados pelos mesmos serviços do plugin e do GLPI.

## Evidências da candidata

- regressão automatizada dos seletores remotos e do roteamento do chamado;
- suíte de navegador com 76 cenários;
- validação ao vivo no GLPI 10 dos sete conjuntos de atores, sem identificadores duplicados ou referências quebradas;
- verificação de foco e nome acessível dos campos de pesquisa;
- análise automatizada sem violação confirmada; itens heurísticos de ARIA e contraste permanecem sujeitos à revisão manual prevista no plano de testes.

## Atualização

A versão, a chave dos assets e o marcador de runtime foram renovados para `0.4.12-beta` e `20260831-03`. Isso permite distinguir o pacote da versão anterior e acionar a atualização seletiva do runtime sem exigir reinício geral do PHP-FPM quando o ambiente permite invalidação de OPcache.

## Limite de homologação

A liberação em produção continua condicionada à validação manual do ZIP final com teclado e leitor de tela (NVDA ou JAWS), além da repetição do WAVE nas instalações GLPI 10 e GLPI 11 escolhidas para homologação.
