# Plano autoritativo: pesquisas salvas somente no GLPI

## Status deste documento

Este e o plano autoritativo para a evolucao das pesquisas de chamados.

Ele substitui as propostas de copias locais e de sincronizacao bidirecional
descritas nos documentos anteriores. A premissa confirmada e:

- ainda nao existem usuarios do portal em producao;
- nao existem pesquisas locais salvas;
- toda pesquisa deve existir diretamente no GLPI;
- o plugin nao mantera copia, fork ou espelho da definicao.

## Decisao arquitetural

`SavedSearch` e `SavedSearch_User` serao as unicas fontes de verdade.

O portal acessivel ira:

- listar pesquisas nativas autorizadas;
- explicar seus criterios em linguagem acessivel;
- aplicar a pesquisa pela Search API;
- criar pesquisas privadas no GLPI;
- editar, excluir, publicar e definir padrao quando o GLPI autorizar;
- abrir a pesquisa na interface nativa quando ainda nao puder reproduzi-la.

O portal nao ira:

- salvar filtros na tabela do plugin;
- importar ou duplicar uma pesquisa para torna-la editavel;
- manter padrao separado;
- reconciliar versoes;
- sobrescrever alteracao externa silenciosamente;
- executar uma aproximacao de pesquisa incompativel.

## Propriedade dos dados

| Dado | Fonte |
|---|---|
| Nome e definicao da pesquisa | `SavedSearch` do GLPI |
| Criterios, metacriterios e operadores | `SavedSearch` do GLPI |
| Ordenacao, visibilidade, entidade e recursividade | `SavedSearch` do GLPI |
| Pesquisa padrao | `SavedSearch_User` do GLPI |
| Autorizacao | modelos, perfil, entidade e ACL do GLPI |
| Execucao | Search API do GLPI |
| Preferencias visuais com equivalente nativo | infraestrutura de preferencias do GLPI |
| Preferencias sem equivalente nativo | somente requisicao ou sessao; nao fazem parte da pesquisa |
| Rascunho nao salvo | sessao temporaria com expiracao |
| Auditoria tecnica | plugin, sem nome, query ou valores pesquisados |

Nao sera criada persistencia local por usuario para pesquisa, AST, filtros,
valores, nome, ID nativo ou padrao.

## Arquitetura alvo

```mermaid
flowchart LR
    UI["Portal acessivel"] --> Catalog["NativeSavedSearchCatalog"]
    UI --> Commands["NativeSavedSearchCommandService"]
    UI --> Executor["NativeTicketSearchExecutor"]
    Catalog --> Gateway["NativeSavedSearchGateway GLPI 10/11"]
    Commands --> Gateway
    Gateway --> Models["SavedSearch / SavedSearch_User"]
    Gateway --> Analyzer["NativeSearchAnalyzer"]
    Analyzer --> AST["NativeSearchDefinition"]
    AST --> Executor
    Executor --> Search["Search API do GLPI"]
```

Componentes:

- `NativeSavedSearchGateway`: compatibilidade GLPI 10/11, leitura e CRUD;
- `NativeSavedSearchCatalog`: busca, paginacao, padrao e resolucao direta;
- `NativeSearchDefinition`: AST canonica e imutavel;
- `NativeSearchAnalyzer`: capacidade, validacao e resumo;
- `NativeTicketSearchExecutor`: execucao paginada e fail-closed;
- `NativeSavedSearchCommandService`: autorizacao, transacao, conflito e auditoria;
- `SavedSearchCursor`: cursor opaco, assinado e vinculado ao contexto.

O servico de aplicacao nao deve escrever diretamente nas tabelas nativas.
Mutacoes usam os modelos do GLPI. Leituras paginadas podem usar a camada
estruturada de banco do GLPI para prefiltrar o catalogo, mantendo
`SavedSearch::can()` como verificacao final.

## Remocoes do desenho atual

Na implementacao, remover:

- tabela `glpi_plugin_glpiacessivel_ticketviews`;
- modelo `TicketView`;
- persistencia e CRUD de pesquisas locais;
- `source_savedsearches_id`;
- `copyable` e `copy_filters`;
- importacao e `Criar copia editavel`;
- origem `portal`;
- padrao local;
- agrupamento do catalogo por origem;
- testes e documentacao que prometem copia local;
- dependencia da resolucao direta em uma lista limitada.

O nome `SavedTicketSearchRepository` deve ser substituido ou ter sua
responsabilidade reduzida ao gateway nativo. Ele nao deve continuar misturando
catalogo, persistencia local, AST e execucao.

## Estados de capacidade

Sem copias, os estados passam a ser:

- `editable`: pode ser aplicada e editada integralmente no portal;
- `executable_read_only`: pode ser aplicada fielmente, mas a edicao permanece no GLPI;
- `native_only`: ainda nao pode ser executada fielmente; oferecer `Abrir no GLPI`;
- `unavailable`: excluida, revogada, corrompida ou fora do contexto.

Uma pesquisa nunca muda de estado por descarte de criterio. Campo, operador,
metacriterio ou parametro desconhecido rebaixa a capacidade.

A ampliacao futura da cobertura de `native_only`, incluindo diagnostico
administrativo, registro central de capacidades, adaptadores incrementais e
prova de equivalencia por IDs em GLPI 10 e 11, esta detalhada em
`review_future_saved_search_compatibility.md`. Essa evolucao preserva este plano
autoritativo: o GLPI continua como fonte unica e nenhuma consulta pode ser
aproximada para parecer compativel.

## AST e paridade avancada

`NativeSearchDefinition` deve preservar:

- `itemtype=Ticket`;
- grupos aninhados;
- `AND`, `OR`, `AND NOT` e `OR NOT`;
- criterios meta legados e modernos;
- itemtype relacionado, campo, operador e valor;
- multiplas ordenacoes;
- escopo de lixeira;
- parametros com impacto semantico;
- versao do contrato e fingerprint.

Campos, operadores e relacoes devem ser descobertos no GLPI ativo e
intersectados com a matriz homologada do plugin. Nao ampliar apenas uma
allowlist fixa.

Orcamento inicial, aplicavel tambem a pesquisas vindas do GLPI:

- ate 64 KiB de definicao;
- ate 600 folhas de parametros;
- profundidade maxima 8;
- ate 100 criterios;
- ate 25 metacriterios;
- ate 5 ordenacoes;
- ate 50 colunas;
- ate 4 KiB por valor;
- pagina maxima de 100 itens.

Excesso, timeout ou operador nao homologado resulta em `native_only`, nunca
em truncamento.

## Experiencia acessivel

### Catalogo unico

O heading sera `Pesquisas salvas do GLPI`.

Controles:

- campo `type="search"` e botao explicito;
- filtros por privada/publica, entidade, capacidade e padrao;
- pesquisa padrao exibida diretamente, mesmo fora da pagina atual;
- lista de 25 pesquisas por pagina;
- cada pesquisa como artigo com heading proprio;
- metadados textuais de visibilidade, entidade, recursividade, capacidade e padrao;
- acoes com nome completo da pesquisa;
- paginacao anterior/proxima em `nav` nomeada;
- texto do intervalo quando o total for confiavel.

Nao usar:

- seletor com centenas de opcoes;
- `Carregar mais` com DOM crescente;
- rolagem infinita;
- virtualizacao na experiencia assistiva principal;
- navegacao automatica ao mudar um `select`.

Apos pesquisar ou paginar, focar o heading dos resultados e anunciar uma vez
o intervalo novo.

### Pesquisa simples

- `Aplicar sem salvar` executa a definicao sem criar objeto;
- `Salvar como nova pesquisa no GLPI` cria `SavedSearch` privada;
- `Atualizar pesquisa X no GLPI` altera a pesquisa original;
- nenhuma selecao executa automaticamente;
- depois de aplicar, focar `Lista de chamados`;
- depois de salvar, focar a mensagem e oferecer `Aplicar agora` e `Voltar ao catalogo`.

### Pesquisa avancada

- cada grupo logico em `fieldset` com `legend`;
- cada condicao informa grupo e posicao;
- radios em linguagem simples para todas/qualquer;
- negacao separada;
- botoes adicionar, duplicar, mover e remover;
- nenhuma dependencia de arrastar;
- foco deterministico depois de adicionar, mover ou remover;
- resumo textual auditavel da logica;
- resumo de erros focado;
- `aria-invalid` e `aria-errormessage`;
- dados preenchidos preservados.

Metacriterios so ficam editaveis depois de round-trip e comparacao de resultados
aprovados em GLPI 10 e 11.

### Campos com muitos valores

Usuarios, grupos, entidades, ativos e categorias usam busca server-side
paginada:

- busca por botao explicito;
- resultados HTML nativos;
- rotulos contextualizados;
- anterior/proxima;
- foco e anuncio deterministas;
- preservacao do valor selecionado.

Nao usar `select` gigante. Combobox customizado exige homologacao completa e
nao pode eliminar a alternativa HTML nativa.

### Exclusao

Preferir pagina de confirmacao dedicada.

Ela deve informar:

- nome da pesquisa;
- que a exclusao sera feita diretamente no GLPI;
- visibilidade publica e impacto em outros usuarios;
- se e o padrao;
- entidade e recursividade.

Exigir confirmacao explicita:

> Confirmo a exclusao permanente da pesquisa X no GLPI.

Depois do readback:

- anunciar o resultado;
- focar o proximo item;
- na ausencia, focar o heading do catalogo;
- nunca abrir uma consulta mais ampla.

### Padrao

Existe apenas `Pesquisa padrao do GLPI para chamados`.

- resolver por ID, fora da paginacao;
- definir e desmarcar pelo modelo nativo;
- serializar concorrencia por usuario e `Ticket`;
- fazer readback;
- se perder autorizacao, falhar fechado e anunciar indisponibilidade.

## CRUD nativo e seguranca

### Criar

- POST e CSRF;
- `type=SEARCH`, `itemtype=Ticket`, proprietario e ID definidos pelo servidor;
- privada por padrao;
- publica apenas com direito nativo;
- entidade validada no contexto;
- URL canonica gerada da AST;
- `SavedSearch::add()` e readback.

### Atualizar e excluir

1. validar CSRF e nonce de acao;
2. validar contexto que originou o formulario;
3. iniciar transacao;
4. adquirir lock em ordem deterministica;
5. recarregar a pesquisa;
6. executar `SavedSearch::can()` sob o lock;
7. comparar fingerprint;
8. conferir chave idempotente;
9. executar a API nativa;
10. registrar auditoria sem conteudo pesquisado;
11. fazer readback;
12. confirmar a transacao.

Em conflito:

- retornar estado de conflito, sem sobrescrever;
- focar alerta;
- oferecer `Recarregar versao do GLPI`, `Revisar alteracoes`,
  `Salvar como nova pesquisa no GLPI` e `Cancelar`.

Se o ambiente nao fornecer transacao e lock confiaveis, as mutacoes ficam
desativadas e o catalogo permanece somente leitura.

### Direitos

- listar, abrir e executar: `can(READ)`;
- atualizar: `can(UPDATE)`;
- excluir: direito nativo correspondente;
- padrao: leitura autorizada para o usuario atual;
- publicar, alterar entidade ou recursividade: direito nativo especifico;
- ACL de cada chamado continua aplicada pela Search API.

O ID recebido nunca concede acesso.

## Catalogo sem limite de 200

- paginacao keyset com cursor opaco e assinado;
- pagina inicial de 25;
- `page_size + 1` para `has_more`;
- usuario, privacidade e entidade antes do limite;
- `SavedSearch::can()` como defesa final;
- busca por nome;
- ordenacao estavel com ID como desempate;
- padrao e lookup direto independentes da pagina;
- nenhuma constante global de 200;
- nenhuma contagem integral obrigatoria.

O cursor deve ser vinculado a usuario, perfil, entidade, termo, ultima chave
e expiracao.

Cache somente de metadados e capacidade, com chave contendo:

- versao exata do GLPI;
- ID e fingerprint;
- usuario;
- perfil;
- entidade e recursividade;
- capacidades dos plugins relevantes.

Nao cachear resultados ou decisoes de ACL.

## Chamados sem varredura de 500

Pesquisas salvas usam somente a Search API.

- paginacao nativa de 20, 50 ou 100;
- ordenacao estavel;
- ID como desempate quando suportado;
- total opcional;
- hidratacao de rotulos em lote;
- memoria proporcional a pagina;
- nenhum `Ticket::find()` para aproximar pesquisa salva;
- nenhuma ampliacao em falha;
- falha retorna lista vazia, explicacao e link nativo;
- timeout, rate limit e circuit breaker para consultas caras.

Se o total nao for confiavel:

- anunciar `pelo menos N`;
- omitir ultima pagina;
- oferecer somente anterior/proxima;
- nunca anunciar parcial como completo.

## Preferencias de exibicao

As preferencias ficam em uma regiao separada `Exibicao da lista`.

Podem incluir:

- colunas visiveis e ordem;
- itens por pagina;
- densidade;
- agrupamento apenas visual;
- tema, contraste e tamanho da fonte.

Regra:

1. usar a preferencia nativa do GLPI quando houver equivalencia;
2. caso contrario, manter somente na requisicao ou sessao;
3. nunca inserir preferencia visual na definicao da pesquisa sem contrato nativo;
4. nunca persistir no plugin nome, AST, filtros, valores ou ID da pesquisa.

## Limpeza segura do schema local

Nao existe migracao de dados.

Na atualizacao:

1. verificar se `glpi_plugin_glpiacessivel_ticketviews` existe;
2. contar os registros;
3. remover a tabela somente se a contagem for zero;
4. abortar a limpeza se aparecer qualquer registro inesperado;
5. alertar o administrador sem registrar nome, filtros ou conteudo;
6. remover a criacao da tabela em instalacoes novas;
7. remover modelo, servicos, controllers, templates e testes locais;
8. adicionar gate que falha se restar referencia ativa a `ticketviews`.

Isso e um preflight de seguranca, nao uma migracao.

## Feature flags e rollout

Flags:

1. `saved_search_catalog_v2`;
2. `saved_search_advanced_execution`;
3. `saved_search_private_write`;
4. `saved_search_default_write`;
5. `saved_search_public_write`.

Ordem:

1. catalogo paginado e lookup direto;
2. execucao nativa somente leitura;
3. criacao e CRUD privado;
4. padrao nativo;
5. editor avancado por capacidade;
6. escrita publica;
7. retirada definitiva do fallback para pesquisas salvas.

Flags de escrita comecam desligadas. Quando desligadas, a interface oferece
somente leitura e `Abrir no GLPI`.

## Roadmap proposto

### `0.2.8-beta` — origem unica e escala

- preflight e remocao segura da tabela vazia;
- remocao do modelo de copias;
- gateway GLPI 10/11;
- catalogo paginado;
- busca por nome;
- padrao e lookup direto;
- pesquisa simples criada diretamente no GLPI;
- Search API obrigatoria para pesquisas salvas.

### `0.2.9-beta` — paridade avancada

- AST canonica;
- resumo textual;
- AND, OR e negacoes aninhadas;
- multiplas ordenacoes;
- metacriterios homologados por fatias;
- editor avancado acessivel;
- comparacao diferencial GLPI 10/11.

### `0.3.0-beta` — escrita completa e robustez

- CRUD privado completo;
- padrao nativo;
- publicacao, entidade e recursividade;
- fingerprint, lock, idempotencia e conflito;
- carga, rate limit e circuit breaker;
- auditoria e telemetria finais.

### `0.3.0-rc` — homologacao

- matriz assistiva;
- matriz de ACL;
- concorrencia e falhas injetadas;
- escala;
- rollback;
- integridade e proveniencia do pacote.

## Rollback

Rollback funcional:

- desligar flags de escrita;
- manter pesquisas e padroes no GLPI;
- nunca excluir objeto nativo automaticamente;
- retornar a interface a somente leitura.

Rollback para a versao anterior:

- recriar `ticketviews` vazia com o schema antigo antes do downgrade;
- nao fabricar copias locais;
- documentar que casos avancados podem voltar a `native_only`.

Nao existe conteudo local a restaurar.

## Testes obrigatorios

### Contrato GLPI 10/11

- catalogo, lookup direto e padrao;
- add, update, delete e default;
- pesquisa privada propria, privada alheia, publica e recursiva;
- entidade autorizada e revogada;
- campo adicionado/removido por plugin;
- round-trip da AST;
- equivalencia de IDs, ordem, total e paginas;
- alteracao externa entre leitura e commit.

### Escala

- pesquisas nas posicoes 201 e 1.000;
- 10.000 pesquisas com mistura de ACL;
- mais de 500 e dezenas de milhares de chamados;
- memoria e consultas proporcionais a pagina;
- insercao e exclusao entre paginas;
- timeout, rate limit e abertura do circuito.

Metas iniciais:

- pagina de 25 em catalogo de 1.000 pesquisas: p95 ate 2 segundos;
- primeira pagina de 10.000 chamados: p95 ate 3 segundos;
- paginas seguintes: p95 ate 2 segundos.

### Seguranca

- CSRF ausente, expirado e replay;
- IDOR em cada operacao;
- troca de usuario, perfil ou entidade;
- TOCTOU;
- update/delete concorrente;
- disputa de padrao;
- nonce e idempotencia;
- deadlock e retry limitado;
- query excessiva ou malformada;
- auditoria sem conteudo pesquisado;
- preflight de tabela vazia e tabela inesperadamente preenchida.

### Acessibilidade

- catalogo, busca e paginacao;
- aplicar sem salvar;
- criar e atualizar no GLPI;
- construtor avancado;
- campos de grande cardinalidade;
- conflito;
- confirmacao e recuperacao de foco apos exclusao;
- padrao;
- total desconhecido;
- teclado;
- zoom de 400% e 320 CSS px;
- `forced-colors`;
- NVDA com Firefox e Chrome;
- JAWS com Edge e Chrome;
- VoiceOver com Safari;
- GLPI 10 e 11.

Cada evidencia deve relacionar requisito, WCAG 2.2 AA/eMAG, teste,
combinacao assistiva, resultado e artefato.

## Gates de release

Bloquear a release se houver:

- referencia ativa a pesquisa ou padrao local;
- tabela antiga removida sem preflight vazio;
- escape de ACL, IDOR, CSRF ou replay;
- consulta parcial ou ampliada silenciosamente;
- divergencia de IDs ou ordem em contrato homologado;
- conflito que sobrescreva alteracao externa;
- mais de um padrao efetivo;
- corte depois da pesquisa 200;
- fallback de 500 para pesquisa salva;
- falha de rollback;
- auditoria com nome, URL, query, termo ou valor;
- falha seria/critica automatizada;
- fluxo essencial reprovado com leitor de tela;
- meta de desempenho reprovada;
- falha em PHPCS, PHPStan, PHPUnit, i18n ou deteccao de mojibake;
- dependencia vulneravel ou licenca sem evidencia;
- segredo, dado pessoal ou arquivo proibido no ZIP;
- manifesto, SBOM, proveniencia ou SHA-256 divergente.

## Criterios de aceite finais

1. Criar uma pesquisa no portal a faz aparecer imediatamente no GLPI.
2. Editar, excluir ou definir padrao altera o objeto original autorizado.
3. Alteracao feita no GLPI aparece no portal na leitura seguinte.
4. Nao existe pesquisa, copia ou padrao salvo pelo plugin.
5. Pesquisa 201 ou 1.000 pode ser encontrada e aplicada.
6. Navegacao ultrapassa 500 chamados sem perda ou fallback.
7. Pesquisa avancada homologada devolve os mesmos IDs e ordem do GLPI.
8. Pesquisa nao homologada permanece no GLPI sem aproximacao.
9. Usuario cego conclui todos os fluxos sem assistencia visual.
10. Qualquer falha de ACL, contexto, concorrencia ou execucao e fechada.

## Referencias primarias

- [SavedSearch no GLPI 10](https://github.com/glpi-project/glpi/blob/10.0/bugfixes/src/SavedSearch.php)
- [SavedSearch no GLPI 11](https://github.com/glpi-project/glpi/blob/11.0/bugfixes/src/SavedSearch.php)
- [Search no GLPI 10](https://github.com/glpi-project/glpi/blob/10.0/bugfixes/src/Search.php)
- [Search no GLPI 11](https://github.com/glpi-project/glpi/blob/11.0/bugfixes/src/Search.php)
