# GLPI Acessível 0.4.11-beta — confirmação da edição geral

Esta correção completa o fluxo de edição acessível dos dados gerais introduzido na versão anterior. Salvar título, descrição, tipo, categoria, localização, origem, urgência, impacto ou prioridade agora exige uma decisão explícita antes da mutação no GLPI 10 ou 11.

## Confirmação vinculada ao servidor

- o servidor emite um token aleatório de uso único para `general_update`, vinculado ao usuário autenticado e ao identificador do chamado;
- a requisição deve conter simultaneamente o token válido e a marca de confirmação explícita;
- o token é consumido na primeira validação e não pode ser reutilizado;
- CSRF, direitos nativos, entidade, recursividade, revisão concorrente e releitura continuam sendo validados pelo fluxo existente.

## Experiência acessível

- o diálogo informa a consequência e lista somente os campos efetivamente alterados;
- valores de listas são apresentados pelo rótulo visível, sem expor identificadores internos;
- a descrição é tratada como conteúdo sensível: o diálogo informa que ela será alterada, mas não reproduz o texto;
- textos são montados com nós DOM e `textContent`, sem injetar HTML recebido dos campos;
- nenhum diálogo ou envio ocorre quando não há mudança;
- erros de validação e de seletores remotos permanecem prioritários;
- cancelar restaura o foco e confirmar preserva o botão que iniciou o envio.

## Compatibilidade e atualização

A correção mantém o contrato dos demais formulários críticos, inclusive atribuição e observadores. A versão `0.4.11-beta` e o marcador `20260831-02` garantem que uma instalação `0.4.10-beta` detecte o novo runtime, renove a chave dos assets e invalide somente os arquivos PHP do plugin elegíveis, sem usar `opcache_reset()`.

## Evidência automatizada

- PHP 8.1 e 8.3: 795 testes PHPUnit e 4.907 asserções em cada runtime;
- PHPStan sem erros e PHPCS sem erros nos arquivos alterados;
- testes de navegador da confirmação, atribuição e seletores remotos aprovados;
- assets JavaScript de fonte e publicação com SHA-256 idêntico.

A liberação continua condicionada à atualização real e à homologação assistiva do mesmo ZIP nos GLPI 10 e 11.
