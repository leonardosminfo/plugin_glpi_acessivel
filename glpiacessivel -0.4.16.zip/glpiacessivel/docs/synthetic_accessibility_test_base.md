# Synthetic accessibility test base

This dataset supports controlled usability and assistive-technology sessions. It contains only synthetic names and content marked with `[A11Y-QA]`.

## Safety model

- The command is dry-run by default.
- Apply mode requires the explicit token `CREATE_SYNTHETIC_A11Y_DATA`.
- Apply mode also requires the explicit disposable-environment marker `DISPOSABLE_LOCAL_GLPI` (the Docker helper supplies both confirmations).
- It uses GLPI model classes instead of direct SQL.
- It is idempotent: records are found by stable names or ticket `externalid`.
- Ordinary synthetic users are disabled and have no password.
- `qa.task.candidate` is the sole active selector fixture: an exact ownership marker is required before reuse, its unreported random password is rotated and its API/personal/cookie tokens are revoked on every apply.
- The selector candidate receives exactly one controlled assignment: an explicitly supplied or previously assigned profile accepted by the non-administrative policy, or the native `Technician`/`Hotliner` profile when it has `Ticket::OWN`. Stale assignments on this fixture-owned account are removed inside the transaction. `Admin` and `Super-Admin` are always refused. Use `--task-profile-id=N` only for a reviewed central profile.
- Apply mode is one database transaction; any failed proof rolls the complete fixture run back.
- The script is stored under `tools/` and is not included in the release ZIP.

Never run it in production. Use a disposable database snapshot that can be restored after the sessions.

## Local Docker

Preview:

```powershell
.\tools\homologation\seed-local-docker.ps1
```

Create or reuse the records:

```powershell
.\tools\homologation\seed-local-docker.ps1 -Apply
```

The command prints a JSON manifest with every created or reused ID.

## Test accounts

The following disabled accounts are prepared:

| Login | Intended profile |
| --- | --- |
| `qa.selfservice` | Self-Service |
| `qa.hotliner` | Hotliner |
| `qa.manager` | Supervisor or Admin |
| `qa.multiperfil` | Self-Service and Hotliner in different entities |
| `qa.admin` | Super-Admin |

Before an assisted session, activate only the account needed for the scenario and set a temporary password in the native GLPI user screen. Disable it again after the session.

The additional `qa.task.candidate` account remains active solely so native technician selectors can prove eligibility. Its password is never printed or stored by the fixture and it is not intended for interactive login.

## Generated coverage

- hierarchical entities;
- requester and assignment groups;
- visible ITIL categories;
- disabled synthetic users and profile assignments;
- own, assigned, group, solved and other-entity tickets;
- simple, nested and assigned-group native saved searches, plus a deliberately unsupported native-only negative case;
- public and restricted knowledge articles.

Dynamic forms and attachments are not created automatically because their contracts vary across GLPI 10, GLPI 11 and Formcreator. Prepare those fixtures through the native engine of the exact version under test.

## Blind-user presentation sequence

1. Start at the accessible login and listen to the page title and instructions.
2. Confirm profile and entity after authentication.
3. Search the knowledge base and open a public article.
4. List tickets and open the synthetic own ticket.
5. Create a request and correct one required-field error.
6. Use the chatbot for a read-only query, then cancel a write action.
7. With `qa.multiperfil`, apply the other profile, wait for the reload and then choose an allowed entity.
8. Confirm that restricted articles and tickets outside the active ACL are absent.
9. Repeat with keyboard only, 200% text, 400% reflow and high contrast.
10. Record the exact announcement, focus location, task result and any required visual assistance.

Automated Axe/Pa11y checks must be run before the assisted session, but they do not replace NVDA, JAWS or VoiceOver validation.
