# Release 0.2.23-beta: refinamento do aviso acessivel no login

## Resultado

Esta versao refina o aviso opcional exibido na tela oficial de login. A mudanca melhora sua identificacao por leitor de tela e sua apresentacao no GLPI 10 e 11, sem transformar a mensagem em acao e sem reabrir uma superficie de autenticacao do plugin.

## Texto e semantica

A mensagem passa a ser direta:

> Portal Acessivel disponivel apos o login.

O contenedor recebe `role="note"` e o nome acessivel **Informacao de acessibilidade**. O texto permanece em um paragrafo real. O icone continua decorativo com `aria-hidden="true"` e foi reduzido para 32 px.

O aviso nao recebe `tabindex` nem `aria-live`. Assim, nao cria parada artificial por Tab e nao interrompe o leitor de tela com um anuncio dinamico para conteudo que ja nasce na pagina.

## Apresentacao compativel

O bloco passa a utilizar classes visuais fornecidas pelo proprio GLPI/Bootstrap: caixa informativa, flexbox, alinhamento, espacamento e texto alinhado ao inicio. Isso preserva uma apresentacao reconhecivel mesmo quando o GLPI 10 nao carrega o CSS anonimo especifico do plugin.

O hook oficial `DISPLAY_LOGIN` continua sendo usado. A nota permanece na area auxiliar definida pelo GLPI, sem sobrescrever o template do core e sem JavaScript para mover elementos dentro do formulario.

## Fronteira de seguranca

- nenhum link, botao, formulario, campo ou `href` e produzido;
- nenhum JavaScript especifico do aviso e executado;
- senha, SSO, MFA, CAPTCHA e sessao continuam sob responsabilidade do GLPI ou IdP;
- `accessible_bridge` continua substituindo a nota, evitando duplicidade;
- a preferencia administrativa e a politica `native_only` permanecem inalteradas.

## Validacao automatizada

- PHPUnit: **374 testes e 2.071 assercoes**;
- PHPStan: **sem erros** em 170 arquivos analisados;
- PHPCS: **169 de 169 arquivos aprovados**;
- navegador: **3 de 3 testes aprovados**;
- i18n: **567 mensagens consistentes**, compiladas e verificadas com `msgfmt`;
- regressao especifica para `role="note"`, nome acessivel, classes nativas, icone de 32 px e ausencia de `tabindex`, `aria-live` ou controles;
- pacote Marketplace verificado quanto a estrutura, versao, documentos e SHA-256.

## Homologacao externa necessaria

Depois da instalacao, validar:

- leitura sequencial e navegacao por formularios com NVDA, JAWS ou VoiceOver;
- ausencia de parada adicional na ordem de Tab;
- identificacao da nota por navegacao semantica;
- contraste, reflow, ampliacao e cores forcadas;
- apresentacao no GLPI 10 e no GLPI 11;
- aviso habilitado, desabilitado e modo `accessible_bridge`.

## Geracao e verificacao

```powershell
.\tools\build-release.ps1 -Output .release_0.2.23-beta_accessible_login_notice_refinement -Profile marketplace -RequireMsgfmt
.\tools\verify-release.ps1 -Package .release_0.2.23-beta_accessible_login_notice_refinement\glpiacessivel.zip -ExpectedVersion 0.2.23-beta -PublicProfile
```

Nao ha tabela, coluna ou migracao de esquema nova.
