# Roadmap 0.2.25-beta - catalogo autorizado do Formcreator

## Estado e prioridade

- Versao-alvo: `0.2.25-beta`.
- Prioridade: P0; a lista de formularios e um fluxo essencial do portal.
- Origem: divergencia reproduzida na homologacao em 13 de agosto de 2026.
- Revisao: plano construido com pareceres de integracao GLPI/Formcreator, seguranca/ACL e acessibilidade/QA.
- Gate: a versao nao deve ser liberada para piloto enquanto formularios autorizados no Formcreator nativo puderem desaparecer do portal ou um item nao autorizado puder ser listado/aberto.

Este roteiro tecnico integra o plano mestre `roadmap_0.2.25-beta_correction_plan.md`. A correcao de formularios pode ser implementada e testada separadamente, mas participa dos gates da mesma versao.

## Problema confirmado

Na homologacao, o portal detecta o Formcreator ativo, mas devolve zero itens. A implementacao atual:

1. cria uma instancia vazia de `PluginFormcreatorForm`;
2. executa `find()` com limite global de 80;
3. chama `canViewForRequest($id)` na instancia ainda vazia;
4. converte qualquer excecao em lista vazia.

No Formcreator 2.13.x, `canViewForRequest()` nao recebe ID e devolve `false` quando o objeto ainda e novo. O metodo espera uma instancia carregada. Por isso, todos os formularios sao descartados.

Corrigir apenas a assinatura nao e suficiente. A consulta propria atual tambem nao reproduz integralmente `is_visible`, idioma/traducao, acesso restrito, entidades/recursividade e hooks nativos. O limite e aplicado antes da autorizacao e `resolveForm()` procura o ID somente dentro dessa lista limitada.

## Contratos nativos que sao fonte de verdade

### Consulta coletiva

`PluginFormcreatorForm::getFormListQuery()` fornece a base autorizada do catalogo e incorpora:

- ativo, visivel e nao excluido;
- entidade e recursividade;
- idioma original, neutro ou traducao para o idioma da sessao;
- acesso por perfil, usuario e grupo;
- hook coletivo `formcreator_restrict_forms`.

### Validacao individual

Uma nova instancia carregada com `getFromDB($id)`, seguida de `canViewForRequest()` sem argumentos, complementa a consulta com:

- sessao e entidade atuais;
- restricoes individuais;
- hook singular `formcreator_restrict_form`;
- alteracoes de permissao ocorridas entre listagem e abertura.

As duas camadas sao obrigatorias. Consulta direta da tabela, `rowVisibleInCurrentEntity()` e `can($id, READ)` nao sao substitutos equivalentes.

## Principios de seguranca e compatibilidade

- Formcreator 2.13.x em GLPI 10 usa o adaptador deste plano.
- GLPI 11 continua exclusivamente no Service Catalog nativo; Formcreator 3 e migrador, nao fonte operacional equivalente.
- Ausencia de classe/metodo, assinatura desconhecida, plugin inativo ou excecao devem falhar de forma fechada.
- Tabelas residuais nao provam que o plugin esta ativo.
- Nenhum fallback pode restaurar leitura direta das tabelas.
- A lista nunca autoriza abertura: toda URL direta deve repetir a verificacao nativa.
- Formulario inexistente e formulario existente sem acesso devem produzir a mesma resposta generica.
- O portal nao cria copia local do catalogo, schema ou autorizacao.

## Arquitetura proposta

Extrair do `FormRepository` um gateway especifico, por exemplo:

```text
FormCatalogGateway
|- capabilities(): FormSourceCapabilities
|- list(FormCatalogRequest): FormCatalogPage
`- findAuthorized(int id): ?FormCatalogItem

Formcreator213CatalogGateway implements FormCatalogGateway
```

`FormRepository` permanece orquestrador das fontes GLPI 11 e Formcreator. O contrato de pagina deve conter itens, cursor/pagina, `has_more`, total apenas quando exato, estado da fonte e codigo de diagnostico normalizado.

### Deteccao de capacidade

Antes de consultar:

- confirmar GLPI 10 e plugin Formcreator ativo;
- confirmar classe `PluginFormcreatorForm`;
- por reflexao, exigir `getFormListQuery()` publico, estatico, sem parametros obrigatorios e com retorno em array no formato esperado;
- exigir `getFromDB()` publico e `canViewForRequest()` publico, nao estatico;
- exigir que `canViewForRequest()` nao possua parametro obrigatorio;
- registrar versoes detectadas no diagnostico administrativo;
- retornar `unsupported_contract` quando o contrato nao for comprovado.

`isFormcreatorPluginActive()` deve retornar falso em caso de excecao, nunca verdadeiro por conveniencia.

## Plano de implementacao

### P0.1 - testes de caracterizacao

- Reproduzir o objeto vazio e comprovar que nunca e autorizado.
- Comprovar que `canViewForRequest()` e chamado sem ID e somente depois de `getFromDB()`.
- Congelar o comportamento atual de fontes ausentes antes da refatoracao.
- Criar doubles de DB, plugin, instancia e hooks capazes de medir ordem e quantidade das chamadas.

### P0.2 - gateway Formcreator 2.13

1. Obter a consulta base por `PluginFormcreatorForm::getFormListQuery()`.
2. Preservar integralmente seus joins e predicados de ACL.
3. Acrescentar apenas selecao minima, agrupamento por ID contra duplicacoes de idioma, ordenacao estavel `nome + ID` e janela de pagina. O merge de `SELECT`, `GROUPBY`, `ORDER`, `WHERE`, `START` e `LIMIT` deve preservar todas as clausulas/joins/hooks existentes e usar colunas qualificadas.
4. Buscar uma janela controlada de candidatos.
5. Para cada ID, criar nova instancia, executar `getFromDB($id)` e depois `canViewForRequest()` sem argumento.
6. Descartar negados e continuar consumindo candidatos ate preencher a pagina ou terminar a fonte.
7. Mapear os campos da instancia carregada e aplicar traducao segura no idioma atual, com fallback para o texto original.

O padrao inicial sera 24 itens, maximo 50. Preferir cursor opaco por ordenacao estavel `nome + ID`; se uma variante exigir deslocamento, o cursor deve registrar a quantidade de candidatos efetivamente consumidos. Em ambos os casos, candidatos negados nao podem ser pulados indevidamente e o cursor deve reiniciar quando `q`, fonte ou contexto mudar.

Nao apresentar total estimado como exato. Se a versao e o pipeline permitirem total autorizado confiavel sem duplicacao, ele pode ser retornado; caso contrario, a interface anuncia pagina atual e se ha mais resultados.

### P0.3 - busca e navegacao no servidor

- Remover o corte silencioso de 80 formularios.
- Oferecer busca explicita por nome e descricao, submetida por botao ou `Enter`.
- Anexar a busca somente a uma copia da consulta nativa ja autorizada, por parametros do DB e colunas permitidas; nunca substituir os predicados nativos.
- Considerar nome original e traducao quando o contrato da versao permitir.
- Preservar `q`, cursor/pagina e fonte na URL.
- Manter pagina anterior/proxima e numero da pagina; `aria-current` sera usado quando houver navegacao numerada confiavel.
- Se nao for possivel provar busca segura em uma versao, manter navegacao paginada e o link para o catalogo nativo, sem consulta aproximada.

### P0.4 - abertura direta autorizada

Substituir a busca do ID dentro de `listFormSources()` por `findAuthorized($id)`:

1. restringir a consulta nativa coletiva ao ID solicitado;
2. negar quando o ID nao pertencer ao conjunto candidato;
3. carregar uma nova instancia;
4. executar `canViewForRequest()` imediatamente antes de schema, incorporacao ou redirecionamento;
5. somente depois gerar o schema dinamico.

Alteracao de perfil, entidade, idioma, direitos, sessao ou hooks entre lista e abertura deve resultar em nova decisao. Acesso negado retorna a lista com mensagem generica e nao revela se o ID existe.

### P0.5 - retirar schema completo da listagem

`FormService::listAvailableForms()` nao deve executar `DynamicFormFacade::formSchema()` para cada card. A lista usa metadados leves. O schema completo e gerado apenas em `resolveForm()`, depois da autorizacao direta.

Memoizacao por requisicao pode reutilizar capacidades e uma instancia ja autorizada dentro da mesma operacao. Cache compartilhado fica fora desta correcao ate haver prova de necessidade e chave segura por usuario, perfil, entidade, idioma e recursividade.

### P0.6 - estados estruturados da fonte

Substituir `catch (Throwable) { return []; }` por resultado explicito:

| Estado | Significado |
|---|---|
| `not_detected` | Formcreator nao instalado |
| `inactive` | instalado, mas inativo |
| `unsupported_contract` | versao ou assinatura nao comprovada |
| `unavailable_context` | fonte indisponivel ao contexto atual |
| `ready_empty` | consulta concluida e zero itens autorizados |
| `ready` | pagina carregada integralmente |
| `partial` | falha inesperada de carga/autorizacao tornou a lista incompleta; uma negativa legitima de ACL nao e falha parcial |
| `error` | falha de API, banco ou hook |

Codigos tecnicos complementares: `native_query_failed`, `item_load_failed`, `authorization_failed`, `translation_failed` e `empty_authorized_result`. Falha de traducao usa o texto original e gera aviso tecnico; somente se o item nao puder ser representado com seguranca ela contribui para `partial` ou `error`.

O usuario comum recebe mensagem clara e link nativo seguro. Diagnostico administrativo recebe codigo de correlacao, fase, duracao, pagina e quantidades agregadas. Nao registrar login, sessao, usuario, perfil, grupo, entidade, ID/titulo/descricao do formulario, SQL, parametros, regras de acesso ou mensagem bruta da excecao.

### P0.7 - experiencia acessivel

- `ready_empty`: "Nenhum formulario esta disponivel para seu perfil e entidade atuais."
- `not_detected`: "O catalogo Formcreator nao esta instalado neste ambiente."
- `inactive`: "O catalogo Formcreator esta desativado neste ambiente."
- `unsupported_contract`: "Esta versao do catalogo ainda nao e compativel com o portal. Use o catalogo nativo."
- `unavailable_context`: "O catalogo nao esta disponivel para seu perfil e entidade atuais."
- `error`: "Nao foi possivel carregar os formularios agora. Tente novamente."
- `partial`: informar explicitamente que a lista esta incompleta.
- Disponibilizar `Tentar novamente` para `error`/`partial` e `Abrir catalogo nativo` para qualquer estado em que a URL nativa seja segura.
- Diferenciar fonte nao detectada, inativa, vazia e com erro sem expor detalhes tecnicos.
- Campo de busca com `label` visivel, botao `Pesquisar`, botao `Limpar` e submissao por `Enter`.
- Apos pesquisar, limpar ou navegar, foco intencional no titulo dos resultados com `tabindex="-1"` e anuncio unico da quantidade conhecida/pagina. Nunca mover o foco durante a carga inicial.
- Quando o total for desconhecido, anunciar, por exemplo: "24 formularios exibidos, pagina 1; ha mais resultados."
- Se houver carregamento assincrono, usar `aria-busy` durante a operacao e uma regiao `role=status`/`aria-live=polite`; erro apos acao usa `role=alert` uma unica vez.
- Pagina anterior/proxima devem ter nomes explicitos; acao indisponivel nao pode permanecer focavel.
- Cada card tem titulo unico e uma acao principal com nome "Abrir formulario: {titulo}".
- Nao associar diagnostico operacional extenso ao `aria-describedby` da acao.
- Imagem decorativa usa `alt=""`; ilustracao informativa recebe alternativa util.
- Preservar ordem logica, foco visivel, 320 CSS px, zoom de 400% e `forced-colors`.

### P0.8 - rollback seguro

Adicionar chave operacional especifica `formcreator_catalog_enabled`:

- quando desativada, o portal mantem o modulo Formularios e oferece apenas o catalogo nativo;
- nunca reativa a implementacao antiga;
- nao altera dados, tabelas ou configuracoes do Formcreator;
- deve ser acionada em falso positivo de ACL, vazamento entre contextos, erro recorrente de hook/consulta ou divergencia nativa.

A chave deve ser administrada pela mesma configuracao protegida do plugin, com valor conservador durante implantacao gradual. O rollout recomendado e Super-Admin/QA, perfis de teste e, somente apos paridade, demais usuarios.

## Matriz de testes P0

| Cenario | Evidencia obrigatoria |
|---|---|
| Formcreator ausente/inativo/tabela residual | estado correto e somente link nativo quando aplicavel |
| Contrato/API ausente ou assinatura alterada | `unsupported_contract`, falha fechada e sem leitura crua |
| Ativo, inativo, visivel, oculto e excluido | apenas ativo/visivel/nao excluido aparece e abre |
| Publico, privado e restrito | paridade por perfil, usuario e grupo |
| Entidade raiz/filha/irma | recursivo permitido e nao recursivo/alheio negado |
| Idioma neutro, atual, traduzido e incompatível | mesmo conjunto e rotulo do catalogo nativo |
| Hooks coletivo e individual | negacao respeitada; excecao falha fechada |
| Hook coletivo permite e individual nega | item ausente da pagina e da abertura direta |
| 201 formularios; primeiros candidatos negados | todas as paginas alcancaveis, IDs unicos, sem corte/omissao |
| Join de idioma duplicado | um unico card por formulario |
| Busca com acentos e zero resultado | ACL preservada, URL/estado/foco consistentes |
| Acesso direto fora da primeira pagina | autorizado abre; negado/inexistente recebem a mesma resposta |
| Troca de perfil, entidade ou sessao | reautorizacao imediata e ausencia de vazamento |
| Falha de consulta/carga/traducao | `error` ou `partial`, nunca vazio legitimo falso |
| GLPI 11 | adaptador 2.13 nao executado; Service Catalog sem regressao |
| Teclado/NVDA e navegadores | lista, busca, cards, vazio, erro e paginacao compreensiveis |

Versoes de contrato: Formcreator 2.13.0, 2.13.9, 2.13.10 e 2.13.11; homologar obrigatoriamente a versao exata instalada. Navegadores P0: Chrome, Edge e Firefox atuais. Tecnologias assistivas P0: NVDA com Chrome e Firefox; JAWS com Edge quando disponivel na homologacao institucional.

## Gates mensuraveis de release

1. IDs listados no portal sao exatamente iguais ao conjunto de referencia `getFormListQuery()` mais `canViewForRequest()` individual para a mesma sessao, perfil, entidade, recursividade e idioma. A interface nativa continua sendo comparada como evidencia adicional, considerando que pode misturar formularios padrao, categorias e FAQ.
2. Zero formulario negado aparece ou abre por URL direta; qualquer falso positivo de ACL bloqueia a release.
3. Todo autorizado e alcancavel sem limite global de 80, duplicacao ou omissao.
4. Abertura repete autorizacao e nao depende de card, pagina ou cache anterior.
5. A listagem nao gera schemas dinamicos completos.
6. Excecao forcada nunca aparece como `ready_empty`.
7. Consulta e renderizacao crescem com o tamanho da pagina, nao com o total do catalogo.
8. Em homologacao, com pagina de 24 itens e catalogos de 201 e 500 formularios, P95 da primeira pagina abaixo de 2,5 segundos em 30 execucoes com cache quente, linha de base separada com cache frio e nenhuma ocorrencia de 504.
9. Busca, pagina, vazio, parcial e erro sao concluidos somente por teclado e compreendidos por leitor de tela sem assistencia visual.
10. Axe apresenta zero violacao seria ou critica; isso nao substitui a avaliacao manual.
11. Nao ha rolagem horizontal em 320 CSS px/400%; contraste de texto e componentes atende WCAG AA.
12. Todas as acoes principais dos cards possuem nomes acessiveis unicos, incluindo o titulo do formulario.
13. Voltar/avancar do navegador restaura busca e pagina sem duplicacao, omissao ou ciclo de cursor.
14. PHPUnit, testes de navegador, PHPStan, PHPCS, i18n, build e verificacao do ZIP permanecem verdes no PHP suportado.

## Sequencia recomendada

1. Criar testes de caracterizacao e doubles do contrato 2.13.
2. Extrair interfaces, estados e detector de capacidades.
3. Implementar consulta coletiva nativa e autorizacao individual carregada.
4. Implementar cursor/paginacao, deduplicacao e busca segura.
5. Implementar `findAuthorized()` e revalidacao na abertura.
6. Retirar schemas dinamicos da listagem.
7. Implementar estados, diagnostico e mensagens acessiveis.
8. Adicionar chave de rollback e rollout gradual.
9. Executar testes negativos de ACL e testes de navegador.
10. Comparar IDs com o Formcreator nativo no mesmo contexto.
11. Homologar teclado/leitor de tela e desempenho antes da release.

## Arquivos e componentes previstos

- `src/Infrastructure/Repository/FormRepository.php`: orquestracao das fontes, sem ACL propria do Formcreator.
- `src/Infrastructure/FormCatalog/FormCatalogGateway.php`: contrato da fonte.
- `src/Infrastructure/FormCatalog/Formcreator213CatalogGateway.php`: adaptador nativo.
- `src/Application/FormService.php`: metadados leves na lista; schema somente na abertura.
- `src/UI/Controller/FormController.php`: entrada de busca/pagina e estados.
- `templates/forms/index.php`: lista, busca, navegacao e estados acessiveis.
- `tests/unit/FormRepositoryTest.php`: fontes/orquestracao.
- novos testes unitarios do gateway e contratos 2.13.
- novo teste de navegador da lista de formularios.
- configuracao, i18n, matriz de compatibilidade e nota da versao.

## Fora do escopo

- reimplementar o motor de condicoes, targets ou submissao do Formcreator;
- autorizar por SQL proprio, direito generico ou estado anterior da interface;
- listar formularios publicos anonimos/captcha fora do fluxo nativo;
- oferecer contagem aproximada como se fosse exata;
- cache compartilhado do catalogo autorizado nesta correcao;
- alterar tabelas ou dados do Formcreator.

## Checklist da lista de melhorias

- [x] P0 - testes de caracterizacao da chamada incorreta.
- [x] P0 - gateway Formcreator 2.13 e detector de capacidades.
- [x] P0 - consulta coletiva nativa mais autorizacao individual carregada.
- [x] P0 - paginacao sem limite global de 80 e deduplicacao por ID.
- [x] P0 - busca servidor-side anexada a consulta autorizada nativa.
- [x] P0 - `findAuthorized()` e revalidacao de URL direta.
- [x] P0 - retirada de schemas completos da listagem.
- [x] P0 - estados estruturados, diagnostico privado e mensagens acessiveis.
- [x] P0 - chave de rollback inicialmente desativada e rollout gradual documentado.
- [ ] P0 - paridade de IDs, ACL negativa, GLPI 10/11 e homologacao assistiva.
