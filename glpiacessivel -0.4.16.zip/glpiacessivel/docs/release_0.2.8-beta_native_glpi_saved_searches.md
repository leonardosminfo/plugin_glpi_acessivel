# Release 0.2.8-beta: pesquisas de chamados nativas do GLPI

## Resultado

As pesquisas salvas de chamados agora usam o GLPI como unica fonte de verdade.
O plugin nao cria copia, espelho, fork ou pesquisa padrao local.

O portal acessivel:

- lista pesquisas privadas e publicas autorizadas pelo GLPI;
- busca o catalogo por nome e pagina em blocos de 25;
- resolve diretamente pesquisas fora da pagina atual;
- cria pesquisas privadas diretamente em `SavedSearch`;
- renomeia, exclui e define ou remove o padrao no objeto nativo autorizado;
- preserva criterios, metacriterios, ordenacoes e escopo de lixeira ao aplicar;
- oferece `Abrir no GLPI` quando nao consegue executar a definicao fielmente.

## Seguranca e integridade

- mutacoes usam CSRF, fingerprint otimista e chave idempotente;
- reserva, mutacao nativa e conclusao do ledger ocorrem na mesma transacao;
- o ledger expira automaticamente e armazena somente hashes, estado, token,
  ID numerico e datas, sem nome, URL, query, criterio, filtro ou valor;
- consultas salvas nao usam varredura aproximada de chamados;
- falha da Search API retorna lista vazia, sem ampliar resultados;
- a query serializada tem limite defensivo de 48 KiB;
- autorizacao final usa os modelos e direitos nativos do GLPI.

## Upgrade sem dados locais

A tabela legada `glpi_plugin_glpiacessivel_ticketviews` deixou de ser criada.
Durante o upgrade, ela so e removida quando existe e esta vazia. Qualquer linha,
resultado inesperado, erro de lock ou erro de leitura interrompe o preflight
antes dos demais comandos de schema.

Nao ha migracao de pesquisas porque o ambiente ainda nao possui usuarios nem
pesquisas locais salvas.

## Experiencia acessivel

- heading unico `Pesquisas salvas do GLPI`;
- busca explicita, sem execucao automatica em `change`;
- cada pesquisa e um artigo com nome, visibilidade, capacidade e estado padrao;
- acoes contextualizadas com o nome completo;
- exclusao com confirmacao explicita, Cancelar, Escape, anuncio e retorno de foco;
- suporte a teclado, reflow, tema noturno, alto contraste e `forced-colors`;
- pesquisas nao homologadas permanecem intactas e abrem na interface nativa.

## Verificacao automatizada

- PHPUnit: 160 testes e 836 assercoes na consolidacao inicial da release;
- PHPCS, PHPStan, lint PHP e validacao de sintaxe JavaScript;
- auditoria i18n e verificacao do pacote;
- gate que proibe referencias ativas a persistencia local de pesquisas.

## Homologacao ainda necessaria

Esta beta nao substitui ensaio real em GLPI 10 e 11 com perfis, entidades,
plugins, volumes e dados representativos. Os fluxos criticos devem ser
repetidos com NVDA, JAWS e VoiceOver antes de uso amplo.
