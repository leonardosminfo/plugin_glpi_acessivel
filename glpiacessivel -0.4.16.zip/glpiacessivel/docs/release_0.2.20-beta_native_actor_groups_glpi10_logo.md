# Release 0.2.20-beta: grupos nativos de chamados e logotipo no GLPI 10

## Objetivo

Aproximar a selecao de atores do chamado ao comportamento nativo do GLPI e corrigir a apresentacao do logotipo do plugin no gerenciador do GLPI 10.

## Grupos de chamados

- separa grupos tecnicos de grupos observadores;
- lista somente grupos ativos, nao excluidos, habilitados para o papel e visiveis na entidade real do chamado;
- respeita a hierarquia de entidades para grupos recursivos e rejeita ramos nao relacionados;
- revalida no servidor todos os identificadores enviados pelo navegador;
- recupera e apresenta os grupos observadores ja relacionados ao chamado;
- inclui grupos observadores na criacao e na atualizacao do chamado;
- substitui grupos por papel com o contrato nativo do `Ticket::update`, usando IDs de relacao para exclusoes;
- preserva usuarios, fornecedores, o papel oposto e grupos atuais que deixaram de estar disponiveis no catalogo.

## Logotipo

O GLPI 11 reconhece o `logo.png` local do plugin. O GLPI 10.0.18 ainda monta o cartao instalado apenas com o logotipo obtido pelo catalogo do Marketplace. Para a versao 10, o JavaScript do plugin aplica uma melhoria progressiva no cartao ativo:

- atua somente na pagina de Plugins/Marketplace e no cartao `glpiacessivel`;
- reconhece instalacoes servidas por `/plugins` ou `/marketplace`, inclusive em subdiretorios;
- preserva a implementacao nativa do GLPI 11 quando ja existe uma imagem;
- usa imagem decorativa com `alt=""`, mantendo o nome textual do plugin;
- restaura as iniciais `GA` se a imagem falhar;
- encerra a observacao do DOM apos sucesso, erro ou tempo limite.

No GLPI 10, o fallback depende de o plugin estar ativo para que seu JavaScript seja carregado. A exibicao do logotipo antes da ativacao continua dependendo da publicacao do plugin no catalogo oficial do Marketplace.

## Validacao manual recomendada

1. abrir um chamado em entidade filha e conferir grupos locais e grupos recursivos ancestrais;
2. confirmar que um grupo de outro ramo nao aparece e que um ID forjado e rejeitado;
3. selecionar, trocar e remover grupos tecnicos e observadores, verificando cada papel separadamente;
4. confirmar que usuarios, solicitantes e fornecedores permanecem inalterados;
5. criar um chamado com grupo observador;
6. abrir o gerenciador de plugins no GLPI 10 e conferir o logotipo, o nome textual e o fallback `GA` em caso de erro;
7. repetir a verificacao em GLPI 11, teclado e leitor de tela.

## Geracao do pacote

```powershell
.\tools\build-release.ps1 -Output .release_0.2.20-beta_native_actor_groups_glpi10_logo -Profile marketplace -RequireMsgfmt
.\tools\verify-release.ps1 -Package .release_0.2.20-beta_native_actor_groups_glpi10_logo\glpiacessivel.zip -ExpectedVersion 0.2.20-beta -PublicProfile
```
