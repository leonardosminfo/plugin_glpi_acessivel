# Plano de testes — 0.4.11-beta

Executar o mesmo ZIP e SHA-256 em GLPI 10/PHP 8.1 e GLPI 11/PHP 8.3. Usar chamados descartáveis e perfis com combinações reais dos direitos nativos.

## 1. Confirmação da edição geral

1. Abrir um chamado editável e acionar `Salvar dados do chamado` sem mudar campos: nenhum POST deve ocorrer; anunciar `Nenhuma alteração foi selecionada`.
2. Alterar isoladamente título, tipo, categoria, localização, origem, urgência, impacto e prioridade: o diálogo deve listar campo, valor anterior e novo rótulo.
3. Alterar a descrição: o diálogo deve informar que o conteúdo será alterado sem apresentar texto antigo ou novo.
4. Alterar vários campos e confirmar ordem, lista sem HTML executável, consequência e nome acessível dos botões.
5. Cancelar por botão e `Escape`: fechar o diálogo, não enviar e devolver o foco ao acionador.
6. Confirmar: efetuar um único POST e validar no GLPI o histórico e os valores persistidos.

## 2. Segurança e integridade

1. Enviar `general_update` sem `critical_confirmed=1`, sem token, com token de outro chamado, usuário ou ação: recusar antes da mutação.
2. Reutilizar um token já aceito: recusar.
3. Manter uma segunda sessão com revisão antiga: recusar por conflito, sem sobrescrever a alteração concorrente.
4. Inserir marcação HTML nos campos textuais: o resumo deve permanecer texto; a descrição não pode aparecer no diálogo.
5. Forçar erro ou carregamento pendente no seletor remoto: a validação deve impedir a abertura do diálogo.

## 3. Regressão funcional e acessível

1. Repetir confirmação de atribuição, observadores, solução, status e decisões do requerente.
2. Validar teclado, leitor de tela, foco preso no diálogo, `Escape`, zoom de 200%/400% e 320 CSS px.
3. Confirmar que perfis de leitura não recebem controles ou tokens de mutação utilizáveis.
4. Repetir seleção remota de categoria e localização com 0, 1, 20 e 21 resultados.
5. Reabrir lista progressiva, pesquisas salvas, formulários, cockpit, auditoria e modelos ITIL.

## 4. Atualização 0.4.10-beta → 0.4.11-beta

1. Instalar o mesmo ZIP sobre a `0.4.10-beta`, sem reiniciar PHP-FPM.
2. Confirmar que `VERSION`, `setup.php`, XML e CFF informam `0.4.11-beta` e os três marcadores de runtime informam `20260831-02`.
3. Confirmar detecção do runtime anterior, invalidação restrita dos PHP do plugin e ausência de `opcache_reset()`.
4. Na requisição seguinte, confirmar versão e epoch novos e URL do JavaScript com nova chave de cache.
5. Repetir os casos 1 a 3 nos GLPI 10 e 11.

## 5. Gates automatizados

1. PHPUnit completo em PHP 8.1 e 8.3.
2. PHPStan, PHPCS, suíte completa do navegador e auditoria i18n.
3. Igualdade dos assets JavaScript fonte/público.
4. Build Marketplace e `verify-release.ps1 -ExpectedVersion 0.4.11-beta -PublicProfile`.

## Critério de liberação

Nenhum envio sem confirmação; nenhum token reutilizável ou fora de contexto; nenhum conteúdo de descrição no diálogo; nenhum direito ampliado; nenhuma regressão dos formulários críticos existentes; mesmo artefato aprovado nos dois GLPIs.
