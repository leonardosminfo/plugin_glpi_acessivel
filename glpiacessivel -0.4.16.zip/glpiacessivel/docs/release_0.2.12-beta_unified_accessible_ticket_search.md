# Release 0.2.12-beta: pesquisa unificada e acessível de chamados

## Resultado

A pesquisa de chamados passa a reunir busca textual, escopo, critérios avançados, ordenação, paginação e escolha de colunas em uma única região. A disposição segue o modelo mental da pesquisa nativa do GLPI, com controles HTML operáveis por teclado e rótulos compreensíveis por leitores de tela.

## Paridade com o GLPI

- campos, operadores, valores remotos, metacritérios e colunas são derivados das Search Options disponíveis para o perfil e a entidade ativos;
- busca textual, escopo e regras compostas são traduzidos para uma única consulta pela Search API;
- pesquisas são recuperadas, criadas, renomeadas, excluídas e definidas como padrão diretamente em `SavedSearch`;
- não existe cópia, cache persistente ou banco paralelo de pesquisas do plugin;
- definições não homologadas permanecem disponíveis pela ação “Abrir no GLPI”, sem aproximação silenciosa.

## Colunas da lista

O diálogo “Escolher colunas” permite adicionar, remover e reordenar as colunas autorizadas. ID e título permanecem obrigatórios. A seleção acompanha a definição atual da pesquisa e é validada novamente no servidor. Esta versão não grava uma preferência geral de colunas separada da pesquisa, pois não há um contrato único e seguro entre GLPI 10 e 11 para essa preferência.

## Acessibilidade

- sequência previsível: busca, filtros, resumo aplicado e resultados;
- filtros avançados e opções de resultado com expansão progressiva;
- nenhuma busca é disparada apenas por alterar um campo;
- retorno de foco ao fechar o diálogo e foco orientado após erros ou resultados;
- posição e quantidade das regras anunciadas;
- alvos de interação de 44 px, reflow a 320 px, alto contraste e `forced-colors`;
- resumo de filtros aplicados separado dos campos ainda em edição.

## Segurança e integridade

- aplicação da pesquisa por POST protegido com CSRF e redirecionamento PRG;
- URL contém somente token opaco, temporário e vinculado ao contexto;
- parâmetros, campos, operadores, escopos e colunas seguem listas permitidas contextuais;
- resultados e rótulos são revalidados conforme ACL antes da apresentação;
- pesquisas salvas utilizam exclusivamente a autorização e a persistência nativas do GLPI.

## Compatibilidade e validação

- GLPI: `>=10.0 <12.0`;
- PHP: `>=8.1`;
- PHPUnit: 280 testes e 1.413 asserções;
- PHPStan: sem erros;
- PHPCS: sem erros no gate de release;
- sintaxe PHP e JavaScript validada;
- espelhos públicos de CSS e JavaScript verificados por SHA-256.

Os testes automatizados reduzem regressões, mas a instalação ainda deve ser homologada com os perfis, entidades, volumes e tecnologias assistivas reais da organização.