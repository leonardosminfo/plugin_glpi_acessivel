# Execução de testes — 0.4.5-beta — 28/08/2026

## Resultado automatizado

| Gate | Resultado |
| --- | --- |
| PHPUnit PHP 8.1.31 | 680 testes, 4.136 asserções, aprovado |
| PHPUnit PHP 8.3.14 | 680 testes, 4.136 asserções, aprovado |
| PHPStan | sem erros |
| PHPCS PSR-12 | 267 arquivos, aprovado |

## Contratos comprovados

- o token atual preserva `status` e `group_id` como estado de edição validado;
- a definição nativa efetiva permanece completa e é a única usada na consulta;
- o editor remove somente o sufixo exato compilado pelo servidor;
- `Status = Novo` volta selecionado sem aparecer também como regra avançada;
- sufixo divergente ou filtros frequentes malformados falham fechado;
- tokens legados e o envelope anterior permanecem compatíveis com estado visual neutro.

## Homologação no navegador

Executada com o pacote candidato instalado nos ambientes locais, sem reiniciar PHP-FPM:

| Cenário | GLPI 10 / PHP 8.1 | GLPI 11 / PHP 8.3 |
| --- | --- | --- |
| Selecionar `Status = Novo` e aplicar | aprovado | aprovado |
| Manter `Novo` selecionado após o redirecionamento | aprovado | aprovado |
| Manter `Novo` selecionado após recarregar a URL com token | aprovado | aprovado |
| Resumo aplicado `E Status é Novo` | aprovado | aprovado |
| Consulta em edição `Status: Novo` | aprovado | aprovado |
| Não duplicar o status nas regras avançadas | aprovado: 0 regras | aprovado: 0 regras |
| Resultado nativo coerente | aprovado: nenhuma fixture ativa com status Novo | aprovado: 4 chamados, todos com status Novo |
| Renovação de runtime/OPcache pelo marcador `20260828-4` | aprovado sem reinício do serviço | aprovado sem reinício do serviço |

A paginação não ficou disponível nesta fixture específica porque o resultado coube em uma única página. A persistência do estado foi comprovada pelo redirecionamento e por nova abertura da mesma URL assinada.

## Pendências gerais herdadas

- carga autenticada longa pelo proxy;
- pesquisa salva real e categoria com fixtures adequadas;
- mutações sintéticas de solução e atores;
- validação manual com NVDA e JAWS.
