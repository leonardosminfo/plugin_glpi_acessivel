# Plano de testes — GLPI Acessível 0.4.12-beta

## 1. Integridade do pacote

1. Conferir `0.4.12-beta` em `VERSION`, `setup.php`, `glpiacessivel.xml`, `CITATION.cff` e catálogos de tradução.
2. Conferir o marcador de runtime `20260831-03` nos componentes de inicialização e migração.
3. Executar o verificador de release no ZIP e comparar o SHA-256 publicado.
4. Atualizar a partir da versão anterior sem reiniciar o PHP-FPM e confirmar a renovação dos assets e do OPcache do plugin.

## 2. Testes automatizados

1. Validar a sintaxe de `assets/js/remote-resource-selector.js` e de sua cópia pública.
2. Executar os testes de seletores remotos e roteamento acessível.
3. Executar a suíte completa de navegador, com 76 cenários esperados.
4. Executar PHPUnit com PHP 8.1 e PHP 8.3.
5. Executar a construção pública com catálogos Gettext obrigatórios e a verificação posterior do pacote.

## 3. Matriz funcional GLPI 10 e GLPI 11

Para cada versão, usar um chamado editável e perfis com direitos de leitura, atualização e atribuição:

1. Abrir a edição dos dados gerais e dos atores do chamado.
2. Verificar localização, requerentes, grupos requerentes, grupos responsáveis, técnicos, fornecedores e pessoas observadoras.
3. Confirmar que cada pesquisa possui nome acessível igual ao rótulo visível e adequado ao contexto.
4. Acionar o rótulo e confirmar que o foco chega ao campo correspondente.
5. Pesquisar, selecionar, remover e salvar um valor permitido pelo perfil.
6. Confirmar que o `select` oculto possui nome acessível, sem entrar indevidamente na ordem de foco.
7. Forçar a indisponibilidade do componente remoto e confirmar o nome acessível do campo alternativo.
8. Recarregar o chamado e verificar a persistência dos dados pelo fluxo nativo do GLPI.

## 4. Acessibilidade manual

1. Navegar somente por teclado, incluindo avanço, retorno, seleção e cancelamento.
2. Com NVDA ou JAWS, confirmar rótulo, função, estado, ajuda e resultado anunciado uma única vez.
3. Executar WAVE e exigir zero ocorrência de “Missing form label” nos controles do plugin.
4. Executar Axe; investigar manualmente alertas de `aria-valid-attr-value`, referências ARIA e contraste.
5. Confirmar ausência de IDs duplicados, `aria-labelledby` quebrado e `aria-controls` sem destino.
6. Testar contraste normal e alto contraste, zoom de 200% e reflow a 320 CSS pixels.

## 5. Segurança e compatibilidade

1. Confirmar que o perfil de leitura não obtém controles de alteração ou atribuição.
2. Confirmar entidade ativa, recursividade e filtros de usuários, grupos e fornecedores.
3. Validar CSRF, concorrência e mensagens de confirmação sem alteração do contrato de submissão.
4. Verificar que a correção não aumenta o número de consultas remotas ao carregar a página.

## 6. Critério de aprovação

A candidata é aprovada quando os gates automatizados passam nas duas versões de PHP, o pacote é validado, GLPI 10 e GLPI 11 preservam o fluxo nativo e não há erro de rótulo, teclado ou leitor de tela nos seletores remotos. Qualquer divergência de direito, entidade, persistência ou nome acessível bloqueia a liberação.
