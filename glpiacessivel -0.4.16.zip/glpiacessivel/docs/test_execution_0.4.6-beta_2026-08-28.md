# Execução de testes — 0.4.6-beta — 28/08/2026

## Resultado automatizado

| Gate | Resultado |
| --- | --- |
| PHPUnit PHP 8.1.31 | 704 testes, 4.307 asserções, aprovado |
| PHPUnit PHP 8.3.14 | 704 testes, 4.307 asserções, aprovado |
| PHPStan | sem erros |
| PHPCS PSR-12 | 268 arquivos, aprovado |
| Navegador | 58 cenários, aprovado |
| Internacionalização | 2.410 mensagens; 2.411 entradas compiladas; POT/PO/MO e espelhos consistentes |

## Contratos comprovados

- autorização de cockpit por leitura nativa e bloqueio de criação antes de CSRF e renderização;
- acesso a formulários desvinculado de `Ticket::CREATE` e revalidado pela API nativa da fonte;
- controles, seletores, serviço e repositório com guardas distintas para atribuição e observação;
- planejamento completo, bloqueio, transação, releitura e rollback na reconciliação dos quatro papéis;
- localização obrigatória consultada de forma limitada e somente após autorização;
- solução submetida uma única vez após validações nativas;
- categoria de helpdesk com o nome de campo nativo correto;
- modelo de tarefa vazio sem perda de conteúdo ou falso anúncio de sucesso;
- CSRF inválido no resultado assíncrono normalizado como JSON `ticket_results` com HTTP 403;
- catálogos, mensagens, placeholders e espelhos de JavaScript consistentes;
- preservação da pesquisa nativa, filtros frequentes, metacritérios, agregação, resultados limitados, capacidade e paginação progressiva.
- sessão PHP liberada antes da Search, teto de 20 IDs por papel, grupos validados exatamente e orçamento global de 1.000 relações hidratadas;
- catálogos distintos para técnicos e observadores no fallback sem seletor remoto;
- falha fechada, monotonicidade assíncrona, exclusão de dados ocultos e foco previsível no formulário dinâmico.

## Cobertura da bateria de navegador

Os 58 cenários cobriram pesquisa avançada e filtros recorrentes, status negativo, lista assíncrona e seus erros, saturação, seletores remotos, condições dinâmicas, modelos ITIL, formulários nativos incorporados GLPI 10/11, ponte WCAG/eMAG, refluxo a 320 CSS px, confirmações críticas, quatro papéis de atores, diagnóstico de acessibilidade e cockpit.

## Itens não alegados como aprovados ao vivo

Esta execução foi feita sobre código e fixtures automatizadas. Permanecem como gates de homologação operacional:

1. perfil real de leitura, autoatendimento e técnico em GLPI 10 e GLPI 11;
2. alteração real dos quatro papéis e falha intermediária controlada para comprovar rollback;
3. categoria com localização obrigatória e modelos reais de tarefa, acompanhamento e solução;
4. acesso direto e catálogo real Formcreator/Service Catalog com perfis permitidos e negados;
5. carga HTTP autenticada pelo proxy com volume representativo;
6. NVDA ou JAWS nas jornadas críticas.

Nenhum desses itens é substituído pelos testes automatizados, e a beta não constitui certificação final WCAG, eMAG ou RGAA.
