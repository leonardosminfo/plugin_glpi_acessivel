# GLPI Acessível 0.4.9-beta — resiliência da paginação

Esta versão corrige o falso bloqueio observado ao avançar rapidamente pelas páginas da lista de chamados no GLPI 10. A investigação autenticada confirmou que cada página fazia somente uma consulta assíncrona, que o GLPI nativo respondia normalmente e que a terceira consulta era recusada pelo token bucket histórico `6/60/2`.

## Implementação

- política padrão da lista: 30 admissões por 60 segundos, burst de 5;
- recomposição: um crédito a cada 2 segundos;
- chave de sessão `glpiacessivel_ticket_list_rate_v3`, vinculada à assinatura da política;
- descarte restrito do bucket `v2`, sem limpar outros dados da sessão;
- migração `V0004_ticket_list_rate_calibration`, transacional e idempotente;
- atualização automática somente quando as três configurações persistidas forem exatamente `6`, `60` e `2`;
- preservação integral de configurações ausentes, parciais ou personalizadas;
- telemetria de rejeição limitada a página, tamanho da página, contagem de critérios, metacritérios, ordenações e política efetiva;
- nenhuma inclusão de termos, valores, títulos ou conteúdo de chamados nos eventos operacionais.

## Recuperação acessível

Em caso de `429`, a interface mantém uma única mensagem de estado visível, informa a página afetada e confirma que os filtros do plugin foram preservados. O botão mantém o rótulo “Tentar novamente”; a contagem regressiva fica fora da região viva; ao terminar, ocorre um único anúncio de disponibilidade. No fallback síncrono, o botão também permanece desabilitado durante todo o `Retry-After`. Seleção e paginação permanecem ocultas enquanto não existem resultados.

A lista nativa continua disponível como contingência, com aviso explícito para revisar os filtros porque a URL geral do GLPI pode não representar a consulta atual. A proteção de capacidade simultânea, o limite de hidratação e o orçamento SQL permanecem ativos.

## Compatibilidade e reversão

A implementação usa somente APIs disponíveis no GLPI 10 e 11 e PHP 8.1+. A reversão do código não exige desfazer esquema: `V0004` não cria colunas nem tabelas; apenas registra a migração e, quando aplicável, calibra três valores. Configurações personalizadas nunca são sobrescritas.
