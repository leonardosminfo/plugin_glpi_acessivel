# Plano de testes — 0.4.8-beta

## Matriz obrigatória

Executar no GLPI 10/PHP 8.1 e no GLPI 11/PHP 8.3 as seis combinações entre
proteção de dados pessoais ligada/desligada e auditoria `full`, `critical` ou
`disabled`.

Para cada combinação:

1. realizar uma listagem, uma alteração de chamado, uma tentativa bloqueada e
   uma revelação de contato;
2. comparar exatamente as linhas criadas em `auditlogs` e `piireveals`;
3. comprovar ausência total de PII quando a proteção estiver desligada;
4. comprovar revelação bloqueada quando a auditoria estiver desativada;
5. executar o CronTask e comprovar que o histórico expirado continua sendo
   removido em lotes.

## Direitos e escopo

Criar perfis independentes com: nenhum direito; somente leitura; leitura mais
sensível; leitura mais exportação; e todos os quatro direitos. Validar menu,
URL direta, chatbot e exportação. Repetir com entidade fora do escopo, evento
global e chamado sem permissão de leitura. `ticket UPDATE`, configuração do
plugin e o direito legado de revelar PII não podem conceder acesso.

Trocar perfil e entidade entre duas páginas e confirmar que o cursor anterior
é rejeitado. Comparar o subconjunto exibido na tela, no chatbot e no CSV.

## Segurança e privacidade

- simular falha no primeiro e no segundo `INSERT` da revelação e confirmar
  rollback e campo ainda mascarado;
- pesquisar no banco, CSV, HTML e logs por e-mail, telefone, justificativa,
  termo de pesquisa, cookie, token, SQL e stack trace usados nas fixtures;
- adulterar modo, cursor e CSRF;
- abrir CSV em software de planilha com valores iniciados por `=`, `+`, `-` e
  `@` e comprovar neutralização;
- confirmar `403`/negação controlada sem contagem ou identificadores para
  perfis não autorizados.

## Desempenho

Executar com 100 mil, 1 milhão e 5 milhões de eventos. Medir inserção, consulta,
exportação limitada, retenção e backlog. Aceitar somente se:

- `critical` reduzir pelo menos 75% dos `INSERTs` nas jornadas de leitura;
- consulta recente autorizada tiver p95 de até 100 ms;
- cada lote de retenção tiver p95 de até 1 s e máximo de 5 s;
- não houver `COUNT(*)`, `OFFSET`, deadlock, crescimento de 504 ou espera na
  requisição interativa;
- o backlog expirado for drenado em menos de duas horas.

## Acessibilidade

Executar teclado, NVDA, zoom de 200% e 400%, reflow a 320 CSS px, contraste,
foco, nomes acessíveis e anúncios de erro/sucesso na configuração, na aba do
perfil, na consulta e na exportação. Complementar Axe/Pa11y com revisão manual
WCAG 2.2 AA e eMAG.

## Gate

O pacote só pode seguir para produção depois que as duas versões do GLPI
aprovarem a matriz funcional, autorização, privacidade, acessibilidade e carga.
Registrar versão, SHA-256, perfil, entidade, banco, PHP e evidências de cada
execução.
