# Plano de testes da versão 0.2.37-beta

## Objetivo e gate

Confirmar a conclusão linguística das superfícies públicas, administrativas e dos formulários dinâmicos sem alterar autorização ou dados enviados ao GLPI. A produção é `NO-GO` diante de mensagem pública fora do catálogo, plural artificial, anúncio duplicado, erro de sessão/CSRF com detalhe interno, divergência de placeholder, POT/PO/MO inválido, mudança de ACL/payload ou qualquer gate automatizado vermelho.

## Matriz mínima

Executar em GLPI 10 e GLPI 11, nos idiomas `pt_BR` e `en_GB`, com perfis Self-Service, técnico e administrador, em entidade recursiva e não recursiva. No GLPI 10, incluir Formcreator compatível quando instalado; no GLPI 11, incluir um formulário controlado do Service Catalog. Registrar versões exatas de GLPI, PHP, banco, navegador, tecnologia assistiva e plugin.

Preparar:

- usuário comum sem direito administrativo e administrador com `config/UPDATE`;
- estados com zero, um e pelo menos dois itens para cada contagem crítica;
- sessão válida, sessão expirada e requisição com CSRF inválido em ambiente controlado;
- formulário simples e formulário com validação, anexo ou condição;
- chamado e artigo de conhecimento com conteúdo fictício rastreável.

## L01 — superfícies públicas

1. Percorrer portal, login, lista, busca, criação e detalhe de chamados, formulários, conhecimento, FAQ e assistente em `pt_BR`.
2. Repetir em `en_GB`, sem trocar o perfil ou a entidade.
3. Verificar texto visível, título, nome acessível, ajuda, placeholder, validação, confirmação e região viva.
4. Confirmar ausência de chaves internas, termos de implementação desnecessários, mojibake e português sem acentuação.

Aceite: todo texto da tarefa usa o idioma ativo ou o fallback documentado; conteúdo operacional do GLPI não é reescrito pelo plugin; IDs, intenções e tokens não aparecem como mensagem pública.

## L02 — administração e formulários dinâmicos

1. Abrir configuração, playbooks e diagnósticos com perfil autorizado nos dois idiomas.
2. Repetir o acesso com perfil comum e confirmar que nenhum detalhe administrativo é revelado.
3. Abrir formulários GLPI 11 e Formcreator GLPI 10 nos estados disponível, carregando, contrato não confirmado, sessão expirada e indisponível.
4. Comparar mensagem pública e diagnóstico administrativo do mesmo caso.

Aceite: mensagens administrativas passam pelo Gettext, detalhes permanecem sanitizados e restritos pela ACL existente, e a pessoa comum recebe orientação funcional sem referência desnecessária ao mecanismo do formulário.

## L03 — plurais naturais

Para cada componente aplicável, produzir zero, um e múltiplos itens:

- chamados selecionados;
- erros de validação;
- arquivos e atores;
- opções selecionadas nos seletores remotos;
- regras, violações, resultados incompletos e elementos afetados na auditoria local.

Aceite: singular e plural concordam em `pt_BR` e `en_GB`; não há `(s)` nem frase montada por concatenação insegura; o número e os placeholders permanecem íntegros.

## A01 — anúncio único

1. Com leitor de tela ou monitor de acessibilidade, alternar tema noturno e contraste duas vezes.
2. Abrir e fechar um alerta crítico.
3. Carregar, falhar, tentar novamente e concluir a abertura de um formulário.
4. Produzir erro e sucesso em busca, seleção e envio.
5. Registrar a sequência de alterações em regiões `aria-live`, `role="status"`, `role="alert"` e diálogos.

Aceite: cada evento é anunciado uma única vez; ativação e desativação são inequívocas; não há silêncio em falha ou sucesso; foco não é movido apenas para produzir anúncio.

## S01 — sessão e CSRF

1. Expirar a sessão antes de uma consulta e antes de uma mutação controlada.
2. Enviar CSRF inválido em criação, pesquisa salva e ação administrativa.
3. Inspecionar resposta, HTML, região viva, redirecionamento e logs permitidos.
4. Seguir a orientação de recuperação e repetir a tarefa com nova sessão e token válido.

Aceite: a operação inválida falha fechado; nenhuma mutação é repetida automaticamente; a mensagem pública não revela token, exceção, classe, caminho ou endpoint; a recuperação é compreensível e a operação válida posterior ocorre uma única vez.

## C01 — preservação de ACL e payload

1. Capturar, em fixture ou ambiente controlado, payloads válidos da versão anterior para criação, ações de chamados, pesquisas salvas e formulários.
2. Repetir na `0.2.37-beta` com os mesmos dados e comparar método, nomes de campos, valores funcionais e endpoint.
3. Comparar conjunto de IDs, total, perfil, entidade e recursividade com a fonte nativa.
4. Tentar acesso direto com usuário sem direito e objeto de outra entidade.

Aceite: somente texto de apresentação e catálogo muda; ACL, conjuntos autorizados, payloads, CSRF, submissão nativa e ordem de validação permanecem iguais; acessos indevidos falham fechado.

## G01 — catálogos e gates globais

1. Executar a auditoria i18n com `msgfmt` obrigatório.
2. Confirmar que todas as mensagens estáticas do runtime existem no POT e nos PO.
3. Verificar cabeçalhos, UTF-8, plurais, placeholders, flags de formato, entradas fuzzy/vazias e MO compilados.
4. Comparar os ativos em `assets/` e `public/assets/`.
5. Confirmar que o pacote exige esta nota e este plano sem remover os documentos históricos.

Aceite: auditoria sem ausência, divergência ou mojibake; MO coerentes com os PO; ativos espelhados; versão `0.2.37-beta` consistente em `setup.php`, XML, CFF e documentação.

## Acessibilidade manual

- teclado completo, foco visível, retorno de foco e ausência de armadilhas;
- NVDA com Firefox e Chrome e JAWS com Edge; VoiceOver quando fizer parte da matriz institucional;
- conferência auditiva dos plurais e de anúncio único;
- reflow em 320 pixels CSS, zoom de 200% e 400%, alto contraste e cores forçadas;
- linguagem compreensível para pessoa sem conhecimento de Gettext, CSRF, payload, iframe ou motor nativo.

## Automação

Executar, nessa ordem:

```powershell
php -d xdebug.mode=off -d xdebug.log=NUL vendor/bin/phpunit --colors=never
php -d xdebug.mode=off vendor/phpstan/phpstan/phpstan.phar analyse --memory-limit=512M --no-progress
php -d xdebug.mode=off vendor/squizlabs/php_codesniffer/bin/phpcs -p --warning-severity=0
pnpm run test:browser
.\tools\i18n-audit.ps1 -RequireMsgfmt
.\tools\build-release.ps1 -Output .release_0.2.37-beta_language_accessibility_completion -Profile marketplace -RequireMsgfmt
.\tools\verify-release.ps1 -Package .release_0.2.37-beta_language_accessibility_completion\glpiacessivel.zip -ExpectedVersion 0.2.37-beta -PublicProfile
```

Durante a preparação documental, não gerar o ZIP. Os dois últimos comandos pertencem ao gate final, depois da homologação funcional, linguística e assistiva.

## Evidências obrigatórias

- matriz de mensagens por rota, idioma e audiência;
- registros de singular/plural para zero, um e múltiplos itens;
- sequência de eventos anunciáveis comprovando uma emissão por mudança;
- respostas sanitizadas de sessão expirada e CSRF inválido;
- comparação de ACL, conjunto de IDs e payloads antes/depois;
- saídas completas dos gates, versões das ferramentas e hashes dos catálogos/ativos;
- decisão `GO/NO-GO`, responsável, data e pendências aceitas.

## Aceite do artefato

O ZIP aprovado deve declarar `0.2.37-beta` em `setup.php`, XML, CFF, README, catálogos e manifesto; conter a nota `release_0.2.37-beta_language_accessibility_completion.md`, este plano e as documentações tecnológica, funcional e de acessibilidade; preservar a raiz única `glpiacessivel/`; passar o verificador oficial; e ter o SHA-256 final registrado no handoff.

