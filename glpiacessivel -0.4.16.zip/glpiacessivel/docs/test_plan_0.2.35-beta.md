# Plano de testes da versão 0.2.35-beta

## Objetivo e gate

Confirmar que a revisão linguística não alterou autorização, resultados, mutações ou foco e que todo texto crítico visível ou anunciado nas jornadas principais está em português canônico ou traduzido pelo catálogo ativo. A produção é `NO-GO` diante de qualquer divergência de ACL/conjunto de IDs, texto sem acentuação na interface pt-BR, chave interna anunciada, catálogo inconsistente, foco perdido ou gate automatizado vermelho.

## Matriz mínima

Executar em GLPI 10 e GLPI 11, com idioma `pt_BR` e `en_GB`, nos perfis Self-Service, técnico e administrador e em entidade recursiva e não recursiva.

### L01 — criação de chamado

1. Abrir a criação pelo portal e percorrer todos os campos por teclado.
2. Confirmar `Formulário acessível`, `Descrição`, `Localização`, `Média` e demais rótulos com acentuação correta.
3. Acionar limpeza, validação obrigatória, seleção remota e envio controlado.
4. Confirmar nomes acessíveis, ajuda, erro associado e anúncios sem texto literal fora do idioma ativo.

### L02 — detalhe e ações ITIL

1. Abrir um chamado autorizado e conferir cabeçalhos, metadados e timeline.
2. Validar `Descrição`, `Interações e ações ITIL`, `Localização`, `Última atualização`, `Solução`, permissões, transições, acompanhamento e tarefa.
3. Exercitar uma validação inválida e uma ação permitida sem concluir mutação destrutiva.
4. Confirmar que usuário sem direito recebe mensagem funcional e não vê controles proibidos.

### L03 — busca, resultados e seletores

1. Executar busca rápida, avançada, pesquisa salva e `Status não é Fechado`.
2. Comparar o conjunto de IDs com a consulta nativa equivalente do GLPI.
3. Exercitar zero, uma e várias páginas, timeout, nova tentativa, sessão expirada e contexto alterado.
4. Validar autocomplete de categorias, localizações, usuários e grupos, inclusive mensagens, `aria-label`, regiões vivas e carregamento adicional.

### L04 — portal, cockpit e formulários

1. Validar portal, menu, atalhos e identificação do usuário nos dois idiomas.
2. Conferir cinco indicadores do cockpit, distinguindo zero exato de indisponibilidade, e abrir cada detalhamento.
3. Abrir catálogo e formulário incorporado; confirmar menu preservado, um único formulário editável e alternativa de página completa.
4. Em não administrador, confirmar ausência de diagnóstico técnico.

### L05 — diagnóstico local

1. Executar Axe local em portal, busca, detalhe, cockpit e formulário.
2. Confirmar separação entre violações confirmadas e revisão manual.
3. Simular timeout/erro e verificar mensagem acentuada, retorno de foco e ausência de URL não autorizada.

## Acessibilidade manual

- teclado completo, `Tab`, `Shift+Tab`, `Enter`, `Escape`, setas, Home/End e foco visível;
- NVDA com Firefox e Chrome e JAWS com Edge, registrando a fala de títulos, campos, erros e regiões vivas;
- viewport de 320 CSS px, zoom de 200% e 400%, alto contraste e cores forçadas;
- nenhuma informação dependente apenas de cor e nenhum anúncio repetido ou chave de tradução crua.

## Automação

Executar, nessa ordem:

```powershell
php -d xdebug.mode=off -d xdebug.log=NUL vendor/bin/phpunit --colors=never
php -d xdebug.mode=off vendor/phpstan/phpstan/phpstan.phar analyse --memory-limit=512M --no-progress
php -d xdebug.mode=off vendor/squizlabs/php_codesniffer/bin/phpcs -p --warning-severity=0
pnpm run test:browser
.\tools\i18n-audit.ps1 -RequireMsgfmt
.\tools\build-release.ps1 -Output .release_0.2.35-beta_linguistic_accessibility -Profile marketplace -RequireMsgfmt
.\tools\verify-release.ps1 -Package .release_0.2.35-beta_linguistic_accessibility\glpiacessivel.zip -ExpectedVersion 0.2.35-beta -PublicProfile
```

## Aceite do artefato

O ZIP aprovado deve declarar `0.2.35-beta` em `setup.php`, XML, CFF, README e manifesto; conter POT/PO/MO, os pares de ativos públicos e fonte idênticos, esta nota, este plano e as documentações tecnológica e funcional; passar o verificador oficial; e ter o SHA-256 final registrado no handoff.
