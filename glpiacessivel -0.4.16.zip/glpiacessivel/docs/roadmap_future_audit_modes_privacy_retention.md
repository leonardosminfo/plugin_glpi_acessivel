# Governança da auditoria, privacidade e retenção — 0.4.8-beta

## Status

Implementação incorporada à versão 0.4.8-beta em 30 de agosto de 2026. A
homologação cruzada no GLPI 10 e 11 e os ensaios representativos de carga
continuam sendo gates para implantação em produção. Este documento não
autoriza excluir registros históricos fora da política de retenção.

O ajuste principal deste plano é separar duas decisões independentes:

1. **proteção de dados pessoais** controla mascaramento e revelação temporária
   de contatos pessoais;
2. **modo de auditoria** controla quais ações do plugin geram trilha persistente.

Desativar a proteção de dados pessoais significa que não existe uma operação
do plugin de “revelar PII”. Portanto, nessa situação, não pode ser criado
registro em `glpi_plugin_glpiacessivel_piireveals` nem evento `pii.reveal`.

## Objetivos

1. Reduzir o custo síncrono da auditoria nas jornadas de leitura e pesquisa.
2. Preservar integralmente eventos necessários de segurança, alteração e
   revelação autorizada de dados pessoais.
3. Impedir a coleta de dados sem finalidade vinculada ao evento.
4. Permitir desligamento controlado da funcionalidade extra em ambientes de
   desenvolvimento, sem enfraquecer silenciosamente a proteção de PII.
5. Manter a limpeza dos registros históricos independente do modo de gravação.
6. Entregar, em uma única versão, o modelo definitivo de direitos nativos,
   consulta administrativa, modos de auditoria, retenção e testes, sem período
   intermediário com autorização baseada em perfil nominal ou direito genérico.

## Decisões de configuração

### Proteção de dados pessoais

Configuração existente: `pii_masking_enabled`.

- `false`: o plugin não mascara e não oferece revelação temporária; não grava
  auditoria específica de revelação;
- `true`: o plugin mascara os campos previstos; a revelação exige autorização,
  justificativa e gravação obrigatória da auditoria antes de liberar o dado.

### Modo de auditoria

Nova configuração: `audit_mode`, com catálogo fechado de valores.

- `full`: registra o catálogo completo autorizado, inclusive eventos
  operacionais de leitura;
- `critical`: registra segurança, falhas relevantes, mudanças de configuração,
  mutações, ações sensíveis e revelações de PII quando a proteção estiver ativa;
- `disabled`: não cria novos eventos operacionais; deve ser permitido somente
  com habilitação local explícita para desenvolvimento ou diagnóstico.

Instalações existentes devem iniciar em `full`, preservando o comportamento
anterior. Instalações novas devem iniciar em `critical`. Valor ausente ou
desconhecido deve falhar de forma conservadora para `critical`, registrar o
diagnóstico sem conteúdo sensível e nunca habilitar `disabled` implicitamente.

## Matriz normativa de comportamento

| Proteção de PII | Auditoria | Comportamento obrigatório |
|---|---|---|
| Desativada | `full` | Não há mascaramento, revelação temporária, linha em `piireveals` ou `pii.reveal`. Somente eventos gerais permitidos pelo catálogo completo. |
| Desativada | `critical` | Não há auditoria de PII. Somente eventos gerais críticos, mutações, segurança e configuração. |
| Desativada | `disabled` | Nenhum novo evento persistente do plugin; retenção histórica continua. |
| Ativada | `full` | Mascaramento ativo; revelação autorizada exige justificativa e gravação obrigatória em `piireveals` e `pii.reveal`; demais eventos seguem o catálogo completo. |
| Ativada | `critical` | Mesma proteção e auditoria obrigatória de revelação; demais eventos limitados ao catálogo crítico. |
| Ativada | `disabled` | Dados continuam mascarados e a revelação fica indisponível. O sistema não pode revelar sem deixar a trilha obrigatória. |

### Registros históricos

Alterar `pii_masking_enabled` ou `audit_mode` não apaga registros existentes.
Eles continuam sujeitos à retenção configurada, preservação legal e descarte
controlado. A interface deve explicar isso antes de salvar a configuração.

## Minimização e finalidade

O fato de uma auditoria ser “geral” não torna seus campos anônimos. Identificador
de usuário, chamado, endereço IP e combinações desses campos podem ser dados
pessoais e precisam de finalidade própria, acesso restrito e retenção definida.

Regras obrigatórias:

1. termos de pesquisa, conteúdo do chamado, justificativas livres, nomes,
   e-mails, telefones, cookies, tokens, SQL e exceções completas não entram no
   `payload`;
2. `users_id`, `entities_id` e `tickets_id` só são gravados quando necessários
   para a finalidade declarada da classe do evento;
3. endereço IP não é gravado em leituras rotineiras; seu uso fica restrito a
   eventos de segurança previamente catalogados e documentados;
4. o `payload` passa por allowlist por evento, sanitização recursiva, limite de
   profundidade, quantidade de campos e tamanho total;
5. métricas de duração, volume, fila e capacidade pertencem à telemetria
   operacional agregada, não à trilha nominal de auditoria;
6. desligar o mascaramento não autoriza ampliar a coleta na auditoria geral.

## Catálogo e política central de eventos

Criar `AuditEventPolicy` e um catálogo fechado, testável e versionado. Toda
gravação deve passar por essa política; controladores e serviços não decidem o
modo diretamente.

Classes iniciais:

1. **meta-auditoria**: mudança do próprio modo, falha ou recusa de gravação;
2. **segurança e PII**: tentativa bloqueada, revelação autorizada e falha de
   autorização;
3. **mutações**: criação e alteração de chamados, tarefas, acompanhamentos,
   soluções, atores e configurações;
4. **leitura de objeto sensível**: somente os casos justificados no catálogo;
5. **telemetria de navegação**: listas, resultados assíncronos e cockpit.

Política por modo:

- `full`: classes 1 a 5;
- `critical`: classes 1 a 3 e somente as leituras sensíveis explicitamente
  classificadas na classe 4;
- `disabled`: nenhuma gravação operacional; a tentativa de revelar PII falha
  fechada e a rotina de retenção permanece ativa.

Evento literal ausente do catálogo deve falhar no CI. Se ainda ocorrer em
execução, deve ser tratado conservadoramente como crítico e gerar diagnóstico
mínimo `catalog_miss`, sem copiar o `payload` original.

## Alterações técnicas planejadas

### 1. Configuração e migração

1. Adicionar `audit_mode` por migração nova, monotônica e idempotente.
2. Não alterar migrações antigas.
3. Preservar `full` para instalações existentes e definir `critical` em novas
   instalações.
4. Exigir constante local, por exemplo
   `GLPIACESSIVEL_ALLOW_AUDIT_DISABLED`, para aceitar `disabled`.
5. Manter `pii_masking_enabled` e `audit_mode` como chaves independentes.
6. Registrar os direitos de auditoria por migração idempotente usando a API
   nativa de `ProfileRight` compatível com GLPI 10 e 11.
7. Não conceder direitos a perfis comuns nem sobrescrever escolhas existentes
   em atualizações posteriores.
8. No primeiro bootstrap interativo, atribuir os direitos ao perfil ativo do
   instalador somente quando ele já puder administrar perfis. Se a instalação
   ocorrer sem sessão, registrar os direitos sem concessão automática e exibir
   diagnóstico orientando sua atribuição na tela nativa de perfis.

### 2. Direitos nativos e autorização

O código nunca deve verificar nome, ID ou interface visual de um perfil. Todo
acesso deve usar os direitos registrados pelo plugin e a sessão ativa do GLPI.
Os direitos pertencem ao perfil pelo mecanismo nativo, mas a implementação
depende exclusivamente da capacidade concedida.

Direitos definitivos da entrega única:

1. `plugin_glpiacessivel_audit_read`: consultar metadados sanitizados;
2. `plugin_glpiacessivel_audit_sensitive`: consultar somente os detalhes
   sensíveis permitidos e o ledger de revelação de PII;
3. `plugin_glpiacessivel_audit_export`: solicitar e baixar exportação do mesmo
   conjunto autorizado;
4. `plugin_glpiacessivel_audit_global`: consultar eventos sem objeto ou entidade
   local, como instalação e mudança de política.

Gerenciar modo, retenção e CronTask continua sob administração de configuração,
mas essa capacidade não concede leitura, detalhe sensível ou exportação.

Regras cumulativas por registro:

- chamado vinculado: `audit_read`, entidade real do chamado no escopo ativo e
  `Ticket::can(id, READ)`;
- evento de entidade sem chamado: `audit_read` e entidade dentro do escopo
  ativo/recursivo;
- evento global: `audit_global`, sem fallback por entidade raiz;
- ledger de PII ou detalhe sensível: regras anteriores mais `audit_sensitive`;
- exportação: regras anteriores mais `audit_export`.

Criar `AuditAuthorization` e `AuditQueryService` como portas únicas para tela,
chatbot, API e exportação. Nenhuma dessas apresentações pode consultar a tabela
diretamente. A troca de perfil, entidade ou recursividade deve ser refletida
imediatamente e toda falha de autorização deve ser fechada.

O acesso inicial será, portanto, somente do administrador que receber esses
direitos no bootstrap. A arquitetura já ficará pronta para eventual delegação
posterior pela tela nativa de perfis, sem nova versão, migração ou mudança de
código.

### 3. Escrita da auditoria

1. Injetar `AuditEventPolicy` em `AuditLogger`.
2. Aplicar a decisão de modo antes de montar o `payload` e antes do `INSERT`.
3. Centralizar a minimização no logger, mesmo que o chamador envie campos a
   mais.
4. Verificar explicitamente retorno `false` do banco, além de exceções.
5. Para auditoria comum, a falha não repete nem bloqueia uma consulta de
   leitura; gera diagnóstico seguro.
6. Para revelação de PII, a falha de qualquer uma das gravações obrigatórias
   interrompe a revelação e mantém o campo mascarado.
7. Garantir atomicidade ou compensação entre `piireveals` e `pii.reveal`, para
   não existir revelação registrada pela metade.

### 4. Interface de configuração acessível

1. Exibir “Proteção de dados pessoais” e “Auditoria persistente” em grupos
   distintos (`fieldset` e `legend`).
2. Explicar em texto o efeito de cada modo, inclusive desempenho, retenção e
   indisponibilidade da revelação de PII no modo `disabled`.
3. Exigir confirmação explícita e acessível antes de salvar `disabled`.
4. Informar que desativar uma opção não remove registros históricos.
5. Expor estado atual, última execução da retenção, backlog expirado estimado,
   último erro e quantidade gravada por classe, sem mostrar conteúdo auditado.
6. Garantir teclado, foco visível, rótulos programáticos, mensagens anunciadas
   e sem dependência exclusiva de cor.

### 5. Consulta administrativa da auditoria

1. Entregar a página administrativa “Trilha de auditoria operacional” como
   parte obrigatória da mesma versão, visível somente com `audit_read`.
2. Manter filtro por entidades ativas, recursividade e ACL nativa do chamado.
3. Apresentar evento em linguagem humana, data/hora, resultado, alvo e ator
   permitido; nunca renderizar JSON ou HTML cru.
4. Usar paginação keyset por `(created_at DESC,id DESC)`, cursor opaco vinculado
   a usuário, perfil, entidade, recursividade e filtros, sem `COUNT(*)` ou
   `OFFSET`.
5. Usar página padrão de 25 e máxima de 100 registros; período padrão de 24
   horas e máximo interativo de 31 dias.
6. Não permitir busca livre no `payload`, ordenação arbitrária ou carregamento
   automático de todo o histórico.
7. Exigir `audit_sensitive` para qualquer detalhe sensível e manter IP, valor de
   PII, token, URI com query e conteúdo de chamado fora da interface normal.
8. Exportar somente com `audit_export`, CSRF, confirmação, finalidade
   estruturada, limite de volume e processamento assíncrono fora do request web.
9. Corrigir a data apresentada pelo chatbot: o logger fornece `created_at`, que
   deve ser consumido pelo template.
10. Substituir no chatbot o direito atual `pii.reveal` por `audit_read`; não
    sugerir nem executar a intenção para perfis não autorizados. O chatbot deve
    usar o mesmo `AuditQueryService`, limite pequeno e conteúdo sanitizado.
11. No modo `critical`, explicar que a ausência de eventos rotineiros é
    esperada, não falha de consulta.
12. No modo `disabled`, informar que não há novos eventos e que registros
    históricos ainda podem aparecer até sua expiração.
13. Distinguir textualmente a trilha persistente do “Diagnóstico local de
    acessibilidade”, que usa Axe apenas na aba e não persiste resultados.

Usuários sem direitos não recebem menu, resultados ou contagens. Eles recebem
apenas o aviso de transparência:

> Para segurança, suporte e rastreabilidade, o portal registra metadados de
> operações relevantes. O acesso é restrito a administradores autorizados e os
> registros são mantidos conforme a política institucional.

### 6. Retenção

1. Executar retenção em todos os modos, inclusive `disabled`.
2. Preferir execução externa/CLI do CronTask em produção.
3. Processar vários lotes limitados por execução, encerrando após cinco lotes
   ou dois segundos, o que ocorrer primeiro.
4. Reagendar rapidamente quando `has_more=true`, sem laço ilimitado.
5. Medir capacidade diária e manter pelo menos duas vezes o percentil 95 do
   volume persistido diário.
6. Preservar o índice `(created_at,id)` e somente adicionar novos índices após
   `EXPLAIN` e teste representativo.
7. Não executar purga dentro da requisição interativa.

## Plano de testes revisado

### Matriz funcional obrigatória

Executar todas as seis combinações da matriz de proteção e auditoria em GLPI 10
e GLPI 11.

Para cada combinação, validar:

1. aparência e disponibilidade dos controles de mascaramento/revelação;
2. quantidade e tipo exatos de registros antes e depois da ação;
3. ausência de `piireveals` e `pii.reveal` sempre que a proteção estiver
   desativada;
4. revelação bloqueada quando proteção ativa e auditoria `disabled`;
5. ausência de eventos operacionais novos em `disabled`;
6. retenção histórica ainda executada em `disabled`;
7. nenhuma exclusão retroativa ao alternar configurações.

### Segurança e privacidade

1. Tentar revelar sem permissão, sem justificativa e com falha simulada no
   banco; o dado deve permanecer mascarado em todos os casos.
2. Confirmar exatamente um registro de revelação válida, sem conteúdo revelado
   no `payload`.
3. Inspecionar banco, logs e respostas para comprovar ausência de termos livres,
   contatos, cookies, tokens, SQL e stack traces.
4. Confirmar que IP não aparece em eventos rotineiros.
5. Testar valor de modo ausente, inválido ou adulterado; o resultado nunca pode
   ser `disabled` implicitamente.
6. Confirmar que a configuração local é indispensável para habilitar
   `disabled`.

### Autorização e acesso administrativo

1. Confirmar que usuário comum, perfil de leitura, técnico com `ticket UPDATE`
   e usuário com `pii.reveal`, mas sem `audit_read`, recebem negação controlada
   na tela, API, URL direta e chatbot, sem vazamento de ID ou contagem.
2. Confirmar que `audit_read` sem `audit_sensitive`, `audit_export` ou
   `audit_global` não herda nenhuma dessas capacidades.
3. Validar entidade, recursividade e `Ticket::can(..., READ)` em todos os
   registros vinculados a chamado.
4. Validar que eventos globais não aparecem apenas porque a entidade raiz está
   ativa.
5. Trocar perfil e entidade durante a sessão e confirmar atualização imediata
   do conjunto autorizado e invalidação dos cursores anteriores.
6. Confirmar que tela, chatbot e exportação retornam o mesmo subconjunto
   autorizado pelo `AuditQueryService`.
7. Executar a matriz completa em GLPI 10 e GLPI 11, incluindo perfis
   personalizados e tentativa de acesso direto aos endpoints.
8. Confirmar que consulta sensível e exportação geram auditoria crítica mínima,
   sem copiar filtros livres ou conteúdo consultado.

### Desempenho e retenção

Usar bases sintéticas de 100 mil, 1 milhão e 5 milhões de eventos.

Metas de aceite:

- `critical` reduz pelo menos 75% dos `INSERTs` e 65% dos bytes/redo em relação
  a `full` nas jornadas de pesquisa e listagem;
- eventos críticos esperados: 100% presentes, zero duplicidade e zero evento
  desconhecido;
- `INSERT` p95 menor ou igual a 10 ms e p99 menor ou igual a 50 ms;
- lote de retenção p95 menor ou igual a 1 s e máximo menor ou igual a 5 s;
- consulta recente de 30 eventos, incluindo ACL, p95 menor ou igual a 100 ms;
- zero deadlock e nenhuma ampliação relevante de 429, 503, 504, memória ou fila
  do PHP-FPM;
- pelo menos 23 de 24 execuções horárias válidas por dia;
- backlog expirado drenado em menos de duas horas.

### Acessibilidade

1. Operar toda a configuração somente por teclado.
2. Validar nomes, descrições, estados, avisos e confirmação com NVDA e leitor de
   tela equivalente adotado na homologação.
3. Confirmar foco restaurado e anúncio único após salvar ou rejeitar mudança.
4. Executar Axe/Pa11y e revisão manual WCAG 2.2 AA/eMAG, sem confiar apenas na
   automação.

## Entrega e implantação em ciclo único

A versão deve ser construída e liberada como uma unidade funcional, sem modo
transitório baseado em `config UPDATE`, `ticket UPDATE`, `pii.reveal`, nome ou ID
de perfil e sem deixar consulta administrativa ou autorização para versão
posterior.

Escopo indivisível da entrega:

1. migração, direitos nativos e bootstrap administrativo;
2. catálogo, política, sanitização e verificação de escrita;
3. modos `full`, `critical` e `disabled` com a matriz de PII;
4. `AuditAuthorization` e `AuditQueryService` compartilhados;
5. página administrativa acessível, chatbot corrigido e exportação protegida;
6. retenção limitada fora da requisição interativa;
7. testes automatizados e homologação GLPI 10/11.

Antes de instalar essa única versão em produção, executar uma homologação única
no GLPIT com todos os gates funcionais, de autorização, privacidade,
acessibilidade e carga. Não haverá período de sete dias em modo sombra nem
liberações sucessivas de direitos. Qualquer gate reprovado bloqueia o pacote
inteiro.

Após a instalação, acompanhar erros, latência e backlog nos marcos de 2 e 24
horas sem alterar o conjunto entregue. Deve existir retorno imediato para
`full` por configuração e desativação controlada da página de consulta, sem
migração reversa ou perda de registros. O modo `disabled` não será procedimento
comum de produção.

## Critérios de conclusão

O plano somente estará concluído quando:

1. a matriz de 12 cenários (seis combinações em duas versões do GLPI) estiver
   aprovada;
2. nenhuma auditoria específica de PII for criada com a proteção desativada;
3. nenhuma revelação ocorrer sem sua trilha obrigatória;
4. dados gerais forem minimizados de acordo com catálogo e finalidade;
5. a retenção funcionar independentemente do modo de gravação;
6. as metas de desempenho forem comprovadas com carga representativa;
7. a interface e mensagens forem homologadas com tecnologia assistiva;
8. houver evidência de rollback para `full` sem perda de configuração ou
   indisponibilidade;
9. os quatro direitos estiverem registrados e o acesso inicial restrito ao
   administrador autorizado, sem dependência de nome/ID de perfil;
10. usuário com `ticket UPDATE` ou `pii.reveal`, sem `audit_read`, não obtiver
    qualquer registro pela tela, chatbot, API ou acesso direto;
11. tela, chatbot e exportação utilizarem exclusivamente o mesmo serviço de
    autorização e consulta;
12. todos os componentes do escopo indivisível forem entregues no mesmo pacote.
