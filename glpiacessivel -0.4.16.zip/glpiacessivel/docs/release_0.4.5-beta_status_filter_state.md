# GLPI Acessível 0.4.5-beta — estado dos filtros frequentes

## Objetivo

Corrigir a divergência observada na homologação: após aplicar `Status = Novo`, a consulta nativa permanecia correta e o resumo mostrava o critério, mas o seletor voltava visualmente para `Todos`.

## Solução

- O token de pesquisa guarda, além da definição nativa efetiva, o estado validado dos filtros frequentes `status` e `group_id`.
- A listagem usa a definição compilada completa para consultar o GLPI. O estado visual não é reutilizado como um segundo filtro e, portanto, não duplica nem amplia a consulta.
- Ao reconstruir o editor, o servidor remove apenas o sufixo exato que ele próprio compilou a partir dos filtros frequentes. O status volta selecionado no controle e não reaparece como regra avançada duplicada.
- A comparação do valor selecionado normaliza a chave numérica do catálogo para texto antes da comparação estrita, evitando a divergência entre `"1"` no token e `1` no array PHP.
- Qualquer divergência entre token, catálogo, campo, operador ou valor encerra a reabertura com `native_search_token_invalid`.
- Tokens legados e tokens da 0.4.4 continuam aceitos durante seu TTL, sem tentar inferir filtros frequentes que não foram armazenados.

## Compatibilidade

O mesmo pacote atende GLPI 10/PHP 8.1 e GLPI 11/PHP 8.3. A mudança não altera ACL, SQL nativo, paginação, pesquisa salva, metacritério, `GROUP BY`, `HAVING` ou limites de desempenho.

## Qualidade automatizada

- PHPUnit PHP 8.1: 680 testes e 4.136 asserções.
- PHPUnit PHP 8.3: 680 testes e 4.136 asserções.
- PHPStan: sem erros.
- PHPCS: 267 arquivos aprovados.
- Os testes novos comprovam persistência visual sem duplicação, compatibilidade de envelopes e recusa de sufixo inconsistente.

## Homologação cruzada

- GLPI 10/PHP 8.1: `Novo` permaneceu selecionado após aplicar e após recarregar; o editor apresentou 0 regras avançadas e o resumo preservou `E Status é Novo`.
- GLPI 11/PHP 8.3: mesmo resultado; a consulta retornou 4 chamados, todos com status `Novo`.
- O marcador de runtime `20260828-4` renovou o código em execução sem reinício do PHP-FPM.

## Rollback

Restaurar o diretório e o pacote anterior preservados antes da atualização. Os tokens da pesquisa têm duração limitada e ficam vinculados à sessão, ao perfil, à entidade e à revisão do catálogo.
