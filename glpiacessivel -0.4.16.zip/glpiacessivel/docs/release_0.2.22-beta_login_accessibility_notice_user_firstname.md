# Release 0.2.22-beta: aviso estatico no login e primeiro nome nativo

## Resultado

Esta versao acrescenta uma identificacao opcional do Portal Acessivel na tela oficial de login sem reabrir uma superficie de autenticacao do plugin. Depois da autenticacao, o cabecalho passa a mostrar o login e o primeiro nome que o GLPI ja mantem na sessao.

## Aviso opcional no login

A administracao passa a oferecer **Aviso de acessibilidade na tela de login**:

- **Nao exibir (padrao seguro):** nao registra o hook quando `native_only` esta ativo;
- **Exibir aviso informativo:** mostra `Login acessivel. Apos entrar, voce podera usar o Portal Acessivel.` na area auxiliar nativa de login.

A chave persistida e `show_login_accessibility_notice`. Ela nasce desativada e falha para desativada quando a configuracao ou o banco estiverem indisponiveis.

## Fronteira de seguranca

O aviso e um paragrafo estatico com icone decorativo. Ele nao contem link, botao, formulario, campo, `href`, JavaScript ou rota. O login, a senha, o SSO e o MFA continuam integralmente sob responsabilidade do GLPI ou do IdP.

No modo `accessible_bridge`, a ponte compativel existente substitui o aviso para evitar duplicidade. O modo futuro `strict_authenticated_portal` continua reservado e nao pode ser selecionado ou ativado nesta versao.

## Identidade autenticada

O rotulo do cabecalho usa:

- `glpiname` para o login;
- `glpifirstname` para o primeiro nome;
- fallback para somente o login quando o primeiro nome estiver vazio.

O campo `glpirealname`, normalmente usado pelo GLPI para sobrenome, deixa de compor esse rotulo. GLPI 10 e GLPI 11 preenchem os dois campos escolhidos durante a inicializacao nativa da sessao, portanto nao foi adicionada consulta ao banco.

## Compatibilidade e posicionamento

O hook oficial `DISPLAY_LOGIN` fica em uma area auxiliar ao formulario tanto no GLPI 10 quanto no 11. O plugin usa essa posicao suportada e nao move o aviso pelo DOM. Isso evita seletores frageis e JavaScript pre-autenticacao; a posicao exatamente abaixo de `Entrar` dependeria de extensao futura do template nativo.

Nao ha nova tabela, coluna ou migracao de esquema. A preferencia utiliza a tabela chave/valor existente.

## Configuracao e auditoria

A alteracao exige sessao autenticada, permissao de configuracao, CSRF e valor fechado `0` ou `1`. A auditoria `config.login_accessibility_notice_updated` registra somente o valor anterior e o atual, sem login, primeiro nome, senha ou token.

O diagnostico administrativo mostra o estado efetivo do aviso para facilitar a homologacao.

## Validacao automatizada

- PHPUnit: **374 testes e 2.065 assercoes**;
- PHPStan: **sem erros** em 170 arquivos analisados;
- PHPCS: **169 de 169 arquivos aprovados**;
- navegador: **3 de 3 testes aprovados**;
- i18n: **566 mensagens consistentes**, compiladas e verificadas com `msgfmt`;
- regressao especifica confirma que o aviso nao contem elementos interativos ou scripts;
- regressao de sessao confirma `login — primeiro nome` e ausencia do sobrenome no fallback;
- pacote Marketplace verificado quanto a raiz, versao, documentos, caminhos proibidos e SHA-256.

## Homologacao externa necessaria

Antes da producao, validar no ambiente institucional:

- login local, SSO e MFA no GLPI 10 e no GLPI 11;
- aviso desativado e ativado, inclusive contraste, reflow e cores forcadas;
- leitura do aviso com NVDA, JAWS ou VoiceOver sem anuncio de acao inexistente;
- rotulo com primeiro nome preenchido e vazio;
- modo `accessible_bridge` sem duplicidade de aviso;
- expiracao de sessao e retorno ao portal depois do login.

## Geracao e verificacao

```powershell
.\tools\build-release.ps1 -Output .release_0.2.22-beta_login_accessibility_notice_user_firstname -Profile marketplace -RequireMsgfmt
.\tools\verify-release.ps1 -Package .release_0.2.22-beta_login_accessibility_notice_user_firstname\glpiacessivel.zip -ExpectedVersion 0.2.22-beta -PublicProfile
```

O rollback operacional consiste em selecionar `Nao exibir`; nao exige downgrade, alteracao de URL ou migracao de banco.
