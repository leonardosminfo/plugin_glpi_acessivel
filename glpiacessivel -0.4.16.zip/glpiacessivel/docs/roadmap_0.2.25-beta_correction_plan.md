# Plano integrado de correcao 0.2.25-beta

## Estado de aprovacao

Roadmap aprovado com ressalvas obrigatorias em 13 de agosto de 2026, apos revisoes independentes de integracao GLPI, acessibilidade/UX e arquitetura/seguranca/desempenho.

As ressalvas deste documento e dos planos tecnicos vinculados sao pre-condicoes de implementacao. Nenhuma frente pode iniciar codificacao sem contrato verificavel de autorizacao, falha fechada, acessibilidade e rollback. A aprovacao do roadmap nao aprova antecipadamente codigo, pacote ou implantacao.

## Objetivo da versao

A `0.2.25-beta` sera uma versao de correcao e escalabilidade, sem ampliacao funcional desconectada dos problemas observados na homologacao. Ela integra tres frentes P0:

1. eliminar o HTTP 504 e o custo adicional excessivo na lista de chamados;
2. substituir listas completas de grande cardinalidade por seletores pesquisaveis com autocomplete remoto, paginado e acessivel;
3. restaurar o catalogo autorizado do Formcreator sem enfraquecer ACL, entidade, idioma ou hooks nativos.

Os planos tecnicos detalhados permanecem como fonte dos respectivos contratos:

- `roadmap_0.2.25-beta_ticket_list_performance.md`;
- `roadmap_0.2.25-beta_formcreator_catalog_visibility.md`.

Este documento e o gate mestre. Uma frente aprovada isoladamente nao autoriza o empacotamento da versao enquanto outra P0 permanecer reprovada.

## Estado da implementacao da candidata

Em 13 de agosto de 2026, a candidata `0.2.25-beta` passou a conter as tres frentes sob flags server-side independentes e inicialmente desativadas. Foram implementados: hidratacao em lote e resultados assincronos de chamados; seletores remotos com cursor, contexto, rate limit e revalidacao integral; e gateway paginado do Formcreator 2.13 com autorizacao sobre objeto carregado.

Os gates locais automatizados foram executados. A candidata permanece destinada a homologacao: comparacao diferencial de ACL/IDs, desempenho com volume real, GLPI 10/11 e testes manuais com NVDA/JAWS continuam obrigatorios antes de habilitar qualquer flag fora do canario.

## Evidencias de homologacao que motivam a versao

### Lista de chamados

- A busca nativa do GLPI concluiu em aproximadamente 31 segundos no contexto medido.
- A lista do Portal Acessivel retornou HTTP 504 em `Todos` e `Meus chamados`.
- O codigo reconstrui catalogos antes da lista, executa Search API e hidrata e autoriza novamente cada linha, criando trabalho adicional e N+1.

### Dados de grande cardinalidade

- A abertura de chamado criou mais de cinco mil elementos no DOM.
- Categorias, localizacoes e atores foram carregados integralmente antes da pesquisa do usuario.
- Esse comportamento aumenta latencia e torna os controles extensos para leitores de tela.

### Formularios

- O Formcreator foi detectado como ativo, mas o portal apresentou zero itens.
- A implementacao chamou `canViewForRequest($id)` em uma instancia vazia, embora o contrato 2.13.x exija objeto carregado e chamada sem ID.
- A consulta propria ainda ignorava partes da visibilidade nativa, tinha limite global de 80 e convertia excecoes em lista vazia legitima.

## Escopo integrado

### Frente A - lista de chamados

Entregas obrigatorias:

- observabilidade por etapa e contrato de privacidade;
- `TicketSearchGateway` com compatibilidade GLPI 10/11;
- estrutura de pagina rapida e carregamento assincrono dos resultados;
- catalogo leve inicial e catalogo avancado sob demanda;
- eliminacao de `getFromDB()`/`can()` e consultas de relacao por linha;
- hidratacao em lote com fronteira de autorizacao comprovada;
- erro, timeout, sessao expirada e rede tratados dentro da pagina acessivel;
- comparacao diferencial com a busca nativa no mesmo contexto.

Especificacao: `roadmap_0.2.25-beta_ticket_list_performance.md`.

### Frente B - seletores de grande cardinalidade

Entregas obrigatorias:

- experiencia de seletor pesquisavel semelhante ao GLPI: rotulo, valor selecionado e resultados de autocomplete no mesmo controle, sem painel externo de busca e botao `Adicionar` como fluxo principal;
- autocomplete remoto e paginado no servidor para categoria, localizacao, usuario e grupo, sem filtrar localmente milhares de opcoes previamente carregadas;
- aplicacao em criacao, atribuicao, observadores e filtros avancados;
- selecao simples para categoria e localizacao e selecao multipla para tecnicos, grupos e observadores;
- cancelamento de respostas antigas, debounce e estados de carregamento/erro;
- teclado completo, `combobox`/`listbox` acessivel e paginacao por acao explicita, sem depender de rolagem infinita;
- carregamento inicial somente da selecao atual e de uma pagina curta de ate 20 sugestoes;
- itens multiplos apresentados em lista de selecionados, cada um com acao de remocao nomeada;
- envio de IDs estaveis e revalidacao de ACL, entidade e elegibilidade no servidor;
- ausencia de duplicacao entre candidatos e selecionados e ausencia de opcao candidata preselecionada para inclusao acidental;
- fallback progressivo para o controle nativo seguro quando o componente remoto nao estiver disponivel, sem materializar automaticamente a lista completa.

Nao atende esta frente um `<select>` com milhares de opcoes apenas filtrado por JavaScript, um `datalist`, uma rolagem infinita sem alternativa ou um campo de texto livre que aceite valor nao confirmado pelo GLPI.

Dois contratos nao intercambiaveis sao obrigatorios:

- `resource_selector`: usado em criacao e atualizacao para categoria, localizacao, usuario ou grupo; retorna ID nativo positivo e exige revalidacao integral antes da operacao;
- `search_option_value`: identificado por `itemtype`, Search Option e operador; retorna valor nativo opaco, rotulo e metadados de validacao, sem coercao generica para inteiro.

Autocomplete remoto somente sera usado para datatype ou provedor nativo comprovado. Texto, numero, data e booleano usam controles acessiveis adequados. Search Option `specific`, metacriterio ou opcao de plugin sem adaptador homologado torna a consulta inteira `native_only`, sem descartar ou aproximar criterios.

Esta frente pode compartilhar infraestrutura transversal, estados e componentes acessiveis com a Frente A, mas deve manter rota ou handler, allowlist, autorizacao, limites, metricas e flag operacional isolados. Nao deve depender da conclusao da consulta de chamados para funcionar.

Especificacao: secao P0.8 de `roadmap_0.2.25-beta_ticket_list_performance.md`.

### Frente C - catalogo Formcreator

Entregas obrigatorias:

- `Formcreator213CatalogGateway` ativado apenas quando o contrato for comprovado;
- consulta coletiva baseada em `getFormListQuery()`;
- nova instancia, `getFromDB($id)` e `canViewForRequest()` sem argumento para cada candidato;
- `findAuthorized($id)` com revalidacao antes de schema, incorporacao ou redirecionamento;
- retirada do limite global de 80 e paginacao/cursor sem omissao;
- busca servidor-side que preserve integralmente a consulta nativa;
- schema dinamico somente depois da abertura autorizada, nunca para todos os cards;
- estados distintos para fonte ausente, inativa, incompatível, vazia, parcial e com erro;
- mensagens, foco, historico e cards acessiveis;
- chave de rollback para manter somente o catalogo nativo.

Especificacao: `roadmap_0.2.25-beta_formcreator_catalog_visibility.md`.

## Arquitetura compartilhada

As frentes devem reutilizar conceitos, mas manter fontes de autorizacao separadas:

| Componente | Lista de chamados | Formcreator |
|---|---|---|
| Fonte de verdade | Search API e ACL do GLPI | `getFormListQuery()` mais `canViewForRequest()` |
| Adaptador | `TicketSearchGateway` | `Formcreator213CatalogGateway` |
| Lista inicial | estrutura rapida e resultado assincrono | pagina leve, sem schemas |
| Detalhe/abertura | autorizacao do chamado preservada | `findAuthorized()` obrigatorio |
| Cache inicial | memoizacao por requisicao | memoizacao por requisicao |
| Persistencia local | proibida para resultados/pesquisas | proibida para catalogo/autorizacao |
| Falha | fechada e acessivel | fechada, link nativo e sem revelar existencia |

Estados compartilhados devem usar o mesmo padrao visual e semantico (`loading`, `ready`, `ready_empty`, `partial`, `error`), sem forcar as duas fontes a compartilhar regras de ACL ou chaves de cache.

### Contratos transversais obrigatorios

- Usuario, perfil, entidade, entidades acessiveis, recursividade, idioma e direitos sao derivados exclusivamente da sessao GLPI; o navegador nunca informa nem substitui esse contexto.
- Endpoints personalizados retornam JSON versionado, inclusive para sessao expirada e erro, sem redirecionamento HTML, stack trace ou mensagem interna.
- Consultas POST seguem a politica CSRF do GLPI; toda mutacao usa POST e token CSRF nativo. GET so e permitido quando estritamente idempotente e sem termo sensivel em URL.
- Respostas personalizadas usam mesma origem, CORS fechado e `Cache-Control: private, no-store`; nao sao persistidas em `localStorage`, service worker ou cache compartilhado.
- Debounce e cancelamento no navegador nao substituem rate limiting, limite de concorrencia e orcamento de tempo no servidor.
- Cursor nunca funciona como autorizacao. Todo ID e todo valor nativo sao revalidados imediatamente antes da operacao canonica do GLPI, sem efeito parcial.
- Flags operacionais sao server-side, independentes por frente/provedor e inicialmente desativadas; nao substituem ACL nem revalidacao.

## Dependencias e ordem de implementacao

### Etapa 1 - contratos, caracterizacao e observabilidade

1. Criar testes que reproduzam o 504/N+1 e a lista vazia do Formcreator.
2. Definir identificador de correlacao, codigos de etapa e regras de privacidade.
3. Criar os contratos `TicketSearchGateway` e `FormCatalogGateway`.
4. Congelar por teste os fallbacks e comportamentos seguros existentes.
5. Versionar contratos JSON e definir metodos HTTP, CSRF, codigos estruturados, limites, cursor, revisao de contexto e redacao de logs.

Gate da etapa: as falhas atuais devem ser reproduziveis e mensuraveis sem registrar dados pessoais.

### Etapa 2 - autorizacao e dados no servidor

1. Implementar `TicketSearchGateway` GLPI 10/11.
2. Eliminar N+1 da lista por hidratacao em lote autorizada.
3. Implementar `Formcreator213CatalogGateway` com as duas camadas nativas de permissao.
4. Implementar `findAuthorized()` e revalidacao de URL direta.
5. Retirar schemas completos da lista de formularios.
6. Implementar registro fechado de provedores nativos por finalidade e separar `resource_selector` de `search_option_value`.
7. Provar o snapshot de sessao e a revisao opaca de contexto antes de qualquer liberacao do bloqueio da sessao PHP.

Gate da etapa: nenhum ID adicional pode aparecer em qualquer lista ou abertura; divergencia de ACL bloqueia imediatamente o trabalho subsequente.

### Etapa 3 - carregamento progressivo e interface

1. Entregar estrutura rapida e endpoint autenticado para resultados dos chamados.
2. Separar catalogo leve e avancado.
3. Implementar pagina/busca do Formcreator e estados estruturados.
4. Implementar seletores pesquisaveis com autocomplete remoto, paginado e acessivel para dados volumosos, preservando a aparencia de um unico controle de selecao.
5. Preservar URL, foco, historico, mensagens e respostas fora de ordem.
6. Implementar selecao multipla como confirmacao de uma sugestao por vez, com selecionados em lista externa e remocao acessivel.
7. Implementar `Carregar mais resultados` como botao real adjacente e externo a `listbox`, com retorno previsivel do foco.

Gate da etapa: teclado e leitor de tela concluem busca, paginacao, abertura, criacao, atribuicao e observadores sem ajuda visual.

### Etapa 4 - desempenho, resiliencia e rollback

1. Executar linhas de base com cache frio/quente e carga controlada.
2. Investigar banco/infraestrutura somente com slow log e planos que comprovem a consulta dominante.
3. Ativar rollout gradual do catalogo Formcreator.
4. Testar falhas de API, hook, rede, sessao, timeout e resposta atrasada.
5. Validar as chaves de rollback sem restaurar implementacoes inseguras.
6. Testar rate limiting, concorrencia por sessao, cursor adulterado/expirado, requisicao abortada e troca de contexto com consultas pendentes.

Gate da etapa: nenhuma ocorrencia de 504/5xx na massa do gate, metas P95 atendidas e rollback comprovado.

### Etapa 5 - homologacao e release

1. Executar matriz GLPI 10/11, perfis, entidades, recursividade e idiomas.
2. Comparar IDs/ordem de chamados e conjunto autorizado de formularios.
3. Executar NVDA com Firefox e Chrome, JAWS com Edge, teclado, 320 CSS px, 400% e `forced-colors`, registrando versao, fala observada e resultado de cada roteiro.
4. Executar QA, i18n, build, verificacao do ZIP e documentacao tecnologica/funcional.
5. Obter aprovacao formal da autoridade de release.

## Matriz integrada minima

| Area | Cenarios P0 |
|---|---|
| Chamados | `all`, `mine`, `group`, filtros, pesquisa salva, pagina 20/50, colunas e excluidos |
| Formcreator | publico/privado/restrito, perfil/usuario/grupo, entidade recursiva, idioma, hooks, 201/500 itens e URL direta |
| Seletores | categoria/localizacao simples e usuario/grupo multiplo; zero, poucos e milhares de resultados; busca, pagina seguinte, selecao, remocao, resposta atrasada e fallback nativo |
| Filtros | texto, numero, data, booleano, referencia, `specific`, Search Options de plugins homologados, metacriterios e consulta integral `native_only` |
| Falhas | 401, 403, 422, 429, sessao expirada, 5xx, timeout interno, rede, cursor adulterado/expirado, hook/consulta com excecao e resposta fora de ordem |
| Compatibilidade | GLPI 10 com Formcreator 2.13.x e GLPI 11 com Service Catalog nativo |
| Assistiva | teclado; NVDA com Chrome/Firefox; JAWS com Edge; versao e fala observada; zoom, reflow e contraste |
| Seguranca | ACL negativa, ID/papel/tipo manipulado, troca de contexto, cache cruzado, enumeracao, rate limiting, origem/metodo/content-type, logs sem dados pessoais e CSRF |
| Desempenho | cache frio/quente, concorrencia controlada, P50/P95/P99, consultas, memoria e fila PHP-FPM |

## Gate mestre da 0.2.25-beta

A versao somente pode ser empacotada quando todos os itens abaixo estiverem aprovados:

1. Lista de chamados sem HTTP 5xx e abaixo dos limites do plano de desempenho.
2. Overhead do plugin fora de `Search::getDatas()` com P95 de ate 2 segundos.
3. Consultas da lista essencialmente constantes entre 20 e 50 chamados.
4. Paridade de IDs, ordem, total e ACL dos chamados com o GLPI.
5. Conjunto de formularios igual a `getFormListQuery()` mais autorizacao individual no mesmo contexto.
6. Zero formulario negado listado ou aberto; URL direta sempre reautorizada.
7. Todos os formularios autorizados alcancaveis sem limite global, duplicacao ou omissao.
8. P95 da primeira pagina de formularios abaixo de 2,5 segundos na massa definida e sem 504.
9. Seletores volumosos se apresentam como um unico controle pesquisavel e nao materializam milhares de opcoes no DOM inicial.
10. Autocomplete consulta o GLPI no servidor, pagina em blocos curtos, descarta respostas antigas e nunca aceita texto livre como ID selecionado.
11. Selecao simples e multipla, remocao, carregamento adicional e fallback sao concluidos por teclado e leitor de tela sem assistencia visual.
12. Endpoints especializados possuem contratos HTTP/JSON, CSRF, no-store, rate limiting, concorrencia, cursor e revisao de contexto aprovados.
13. Filtros preservam integralmente arvore, operadores e valores nativos; incompatibilidade torna a consulta inteira `native_only`.
14. Revalidacao final rejeita todo o conjunto sem efeito parcial quando qualquer ID, papel, entidade, estado ou elegibilidade falhar.
15. Vazio, parcial, erro, timeout e sessao expirada possuem estados distintos e acessiveis.
16. Fluxos essenciais concluidos por teclado e leitor de tela sem assistencia visual.
17. Zero falha confirmada de WCAG 2.2 niveis A e AA; toda ocorrencia Axe, inclusive moderada ou `incomplete`, analisada e registrada.
18. Rollback das listas/integacoes comprovado e fluxo nativo preservado.
19. Nenhuma copia local de pesquisa, resultado, catalogo ou autorizacao.
20. Nenhum dado proibido em logs, metricas, traces ou cache.
21. PHPUnit, navegador, PHPStan, PHPCS, i18n, build e verificacao do ZIP verdes.
22. Documentos `solucao_tecnologica.md` e `documentacao_funcional_e_organizacao.md` atualizados para a nova versao.
23. Homologacao externa e autoridade de release aprovam formalmente a entrega.

Qualquer falso positivo de ACL, 504 recorrente atribuivel ao plugin, divergencia silenciosa, falha assistiva essencial ou regressao GLPI 10/11 bloqueia codigo e empacotamento. Capacidade insuficiente comprovadamente nativa bloqueia o piloto no ambiente afetado conforme a politica abaixo.

## Rollout e rollback integrados

- Criar flags server-side, independentes e inicialmente desativadas para lista assincrona, autocomplete por fluxo/provedor e catalogo Formcreator; parametros do cliente nao podem controla-las.
- Implantar em sequencia: Super-Admin, QA nao administrador em entidade limitada, usuarios de tecnologia assistiva e ampliacao gradual.
- Habilitar o catalogo Formcreator por chave operacional somente depois da comparacao de IDs.
- Manter link para listas e formularios nativos durante todo o piloto.
- Em falha do catalogo Formcreator, desativar apenas essa integracao e manter o link nativo.
- Em falha do endpoint assincrono de chamados, retornar ao fluxo nativo; nao reativar o N+1 antigo.
- Em falha de autocomplete, preservar a selecao atual, anunciar a indisponibilidade e encaminhar ao controle nativo seguro; nao carregar automaticamente milhares de opcoes nem aceitar texto nao confirmado.
- Em erro transitorio e contexto inalterado, preservar os selecionados enquanto a pagina existir. Em troca de perfil, entidade, recursividade ou direitos, marcar valores anteriores como indisponiveis e impedir o envio.
- Antes de navegacao de fallback que possa perder dados ainda nao enviados, informar o risco e solicitar confirmacao; nao prometer recuperacao apos recarga ou reautenticacao sem mecanismo comprovado.
- Divergencia de ACL exige desligamento imediato da flag afetada. Taxa de 5xx/timeout, P95 ou 429 anormal por duas janelas consecutivas exige rollback ou reducao do canario conforme limites homologados.
- Assets e contratos JSON devem ser versionados para impedir frontend antigo com backend novo; testar rollback com aba ja aberta.
- Ajustes temporarios de timeout devem ter responsavel, prazo e rollback, sem encerrar o item tecnico.

## Politica de empacotamento e implantacao

O gate de codigo, seguranca, funcionalidade e acessibilidade bloqueia o empacotamento da versao. O gate de capacidade da implantacao bloqueia piloto ou producao no ambiente reprovado, mas nao transforma lentidao comprovadamente nativa do GLPI em falha do codigo do plugin. A release so pode declarar o ambiente apto quando ambos estiverem aprovados. Qualquer 5xx causado pelo plugin, divergencia de ACL ou falha assistiva essencial continua bloqueando codigo e pacote.

## Responsabilidades

- Backend/plugin: gateways, autorizacao, lotes, endpoints, estados e rollback.
- Web/acessibilidade: busca, paginacao, foco, anuncios, combobox e reflow.
- QA: caracterizacao, matrizes diferenciais, carga e rastreabilidade dos gates.
- Infraestrutura/DBA: correlacao, PHP-FPM, proxy, slow log, planos, indices e capacidade.
- Seguranca/privacidade: ACL negativa, CSRF, logging, retencao e dados de teste.
- Dono do SLO: metas operacionais e registro de bloqueadores externos.
- Autoridade de release: decisao final de empacotamento.

## Checklist mestre

- [x] Frente A - lista de chamados implementada e coberta localmente.
- [x] Frente B - seletores pesquisaveis implementados e cobertos localmente.
- [x] Contratos `resource_selector` e `search_option_value` separados e cobertos.
- [x] HTTP/JSON, CSRF, rate limiting, cursor, contexto e revalidacao integral cobertos localmente.
- [x] Frente C - catalogo Formcreator implementado e coberto localmente.
- [ ] Paridade e ACL GLPI 10/11 aprovadas.
- [ ] Desempenho e resiliencia aprovados.
- [ ] Acessibilidade automatizada e manual aprovada.
- [ ] Rollback e fluxo nativo aprovados.
- [x] QA automatizado, i18n, build e ZIP aprovados localmente.
- [x] Documentacao tecnologica e funcional atualizada.
- [ ] Homologacao externa e autoridade de release aprovadas.
