# Plano de homologação — GLPI Acessível 0.4.1-beta

## Critério de entrada

- instalar exatamente o ZIP da `0.4.1-beta` e registrar seu SHA-256;
- usar cópia de homologação com volume e índices representativos;
- executar separadamente GLPI 10 + Formcreator compatível e GLPI 11 + Service Catalog;
- incluir Self-Service, técnico/hotliner e Super-Admin em entidade simples e recursiva;
- confirmar MySQL `>= 5.7.8` ou MariaDB `>= 10.2` e registrar versão de PHP-FPM, proxy, plugins e configuração da lista;
- confirmar que a instalação falha com mensagem explícita em uma versão de banco abaixo do requisito.

## 1. Paridade funcional da Search

Em cada versão do GLPI, executar primeiro na lista nativa e depois no portal acessível:

1. meus chamados, todos os chamados permitidos e chamados de grupos responsáveis;
2. busca textual e filtros simples;
3. grupos aninhados com `AND`, `OR`, `AND NOT` e `OR NOT`;
4. campo relacionado, metacritério e ordenação ascendente/descendente;
5. agregação ou opção que produza `GROUP BY` e `HAVING`;
6. pesquisa salva pessoal, pública autorizada e pesquisa recorrente anterior;
7. Search Option fornecida por plugin instalado.

Aceite: a sequência de IDs e a ordem da página acessível devem coincidir com a página nativa no mesmo perfil, entidade, recursividade e instante. Resultado vazio precisa ser vazio nos dois lados; contrato não comprovado precisa informar indisponibilidade, nunca ampliar o conjunto.

## 2. Limites e paginação

- testar tamanhos 10, 20 e 50;
- confirmar no log controlado que a SQL final contém exatamente um `LIMIT offset, page_size + 1`;
- confirmar que somente 50 itens são hidratados quando a janela retorna 51 IDs;
- navegar anterior/próxima e confirmar desempate estável por ID;
- recusar tamanho acima de 50 e deslocamento acima de 10.000;
- confirmar que não existe chamada a `Search::getDatas()` nem contagem global no caminho da lista.

## 3. Banco e recuperação

- provocar consulta com duração superior a 3 segundos em massa sintética;
- MySQL: confirmar interrupção pelo hint e restauração do `@@SESSION.group_concat_max_len`;
- MariaDB: confirmar interrupção por `max_statement_time` e escopo somente da instrução;
- simular falha de snapshot, aplicação, execução e restauração;
- confirmar resposta recuperável, ausência de SQL ou exceção na tela e disponibilidade do link para a lista nativa.

Aceite: nenhuma tentativa pode ultrapassar o orçamento server-side de forma sustentada nem deixar configuração de sessão alterada.

## 4. Capacidade e carga

- disparar 1, 2 e mais de 2 consultas simultâneas por servidor;
- repetir pelo mesmo usuário/contexto e por usuários diferentes;
- confirmar `429` em contenção e `503` em falha do backend, ambos com `Retry-After`;
- confirmar validade mínima de 8 segundos e liberação em `finally` após sucesso ou falha;
- em múltiplos nós, usar e testar o adaptador externo; não aprovar coordenação somente local;
- observar PHP-FPM, CPU, memória, conexões, slow query log e tempo do proxy por pelo menos 30 minutos de carga representativa.

## 5. Contrato de interface e acessibilidade

- validar SSR e assíncrono com contrato V2;
- testar total conhecido, adiado e indisponível sem anúncio de falso zero;
- confirmar um único anúncio após cada carregamento;
- verificar “N nesta página” em agrupamentos;
- provocar `Retry-After` em segundos e em data HTTP e validar botão desabilitado com contagem regressiva;
- operar lista, filtros, paginação, erro e recuperação somente por teclado;
- testar 320 pixels CSS, zoom de 200%, contraste, cores forçadas, NVDA e ao menos outra tecnologia assistiva;
- executar axe/Pa11y e registrar a revisão manual, sem tratar automação como certificação.

## 6. Segurança e contexto

- trocar perfil, entidade e recursividade durante uma pesquisa pendente;
- testar pesquisa salva privada de outro usuário e pública sem direito;
- confirmar que IDs fora da Search nativa não são hidratados;
- confirmar falha fechada para fragmento ausente, alias `id` ausente, versão desconhecida, SQL múltipla e token de contexto expirado;
- verificar que respostas e auditoria não expõem SQL, termos livres ou exceções.

## 7. Rollback

1. desabilitar a lista assíncrona se ela for a origem comprovada de uma regressão;
2. desabilitar o módulo de chamados acessível e manter a lista nativa disponível;
3. restaurar o diretório anterior do plugin e executar a atualização pelo GLPI;
4. limpar cache do GLPI e invalidar somente os arquivos PHP do plugin conforme o procedimento operacional;
5. repetir login, contexto, lista nativa e abertura de chamado.

## GO/NO-GO

GO exige: automação integral verde em PHP 8.1 e 8.3, pacote verificado, paridade de IDs nos cenários acima, timeout comprovado no banco real, ausência de `Gateway Timeout` na carga acordada, zero falha crítica de ACL/CSRF/contexto e ausência de barreira bloqueante nos testes assistivos.

NO-GO: qualquer ampliação de resultados, divergência não explicada de IDs/ordem, reserva expirada durante consulta ativa, alteração de sessão do banco não restaurada, timeout recorrente, resposta sem recuperação ou barreira impeditiva de teclado/leitor de tela.
