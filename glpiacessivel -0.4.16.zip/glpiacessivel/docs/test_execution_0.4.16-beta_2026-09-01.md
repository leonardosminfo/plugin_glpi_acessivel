# Execução de testes — GLPI Acessível 0.4.16-beta — 01/09/2026

## Artefato e atualização

- origem: `0.4.15-beta` ativa nos dois ambientes;
- destino: `0.4.16-beta`, runtime epoch `20260901-08`;
- instalação nativa forçada e reativação concluídas no GLPI 10 e no GLPI 11;
- nenhum restart de PHP-FPM ou dos contêineres foi executado depois da cópia;
- PHP e JavaScript novos foram observados nas respostas, inclusive `glpiacessivel.js?v=0.4.16-beta-*` e o novo resumo de filtros.

## Gates automatizados

| Gate | Resultado |
|---|---|
| PHPUnit/PHP 8.1.31 | 845 testes e 5.191 asserções aprovados |
| PHPStan | sem erros em 297 arquivos |
| PHPCS | sem erros em 296 arquivos |
| Navegador | 83 verificações aprovadas em 21 arquivos |
| i18n | 2.657 mensagens; POT/PO/MO e `msgfmt` aprovados |
| ZIP público | raiz única, perfil Marketplace e 355 entradas aprovados |

## Homologação autenticada

Nos dois ambientes foram percorridos portal, fila com `Status = Novo`, pesquisa salva, abertura, detalhe e base de conhecimento.

- 6/6 rotas autenticadas por ambiente;
- zero erro de servidor e zero violação Axe confirmada;
- 6/6 rotas sem rolagem horizontal a 320 pixels CSS;
- seletor e resumo mantiveram `Status: Novo` na primeira e na segunda página;
- pesquisas salvas conservaram o resumo nativo, sem substituição pelo resumo frequente.

O Axe manteve `aria-valid-attr-value` como revisão inconclusiva nos seletores remotos. A inspeção concreta confirmou exatamente um alvo existente para cada `aria-controls` e nenhum `aria-activedescendant` inválido; portanto, não foi classificado como violação confirmada.

## FormCreator real no GLPI 10

O formulário sintético complexo `id=2` foi aberto no modo incorporado:

- formulário nativo verificado e modo mínimo ativo;
- cabeçalho e sidebar internos ocultos, `aria-hidden`, `inert` e fora da árvore operacional;
- cinco controles verificados e nenhum sem nome acessível;
- dois Select2 anunciaram rótulo do campo e valor atual;
- todos os IDs referenciados por `aria-labelledby` e `aria-describedby` existiam;
- documento externo coube em 320 pixels e o documento do iframe em 252 pixels, sem overflow.

O caso “Ramal + Telefone”, existente em GLPIT mas ausente nas fixtures locais atuais, foi coberto pelo teste realista de navegador, inclusive mismatch entre `for` e ID aleatório e recriação do Select2.

## Carga autenticada curta

| Ambiente | Sucesso | Backend | p95 | Máximo |
|---|---:|---|---:|---:|
| GLPI 10 | 5/5 HTTP 200 | `search_api` / `bounded_native_search` | 32 ms | 32 ms |
| GLPI 11 | 5/5 HTTP 200 | `search_api` / `bounded_native_search` | 43 ms | 43 ms |

Os totais permaneceram diferidos, com 20 itens por página, sem `429`, `502`, `504` ou falha.

## Estados complementares

- catálogo com tipo de solução elegível: `Não informar` e o tipo configurado foram exibidos normalmente;
- catálogo vazio: mensagem, associação por `aria-describedby` e payload nativo sem tipo foram cobertos por regressão PHPUnit;
- indisponibilidade do VLibras: mensagem, cooldown de cinco minutos e retentativa após `online` foram cobertos por navegador; a integração real carregou o botão nomeado e imagens decorativas com `alt=""`.

## Pendências manuais antes da publicação

1. repetir teclado e leitor de tela (NVDA/Firefox e NVDA/Chrome) no pacote instalado em GLPIT;
2. confirmar no formulário institucional “Ramal + Telefone” os mesmos nomes observados na fixture;
3. simular indisponibilidade externa do VLibras no ambiente de homologação;
4. manter as ocorrências Axe inconclusivas separadas de violações confirmadas.
