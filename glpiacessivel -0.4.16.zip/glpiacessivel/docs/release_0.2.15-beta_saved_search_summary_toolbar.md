# Release 0.2.15-beta: resumo fiel de SavedSearch e barra acessível

Data: 2026-07-31

## Finalidade da versão

A `0.2.15-beta` consolida a aplicação, a explicação e o gerenciamento das pesquisas de chamados já salvas no GLPI. O objetivo é oferecer às pessoas cegas, às pessoas com baixa visão e aos usuários de teclado uma experiência previsível e próxima da semântica da pesquisa nativa, sem criar uma fonte de verdade paralela.

Esta versão permanece destinada à homologação externa em instalações reais do GLPI 10 e 11. Ela não representa certificação definitiva de acessibilidade, aprovação para produção, validação de todas as combinações de plugins, perfis e entidades ou aprovação no Marketplace GLPI.

Não há migração de banco específica para esta versão.

## Resumo fiel da pesquisa aplicada

Quando uma pesquisa compatível é aplicada, o portal produz um resumo textual e estruturado a partir da definição efetivamente validada. O resumo pode apresentar:

- nome autorizado da SavedSearch;
- escopo e texto livre;
- critérios e metacritérios, com rótulos obtidos do catálogo contextual;
- escopo de chamados ativos ou excluídos;
- múltiplas ordenações e suas direções;
- colunas apresentadas;
- quantidade de resultados por página;
- avisos quando uma parte de apresentação deixa de estar disponível no perfil ou na entidade atuais.

O resumo não conhece nem publica `SavedSearch.id`, `entities_id`, fingerprint, motivos internos de capacidade, parâmetros nativos brutos, tabela, `users_id`, condição SQL, direitos ou tokens de autorização. Para campos remotos, o texto acessível não reproduz o identificador técnico: anuncia que há um valor selecionado ou usa o rótulo autorizado disponível.

A SavedSearch com capacidade `native_only` não é descrita como se seus critérios tivessem sido aplicados pelo construtor. O portal informa que os critérios completos estão disponíveis apenas na interface nativa e oferece o caminho “Abrir pesquisa completa no GLPI”. A listagem falha de forma fechada quando não consegue executar a consulta com fidelidade.

## SavedSearch, AST versão 3 e `forcetoview`

`SavedSearch` e `SavedSearch_User` continuam sendo as fontes de verdade. O plugin não copia pesquisas para tabelas próprias e não mantém um catálogo paralelo.

A representação editável preserva a AST versão 3 do construtor acessível. Antes de qualquer execução ou gravação, critérios, metacritérios, ordenações, colunas, escopo de excluídos e contratos de valor são revalidados contra o catálogo do perfil, da entidade e da recursividade atuais.

A adaptação entre GLPI 10 e GLPI 11 projeta somente os parâmetros que alteram a semântica autorizada da consulta:

- `itemtype`;
- `criteria`;
- `metacriteria`;
- `sort`;
- `order`;
- `is_deleted`;
- `forcetoview`, quando fornecido em formato estruturalmente válido.

Chaves internas ou de apresentação reconhecidas não são encaminhadas como semântica. Chaves arbitrárias, como `table` e `users_id`, são descartadas e fazem a pesquisa ser tratada conservadoramente quando impedem equivalência comprovada. O fallback do GLPI 10 e o formato retornado pelo GLPI 11 passam pela mesma projeção permitida.

## Barra de pesquisa e painéis de divulgação

A pesquisa de chamados passa a reunir suas ações em uma barra compacta e textual:

- **Pesquisar** submete a consulta;
- **Pesquisas salvas** abre o catálogo mantido pelo GLPI;
- **Salvar pesquisa** leva ao fluxo autorizado de criação;
- **Opções dos resultados** abre ordenação, paginação e colunas;
- **Registros: ativos/excluídos** abre o escopo permitido;
- **Limpar** remove o estado atual pelos caminhos existentes.

Os controles que apenas abrem opções usam `button type="button"`, texto visível e SVG decorativo com `aria-hidden="true"` e `focusable="false"`. Cada botão possui `aria-expanded` e `aria-controls` coerentes com um painel único.

Com JavaScript, somente um painel permanece aberto. Escape fecha o painel atual e devolve o foco ao botão que o abriu. Links profundos revelam o painel correspondente. Sem JavaScript, os painéis continuam presentes no documento e os estados ARIA iniciais descrevem essa apresentação expandida.

Abrir um painel, fechá-lo ou trocar o radio de registros ativos/excluídos não submete a pesquisa. A nova escolha só é aplicada ao acionar **Pesquisar**. O escopo de excluídos continua composto por dois radios reais e só é renderizado quando `allow_deleted` está autorizado.

O painel de pesquisas salvas permanece fora do formulário da busca avançada. Isso evita formulários aninhados e mantém válidos os formulários POST usados para criar, renomear, excluir e definir pesquisas padrão.

## Segurança preservada

A versão mantém as seguintes fronteiras:

- autenticação e direito de leitura de chamados antes da consulta;
- ACL, perfil, entidade e recursividade nativos do GLPI;
- validação contextual e lista permitida para AST, campos, operadores, valores e colunas;
- POST, CSRF e PRG para aplicação da busca avançada;
- POST, CSRF, confirmação de exclusão, fingerprint, idempotência e ACL para mutações de SavedSearch;
- revalidação de IDs remotos antes da emissão do token opaco;
- ausência de persistência local dos critérios nativos;
- falha fechada quando a Search API, a SavedSearch ou o contexto não permitem execução fiel;
- descarte de metadados e parâmetros não autorizados antes da execução e da apresentação.

## Linha de base automatizada

A linha de base integrada da `0.2.15-beta` é:

- PHPUnit: **329 testes e 1.838 asserções**;
- PHPStan: **OK**;
- PHPCS: **167 de 167 arquivos aprovados**;
- navegador: **2 de 2 testes aprovados**;
- i18n: **555 mensagens consistentes**.

Comandos principais:

```powershell
composer qa
npm run test:search-ui
```

Os testes de navegador cobrem o construtor/autocomplete e a barra de pesquisa: exclusividade dos painéis, coerência de ARIA, ausência de submissão acidental, radios de excluídos, Escape e devolução de foco, links profundos, texto visível, alvo mínimo e reflow a 320 px.

## Homologação externa obrigatória

Antes de promover a beta para produção, executar ao menos a seguinte matriz:

1. GLPI 10 suportado e GLPI 11 suportado, cada um com PHP compatível.
2. Perfil Self-Service, técnico e administrador restrito, sem ampliar permissões para facilitar o teste.
3. Entidade simples, entidade filha e escopo recursivo, incluindo troca de contexto durante a jornada.
4. SavedSearch privada, pública autorizada, padrão, editável, somente leitura, `native_only` e removida durante a sessão.
5. Critérios simples, grupos aninhados, metacritérios, múltiplas ordenações, colunas, `forcetoview` e registros excluídos quando autorizados.
6. NVDA com Firefox e Chrome ou Edge, mais uma segunda tecnologia assistiva adotada pela organização.
7. Navegação somente por teclado, ampliação, alto contraste, `forced-colors` e reflow a 320 px.
8. Dados e volumes representativos, incluindo catálogo paginado e SavedSearch fora da primeira página.

Confirmar em cada cenário:

- o resumo anunciado corresponde exatamente à consulta e aos resultados nativos;
- nenhum ID ou metadado interno aparece no resumo, DOM público, mensagens ou URL;
- abrir painéis não pesquisa nem altera resultados;
- somente **Pesquisar** aplica a alteração de escopo ou opções;
- Escape fecha e devolve o foco de maneira previsível;
- pesquisas `native_only` não recebem resumo enganoso e abrem corretamente no GLPI;
- trocar perfil ou entidade revalida catálogo, valores, SavedSearch e permissões;
- resultados excluídos nunca ficam disponíveis sem `allow_deleted`;
- criar, renomear, excluir e definir padrão respeitam CSRF, confirmação e ACL.

Interromper a homologação se houver resultado mais amplo que a pesquisa nativa, critério omitido do resumo, exposição de identificador interno, submissão acidental, foco perdido, anúncio inconsistente ou acesso fora do perfil e da entidade ativos.

## Build e verificação pública

```powershell
.\tools\build-release.ps1 `
  -Output .release_0.2.15-beta_saved_search_summary_toolbar `
  -Profile marketplace `
  -RequireMsgfmt

.\tools\verify-release.ps1 `
  -Package .release_0.2.15-beta_saved_search_summary_toolbar\glpiacessivel.zip `
  -ExpectedVersion 0.2.15-beta `
  -PublicProfile
```

O pacote deve conter uma única raiz `glpiacessivel/`, os metadados `0.2.15-beta`, este documento, licenças e avisos obrigatórios. Não pode conter `tests`, `tools`, dependências de desenvolvimento nem assets offline de voz. `SHA256SUMS` e `RELEASE_MANIFEST.json` devem corresponder ao ZIP final.

## Rollback

Se a homologação encontrar um bloqueador:

1. interromper o canário e registrar GLPI, PHP, perfil, entidade, SavedSearch, navegador e tecnologia assistiva;
2. preservar evidências sem copiar termos livres, IDs pessoais ou parâmetros nativos sensíveis;
3. restaurar o pacote beta anteriormente homologado conforme a política local;
4. limpar os caches do GLPI e do navegador;
5. repetir o cenário com dados sintéticos antes de reabrir a homologação.

Não há rollback de banco específico para a `0.2.15-beta`.