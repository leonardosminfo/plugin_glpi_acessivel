# GLPI Acessível 0.2.35-beta: linguagem acessível e i18n verificável

## Resultado

Esta beta corrige a linguagem observada na homologação da `0.2.34-beta` e amplia a proteção contra regressões linguísticas nas jornadas principais:

- criação e detalhe de chamados passam a usar português canônico acentuado em títulos, rótulos, instruções, confirmações, nomes acessíveis e mensagens anunciadas;
- prioridades, estados e textos como `Média`, `Descrição`, `Localização`, `Última atualização`, `Interações e ações ITIL` e `Solução` são apresentados de forma consistente;
- mensagens dinâmicas da busca, resultados, seletores e auditoria local usam o catálogo Gettext compartilhado, sem fallbacks portugueses sem acentuação no JavaScript;
- os pares de ativos em `assets/` e `public/assets/` continuam byte a byte equivalentes;
- o comando oficial da suíte de navegador volta a executar com a configuração explícita do Puppeteer no pnpm.

## Contratos preservados

- não há mudança na autorização, no escopo de perfil ou entidade, na Search API, na semântica de `Status não é`, nos tokens ou na revalidação de mutações;
- criação, atualização e ações ITIL continuam delegadas às APIs e permissões do GLPI;
- a apresentação reduzida do Formcreator mantém seus gates conservadores e o fallback visual completo;
- a ausência de catálogo JavaScript válido não expõe chaves internas: a melhoria progressiva não inicia e o HTML do servidor permanece disponível;
- nenhuma tabela ou cópia de dados operacionais foi criada.

## Verificação obrigatória

O gate detalhado está em [`test_plan_0.2.35-beta.md`](test_plan_0.2.35-beta.md). A liberação exige, no mínimo:

1. zero ocorrência dos textos sem acentuação registrados na homologação nas superfícies visíveis e anunciadas;
2. catálogos POT, PO e MO alinhados, sem entradas vazias ou fuzzy e com placeholders equivalentes;
3. pt-BR e en-GB íntegros na criação, detalhe, busca, resultados assíncronos, seletores, cockpit, formulários e diagnóstico local;
4. paridade funcional e de ACL com a `0.2.34-beta`, inclusive troca persistente de contexto e conjuntos exatos de chamados;
5. PHPUnit, Browser, PHPStan, PHPCS, auditoria i18n, build e verificador de release integralmente verdes.

## Empacotamento

```powershell
.\tools\build-release.ps1 -Output .release_0.2.35-beta_linguistic_accessibility -Profile marketplace -RequireMsgfmt
.\tools\verify-release.ps1 -Package .release_0.2.35-beta_linguistic_accessibility\glpiacessivel.zip -ExpectedVersion 0.2.35-beta -PublicProfile
```
