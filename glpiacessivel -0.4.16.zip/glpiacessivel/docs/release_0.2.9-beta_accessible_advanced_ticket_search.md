# Release 0.2.9-beta: busca avancada acessivel de chamados

## Resultado

A lista de chamados passa a oferecer uma busca avancada acessivel com paridade
controlada com a Search API do GLPI. O usuario pode combinar criterios, grupos
aninhados, regras globais sobre itens relacionados, ate cinco ordenacoes,
colunas, tamanho de pagina e escopo de lixeira quando sua permissao permitir.

A busca rapida continua disponivel como fluxo separado. A troca de modo nao
executa a pesquisa automaticamente nem descarta silenciosamente a definicao
avancada aplicada.

## Catalogo contextual do GLPI

`GlpiSearchOptionCatalog` consulta as opcoes de pesquisa nativas para `Ticket`
e para os itemtypes relacionados autorizados no contexto ativo. O construtor
nao mantem uma lista estatica de numeros de campo.

O catalogo entregue a interface inclui:

- identificador, rotulo, campo, tabela, linkfield e datatype da opcao nativa;
- descritor do controle de valor e opcoes de selecao quando disponiveis;
- operadores descobertos no GLPI e limitados ao conjunto homologado;
- indicacao das opcoes ordenaveis e limite de cinco ordenacoes;
- itemtypes e campos permitidos para metacriterios;
- capacidade contextual para consultar itens excluidos;
- `context_revision`, calculada sobre opcoes, relacionamentos, capacidades,
  perfil, entidade e demais elementos relevantes do contexto.

A mesma descoberta gera as listas permitidas usadas pelo validador no
servidor. Se o GLPI nao expuser um campo, operador ou relacionamento de forma
confiavel, ele nao e oferecido nem aceito.

## AST nativa, POST, PRG e token opaco

O JavaScript reindexa controles HTML nomeados e envia a definicao por `POST`.
O contrato inclui `criteria`, `global_rules`, `sorts`, `deleted_scope`,
`page_size`, `columns`, `focus` e `context_revision`. Criterios aninhados formam
uma arvore de sintaxe abstrata (AST); regras globais sao traduzidas para
`metacriteria` e as linhas de ordenacao para os vetores nativos `sort` e
`order`.

O servidor:

1. valida CSRF, modo, versao do schema, sentinela de completude e chaves exatas;
2. traduz o formulario para a definicao canonica versionada de `Ticket`;
3. compara a revisao recebida com o catalogo contextual atual;
4. valida campos, operadores, profundidade, quantidades, valores, colunas,
   ordenacoes e acesso a lixeira;
5. guarda definicao e tamanho de pagina na sessao autenticada;
6. responde com PRG para uma URL que contem somente um token opaco e o pedido
   de foco nos resultados.

O token possui 48 caracteres hexadecimais gerados com aleatoriedade
criptografica, expira em 15 minutos e referencia no maximo cinco estados por
sessao. Paginacao e demais links reutilizam o token; a AST nao e serializada na
URL. A definicao e revalidada antes de cada execucao e deixa de valer quando o
catalogo contextual muda.

## Pesquisas salvas somente no GLPI

`SavedSearch` e `SavedSearch_User` permanecem as unicas fontes de verdade. Nao
ha tabela, espelho, copia de consulta ou preferencia padrao local.

Pesquisas privadas e publicas autorizadas podem ser recuperadas do GLPI. Uma
definicao homologada preenche o construtor como editavel ou somente leitura,
conforme a capacidade nativa. Ao salvar uma busca avancada aplicada, o
servidor resolve o token, revalida a AST e cria a pesquisa diretamente no
objeto `SavedSearch` autorizado. Consultas nao homologadas continuam intactas
e usam a acao `Abrir no GLPI`.

Criar, renomear, excluir e marcar como padrao continuam sujeitos a ACL,
entidade, fingerprint otimista, CSRF e idempotencia da operacao nativa.

## Executor sem pos-filtro

Criterios, metacriterios, escopo de lixeira, pagina e todas as ordenacoes sao
enviados para `Search::manageParams` e `Search::getDatas`. O executor usa o
total e a pagina devolvidos pela Search API e apenas hidrata os IDs retornados
para montar as linhas acessiveis.

O portal nao reaplica filtros simplificados sobre a pagina, nao corta a lista
de ordenacoes e nao varre uma amostra local de chamados para aproximar o
resultado. Se a Search API nao puder executar a definicao fielmente, a lista
falha fechada e retorna vazia com diagnostico operacional, sem ampliar o
conjunto de chamados.

## Seguranca e limites defensivos

- somente `POST` autenticado e protegido por CSRF aplica a busca avancada;
- chaves desconhecidas, tipos inesperados e listas nao sequenciais sao
  rejeitados, sem sanitizacao por omissao;
- `advanced_schema_version=2` fixa o contrato e
  `advanced_request_complete=1`, emitido depois dos campos dinamicos e como
  ultimo controle nomeado, detecta truncamento por limite de variaveis;
- a revisao contextual bloqueia replay depois de troca de perfil, entidade,
  permissao, plugin ou opcoes de pesquisa;
- o token e vinculado a sessao, tem TTL e nao revela criterios ou valores;
- a definicao e a query sao limitadas a 48 KiB, com ate 600 folhas, 50
  criterios, 25 metacriterios, profundidade quatro, cinco ordenacoes, 50
  colunas e 4 KiB por valor;
- o escopo de lixeira depende da capacidade nativa e falha fechado;
- falhas registram fase, codigo controlado e classe da excecao, sem copiar
  valores livres da pesquisa para auditoria.

## Acessibilidade

- escolha explicita entre busca rapida e avancada por radios nativos;
- titulos e regioes associadas para criterios, regras globais, ordenacao,
  colunas e resumo;
- botoes textuais para adicionar, remover e mover itens, sem depender de
  arrastar ou de gestos precisos;
- nomes acessiveis contextualizados, foco deterministico e anuncios em regiao
  viva apos inclusao, remocao, movimento e mudanca de modo;
- resumo em linguagem natural atualizado durante a edicao;
- painel de erros com links para os campos, `aria-invalid` e foco no primeiro
  erro relevante;
- foco no titulo dos resultados depois do PRG bem-sucedido;
- ordenacao de cabecalho desativada no modo avancado, evitando conflito com a
  secao que representa todas as ordenacoes;
- suporte a teclado, modo somente leitura, reflow, ampliacao, tema noturno,
  alto contraste e `forced-colors`.

## Verificacao automatizada

Na consolidacao da release:

- PHPUnit: 216 testes e 1.079 assercoes;
- PHPStan e PHPCS sem erros;
- lint PHP e validacao de sintaxe JavaScript;
- paridade entre assets de origem e copias publicadas;
- teste headless do construtor, incluindo grupo aninhado, regra global,
  ordenacao, nomes POST, sentinela final, resumo, erro focado e troca de modo.

## Homologacao manual ainda necessaria

Esta beta nao representa certificacao de acessibilidade. Antes de ampliar o
piloto, repetir a matriz em GLPI 10 e 11 com:

- perfis Self-Service, tecnico/hotliner e Super-Admin;
- entidades simples e recursivas, troca de contexto e expiracao de sessao;
- pesquisas privadas, publicas, padrao, editaveis, somente leitura e nao
  homologadas;
- plugins que adicionem ou alterem opcoes, operadores e metacriterios;
- consultas vazias, profundas, proximas dos limites e com multiplas
  ordenacoes;
- NVDA e JAWS no Windows, VoiceOver no macOS e iOS, ampliadores, alto contraste
  e navegacao somente por teclado;
- usuarios cegos executando criacao, revisao, aplicacao, recuperacao e
  salvamento de pesquisas em dados representativos e devidamente
  anonimizados.

Registrar versao exata do GLPI, PHP, navegador, leitor de tela, perfil,
entidade, plugins ativos, resultado esperado e barreiras observadas. Uma falha
na equivalencia da Search API deve bloquear a execucao no portal, nunca ser
compensada por aproximacao silenciosa.
