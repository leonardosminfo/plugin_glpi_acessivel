# Release 0.2.16-beta: escopo conciso e nomes de entidade normalizados

## Objetivo

Esta versão reduz o ruído da pesquisa de chamados e corrige a apresentação de nomes hierárquicos recebidos do GLPI.

O seletor **Escopo** permanece disponível porque oferece atalhos úteis para **Todos os chamados permitidos**, **Meus chamados** e **Chamados do grupo**. Ele não substitui nem amplia as permissões: a consulta continua limitada pelas ACLs, perfil, entidade e recursividade ativos no GLPI.

## Alterações

- o escopo padrão `all` não é mais narrado como se fosse um filtro escolhido;
- `mine` e `group` continuam aparecendo no resumo quando selecionados;
- o resumo aplicado e a consulta em edição seguem a mesma regra;
- nomes hierárquicos da sessão passam pelo normalizador semântico antes de compor mensagens;
- entidades como `JF2R &amp;#62; InternoTi` são apresentadas como `JF2R > InternoTi`;
- os templates continuam responsáveis pelo escape HTML final, evitando introduzir marcação não confiável.

## Compatibilidade e dados

- GLPI: `>= 10.0` e `< 12.0`;
- PHP: `>= 8.1`;
- nenhuma migração de banco;
- nenhuma cópia local de pesquisas salvas;
- SavedSearch do GLPI permanece como fonte de verdade.

## Validação automatizada

- PHPUnit: **331 testes e 1.843 asserções**;
- PHPStan: **sem erros**;
- PHPCS: **167 de 167 arquivos aprovados**;
- interface de busca: **2 de 2 testes de navegador aprovados**;
- i18n: **555 mensagens consistentes**.

## Homologação recomendada

Na homologação externa, conferir pelo menos:

1. abertura da busca sem filtros: o escopo padrão não deve aparecer no resumo;
2. seleção de **Meus chamados** e **Chamados do grupo**: o escopo escolhido deve ser narrado;
3. troca para uma entidade hierárquica: a mensagem deve usar `>` sem mostrar entidades HTML;
4. navegação por teclado e leitura do resumo com NVDA ou JAWS;
5. repetição dos cenários em GLPI 10 e GLPI 11, com perfis e entidades representativos.

## Pacote

```powershell
.\tools\build-release.ps1 -Output .release_0.2.16-beta_scope_summary_entity_encoding -Profile marketplace -RequireMsgfmt
.\tools\verify-release.ps1 -Package .release_0.2.16-beta_scope_summary_entity_encoding\glpiacessivel.zip -ExpectedVersion 0.2.16-beta -PublicProfile
```

A versão continua classificada como beta para homologação fora do ambiente de desenvolvimento.