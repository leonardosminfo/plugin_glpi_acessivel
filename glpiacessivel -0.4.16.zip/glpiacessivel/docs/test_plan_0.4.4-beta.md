# Plano de testes — 0.4.4-beta

## Gate automatizado

1. Executar PHPUnit completo em PHP 8.1 e 8.3.
2. Executar PHPStan, PHPCS, auditoria i18n e validação de sintaxe.
3. Executar toda a suíte de navegador e confirmar hashes entre `assets/` e `public/assets/`.
4. Gerar o ZIP Marketplace, verificar raiz única, metadados, documentos, ativos, ausência de arquivos de desenvolvimento e SHA-256.

## Matriz GLPI 10 e 11

### Requerente e atores

- requerente atual, delegado válido, inativo, fora da entidade e contexto expirado;
- técnico, pessoa observadora, grupo responsável e grupo observador isoladamente;
- para cada papel: campo omitido, vazio, um ID e vários IDs;
- os quatro papéis no mesmo envio, mistura de inclusão/remoção e no-op;
- leitura de `Ticket_User` tipos 2/3 e `Group_Ticket` tipos 2/3;
- preservação do requerente, fornecedor e relações anônimas;
- nenhum detalhe SQL/PHP na interface e exatamente um POST após confirmação.

### Modelos e solução

- tarefa com HTML, entidades, lista e Twig contextual;
- modelo inválido, privado ou fora da entidade;
- acompanhamento público e privado convertido para texto legível;
- solução manual sem tipo, com tipo e por modelo;
- chamado já solucionado e perda de permissão antes do `add()`;
- releitura da solução, autor, tipo, timeline e estado `SOLVED/CLOSED`;
- falha de releitura deve impedir reenvio automático.

### Formulários e acessibilidade

- Formcreator GLPI 10 e Service Catalog GLPI 11 com rota, ID, método e action corretos;
- login expirado, origem/rota/ID/action inválidos e nova tentativa;
- DOM conhecido ativa modo mínimo; DOM desconhecido mantém modo completo;
- no modo mínimo, somente título, instruções, campos, mensagens, erros e ações funcionais permanecem expostos;
- teclado, `Escape`, retorno de foco, 320 CSS px, zoom 200%/400%, alto contraste e `forced-colors`;
- Axe no pai e no iframe, seguido de NVDA/Firefox, NVDA/Chrome e JAWS/Edge.

## Carga autenticada via proxy

- massas de 10 mil, 100 mil e, mediante aprovação, 1 milhão de chamados;
- concorrência 1, 5, 10 e 25, interrompida no primeiro gate de parada;
- resultados 0, 1, 19, 20, 21, 40 e 41;
- pesquisa simples, salva, metacritério, `GROUP BY`, `HAVING`, ordenação não indexada e offset profundo permitido;
- lista lenta em paralelo com detalhe e criação na mesma sessão;
- sobrecarga deliberada para comprovar 429/503, `Retry-After`, liberação da lease e recuperação do circuito.

Parar imediatamente em `504`, OOM, fatal, deadlock, fila sustentada, `max children reached`, deriva de RSS superior a 10%, lease não liberada, circuito sem recuperação ou ampliação de ACL.

## Decisão

GO somente com o mesmo ZIP/SHA aprovado nas duas versões, mutações confirmadas por releitura, zero `5xx/504` causado pelo plugin e aprovação assistiva das jornadas críticas. Qualquer resultado incerto mantém NO-GO para promoção ampla.
