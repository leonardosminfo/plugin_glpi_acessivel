# GLPI Acessível 0.4.15-beta — decisão nativa da solução

## Resultado

A aprovação e a recusa de uma solução passam pelo mesmo caminho funcional do GLPI 10 e 11: um único `ITILFollowup::add()` com `add_close` para aprovar ou `add_reopen` para recusar. O plugin não altera diretamente o status do chamado nem os campos da solução.

## Paridade com o núcleo

- autorização por `Ticket::isSolved()`, `Ticket::canApprove()`, `Ticket::canAddFollowups()` e `Ticket::isAllowedStatus()`;
- escolha da solução por `date_creation DESC, id DESC`, como no núcleo;
- releitura de revisão e permissões depois do bloqueio da linha do chamado;
- payload público nativo com comentário, anexos e ação de fechar ou reabrir;
- pós-condições para acompanhamento, autor, visibilidade, solução, aprovador, data, status do chamado e documentos;
- nenhum direito é deduzido por nome de perfil, primeiro requerente ou direito genérico de atualização.

## Concorrência e recuperação

O fluxo combina um identificador estável de operação, reserva transacional e guard persistente por chamado. Reenvios idênticos retornam o resultado já confirmado; conteúdo divergente entra em conflito e não executa outra mutação.

O guard registra um baseline opaco do último acompanhamento. Resultados conclusivos limpam o marcador. Uma interrupção anterior à mutação só é reconciliada depois de uma hora, quando chamado e solução continuam pendentes e nenhum acompanhamento surgiu desde o baseline. Um resultado ambíguo com qualquer indício de efeito permanece bloqueado para impedir duplicação.

Quando o `add()` nativo retorna falha, a transação sofre rollback. O guard só é liberado depois de confirmar que revisão e último acompanhamento não mudaram.

## Anexos e dados

- fingerprints de idempotência usam somente hashes de nome normalizado, tamanho e conteúdo;
- nomes aleatórios dos temporários não alteram a identidade de um reenvio;
- documentos homônimos são verificados por multiplicidade e quantidade de vínculos;
- comentário, nome e conteúdo dos anexos não são persistidos no ledger ou na auditoria;
- em resultado incerto, temporários são removidos e a mensagem orienta nova seleção somente após conferir o estado.

## Acessibilidade

- motivo opcional ao aprovar e obrigatório ao recusar;
- `required`, `aria-required`, `aria-invalid`, erro associado e foco no campo vazio;
- títulos, consequências e rótulos de confirmação específicos para fechar ou reabrir;
- lista integral de nomes dos anexos no diálogo;
- retorno PRG focalizável e mensagens específicas do resultado;
- manutenção do diálogo modal, contenção de foco, Escape e restauração ao acionador;
- seletores de anexos contidos em 320 pixels CSS no detalhe, sem esconder conteúdo;
- imagens decorativas do `shadow DOM` aberto do VLibras recebem `alt=""`, sem substituir o nome acessível do botão externo.

## Linha de base automatizada

- PHPUnit/PHP 8.1: 840 testes e 5.170 asserções;
- PHPStan e PHPCS no projeto: sem erros;
- navegador: 80 verificações, incluindo quatro cenários de confirmação crítica, reflow do detalhe, integração VLibras e Axe;
- i18n: 2.655 entradas compiladas em `pt_BR` e `en_GB`.

A homologação assistiva e funcional no GLPI 10/PHP 8.1 e GLPI 11/PHP 8.3 continua obrigatória antes da publicação.
