# Plano de testes — 0.4.10-beta

Executar o mesmo ZIP e SHA-256 em um GLPI 10/PHP 8.1 e um GLPI 11/PHP 8.3. Usar dados descartáveis e perfis separados para leitura, autoatendimento, técnico e administração de chamados.

## 1. Direitos e visibilidade

1. O perfil somente leitura deve visualizar apenas chamados e ações permitidos pelo GLPI, sem formulários de alteração.
2. O requerente deve editar somente os campos que o item e o fluxo nativo autorizarem.
3. Um perfil com `canAdminActors()` deve editar pessoas e grupos requerentes e observadores.
4. Um perfil com `canAssign()` deve editar técnicos, grupos responsáveis e fornecedores.
5. Combinações parciais de direitos devem exibir apenas seus blocos; os demais papéis precisam permanecer inalterados após o envio.
6. Trocar perfil, entidade ou recursividade e repetir todos os acessos diretos aos endpoints de seleção e mutação.

## 2. Dados gerais

1. Alterar separadamente e em conjunto título, descrição, tipo, categoria, localização, origem, urgência e impacto.
2. Alterar prioridade com e sem o direito nativo específico.
3. Aplicar um `TicketTemplate` com categoria ou localização obrigatória e confirmar `required`, `aria-required`, erro focalizável e recusa do servidor quando vazio.
4. Testar campo somente leitura e campo não suportado pelo modelo: nenhuma alteração parcial deve ser persistida.
5. Abrir descrição HTML existente, salvar sem alteração e confirmar preservação byte a byte; depois editar e confirmar HTML escapado, texto legível e quebras de linha.
6. Alterar o chamado em outra sessão antes do envio: a primeira tela deve receber conflito recuperável, sem sobrescrever o estado novo.

## 3. Sete conjuntos de atores

Para cada papel, testar 0, 1 e múltiplos atores elegíveis:

- pessoas requerentes;
- grupos requerentes;
- técnicos atribuídos;
- grupos responsáveis;
- fornecedores atribuídos;
- pessoas observadoras;
- grupos observadores.

Confirmar inclusão, remoção, limpeza explícita e preservação quando o campo não é enviado. Criar um requerente anônimo por e-mail no GLPI e comprovar que qualquer edição pelo plugin o mantém. Tentar incluir usuário, grupo ou fornecedor inativo, excluído, de entidade incompatível ou sem a capacidade do papel; a mutação deve falhar integralmente.

## 4. Concorrência, regras e efeitos nativos

1. Duas sessões devem abrir a mesma revisão; a primeira altera um papel e a segunda deve ser recusada como desatualizada.
2. Forçar falha no meio das sete operações e comprovar rollback integral.
3. Confirmar no histórico as inclusões e remoções de cada tipo de ator.
4. Confirmar notificações esperadas e ausência de duplicação de mensagens.
5. Confirmar transição automática de status quando a atribuição nativa assim determinar.
6. Executar regras de negócio locais que atuem sobre categoria, tipo e atores e comparar o resultado final com a mesma operação na interface GLPI.

## 5. Jornada acessível

1. Navegar por teclado, leitor de tela, zoom de 200%/400% e viewport de 320 CSS px.
2. Confirmar ordem: título, instruções, campos autorizados, motivo e ação.
3. O diálogo de confirmação deve anunciar chamado, consequência e resumo das alterações, preservar o botão acionador e restaurar o foco ao cancelar.
4. Após sucesso ou erro, o foco deve chegar à seção de atores ou de dados gerais e a mensagem deve ser anunciada uma única vez.
5. Remover e adicionar opções nos seletores múltiplos e confirmar nome acessível, estado, ajuda e foco previsível.

## 6. Atualização e regressão

1. Substituir uma instalação `0.4.9-beta` pela `0.4.10-beta` sem reiniciar PHP-FPM.
2. Confirmar detecção da nova versão, marcador de runtime coerente e invalidação restrita de OPcache.
3. Reabrir portal, chamados, formulários, cockpit, auditoria, pesquisas salvas, modelos de acompanhamento/tarefa/solução e paginação progressiva.
4. Executar PHPUnit nos dois runtimes, PHPStan, PHPCS, suíte completa de navegador, auditoria i18n e verificação do pacote.

## Critério de liberação

Nenhuma falha P0/P1; nenhuma ampliação de direito ou entidade; nenhum estado parcialmente persistido; histórico e notificações coerentes; jornada crítica concluída por teclado e leitor de tela; mesmo artefato aprovado nos dois GLPIs.
