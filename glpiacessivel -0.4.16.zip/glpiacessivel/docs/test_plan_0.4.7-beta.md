# Plano de testes — 0.4.7-beta

Para formulários nativos incorporados, a aprovação exige que cabeçalho, sidebar, rodapé, glifos de navegação e profiler não apareçam na árvore acessível nem na ordem de tabulação após o gate positivo. Título, instruções, alertas/status, campos e envio devem permanecer expostos; gates desligados ou inválidos devem preservar integralmente a interface nativa. A barra de depuração inserida após o carregamento também deve ser isolada nos GLPI 10 e 11.

## 1. Gates do mesmo artefato

1. Executar PHPUnit em PHP 8.1 e 8.3, PHPStan, PHPCS, auditoria i18n e toda a suíte de navegador.
2. Gerar um único ZIP Marketplace, validar raiz, arquivos, versões, ausência de conteúdo de desenvolvimento e SHA-256.
3. Instalar esse mesmo ZIP nos GLPI 10/PHP 8.1 e GLPI 11/PHP 8.3, sem reiniciar o PHP, e conferir versão de disco/runtime e OPcache.

## 2. Fixtures locais

- entidade operacional e entidade remota;
- perfil de leitura, autoatendimento e técnico;
- categoria elegível, categoria de tarefa, localização obrigatória;
- grupos `is_assign`, `is_task` e `is_watcher`;
- técnico elegível e atores inativos/existentes para preservação;
- modelos HTML de acompanhamento, tarefa `INFO=0` e solução;
- 55 chamados para paginação funcional; ensaio separado com até 10.000 mediante confirmação e snapshot do banco.

## 3. Jornadas funcionais GLPI 10/11

### Perfis e formulários

- perfil de leitura: consultar somente o autorizado, sem ações de criação/alteração;
- autoatendimento e técnico: catálogo e acesso direto coerentes com o perfil e entidade;
- Formcreator 10 e Service Catalog 11: permitido, negado, sessão expirada, modo incorporado e página completa.

### Pesquisas

- simples recorrente `Status = Novo`: seletor mostra `Novo`;
- pesquisa por grupo responsável: definição reconciliada com Search Option nativa e execução válida de agregação, inclusive resultado vazio legítimo;
- regra avançada: seletor bloqueado e edição pelo construtor;
- `native_only`: seletor não mostra `Todos` e consulta original permanece nativa;
- critérios aninhados `AND`, `OR`, `AND NOT`, `OR NOT`, metacritério, `GROUP BY`, `HAVING`, ordenação e Search Option de terceiro;
- IDs e ordem idênticos à tela nativa do mesmo usuário, perfil e entidade.

### Atores, status e modelos

- adicionar/remover/no-op para técnico, grupo responsável, pessoa observadora e grupo observador;
- tela desatualizada entre leitura e envio deve retornar `routing_context_stale` sem escrita parcial;
- hidratação incompleta não apresenta formulário de mutação;
- transição de status apenas para opções retornadas pelo GLPI, com confirmação origem/destino;
- tarefa manual `INFO=0`, modelo `INFO=0`, privado permitido pelo `CREATE`, técnico/grupo/categoria/duração e motivo de pendência recusado;
- HTML de acompanhamento e solução convertido para texto legível, com entidades e quebras de linha preservadas;
- trocar o modelo durante a prévia nunca aplica a resposta anterior.
- `TicketTemplate` nativo: predefinições compatíveis de tipo, categoria, localização, origem, ID externo, urgência e impacto são projetadas e bloqueadas; o valor oculto chega ao `POST`; título, descrição ou campo não representável direcionam para o formulário nativo.
- criar um chamado sintético por versão com o modelo predefinido e conferir no banco/API o tipo, a categoria, a localização e a entidade realmente persistidos.

## 4. Acessibilidade

- teclado completo, foco após incluir/remover atores, erro, cancelamento, resposta obsoleta e recuperação;
- campos de modelo bloqueados não podem ser alterados nem reativados por JavaScript e preservam o valor no POST;
- regiões vivas sem duplicação, resumo de erro associado, reflow a 320 CSS px, zoom 200%/400%, alto contraste e `forced-colors`;
- Axe/Pa11y no pai e iframe; NVDA/Firefox e NVDA/Chrome nas jornadas críticas.

## 5. Carga autenticada

Executar `tools/homologation/run-local-load-matrix.ps1` primeiro com 55 registros e concorrência 1/2/5/10. O padrão `virtual-users` usa uma sessão autenticada distinta por concorrente, distribui exatamente duas tentativas por usuário e prepara o pool HTTP fora da janela medida; `shared` permanece disponível apenas como cenário explícito. Exigir `backend=search_api` e motivo `bounded_native_search` ou `native_saved_search`, registrar toda tentativa e separar sucessos, rejeições controladas e falhas por rota. Em snapshot descartável, repetir com 10 mil, 5 minutos de aquecimento e 15 minutos por patamar. Parar no primeiro 5xx não controlado, timeout, OOM, deadlock, fila sustentada ou deriva de RSS maior que 10%.

Além da carga válida, enviar token CSRF inválido ao endpoint exato. O GLPI 10 e o GLPI 11 devem responder HTTP 403 com o contrato `ticket_results` V2 e `invalid_security_token`; qualquer outra exceção de acesso do GLPI 11 deve continuar no tratamento nativo.

Aceite mínimo: zero 502/504/OOM/fatal/deadlock, página `<=50`, executor `<=51`, 1.000 relações aceitas e 1.001 bloqueadas de forma controlada, sucesso com p95 `<=4 s` e máximo `<=6 s`, rejeição controlada com p95 `<=1 s` e máximo `<=2 s`, recuperação HTTP 200 na primeira tentativa e nenhum aumento de ACL. Em cada cenário `virtual-users`, deve ocorrer ao menos um `capacity_limited` e nenhum `rate_limited`; o cenário compartilhado mede separadamente a contenção de uma única sessão.

## 6. Evidência e rollback

Registrar versões GLPI/PHP/banco, nó/pool, `pm.max_children`, ZIP/SHA, manifesto, identificador da fixture, tempos, backend/motivo, status HTTP, tentativa de recuperação e logs sem PII. Manter snapshot do banco e diretório anterior; não executar massa de carga em produção.
