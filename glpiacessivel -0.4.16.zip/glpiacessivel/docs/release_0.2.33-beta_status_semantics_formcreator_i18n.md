# GLPI Acessível 0.2.33-beta: semântica de status e compatibilidade institucional

## Objetivo

Esta versão corrige achados da homologação real no GLPI 10. A principal correção impede que a condição acessível `Status não é` seja executada com a polaridade oposta pelo tratamento especial de status da Search API nativa.

## Alterações

- a AST, a interface e o resumo continuam representando `Status não é` de forma explícita;
- antes da execução nativa, o plugin identifica Status pelos metadados `glpi_tickets.status` e converte `notequals` para `equals`, invertendo de forma controlada `AND`, `OR`, `AND NOT` e `OR NOT`;
- lista, cockpit e pesquisas salvas usam o mesmo compilador semântico;
- pesquisas gravadas no GLPI recebem a representação nativa compatível e são reabertas no portal com a semântica acessível original;
- campos diferentes de Status não recebem essa transformação;
- a apresentação reduzida do Formcreator reconhece também o layout vertical institucional comprovado na homologação, sem depender de uma `action` ausente no formulário real;
- o fingerprint exige formulário, ID, CSRF e envio válidos e continua preservando a interface completa quando a estrutura não é reconhecida;
- textos compartilhados do shell e da sessão recebem acentuação e cobertura Gettext consistentes.

## Segurança e compatibilidade

A transformação do operador ocorre somente na fronteira nativa e somente para a Search Option comprovada como `glpi_tickets.status`. Ela não altera ACL, entidade, recursividade, valor escolhido ou demais campos. O estado opaco e as pesquisas salvas continuam vinculados ao contexto autorizado.

A redução do Formcreator permanece exclusivamente visual. Ela não remove nem modifica o formulário, a URL, o CSRF, os campos, as validações, os anexos ou a submissão. Qualquer divergência conserva a interface completa.

## Homologação obrigatória

O roteiro executável, a massa controlada, as evidências e os gates estão em [`test_plan_0.2.33-beta.md`](test_plan_0.2.33-beta.md).

- comparar `Status não é Fechado` com `equals + AND NOT` no GLPI 10 real;
- validar as quatro polaridades, grupos aninhados, pesquisa direta, pesquisa salva, lista assíncrona e cockpit;
- repetir a matriz no GLPI 11 para confirmar equivalência sem regressão;
- testar perfis administrador, Helpdesk e autoatendimento, entidades recursivas e não recursivas;
- conferir o Formcreator 2.13 no tema institucional: menu externo preservado, chrome interno reduzido, campos, erros, anexos, CSRF e envio íntegros;
- repetir teclado, NVDA/JAWS, zoom de 200% e 400%, largura de 320 CSS px e contraste forçado.

## Build

```powershell
.\tools\build-release.ps1 -Output .release_0.2.33-beta_status_semantics_formcreator_i18n -Profile marketplace -RequireMsgfmt
.\tools\verify-release.ps1 -Package .release_0.2.33-beta_status_semantics_formcreator_i18n\glpiacessivel.zip -ExpectedVersion 0.2.33-beta -PublicProfile
```
