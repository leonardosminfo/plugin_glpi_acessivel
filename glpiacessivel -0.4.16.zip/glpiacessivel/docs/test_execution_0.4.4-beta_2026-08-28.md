# Execução de testes — 0.4.4-beta — 28/08/2026

## Resultado automatizado

| Gate | Resultado |
| --- | --- |
| PHPUnit PHP 8.1.31 | 678 testes, 4.126 asserções, aprovado |
| PHPUnit PHP 8.3.14 | 678 testes, 4.126 asserções, aprovado |
| PHPStan nível 3 | sem erros |
| PHPCS PSR-12 | 267 arquivos, aprovado |
| Navegador headless | 47 testes, aprovado |
| i18n | 2.388 mensagens, aprovado |
| Formcreator incorporado | 8 cenários, aprovado |
| Service Catalog GLPI 11 | 4 cenários, aprovado |

A primeira execução PHPUnit expôs quatro erros ambientais em subprocessos porque o Xdebug do WAMP não podia gravar em `c:/wamp64/logs/xdebug.log`. A repetição direcionou `XDEBUG_CONFIG` para a pasta temporária gravável do projeto e aprovou a suíte completa nos dois runtimes. O aviso inicial do Xdebug não alterou o código de saída final.

## Contratos comprovados

- política exata comum ao catálogo, hidratação e POST de requerentes/atores;
- conjunto vazio sem consulta nativa de autorização;
- snapshot e releitura dos quatro papéis com resultado tipado;
- renderização nativa de tarefa/solução e recusa de Twig residual;
- exatamente um `ITILSolution::add()` e nenhuma repetição de resultado incerto;
- iframe inválido oculto e retirado do foco/árvore, com restauração no retry;
- perfil mínimo separado para GLPI 11 e fallback completo em DOM desconhecido;
- lease liberada mesmo com falha de circuito e métricas com allowlists.

## Instalação e smoke autenticado local

- O mesmo ZIP verificado foi instalado sem reiniciar o PHP nos contêineres GLPI 10.0.10 e GLPI 11. O GLPI 10 registrou `0.4.4-beta` no estado ativo (`Plugin::ACTIVATED`) após o fluxo nativo de instalação; o GLPI 11 concluiu `plugin:install` e `plugin:activate` como o usuário do servidor web.
- No GLPI 10, a lista carregou 9 chamados autorizados, sem erro de console ou gateway. O carregamento inicial da página mediu 3.366 ms no ambiente local; o resultado assíncrono informou total adiado, como previsto.
- No GLPI 11, a lista carregou 14 chamados como Super-Admin. Depois da troca de contexto, carregou 9 chamados como Hotliner e 9 como Self-Service, sem erro de console ou gateway; o perfil original Super-Admin foi restaurado.
- No GLPI 10, o filtro frequente `Status = Novo` foi aplicado pelo botão `Aplicar filtros e pesquisar` e apareceu no resumo como `E Status é Novo`. O seletor da consulta em edição volta a `Todos` após a aplicação; embora o resumo preserve o estado aplicado, essa separação deve ser confirmada com o usuário para excluir ambiguidade de uso.
- O modelo de solução `[A11Y-QA] Solucao 0.4.2` foi aplicado ao chamado sintético 1 sem salvar a solução. O campo recebeu texto legível com quebras de linha, sem tags nem entidades HTML, e o ID aplicado foi registrado no formulário.
- O seletor de categoria foi operado por teclado e anunciou `Nenhum resultado encontrado` para os termos disponíveis no ambiente. Sem categoria de fixture compatível, não foi possível comprovar seleção e persistência.
- O catálogo local não continha pesquisas salvas visíveis para os perfis testados. A aplicação de pesquisa salva continua comprovada por fixtures automatizadas, mas não por uma recorrência real neste smoke.

Nenhuma solução, atribuição ou observador foi persistido durante este smoke de leitura. As mutações sintéticas permanecem parte da homologação controlada.

## Pendente para homologação operacional

- mutações sintéticas de solução, técnico, grupo e observadores no núcleo real, com releitura do chamado;
- repetição de pesquisa salva real e seleção/persistência de categoria com fixtures adequadas;
- carga longa autenticada via proxy com observação de PHP-FPM, banco e memória;
- confirmação da topologia do GLPIT;
- NVDA e JAWS com usuário final e técnicos.

Essas pendências não invalidam o gate de código, mas impedem declarar GO de produção ou conformidade assistiva final.
