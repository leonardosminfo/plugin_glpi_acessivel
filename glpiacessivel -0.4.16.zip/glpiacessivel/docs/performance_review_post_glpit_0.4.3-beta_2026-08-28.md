# Revisão de desempenho e protocolo de carga pós-GLPIT — 0.4.3-beta

## Escopo e decisão

Esta revisão cobre a lista progressiva de chamados, PHP-FPM, MariaDB/MySQL,
sessão PHP, proxy e proteção de capacidade em GLPI 10/PHP 8.1 e GLPI 11/PHP
8.3. Ela não aumenta timeout e não autoriza carga destrutiva em produção.

O código possui contenções importantes contra materialização ilimitada, mas a
homologação de desempenho continua **pendente** até a carga autenticada longa
via proxy e a prova do comportamento da sessão. O smoke test curto sem `504`
não mede fila sustentada, deriva de RSS, conexões ou lock de uma mesma sessão.

## Evidências confirmadas no código

1. `BoundedTicketSearchRequest` limita a página a 50 e o deslocamento a 10.000.
2. O adaptador preserva `SELECT`, `FROM`, `WHERE`, `GROUP BY`, `HAVING` e
   `ORDER BY` produzidos pelo GLPI e substitui somente `LIMIT` por
   `offset,page_size+1`.
3. `GlpiTicketIdQueryExecutor` lê no máximo 51 linhas e falha fechado se o
   driver devolver uma linha adicional.
4. O total não bloqueia a página: o contrato V2 usa `total=null` e
   `total_state=deferred`.
5. A hidratação recebe no máximo 50 IDs e usa consultas coletivas. Não existe
   retorno para `Search::getDatas()` ou varredura PHP quando o plano limitado
   não pode ser comprovado.
6. MySQL e MariaDB recebem orçamento server-side de 3 segundos. O código
   restaura `group_concat_max_len` do MySQL em `finally`.
7. O endpoint assíncrono aplica rate limit, semáforo, uma consulta em voo por
   contexto e circuito antes da chamada de listagem.

Essas propriedades reduzem muito o risco original de `504` e OOM, mas não
garantem baixo custo: joins, agregações, `HAVING`, ordenação sem índice e
offset ainda podem consumir CPU/temporários até o orçamento do banco.

## Achados e riscos remanescentes

### P0 — lock da sessão ainda não foi liberado durante a consulta

O bootstrap do GLPI abre a sessão antes de `TicketResultController::fetch()`.
O endpoint resolve o estado e atualiza o token bucket em `$_SESSION`, mas não
executa `session_write_close()` antes da Search. Assim, duas requisições da
mesma sessão podem ficar serializadas no handler PHP, inclusive lista lenta
em paralelo com detalhe ou criação.

Não é seguro inserir `session_write_close()` isoladamente: Search, direitos,
hooks e auditoria ainda leem `$_SESSION`, e qualquer escrita posterior seria
silenciosamente perdida. Antes dessa mudança deve existir um inventário
executável de leitura/escrita pós-fechamento e um snapshot imutável de usuário,
perfil, entidade, recursividade, idioma, grupos e direitos.

### P0 em cluster — o limite local não é global

APCu e arquivo protegem apenas o nó/pool local. A opção `external` existe no
contrato, mas os controladores atuais não injetam uma implementação externa;
configurá-la resulta em indisponibilidade fail-closed. Antes de usar vários nós
é obrigatório fornecer backend compartilhado com aquisição atômica, TTL,
token de posse, renovação e liberação idempotente. O banco GLPI saturado não
deve ser usado como semáforo.

### P1 — lease APCu pode expirar antes do término da aplicação

O orçamento SQL é de 3 segundos e a lease padrão é de 8, mas preparação,
hidratação, hooks e auditoria também consomem tempo. Se a aplicação ultrapassar
a lease, outro worker pode ocupar o slot enquanto o primeiro ainda termina.
Não aumentar a lease para esconder a causa. Primeiro medir
`application_duration_ms` e, se necessário, implementar renovação com token de
posse e limite absoluto.

### P1 — cardinalidade relacional na hidratação

Há no máximo 50 chamados, porém requerentes, atribuídos e grupos associados
não possuem teto próprio. Um chamado patológico com milhares de relações pode
ampliar memória mesmo com a página limitada. A próxima otimização deve hidratar
somente relações exigidas pelas colunas/agrupamento e definir política explícita
para cardinalidade anormal, sem truncar silenciosamente dados apresentados.

### P1 — duas auditorias no caminho de sucesso

`TicketService::list()` grava `ticket.list` e o controlador assíncrono grava
`ticket.results.async`. Isso acrescenta duas escritas no banco para a mesma
operação e dificulta a correlação. Após estabilizar a telemetria, consolidar em
um único evento operacional, preservando retenção fora do request.

### P1 — falha do orçamento perde diagnóstico na borda

O executor conhece dialeto e razão (`statement_execution_failed`, falha de
snapshot/restauração), mas o gateway publica a razão genérica
`bounded_search_execution_unavailable`. Manter a mensagem pública genérica,
mas transportar código técnico allowlisted para a auditoria, sem SQL, valores,
critérios ou PII.

### P2 — paginação por offset

O teto 10.000 impede abuso ilimitado, mas páginas profundas continuam
reprocessando linhas anteriores. Cursor keyset não é substituição geral para
pesquisas salvas com ordenação arbitrária, metacritério, `GROUP BY` e `HAVING`.
Manter fail-closed e medir os piores casos antes de alterar a semântica nativa.

## Correções seguras desta revisão

1. A liberação da lease passou a ser tentada mesmo quando a gravação do estado
   do circuito lança exceção. Uma falha no plano de controle não pode consumir
   um slot até o TTL.
2. `capacity_lease_released` agora representa o retorno real da liberação, e
   não apenas a tentativa.
3. A telemetria assíncrona passa a registrar, sem conteúdo ou PII:
   - duração de admissão e da aplicação;
   - estado do circuito e backend da capacidade;
   - duração da Search nativa e da hidratação em lote;
   - memória atual/pico e deltas em relação ao início do controlador;
   - adaptador, estado do total, versões PHP/GLPI/plugin e código HTTP.

Não foram alterados timeouts, SQL, ACL, hidratação, sessão ou semântica de
pesquisas salvas/complexas.

## Protocolo obrigatório de carga autenticada

Executar em janela controlada, primeiro no GLPI 10 e depois no GLPI 11, com o
mesmo conjunto congelado de dados e o mesmo perfil/entidade. Não usar credencial
administrativa em arquivo de script ou log.

### Preparação

1. Confirmar número de nós, pools PHP-FPM e valor de `pm.max_children`.
2. Confirmar backend efetivo de capacidade em cada nó.
3. Registrar limites do proxy, PHP-FPM e banco sem alterá-los.
4. Habilitar slowlog do PHP-FPM e slow query log do banco somente na janela
   aprovada, com retenção e acesso restritos.
5. Congelar fixtures de 10 mil, 100 mil e, se aprovado, 1 milhão de chamados.
6. Obter uma sessão independente por usuário virtual; compartilhar um único
   cookie mede contenção da mesma sessão, não concorrência de usuários.

### Matriz

- concorrência: 1, 5, 10 e 25 usuários, interrompendo a rampa no primeiro gate
  de parada;
- resultados: 0, 1, 19, 20, 21, 40 e 41;
- escopos: `all`, `mine` e `group`;
- consulta simples, pesquisa salva, metacritério, `GROUP BY`, `HAVING` e
  ordenação não indexada;
- página 1, página intermediária e maior offset permitido;
- uma lista deliberadamente lenta em paralelo com detalhe e criação da mesma
  sessão;
- sobrecarga deliberada para provar 429/503 e recuperação.

Cada onda deve usar o endpoint através do proxy, validar o envelope
`ticket_results` V2 e registrar `request_id`, HTTP, `Retry-After`, duração e
tamanho da resposta. Não repetir automaticamente mutações; esta carga usa
somente leitura.

### Observação simultânea

- proxy: upstream time, 499/502/503/504;
- PHP-FPM: active/idle/total processes, listen queue, max children reached,
  slow requests e RSS por processo;
- banco: threads connected/running, aborted connections, temporary tables em
  disco, sort merge passes, rows examined, locks/deadlocks e slow queries;
- plugin: p50/p95/p99 de admissão, Search, hidratação e aplicação, contagem por
  outcome, backend/circuito, lease não liberada e deltas de memória.

### Gates de parada imediata

- qualquer 504, OOM, fatal, deadlock ou ampliação de ACL;
- fila do PHP-FPM crescente por duas janelas consecutivas;
- `max children reached` sustentado;
- lease não liberada ou circuito sem recuperação;
- RSS após aquecimento com deriva superior a 10%;
- detalhe/criação da mesma sessão bloqueados além do orçamento;
- p95 da aplicação acima de 4 segundos ou resposta PHP além de 6 segundos.

### Aceite

- zero 5xx/504 causado pelo plugin;
- 429/503 ocorre antes do limite do cliente e inclui `Retry-After`;
- consultas são canceladas pelo orçamento e não ficam zumbis;
- memória, fila e conexões retornam à linha de base após a carga;
- `items <= page_size <= 50`, total desconhecido nunca vira zero e nenhuma
  página materializa mais de 51 IDs;
- IDs e ordem coincidem com a Search nativa para todos os casos complexos;
- outra jornada da mesma sessão continua responsiva dentro do orçamento.

## Próxima ordem de engenharia

1. Rodar a carga acima e correlacionar pelo `request_id`.
2. Corrigir eventual cardinalidade relacional guiado pelas colunas solicitadas.
3. Consolidar as duas escritas de auditoria em um evento.
4. Transportar diagnóstico allowlisted do orçamento até a telemetria.
5. Provar o inventário de sessão; só então experimentar fechamento antecipado.
6. Implementar backend compartilhado antes de qualquer implantação multi-nó.

