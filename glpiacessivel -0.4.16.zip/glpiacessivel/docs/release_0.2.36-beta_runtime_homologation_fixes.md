# GLPI Acessível 0.2.36-beta: correções de runtime e homologação

## Resultado

Esta beta reúne correções encontradas na homologação real sobre o GLPI 11 e amplia os gates que impedem a volta dessas falhas:

- a busca avançada, as pesquisas salvas e a criação de chamados concluem o ciclo POST/Redirect/GET sem que a exceção de redirecionamento do GLPI 11 seja interpretada como falha da operação;
- a busca válida preserva o estado opaco em `advanced_search_token`, direciona o foco para os resultados e não retorna silenciosamente à lista anterior;
- o formulário do Service Catalog do GLPI 11 pode permanecer incorporado na jornada do portal quando seu contrato nativo é comprovado, mantendo o menu, o envio oficial e a alternativa de página completa;
- o shell autenticado, os seletores de contexto e as regiões de conteúdo permanecem contidos em 320 pixels CSS, com rolagem horizontal localizada nas tabelas extensas;
- o gate linguístico passa a inspecionar mais serviços, controladores, templates, JavaScript, nomes acessíveis e regiões vivas.

## Redirecionamentos no GLPI 11

`Html::redirect()` encerra o fluxo do GLPI 11 por meio de `Glpi\Exception\RedirectException`. Quando o redirecionamento de sucesso permanecia dentro de um `try` seguido por `catch (Throwable)`, o próprio redirecionamento era capturado como erro da aplicação. Na pesquisa, isso descartava o token recém-criado e devolvia uma URL incompleta, sem o novo estado e sem o foco esperado.

A `0.2.36-beta` adota uma única fronteira para os três fluxos afetados:

1. ACL, CSRF, idempotência e validações continuam sendo executados na ordem anterior;
2. o bloco protegido calcula o resultado e a URL de destino, sem redirecionar;
3. falhas reais escolhem a mensagem e o destino conservador;
4. o redirecionamento do resultado operacional é chamado depois do `catch` correspondente, fora da fronteira que classifica falhas da operação.

Na busca avançada, o destino de sucesso contém `advanced_search_token=<opaco>` e `focus=results`. `search_mode=advanced` permanece no destino conservador de falha, sem fingir que um novo estado foi criado. Pesquisas salvas e criação de chamados usam o mesmo princípio sem ampliar direitos nem ocultar erros de validação.

## Contrato do iframe nativo no GLPI 11

O modo incorporado do Service Catalog é uma delegação visual, não um formulário reimplementado. O estado `ready` só é publicado quando a inspeção de mesma origem comprova:

- origem e rota de renderização esperadas;
- formulário `POST` nativo e estrutura identificável;
- identificador do formulário igual ao item aberto;
- `action` igual ao endpoint nativo de submissão `/Form/SubmitAnswers`;
- presença dos campos de resposta sem alteração de nome, valor ou ordem de envio.

O plugin não copia, serializa nem dispara a submissão. Condições, campos, anexos, CSRF, validações e criação final continuam no GLPI 11. A apresentação mínima específica do Formcreator não é aplicada ao Service Catalog. Se ID, rota, estrutura ou endpoint divergirem, o iframe não é ocultado: o usuário recebe um estado funcional, pode tentar novamente o **GET de carregamento** e conserva o link para a página completa. A nova tentativa nunca repete `POST`.

## Reflow em 320 pixels CSS

O shell autenticado passa a conter textos longos, seletores de perfil e entidade, botões e cartões dentro da largura do documento. Controles interativos preservam alvo mínimo de 44 pixels. Tabelas que não podem ser linearizadas continuam em uma região identificada e focalizável com rolagem própria; o documento e o `body` não devem adquirir rolagem horizontal.

O aceite exige também zoom de 200% e 400%, conteúdo em pt-BR e en-GB, foco visível e leitura do nome da região tabular por tecnologia assistiva.

## Gate linguístico ampliado

A auditoria compartilhada passa a verificar, nas jornadas críticas:

- palavras portuguesas conhecidas sem acentuação em texto visível, ajuda, ARIA, placeholders e regiões vivas;
- msgids estáticos usados por gateways Gettext do plugin e chaves JavaScript sem fonte no catálogo;
- alinhamento POT/PO/MO, ausência de entradas vazias ou fuzzy e equivalência de placeholders;
- mojibake em `src/`, `templates/` e JavaScript de runtime;
- equivalência byte a byte dos ativos fonte e públicos.

Os controladores corrigidos também têm regressões explícitas para mensagens como `título`, `descrição`, `operação`, `excluída` e `Não foi possível`.

## Contratos preservados

- não há mudança na ACL, no escopo de perfil ou entidade, nos tokens CSRF, na Search API, na semântica de status ou na revalidação de mutações;
- o token de pesquisa permanece opaco, limitado à sessão e consumido pelo fluxo existente;
- o modo incorporado continua sendo melhoria progressiva e mantém página completa como alternativa;
- nenhuma tabela ou cópia de chamados, pesquisas, formulários, respostas ou diagnósticos foi criada;
- GLPI 10 e Formcreator mantêm os contratos conservadores das versões anteriores.

## Verificação obrigatória

O gate detalhado está em [`test_plan_0.2.36-beta.md`](test_plan_0.2.36-beta.md). A liberação exige, no mínimo:

1. regressão verde que prove a ausência de `Html::redirect()` dentro de `try` nos controladores afetados;
2. busca rápida e avançada reais no GLPI 11 com estado e foco preservados após o POST;
3. formulário real do Service Catalog carregado e enviado pelo endpoint oficial, além dos cenários conservadores de ID/action divergentes e sessão expirada;
4. reflow sem overflow do documento em 320 pixels CSS;
5. pt-BR e en-GB íntegros, catálogos compilados e gate linguístico verde;
6. PHPUnit, Browser, PHPStan, PHPCS, auditoria i18n, build e verificador de release integralmente verdes.

## Empacotamento

O artefato não é gerado durante a preparação documental. Depois da homologação, os mantenedores devem executar:

```powershell
.\tools\build-release.ps1 -Output .release_0.2.36-beta_runtime_homologation_fixes -Profile marketplace -RequireMsgfmt
.\tools\verify-release.ps1 -Package .release_0.2.36-beta_runtime_homologation_fixes\glpiacessivel.zip -ExpectedVersion 0.2.36-beta -PublicProfile
```

Esta versão permanece beta e não representa certificação definitiva WCAG/eMAG nem aprovação no Marketplace GLPI.
