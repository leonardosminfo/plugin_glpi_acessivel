# 0.2.1-beta - authentication and operational context

## Scope

This maintenance beta corrects the accessible-login return path and makes profile/entity switching follow the effective GLPI session state on GLPI 10 and 11.

## Corrections

- public entry points declare the GLPI 10 public security strategy before loading the legacy bootstrap;
- the native login receives a raw local return path and URL encoding is used only in query strings;
- a controlled post-login callback verifies profile, entity, interface and operational session readiness;
- protected pages block partial sessions and return to the portal recovery step;
- profile and entity are applied in separate accessible forms;
- a profile change accepts only entities exposed by the newly active profile, including recursive descendants;
- native profile/entity results are verified before announcing success;
- all-entities scope uses the native `glpientity_fullstructure` flag;
- context changes invalidate chatbot memory, pending confirmations and temporary PII reveal state, including a failed native entity mutation;
- partial authenticated sessions are normalized before the native login check redirects the request;
- `return_to` accepts only local plugin front paths;
- the login help dialog makes background regions inert and returns focus on close;
- the authenticated audit starts from the accessible login and uses the correct ticket route.

## Synthetic test base

The repository includes an idempotent local-only generator under `tools/homologation/`. It creates marked `[A11Y-QA]` entities, groups, categories, disabled users, profile assignments, tickets and knowledge articles through GLPI model classes. It is excluded from the release ZIP.

## Verification

- PHPUnit: 112 tests, 502 assertions;
- PHPStan: no errors;
- PHPCS release gate: no errors;
- GLPI 11.0.7 synthetic data dry-run, apply and idempotency checks completed;
- accessible-login callback completed without a second login request;
- profile switching validated across Hotliner, Self-Service and Super-Admin;
- recursive descendant entity selection and restoration to the root entity validated;
- protected Self-Service routes opened without losing the authenticated session;
- administrator diagnostics remained hidden from Self-Service and visible to Super-Admin;
- local Axe checks reported zero violations in normal and high-contrast modes;
- authenticated Pa11y audit reported zero issues across nine routes: portal, chatbot, ticket creation, ticket list, knowledge base, forms, cockpit, configuration and playbooks.

## Remaining assisted validation

Before a blind-user presentation, repeat the critical journeys with NVDA, JAWS or VoiceOver and the intended GLPI profiles. Dynamic forms and attachment fixtures must be prepared in the native engine of the exact GLPI/Formcreator version under test.
