# GLPI Acessível 0.2.37-beta: conclusão linguística e acessibilidade de mensagens

## Resultado

Esta beta conclui a revisão linguística transversal iniciada nas versões anteriores e transforma os contratos revisados em gates permanentes de distribuição:

- as jornadas públicas, a administração e os adaptadores de formulários dinâmicos usam o domínio Gettext do plugin para textos visíveis, nomes acessíveis, ajuda, validações, confirmações e regiões vivas;
- contagens são expressas com plurais naturais em `pt_BR` e `en_GB`, sem sufixos artificiais como `(s)`;
- cada mudança relevante de estado produz um único anúncio, evitando a repetição simultânea em região viva, alerta e diálogo;
- erros de sessão e CSRF orientam a pessoa a atualizar, entrar novamente ou repetir a ação, sem expor token, exceção, classe ou diagnóstico interno;
- a auditoria global cruza runtime PHP, templates, JavaScript, POT/PO/MO, placeholders, plurais, mojibake e paridade dos ativos publicados.

## Cobertura Gettext

O catálogo cobre as superfícies públicas do portal, login, chamados, formulários, conhecimento, FAQ e assistente; as superfícies administrativas de configuração e playbooks; e as mensagens funcionais e diagnósticas dos adaptadores de formulários dinâmicos.

Mensagens públicas evitam termos de implementação quando a pessoa precisa apenas concluir uma tarefa. Informações técnicas necessárias à operação permanecem disponíveis somente nas áreas administrativas autorizadas. Tokens internos de busca, intenção, API ou payload continuam fora da tradução quando não são conteúdo de interface.

## Plurais naturais

Contagens de itens selecionados, erros, arquivos, atores, regras e elementos afetados passam a escolher explicitamente a forma singular ou plural. Os placeholders continuam tipados e equivalentes entre POT, `pt_BR` e `en_GB`.

O aceite proíbe construções visíveis como `item(ns)`, `erro(s)` e `regra(s)`. Também proíbe concatenar um número a uma frase sem garantir concordância no idioma ativo.

## Anúncio único

Tema, contraste, alertas críticos, carregamento de formulários e demais atualizações dinâmicas devem ter uma única fonte anunciável por evento. O estado visual pode aparecer em outros componentes, mas estes não podem repetir a mesma mensagem por `aria-live`, `role="status"` ou `role="alert"`.

A deduplicação não remove feedback: o usuário continua recebendo resultado inequívoco, incluindo se tema ou contraste foi ativado ou desativado.

## Sessão e CSRF

Falhas de sessão ou de proteção CSRF permanecem bloqueios de segurança. A mudança se limita à mensagem apresentada:

- a interface não imprime token, exceção, classe, endpoint ou configuração interna;
- a orientação pública explica como recuperar a tarefa com segurança;
- o diagnóstico administrativo continua sujeito à ACL própria e à sanitização já existentes;
- nenhuma ação é repetida automaticamente e nenhum `POST` é reenviado pelo texto de recuperação.

## Gates globais

A liberação exige:

1. todas as mensagens estáticas do runtime presentes no POT e nos dois PO;
2. MO recompilados a partir dos PO aprovados;
3. placeholders, formatos e plurais equivalentes entre os catálogos;
4. ausência de mojibake, msgids dinâmicos indevidos e português não acentuado nas superfícies cobertas;
5. paridade byte a byte entre fontes JavaScript/CSS e cópias publicadas;
6. regressões de navegador para pluralização, anúncio único e recuperação de sessão;
7. PHPUnit, PHPStan, PHPCS, auditoria i18n, testes de navegador, build e verificação de release verdes.

## Contratos preservados

- não há mudança em ACL, perfil, entidade, recursividade ou visibilidade de objetos;
- não há mudança em payloads, nomes de campos, tokens, contratos JSON ou parâmetros enviados ao GLPI;
- a ordem de autenticação, autorização, CSRF, validação, idempotência e gravação permanece a mesma;
- formulários continuam submetidos pelos mecanismos oficiais do GLPI 11 ou Formcreator no GLPI 10;
- nenhuma tabela, coluna ou cópia de chamados, formulários, respostas, diagnósticos ou catálogos foi criada;
- a página completa permanece disponível nos fluxos delegados em que já era alternativa.

## Homologação

O gate executável está em [`test_plan_0.2.37-beta.md`](test_plan_0.2.37-beta.md). A revisão deve percorrer `pt_BR` e `en_GB`, perfis de autoatendimento, técnico e administrador, além de GLPI 10/Formcreator e GLPI 11/Service Catalog nas combinações efetivamente suportadas pela instalação.

Esta beta continua dependente de teste manual com tecnologias assistivas. Aprovação automatizada não representa certificação definitiva WCAG/eMAG nem aprovação no Marketplace GLPI.

## Empacotamento

O artefato não é gerado durante a preparação documental. Depois de todos os gates e da homologação, os mantenedores devem executar:

```powershell
.\tools\build-release.ps1 -Output .release_0.2.37-beta_language_accessibility_completion -Profile marketplace -RequireMsgfmt
.\tools\verify-release.ps1 -Package .release_0.2.37-beta_language_accessibility_completion\glpiacessivel.zip -ExpectedVersion 0.2.37-beta -PublicProfile
```

