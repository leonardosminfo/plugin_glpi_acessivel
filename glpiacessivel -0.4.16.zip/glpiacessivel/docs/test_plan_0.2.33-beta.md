# Plano de testes da versão 0.2.33-beta

## 1. Controle do documento

| Campo | Valor |
|---|---|
| Versão sob teste | `0.2.33-beta` |
| Artefato | `glpiacessivel.zip` do perfil `marketplace` |
| Integridade | conferir `SHA256SUMS` e `RELEASE_MANIFEST.json` antes da instalação |
| Escopo principal | semântica de `Status não é`, pesquisas salvas, cockpit, fingerprint Formcreator v2 e revisão linguística |
| Decisão possível | `GO`, `GO somente para homologação` ou `NO-GO` |

Este plano complementa a suíte automatizada. Ele não substitui a validação no GLPI real, a revisão manual WCAG 2.2 AA/eMAG nem os testes com tecnologias assistivas.

## 2. Objetivos e riscos da versão

1. Provar que `Status não é` retorna exatamente o mesmo conjunto autorizado que a representação nativa `Status é` com conector negativo.
2. Provar que a mesma semântica é mantida na lista síncrona, lista assíncrona, cockpit e pesquisas salvas abertas no portal e no GLPI original.
3. Confirmar que a transformação ocorre somente para a Search Option comprovada como `glpi_tickets.status`, sem alterar campos arbitrários.
4. Confirmar que o fingerprint `formcreator-glpi10-2.13-vertical-dom-v2` reduz apenas a casca institucional reconhecida.
5. Garantir que divergência de versão, rota, origem, ID, CSRF, envio ou DOM mantém a interface completa e funcional.
6. Confirmar acentuação, Gettext, nomes acessíveis, foco e anúncios nos fluxos principais.
7. Repetir ACL, contexto, concorrência e volume para impedir que a correção funcional introduza vazamento ou sobrecarga.

## 3. Critérios de entrada

- ZIP aprovado por `tools/verify-release.ps1`.
- SHA-256 instalado igual a `SHA256SUMS` e ao manifesto externo do build.
- backup restaurável do banco e dos arquivos do GLPI.
- cache do GLPI, OPcache e cache do navegador limpos depois da instalação.
- logs PHP, GLPI, servidor web e banco disponíveis durante a execução.
- relógio e fuso dos ambientes conhecidos.
- massa de chamados congelada durante cada comparação portal × GLPI.
- contas, grupos, perfis e entidades exclusivamente de homologação.
- nenhum cookie, token, CSRF, conteúdo de chamado ou dado pessoal real registrado como evidência.

## 4. Ambientes obrigatórios

| Ambiente | Integração | Navegadores | Tecnologia assistiva |
|---|---|---|---|
| GLPI 10.x institucional | Formcreator 2.13.x e tema institucional | Chrome, Edge e Firefox suportados | NVDA + Firefox/Chrome; JAWS + Edge/Chrome |
| GLPI 11.x | Service Catalog e formulários oficiais | Chrome, Edge e Firefox suportados | NVDA + Firefox/Chrome; JAWS + Edge/Chrome |

Registrar versões exatas de GLPI, PHP, banco, Formcreator, navegador, NVDA/JAWS e sistema operacional. O GLPI 11 não deve receber o fingerprint legado do Formcreator 2.13.

## 5. Personas e contextos

- administrador global;
- técnico Helpdesk limitado a uma entidade;
- técnico pertencente ao grupo `G-A`;
- usuário de autoatendimento `self_a`;
- perfil sem direito de visualizar chamados;
- dois usuários de entidades sem direitos recíprocos;
- conta multiperfil para troca de perfil e entidade em duas abas.

Contextos mínimos:

- entidade `E10`, recursiva;
- entidade `E10`, não recursiva;
- entidade filha `E11`;
- entidade não autorizada `E20`;
- registros ativos e excluídos em escopos separados.

## 6. Massa funcional controlada

| ID lógico | Entidade | Status | Prioridade | Participação | Grupo | Observação |
|---|---|---|---|---|---|---|
| T101 | E10 | Novo | Alta | requerente `self_a` | — | título com `VPN` |
| T102 | E10 | Em atendimento | Média | técnico `tec_a` | G-A | ativo |
| T103 | E11 | Planejado | Alta | requerente `self_a` | G-A | título com `VPN` |
| T104 | E11 | Pendente | Média | técnico `tec_a` | G-A | ativo |
| T105 | E10 | Solucionado hoje | Média | outro | — | título com `VPN` |
| T106 | E10 | Fechado | Alta | requerente `self_a` | — | controle de exclusão por status |
| T107 | E20 | Novo | Alta | outro | — | controle negativo de ACL |
| T108 | E10 | Novo | Média | requerente `self_a` | — | excluído |
| T109 | E10 | Fechado | Média | outro | — | excluído |

Para carga, criar uma massa isolada representativa do ambiente, preferencialmente com patamares de 10 mil e 100 mil chamados. Os casos de equivalência devem usar uma fotografia congelada dos dados.

## 7. Linha de base automatizada

Antes da homologação manual, exigir:

- PHPUnit completo;
- PHPStan e PHPCS;
- `npm run test:browser`;
- auditoria POT/PO/MO com `msgfmt`;
- build e `verify-release` do perfil público;
- pares `assets/public` idênticos;
- ausência de erro de sintaxe em todos os PHP do ZIP.

Na linha de base desta versão foram observados 476 testes PHPUnit, 2.861 asserções, 29 testes de navegador e 905 mensagens Gettext. O CI publicado é a evidência definitiva.

## 8. Ordem de execução

1. Integridade, instalação e atualização.
2. Smoke de portal, rotas e permissões.
3. Semântica de Status no GLPI 10.
4. Semântica de Status no GLPI 11.
5. Lista assíncrona, pesquisas salvas e cockpit.
6. ACL, troca de contexto, CSRF, IDOR, sessão e erros.
7. Formcreator GLPI 10 e Service Catalog GLPI 11.
8. Teclado, leitores de tela, reflow, contraste e Axe.
9. Volume e concorrência em janela isolada.
10. Reteste de defeitos, revisão das evidências e decisão.

Qualquer P0 interrompe imediatamente a execução. Um P1 impede a liberação, mas permite continuar apenas os testes úteis ao diagnóstico.

## 9. Instalação, atualização e rollback

| ID | Caso | Resultado esperado |
|---|---|---|
| I01 | Instalar a 0.2.33-beta em GLPI 10 limpo | plugin instala e ativa sem erro ou tabela inesperada |
| I02 | Atualizar da 0.2.32-beta | preferências, pesquisas nativas e configuração Formcreator permanecem |
| I03 | Instalar/atualizar no GLPI 11 | firewall, menus, assets e rotas autenticadas funcionam |
| I04 | Comparar versão em setup, XML, tela e manifesto | todos informam 0.2.33-beta |
| I05 | Desativar e reativar | nenhuma perda de dados nativos; hooks e menu retornam corretamente |
| I06 | Restaurar snapshot anterior | rollback operacional documentado e funcional |

## 10. Semântica de Status

### 10.1 Referência nativa

Para validar `Status não é Fechado`, montar no GLPI original:

- campo `Status`;
- operador `é`;
- valor `Fechado`;
- conector `E NÃO`.

Essa é a representação executada pelo ramo especial de Status. Comparar sempre o conjunto completo de IDs, no mesmo usuário, perfil, entidade e recursividade.

### 10.2 Casos críticos

| ID | P | Consulta | Resultado esperado na massa E10 recursiva |
|---|---:|---|---|
| S01 | P0 | Status não é Fechado | T101–T105; T106/T107 ausentes |
| S02 | P0 | Status é Fechado | somente T106 |
| S03 | P0 | Status não é Solucionado | T101–T104 e T106 |
| S04 | P0 | administrador global, não é Fechado | T101–T105 e T107 |
| S05 | P0 | E10 não recursiva, não é Fechado | T101, T102 e T105 |
| S06 | P0 | autoatendimento `self_a`, não é Fechado | T101 e T103 |
| S07 | P0 | excluídos, não é Fechado | somente T108 |
| S08 | P1 | ID inexistente OU Status não é Fechado | mesmo universo de S01 |
| S09 | P0 | AND NOT com Status não é Fechado | dupla negação: somente T106 |
| S10 | P0 | OR NOT com Status não é Fechado | polaridade equivalente comprovada no GLPI nativo |
| S11 | P0 | não é Fechado E (Alta OU Pendente) | T101, T103 e T104 |
| S12 | P0 | Fechado OU (não é Solucionado E Alta) | T101, T103 e T106 |
| S13 | P1 | Status não é + campo não Status com operador negativo | somente Status sofre a compilação especial |
| S14 | P1 | alterar ordenação, colunas e paginação após S01 | mesmo universo, sem perda ou duplicação |

Executar S01–S14 no GLPI 10 e 11. Para cada caso, guardar resumo acessível, consulta nativa equivalente e listas completas de IDs.

## 11. Busca direta, assíncrona e pesquisas salvas

| ID | P | Caso | Resultado esperado |
|---|---:|---|---|
| B01 | P0 | executar S01 no formulário principal | resumo mostra `Status não é Fechado`; IDs corretos |
| B02 | P0 | executar S01 pela lista assíncrona | mesmo conjunto da renderização síncrona/nativa |
| B03 | P0 | paginar com dois itens | cinco IDs únicos, sem salto ou duplicação |
| B04 | P0 | reutilizar estado após troca de perfil/entidade | estado rejeitado; nenhum dado do contexto anterior |
| B05 | P0 | salvar `HML - não fechados` | objeto criado diretamente em `SavedSearch` |
| B06 | P0 | reabrir no portal | campo, operador, valor, grupos e resumo preservados |
| B07 | P0 | abrir a mesma pesquisa no GLPI original | conjunto de IDs idêntico |
| B08 | P0 | inspecionar definição sanitizada | GLPI armazena `equals` com conector negativo |
| B09 | P1 | renomear e alternar padrão | definição permanece íntegra e sem cópia local |
| B10 | P1 | abrir pesquisa antiga com `notequals` | portal interpreta `não é`; próxima gravação é normalizada |
| B11 | P0 | tentar pesquisa privada de outro usuário | negação sem nome, critérios ou resultados |
| B12 | P1 | excluir após confirmação | exclusão ocorre somente no GLPI autorizado |

## 12. Cockpit

| ID | P | Caso | Resultado esperado |
|---|---:|---|---|
| C01 | P0 | Helpdesk E10 recursiva | Abertos 4; Pendentes 1; Solucionados hoje 1 |
| C02 | P0 | Meus abertos de `tec_a` | T102 e T104 |
| C03 | P0 | Grupo G-A aberto | T102, T103 e T104 |
| C04 | P0 | abrir os cinco detalhamentos | IDs do detalhe correspondem ao contador |
| C05 | P0 | repetir sem recursividade | filhos saem de contadores e listas |
| C06 | P0 | autoatendimento | nenhum total ou ID fora da ACL |
| C07 | P1 | resultado não calculável | `Resultado indisponível`, nunca zero sintético |
| C08 | P1 | atualizar e abrir detalhes repetidamente | cinco consultas agregadas fixas, sem consulta por chamado |

Qualquer divergência contador × detalhamento é `NO-GO`.

## 13. Formcreator GLPI 10

Pré-condições do positivo: Formcreator 2.13, mesma origem, rota e ID esperados, layout vertical institucional, formulário POST, um ID oculto, um CSRF não vazio e um único envio.

| ID | P | Caso | Resultado esperado |
|---|---:|---|---|
| F01 | P0 | abrir formulário básico pelo catálogo | menu externo permanece; formulário incorporado |
| F02 | P0 | preencher e enviar uma vez | solicitação/ticket único e valores corretos |
| F03 | P0 | omitir obrigatório | erro nativo visível, associado e anunciado |
| F04 | P0 | condição dinâmica | campos mudam sem perda indevida de valores |
| F05 | P0 | seletor/autocomplete | opções autorizadas e operação por teclado |
| F06 | P0 | anexo permitido | documento vinculado ao item correto |
| F07 | P1 | fingerprint v2 positivo | header/aside internos reduzidos; conteúdo funcional íntegro |
| F08 | P0 | CSRF/ID ausente, vazio, duplicado ou divergente | minimal não aplicado; interface completa funcional |
| F09 | P0 | dois envios, versão/DOM/rota/origem divergente | minimal não aplicado; nenhum controle ocultado |
| F10 | P0 | sessão expirada ou login no iframe | nenhum POST aceito; recuperação e página completa disponíveis |
| F11 | P1 | abrir página completa | mesmo formulário e contexto autorizado |
| F12 | P0 | perfil sem acesso | formulário e diagnóstico técnico ausentes |

O fallback visual completo é `PASS` quando ACL, CSRF, validações, campos, erros, anexos e envio permanecem íntegros.

## 14. GLPI 11 e Service Catalog

- listar apenas formulários autorizados;
- abrir e enviar formulário simples exatamente uma vez;
- validar condicionais, seletores, anexos e mensagens nativas;
- negar usuário sem permissão sem expor schema ou diagnóstico;
- confirmar que o fingerprint Formcreator GLPI 10 não é aplicado;
- validar alternativa de página completa sem perda de sessão ou contexto.

## 15. Segurança e contexto

| ID | P | Caso | Resultado esperado |
|---|---:|---|---|
| SEC01 | P0 | alterar IDs de chamado, formulário e pesquisa | IDOR negado sem revelar conteúdo |
| SEC02 | P0 | POST sem CSRF, incorreto ou de outra sessão | nenhuma mutação |
| SEC03 | P0 | `javascript:`, `//host`, origem/rota externa | nunca tratada como origem confiável |
| SEC04 | P0 | logout em outra aba e nova ação | sessão expirada; ação recusada |
| SEC05 | P0 | aba A com dados; mudar perfil/entidade na B | nova consulta/mutação revalida o contexto |
| SEC06 | P0 | pesquisa privada alheia | listagem, aplicação e CRUD negados |
| SEC07 | P1 | 401/403/409/422/429/503/504 | mensagem útil e recuperação; sem HTML tratado como JSON |
| SEC08 | P1 | timeout e resposta tardia | `aria-busy` termina; resposta antiga descartada |
| SEC09 | P0 | logs e diagnóstico | sem cookies, tokens, SQL, PII ou conteúdo de chamado |

### Teste de duas abas

1. Abrir lista, detalhe, pesquisa salva e formulário na aba A.
2. Trocar perfil, entidade ou recursividade na aba B.
3. Voltar à aba A sem recarregar.
4. Consultar, paginar, aplicar pesquisa e tentar um POST.
5. Recarregar e repetir.

Nenhuma ação nova pode usar o contexto antigo como autorização.

## 16. Acessibilidade, UX e linguagem

| ID | Jornada | Critério de aprovação |
|---|---|---|
| A01 | shell e portal | títulos, landmarks, menu atual, contexto e textos acentuados em ordem lógica |
| A02 | teclado | Tab/Shift+Tab, Enter, Espaço, setas, Home/End e Escape sem armadilha |
| A03 | Status não é | combo, valor, resumo e resultado anunciados com a mesma semântica |
| A04 | pesquisa salva | operador e resumo permanecem após salvar, aplicar e recarregar |
| A05 | colunas | diálogo nomeado; mover/remover; Escape devolve foco à engrenagem |
| A06 | cockpit | cinco indicadores textuais; indisponível não vira zero; cor não é única pista |
| A07 | Formcreator reduzido | menu externo, campos, ajuda, erros, anexos e envio disponíveis |
| A08 | fallback Formcreator | interface completa funcional e linguagem pública não técnica |
| A09 | regiões vivas | anúncio único, curto e sem leitura a cada tecla |
| A10 | 320 CSS px e zoom 200%/400% | sem perda, sobreposição ou rolagem horizontal global |
| A11 | forced colors | foco, bordas, estados e ações continuam perceptíveis |
| A12 | Axe pai e iframe | nenhuma violação confirmada crítica/séria; `incomplete` revisado manualmente |
| A13 | pt_BR e en_GB | sem mojibake, mistura de idioma ou nome acessível divergente |

### Roteiro NVDA/JAWS

1. Entrar sem mouse e confirmar título, perfil e entidade.
2. Percorrer regiões, títulos, links, formulários e tabelas pelas teclas do leitor.
3. Alternar naturalmente entre modo de navegação e formulário.
4. Executar A03–A08 integralmente.
5. Confirmar foco antes/depois de painéis, diálogo, erro e retorno.
6. Repetir com lista de títulos, links e formulários do leitor.
7. Registrar transcrição no Speech Viewer do NVDA ou equivalente do JAWS.

Aprovação exige conclusão sem inferir significado por posição, cor ou auxílio visual.

## 17. Volume, banco e concorrência

- medir TTFB do shell frio e aquecido;
- medir endpoint de resultados, cockpit, pesquisas salvas e seletores;
- confirmar timeout controlado e fallback utilizável até 6 segundos;
- verificar ausência de consulta por chamado no cockpit e na página de resultados;
- confirmar cinco consultas agregadas fixas do cockpit;
- consolidar IDs de todas as páginas sob massa grande;
- executar rampa isolada de concorrência `1 → 5 → 10` sessões, com critério de parada;
- não executar 25 ou mais sessões no ambiente compartilhado sem aprovação de capacidade;
- registrar P50/P95, 4xx/5xx, 429, timeout, queries por fluxo, CPU e conexões do banco;
- interromper se houver erro 5xx causado pelo plugin, crescimento de queries por linha, saturação sustentada ou impacto nos demais usuários.

Meta inicial de homologação: shell HTTP 200 em até 2 segundos no P95 da infraestrutura preparada e resultado ou fallback controlado em até 6 segundos. Ajustes de capacidade precisam ser registrados com a linha de base do ambiente, nunca mascarados como sucesso funcional.

## 18. Regressões essenciais

- rota canônica `front/tickets.php` não capturada pelo Formcreator;
- rota antiga preserva query e método compatível;
- lista, detalhe, timeline e ações ITIL autorizadas;
- atribuição e observador mostram apenas atores elegíveis;
- criação com anexo sem duplicidade;
- perfil sem leitura recebe página amigável sem consulta sensível;
- autocomplete remoto por teclado, paginação e erros;
- auditoria Axe local sem persistir ou transmitir conteúdo;
- console e logs sem fatal, SQL inválido ou repetição anormal.

## 19. Evidências

Para cada caso registrar:

- ID, data, ambiente e executor;
- versão e SHA do plugin;
- perfil, entidade e recursividade usando nomes sintéticos;
- passos, resultado esperado e observado;
- conjunto completo de IDs esperado e obtido;
- captura do resumo e da consulta nativa equivalente;
- captura ou vídeo curto de foco/teclado quando necessário;
- transcrição do leitor de tela;
- relatório Axe do pai e iframe;
- códigos HTTP e diagnóstico sanitizado;
- tempos e contagem de queries nos testes de carga;
- resultado `PASS`, `FAIL` ou `BLOCKED`, defeito, prioridade, responsável e reteste.

Nunca registrar cookie, token CSRF, cabeçalho de autorização, SQL bruto, conteúdo de chamado, resposta de formulário ou dados pessoais reais.

## 20. Severidade e critérios de parada

### P0 — parar imediatamente

- leitura ou mutação fora do usuário, perfil, entidade ou recursividade;
- IDOR confirmado;
- mutação sem autorização ou CSRF válido;
- ação aceita após logout;
- origem externa aceita como confiável;
- ocultação/alteração de CSRF, validação ou controles funcionais;
- perda de dados ou submissão duplicada.

### P1 — impede liberação

- `Status não é` ou pesquisa salva com conjunto diferente do GLPI nativo;
- contador do cockpit diferente do detalhamento;
- perfil autorizado sem acesso ao fluxo principal;
- formulário válido inutilizável;
- tarefa essencial impossível por teclado/leitor;
- foco perdido/preso, erro não anunciado ou timeout sem recuperação;
- quebra funcional em GLPI 10 ou 11;
- violação crítica/séria confirmada no DOM controlado pelo plugin.

### P2

Pode ser aceito somente com registro, responsável e prazo, desde que não prejudique compreensão, idioma, nome acessível, foco, contraste ou operação.

## 21. Gate final

### GO para produção

- 100% dos P0 e P1 aprovados em GLPI 10 e 11;
- equivalência de IDs entre portal, GLPI nativo, async, pesquisa salva e cockpit;
- Formcreator simples/complexo e fallback aprovados;
- zero fatal, 500 ou SQL inválido causado pelo plugin;
- NVDA e JAWS concluídos sem P0/P1;
- 320 px, zoom, forced colors e Axe triados;
- revisão pt_BR/en_GB concluída;
- carga controlada sem N+1 ou saturação anormal;
- evidências e aceite assinados por funcional, segurança, acessibilidade e operação.

### GO somente para homologação

Todos os P0 aprovados, mas existe P1 conhecido, registrado e ainda em correção.

### NO-GO

Qualquer P0 ou P1 não mitigado.

## 22. Registro de execução

| Caso | Ambiente | Perfil/entidade | Resultado | Evidência | Defeito | Reteste | Responsável |
|---|---|---|---|---|---|---|---|
| | | | PASS/FAIL/BLOCKED | | | | |

## 23. Aprovações

| Frente | Nome | Data | Decisão | Observações |
|---|---|---|---|---|
| Funcional | | | | |
| Segurança | | | | |
| Acessibilidade | | | | |
| Operação/infraestrutura | | | | |
| Responsável pela liberação | | | | |
