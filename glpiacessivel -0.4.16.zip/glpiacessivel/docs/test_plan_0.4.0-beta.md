# Plano de testes da versão 0.4.0-beta

## Objetivo e decisão

Comprovar que a lista processa somente uma página limitada de IDs autorizados,
permanece utilizável sem total exato e protege PHP-FPM/banco sob concorrência,
sem regressão de ACL ou acessibilidade.

GO exige o mesmo ZIP/SHA em GLPI 10 e 11, zero P0/P1, SQL limitada comprovada,
equivalência de IDs/ordem, ausência de 504/OOM e aprovação assistiva. O resultado
de uma versão do GLPI não substitui a outra.

## Gate 1 — artefato e esquema

1. confirmar `0.4.0-beta` em setup, XML, CFF, catálogos e tela do GLPI;
2. instalar/atualizar o mesmo ZIP no GLPI 10 e 11;
3. verificar índices de auditoria por `created_at,id`;
4. confirmar que a retenção não roda em cada `AuditLogger::log()`;
5. executar a CronTask em tabela vazia, pequena e grande;
6. registrar PHP, banco, proxy, FPM, plugin e SHA-256.

## Gate 2 — capability e SQL efetiva

Para cada GLPI:

1. confirmar o adaptador correto e sua assinatura;
2. capturar a SQL sanitizada somente em homologação;
3. provar `LIMIT offset,page_size+1`;
4. provar projeção somente de ID e campos inevitáveis de ordenação;
5. confirmar zero `Search::getDatas()` no caminho limitado;
6. adulterar assinatura/classe/provider e confirmar falha fechada;
7. confirmar ausência de fallback ao executor ilimitado.

## Gate 3 — equivalência funcional e ACL

Comparar todos os IDs e sua ordem com o GLPI nativo no mesmo usuário, perfil,
entidade e recursividade:

- `all`, `mine` e `group`;
- sem grupos, um grupo e vários grupos;
- status, texto e ID;
- critérios aninhados e metacritérios;
- busca rápida, avançada e pesquisa salva;
- Self-Service, técnico, gestor e Super-Admin;
- entidade raiz/filha, direta/recursiva;
- troca de contexto durante a requisição.

Nenhum ID fora do resultado nativo é tolerado. O registro sentinela não pode ser
hidratado ou enviado ao cliente.

## Gate 4 — paginação e total

Cobrir 0, 1, 19, 20, 21, 40, 41 e grandes quantidades:

- primeira, intermediária, última e página além do fim;
- `has_previous` e `has_more` corretos;
- total `null/deferred`, `pending`, `exact`, `unavailable` e resposta tardia;
- total ausente nunca convertido em zero;
- sem “Página X de Y” ou “Última” quando desconhecido;
- ordenação estável com empates;
- offset máximo e orientação para refinar/abrir no GLPI.

## Gate 5 — capacidade e falhas

- uma consulta em voo por usuário/contexto;
- burst, token bucket, `Retry-After` e liberação da lease em `finally`;
- circuito fechado, aberto, resfriamento e half-open;
- APCu ausente ou falho com contenção conservadora;
- múltiplas abas, abort, retry e sessão bloqueada;
- 401, 403, 409, 422, 429, 503, timeout e resposta inválida;
- nenhum retry automático;
- contexto alterado invalida resposta tardia.

Sob excesso, o endpoint deve devolver 429/503 antes do timeout externo, sem
acumular consultas zumbis.

## Gate 6 — banco, auditoria e carga

Massas: 10 mil, 100 mil e 1 milhão de chamados, dados sintéticos, conteúdo longo
e alto fan-out de pessoas/grupos.

Rampa inicial: 1, 5, 10 e 25 usuários; cargas superiores somente após
dimensionamento. Medir:

- P50/P95/P99 por preparação, SQL, hidratação e serialização;
- RSS/pico de memória e fila FPM;
- conexões, locks, deadlocks e temporárias em disco;
- linhas examinadas/retornadas;
- 429, 503, 504, abortos e circuito;
- statements e duração da auditoria/CronTask.

Aceite: zero OOM/504/deadlock do plugin, recuperação da fila após a carga, RSS
sem deriva relevante e quantidade processada compatível com a página limitada.

## Gate 7 — WCAG/eMAG

- shell sem JavaScript e fallback utilizável;
- um anúncio por transição, verificado por `MutationObserver`;
- `aria-busy` termina em todos os estados;
- página pronta com total pendente/indisponível;
- chegada do total sem alterar foco, seleção ou tabela;
- foco previsível em retry, paginação e erro;
- Primeira/Anterior/Próxima por teclado;
- 320 CSS px, zoom 200%/400%, forced-colors e foco visível;
- NVDA/Firefox e Chrome; JAWS/Edge;
- pt_BR/en_GB e Axe no DOM do plugin.

## Gate 8 — automação e pacote

Linha de base automatizada obtida em 24 de agosto de 2026:

- PHP 8.1 e 8.3: 582 testes PHPUnit e 3.638 asserções aprovados;
- PHPStan e PHPCS aprovados;
- 40 verificações de navegador aprovadas;
- auditoria i18n com 2.320 mensagens aprovada.

Esses resultados não substituem os Gates 2, 3, 6 e 7 no GLPI real.

Executar com PHP compatível:

```powershell
composer qa
pnpm run test:browser
.\tools\i18n-audit.ps1 -RequireMsgfmt
```

Depois dos gates reais:

```powershell
.\tools\build-release.ps1 -Output .release_0.4.0-beta_bounded_ticket_search -Profile marketplace -RequireMsgfmt
.\tools\verify-release.ps1 -Package .release_0.4.0-beta_bounded_ticket_search\glpiacessivel.zip -ExpectedVersion 0.4.0-beta -PublicProfile
```

Registrar versão, ambiente, perfil, entidade, recursividade, massa, SHA, SQL
limitada comprovada, IDs esperados/observados, métricas, tecnologia assistiva e
evidência anonimizada.

## NO-GO

- SQL da página sem `LIMIT` real;
- uso de `Search::getDatas()` no caminho limitado;
- qualquer diferença/autorização indevida de IDs;
- sentinela exibida;
- total desconhecido apresentado como zero;
- retorno ao executor ilimitado;
- OOM, 504, fila/conexões descontroladas;
- purga de auditoria no request;
- resposta tardia de contexto antigo;
- foco perdido, busy permanente ou anúncio duplicado em jornada crítica.
