# GLPI Acessível 0.4.3-beta

Esta versão aplica os refinamentos priorizados após o checklist de acessibilidade e a revisão funcional de chamados, sem ampliar as permissões concedidas pelo GLPI 10 ou 11.

## Chamados, atribuição e observadores

- Técnicos, grupos responsáveis, pessoas observadoras e grupos observadores são tratados como quatro papéis independentes.
- A atualização é diferencial: campo omitido preserva o estado; campo enviado vazio limpa explicitamente; listas 0/1/N não produzem SQL vazio.
- Antes da mutação, cada ID é revalidado pelo provedor nativo correspondente, considerando chamado, entidade, recursividade, perfil e finalidade.
- Um ator existente que deixou de aparecer no catálogo não é apagado incidentalmente. Requerente, atores anônimos e o papel oposto também são preservados.
- A alteração exige confirmação de impacto vinculada à sessão, ao usuário, ao chamado e à ação; o token é de uso único e expira.
- Seletores remotos mantêm rótulo, ajuda, estado atual, teclado, foco, remoção nomeada, mensagens e fallback nativo.
- As requisições dos seletores enviam os cabeçalhos AJAX e CSRF esperados pelo listener nativo do GLPI 11; o GLPI 10 conserva a validação legada do mesmo token.

## Abertura em nome de outra pessoa

- A busca de requerentes existe somente na interface central e quando o núcleo confirma a capacidade de delegação.
- A orientação visível solicita nome ou usuário; a exigência de dois caracteres permanece apenas como proteção contra enumeração ampla. A matrícula continua pesquisável quando for o nome de usuário adotado pela instalação.
- No Autoatendimento, o requerente permanece o usuário autenticado, inclusive diante de POST adulterado.
- A autorização é verificada no catálogo remoto, no serviço e novamente junto à chamada nativa `Ticket::add()`.
- Se a capacidade nativa não puder ser provada, o portal falha fechado e oferece o formulário nativo como alternativa.
- No GLPI 11, o fingerprint remoto usa identidade, perfil/interface, entidade e grupos normalizados, evitando falsos `context_stale` causados por metadados e caches voláteis de direitos. A autorização e a consulta nativa continuam sendo repetidas em cada requisição.
- O texto da busca usa a terminologia comum às duas versões: **nome ou usuário**. Matrícula continua sendo encontrada quando for o nome de usuário configurado pela organização.

## Lista, pesquisa e solução

- A lista progressiva, paginada e limitada passa a ser o padrão seguro; o administrador ainda pode desativá-la explicitamente.
- Um critério negativo de status sem Search Options confiáveis não é reinterpretado: a pesquisa é recusada para impedir resultados mais amplos.
- A inclusão nativa de solução registra o ID retornado e faz leitura posterior diagnóstica de chamado, tipo e conteúdo não vazio. A verificação nunca repete a gravação nem inclui o conteúdo na auditoria.

## Refinamentos do checklist de acessibilidade

- O formulário de criação deixa de produzir `main` aninhado.
- O detalhe usa pares semânticos para o resumo e expõe a data de abertura.
- O botão de pesquisa recebe nome contextual e preserva o destino de foco nos resultados.
- Artigos da base de conhecimento usam títulos reais, sem saltos artificiais, e links com nomes acessíveis únicos.
- Os controles continuam sujeitos a teste manual com teclado, NVDA/JAWS, zoom, reflow, contraste e cores forçadas; a aprovação automatizada não equivale a certificação WCAG, eMAG ou RGAA.

## Compatibilidade e rollback

- Código validado em PHP 8.1 e 8.3 e projetado para GLPI 10 e 11.
- Para rollback, restaure a pasta anterior somente com schema compatível. A lista progressiva pode ser desativada administrativamente e os seletores continuam oferecendo o caminho nativo.
- O fingerprint de runtime foi renovado para que o diagnóstico de atualização detecte mistura de arquivos da versão anterior.

Consulte [o plano de testes](test_plan_0.4.3-beta.md) antes de promover esta beta.
