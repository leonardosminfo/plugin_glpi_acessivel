# Plano de testes — 0.4.9-beta

## Matriz obrigatória

Executar no GLPI 10 e no GLPI 11, com a lista assíncrona e a proteção de capacidade habilitadas.

1. Preparar a mesma sessão autenticada e abrir as páginas 1, 2, 3, 4 e 5 em sequência imediata: todas devem retornar HTTP 200 e itens coerentes.
2. Se as cinco respostas forem concluídas em menos de dois segundos, fazer uma sexta consulta imediata: deve retornar HTTP 429, envelope `ticket_results`, código `rate_limited` e `Retry-After` entre 1 e 2 segundos. Se o servidor consumir dois segundos ou mais, registrar “limite não exercitado” porque a reposição de um crédito é legítima, sem declarar falha da política.
3. Aguardar o valor de `Retry-After` e repetir: a página deve retornar HTTP 200 sem reiniciar PHP-FPM, sessão ou navegador.
4. Confirmar que cada navegação gera somente um POST para `ticket.results.php` e que não há duplicação pelo JavaScript.
5. Confirmar que filtros, pesquisa salva, página e contexto de perfil/entidade permanecem inalterados após a recusa.
6. Confirmar que a contingência nativa informa que os filtros devem ser revisados.

O ensaio controlado está em `tools/homologation/ticket-rate-policy.cjs`; ele mede o tempo da rajada e distingue aprovação, falha e política não exercitada. A senha é lida somente de `GLPI_TEST_PASSWORD` e não é incluída no artefato.

## Migração e configuração

1. Instalação nova: persistir `30/60/5`.
2. Atualização com a configuração exata `6/60/2`: migrar para `30/60/5` em uma transação.
3. Atualização com qualquer valor personalizado ou chave ausente: não alterar nenhum dos três valores.
4. Executar novamente a instalação: `V0004` deve permanecer única e não repetir a calibração.
5. Alterar a política administrativa: o bucket da lista deve reiniciar com a nova assinatura, sem apagar outros dados da sessão.

## Acessibilidade e recuperação

1. Em `429`, existir uma única mensagem semântica com a página e a preservação dos filtros.
2. O título “Página não carregada” deve rotular a região de recuperação.
3. O botão “Tentar novamente” não deve mudar de nome durante a espera.
4. A contagem deve usar `aria-live="off"`; ao zerar, deve ocorrer um único anúncio na região de resultados.
5. Ao repetir, o foco deve permanecer no título da lista; a página carregada deve substituir integralmente o erro.
6. Seleção e paginação devem ficar ocultas em carregamento, falha e resultado vazio, reaparecendo apenas quando aplicáveis.
7. Validar teclado, zoom de 200% e 400%, leitor de tela e contraste nos dois GLPIs.
8. No fallback síncrono, confirmar que o botão permanece desabilitado durante a contagem e que a liberação é anunciada antes de aceitar a retentativa.

## Regressão técnica

- PHPUnit completo, PHPStan, PHPCS, auditoria i18n e suíte browser;
- cinco sucessos, sexta recusa e recuperação autenticada em ambos os GLPIs;
- carga concorrente para confirmar que a proteção de capacidade continua recusando excesso real;
- auditoria sem valores de pesquisa ou conteúdo de chamados;
- pacote com `VERSION`, XML, CFF, `setup.php` e fingerprints de runtime coerentes.
