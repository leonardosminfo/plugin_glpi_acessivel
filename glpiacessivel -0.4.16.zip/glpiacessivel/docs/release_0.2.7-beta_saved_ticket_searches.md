# 0.2.7-beta - pesquisas de chamados salvas e acessiveis

## Objetivo

Esta versao permite que usuarios, inclusive pessoas cegas, recuperem pesquisas de chamados ja salvas no GLPI e criem pesquisas privadas no portal acessivel sem reconstruir filtros a cada sessao.

## Funcionalidades

- lista pesquisas privadas do usuario e pesquisas publicas autorizadas pelo GLPI;
- identifica a pesquisa nativa padrao;
- classifica cada pesquisa como compativel, copiavel ou disponivel somente no GLPI;
- executa criterios nativos validados pela Search API;
- cria copia editavel quando todos os criterios podem ser traduzidos sem perda;
- salva filtros, ordenacao, paginacao, agrupamento e colunas visiveis;
- permite definir uma pesquisa privada do portal como padrao;
- permite excluir pesquisas proprias sem alterar a pesquisa nativa;
- oferece link para abrir a pesquisa completa no GLPI quando o portal nao suporta seu contrato.

## Modelo de seguranca

- pesquisas privadas nativas sao visiveis somente para o autor;
- pesquisas publicas passam pela autorizacao nativa e pelo contexto de entidade;
- o identificador recebido pela URL nunca concede acesso por si so;
- a consulta nativa e carregada novamente no momento de cada uso;
- criterios desconhecidos, metacriterios e operadores nao homologados bloqueiam a execucao no portal;
- consultas truncadas, parametros sem equivalencia, lixeira e tipos URI/alerta ficam disponiveis somente no GLPI;
- uma chave removida ou sem autorizacao produz alerta e lista vazia, nunca uma listagem ampla;
- um erro da Search API nunca cai para uma listagem sem os criterios da pesquisa;
- resultados continuam submetidos a ACL por chamado;
- termos livres nao sao gravados na auditoria; registra-se apenas se existe termo e a quantidade de colunas.

## Persistencia

A tabela `glpi_plugin_glpiacessivel_ticketviews` armazena somente pesquisas privadas criadas ou importadas pelo usuario:

- usuario proprietario;
- nome;
- contrato JSON normalizado e versionado;
- indicador de pesquisa padrao;
- identificador da pesquisa nativa de origem, quando houver;
- datas de criacao e atualizacao.

Nao sao armazenados SQL, resultados de chamados ou ACLs em cache.

## Experiencia assistiva

- a escolha da pesquisa so e aplicada por botao explicito;
- origem, visibilidade e compatibilidade sao apresentadas em texto;
- mensagens de sucesso e erro usam o fluxo anunciavel do portal;
- customizacao de colunas usa controles HTML nativos;
- ID e titulo permanecem na visualizacao para identificacao e abertura;
- o gerenciamento nao depende de arrastar itens;
- pesquisas incompativeis apresentam explicacao e link para o GLPI;
- a opcao sem nome e os links Limpar filtros suprimem explicitamente a pesquisa padrao;
- cada acao repetida inclui o nome da pesquisa no nome acessivel;
- instrucoes de selecao e colunas usam associacao programatica;
- toda a interface nova possui mensagens pt_BR e en_GB compiladas.

## Homologacao obrigatoria

Repetir em GLPI 10 e 11:

1. pesquisa privada simples do usuario;
2. pesquisa publica na entidade ativa;
3. pesquisa publica recursiva;
4. pesquisa privada de outro usuario;
5. pesquisa com `AND` e `OR`;
6. pesquisa com metacriterio nao suportado;
7. pesquisa nativa alterada ou excluida depois do primeiro uso;
8. troca de perfil e entidade;
9. copia editavel e pesquisa padrao do portal;
10. customizacao de colunas, ordenacao e paginacao;
11. NVDA com Firefox e Chrome;
12. JAWS com Edge ou Chrome;
13. VoiceOver com Safari;
14. teclado, zoom de 400%, alto contraste e `forced-colors`.

O fluxo somente sera considerado homologado se puder ser concluido sem assistencia visual e sem perda silenciosa de criterios.
