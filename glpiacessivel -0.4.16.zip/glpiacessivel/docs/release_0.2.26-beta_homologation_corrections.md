# GLPI Acessivel 0.2.26-beta: correcoes da homologacao

## Objetivo

A `0.2.26-beta` corrige dois problemas confirmados durante a homologacao da candidata anterior: formularios Formcreator autorizados apareciam no catalogo, mas podiam abrir um caminho inexistente; e a lista assincrona de chamados podia permanecer indefinidamente em carregamento nos layouts standalone do portal.

As flags das frentes de escalabilidade continuam server-side, independentes, desativadas por padrao e sem criar tabela ou copiar dados operacionais.

## Formcreator

- A raiz web e resolvida no servidor por `FORMCREATOR_ROOTDOC` ou `Plugin::getWebDir('formcreator')`.
- Sao aceitas instalacoes oficiais em `/plugins/formcreator` e `/marketplace/formcreator`, inclusive quando o GLPI esta em subdiretorio.
- A raiz precisa ser local, pertencer ao `root_doc` do GLPI e terminar no diretorio conhecido do Formcreator.
- Catalogo, abertura e envio nativo usam a mesma raiz validada.
- Caminhos, origens e endpoints enviados pelo navegador nao participam da resolucao.
- Se o contrato nao puder ser comprovado, o plugin falha de modo conservador e oferece a jornada nativa suportada.
- No GLPI 11, o Service Catalog nativo continua sendo a fonte suportada.

## Lista assincrona de chamados

- O ativo `ticket-results.js` e referenciado pela propria pagina, com versao, e nao depende do hook global do layout nativo.
- O HTML inicial nao afirma que existe uma requisicao em andamento.
- O link para a lista nativa fica visivel com ou sem JavaScript.
- `aria-busy` existe somente durante uma requisicao real e e removido em sucesso, falha ou timeout.
- Configuracao ausente, ativo ausente, resposta invalida, sessao expirada, troca de contexto, limite de frequencia e indisponibilidade produzem um estado terminal compreensivel.
- A nova tentativa e explicita, nao move o foco e cria somente uma nova requisicao.
- Respostas tardias nao substituem o fallback depois do timeout.

## Acessibilidade e seguranca

- Falhas nao deixam uma regiao permanentemente ocupada.
- O inicio e a conclusao usam status moderado; falhas usam alerta e mantem botoes e links operaveis por teclado.
- O servidor continua sendo a fonte de ACL, perfil, entidade, recursividade e elegibilidade dos formularios.
- Nao ha liberacao de CORS, persistencia local dos resultados ou confianca em rotulos e caminhos fornecidos pelo cliente.

## Homologacao obrigatoria

Antes de habilitar as flags fora do canario:

1. testar GLPI 10 com Formcreator 2.13 instalado sob `marketplace/formcreator` e, quando aplicavel, sob `plugins/formcreator`;
2. comparar o catalogo do plugin com o catalogo nativo usando perfil e entidade limitados;
3. abrir e enviar ao menos um formulario autorizado, confirmando que um formulario proibido continua inacessivel por URL direta;
4. testar a lista de chamados nos modos portal, hibrido e embedded;
5. simular ativo JavaScript ausente e endpoint indisponivel, confirmando fallback imediato e ausencia de `aria-busy` permanente;
6. repetir teclado, reflow a 320 CSS px, NVDA e JAWS nas versoes institucionais definidas pelo plano de testes.

## Geracao do pacote

```powershell
.\tools\build-release.ps1 -Output .release_0.2.26-beta_homologation_corrections -Profile marketplace -RequireMsgfmt
.\tools\verify-release.ps1 -Package .release_0.2.26-beta_homologation_corrections\glpiacessivel.zip -ExpectedVersion 0.2.26-beta -PublicProfile
```
