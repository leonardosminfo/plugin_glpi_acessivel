# Plano de testes — GLPI Acessível 0.4.16-beta

## Ambientes

Executar o mesmo pacote em GLPI 10/PHP 8.1 (`http://127.0.0.1:8089`) e GLPI 11 (`http://127.0.0.1:8080`), com um perfil técnico autorizado e um perfil sem direitos de alteração. Não reiniciar o PHP-FPM durante a atualização.

## Matriz obrigatória

| ID | Cenário | Resultado esperado |
|---|---|---|
| RF-01 | Detalhe a 305 e 320 pixels CSS | acompanhamento, tarefa, visibilidade e anexos sem corte ou rolagem horizontal |
| FIL-01 | Aplicar `Status = Novo` | seletor, resultados e resumo exibem o mesmo filtro |
| FIL-02 | Avançar e voltar páginas | filtro e resumo permanecem; nenhuma falsa limitação ou `502/504` |
| FIL-03 | Abrir pesquisa salva/avançada | resumo nativo validado não é substituído pelo resumo frequente |
| FC-01 | Abrir FormCreator incorporado | título, instruções, campos, mensagens e envio mantêm funcionamento nativo |
| FC-02 | Campo com `for` e ID dinâmico | nome acessível corresponde ao rótulo visível |
| FC-03 | Select2 inicial e recriado | combobox anuncia rótulo do campo e valor; tokens ARIA não duplicam |
| FC-04 | Enviar com erro e com sucesso | validação, foco, CSRF e submissão continuam nativos |
| SOL-01 | Entidade sem tipo de solução elegível | mensagem explica a ausência e permite registrar sem informar tipo |
| SOL-02 | Entidade com tipo elegível | opções permitidas aparecem e o registro segue o fluxo nativo |
| VLB-01 | Bloquear o recurso externo do VLibras | portal permanece utilizável e o estado informa recuperação posterior |
| VLB-02 | Restaurar a rede | uma nova tentativa controlada ocorre sem laço agressivo |
| ACL-01 | Repetir com perfil restrito | controles e dados obedecem exatamente aos direitos e entidades do GLPI |
| UPD-01 | Substituir a 0.4.15 pela 0.4.16 | versão e assets novos aparecem sem reiniciar PHP-FPM |

## Gates automatizados

1. PHPUnit em PHP 8.1, PHPStan e PHPCS;
2. suíte de navegador completa, incluindo Axe para `label`, `select-name` e `aria-input-field-name`;
3. auditoria i18n e catálogos `pt_BR`/`en_GB` compilados;
4. verificação do ZIP público e paridade entre `assets` e `public/assets`;
5. checklist autenticado nas duas versões, com medição de tempo e ausência de `502/504`.

## Aceite

O cenário só é aprovado quando o estado observado no plugin coincide com o GLPI nativo, não amplia direitos, não duplica mutações e não cria regressão de teclado, foco, leitor de tela, reflow ou desempenho. Pendências de NVDA/WAVE devem ser registradas separadamente das violações automatizadas confirmadas.
