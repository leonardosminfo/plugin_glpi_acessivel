# Plano de testes da versão 0.2.36-beta

## Objetivo e gate

Confirmar as correções de runtime encontradas na homologação do GLPI 11 sem alterar ACL, CSRF, validações, conjuntos de chamados ou submissões nativas. A produção é `NO-GO` diante de busca válida que perca o estado, redirecionamento de sucesso registrado como erro, repetição de `POST`, iframe aceito com contrato divergente, overflow horizontal do documento em 320 pixels CSS, texto crítico sem acentuação ou qualquer gate automatizado vermelho.

## Matriz mínima

Executar em GLPI 10 e GLPI 11, com idiomas `pt_BR` e `en_GB`, nos perfis Self-Service, técnico e administrador, em entidade recursiva e não recursiva. No GLPI 11, usar ao menos um formulário simples controlado do Service Catalog. Registrar versão exata de GLPI, PHP, banco, navegador e plugin.

Preparar antes do teste:

- um termo de busca que retorne conjunto conhecido e outro sem resultados;
- uma pesquisa nativa que possa ser criada, renomeada e excluída;
- um chamado de teste com título rastreável e sem dados pessoais;
- um formulário do Service Catalog com dois campos e submissão para um destino controlado;
- usuário sem direito de leitura e usuário autorizado em entidade distinta.

## R01 — busca rápida e avançada no GLPI 11

1. Abrir `front/tickets.php`, informar o termo controlado e selecionar `Pesquisar`.
2. Capturar o POST e a resposta de redirecionamento sem seguir automaticamente.
3. Confirmar que o destino de sucesso contém `advanced_search_token` opaco e `focus=results`; o destino conservador de falha pode manter `search_mode=advanced`, mas não pode fingir que emitiu token.
4. Seguir o redirecionamento e comparar termo, resumo aplicado, total e conjunto de IDs com a consulta nativa equivalente.
5. Repetir com regra avançada, zero resultados e erro de validação.
6. Confirmar que uma busca válida não termina somente em `tickets.php?search_mode=advanced`, não mantém resultados antigos e não anuncia erro.

Aceite: o novo estado é usado uma única vez conforme o contrato da sessão, o foco chega à região de resultados e falhas reais usam o destino conservador sem ampliar o conjunto autorizado.

## R02 — pesquisas salvas

1. Criar uma pesquisa salva a partir do estado controlado.
2. Aplicar, renomear, definir ou remover o padrão e excluir a pesquisa.
3. Em cada POST, confirmar sucesso e redirecionamento somente depois da mutação.
4. Repetir com CSRF inválido, pesquisa de outro usuário e contexto alterado.

Aceite: operações válidas não são classificadas como falhas; ACL e CSRF falham fechado; nenhuma pesquisa alheia é revelada ou alterada.

## R03 — criação de chamado

1. Enviar o formulário acessível com dados controlados e capturar o redirecionamento.
2. Confirmar a criação de um único chamado e a chegada ao seu detalhe autorizado.
3. Repetir com título ausente, descrição ausente, valor inválido, CSRF inválido e envio duplicado.
4. Remover ou encerrar a massa conforme a política do ambiente.

Aceite: o redirect de sucesso não é capturado como erro; validações continuam no formulário; idempotência evita duplicata; não há mudança na ordem ACL/CSRF/validações.

## F01 — iframe do Service Catalog do GLPI 11

1. Abrir o formulário pelo catálogo do plugin e confirmar que o menu permanece presente e marca `Formulários` como página atual.
2. Confirmar origem igual, rota `/Form/Render/<id>`, formulário identificável, método `POST`, mesmo ID em `forms_id` e `action` `/Form/SubmitAnswers`.
3. Percorrer campos, condições e mensagens por teclado; anexar arquivo pequeno se o formulário permitir.
4. Enviar uma resposta controlada e confirmar que o request foi feito pelo formulário nativo, com CSRF e endpoint oficiais.
5. Confirmar que a classe de apresentação mínima do Formcreator não foi aplicada ao GLPI 11.

Aceite: há um único formulário de tarefa reconhecido, o plugin não cria POST auxiliar e a resposta/target final é produzido pelo GLPI 11.

## F02 — falha conservadora e nova tentativa

1. Em ambiente de teste ou fixture automatizada, variar separadamente ID, `action`, rota, estrutura, origem e estado de login do documento filho.
2. Confirmar estado `failed`, mensagem anunciada uma vez, iframe não ocultado, botão `Tentar novamente` e alternativa de página completa.
3. Acionar nova tentativa e registrar os métodos de rede.
4. Restaurar o contrato correto e confirmar transição para `ready` sem mover o foco inesperadamente.

Aceite: a nova tentativa repete somente o GET de renderização, nunca `/Form/SubmitAnswers`; nenhuma divergência é aceita silenciosamente; a página completa permanece utilizável.

## A01 — reflow em 320 pixels CSS

1. Abrir portal, chamados, busca, detalhe, cockpit e formulários em viewport de `320 × 720` CSS pixels.
2. Usar nomes extensos de perfil, entidade, usuário, filtros e colunas.
3. Medir `scrollWidth - clientWidth` do documento e do `body`.
4. Confirmar seletores, botões e link de saída dentro da viewport e com alvo mínimo de 44 pixels.
5. Confirmar que tabela extensa rola somente em sua região focalizável, com nome acessível e sem esconder indicador de ordenação.
6. Repetir em zoom de 200% e 400% e em orientação paisagem.

Aceite: overflow do documento e do `body` de no máximo 1 pixel por arredondamento; controles íntegros; rolagem tabular local e operável por teclado.

## L01 — linguagem e catálogos

1. Percorrer criação, detalhe, busca, pesquisas salvas, resultados assíncronos, seletores, cockpit, formulário e erros nos dois idiomas.
2. Confirmar textos visíveis, ARIA, ajuda, placeholders e regiões vivas sem palavras portuguesas conhecidas sem acentuação ou chaves internas.
3. Executar o gate i18n e validar POT/PO/MO, msgids estáticos, placeholders, ausência de fuzzy/vazios e mojibake.
4. Confirmar equivalência dos ativos em `assets/` e `public/assets/`.

Aceite: nenhuma mensagem pública do controlador aparece sem acentuação; pt-BR e en-GB seguem o catálogo ativo; `msgfmt` e a auditoria ficam verdes.

## Acessibilidade manual

- teclado completo, foco visível, retorno de foco e ausência de armadilhas dentro e fora do iframe;
- NVDA com Firefox e Chrome e JAWS com Edge, registrando títulos, estado do formulário, erros, tabela rolável e resultados;
- viewport de 320 pixels CSS, zoom de 200% e 400%, alto contraste e cores forçadas;
- nenhuma informação dependente apenas de cor, nenhum anúncio duplicado e nenhuma mudança de foco causada por falha ou nova tentativa.

## Automação

Executar, nessa ordem:

```powershell
php -d xdebug.mode=off -d xdebug.log=NUL vendor/bin/phpunit --colors=never
php -d xdebug.mode=off vendor/phpstan/phpstan/phpstan.phar analyse --memory-limit=512M --no-progress
php -d xdebug.mode=off vendor/squizlabs/php_codesniffer/bin/phpcs -p --warning-severity=0
pnpm run test:browser
.\tools\i18n-audit.ps1 -RequireMsgfmt
.\tools\build-release.ps1 -Output .release_0.2.36-beta_runtime_homologation_fixes -Profile marketplace -RequireMsgfmt
.\tools\verify-release.ps1 -Package .release_0.2.36-beta_runtime_homologation_fixes\glpiacessivel.zip -ExpectedVersion 0.2.36-beta -PublicProfile
```

Durante a preparação desta documentação, não gerar o ZIP. Os dois últimos comandos pertencem ao gate final, depois da homologação funcional e assistiva.

## Evidências obrigatórias

- headers e destinos dos POSTs, sem expor CSRF ou token opaco integral;
- conjunto de IDs e contagem comparados com o GLPI nativo;
- log de rede provando nova tentativa somente GET e submissão somente nativa;
- captura e medição de reflow em 320 pixels CSS;
- fala registrada dos estados principais com tecnologia assistiva;
- saídas completas dos gates automatizados e versões das ferramentas;
- decisão `GO/NO-GO`, responsável, data e pendências aceitas.

## Aceite do artefato

O ZIP aprovado deve declarar `0.2.36-beta` em `setup.php`, XML, CFF, README, catálogos e manifesto; conter esta nota, este plano e as documentações tecnológica, funcional e de acessibilidade; preservar a raiz única `glpiacessivel/`; passar o verificador oficial; e ter o SHA-256 final registrado no handoff.
