# Plano de testes — GLPI Acessível 0.4.13-beta

## 1. Gates do pacote

1. Confirmar `0.4.13-beta` em `VERSION`, `setup.php`, XML, CFF, README e catálogos gettext.
2. Confirmar `20260831-04` em `setup.php`, `Bootstrap` e `SchemaManager`.
3. Executar PHPUnit, PHPStan, PHPCS, auditoria i18n, sintaxe JavaScript e verificação dos espelhos públicos.
4. Gerar um único ZIP, validar a raiz `glpiacessivel/`, o perfil público, o SHA-256 e a ausência de testes, temporários e chamadas a `opcache_reset()`.

## 2. Matriz funcional em GLPI 10 e 11

Usar o mesmo ZIP e checksum nas duas versões.

1. Criar ou selecionar chamado ativo com perfil técnico autorizado, entidade válida e todos os campos obrigatórios.
2. Informar tipo e descrição da solução; confirmar a ação pelo diálogo acessível.
3. Verificar no banco e na interface nativa: exatamente uma nova `ITILSolution`, vínculo ao chamado, autor, tipo, conteúdo e status `Solucionado` ou `Fechado` conforme a regra nativa.
4. Confirmar que o plugin não criou acompanhamento em lugar de solução e não executou atualização manual de status.
5. Atualizar a página e repetir o mesmo POST/token: nenhum segundo registro e nenhuma segunda auditoria terminal.
6. Recusar a solução pelo fluxo nativo, reabrir quando permitido e confirmar que uma nova solução legítima volta a ser possível, sem bloqueio por solução histórica.
7. Repetir com perfil sem `canSolve`, entidade fora do escopo, tipo inválido e campo obrigatório ausente; resultado esperado: zero solução criada e mensagem contextual.

## 3. Concorrência e falhas

1. Abrir o mesmo chamado em dois navegadores ou sessões técnicas.
2. Confirmar quase simultaneamente descrições iguais e diferentes. Resultado: uma única mutação; a outra sessão recebe operação em andamento/conflito.
3. Com duas conexões MySQL, comprovar visibilidade do guard antes do `add()` e bloqueio `FOR UPDATE` durante a transação.
4. Simular retorno positivo do `add()` sem transição de status: rollback, delta de solução igual a zero e nova tentativa liberada somente após comprovação.
5. Simular commit/rollback inconclusivo: manter guard compartilhado, ocultar o formulário de nova solução e orientar atualização/reconciliação.
6. Simular falha e exceção ao limpar o guard após commit confirmado: preservar sucesso, `marker_cleared=false`, zero retry automático e chamado terminal.
7. Simular releitura ausente ou solução com vínculo divergente: manter estado parcial; não apagar marcador por inferência.

## 4. Acessibilidade

1. Percorrer o diálogo somente por teclado: foco inicial em Cancelar, Tab para Confirmar, ciclo até “Revisar descrição completa” e Shift+Tab inverso.
2. Abrir e fechar a descrição completa com Enter e Espaço.
3. Confirmar foco restaurado no acionador após cancelamento e foco no painel de estado após resultado parcial.
4. Validar nomes, instruções, mensagens, `alertdialog`, região viva, contraste, zoom de 200% e reflow em 320 CSS px.
5. Repetir com NVDA/Firefox e NVDA/Chrome; registrar anúncio do resumo, consequência, progresso e resultado.

## 5. Critérios de aceite

- nenhuma solução duplicada nos cenários de replay, concorrência ou falha;
- exatamente uma chamada nativa no sucesso;
- nenhum `Ticket::update()` manual no fluxo de solução;
- nenhuma liberação de retry por leitura inconclusiva;
- falha ao persistir o guard impede a mutação;
- falha de limpeza não reclassifica sucesso;
- todos os gates automatizados verdes;
- evidência ao vivo aprovada no GLPI 10 e 11 antes da promoção da beta.

