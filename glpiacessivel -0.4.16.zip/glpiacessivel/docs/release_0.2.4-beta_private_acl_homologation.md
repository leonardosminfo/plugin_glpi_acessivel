# 0.2.4-beta - ACL de itens privados e retorno acessivel

## Objetivo

Corrigir os bloqueadores encontrados na homologacao da 0.2.3-beta sem ampliar os direitos concedidos pelo GLPI.

## Correcoes

- a criacao publica continua delegada a `ITILFollowup::can()` e `TicketTask::can()`;
- `is_private=1` exige adicionalmente `ITILFollowup::SEEPRIVATE` ou `TicketTask::SEEPRIVATE`;
- o bloqueio ocorre no repositorio antes da persistencia, inclusive contra POST forjado;
- modelos privados sao omitidos e rejeitados quando o perfil nao possui `SEEPRIVATE`;
- a interface mostra a escolha privada somente quando autorizada e envia valor publico fixo nos demais perfis;
- radios nativos possuem `id`, `label for`, descricao associada, foco visivel e estado selecionado perceptivel;
- chamado inexistente ou fora do escopo gera mensagem acessivel, auditoria e retorno para Meus chamados.

## Compatibilidade

A implementacao usa os direitos nativos `SEEPRIVATE` presentes em GLPI 10 e 11 e mantem bloqueio conservador quando classe, constante, sessao ou permissao nao estiver disponivel.

## Evidencias automatizadas

- PHPUnit: 123 testes e 561 assercoes;
- PHPStan: sem erros;
- PHPCS: sem violacoes;
- sintaxe PHP validada em PHP 8.3;
- revisao especializada GLPI 10/11 e WCAG/eMAG concluida.

## Homologacao manual restante

1. instalar o pacote em GLPI 10 e 11;
2. confirmar que Self-Service cria somente acompanhamento publico;
3. confirmar que tecnico com `SEEPRIVATE` cria itens publicos e privados;
4. tentar POST privado forjado e verificar negacao sem insercao;
5. aplicar modelo privado com e sem permissao;
6. trocar perfil durante a visualizacao de ticket fora do novo escopo;
7. validar radios com teclado e NVDA em tema normal, noturno, alto contraste e cores forcadas.