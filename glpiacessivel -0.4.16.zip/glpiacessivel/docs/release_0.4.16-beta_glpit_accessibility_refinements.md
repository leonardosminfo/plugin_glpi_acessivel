# GLPI Acessível 0.4.16-beta — refinamentos da homologação GLPIT

## Resultado

A versão consolida cinco correções de baixo risco encontradas na homologação real: refluxo em largura estreita, coerência do resumo de filtros, nomes acessíveis no FormCreator incorporado, explicação do catálogo vazio de tipos de solução e recuperação compreensível quando o VLibras não carrega.

## Alterações

- cartões de visibilidade de acompanhamento e tarefa aceitam a largura disponível em 305 e 320 pixels CSS, com quebra de texto e sem rolagem horizontal;
- o resumo da pesquisa frequente usa o mesmo `scope`, termo, status e agrupamento efetivamente enviados ao serviço; paginação não apaga `Status: Novo`;
- pesquisas salvas e critérios avançados continuam apresentando o resumo validado do mecanismo nativo;
- a ponte do FormCreator associa rótulo e ajuda ao controle nativo e ao combobox Select2 visível, inclusive após renderização dinâmica;
- a normalização do iframe é limitada ao FormCreator verificado, de mesma origem, e não modifica dados, regras, ação, método, CSRF ou submissão;
- a ausência de tipos de solução elegíveis é explicada sem bloquear o tipo nativo `Não informar`;
- a mensagem de falha do VLibras esclarece que o portal permanece utilizável e mantém recuperação limitada por reconexão e cooldown.

## Compatibilidade e segurança

O código mantém a mesma faixa GLPI 10.0–11.x e PHP 8.1 ou superior. Direitos, entidades, consultas, payloads ITIL e contratos nativos não são ampliados. A versão e o marcador de runtime foram renovados para que a atualização possa invalidar apenas o bytecode do plugin, sem reiniciar o PHP-FPM.

## Limite de conformidade

As correções atendem achados objetivos de WCAG 2.2 AA/eMAG/RGAA, mas ferramentas automáticas não constituem certificação. A publicação continua condicionada à matriz GLPI 10/11, teclado, leitor de tela e comparação com o estado nativo.

## Linha de base automatizada

- PHPUnit/PHP 8.1: 845 testes e 5.191 asserções;
- navegador: 83 verificações em 21 arquivos;
- PHPStan e PHPCS: sem erros;
- i18n: 2.657 mensagens em POT/PO/MO, com `msgfmt` e espelhos de assets validados.
