# Release 0.2.14-beta: contratos de valores da pesquisa de chamados

## Finalidade da versão

A `0.2.14-beta` é um pacote destinado à homologação externa da pesquisa acessível de chamados em instalações reais do GLPI 10 e 11. Ela fecha os bloqueadores técnicos conhecidos do construtor de filtros, mas ainda não representa aprovação para produção, certificação definitiva de acessibilidade ou validação de todas as combinações de perfis, entidades, plugins e volumes de dados.

A versão preserva a AST de pesquisa na versão 3, usa `SavedSearch` do GLPI como fonte de verdade e não requer migração de banco.

## Contrato compartilhado por campo e operador

O catálogo contextual passa a publicar um `value_contract` para cada combinação autorizada de campo e operador. Esse contrato informa somente o necessário à interface:

- tipo do valor: `none`, `text`, `integer`, `decimal`, `date`, `datetime`, `boolean`, `local_select` ou `remote_select`;
- obrigatoriedade e valor canônico quando o operador não recebe valor;
- limites e domínio permitido para valores locais;
- capacidades de apresentação, como seleção hierárquica, sem expor o descritor interno.

Tabela, `linkfield`, condições, rights, tokens IDOR e demais metadados sensíveis permanecem no servidor. Combinações não comprovadas no contrato contextual não são oferecidas para edição e falham de forma fechada.

## Semântica corrigida

- Título e Descrição são tratados explicitamente como texto livre.
- Status, Prioridade, Urgência e Impacto usam opções locais derivadas do domínio nativo disponível no GLPI.
- `empty` e `notempty` não criam um campo de valor e usam o valor canônico vazio.
- Inteiros, decimais, datas, data e hora e booleanos possuem validação e canonicalização estritas no servidor.
- Campos remotos aceitam somente IDs canônicos maiores que zero e alvos nativos homologados.
- Tipos desconhecidos ou de plugins não são convertidos silenciosamente em texto ou catálogo remoto.

## Autocomplete e autorização remota

O endpoint de valores exige POST autenticado, autorização para visualizar chamados, CSRF, lista fechada de parâmetros, `operator` e `context_revision`. A classificação do valor é recuperada do contrato atual do servidor; o navegador não escolhe tabela, modelo ou campo de vínculo.

Antes de emitir o token opaco do fluxo POST/Redirect/GET, cada ID remoto é consultado novamente pelo provider nativo no contexto atual. A revalidação considera ACL, perfil, entidade, recursividade, condições da Search Option e mecanismos IDOR disponíveis no GLPI. IDs ausentes, fora do contexto, zero ou não canônicos são recusados.

O limite de requisições da autorização final usa um canal separado do autocomplete. Assim, navegar normalmente pelo catálogo não consome o mesmo bucket usado para confirmar os IDs antes da submissão.

## Estados recuperáveis e acessibilidade

O combobox remoto associa nome, ajuda, erro, `aria-invalid` e `aria-errormessage` ao controle visível. O `input` oculto permanece apenas como valor canônico de submissão e não recebe ARIA nem foco.

A interface diferencia:

- `403`: sessão, autorização ou token de segurança não permitem continuar;
- `409`: o catálogo mudou para o perfil ou entidade atual;
- `422`: campo, operador, valor ou requisição deixou de ser válido;
- `429`: muitas consultas, respeitando `Retry-After`;
- `503`: provider nativo temporariamente indisponível;
- timeout, cancelamento, carregamento, página adicional e fim da lista.

Cada estado oferece mensagem e ação coerentes, como recarregar a página, revisar a condição ou tentar novamente. A paginação evita duplicação de requisições e mantém foco e opção ativa previsíveis para teclado e leitores de tela.

## SavedSearch e compatibilidade

Pesquisas existentes continuam sendo recuperadas diretamente do GLPI. Critérios compatíveis são normalizados pelo mesmo contrato usado na criação; critérios que não podem ser representados com fidelidade permanecem disponíveis pelo caminho “Abrir no GLPI”, sem aproximação silenciosa nem persistência paralela.

Compatibilidade declarada:

- GLPI: `>=10.0 <12.0`;
- PHP: `>=8.1`;
- navegadores modernos com JavaScript, `fetch`, `AbortController` e APIs ARIA usadas pelo combobox.

## Homologação externa obrigatória

Antes de promover esta beta para produção, repetir em GLPI 10 e GLPI 11, com dados sintéticos e os perfis reais pretendidos:

1. Título e Descrição com `contains`, `notcontains`, `equals`, `notequals`, `empty` e `notempty`, quando disponíveis.
2. Status, Prioridade, Urgência e Impacto com os rótulos e valores nativos da instalação.
3. Categoria, Entidade, Localização, usuários e grupos nos escopos simples e recursivos.
4. Criação, recuperação, execução e edição de pesquisas privadas, públicas e padrão autorizadas.
5. Troca de perfil e entidade durante a jornada, incluindo revisão contextual obsoleta.
6. Paginação, consulta vazia, pesquisa digitada, timeout, repetição e respostas `403`, `409`, `422`, `429` e `503`.
7. Teclado completo, NVDA e ao menos uma segunda tecnologia assistiva adotada pela organização.
8. Reflow a 320 px, alto contraste e `forced-colors`.

Interromper a homologação se um ID fora do contexto for aceito, se houver campo sem contrato editável, perda de foco, erro não anunciado, divergência da pesquisa nativa ou indisponibilidade relevante em uma jornada normal.

## Gate automatizado local

```powershell
composer qa
npm run test:search-ui
```

A linha de base integrada contém 315 testes PHPUnit e 1.595 asserções. O teste `test:search-ui` exercita em navegador o contrato de requisição, foco visível, paginação, timeout, repetição e respostas HTTP recuperáveis.

## Build e verificação do pacote

```powershell
.\tools\build-release.ps1 `
  -Output .release_0.2.14-beta_ticket_search_value_contracts `
  -Profile marketplace `
  -RequireMsgfmt

.\tools\verify-release.ps1 `
  -Package .release_0.2.14-beta_ticket_search_value_contracts\glpiacessivel.zip `
  -ExpectedVersion 0.2.14-beta `
  -PublicProfile
```

O gate deve confirmar raiz única `glpiacessivel/`, metadados `0.2.14-beta`, ausência de caminhos de desenvolvimento e assets offline de voz, licenças obrigatórias, manifesto, `SHA256SUMS` e hash SHA-256 do ZIP.

## Rollback

Se a homologação encontrar um bloqueador:

1. interromper o canário e registrar versão GLPI, perfil, entidade, navegador e tecnologia assistiva;
2. desativar o browse automático de valores remotos quando essa mitigação estiver disponível;
3. manter a pesquisa digitada e o link “Abrir no GLPI” como caminhos conservadores;
4. restaurar o pacote homologado anterior conforme a política local;
5. limpar cache do GLPI e do navegador após a troca de pacote.

Não há rollback de banco específico para esta versão.
