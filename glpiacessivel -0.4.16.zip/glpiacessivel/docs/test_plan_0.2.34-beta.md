# Plano de testes da versão 0.2.34-beta

## Gate de liberação

Produção somente com todos os P0 e P1 aprovados em GLPI 10 e GLPI 11. Qualquer vazamento de ACL, contexto não persistido, divergência de IDs no escopo pessoal, mutação sem CSRF, 5xx/504 causado pelo plugin ou bloqueio de teclado/leitor de tela é **NO-GO**.

## 1. Perfil, entidade e sessão

| ID | Cenário | Resultado esperado |
|---|---|---|
| C01 | trocar somente o perfil e recarregar | segunda requisição confirma o perfil persistido; mensagem aparece uma vez |
| C02 | trocar somente a entidade e recarregar | entidade e recursividade persistem no GLPI e no plugin |
| C03 | trocar perfil para um contexto em que a entidade antiga não existe | GLPI seleciona uma entidade permitida e o plugin orienta a revisão |
| C04 | usar Voltar/Avançar e atualizar após a troca | a operação não se repete; parâmetros `force_*` e marcador não permanecem na URL final |
| C05 | reutilizar, alterar ou expirar o marcador | confirmação recusada sem mudar novamente o contexto |
| C06 | retorno absoluto, externo, com controles ou `..` | retorno substituído pela página inicial segura do plugin |
| C07 | duas abas e troca pelo GLPI nativo | a nova requisição usa somente o contexto atual; tokens antigos falham fechados |

## 2. Escopo “Meus chamados”

Preparar chamados em que o mesmo usuário seja apenas requisitante, apenas técnico, apenas observador e não participante.

| ID | Cenário | Resultado esperado |
|---|---|---|
| M01 | `scope=mine` no plugin e busca equivalente no GLPI | conjuntos ordenados de IDs idênticos |
| M02 | IDs das Search Options alterados na massa de teste | resultado permanece idêntico |
| M03 | idioma pt-BR e en-GB | descoberta independe do rótulo apresentado |
| M04 | opção duplicada, ausente ou sem relação `glpi_tickets_users` | escopo falha fechado e não executa consulta ampliada |
| M05 | perfil/entidade recursiva e não recursiva | IDs respeitam exatamente a Search API do contexto atual |
| M06 | cockpit “Meus chamados abertos” e drill-down | total e lista correspondem ao mesmo conjunto canônico |
| M07 | pesquisa salva pessoal | definição reaberta conserva os três papéis e a ACL vigente |

## 3. Internacionalização e acessibilidade

| ID | Cenário | Resultado esperado |
|---|---|---|
| L01 | lista assíncrona em pt-BR | títulos, paginação, erro e região viva com acentuação correta |
| L02 | seletores remotos em pt-BR | ajuda, resultados, erros, remoção e validação com pronúncia natural |
| L03 | repetir L01/L02 em en-GB | nenhuma frase em português nem chave técnica visível/anunciada |
| L04 | remover/bloquear o catálogo JavaScript | enhancement não inicia; controles e fallback SSR continuam utilizáveis e sem `aria-busy` falso |
| L05 | teclado e NVDA/JAWS | setas, Enter, Escape, Tab, foco e anúncios sem duplicação |
| L06 | 320 CSS px, zoom 200%/400%, forced colors | nenhuma ação perdida nem rolagem horizontal indevida |
| L07 | Axe pai e estados abertos/erro | zero violação critical/serious; `incomplete` revisado manualmente |

## 4. Segurança, carga e compatibilidade

- executar chamadas sem sessão, sem CSRF, origem cruzada, método e `Content-Type` incorretos;
- alternar perfil/entidade durante lista, autocomplete e paginação em voo;
- validar GLPI 10 institucional e GLPI 11 local com os mesmos conjuntos de IDs;
- medir base de 10 mil e 100 mil chamados e rampa concorrente 1→5→10 usuários;
- alvo: shell P95 ≤ 2 s, resultado ou fallback controlado ≤ 6 s, zero 5xx/504 do plugin;
- cockpit mantém cinco consultas agregadas fixas e nenhuma consulta por chamado;
- confirmar ausência de nova tabela e de persistência de termos, IDs autorizados ou respostas personalizadas no navegador.

## 5. Automação e artefato

```powershell
$env:XDEBUG_MODE='off'
$env:XDEBUG_CONFIG='log='
C:\wamp64\bin\php\php8.3.14\php.exe vendor/bin/phpunit
C:\wamp64\bin\php\php8.3.14\php.exe vendor/bin/phpstan analyse --memory-limit=512M
C:\wamp64\bin\php\php8.3.14\php.exe vendor/bin/phpcs -n
npm run test:browser
powershell.exe -ExecutionPolicy Bypass -File tools\i18n-audit.ps1 -RequireMsgfmt
```

O ZIP aprovado deve declarar `0.2.34-beta` em `setup.php`, XML, CFF, README e manifesto; conter PO/POT/MO, os dois pares de assets idênticos, esta nota, este plano e as documentações tecnológica e funcional; e passar `verify-release.ps1` com SHA-256 recalculado.

