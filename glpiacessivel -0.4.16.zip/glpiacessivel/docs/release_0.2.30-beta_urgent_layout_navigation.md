# GLPI Acessível 0.2.30-beta: correção urgente de layout e navegação

## Resultado para o usuário

A `0.2.30-beta` corrige regressões observadas na homologação da versão anterior sem reverter os controles de segurança, a separação de diagnósticos ou a autorização nativa do GLPI.

- o formulário aberto pelo catálogo continua dentro do portal e mantém o menu acessível;
- a área incorporada deixa de crescer até milhares de pixels e passa a ter altura limitada com rolagem própria;
- páginas Formcreator com formulários auxiliares deixam de produzir uma falsa mensagem de falha quando o formulário solicitado está presente e autorizado;
- o cockpit recupera a diferenciação visual dos cinco indicadores e mantém os metadados disponíveis sob `Detalhes do indicador`;
- perfis sem direito de leitura recebem uma explicação amigável em Chamados e Cockpit, sem redirecionamento inesperado para outro módulo.

## Chamados e proteção contra sobrecarga

Quando o modo assíncrono está habilitado, uma falha ao preparar o estado contextual não aciona mais a listagem síncrona pesada. O portal conserva o shell, apresenta o estado de indisponibilidade, oferece nova tentativa e mantém o link para a listagem oficial do GLPI.

Essa proteção reduz o risco de uma falha de preparação transformar-se em consulta longa ou `504`. Ela não substitui os ensaios de carga com a base real: catálogo de pesquisas, grupos, Search API, PHP-FPM e banco de dados ainda precisam ser medidos sob concorrência representativa.

## Segurança preservada

- nenhuma ACL foi ampliada;
- o perfil, a entidade, a recursividade, os grupos e a sessão continuam sendo definidos pelo GLPI;
- o formulário real é selecionado pelo campo `plugin_formcreator_forms_id` esperado;
- CSRF, origem, URL resolvida no servidor e submissão nativa permanecem inalterados;
- o cockpit conserva as cinco consultas canônicas e nunca converte indisponibilidade em zero;
- a versão não cria tabela nem cópia local de formulários, pesquisas, chamados ou indicadores.

## Homologação obrigatória

1. Abrir formulário simples e complexo pelo catálogo; confirmar menu, título do iframe, campos, condições, anexos, erros e envio único.
2. Testar formulários com a interface GLPI completa e com apresentação mínima homologada.
3. Validar 320 CSS px, zoom de 200% e 400%, teclado, NVDA e JAWS.
4. Comparar Chamados no plugin e no GLPI nativo com perfil autorizado e não autorizado.
5. Simular falha da preparação assíncrona, timeout e sessão/contexto alterado.
6. Comparar os cinco KPIs e seus detalhamentos com consultas equivalentes no GLPI.
7. Medir tempo de shell, endpoint, consultas SQL, PHP-FPM e banco sob volume e concorrência reais.

## Geração e verificação

```powershell
.\tools\build-release.ps1 -Output .release_0.2.30-beta_urgent_layout_navigation -Profile marketplace -RequireMsgfmt
.\tools\verify-release.ps1 -Package .release_0.2.30-beta_urgent_layout_navigation\glpiacessivel.zip -ExpectedVersion 0.2.30-beta -PublicProfile
```

A versão permanece beta e não representa certificação definitiva de acessibilidade nem aprovação automática no Marketplace GLPI.
