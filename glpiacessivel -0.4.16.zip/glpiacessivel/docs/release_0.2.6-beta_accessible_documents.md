# 0.2.6-beta - documentos e anexos acessiveis

## Objetivo

Esta versao torna os documentos vinculados a chamados, acompanhamentos e tarefas localizaveis, compreensiveis e operaveis por teclado e leitor de tela, sem substituir a autorizacao nativa do GLPI.

## Comportamento

- documentos do chamado aparecem na secao `Documentos e anexos`;
- documentos de acompanhamento e tarefa aparecem junto ao evento correspondente da timeline;
- cada link informa nome, formato e tamanho em seu nome acessivel;
- formato, tamanho, origem, data de atualizacao e visibilidade sao apresentados como metadados textuais;
- nomes longos quebram linha sem provocar rolagem horizontal desnecessaria;
- a selecao de anexos em acompanhamento e tarefa anuncia a quantidade e lista os arquivos escolhidos;
- o usuario pode limpar a selecao por um botao operavel por teclado.

## Seguranca e ACL

Antes de expor um link, o plugin valida:

1. leitura do chamado no perfil e na entidade ativos;
2. leitura do acompanhamento ou tarefa que originou o documento;
3. direito `SEEPRIVATE` quando o item pai for privado;
4. relacionamento exato em `Document_Item`;
5. autorizacao nativa `Document::canViewFile()` no contexto do item pai.

O download e delegado a `front/document.send.php`, que revalida o acesso no GLPI. Caminho fisico, hash e detalhes internos de armazenamento nao sao enviados ao navegador.

## Sucesso parcial

Se um acompanhamento ou uma tarefa for criado, mas o vinculo final do anexo nao puder ser confirmado, a interface:

- informa que a acao principal foi registrada;
- orienta a nao reenviar a acao;
- retorna para a timeline;
- registra somente identificadores, codigos e estado da operacao na auditoria, sem gravar nomes de arquivos.

## Evidencias automatizadas

- PHPUnit: 128 testes e 596 assercoes;
- PHPStan: sem erros;
- PHPCS: sem erros nos arquivos PHP de dominio, controlador e teste alterados;
- gettext: 432 mensagens consistentes, validadas e compiladas com `msgfmt`;
- pacote validado quanto a raiz, versao, documentos obrigatorios, perfil publico e SHA-256.

## Homologacao assistiva obrigatoria

Antes de ampliar o piloto, repetir em GLPI 10 e 11:

1. Self-Service com documento publico;
2. tecnico com documento publico e privado;
3. usuario sem `SEEPRIVATE` tentando acessar URL de documento privado;
4. documento em chamado, acompanhamento e tarefa;
5. nome longo, arquivo sem extensao e tamanho indisponivel;
6. download por teclado e leitura com NVDA;
7. upload valido, extensao bloqueada, excesso de tamanho e falha de vinculacao;
8. troca de perfil e entidade seguida de tentativa de reutilizar a URL anterior.

O resultado esperado para acesso indevido e bloqueio nativo sem exposicao de metadados ou conteudo.
