# Plano de testes da versão 0.2.39-beta

## Objetivo e regra de decisão

Comprovar, no mesmo artefato para GLPI 10 e GLPI 11, que a ausência autorizada de grupos produz vazio e zero exatos, enquanto qualquer contexto não comprovado permanece indisponível. O plano também deve provar que a correção não amplia visibilidade, não bloqueia escopos independentes e não executa consultas de grupo desnecessárias.

GO somente quando todos os casos P0 forem aprovados nas duas versões, com o mesmo SHA-256, zero exposição fora da ACL e sem regressão dos outros quatro indicadores. Contexto incerto apresentado como zero, `group_id` externo consultado ou divergência entre lista síncrona e assíncrona são NO-GO.

## Gate 1 — artefato, versão e pré-requisitos

1. Gerar um único pacote somente após a revisão do código e registrar o SHA-256.
2. Instalar o mesmo pacote em uma versão homologada do GLPI 10 e outra do GLPI 11.
3. Confirmar `0.2.39-beta` em `setup.php`, `glpiacessivel.xml`, `CITATION.cff` e na tela de plugins.
4. Limpar cache do GLPI e fazer recarga completa do navegador.
5. Preparar dados inteiramente sintéticos em duas entidades, uma recursiva e outra não recursiva.

Perfis mínimos: usuário Self-Service sem grupos, usuário com um grupo direto, usuário com mais de um grupo, técnico/Hotliner e Super-Admin. Criar chamados abertos atribuídos a cada grupo e chamados fora do conjunto permitido.

## Gate 2 — grupos oficiais resolvidos

Executar em GLPI 10 com associações diretas e em GLPI 11 com associações diretas e, quando configurado, expansão recursiva:

1. abrir a lista com `scope=group` sem `group_id`;
2. conferir que somente chamados atribuídos a pelo menos um grupo oficial atual são retornados;
3. repetir com cada `group_id` oferecido pela interface;
4. alternar ordenação, paginação, busca rápida, filtros e `group_by=group`;
5. comparar total, IDs e ordem com a Search API nativa no mesmo contexto.

Aceite: IDs positivos são normalizados sem duplicação; nenhum grupo de outro perfil ou entidade é incluído; o resultado continua exato.

## Gate 3 — ausência comprovada de grupos

Com um usuário realmente sem grupos no perfil e na entidade atuais:

1. abrir a lista síncrona com `scope=group`;
2. repetir pela lista assíncrona, inclusive com paginação solicitada maior que a primeira;
3. confirmar total zero, página 1 de 1, itens vazios, backend `scope_empty` e razão `group_scope_without_current_groups` no diagnóstico autorizado;
4. confirmar a mensagem “Você não pertence a nenhum grupo no perfil e na entidade atuais. Por isso, não há chamados de grupos responsáveis para exibir.”;
5. verificar que a mensagem está em região de status, não recebe foco forçado e não é anunciada em duplicidade;
6. abrir o cockpit e confirmar `group_open` com valor e contagem zero, `available=true`, completude `exact` e backend `scope_empty`;
7. confirmar que os outros quatro indicadores continuam disponíveis conforme suas próprias consultas.

Instrumentação de aceite: zero chamadas a `Search::getDatas` para a lista e quatro chamadas para o cockpit completo. A chave legada `glpigroups_assign`, ainda que populada em uma simulação de regressão, não pode substituir o conjunto oficial vazio.

## Gate 4 — contexto ausente, malformado ou cuja carga falhou

Cobrir por testes unitários/integração controlada, sem adulterar uma sessão de produção:

- chave `glpigroups` ausente;
- `glpigroups` com valor que não seja array;
- array com entrada que não identifique um grupo positivo;
- chave vazia residual combinada com marcador explícito de falha de `Session::loadGroups()`.

Para cada caso, validar a lista e o cockpit. Aceite: razão `group_scope_context_unavailable`; lista sem consulta pesada; `group_open` com `available=false`, completude `unknown` e sem valor zero inferido; os outros quatro indicadores do cockpit continuam independentes. O estado visual permanece **Resultado indisponível**, nunca a mensagem de ausência comprovada.

## Gate 5 — `group_id` explícito e separação de escopos

1. usar `scope=group&group_id=<grupo atual>` e confirmar a consulta autorizada;
2. manipular a URL com ID positivo de grupo fora do conjunto atual;
3. confirmar vazio exato, backend `scope_empty`, razão `group_scope_group_not_in_current_groups` e zero chamadas a `Search::getDatas` no segundo caso;
4. executar `scope=all&group_by=group` e `scope=mine&group_by=group` com conjunto oficial vazio;
5. confirmar que `group_by` não ativa o atalho do escopo de grupos e que os dois escopos continuam consultando conforme seus contratos e ACLs.

Aceite: nenhum ID externo amplia visibilidade e nenhuma opção de agrupamento altera autorização.

## Gate 6 — troca de contexto e concorrência

1. alternar de um perfil/entidade com grupos para outro sem grupos e repetir o caminho inverso;
2. repetir com recursividade ativada e desativada quando o perfil permitir;
3. manter lista e cockpit abertos em uma segunda aba durante a troca;
4. solicitar novamente um resultado assíncrono emitido antes da troca.

Aceite: a carga nativa de grupos é refeita no contexto vigente; respostas ligadas à revisão anterior são rejeitadas ou recarregadas; nenhum total anterior reaparece como atual.

## Gate 7 — regressão, acessibilidade e automação

Executar os contratos focados de repositório, Search API, snapshot de contexto, lista assíncrona, mensagem acessível e i18n, além da suíte integral:

```powershell
composer qa
pnpm run test:browser
.\tools\i18n-audit.ps1 -RequireMsgfmt
```

Executar manualmente teclado completo, NVDA com Firefox/Chrome, JAWS com Edge, zoom de 200% e 400%, viewport de 320 pixels CSS, alto contraste e `forced-colors`. Confirmar que vazio e indisponibilidade têm texto inequívoco e não dependem apenas de cor.

Depois de todos os gates anteriores e da autorização de empacotamento, gerar e verificar:

```powershell
.\tools\build-release.ps1 -Output .release_0.2.39-beta_group_scope_tristate -Profile marketplace -RequireMsgfmt
.\tools\verify-release.ps1 -Package .release_0.2.39-beta_group_scope_tristate\glpiacessivel.zip -ExpectedVersion 0.2.39-beta -PublicProfile
```

O registro final deve incluir versões exatas de GLPI/PHP/banco/navegador/tecnologia assistiva, perfil, entidade, recursividade, SHA-256, totais esperados e observados, contagem instrumentada de chamadas e evidência anonimizada de cada gate.
