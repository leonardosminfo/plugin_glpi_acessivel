# GLPI Acessível 0.4.8-beta — governança da auditoria

## Resultado entregue

A trilha persistente deixou de ser uma consequência implícita das páginas do
plugin e passou a ter política, direitos e consulta próprios. A implementação é
comum ao GLPI 10 e 11 e não autoriza por nome ou identificador de perfil.

## Comportamento

- `critical` é o padrão seguro de novas instalações: grava mudanças, segurança,
  configuração e revelações autorizadas, sem leituras rotineiras;
- `full` também registra eventos operacionais e é preservado quando uma
  instalação anterior é atualizada;
- `disabled` exige a constante local
  `GLPIACESSIVEL_ALLOW_AUDIT_DISABLED=true` e confirmação na interface;
- a rotina de retenção continua em qualquer modo e não roda na requisição do
  usuário;
- quando a proteção de dados pessoais está desligada, não é criada linha no
  ledger nem evento `pii.reveal`;
- quando a proteção está ligada, uma revelação só ocorre se as duas gravações
  obrigatórias puderem ser concluídas atomicamente.

## Autorização nativa

Quatro direitos independentes são registrados no perfil do GLPI:

1. consultar metadados da auditoria;
2. consultar registros sensíveis permitidos;
3. exportar o subconjunto autorizado;
4. consultar eventos globais.

Cada linha ainda exige entidade ativa e, quando vinculada a chamado, a leitura
nativa do próprio chamado. Direitos de atualizar chamado, configurar o plugin
ou revelar PII não concedem acesso à auditoria.

## Desempenho e privacidade

A consulta usa período máximo de 31 dias, página de 25 registros, limite máximo
de 100 e cursor opaco vinculado a usuário, perfil e entidade. Não usa busca
livre em `payload`, `COUNT(*)` nem `OFFSET`. A exportação síncrona é
deliberadamente limitada a 100 linhas e duas solicitações por hora por sessão.

O sanitizador elimina texto livre e chaves associadas a conteúdo, pesquisa,
contatos, tokens, cookies, SQL, exceções e URLs. O IP só é mantido em eventos de
segurança classificados. O payload tem limites de profundidade, quantidade de
campos e tamanho.

## Implantação

Ao atualizar, acesse a página de plugins do GLPI para executar a migração
`V0002_audit_governance_rights` e a normalização idempotente
`V0003_audit_schema_normalization`. Em seguida, um administrador de perfis deve
revisar a aba “Auditoria do GLPI Acessível” e conceder apenas os direitos
necessários. A ausência de menu para um perfil sem `audit_read` é o resultado
esperado.

Esta beta ainda requer os testes assistivos e de carga descritos no plano da
versão antes de uso em produção.
