# Release 0.2.18-beta: icone local no gerenciador de plugins

## Objetivo

Substituir as iniciais `GA`, geradas como fallback pelo GLPI, pela identidade visual do GLPI Acessivel no cartao do plugin instalado.

## Alteracoes

- adiciona `logo.png` na raiz do plugin, no nome que o gerenciador de plugins do GLPI reconhece;
- reutiliza o simbolo existente do sistema em uma imagem PNG quadrada de 256 por 256 pixels;
- reduz a imagem para aproximadamente 44 KB, adequada ao cartao de administracao;
- mantem `glpiacessivel.png` em alta resolucao para a documentacao;
- aponta o catalogo `glpiacessivel.xml` para `logo.png`;
- inclui o novo arquivo obrigatoriamente no ZIP de distribuicao;
- adiciona regressao automatizada para formato, dimensoes, tamanho e empacotamento do icone.

## Compatibilidade

A mudanca e apenas de apresentacao e nao altera banco de dados, permissoes, rotas ou contratos funcionais. O arquivo local e seguro para GLPI 10 e 11; no GLPI 11 ele e preferido pelo Marketplace quando existe na raiz do plugin.

## Validacao depois da instalacao

1. instalar ou atualizar o plugin com o ZIP desta versao;
2. limpar o cache do GLPI se o cartao permanecer aberto com o recurso antigo;
3. acessar **Configuracao > Plugins** ou **Marketplace > Instalados**;
4. confirmar que o simbolo de acessibilidade aparece no lugar das letras `GA`;
5. confirmar que ativacao, desativacao, configuracao e remocao continuam disponiveis de acordo com o perfil administrativo.

## Artefatos permanentes

O pacote continua incluindo `docs/solucao_tecnologica.md` e `docs/documentacao_funcional_e_organizacao.md`, conforme a politica de documentacao de cada nova versao.

## Geracao do pacote

```powershell
.\tools\build-release.ps1 -Output .release_0.2.18-beta_local_plugin_logo -Profile marketplace -RequireMsgfmt
.\tools\verify-release.ps1 -Package .release_0.2.18-beta_local_plugin_logo\glpiacessivel.zip -ExpectedVersion 0.2.18-beta -PublicProfile
```
