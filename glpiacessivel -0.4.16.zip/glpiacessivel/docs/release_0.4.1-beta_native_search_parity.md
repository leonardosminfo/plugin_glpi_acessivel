# GLPI Acessível 0.4.1-beta — paridade nativa da pesquisa limitada

## Objetivo

Corrigir a incompatibilidade que fazia pesquisas válidas no GLPI 10 ou 11 falharem no portal acessível e, ao mesmo tempo, impedir que a lista volte a materializar uma consulta ilimitada capaz de provocar `Gateway Timeout`.

## Contrato implementado

O plugin entrega os critérios, metacritérios, ordenação, perfil, entidade, recursividade e ACL ao mecanismo `Search` da versão instalada. Depois da construção nativa, preserva byte a byte:

- `SELECT`;
- `FROM`;
- `WHERE`;
- `GROUPBY`;
- `HAVING`;
- `ORDER`.

No planejador, somente o fragmento `LIMIT` é descartado e substituído por `offset, page_size + 1`. A linha adicional é sentinela de continuidade; no máximo 50 chamados são hidratados. A lista não chama `Search::getDatas()` e não depende de uma contagem global. Na execução, um comentário de controle no MySQL ou um invólucro `SET STATEMENT` no MariaDB acrescenta o orçamento server-side sem modificar os fragmentos semânticos produzidos pelo GLPI.

Esse desenho mantém a semântica nativa de aliases `ITEM_*` e `META_*`, agregações, campos relacionados, pesquisas salvas, busca avançada e Search Options registradas por plugins. Uma forma sem o alias canônico `id`, com fragmentos ausentes, instruções múltiplas ou versão não reconhecida falha fechada.

## Limites operacionais

- página máxima: 50 itens;
- leitura máxima por janela: 51 IDs;
- deslocamento máximo: 10.000;
- orçamento SQL: 3 segundos por instrução;
- reserva mínima de capacidade: 8 segundos;
- total: `null` com estado explícito quando ainda não conhecido;
- alternativa de recuperação: lista nativa do GLPI.

No MySQL, o executor usa `MAX_EXECUTION_TIME(3000)`, ajusta `group_concat_max_len` apenas na sessão atual e restaura o valor anterior em `finally`. No MariaDB, usa `SET STATEMENT max_statement_time=3.000, group_concat_max_len=8194304 FOR ...`. Falha de detecção, aplicação, execução ou restauração encerra a operação sem ampliar a consulta.

## Interface e acessibilidade

Resultados SSR e assíncronos declaram o contrato V2. O estado do total faz parte do único anúncio de resultados, notas visuais duplicadas ficam fora da árvore acessível e grupos informam quantos itens existem nesta página. Em respostas `429` ou `503`, o cliente interpreta `Retry-After`, desabilita a nova tentativa e apresenta a contagem regressiva sem iniciar consultas concorrentes.

## Compatibilidade e segurança

- GLPI 10: usa o construtor SQL nativo da classe `Search` da série 10;
- GLPI 11: usa a fachada `Search`, que delega ao `Glpi\Search\Provider\SQLProvider`;
- banco: MySQL `>= 5.7.8` ou MariaDB `>= 10.2`, requisito verificado durante a instalação;
- nenhuma ACL é reconstruída no plugin;
- somente IDs devolvidos pela consulta nativa limitada atravessam o gateway para hidratação e nova autorização por objeto;
- não há alteração de esquema nesta versão.

## Limitações e gates antes de produção

Um `LIMIT` impede a materialização de toda a lista no PHP, mas não torna baratos joins, agrupamentos ou ordenações. A versão deve ser homologada com volume, perfis, entidades, plugins, versões de GLPI e banco equivalentes ao ambiente real. A liberação antecipada da sessão PHP não foi adotada: não há contrato seguro comprovado para reabrir e revalidar o contexto em todas as versões suportadas. Em múltiplos nós, a implantação precisa fornecer um backend de capacidade compartilhado.

O pacote beta não constitui certificação WCAG/eMAG nem aprovação do Marketplace.
