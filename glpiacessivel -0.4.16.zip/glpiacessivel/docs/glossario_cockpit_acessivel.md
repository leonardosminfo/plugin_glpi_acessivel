# Glossário funcional e acessível do cockpit

Este glossário fixa a linguagem apresentada e anunciada pelo cockpit. Os rótulos não substituem a definição técnica dos indicadores nem autorizam acesso adicional.

## Terminologia obrigatória

| Termo | Uso no cockpit | Evitar |
|---|---|---|
| Chamado | Registro de atendimento do GLPI | Ticket, item ou registro quando significarem chamado |
| Técnico responsável | Pessoa atribuída ao atendimento | Técnico atribuído, dono ou atendente sem contexto |
| Grupo responsável | Grupo atribuído ao atendimento | Grupo aberto ou meu grupo |
| Atualização | Momento em que o indicador foi calculado | Frescor sem explicação ou data implícita |
| Resultado indisponível | O cálculo completo e autorizado não pôde ser produzido | Zero, vazio, traço ou erro genérico |
| Escopo | Conjunto de chamados permitido pelo perfil, entidade e recursividade ativos | Todos, quando não significar todos os permitidos |
| Período | Intervalo temporal abrangido pelo indicador | Hoje sem informar data e fuso horário |

## Indicadores

O cockpit apresenta no máximo cinco indicadores:

1. **Chamados abertos:** chamados novos, atribuídos, planejados ou pendentes.
2. **Chamados pendentes:** chamados que aguardam informação, decisão ou evento externo.
3. **Chamados solucionados hoje:** chamados solucionados na data e no fuso horário informados.
4. **Meus chamados abertos:** chamados em que o usuário participa como requerente, técnico responsável ou observador.
5. **Chamados dos grupos responsáveis:** chamados atribuídos a pelo menos um grupo responsável do qual o usuário faz parte.

Cada indicador deve expor rótulo, valor ou estado indisponível, período, escopo, atualização, fuso horário e link para a consulta relacionada.

## Regras de apresentação

- `completeness=unknown`, `available=false`, valor nulo, inválido ou negativo resultam em **Resultado indisponível**.
- Zero somente é apresentado quando o backend declara resultado disponível e completo.
- O link de cada indicador usa uma rota de mesma origem; URL ausente ou inválida recua para a listagem autorizada correspondente.
- Cor, gráfico ou ícone nunca são a única forma de identificar valor, estado ou significado.
- Atualização e fuso horário são texto visível. Ausência é informada explicitamente.
- Os rótulos e as descrições pertencem ao template e passam pelo gateway Gettext; metadados fornecidos pelo backend não substituem essa linguagem.
