# Plano de testes da versão 0.2.38-beta

## Gate 1 — artefato e cache

1. Gerar um único ZIP e registrar o SHA-256.
2. Instalar o mesmo ZIP em GLPI 10 e GLPI 11.
3. Limpar cache do GLPI e fazer recarga completa do navegador.
4. Confirmar `0.2.38-beta` e o hash do `glpiacessivel.js` servido em ambos.

Aceite: versão e arquivos idênticos; nenhum ativo antigo servido.

## Gate 2 — confirmações críticas

Cobrir, quando a ACL permitir:

- alteração de status;
- inclusão de solução;
- aprovação e recusa de solução;
- satisfação do requisitante;
- aprovação, rejeição e exclusão de roteiro.

Para cada ação:

1. abrir pelo acionador correto;
2. confirmar um único `alertdialog`;
3. validar foco inicial em **Cancelar**, ciclo `Tab`/`Shift+Tab`, `Escape` e retorno ao acionador;
4. provar zero POST e zero mutação ao cancelar;
5. confirmar exatamente um POST e uma mutação ao prosseguir;
6. verificar botão, ação, ticket/roteiro e token corretos;
7. repetir token, trocar ação ou remover CSRF e confirmar bloqueio sem mutação.

Aceite: nenhum bloqueio em fluxo válido e nenhum bypass em fluxo inválido.

## Gate 3 — GLPI 10 e Formcreator 2.13.10

Criar massa sintética, sem dados pessoais reais:

- formulário simples com texto, área de texto e campo obrigatório;
- formulário complexo com seleção, condição de exibição, autocomplete e anexo;
- um formulário autorizado e outro restrito a entidade/perfil;
- target de ticket com categoria, entidade e atores controlados.

Validar catálogo, busca, paginação, ACL, abertura incorporada, alternativa de página completa, condições, erros, anexos, submissão única e ticket/target resultante. Divergência de fingerprint deve preservar a interface completa.

## Gate 4 — GLPI 11

Repetir confirmações críticas e os smokes de regressão de busca avançada, pesquisa salva, criação de chamado e Service Catalog. O ciclo POST/Redirect/GET deve preservar token e foco sem classificar `RedirectException` como falha.

## Gate 5 — perfis, entidades e duas abas

Executar com Self-Service/requisitante, técnico/Hotliner, gestor e Super-Admin, em entidade recursiva e não recursiva. Trocar perfil ou entidade em outra aba durante lista, detalhe, formulário e confirmação pendente; o servidor deve rejeitar o contexto antigo sem revelar conteúdo.

## Gate 6 — acessibilidade e apresentação

- teclado completo;
- NVDA com Firefox e Chrome;
- JAWS com Edge;
- viewport de 320 pixels CSS, zoom de 200% e 400%;
- alto contraste/`forced-colors`;
- Axe sem violações críticas ou sérias no DOM controlado pelo plugin.

O diálogo deve ser anunciado uma vez, incluir título, descrição e consequência, e nunca emitir “Processando” antes da confirmação.

## Gate 7 — automação e pacote

Executar:

```powershell
composer qa
pnpm run test:browser
.\tools\i18n-audit.ps1 -RequireMsgfmt
.\tools\build-release.ps1 -Output .release_0.2.38-beta_critical_confirmations_formcreator -Profile marketplace -RequireMsgfmt
.\tools\verify-release.ps1 -Package .release_0.2.38-beta_critical_confirmations_formcreator\glpiacessivel.zip -ExpectedVersion 0.2.38-beta -PublicProfile
```

## Decisão

GO somente com todos os P0/P1 aprovados nas duas versões usando o mesmo SHA, zero mutação duplicada, zero exposição por ACL e fluxos Formcreator simples e complexo concluídos. Teste assistivo manual pendente ou falha de condição/anexo/target mantém a decisão em NO-GO ou BLOCKED, conforme a evidência.
