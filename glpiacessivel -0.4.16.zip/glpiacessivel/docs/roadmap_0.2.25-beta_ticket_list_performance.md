# Roadmap 0.2.25-beta - desempenho e escalabilidade dos chamados

Este roteiro tecnico integra o plano mestre `roadmap_0.2.25-beta_correction_plan.md`.

## Estado de aprovacao

Aprovado com ressalvas obrigatorias em 13 de agosto de 2026. Todos os contratos P0 deste documento devem ser incorporados e testaveis antes do inicio da codificacao correspondente.

## Estado e decisao de escopo

- Versao-alvo: `0.2.25-beta`.
- Prioridade: P0 para a lista de chamados e para seletores de grande cardinalidade usados nos fluxos essenciais.
- Origem: teste manual da `0.2.24-beta` em homologacao em 13 de agosto de 2026.
- Revisao: planejamento aprovado com ressalvas pelos pareceres de integracao GLPI, infraestrutura/banco e acessibilidade/QA.
- Gate: a proxima versao nao deve ser liberada para piloto enquanto a lista puder terminar em HTTP 504 ou um seletor com milhares de opcoes tornar criacao, atribuicao, observadores ou filtros impraticaveis para usuarios de tecnologia assistiva.

## Evidencia e limite do diagnostico

Na homologacao, a lista nativa de chamados do GLPI concluiu o carregamento em aproximadamente 31 segundos. A rota equivalente do Portal Acessivel excedeu o tempo do gateway e retornou HTTP 504 tanto no escopo `Todos` quanto em `Meus chamados`.

O 504 e emitido pela infraestrutura. A hipotese de trabalho e que servidor/banco ja possuem custo elevado e o processamento adicional do plugin faz a requisicao ultrapassar o menor timeout da cadeia. Isso ainda deve ser comprovado comparando GLPI nativo e portal, de forma intercalada, com exatamente o mesmo usuario, perfil, entidade, recursividade, criterios, colunas, ordenacao e tamanho de pagina.

Tambem foi observado que a abertura de chamado cria mais de cinco mil elementos no DOM e carrega milhares de categorias e localizacoes de uma vez. Esse ponto nao causou o 504 da lista, mas constitui bloqueador proprio de desempenho e acessibilidade.

Aumentar apenas o timeout do proxy, servidor web ou PHP nao e considerado correcao.

## Hipoteses tecnicas a comprovar

1. O catalogo completo de campos, metacampos, operadores e colunas e reconstruido antes de a primeira pagina poder ser apresentada.
2. `Search::getDatas()` ja possui custo elevado no ambiente homologado.
3. Cada linha retornada e novamente autorizada e hidratada, incluindo relacoes, criando padrao N+1.
4. Diagnosticos, opcoes de grupos, Search Options e mapeamentos de colunas repetem trabalho no mesmo contexto.
5. Categorias, localizacoes, usuarios e grupos sao materializados integralmente em HTML antes de qualquer pesquisa.
6. Uma pagina PHP monolitica nao consegue apresentar uma falha acessivel depois que o gateway encerra a conexao.

Instrumentacao deve confirmar ou rejeitar cada hipotese antes de alteracoes amplas em banco, cache ou arquitetura.

## Principios que nao podem ser violados

- A Search API e as ACLs do GLPI permanecem como fonte de verdade.
- O plugin nao cria copia local de chamados, resultados ou definicoes de pesquisas salvas.
- Otimizacao nao pode ampliar ACL, alterar IDs, ordem, total, exclusao logica ou entidade.
- Formato nativo desconhecido, permissao nao comprovada ou resposta inconsistente devem falhar de forma fechada.
- Nenhuma meta de desempenho justifica registrar credenciais, termos, valores pesquisados ou dados pessoais.
- Timeout maior pode ser mitigacao temporaria documentada, nunca criterio de conclusao.

## Plano de implementacao

### P0.1 - observabilidade de ponta a ponta

Usar um identificador de correlacao opaco durante proxy, servidor web/PHP-FPM, plugin e banco, quando a infraestrutura permitir. Medir:

- resolucao da pesquisa salva e do contexto;
- catalogo leve e catalogo avancado;
- preparacao dos parametros nativos;
- `Search::getDatas()`;
- autorizacao e hidratacao em lote;
- opcoes de grupo e diagnosticos;
- serializacao/renderizacao;
- quantidade e duracao total das consultas;
- fingerprint da consulta dominante sem parametros;
- memoria maxima, estado do cache e tamanho de pagina;
- fila/saturacao do PHP-FPM, conexoes, locks e espera no banco;
- camada que encerrou ou interrompeu a requisicao.

As metricas nao podem usar usuario, entidade, chamado ou filtro como rotulo. Logs nao podem conter login, sessao, nome de pesquisa, ID de chamado, URL completa, SQL parametrizado, valores, chaves brutas de cache ou corpo da consulta. Antes da ativacao devem ser definidos retencao, acesso, redacao, amostragem e captura de erros/requisicoes lentas.

Excecoes nao podem desaparecer em um retorno generico: registrar codigo da etapa, classe do erro, duracao, memoria e contagem de consultas, sem conteudo pesquisado.

### P0.2 - gateway de busca compativel com GLPI 10 e 11

Criar um `TicketSearchGateway` que:

- encapsule `Search::manageParams()`, `Search::getDatas()` e equivalentes suportados;
- detecte capacidades sem depender somente do numero da versao;
- normalize respostas GLPI 10/11 para um contrato interno unico;
- preserve os parametros nativos e a ordem de retorno;
- rejeite formatos desconhecidos ou incompletos;
- permita fixtures representativas, mas exija validacao em instalacoes reais das duas linhas.

Search Options fornecidas por outros plugins tambem devem entrar na matriz de capacidade e invalidacao.

O codigo comum usa a fachada publica `\Search` presente nas duas linhas. Diferencas internas do GLPI 11, incluindo delegacao a mecanismos reorganizados, permanecem encapsuladas no adaptador de versao; o codigo comum nao depende diretamente de classes internas.

O catalogo autorizado deve ser obtido dinamicamente por `Search::getCleanedOptions($itemtype, READ, true)` ou equivalente comprovado. IDs numericos de Search Options sao proprios da instalacao e nunca sao presumidos estaveis entre versoes, plugins ou ambientes.

Consultas avancadas sao atomicas: preservar criterios aninhados, `metacriteria`, `itemtype`, conectores `AND`, `OR`, `AND NOT` e `OR NOT`, `field`, `searchtype`, valor, listas de `sort`/`order`, `is_deleted`, `start`, `list_limit` e `forcetoview`. Se qualquer no, operador, metacriterio ou Search Option nao puder ser validado, toda a consulta torna-se `native_only`; nenhum criterio pode ser descartado, aproximado ou executado parcialmente.

Pesquisas salvas usam objeto e autorizacao nativos do GLPI. A existencia de `SavedSearch` nao concede acesso. Alteracao ou exclusao externa reflete-se imediatamente, sem copia substitutiva local. A precedencia de colunas e: `forcetoview` da pesquisa salva, escolha explicita atual e, na ausencia dessas, preferencias nativas do usuario; todas validadas contra Search Options limpas.

### P0.3 - estrutura rapida e resultados assincronos

- Entregar rapidamente cabecalho, filtros, resumo e regiao de resultados, sem aguardar a consulta pesada.
- Buscar a pagina de resultados por endpoint autenticado, de mesma origem e sujeito as mesmas ACLs.
- Tratar HTTP nao bem-sucedido, timeout interno, perda de rede, sessao expirada e resposta invalida dentro da pagina acessivel.
- Definir prazo interno menor que o menor timeout de proxy, servidor web e PHP-FPM.
- Antes de qualquer liberacao do bloqueio de sessao PHP, capturar e validar snapshot minimo de usuario, perfil, entidade, recursividade, idioma e assinatura de direitos. Depois de `session_write_close()`, nenhum codigo ou hook pode ler ou escrever `$_SESSION`.
- Liberar a sessao somente quando testes reais GLPI 10/11 provarem que nenhum hook posterior depende dela; caso contrario, manter o bloqueio e registrar a serializacao como bloqueador tecnico.
- Devolver revisao opaca do contexto e descartar no cliente qualquer resposta cuja revisao nao corresponda mais ao contexto atual.
- Cinco consultas concorrentes na mesma sessao nao podem somar serialmente suas duracoes por bloqueio de sessao.
- Limitar retentativas e impedir que uma resposta antiga substitua uma pesquisa mais recente.
- Preservar fallback `Abrir no GLPI` sem executar aproximacao local da consulta.

Resultados de chamados e autocomplete usam rotas ou handlers logicamente isolados, contratos JSON versionados, allowlists, autorizacao, limites, metricas e flags independentes. Podem compartilhar apenas infraestrutura transversal.

Contrato HTTP comum:

- leitura estritamente sem efeito colateral; GET somente quando idempotente e sem termo sensivel na URL; POST de consulta segue a politica CSRF do GLPI;
- toda mutacao usa POST e token CSRF nativo;
- cookies somente same-origin, CORS fechado e `Cache-Control: private, no-store`;
- resposta sempre JSON, inclusive para sessao expirada, com codigos estruturados `401 session_expired`, `403 forbidden`, `422 invalid_request`, `429 rate_limited` e `503/504 unavailable`;
- rejeitar metodo, content-type, tamanho ou parametro inesperado;
- nunca retornar stack trace, SQL ou mensagem bruta de excecao;
- respostas personalizadas nao podem ser persistidas em `localStorage`, service worker ou cache HTTP/intermediario.

Se a entrega assincrona nao for viavel em determinada implantacao, a infraestrutura deve fornecer pagina de erro acessivel no gateway; isso nao elimina o bloqueador de desempenho.

### P0.4 - separar catalogo leve e avancado

O caminho inicial deve usar somente um catalogo leve com IDs, ordenacao e colunas necessarias a lista. Campos, operadores, metacampos, valores e colunas adicionais pertencem ao catalogo avancado tardio.

- A revisao de contexto inicial nao pode reconstruir o catalogo completo.
- Reutilizar cada catalogo durante a mesma requisicao.
- Comecar com memoizacao por requisicao.
- Cache compartilhado entre requisicoes fica restrito a metadados neutros de autorizacao e somente pode ser habilitado se medicao e hooks confiaveis de invalidacao demonstrarem seguranca e beneficio.
- E proibido cache compartilhado de resultados, rotulos de autocomplete, listas autorizadas e nomes de usuarios ou grupos.
- Chaves nunca usam usuario cru; quando necessarias, usam HMAC rotacionavel do contexto, namespace por versao, TTL curto, limite de memoria/cardinalidade e protecao anti-stampede.
- Definir TTL curto, limite de memoria/cardinalidade, descarte, invalidacao e protecao contra reconstrucao concorrente.
- Nao usar sessao PHP como cache volumoso.
- Nao cachear erros, resultados, valores pesquisados ou definicoes de pesquisas salvas.

Troca de usuario, perfil, entidade, direitos, idioma ou plugins ativos deve invalidar o contexto imediatamente.

### P0.5 - eliminar N+1 com fronteira de autorizacao explicita

- Usar diretamente campos seguros ja devolvidos pelo gateway nativo.
- Buscar em lote apenas relacoes ausentes: usuarios, grupos, entidades, categorias e locais.
- Preservar exatamente a ordem dos IDs devolvidos pelo GLPI.
- Nao executar `getFromDB()` completo, `can()` ou consultas de relacao para cada linha.
- Fazer a quantidade total de consultas permanecer essencialmente constante entre paginas de 20 e 50 itens.
- Nao expor coluna que nao corresponda a Search Option autorizada no contexto.

Os IDs retornados pela Search API somente podem ser tratados como conjunto autorizado depois que testes diferenciais comprovarem ACL para todos os perfis e contextos homologados. A hidratacao em lote nao pode acrescentar IDs. Se a prova de autorizacao falhar, a operacao deve ser bloqueada.

### P0.6 - simplificar calculos auxiliares

- Resolver Search Options frequentes uma vez por contexto.
- Construir opcoes de grupo somente quando o filtro ou agrupamento for solicitado.
- Impedir que diagnosticos reconstruam catalogos ou repitam consultas funcionais.
- Validar limites de pagina e parametros antes de consultar o GLPI.
- Detectar joins que dupliquem chamados sem deduplicar silenciosamente ou alterar o total nativo.

### P0.7 - contrato acessivel de carregamento e falha

- A regiao de resultados deve usar `aria-busy` durante a requisicao.
- Fazer um anuncio educado de inicio e um de conclusao, sem repetir mensagens a cada atualizacao.
- Diferenciar claramente `nenhum chamado encontrado` de falha, timeout ou falta de permissao.
- Anunciar o erro uma unica vez e associar a mensagem a regiao afetada.
- Preservar filtros, pesquisa salva, ordenacao, pagina e foco.
- Evitar deslocamento inesperado do foco; movimento intencional para resumo de erro ou dialogo deve ser anunciado e permitir retorno ao acionador.
- Painel expansivel mantem foco no botao e insere o conteudo na sequencia logica.
- `Tentar novamente` nao pode duplicar requisicoes nem criar ciclo infinito.
- Respostas canceladas ou antigas nao podem substituir resultados atuais.

Tempo ate o primeiro feedback acessivel, quantidade inicial de elementos e quantidade inicial de opcoes devem fazer parte das evidencias.

### P0.8 - seletores de grande cardinalidade

Substituir listas completas de categoria, localizacao, usuario e grupo por seletores pesquisaveis com autocomplete remoto e paginado em criacao, atribuicao, observadores e valores de filtros avancados.

Existem dois contratos distintos:

- `resource_selector`: operacoes de criacao e atualizacao; retorna ID nativo positivo para um provedor e papel permitidos;
- `search_option_value`: identificado por `itemtype`, Search Option e operador; retorna valor nativo opaco, rotulo e metadados de validacao, sem coercao generica para inteiro.

Autocomplete e usado somente quando o datatype ou provedor `specific` possui adaptador nativo comprovado. Texto, numero, data e booleano usam controles acessiveis proprios. Search Option ou plugin desconhecido encaminha a consulta inteira ao GLPI.

#### Decisao de experiencia

O usuario deve perceber um unico seletor semelhante ao GLPI, e nao um campo de busca separado de uma lista externa de candidatos. O controle fechado mostra o rotulo e a selecao atual; ao abrir ou digitar, apresenta uma lista curta de sugestoes autorizadas. A busca apenas local sobre milhares de `<option>` nao atende o objetivo, porque mantem o custo de servidor, transferencia, DOM e navegacao assistiva.

Modelo de interacao:

- categoria e localizacao usam selecao simples;
- tecnicos, grupos e observadores usam selecao multipla;
- abrir o controle pode carregar uma primeira pagina de ate 20 sugestoes;
- digitar inicia busca remota com debounce e feedback imediato de carregamento;
- cada pagina adicional e solicitada por botao real `Carregar mais resultados`, adjacente e externo a `listbox`, acessivel por teclado;
- selecionar uma opcao confirma seu ID nativo e fecha a lista no modo simples;
- no modo multiplo, a selecao entra em uma lista de itens escolhidos e cada item oferece `Remover <tipo> <nome>`;
- a selecao atual permanece disponivel mesmo quando nao pertence a pagina retornada, ocorre erro ou o termo muda;
- nenhuma opcao candidata e considerada selecionada apenas por ser a primeira da lista;
- texto digitado que nao corresponda a uma opcao confirmada nunca e enviado como ID.

Nao sao solucoes aceitas:

- `<select>` ou seletor oculto contendo previamente milhares de opcoes, ainda que tenha filtro JavaScript;
- `datalist` como componente principal;
- campo de busca, lista externa e botao `Adicionar` como experiencia principal;
- rolagem infinita sem botao ou paginacao operavel por teclado;
- texto livre convertido em ID ou valor nativo;
- cache ou copia local permanente do catalogo autorizado.

Nos campos multiplos, o combobox pesquisa e confirma uma sugestao por vez. O popup continua sendo lista de sugestoes de escolha unica; nao usar `aria-multiselectable`, caixas de selecao ou teclas modificadoras no popup. Confirmados ficam em lista separada.

#### Contrato do endpoint remoto

O endpoint deve ser autenticado, de mesma origem e limitado por registro fechado de provedores/finalidades. Deve receber somente tipo de contrato, provedor ou Search Option permitida, termo, cursor, tamanho e dependencias funcionais autorizadas. Contexto de autorizacao nunca vem do navegador.

- consultar APIs, Search Options e regras nativas do GLPI compatíveis com a capacidade detectada em GLPI 10/11;
- derivar usuario, perfil, entidade, entidades acessiveis, recursividade, idioma e direitos exclusivamente da sessao GLPI;
- aplicar ACL e elegibilidade especifica de categoria, localizacao, requerente, tecnico, grupo atribuido, usuario observador ou grupo observador em toda requisicao; nunca usar consulta generica comum a todos os papeis;
- em chamado existente, considerar tambem entidade e permissoes do chamado; na criacao, a entidade efetiva selecionada no GLPI;
- preservar parametros nativos aplicaveis, incluindo `condition`, `displaywith`, `used`, entidade, descendentes, direito exigido e selecao de pai;
- retornar `id` ou valor nativo opaco, `label`, complemento visivel para desambiguacao, `next_cursor`, `has_more`, quantidade carregada e, quando confiavel, `total`;
- limitar a pagina a no maximo 20 opcoes por controle, salvo evidencia homologada que justifique outro limite menor;
- rejeitar tipo de recurso, campo, ID ou contexto nao permitido;
- nao registrar termo pesquisado, nomes retornados, login ou outros dados pessoais;
- limitar termo, corpo, cursor, profundidade, tempo e concorrencia por sessao/contexto; aplicar rate limiting com rajada compativel com digitacao e tecnologia assistiva, retornando `429` e `Retry-After`;
- para usuarios e grupos, exigir minimo homologado de dois ou tres caracteres, exceto hidratacao de IDs selecionados; categoria/localizacao podem oferecer primeira pagina curta;
- cancelar a requisicao anterior com `AbortController` quando possivel, sem presumir cancelamento do PHP/SQL, e sempre descartar resposta antiga por sequencia logica;
- revalidar no envio final todos os IDs selecionados; resultado anterior do autocomplete nao funciona como autorizacao duradoura;
- invalidar qualquer estado temporario na troca de usuario, perfil, entidade, recursividade, direitos ou idioma;
- nao compartilhar resultados de autocomplete entre contextos de autorizacao diferentes.

Cursor deve ser opaco, expiravel, sem PII legivel e vinculado ao contrato, provedor/campo, termo normalizado, dependencias, ordenacao e revisao de contexto. Pode ser HMAC stateless ou token temporario. Ordenacao e deterministica com desempate por ID; buscar limite mais um para calcular `has_more` sem `COUNT` caro. Cursor adulterado, expirado ou reutilizado em outro contexto e rejeitado e nunca concede autorizacao.

Respostas fora de ordem usam contador por instancia e assinatura de contrato, provedor/campo, termo e revisao de contexto. A resposta ecoa `request_id`; o DOM so atualiza se contador e assinatura forem atuais. Pagina adicional deduplica por ID e somente agrega ao mesmo cursor/assinatura.

#### Contrato acessivel do componente

Contrato obrigatorio:

- rotulo programatico e instrucao curta associados ao controle;
- `role="combobox"` no proprio `input`, com `aria-autocomplete="list"`, `aria-expanded`, `aria-controls` e opcao ativa comunicada por `aria-activedescendant` quando aplicavel;
- lista de resultados com semantica `listbox`/`option`, sem duplicar a opcao ativa no cursor virtual;
- foco DOM permanece no input; setas percorrem sugestoes sem alterar o valor confirmado; `Enter` confirma somente a sugestao ativa; `Escape` fecha e restaura o rotulo confirmado; `Tab` e `Shift+Tab` fecham e seguem sem confirmar; teclas normais de edicao nao sao interceptadas;
- `Enter` sem sugestao ativa nao converte texto em ID nem submete acidentalmente o formulario;
- IDs de opcoes sao unicos e estaveis; `aria-activedescendant` existe apenas enquanto a opcao esta no DOM e e removido ao mudar termo ou fechar;
- estados `carregando`, quantidade encontrada, `sem resultados`, pagina adicional e `erro` anunciados de forma agrupada;
- debounce, cancelamento logico e descarte de respostas antigas;
- anuncios agrupados, sem falar a cada tecla;
- paginacao acessivel por acao explicita, sem depender de rolagem infinita;
- preservacao de selecionados e remocao com nome acessivel especifico;
- diferenciacao de homonimos por entidade, caminho ou contexto;
- carregamento inicial apenas da selecao atual e de uma pagina curta de ate 20 sugestoes;
- ausencia de duplicacao das mesmas opcoes entre candidatos e selecionados;
- foco permanece no `combobox` durante a navegacao e retorna de forma previsivel depois da remocao;
- contraste, zoom de 400%, largura de 320 CSS px e `forced-colors` preservam texto, foco e acoes;
- contrato equivalente em GLPI 10 e 11.

O botao `Carregar mais resultados` fica fora de `listbox`, `option` e do elemento controlado pelo combobox. Entra na ordem de Tab somente enquanto disponivel; sua ativacao anexa a pagina, anuncia uma vez e retorna foco ao input, preservando a sugestao ativa quando ainda existir.

Opcoes paginadas usam `aria-posinset` cumulativo e `aria-setsize` com total real ou `-1` quando desconhecido. Nao anunciar total inexistente. Uma unica regiao `role="status"` apresenta mensagens agregadas; `listbox` nao recebe `aria-live`. O limiar para anunciar `Carregando` sera calibrado em teste assistivo.

Nenhum ID e confirmado por ser primeiro ou apenas ativo. `aria-selected` pode comunicar a sugestao ativa, mas o controle submetido muda somente apos `Enter`, clique ou toque. No simples, o valor anterior permanece confirmado ate nova escolha ou `Limpar`; no multiplo, confirmar limpa apenas o termo e preserva escolhidos.

Texto nao confirmado gera erro visivel associado, `aria-invalid="true"` e descricao programatica. No envio, o resumo de erros recebe foco e liga ao campo. Campos opcionais simples oferecem `Limpar`. Apenas IDs ou valores nativos confirmados sao submetidos.

Botoes de remocao sao paradas normais de Tab. Apos remover, o foco vai ao proximo, ao anterior se nao houver proximo, ou ao combobox se a lista ficar vazia; remocao e nova quantidade sao anunciadas uma unica vez.

#### Fallback e melhoria progressiva

- Para conjuntos comprovadamente pequenos, um `<select>` nativo continua permitido.
- Para grande cardinalidade, falha de JavaScript, endpoint, rede ou sessao nao pode provocar carregamento automatico da lista completa.
- O componente preserva a selecao atual, anuncia a indisponibilidade e oferece abertura do controle/fluxo nativo seguro do GLPI.
- O fallback nao pode ampliar ACL, aceitar texto livre, perder silenciosamente selecionados nem submeter opcao candidata por padrao.
- O fallback nao descarta dados ja preenchidos. Preferir busca paginada server-side dentro do plugin; quando a navegacao ao GLPI puder perder estado, avisar e solicitar confirmacao.
- Em erro transitorio com contexto inalterado, preservar selecionados enquanto a pagina existir. Em troca de perfil, entidade, recursividade ou direitos, marcar valores anteriores como indisponiveis e impedir envio.
- Nao prometer preservacao apos recarga ou reautenticacao sem mecanismo comprovado.
- Fallback e especifico: filtros abrem a pesquisa nativa completa; criacao abre formulario nativo; atribuicao/observador abre chamado nativo; URLs sao geradas por helpers/capacidades do GLPI.

#### Gates especificos dos seletores

1. Nenhum controle volumoso inclui o catalogo completo no HTML inicial ou em seletor oculto.
2. Cada resposta contem no maximo 20 sugestoes e informa de forma confiavel se existem mais resultados.
3. Estado visual local aparece em ate 200 ms apos o debounce; endpoint atende P95 de ate 1,5 segundo, P99 diagnostico de ate 2,5 segundos e timeout interno maximo de 5 segundos na massa homologada. O momento do anuncio de carregamento e calibrado em teste assistivo.
4. IDs e elegibilidade coincidem com o seletor nativo no mesmo usuario, perfil, entidade e recursividade.
5. Zero, poucos, homonimos e milhares de resultados preservam selecao, ordem, desambiguacao e paginacao.
6. Resposta atrasada nunca substitui termo mais recente e troca de contexto invalida imediatamente o componente.
7. Categoria/localizacao simples e tecnicos/grupos/observadores multiplos sao concluidos por teclado, NVDA e JAWS sem ajuda visual.
8. Falha, timeout, 403 e sessao expirada mantem a selecao atual e oferecem fallback nativo seguro.
9. O servidor revalida cada ID no envio; manipular valor oculto ou resposta do endpoint falha de forma fechada.
10. Revalidacao confirma operacao, chamado, entidade, papel, conjunto, existencia, estado ativo, ACL e elegibilidade; qualquer falha rejeita toda a mutacao sem efeito parcial e sem revelar recurso proibido.
11. Zero falha confirmada de WCAG 2.2 niveis A e AA; toda ocorrencia Axe, inclusive moderada ou `incomplete`, analisada e registrada.
12. Nenhuma perda de operacao em 320 CSS px, 400% ou `forced-colors`.
13. NVDA com Firefox/Chrome e JAWS com Edge concluem 0, 1, 20, 21 e milhares de resultados, selecao/remocao simples e multipla e pagina adicional, com versao e fala observada registradas.

### P0.9 - analise de banco e infraestrutura baseada em evidencia

- Ativar slow log e coletar planos de execucao apenas em ambiente controlado.
- Alterar ou criar indice somente depois de identificar a consulta dominante e validar escrita/leitura.
- Verificar locks, conexoes, fila PHP-FPM, CPU, memoria e saturacao, nao apenas SQL.
- Registrar o menor timeout da cadeia e quem o controla.
- Manter plano de rollback para indices, cache, endpoint assincrono e configuracoes temporarias.

## Gates de desempenho separados

### Gate do codigo do plugin

1. Overhead P95 fora de `Search::getDatas()` de no maximo 2 segundos.
2. Quantidade de consultas limitada a uma base e numero fixo de lotes definido por cenario, nunca proporcional a cada linha, entre paginas de 20 e 50 itens.
3. Nenhum `getFromDB()`, `can()` ou consulta completa adicional por linha.
4. Mesmos IDs, ordem, total, exclusao logica, colunas autorizadas e escopo do GLPI nativo.
5. Nenhum dado proibido em logs, metricas, traces ou chaves de cache.
6. Nenhuma resposta desconhecida da Search API aceita silenciosamente.

### Gate da implantacao e do piloto

1. Feedback visual/estado local apos debounce em ate 200 ms; anuncio de carregamento calibrado para evitar fala excessiva.
2. P95 de resultados padrao em ate 10 segundos e de pesquisa avancada homologada em ate 15 segundos.
3. Tempo total abaixo de 80% do menor timeout da cadeia.
4. Zero falha nominal causada pelo plugin; taxa e orcamento de erro do canario medidos em janela definida.
5. GLPI nativo e portal comparados em pares intercalados com contexto identico.
6. Se o nativo exceder o SLO, servidor/banco passam a ser bloqueador formal mesmo que o overhead do plugin esteja aprovado.

Para a linha de base diferencial, executar no minimo 30 pares apos aquecimento, separando cache frio e quente e usando massa congelada/sintetica ou excluindo alteracoes entre o par. Para carga, executar rampa 1, 5, 10 e 25 somente ate a capacidade-alvo aprovada, com criterios de parada. Registrar P50/P95, throughput, 5xx, CPU, memoria, PHP-FPM, conexoes, locks e tempo de banco; P99 com 200 amostras e apenas diagnostico, salvo amostra maior definida.

## Gates funcionais, de seguranca e acessibilidade

A `0.2.25-beta` somente pode ser empacotada quando:

1. `Todos`, `Meus chamados` e `Chamados do grupo` concluirem sem HTTP 5xx no volume homologado.
2. Pesquisas nativas privadas, publicas e globais mantiverem definicao, IDs e ordem sem copia local.
3. Entidade com/sem recursividade, troca de perfil/direitos e visualizacao de excluidos nao causarem cache cruzado ou ampliacao de ACL.
4. Joins, paginas, ordenacao, colunas personalizadas e Search Options de outros plugins tiverem resultado diferencial documentado.
5. O equivalente nativo de `mine` e `group` estiver definido e comprovado em GLPI 10 e 11.
6. Pesquisar, aplicar pesquisa salva, paginar, ordenar, abrir, criar, atribuir e incluir observador forem concluidos por teclado e leitor de tela sem assistencia visual.
7. Sessao expirada, 403, 5xx, timeout, perda de rede, resposta vazia e respostas fora de ordem tiverem comportamento acessivel e seguro.
8. Zero falha confirmada WCAG 2.2 A/AA; toda ocorrencia Axe e `incomplete` revisada, sem substituir avaliacao manual.
9. Zoom de 400%, largura de 320 CSS px e `forced-colors` nao perderem conteudo ou acao.
10. PHPUnit, testes de navegador, PHPStan, PHPCS, i18n, build e verificacao do ZIP permanecerem verdes.

## Matriz minima de validacao

| Cenario | Evidencia obrigatoria |
|---|---|
| Sem filtro, 20 e 50 itens | duracao por etapa, consultas, memoria, IDs e ordem |
| Escopos `all`, `mine` e `group` | equivalente nativo, ACL, recursividade e ausencia de 504 |
| Pesquisa salva privada/publica/global | definicao, IDs, ordem, alteracao/remocao externa e resumo |
| Filtros simples, grupos e metacriterios | paridade ou encaminhamento explicito ao GLPI |
| Primeira/ultima pagina, zero/muitos resultados | total, ordenacao, joins e ausencia de duplicacao silenciosa |
| Colunas personalizadas e excluidos | Search Options autorizadas e mesma apresentacao nativa |
| Troca de entidade, perfil ou direitos | invalidacao imediata e ausencia de cache cruzado |
| Categorias/localizacoes simples e atores/grupos multiplos | DOM inicial, 0/1/20/21/milhares, termo, pagina seguinte, selecao, remocao primeiro/intermediario/ultimo/unico, homonimos, resposta atrasada, revalidacao e operacao assistiva |
| Timeout, 403, 5xx, rede e sessao expirada | falha fechada, mensagem unica, foco e codigo de suporte |
| Contrato HTTP e abuso | sem cookie, origem cruzada, metodo/content-type errado, CSRF ausente/invalido, termo Unicode/longo, 429, cursor adulterado/expirado e cliente abortado |
| Contexto e mutacao | duas abas, troca de entidade durante requisicao, ID revogado entre selecao/envio, manipulacao de papel/tipo e zero efeito parcial |
| Cache frio/quente e tempestade de cache | TTL, descarte, concorrencia, memoria e ausencia de stampede |
| GLPI 10/11 e Search Options de plugins | contrato do gateway e comportamento equivalente |

Registrar versoes exatas de GLPI, PHP, banco, navegador e tecnologia assistiva, alem de perfil, entidade, recursividade, quantidade de chamados e timeout efetivo. Dados de teste devem ser sinteticos ou mascarados.

Combinacoes assistivas minimas obrigatorias: NVDA com Firefox e Chrome; JAWS com Edge. Usar as versoes institucionais vigentes e registrar versao, fala observada e resultado de cada roteiro. TalkBack ou VoiceOver entra como teste exploratorio inicial.

## Sequencia de execucao

1. Aprovar contrato de observabilidade e privacidade.
2. Capturar linha de base diferencial e identificar a etapa dominante.
3. Criar `TicketSearchGateway` e fixtures GLPI 10/11.
4. Eliminar N+1 com hidratacao em lote e prova diferencial de ACL.
5. Separar catalogo leve/avancado e aplicar memoizacao por requisicao.
6. Entregar estrutura rapida e resultados assincronos com contrato acessivel.
7. Converter seletores volumosos em controles unicos de selecao com autocomplete remoto, paginado e acessivel.
8. Ativar por flags server-side independentes: lista assincrona, cada familia de provedor de autocomplete e Formcreator.
9. Avaliar cache compartilhado somente para metadados neutros e se ainda houver beneficio comprovado.
10. Analisar banco/infraestrutura e aplicar apenas correcoes sustentadas por evidencia.
11. Executar carga, matriz funcional, seguranca e tecnologias assistivas na menor versao declarada, na homologacao 10.0.18, na ultima 10.0.x e na primeira/ultima 11.x suportadas.
12. Homologar externamente antes de gerar a release; se a versao minima nao puder ser testada, elevar formalmente o requisito minimo.

## Responsabilidades

- Plugin/backend: gateway GLPI, consultas em lote, endpoint, cache e contratos nativos.
- Web/acessibilidade: carregamento, erro, foco, combobox, reflow e tecnologias assistivas.
- QA: linha de base, comparacao diferencial, carga, regressao e rastreabilidade dos gates.
- Infraestrutura: correlacao de ponta a ponta, proxy, servidor web, PHP-FPM e capacidade.
- DBA: slow log, planos, indices, locks, conexoes e rollback de banco.
- Seguranca/privacidade: contrato de logs, acesso, retencao, redacao e dados de teste.
- Responsavel pelo SLO: aprovar metas operacionais e registrar bloqueadores externos.
- Autoridade de release: impedir empacotamento quando qualquer P0 estiver reprovado.

## Fora do escopo

- criar copia local de chamados ou pesquisas salvas;
- substituir ACL/Search API por SQL que amplie resultados;
- mascarar o problema somente aumentando timeouts;
- cachear resultados ou conteudo pesquisado;
- considerar teste automatizado substituto da homologacao manual assistiva;
- liberar piloto quando a infraestrutura nativa continuar fora do SLO acordado.

## Checklist da lista de melhorias

- [ ] P0 - contrato de observabilidade, privacidade e linha de base intercalada.
- [ ] P0 - `TicketSearchGateway` compativel com GLPI 10 e 11.
- [x] P0 - estrutura rapida e resultados assincronos com prazo interno.
- [ ] P0 - catalogos leve/avancado e memoizacao por requisicao.
- [x] P0 - remocao do N+1 e hidratacao em lote coberta por regressao automatizada.
- [x] P0 - resposta acessivel para carregamento, timeout, rede, sessao e erro.
- [x] P0 - seletores unicos com autocomplete remoto e paginado para os dados essenciais de criacao e roteamento.
- [x] P0 - contratos separados de recursos e valores de Search Options implementados.
- [x] P0 - HTTP/JSON, CSRF, rate limiting, cursor, contexto e revalidacao integral implementados e cobertos localmente.
- [ ] P0 - WCAG 2.2 A/AA, NVDA e JAWS aprovados com evidencia registrada.
- [ ] P0 - gates separados do plugin e da implantacao.
- [ ] P0 - matriz diferencial GLPI 10/11, ACL, carga e tecnologias assistivas.
- [ ] P0 - homologacao externa e aprovacao formal da autoridade de release.
