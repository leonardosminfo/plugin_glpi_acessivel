# GLPI Acessivel 0.2.27-beta: refinamentos P1 de acessibilidade

## Objetivo

A `0.2.27-beta` incorpora os refinamentos P1 identificados durante a homologacao da abertura de chamados, do Formcreator incorporado e do diagnostico local Axe. A versao mantem ACL, validacao, condicoes, anexos e submissao nos motores nativos do GLPI e do Formcreator.

As novas apresentacoes continuam controladas por configuracao server-side, sem criar tabelas nem copiar catalogos, resultados, atores ou conteudo auditado.

## Seletores com autocomplete

- Categoria e localizacao aceitam navegacao inicial e pesquisa curta porque usam catalogos paginados e autorizados.
- Usuarios e grupos continuam exigindo pelo menos dois caracteres, exceto na hidratacao de IDs ja selecionados.
- O comprimento minimo passa a vir do registro server-side de provedores, evitando divergencia entre HTML, JavaScript e endpoint.
- Erros de consulta curta ou invalida usam codigos JSON permitidos e mensagens publicas especificas, sem expor excecoes internas.
- Depois da primeira tentativa de envio, o resumo de erros acompanha confirmacao, remocao, limpeza e redefinicao dos seletores sem roubar o foco nem apagar erros ainda ativos.

## Formcreator incorporado

- `native_embedded` permanece o comportamento padrao e `Abrir pagina completa` continua disponivel como preferencia e fallback, sem se tornar a jornada principal.
- `native_embedded_minimal` e uma apresentacao separada e reversivel para GLPI 10 com Formcreator 2.13.
- Um gate server-side independente, desativado por padrao, impede que a apresentacao minima seja habilitada apenas por parametro do navegador.
- A reducao visual somente e aplicada dentro do iframe oficial, em mesma origem, com rotas, ID, versoes e estrutura reconhecidos.
- A melhoria adiciona uma classe de apresentacao e oculta apenas o chrome conhecido. Campos, mensagens, validacoes, anexos, modais, CSRF e botoes do formulario nao sao removidos nem recriados.
- Qualquer divergencia de origem, rota, versao, documento ou estrutura preserva a interface nativa completa no iframe. ACL e abertura continuam falhando de modo conservador no servidor.
- Carga, timeout, sessao expirada e redirecionamento inesperado nao movem o foco; a alternativa em pagina completa permanece fora da regiao viva.

## Diagnostico local Axe

- Resultados que exigem revisao manual passam a mostrar somente contexto tecnico limitado e seguro, como seletor do alvo, regra e motivo fornecidos pelo Axe.
- O painel diferencia resultados incompletos de violacoes automatizadas confirmadas.
- A execucao tem limite logico de 15 segundos, recupera a interface quando o Axe nao conclui e ignora resultado tardio.
- Links de ajuda somente sao exibidos quando apontam por HTTPS para a documentacao oficial permitida da Deque.
- Valores de campos, texto do usuario, atributos sensiveis e HTML integral nao sao mostrados, persistidos ou transmitidos.
- A informacao continua local a aba e limitada em quantidade e tamanho para manter navegacao por teclado e leitor de tela previsiveis.

## Homologacao obrigatoria

Antes de ampliar o canario:

1. comparar categoria/localizacao com consultas vazias, de um caractere e de dois caracteres;
2. confirmar que usuarios e grupos nao consultam o servidor com um caractere e que a revalidacao final continua integral;
3. testar o resumo com um e varios erros, remocao, limpeza, redefinicao e foco estavel;
4. validar `native_embedded`, `native_embedded_minimal` e `native_link` no GLPI 10 e manter o Service Catalog suportado no GLPI 11;
5. exercitar Formcreator simples, condicional, anexos, seletores nativos, erro de validacao, sucesso e sessao expirada;
6. provar o retorno seguro para a interface completa com estrutura desconhecida, rota divergente, iframe bloqueado ou JavaScript ausente;
7. revisar o diagnostico Axe nos estados inicial, erro e resultado incompleto, confirmando que nenhum dado de formulario e exposto;
8. repetir teclado, reflow a 320 CSS px, zoom de 200% e 400%, NVDA e JAWS nas versoes institucionais homologadas.

## Linha de base automatizada

- PHPUnit: 426 testes e 2.398 assercoes;
- PHPStan: sem erros;
- PHPCS: 192 de 192 arquivos aprovados;
- navegador: 23 testes em 8 arquivos;
- i18n: 636 mensagens consistentes e catalogos Gettext compilados.

## Geracao do pacote

```powershell
.\tools\build-release.ps1 -Output .release_0.2.27-beta_accessibility_p1_refinements -Profile marketplace -RequireMsgfmt
.\tools\verify-release.ps1 -Package .release_0.2.27-beta_accessibility_p1_refinements\glpiacessivel.zip -ExpectedVersion 0.2.27-beta -PublicProfile
```
