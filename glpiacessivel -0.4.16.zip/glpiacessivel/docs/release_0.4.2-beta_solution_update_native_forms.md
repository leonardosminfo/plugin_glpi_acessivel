# GLPI Acessível 0.4.2-beta

Esta versão reúne quatro melhorias independentes e reversíveis para GLPI 10 e 11.

## Modelos de solução

- O detalhe do chamado lista somente modelos que o usuário pode ler e aplicar no chamado, considerando entidade e recursividade.
- O corpo do modelo é obtido sob demanda, renderizado pelo GLPI e convertido de HTML rico para texto legível antes de preencher o `textarea`.
- O tipo de solução é filtrado conforme entidade e, quando o esquema oferece essa informação, conforme incidente ou requisição.
- Preview e gravação revalidam permissão e contexto. A gravação final usa `ITILSolution::add()` com `_solutiontemplates_id`, preservando status e automações nativas.
- Conteúdo, respostas e anexos nunca são incluídos no log de auditoria.

## Atualização, setup e OPcache

- O pacote passa a conter `VERSION`, coerente com `setup.php`, XML e CFF.
- Se um `setup.php` antigo observar um `VERSION` diferente, o plugin entra em estado `stale`, não carrega `hook.php` e agenda somente `opcache_invalidate()` dos arquivos PHP reais contidos na pasta do plugin.
- Não há `opcache_reset()`, shell, reinício de serviço ou caminho vindo da requisição.
- `RUNTIME_EPOCH` em `setup.php`, `Bootstrap` e `SchemaManager` impede migração com classes de releases diferentes.
- O esquema possui ledger de migrações imutáveis com checksum e lock de banco.
- A configuração administrativa exibe versão carregada, versão em disco, estado do runtime e condição do OPcache. A descoberta de releases públicas continua a cargo do Marketplace do GLPI.

Limitação operacional: a primeira atualização que instala este mecanismo ainda exige uma última recarga controlada do PHP-FPM, pois a versão anterior não sabe ler `VERSION`. Preload, vários pools ou nós e restrições da API do OPcache continuam sob responsabilidade da infraestrutura.

## Formulários nativos e acessibilidade

- Um resolvedor explícito escolhe entre projeção acessível com envio nativo, formulário nativo incorporado e página nativa completa.
- No GLPI 11, a abertura por ID usa `Form::getById()` e `FormAccessControlManager::canAnswerForm()` quando essas APIs estão disponíveis, sem varrer todo o catálogo.
- A ponte visual do formulário incorporado é uma feature flag desativada por padrão.
- Depois de validar mesma origem, rota, ID, método, token e assinatura estrutural do formulário, a ponte sincroniza tema, contraste e escala de fonte e fornece foco visível/reflow.
- A ponte não muda nomes, valores, IDs, obrigatoriedade, eventos, ação, método ou token CSRF. Em qualquer divergência, o conteúdo nativo é preservado e a página completa permanece disponível.

## Rollback

- Desative a integração WCAG/eMAG e/ou selecione página nativa completa na configuração.
- Restaure a pasta anterior somente se o schema permanecer compatível; migrações desta versão são aditivas.
- Em cluster ou preload, execute o procedimento de recarga coordenada da infraestrutura.

Consulte [o plano de testes](test_plan_0.4.2-beta.md) antes de promover esta beta.
