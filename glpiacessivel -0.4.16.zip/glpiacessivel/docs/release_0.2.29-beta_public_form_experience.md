# GLPI Acessível 0.2.29-beta: formulários claros e diagnósticos protegidos

## Objetivo

A `0.2.29-beta` torna o catálogo e a abertura de formulários mais claros para quem precisa solicitar um serviço. Informações sobre fonte, versão, renderer, contrato, fallback e compatibilidade deixam de fazer parte da jornada comum. Elas continuam disponíveis, de forma sanitizada e recolhida, somente para a administração autorizada.

Essa simplificação não altera a fronteira de confiança: sessão, perfil, entidade, ACL, CSRF, campos, condições, anexos, validação e submissão continuam sob responsabilidade do GLPI, do Service Catalog ou do Formcreator.

## Experiência pública

- o catálogo apresenta título, instrução, busca, nome, descrição e uma ação principal por formulário;
- a abertura usa linguagem orientada à tarefa: voltar, preencher, tentar novamente e abrir em página completa;
- o estado normal não é apresentado como advertência;
- termos técnicos e versões não chegam ao modelo nem ao HTML do usuário comum;
- a alternativa em página completa permanece disponível antes, durante e depois do carregamento;
- falha, timeout ou sessão encerrada são comunicados sem afirmar sucesso e sem mover o foco automaticamente.

## Diagnóstico administrativo

- o acesso depende exclusivamente do direito nativo `config/UPDATE`;
- nomes ou identificadores de perfil não concedem diagnóstico;
- ausência do direito, constante ou API, ou qualquer exceção resulta na audiência pública;
- códigos desconhecidos não são refletidos;
- códigos, versões, razões, durações e contagens passam por listas permitidas e limites;
- o diagnóstico aparece em um bloco `<details>` fechado, depois da tarefa, e fora das regiões vivas.

## Acessibilidade da área incorporada

- existe uma única região `role="status"` para as transições;
- `aria-busy` é verdadeiro somente durante uma tentativa ativa e termina em todos os estados;
- anúncios repetidos são deduplicados;
- uma resposta atrasada não substitui o resultado de uma nova tentativa;
- o botão `Começar preenchimento` pode levar o foco ao quadro somente por ação explícita;
- carregamento, erro e timeout preservam o foco;
- um `ResizeObserver` acompanha alterações de altura em formulários longos e condicionais;
- a redução visual continua restrita ao gate server-side e ao fingerprint estrito; se ele não for comprovado, a interface completa é preservada.

## Correções complementares

- o portal conserva um único `h1` por página;
- a contagem visual das regras avançadas acompanha a contagem acessível;
- os novos textos passam pelo catálogo Gettext em português do Brasil e inglês britânico;
- as cópias de JavaScript e CSS em `assets/` e `public/assets/` permanecem idênticas.

## Segurança e persistência

Esta versão não cria tabela, não copia formulários e não persiste diagnósticos. A projeção pública ou administrativa é refeita em cada requisição. Alterar perfil ou direitos passa a produzir imediatamente a audiência correspondente.

O diagnóstico não muda as ações disponíveis, a ACL, a URL resolvida, o modo de abertura ou a submissão. Parâmetros do navegador e flags operacionais não elevam a audiência.

## Homologação obrigatória

Antes do piloto com usuários, verificar:

1. perfil chamado `Admin` sem `config/UPDATE` recebe somente a experiência pública;
2. perfil de nome comum com `config/UPDATE` recebe o diagnóstico sanitizado;
3. a troca de perfil revoga ou concede o diagnóstico na requisição seguinte;
4. catálogo vazio, parcial e indisponível não revelam existência de formulários sem ACL;
5. formulário simples e complexo preservam condições, anexos, validações e uma única submissão;
6. timeout, nova tentativa, sessão encerrada e resposta tardia deixam a alternativa em página completa operável;
7. teclado, NVDA e JAWS percorrem título, instrução, estado, quadro e alternativa sem armadilha ou anúncio duplicado;
8. reflow em 320 pixels CSS, zoom de 200% e 400% e cores forçadas não removem ações;
9. Axe é executado separadamente na página do plugin e no documento incorporado, com revisão manual dos resultados incompletos;
10. o comportamento é repetido no GLPI 10 com Formcreator 2.13 e no GLPI 11 com Service Catalog.

## Construção e verificação

```powershell
.\tools\build-release.ps1 -Output .release_0.2.29-beta_public_form_experience -Profile marketplace -RequireMsgfmt
.\tools\verify-release.ps1 -Package .release_0.2.29-beta_public_form_experience\glpiacessivel.zip -ExpectedVersion 0.2.29-beta -PublicProfile
```

A liberação continua beta e depende da homologação assistiva e funcional no ambiente institucional.
