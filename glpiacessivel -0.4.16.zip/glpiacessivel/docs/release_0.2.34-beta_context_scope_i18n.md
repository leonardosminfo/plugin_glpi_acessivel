# GLPI Acessível 0.2.34-beta: contexto persistido, escopo pessoal e i18n assíncrono

## Resultado

Esta beta corrige duas divergências identificadas na homologação real e reforça a qualidade linguística das jornadas assíncronas:

- a troca de perfil ou entidade somente é anunciada como concluída depois que uma segunda requisição comprova que o GLPI gravou o novo contexto na sessão;
- `Meus chamados abertos` descobre requisitante, técnico e observador pelos metadados estruturados das Search Options do GLPI 10/11, sem depender de ID ou texto traduzido;
- lista assíncrona e seletores remotos usam o mesmo catálogo Gettext emitido pelo servidor, com português acentuado e inglês britânico.

## Contratos de segurança e compatibilidade

- a troca de contexto usa `POST`, CSRF nativo, redirecionamento `303` e marcador aleatório de uso único com validade de 120 segundos;
- o retorno aceita somente rota interna do plugin e remove parâmetros que poderiam repetir a alteração no reload ou no histórico;
- tokens, cursores, pesquisas e estados assíncronos do contexto anterior são invalidados;
- o escopo pessoal exige exatamente uma Search Option estrutural para cada papel e falha fechado se o catálogo for ausente ou ambíguo;
- a Search API continua sendo a fronteira de ACL, perfil, entidade e recursividade;
- nenhum catálogo JavaScript válido significa nenhuma melhoria progressiva: o HTML seguro do servidor permanece disponível;
- nenhuma tabela ou cópia operacional foi criada.

## Verificação obrigatória

O gate detalhado está em [`test_plan_0.2.34-beta.md`](test_plan_0.2.34-beta.md). A liberação exige, no mínimo:

1. troca de perfil e entidade persistente após reload e navegação, sem repetição pelo histórico;
2. igualdade dos conjuntos de IDs de `mine` entre plugin e GLPI nativo em GLPI 10 e 11;
3. catálogo ausente/ambíguo produzindo falha fechada, nunca ampliação do conjunto;
4. pt-BR e en-GB corretos nos componentes assíncronos, inclusive nomes acessíveis e regiões vivas;
5. pipeline PHPUnit, Browser, PHPStan, PHPCS, i18n, build e verificador de release integralmente verde.

## Empacotamento

```powershell
.\tools\build-release.ps1 -Output .release_0.2.34-beta_context_scope_i18n -Profile marketplace -RequireMsgfmt
.\tools\verify-release.ps1 -Package .release_0.2.34-beta_context_scope_i18n\glpiacessivel.zip -ExpectedVersion 0.2.34-beta -PublicProfile
```

