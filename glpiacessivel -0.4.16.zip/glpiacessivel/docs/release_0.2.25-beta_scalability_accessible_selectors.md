# GLPI Acessivel 0.2.25-beta: escalabilidade e seletores acessiveis

## Finalidade

A `0.2.25-beta` implementa os tres planos P0 aprovados para homologacao: lista de chamados sem hidratacao N+1, seletores remotos paginados e acessiveis e catalogo autorizado do Formcreator. A entrega continua beta e todas as novas frentes ficam desativadas por padrao ate a validacao diferencial no ambiente real.

## Principais mudancas

### Lista de chamados

- separa a estrutura da pagina do carregamento dos resultados por um endpoint JSON autenticado;
- troca a hidratacao individual de cada linha por leitura em lote, preservando a ordem da Search API;
- usa estado opaco, curto e vinculado ao contexto, sem publicar a consulta completa na URL;
- limita cada item JSON as colunas solicitadas e aos campos minimos de navegacao, sem devolver conteudo ou relacoes nao exibidas;
- rejeita respostas antigas depois de troca de perfil, entidade, recursividade ou direitos;
- informa carregamento, vazio, expiracao, limite e indisponibilidade sem substituir o documento;
- mantem link explicito para a lista nativa do GLPI como fallback;
- registra tempos das etapas nativas e da hidratacao sem registrar termos ou conteudo dos chamados.

### Autocomplete de recursos

- substitui listas extensas de categoria, localizacao, tecnicos, grupos e observadores por um componente unico;
- pagina em blocos de ate 20 itens com cursor opaco e botao real `Carregar mais resultados` fora da `listbox`;
- suporta teclado, leitor de tela, selecao simples e multipla, remocao e retorno previsivel de foco;
- exige pesquisa minima para usuarios e grupos, limita frequencia e descarta respostas fora de ordem;
- deriva provedores, papeis, entidade e elegibilidade no servidor; texto ou rotulo do cliente nunca autoriza um ID;
- revalida todo o conjunto imediatamente antes da criacao ou alteracao e rejeita a operacao inteira se um item falhar;
- preserva atores atuais no detalhe do chamado e restringe a consulta a ACL e entidade do proprio chamado.

### Catalogo Formcreator

- adota um gateway isolado para o contrato comprovado do Formcreator 2.13 no GLPI 10;
- parte da consulta coletiva nativa, carrega uma nova instancia por candidato e executa a autorizacao nativa;
- remove o corte global de 80 formularios e pagina o catalogo com cursor vinculado ao contexto;
- faz busca no servidor, deduplicacao e revalidacao da URL direta;
- nao materializa schemas dinamicos durante a listagem;
- diferencia fonte ausente, inativa, incompatibilidade, vazio autorizado, parcial e erro;
- no GLPI 11, conserva o Service Catalog nativo como fonte suportada.

## Seguranca e operacao

- endpoints de resultados e recursos aceitam apenas contratos JSON versionados, mesma origem e sessao autenticada;
- mutacoes continuam protegidas pelo token CSRF do GLPI;
- respostas personalizadas usam `Cache-Control: private, no-store` e nao sao persistidas em `localStorage` ou Service Worker;
- cursores nao carregam PII legivel e nao funcionam como autorizacao;
- gates independentes e server-side controlam lista assincrona, catalogo Formcreator e autocompletes de abertura/roteamento;
- as flags ficam desativadas por padrao e nao podem ser habilitadas por parametro do navegador;
- nenhuma tabela nova e criada nesta versao: as flags usam a tabela chave/valor ja existente.

## Validacao local desta candidata

- PHPUnit: 405 testes e 2.284 assercoes;
- PHPStan: sem erros;
- PHPCS: 188 arquivos aprovados;
- navegador: 11 testes em seis arquivos, incluindo lista assincrona, autocompletes, respostas antigas, foco e Axe;
- build e verificacao do ZIP confirmam raiz unica, metadados, ativos publicos, documentos e SHA-256.

Os testes automatizados nao substituem a homologacao no GLPI 10/11 real. Antes do canario devem ser executados: comparacao de IDs e ACL, entidade simples/recursiva, perfis limitados, volumes reais, NVDA com Firefox/Chrome e JAWS com Edge. Divergencia de ACL exige desligamento imediato da flag correspondente.

## Rollout recomendado

1. instalar a beta mantendo todos os gates da `0.2.25-beta` desativados;
2. validar o fluxo nativo e os diagnosticos;
3. habilitar uma frente por vez para Super-Admin;
4. repetir com QA nao administrador em entidade limitada;
5. executar testes assistivos e de concorrencia;
6. ampliar gradualmente, mantendo os links nativos de rollback.

## Geracao do pacote

```powershell
.\tools\build-release.ps1 -Output .release_0.2.25-beta_scalability_accessible_selectors -Profile marketplace -RequireMsgfmt
.\tools\verify-release.ps1 -Package .release_0.2.25-beta_scalability_accessible_selectors\glpiacessivel.zip -ExpectedVersion 0.2.25-beta -PublicProfile
```
