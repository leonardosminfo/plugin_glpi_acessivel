# GLPI Acessível 0.4.6-beta — paridade nativa de perfil e integridade das ações ITIL

## Objetivo

Consolidar as correções encontradas na homologação com perfil de leitura e nas jornadas de categoria, localização, modelos, solução e atribuição, mantendo o mesmo pacote compatível com GLPI 10/PHP 8.1 e GLPI 11/PHP 8.3.

## Autorizações nativas

- O cockpit depende do direito nativo de leitura de chamados, e não do direito de criação.
- O catálogo e o acesso direto aos formulários são revalidados pela API nativa da fonte: `canViewForRequest()` no Formcreator/GLPI 10 e `ServiceCatalog` com `FormAccessControlManager` no GLPI 11.
- O plugin não deduz acesso a formulários a partir de `Ticket::CREATE`.
- A rota de criação, os atalhos da lista e a sugestão do chatbot respeitam a autorização nativa de criação no perfil e na entidade ativos.
- Atribuição e observação possuem guardas distintas. Atribuição usa `canAssign()`; observação exige atualização do item e, quando disponível no GLPI 11, `canAdminActors()`.
- O seletor remoto e o fallback local usam catálogos distintos para técnicos e observadores; a ausência de uma API exigida falha fechado.

## Integridade das ações ITIL

- A alteração de técnico, grupo responsável, pessoa observadora e grupo observador é planejada antes da escrita e executada em transação, após bloqueio da linha do chamado.
- A mutação é diferencial, preserva papéis omitidos, relê o resultado e confirma igualdade exata. Falha, exceção ou divergência provocam rollback.
- A localização obrigatória é obtida primeiro do objeto autorizado e somente então por consulta limitada à chave primária.
- A solução valida todas as precondições antes da escrita, chama `ITILSolution::add()` exatamente uma vez e transforma falhas nativas em resultado estruturado sem repetir a mutação.
- Modelos de tarefa sem conteúdo textual não apagam o texto existente nem geram anúncio de aplicação inexistente; metadados válidos continuam aplicáveis.
- O mesmo contrato distingue texto, metadados e ausência de efeito nos modelos de acompanhamento e solução.

## Interface e acessibilidade

- A visibilidade de categoria usa o campo nativo `is_helpdeskvisible` e o estado vazio explica o contexto da busca.
- Campos e seletores de atribuição ou observação são mostrados somente quando a capacidade nativa correspondente está disponível.
- Token CSRF inválido no endpoint assíncrono retorna HTTP 403 com o mesmo envelope JSON `ticket_results`, permitindo recuperação acessível previsível.
- Uma falha no motor de condições do formulário impede o envio; respostas antigas são descartadas e campos ocultos ficam desabilitados, fora do `FormData`, com reposicionamento previsível do foco.
- O atalho `Alt+N` e as sugestões do chatbot seguem as capacidades efetivas do perfil, e falhas do iframe devolvem o foco à recuperação visível.
- As novas mensagens de bloqueio por perfil foram incluídas nos catálogos `pt_BR` e `en_GB`.

## Compatibilidade e desempenho

As mudanças não removem os limites existentes: a lista continua assíncrona por padrão, consulta somente uma janela limitada de identificadores, não materializa todos os chamados, não faz contagem global no caminho crítico e preserva proteção de capacidade, orçamento do banco e paginação progressiva. A sessão PHP é liberada antes da Search; cada papel aceita no máximo 20 IDs; grupos são validados por consulta exata; e a hidratação falha controladamente acima de 1.000 relações por página.

## Qualidade automatizada

- PHPUnit PHP 8.1.31: 704 testes e 4.307 asserções.
- PHPUnit PHP 8.3.14: 704 testes e 4.307 asserções.
- Navegador: 58 cenários aprovados.
- PHPStan: sem erros.
- PHPCS: 268 arquivos aprovados.
- Internacionalização: 2.410 mensagens auditadas e 2.411 entradas compiladas em cada catálogo.

## Homologação obrigatória antes da liberação final

- repetir a matriz com perfis reais de leitura, autoatendimento e técnico no GLPI 10 e no GLPI 11;
- alterar os quatro papéis de atores e provocar uma falha intermediária controlada para comprovar rollback;
- testar localização obrigatória, modelo de tarefa, modelo de acompanhamento e solução em categorias e entidades reais;
- validar formulário Formcreator/Service Catalog e acesso direto com perfis autorizados e não autorizados;
- executar carga HTTP autenticada pelo proxy e acompanhar PHP-FPM, banco, latência, memória, circuito e respostas de saturação;
- validar as jornadas críticas com teclado e leitor de tela.

## Rollback

Preservar o diretório e o ZIP anteriores antes da atualização. A versão não cria uma migração destrutiva. A restauração deve usar o pacote anterior completo, seguida da verificação do diagnóstico de versão e runtime do plugin.
