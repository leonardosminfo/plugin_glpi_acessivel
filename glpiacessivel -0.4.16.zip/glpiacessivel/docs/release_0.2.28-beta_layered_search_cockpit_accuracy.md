# GLPI Acessível 0.2.28-beta: pesquisa em camadas e cockpit confiável

## Objetivo

A `0.2.28-beta` reorganiza a pesquisa de chamados sem criar mecanismos paralelos ao GLPI e corrige a forma como o cockpit calcula e comunica seus indicadores. A mesma consulta canônica continua sendo a fonte da busca rápida, dos filtros, das pesquisas salvas nativas, da exibição dos resultados e dos detalhamentos abertos pelos indicadores.

A versão também inicia uma revisão linguística orientada à pronúncia por leitores de tela, à consistência terminológica e à distinção inequívoca entre valor exato, resultado indisponível e estado ainda não consultado.

## Pesquisa de chamados em quatro camadas

1. **Busca rápida** para ID, título ou descrição.
2. **Acesso recorrente** para pesquisas salvas no próprio GLPI.
3. **Filtros** frequentes e avançados, com divulgação progressiva.
4. **Exibição dos resultados** para colunas, ordenação, agrupamento, paginação e registros excluídos.

As quatro camadas compartilham um único formulário e uma única ação `Pesquisar`. Abrir ou fechar uma camada não altera o conjunto exibido, e editar a consulta somente produz novos resultados quando o usuário confirma a pesquisa. O resumo aplicado permanece visível e deve reproduzir o estado efetivamente executado.

## Cockpit confiável e acionável

- Os cinco indicadores usam consultas independentes e autorizadas pela Search API nativa do GLPI.
- A varredura dos 500 chamados mais recentes e a hidratação N+1 deixam de ser usadas para calcular os totais.
- Cada indicador informa valor, período, escopo, horário de referência e apresenta um detalhamento que recompõe a mesma consulta canônica na lista de chamados.
- Falha, timeout, operador incompatível ou ausência de total explícito produzem `Resultado indisponível`; nunca um zero enganoso.
- A consulta respeita usuário, perfil, entidade, recursividade, grupos e direitos ativos. O detalhamento é reautorizado e não confia em critérios ou IDs enviados pelo navegador.
- Os estados opacos de detalhamento permanecem na sessão do GLPI e não criam cópias locais de chamados ou pesquisas salvas.

## Revisão linguística e acessibilidade

- Os textos visíveis e anunciados dos fluxos alterados usam Gettext e português brasileiro com acentuação correta.
- Os mesmos conceitos usam a mesma terminologia em rótulos, estados e mensagens.
- Resultado desconhecido não é apresentado como `0`, e informações técnicas internas não são usadas como mensagem comum.
- Os painéis progressivos expõem `aria-expanded` e `aria-controls`, preservam o foco e podem ser fechados por teclado sem duplicar controles para o cursor virtual.
- Os cartões do cockpit não dependem apenas de cor ou gráfico e conservam equivalentes textuais completos.

## Homologação obrigatória

Antes de ampliar o piloto:

1. comparar cada indicador com seu detalhamento, com a lista do plugin e com a pesquisa equivalente no GLPI nativo;
2. repetir os cenários com 499, 500 e 501 chamados para provar que não existe corte silencioso;
3. validar perfis de autoatendimento, técnico e administração, entidades recursivas e não recursivas e participação em múltiplos grupos;
4. testar a pesquisa simples sem abrir filtros avançados e a pesquisa complexa sem perder o contexto aplicado;
5. confirmar teclado, Escape, foco, modo de navegação e modo de formulários com NVDA e JAWS;
6. revisar pronúncia, mensagens de erro, nomes acessíveis, mojibake e entidades HTML nos fluxos alterados;
7. confirmar que indisponibilidade, sessão expirada e troca de contexto não deixam contagem antiga nem anunciam zero.

## Linha de base automatizada

Gates concluídos antes do empacotamento:

- PHPUnit: 450 testes e 2.652 asserções;
- PHPStan: sem erros;
- PHPCS: 195 arquivos sem erros;
- navegador: 25 testes em 9 arquivos;
- Gettext: 817 mensagens consistentes e catálogos recompilados por `msgfmt`;
- build Marketplace e verificação independente do ZIP.

## Geração do pacote

```powershell
.\tools\build-release.ps1 -Output .release_0.2.28-beta_layered_search_cockpit_accuracy -Profile marketplace -RequireMsgfmt
.\tools\verify-release.ps1 -Package .release_0.2.28-beta_layered_search_cockpit_accuracy\glpiacessivel.zip -ExpectedVersion 0.2.28-beta -PublicProfile
```
