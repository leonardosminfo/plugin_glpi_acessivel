# GLPI Acessível 0.4.13-beta — solução nativa com guard persistente

## Objetivo

Esta versão corrige o fluxo de resolução para reproduzir o contrato do GLPI 10 e 11: o plugin envia a solução uma única vez por `ITILSolution::add()` e deixa o próprio GLPI executar as regras, notificações e mudança de status. O plugin não chama `Ticket::update()` para forçar `SOLVED`.

## Contrato implementado

- ACL, `Ticket::canUpdate()`, `Ticket::canSolve()`, entidade, tipo de solução, modelo e campos obrigatórios são validados antes da mutação.
- Um guard persistente e opaco é adquirido por chamado antes de iniciar a transação. Se ele não puder ser confirmado, nenhum `add()` é executado.
- A linha do chamado é bloqueada com `FOR UPDATE`; solução, vínculo, autor, tipo e status terminal são relidos dentro da mesma transação.
- O commit ocorre somente depois da pós-condição completa. Resultado positivo sem mudança nativa de status sofre rollback e não é apresentado como sucesso.
- Commit ou rollback inconclusivo conserva o guard entre usuários, abas e sessões. Não existe repetição automática.
- Replay da mesma confirmação devolve o resultado já concluído, sem segundo `add()` e sem nova auditoria terminal.
- O snapshot confirmado sob lock é o resultado autoritativo. Uma recusa ou reabertura posterior não reclassifica a operação original.
- Falha na limpeza pós-commit apenas deixa `marker_cleared=false`; não transforma sucesso nativo em erro. O guard remanescente é seguro e pode ser reconciliado.
- Leitura ausente ou vínculo divergente não prova rollback e mantém o estado parcial. A liberação ocorre por estado terminal, solução recusada com limpeza confirmada ou reconciliação operacional.

## Acessibilidade da confirmação

O diálogo apresenta tipo, descrição e modelo efetivamente aplicado. Descrições longas usam `details/summary`, criado com `textContent`. O `summary` participa do ciclo de foco do `alertdialog` e foi exercitado com Tab, Shift+Tab, Enter e Espaço.

## Compatibilidade e atualização

O mesmo caminho mantém compatibilidade com GLPI 10 e 11. A versão foi elevada para `0.4.13-beta` e o marcador de runtime para `20260831-04`, permitindo a detecção do novo código e a invalidação seletiva de OPcache prevista pelo plugin.

## Estado da validação

Os testes automatizados cobrem sucesso, rejeição nativa, rollback completo, commit/rollback ambíguos, replay, conflito, chaves distintas, falha ao criar o guard, falha/erro na limpeza, troca de sessão e releitura inconclusiva. A promoção continua condicionada ao plano de testes em GLPI 10 e 11 com duas sessões e banco real.

