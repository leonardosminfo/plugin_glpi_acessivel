# Plano de testes — 0.4.3-beta

## 1. Gate automatizado

1. Executar PHPUnit completo em PHP 8.1 e 8.3.
2. Executar PHPStan, PHPCS, auditoria Gettext com `msgfmt` e a bateria completa de navegador.
3. Gerar o pacote marketplace e validar raiz, versão, fingerprint, arquivos obrigatórios, ativos espelhados e ausência de `opcache_reset()`.
4. Executar os testes abaixo com o mesmo ZIP e SHA-256 em GLPI 10 e GLPI 11.

## 2. Lista e pesquisa

| ID | Cenário | Resultado esperado |
|---|---|---|
| L01 | abrir Chamados com lista progressiva sem configuração prévia | shell imediato e primeira página limitada; nenhum total global obrigatório |
| L02 | anterior, próxima, ordenar, filtrar, repetir e trocar contexto | sem perda/duplicação; estado e foco coerentes; resposta antiga descartada |
| L03 | total desconhecido, lista vazia, 403 CSRF, timeout e saturação | mensagem única e acionável; nenhum falso zero; retry respeita espera do servidor |
| L04 | status `não é` com catálogo válido | paridade de IDs com a pesquisa nativa |
| L05 | status `não é` sem Search Options ou catálogo ambíguo | falha fechada; nenhum resultado mais amplo |

## 3. Abertura e requerente

| ID | Cenário | Resultado esperado |
|---|---|---|
| C01 | Self-Service, submissão normal | requerente autenticado, sem seletor delegado |
| C02 | Self-Service, POST com outro `requester_user_id` | recusado antes de `Ticket::add()` |
| C03 | Central, requerente autorizado na entidade | catálogo remoto exato e ticket criado para o escolhido |
| C04 | ID forjado, outra entidade, usuário inativo ou catálogo vencido | falha fechada, sem ticket parcial |
| C05 | capability nativa ausente ou inconclusiva | alternativa de formulário nativo, sem enumeração de usuários |
| C06 | busca remota no GLPI 11 com `X-Requested-With` e token CSRF | listener nativo aceita o POST e o endpoint responde no contrato `resource_selector`; sem o marcador AJAX, o núcleo mantém `403` |

## 4. Matriz de atribuição e observadores

Repetir para **técnico atribuído**, **grupo responsável**, **pessoa observadora** e **grupo observador**.

| ID | Operação | Resultado esperado |
|---|---|---|
| A01 | campo omitido | atores existentes preservados |
| A02 | enviar lista vazia | papel correspondente limpo, sem `IN ()` |
| A03 | 0 → 1, 1 → N e N → 1 | somente diferenças adicionadas/removidas; sem duplicidade |
| A04 | remover um e adicionar outro no mesmo envio | estado final exato e histórico coerente |
| A05 | ator existente deixou de ser elegível | preservado; não removido por efeito colateral |
| A06 | ID forjado, ator de outra entidade ou papel incorreto | nenhuma mutação parcial |
| A07 | duas abas e revisão de contexto entre busca e envio | revalidação final recusa contexto obsoleto |
| A08 | operar somente por teclado | busca, seleção, remoção, limpar, confirmação e retorno de foco concluídos |
| A09 | cancelar/Escape na confirmação | nenhuma alteração; foco retorna ao acionador |
| A10 | confirmar | token único consumido; exatamente uma atualização e uma auditoria sem dados pessoais |

Conferir no GLPI nativo as relações `Ticket_User` tipo 2/3, `Group_Ticket` tipo 2/3, histórico e entidade. O requerente nunca deve ser removido pelo roteamento.

## 5. Acompanhamento, tarefa e solução

1. Aplicar modelos globais, de entidade e recursivos; tentar modelo forjado.
2. Confirmar conversão segura de HTML em texto, entidades e quebras de linha nos `textarea`.
3. Conferir privacidade, categoria, estado, duração, técnico e grupo em `TaskTemplate`.
4. Adicionar solução uma única vez e conferir ID, chamado, tipo, conteúdo não vazio, histórico e status nativo.
5. Simular falha da leitura pós-gravação: registrar diagnóstico sem repetir a solução.

## 6. Checklist de acessibilidade

Executar em portal, lista, criação, detalhe, base de conhecimento, cockpit e formulário incorporado:

- hierarquia de títulos e landmarks sem `main` aninhado;
- nome acessível único para links e botões; rótulos e ajuda programaticamente associados;
- resumo de erros, mensagens e resultados anunciados uma vez;
- teclado completo, foco visível e retorno previsível após erro, retry, remoção e modal;
- zoom 200%/400%, viewport de 320 CSS px, tema claro/noturno, alto contraste e `forced-colors`;
- Axe/WAVE sem violação crítica/séria confirmada e revisão manual dos falsos positivos;
- NVDA com Chrome/Firefox e JAWS com Edge nas jornadas críticas;
- formulário incorporado auditado separadamente no documento pai e no iframe.

## 7. Segurança, carga e compatibilidade

1. Repetir com perfil autorizado e não autorizado, entidade simples/recursiva e troca de contexto em voo.
2. Verificar CSRF, token crítico, limite, cursor opaco, timeout, `Retry-After` e logs sem conteúdo do chamado.
3. Confirmar que os seletores enviam `X-Requested-With: XMLHttpRequest` e `X-GLPI-CSRF-TOKEN` no GLPI 11, mantendo a validação legada no GLPI 10.
4. Executar carga autenticada via proxy com paginação e seletores; medir p95/p99, memória, erros HTTP, PHP-FPM e banco.
5. Confirmar nenhuma contagem total ou materialização ilimitada no caminho da lista.
6. Repetir instalação limpa e atualização sobre 0.4.2-beta, confirmando versão em disco/carregada e OPcache sem reinício quando o mecanismo anterior já estiver presente.

## 8. Critério de liberação

GO somente com: todos os gates automatizados aprovados; matriz GLPI 10/11 concluída com o mesmo pacote; zero ampliação de ACL; zero duplicidade de mutação; nenhuma falha crítica/séria de acessibilidade confirmada; e jornadas assistivas aceitas pelos usuários. Qualquer falha de autorização, 5xx/504, perda de ator, submissão duplicada ou bloqueio de teclado é NO-GO.
