# 0.2.2-beta - contexto GLPI 10 e estado sem acoes

## Objetivo

Esta versao fecha a divergencia visual observada apos o login direto pelo portal acessivel no GLPI 10, sem contornar permissoes ou configuracoes administrativas.

## Diagnostico homologado

- O login direto carregou os perfis Helpdesk, Self-Service e Super-Admin.
- A troca entre os tres perfis foi concluida pelas APIs nativas do GLPI.
- No ambiente GLPI 10 analisado, Formularios, Chatbot e Roteiros estavam configurados como indisponiveis.
- O perfil Helpdesk oferecia somente o fluxo nativo do FormCreator e nao possuia as permissoes centrais exigidas pelos demais atalhos.
- No GLPI 11, os modulos e as permissoes efetivas liberavam mais acoes, por isso os cards eram exibidos.

## Correcoes

- `ContextService` mantem a opcao Todas as entidades quando `glpientity_fullstructure` esta ativo, inclusive quando existe uma unica raiz permitida.
- O portal calcula explicitamente se ha alguma acao efetivamente disponivel.
- Quando nao existe acao autorizada, a tela apresenta uma mensagem acessivel com orientacao para trocar de perfil ou solicitar revisao administrativa.
- A mensagem nao revela estados internos de modulos, nomes de classes, limites operacionais ou diagnosticos tecnicos.

## Seguranca e compatibilidade

- Nenhuma ACL foi ampliada ou ignorada.
- Modulos marcados como ocultos ou indisponiveis continuam sem rota operacional.
- A autoridade permanece com o perfil, a entidade, a recursividade e as permissoes nativas do GLPI.
- A alteracao e compativel com GLPI 10 e 11 e nao modifica dados de chamados.

## Orientacao operacional

Para exibir Formularios, Chatbot ou Roteiros, o administrador deve liberar os respectivos modulos nas configuracoes do plugin. Para exibir funcoes de chamados, o perfil precisa possuir as permissoes correspondentes no GLPI. O plugin nunca transforma uma configuracao de apresentacao em concessao de acesso.

## Evidencias automatizadas

- regressao do escopo Todas as entidades com uma unica raiz permitida;
- regressao da mensagem apresentada quando nao ha acoes disponiveis;
- PHPUnit, PHPStan, PHPCS e auditoria gettext no pacote final.