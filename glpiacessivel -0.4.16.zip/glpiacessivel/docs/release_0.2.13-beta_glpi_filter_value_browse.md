# Release 0.2.13-beta: opções de filtros alinhadas ao GLPI

## Resultado

Os campos de catálogo do filtro avançado passam a se comportar como a pesquisa nativa observada no GLPI: ao usar `é`, `não é`, `sob` ou `não sob`, o combobox carrega a primeira página de opções autorizadas assim que recebe foco. O usuário pode escolher diretamente ou digitar para restringir os resultados.

## Comportamento por tipo de valor

- listas locais, como Status, Prioridade, Urgência e Impacto, continuam apresentadas imediatamente em um `select`;
- catálogos remotos, como Categoria, Entidade, Localização, Técnico e Grupo, abrem as primeiras 25 opções autorizadas;
- ao digitar dois ou mais caracteres, o mesmo combobox pesquisa por nome;
- “Carregar mais resultados” pagina o catálogo sem trocar de controle;
- `contém` e `não contém` preservam a pesquisa textual, evitando uma enumeração automática desnecessária;
- datas, números, booleanos e texto livre mantêm o controle adequado ao tipo informado pela Search Option.

## Paridade observada

A comparação foi feita na própria instalação GLPI, alternando entre a tela acessível e `/front/ticket.php`. Foram confirmados:

- Status com valor local selecionável;
- Categoria com `é`, `não é`, `sob` e `não sob`;
- catálogo nativo carregado de forma progressiva pelo Select2 do GLPI;
- rótulos e ordem dos valores agregados de Status usados pela tela nativa.

## Acessibilidade

O combobox mantém `aria-expanded`, `aria-controls`, `aria-activedescendant`, lista com `role="option"`, estado de carregamento e anúncios em região viva. Setas, Home, End, Enter e Escape continuam disponíveis; ao receber foco vazio, a lista inicial é carregada sem executar a pesquisa de chamados.

## Segurança e escala

A consulta de opções permanece protegida por POST, autenticação, direito de visualizar chamados, CSRF, lista fechada de parâmetros e limitação por sessão. Campo, tabela e itemtype são resolvidos pelo catálogo contextual do servidor. Os provedores nativos aplicam entidade, recursividade, rights, condições e token IDOR do GLPI 10/11. Cada página contém no máximo 25 itens.

## Compatibilidade e validação

- GLPI: `>=10.0 <12.0`;
- PHP: `>=8.1`;
- PHPUnit: 280 testes e 1.420 asserções;
- PHPStan: sem erros;
- PHPCS: sem erros nos arquivos alterados;
- sintaxe PHP 8.1 e JavaScript validada;
- catálogos gettext e espelhos públicos de assets verificados.