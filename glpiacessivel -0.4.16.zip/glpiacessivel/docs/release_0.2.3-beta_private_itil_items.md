# 0.2.3-beta - privacidade de acompanhamentos e tarefas

## Objetivo

Oferecer no detalhe acessivel do chamado a mesma decisao operacional entre item publico e privado existente no GLPI, sem contornar perfil, entidade ou ACL nativa.

## Implementacao

- acompanhamentos usam escolha obrigatoria entre resposta publica e nota interna privada;
- tarefas usam escolha obrigatoria entre tarefa publica e tarefa interna privada;
- o valor inicial vem de ITILFollowup::getEmpty() e TicketTask::getEmpty(), com fallback para as preferencias de sessao do GLPI;
- modelos privados permanecem privados mesmo se o POST solicitar visibilidade publica;
- autorizacao e persistencia recebem o mesmo valor efetivo de is_private;
- a timeline consulta os candidatos e delega a leitura de cada item ao metodo nativo can(id, READ);
- itens autorizados exibem tipo, visibilidade, autor e data em texto;
- anexos seguem a visibilidade do item pai.

## Compatibilidade

A implementacao usa ITILFollowup, TicketTask, ITILSolution e ITILFollowupTemplate, classes presentes na matriz GLPI 10 e 11. Ausencia de classe, metodo, item ou permissao resulta em bloqueio conservador.

## Evidencias automatizadas

- PHPUnit: 120 testes e 540 assercoes;
- PHPStan nos arquivos alterados: sem erros;
- PHPCS nos arquivos PHP alterados: sem erros;
- catalogos gettext: 409 mensagens compiladas e consistentes;
- sintaxe PHP validada em PHP 8.1.

## Homologacao manual obrigatoria

Repetir em GLPI 10 e 11 com Self-Service, tecnico/Hotliner, gestor e Super-Admin:

1. criar resposta publica e confirmar leitura pelo solicitante;
2. criar nota interna e confirmar que perfis sem SEEPRIVATE nao veem item, contagem ou conteudo;
3. criar tarefa publica e tarefa privada;
4. aplicar modelo publico e privado;
5. anexar documento a cada tipo e confirmar o vinculo final;
6. alternar perfil e entidade durante a sessao;
7. validar teclado, foco, NVDA/JAWS/VoiceOver, zoom 400%, alto contraste e reflow.

Esta beta nao substitui a homologacao da instalacao real.
