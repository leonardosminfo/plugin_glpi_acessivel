# GLPI Acessível 0.4.14-beta — recuperação segura do replay de solução no GLPI 11

## Objetivo

Esta versão corrige a experiência apresentada quando o GLPI 11 rejeita, antes do controlador do plugin, uma nova submissão do formulário de solução cujo token CSRF já expirou ou foi consumido.

## Comportamento

- o token continua descartável e é validado exclusivamente pelo núcleo do GLPI;
- a solução não é reenviada, o controlador não é chamado e nenhuma mutação é repetida;
- somente o POST HTML, não AJAX, de `ticket.action.php` com `action=solution` e chamado válido recebe recuperação contextual;
- a recuperação usa `303 See Other` para reler o chamado e apresenta um alerta acessível com foco;
- o `403` do GLPI permanece inalterado fora desse contrato estrito;
- a resposta e a auditoria não reproduzem token, descrição da solução nem outros campos submetidos;
- o endpoint assíncrono `ticket.results.php` mantém seu normalizador JSON independente.

## Compatibilidade

O listener é registrado somente no GLPI 11. O fluxo do GLPI 10 permanece no controlador legado já testado. Não há alteração de banco de dados, ledger de idempotência ou chamada nativa de `ITILSolution::add()`.

## Atualização

A versão passa a `0.4.14-beta` e o marcador de runtime a `20260831-05`. A divergência entre `VERSION` e o código carregado aciona a invalidação seletiva de OPcache já prevista pelo plugin.
