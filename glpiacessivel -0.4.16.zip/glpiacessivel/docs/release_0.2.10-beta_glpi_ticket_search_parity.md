# Release 0.2.10-beta: pesquisa de chamados alinhada ao GLPI 10 e 11

## Objetivo

Esta versao reorganiza a pesquisa de chamados para manter o modelo mental do
GLPI, com uma apresentacao progressiva e operavel por teclado e leitor de
tela. O plugin continua delegando catalogo, autorizacao, execucao e
persistencia ao GLPI.

## Experiencia de pesquisa

- a busca avancada passa a ser o modo inicial da pagina;
- os filtros aparecem antes das pesquisas salvas e dos resultados;
- cada criterio segue a ordem relacao, categoria, campo, condicao e valor;
- categorias e campos sao derivados das Search Options autorizadas pelo
  perfil, entidade e plugins ativos;
- a ordenacao identifica a categoria nativa de cada campo;
- ordenacao, quantidade por pagina e colunas ficam em "Opcoes dos resultados",
  que pode ser expandido quando necessario;
- filtros rapidos permanecem disponiveis como modo alternativo explicito;
- pesquisas salvas continuam sendo lidas, criadas, renomeadas, definidas como
  padrao e excluidas diretamente no SavedSearch do GLPI, sem copias locais.

## Compatibilidade GLPI 10 e 11

O catalogo detecta a API disponivel em tempo de execucao:

- GLPI 10: Search com getCleanedOptions/getOptions e getActionsFor;
- GLPI 11: Glpi\Search\SearchOption com getOptionsForItemtype e getActionsFor;
- metacriterios usam o mecanismo de busca disponivel na respectiva geracao.

Cabecalhos de grupo das Search Options sao preservados como categorias. O
metadado interno `searchopt`, devolvido junto com as acoes em algumas
combinacoes do GLPI, e removido no servidor e novamente no cliente. Somente
condicoes reconhecidas pelo validador e oferecidas pelo catalogo contextual
podem ser enviadas.

## Acessibilidade

- controles nativos com rotulos programaticos;
- ordem visual e de foco equivalente a ordem de preenchimento;
- mudanca de categoria atualiza campos e move o foco para o proximo controle;
- anuncios para mudancas dinamicas;
- reflow em duas colunas e depois uma coluna;
- foco visivel, alto contraste e forced-colors;
- nenhuma dependencia de arrastar e soltar.

## Garantias e limites

- o plugin nao mantem copia local de pesquisa salva;
- nenhuma pesquisa ignora perfil, entidade ou ACL do GLPI;
- operadores desconhecidos ou metadados internos falham de forma fechada;
- metacriterios ou condicoes que nao possam ser representados fielmente
  continuam disponiveis pelo comando "Abrir no GLPI";
- a homologacao manual deve ser repetida no GLPI 10 e 11 da instalacao com os
  perfis e plugins realmente usados.

## Validacao automatizada

Na consolidacao inicial:

- PHPUnit: 227 testes e 1.128 assercoes;
- PHPStan: sem erros;
- PHPCS: sem erros;
- sintaxe PHP e JavaScript: validada;
- ativos fonte e publicos: hashes identicos.
