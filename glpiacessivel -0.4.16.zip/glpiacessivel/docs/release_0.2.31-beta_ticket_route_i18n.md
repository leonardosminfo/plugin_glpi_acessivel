# GLPI Acessível 0.2.31-beta: rota de Chamados e tradução de estados

## Objetivo

Esta correção resolve uma colisão observada no GLPI 10 quando o Formcreator substitui a central de ajuda. O Formcreator 2.13 procura a substring `front/ticket.php` na URL e, em perfis com interface Self-Service, também capturava a antiga rota do GLPI Acessível antes que o controlador do plugin fosse executado.

## Alterações

- `front/tickets.php` passa a ser a rota canônica da lista e do detalhe de chamados;
- links, formulários, pesquisas salvas, cockpit, chatbot, atalhos e redirecionamentos internos usam a rota sem colisão;
- `front/ticket.php` permanece como compatibilidade e redireciona antes do bootstrap do GLPI, com `302` para GET/HEAD e `307` para os demais métodos;
- fallbacks para a listagem nativa continuam apontando para `/front/ticket.php` do GLPI;
- os estados agregados da Search API são traduzidos pelo domínio `glpiacessivel`: Não solucionado, Não fechado, Processando, Solucionado + fechado e Todos;
- os tokens `notold`, `notclosed`, `process`, `old` e `all` permanecem inalterados.

## Segurança e compatibilidade

A mudança não amplia ACL, não altera permissões nem desabilita o `replace_helpdesk` do Formcreator. O controlador continua validando sessão, perfil, entidade e direitos do GLPI. Favoritos antigos são encaminhados para a rota nova sem executar o bootstrap na rota vulnerável à colisão.

## Homologação obrigatória

- GLPI 10 com Formcreator 2.13 e `replace_helpdesk` ligado/desligado;
- perfis Self-Service, técnico e Super-Admin;
- lista, detalhe, filtros, pesquisas salvas, cockpit, chatbot e POST de busca;
- GLPI 11 nos perfis central e helpdesk;
- teclado, NVDA/JAWS, zoom de 200% e 400% e largura de 320 CSS px;
- confirmação de que a rota do plugin não termina em `/formcreator/front/issue.php`.

## Build

```powershell
.\tools\build-release.ps1 -Output .release_0.2.31-beta_ticket_route_i18n -Profile marketplace -RequireMsgfmt
.\tools\verify-release.ps1 -Package .release_0.2.31-beta_ticket_route_i18n\glpiacessivel.zip -ExpectedVersion 0.2.31-beta -PublicProfile
```
