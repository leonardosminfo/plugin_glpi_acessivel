# Gates finais do plano nativo

Este documento integra o plano
`roadmap_saved_ticket_searches_glpi_native_only.md`. As regras abaixo foram
adicionadas apos a revisao final dos especialistas e prevalecem em caso de
ambiguidade.

## Adaptadores GLPI 10 e 11

O gateway tera adaptadores explicitos:

- `Glpi10SavedSearchAdapter`;
- `Glpi11SavedSearchAdapter`.

Ambos analisam a query armazenada e falham fechados antes da execucao. O
adaptador GLPI 10 deve exigir explicitamente o direito nativo de publicar
pesquisas antes de aceitar `is_private=0`; `can(UPDATE)` do proprietario,
isoladamente, nao e suficiente nessa versao.

Publicar, retirar publicidade, alterar entidade ou recursividade sempre exige
o direito nativo especifico, alem do direito de atualizar o objeto.

## Tamanho da query

O orcamento nao usa 64 KiB.

- medir a query final ja serializada e codificada;
- aplicar margem abaixo da capacidade do campo `TEXT`;
- iniciar com teto de 48 KiB para a query final;
- contar tambem quantidade de parametros, criterios, metacriterios e colunas;
- exceder qualquer teto resulta em `native_only`;
- nunca depender de truncamento do banco, PHP ou GLPI.

O teto so pode aumentar depois de teste contratual nas duas versoes e
comprovacao da capacidade completa, incluindo URL encoding.

## Sem cache persistente de pesquisas

Nas primeiras entregas nao existira cache persistente de ID, fingerprint,
metadados ou capacidade de pesquisa.

E permitido apenas memoization durante a mesma requisicao, descartada ao fim
do request. Ela deve continuar isolada pelo contexto autenticado.

Uma proposta futura de cache entre requisicoes exige revisao separada de ACL,
invalidacao, privacidade e troca de perfil/entidade.

## Idempotencia sem copia local

Idempotencia operacional nao e uma copia da pesquisa.

Pode existir um ledger generico de operacoes com prazo curto, contendo apenas:

- hash da chave idempotente;
- usuario, perfil e entidade;
- tipo de acao;
- tipo e ID do recurso nativo resultante;
- estado `reserved`, `completed` ou `failed`;
- correlation ID;
- criacao e expiracao.

O ledger nao pode conter nome, URL, query, AST, criterios, filtros, valores ou
padrao. Deve ter unicidade por usuario, acao e hash da chave, expiracao e
limpeza automatica.

### Criacao

Criar pesquisa entra no mesmo pipeline transacional das demais mutacoes:

1. validar CSRF;
2. validar nonce de uso unico;
3. reservar a chave idempotente;
4. iniciar transacao;
5. revalidar usuario, perfil, entidade e direito;
6. gerar e validar a query canonica;
7. executar `SavedSearch::add()`;
8. fazer readback;
9. registrar o ID resultante no ledger;
10. registrar auditoria sem conteudo;
11. confirmar a transacao.

Se a mesma chave concluida for reenviada, retornar o resultado anterior sem
criar nova pesquisa. Chave `reserved` abandonada segue politica explicita de
expiracao e recuperacao. Falha nao pode deixar uma pesquisa criada sem
readback ou estado recuperavel.

Update, exclusao e padrao usam o mesmo contrato de nonce e idempotencia.

## Exclusao acessivel

A pagina de confirmacao deve:

- focar inicialmente o heading ou aviso que explica a consequencia;
- apresentar acao explicita `Cancelar`;
- apresentar `Excluir definitivamente X`;
- informar nome, origem GLPI, publicidade, entidade, recursividade e padrao;
- exigir confirmacao textual/checkbox associada ao nome;
- devolver foco ao acionador quando cancelada.

Apos excluir e confirmar por readback:

- focar o proximo item do catalogo;
- na ausencia, focar o heading dos resultados;
- anunciar o resultado uma unica vez;
- nunca executar uma pesquisa substituta.

## Preferencias de exibicao acessiveis

Todos os controles de exibicao precisam:

- ter label e instrucao associados;
- funcionar integralmente por teclado;
- ser aplicados por botao explicito;
- manter ou devolver foco ao acionador;
- anunciar somente o estado final;
- preservar a pesquisa e a pagina sempre que isso for coerente;
- participar da matriz NVDA, JAWS, VoiceOver, zoom e `forced-colors`.

Colunas usam `DisplayPreference` nativo. Tamanho de pagina usa a preferencia
nativa do usuario ou apenas a requisicao. Opcao exclusiva do portal sem modelo
nativo equivalente nao ganha persistencia.

## Gate adicional de release

Bloquear a release se:

- GLPI 10 permitir publicacao sem o direito nativo explicito;
- a query final puder exceder 48 KiB ou sofrer truncamento;
- existir cache persistente de pesquisa sem revisao propria;
- criacao puder ser repetida por retry, replay ou duplo clique;
- o ledger armazenar qualquer conteudo da pesquisa;
- cancelamento ou exclusao perder foco;
- preferencia visual depender de mouse ou executar em `change`.

