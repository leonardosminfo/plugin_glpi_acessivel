<?php

$glpiacessivelHtmlLang = function_exists('glpiacessivel_html_lang') ? glpiacessivel_html_lang() : 'pt-BR';

if (!function_exists('glpiacessivel_login_e')) {
    function glpiacessivel_login_e($value): string
    {
        return htmlspecialchars((string) $value, ENT_QUOTES, 'UTF-8');
    }
}

$t = static fn(string $text): string => glpiacessivel_t($text);
$accessibilityModeLabels = [
    'embedded' => $t('Incorporado'),
    'hybrid' => $t('Híbrido'),
    'standalone' => $t('Independente'),
];
$accessibilityModeKey = (string) ($accessibilityMode ?? 'hybrid');
$accessibilityModeLabel = $accessibilityModeLabels[$accessibilityModeKey] ?? $t('Híbrido');
$loginRuntimeMessages = [
    'themeNightOn' => $t('Tema noturno ativado.'),
    'themeLightOn' => $t('Tema claro ativado.'),
    'contrastOn' => $t('Alto contraste ativado.'),
    'contrastOff' => $t('Alto contraste desativado.'),
    'helpOpened' => $t('Painel de ajuda aberto.'),
    'helpClosed' => $t('Painel de ajuda fechado.'),
    'authenticationInProgress' => $t('Autenticação em andamento. Aguarde o retorno do GLPI.'),
    'fontSizeAdjusted' => $t('Tamanho da fonte ajustado para {percent} por cento.'),
];
?>
<!doctype html>
<html lang="<?= htmlspecialchars($glpiacessivelHtmlLang, ENT_QUOTES, 'UTF-8') ?>">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title><?= glpiacessivel_login_e($t('Portal acessível — Login')) ?></title>
  <link rel="stylesheet" href="<?= glpiacessivel_login_e($css) ?>" />
  <link rel="stylesheet" href="<?= glpiacessivel_login_e($portalCss) ?>" />
</head>
<body class="glpiacessivel-login-page">
  <a class="glpiacessivel-skip-link" href="#login-principal" aria-keyshortcuts="Alt+1"><?= glpiacessivel_login_e($t('Ir para o conteúdo')) ?></a>
  <a class="glpiacessivel-skip-link" href="#glpiacessivel-login-header" aria-keyshortcuts="Alt+2"><?= glpiacessivel_login_e($t('Ir para o menu')) ?></a>
  <a class="glpiacessivel-skip-link" href="#glpiacessivel-login-form" aria-keyshortcuts="Alt+3"><?= glpiacessivel_login_e($t('Ir para o formulário')) ?></a>
  <div id="glpiacessivel-login-live" class="glpiacessivel-sr-only" aria-live="polite" aria-atomic="true"></div>

  <header class="glpiacessivel-login-topbar" aria-label="<?= glpiacessivel_login_e($t('Ferramentas de acessibilidade')) ?>">
    <nav class="glpiacessivel-login-shortcuts" aria-label="<?= glpiacessivel_login_e($t('Atalhos da página')) ?>">
      <a href="#login-principal" aria-keyshortcuts="Alt+1"><?= glpiacessivel_login_e($t('Ir para o conteúdo [1]')) ?></a>
      <a href="#glpiacessivel-login-header" aria-keyshortcuts="Alt+2"><?= glpiacessivel_login_e($t('Ir para o menu [2]')) ?></a>
      <a href="#glpiacessivel-login-form" aria-keyshortcuts="Alt+3"><?= glpiacessivel_login_e($t('Ir para o formulário [3]')) ?></a>
    </nav>
    <div class="glpiacessivel-login-tools" role="toolbar" aria-label="<?= glpiacessivel_login_e($t('Controles de acessibilidade')) ?>">
      <button type="button" class="glpiacessivel-login-tool" data-glpiacessivel-theme aria-pressed="false" aria-keyshortcuts="Alt+T Control+Alt+Shift+T" aria-label="<?= glpiacessivel_login_e($t('Alternar tema claro e noturno')) ?>"><?= glpiacessivel_login_e($t('Tema')) ?></button>
      <button type="button" class="glpiacessivel-login-tool" data-glpiacessivel-contrast aria-pressed="false" aria-keyshortcuts="Alt+C Control+Alt+Shift+K" aria-label="<?= glpiacessivel_login_e($t('Ativar ou desativar alto contraste')) ?>"><?= glpiacessivel_login_e($t('Alto contraste')) ?></button>
      <button type="button" class="glpiacessivel-login-tool" data-glpiacessivel-font="decrease" aria-keyshortcuts="Alt+-" aria-label="<?= glpiacessivel_login_e($t('Diminuir tamanho da fonte')) ?>">A-</button>
      <button type="button" class="glpiacessivel-login-tool" data-glpiacessivel-font="reset" aria-keyshortcuts="Alt+0" aria-label="<?= glpiacessivel_login_e($t('Restaurar tamanho da fonte')) ?>">A</button>
      <button type="button" class="glpiacessivel-login-tool" data-glpiacessivel-font="increase" aria-keyshortcuts="Alt++" aria-label="<?= glpiacessivel_login_e($t('Aumentar tamanho da fonte')) ?>">A+</button>
      <button
        type="button"
        class="glpiacessivel-login-tool"
        data-glpiacessivel-help
        aria-expanded="false"
        aria-controls="glpiacessivel-login-help"
        aria-keyshortcuts="Alt+H Control+Alt+Shift+H"
      ><?= glpiacessivel_login_e($t('Ajuda')) ?></button>
    </div>
  </header>

  <header id="glpiacessivel-login-header" class="glpiacessivel-login-hero" aria-labelledby="login-title">
    <div class="glpiacessivel-login-brand">
      <div class="glpiacessivel-login-brand-icon" aria-hidden="true">
        <?php if (function_exists('plugin_glpiacessivel_portal_icon_markup')): ?>
          <?= plugin_glpiacessivel_portal_icon_markup() ?>
        <?php endif; ?>
      </div>
      <div>
        <h1 id="login-title"><?= glpiacessivel_login_e($t('Portal de Chamados Acessível')) ?></h1>
        <p class="glpiacessivel-login-brand-copy"><?= glpiacessivel_login_e($t('Atendimento institucional acessível')) ?></p>
        <p class="glpiacessivel-login-brand-copy">
          <?= glpiacessivel_login_e(sprintf($t('Modo atual: %s.'), $accessibilityModeLabel)) ?>
          <?= glpiacessivel_login_e($t('Esta entrada acessível usa a mesma autenticação, o mesmo perfil e a mesma entidade do GLPI.')) ?>
        </p>
      </div>
    </div>
  </header>

  <main id="login-principal" class="glpiacessivel-login-shell" tabindex="-1">
    <section class="glpiacessivel-login-panel glpiacessivel-login-panel-form" aria-labelledby="glpiacessivel-form-title">
      <h2 id="glpiacessivel-form-title"><?= glpiacessivel_login_e($t('Acesso ao sistema')) ?></h2>
      <p class="glpiacessivel-login-copy"><?= glpiacessivel_login_e($t('Use o login e a senha da rede.')) ?></p>

      <form method="post" action="<?= glpiacessivel_login_e($loginAction) ?>" class="glpiacessivel-login-form" id="glpiacessivel-login-form">
        <input type="hidden" name="redirect" value="<?= glpiacessivel_login_e($redirect) ?>" />
        <input type="hidden" name="noAUTO" value="<?= glpiacessivel_login_e((string) ($noAuto ?? 0)) ?>" />
        <?php if ($csrfToken !== ''): ?>
          <input type="hidden" name="_glpi_csrf_token" value="<?= glpiacessivel_login_e($csrfToken) ?>" />
        <?php endif; ?>
        <?php if (($loginSource['mode'] ?? 'none') === 'hidden' && !empty($loginSource['value'])): ?>
          <input type="hidden" name="auth" value="<?= glpiacessivel_login_e((string) $loginSource['value']) ?>" />
        <?php endif; ?>
        <p id="login-help"><?= glpiacessivel_login_e($t('A autenticação é realizada pelo GLPI.')) ?></p>
        <label for="login_name"><?= glpiacessivel_login_e($t('Usuário de rede')) ?></label>
        <input id="login_name" name="<?= glpiacessivel_login_e((string) ($loginFieldName ?? 'login_name')) ?>" type="text" autocomplete="username" required aria-describedby="login-help" placeholder="<?= glpiacessivel_login_e($t('Ex.: T212521')) ?>" />

        <label for="login_password"><?= glpiacessivel_login_e($t('Senha')) ?></label>
        <input id="login_password" name="<?= glpiacessivel_login_e((string) ($passwordFieldName ?? 'login_password')) ?>" type="password" autocomplete="current-password" required aria-describedby="login-help" placeholder="<?= glpiacessivel_login_e($t('Sua senha')) ?>" />

        <?php if (($loginSource['mode'] ?? 'none') === 'select' && !empty($loginSource['options'])): ?>
          <label for="auth"><?= glpiacessivel_login_e($t('Origem do login')) ?></label>
          <select id="auth" name="auth" aria-describedby="login-help">
            <?php foreach ($loginSource['options'] as $option): ?>
              <option
                value="<?= glpiacessivel_login_e((string) ($option['value'] ?? '')) ?>"
                <?php if (!empty($option['selected'])): ?> selected<?php endif; ?>
                <?php if (!empty($option['disabled'])): ?> disabled<?php endif; ?>
              ><?= glpiacessivel_login_e((string) ($option['label'] ?? '')) ?></option>
            <?php endforeach; ?>
          </select>
        <?php endif; ?>

        <button type="submit" name="submit"><?= glpiacessivel_login_e($t('Acessar o sistema')) ?></button>
      </form>

      <?php if (!empty($faqUrl ?? '')): ?>
        <div class="glpiacessivel-login-action-stack" aria-label="<?= glpiacessivel_login_e($t('Acessos auxiliares')) ?>">
          <a class="glpiacessivel-button glpiacessivel-button-secondary glpiacessivel-login-secondary-action" href="<?= glpiacessivel_login_e((string) $faqUrl) ?>">
            <?= glpiacessivel_login_e($t('Consultar FAQ pública acessível')) ?>
          </a>
          <p class="glpiacessivel-login-support-copy">
            <?= glpiacessivel_login_e($t('A base de conhecimento pública permite consultar orientações e respostas frequentes sem entrar no GLPI.')) ?>
          </p>
        </div>
      <?php endif; ?>

      <p class="glpiacessivel-login-fallback">
        <?= glpiacessivel_login_e($t('Se a instalação exigir um método adicional de autenticação, acesse também')) ?>
        <a href="<?= glpiacessivel_login_e((string) ($nativeLoginUrl ?? $loginAction)) ?>"><?= glpiacessivel_login_e($t('o login padrão do GLPI')) ?></a>.
      </p>

      <section
        id="glpiacessivel-login-help"
        class="glpiacessivel-login-help"
        aria-labelledby="glpiacessivel-login-help-title"
        role="dialog"
        aria-modal="true"
        tabindex="-1"
        hidden
      >
        <div class="glpiacessivel-help-heading">
          <h3 id="glpiacessivel-login-help-title"><?= glpiacessivel_login_e($t('Ajuda de acessibilidade')) ?></h3>
          <button type="button" class="glpiacessivel-help-close" data-glpiacessivel-help-close aria-label="<?= glpiacessivel_login_e($t('Fechar ajuda')) ?>">X</button>
        </div>
        <p><?= glpiacessivel_login_e($t('Atalhos disponíveis para facilitar a navegação e o uso do portal.')) ?></p>
        <div class="glpiacessivel-shortcut-table-wrap" tabindex="0">
          <table class="glpiacessivel-shortcut-table">
            <thead><tr><th><?= glpiacessivel_login_e($t('Atalho')) ?></th><th><?= glpiacessivel_login_e($t('Ação')) ?></th></tr></thead>
            <tbody>
              <tr><td><kbd>Alt</kbd> + <kbd>1</kbd></td><td><?= glpiacessivel_login_e($t('Ir para o conteúdo principal')) ?></td></tr>
              <tr><td><kbd>Alt</kbd> + <kbd>2</kbd></td><td><?= glpiacessivel_login_e($t('Ir para o menu de navegação')) ?></td></tr>
              <tr><td><kbd>Alt</kbd> + <kbd>3</kbd></td><td><?= glpiacessivel_login_e($t('Ir para o formulário de login')) ?></td></tr>
              <tr><td><kbd>Alt</kbd> + <kbd>C</kbd></td><td><?= glpiacessivel_login_e($t('Alternar alto contraste')) ?></td></tr>
              <tr><td><kbd>Alt</kbd> + <kbd>T</kbd></td><td><?= glpiacessivel_login_e($t('Alternar tema claro ou noturno')) ?></td></tr>
              <tr><td><kbd>Alt</kbd> + <kbd>-</kbd></td><td><?= glpiacessivel_login_e($t('Diminuir tamanho da fonte')) ?></td></tr>
              <tr><td><kbd>Alt</kbd> + <kbd>0</kbd></td><td><?= glpiacessivel_login_e($t('Restaurar tamanho da fonte')) ?></td></tr>
              <tr><td><kbd>Alt</kbd> + <kbd>+</kbd></td><td><?= glpiacessivel_login_e($t('Aumentar tamanho da fonte')) ?></td></tr>
              <tr><td><kbd>Alt</kbd> + <kbd>H</kbd><br><kbd>Ctrl</kbd> + <kbd>Alt</kbd> + <kbd>Shift</kbd> + <kbd>H</kbd></td><td><?= glpiacessivel_login_e($t('Abrir ou fechar a ajuda de acessibilidade')) ?></td></tr>
              <tr><td><kbd>Alt</kbd> + <kbd>A</kbd></td><td><?= glpiacessivel_login_e($t('Abrir a jornada acessível quando estiver no GLPI padrão')) ?></td></tr>
            </tbody>
          </table>
        </div>
        <div class="glpiacessivel-help-notes" aria-label="<?= glpiacessivel_login_e($t('Orientações complementares de acessibilidade')) ?>">
          <section>
            <h4><?= glpiacessivel_login_e($t('Leitores de tela')) ?></h4>
            <p><?= glpiacessivel_login_e($t('Este portal é otimizado para leitores de tela como NVDA, JAWS e VoiceOver.')) ?></p>
            <ul>
              <li><strong><?= glpiacessivel_login_e($t('Regiões da página:')) ?></strong> <?= glpiacessivel_login_e($t('use as teclas de navegação rápida do leitor de tela, como R no NVDA, para percorrer as seções.')) ?></li>
              <li><strong><?= glpiacessivel_login_e($t('Títulos:')) ?></strong> <?= glpiacessivel_login_e($t('use H para navegar pelos títulos.')) ?></li>
              <li><strong><?= glpiacessivel_login_e($t('Tabelas:')) ?></strong> <?= glpiacessivel_login_e($t('navegue pelas células com os comandos de tabela do leitor, como Ctrl+Alt+Setas, quando houver suporte.')) ?></li>
              <li><strong><?= glpiacessivel_login_e($t('Formulários:')) ?></strong> <?= glpiacessivel_login_e($t('os campos obrigatórios são anunciados como obrigatórios.')) ?></li>
            </ul>
          </section>
          <section>
            <h4><?= glpiacessivel_login_e($t('Recursos visuais')) ?></h4>
            <ul>
              <li><strong><?= glpiacessivel_login_e($t('Modo escuro:')) ?></strong> <?= glpiacessivel_login_e($t('ative pelo botão Tema, por Alt+T ou por Ctrl+Alt+Shift+T.')) ?></li>
              <li><strong><?= glpiacessivel_login_e($t('Alto contraste:')) ?></strong> <?= glpiacessivel_login_e($t('ative pela barra de acessibilidade, por Alt+C ou por Ctrl+Alt+Shift+K.')) ?></li>
              <li><strong><?= glpiacessivel_login_e($t('Foco visível:')) ?></strong> <?= glpiacessivel_login_e($t('bordas destacadas indicam o elemento ativo.')) ?></li>
              <li><strong><?= glpiacessivel_login_e($t('VLibras:')) ?></strong> <?= glpiacessivel_login_e($t('tradução automática para a Língua Brasileira de Sinais, quando habilitada.')) ?></li>
            </ul>
          </section>
        </div>
        <div class="glpiacessivel-help-footer">
          <button type="button" class="glpiacessivel-button glpiacessivel-button-primary" data-glpiacessivel-help-close><?= glpiacessivel_login_e($t('Fechar')) ?></button>
        </div>
      </section>
    </section>
  </main>
  <script src="<?= glpiacessivel_login_e((string) ($runtimeConfigJs ?? '')) ?>" data-glpiacessivel-runtime-config="1"></script>
  <script src="<?= glpiacessivel_login_e((string) ($globalJs ?? '')) ?>"></script>
  <script>
    (function () {
      var messages = <?= json_encode($loginRuntimeMessages, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) ?>;
      var body = document.body;
      var liveRegion = document.getElementById('glpiacessivel-login-live');
      var storageKey = 'glpiacessivel-login-preferences-v2';
      var defaultPrefs = {
        theme: 'light',
        contrast: false,
        fontScale: 1
      };
      var themeButton = document.querySelector('button[data-glpiacessivel-theme], [role="button"][data-glpiacessivel-theme]');
      var contrastButton = document.querySelector('button[data-glpiacessivel-contrast], [role="button"][data-glpiacessivel-contrast]');
      var helpButton = document.querySelector('button[data-glpiacessivel-help], [role="button"][data-glpiacessivel-help]');
      var helpPanel = document.getElementById('glpiacessivel-login-help');
      var helpCloseButtons = document.querySelectorAll('[data-glpiacessivel-help-close]');
      var loginForm = document.getElementById('glpiacessivel-login-form');

      function readPrefs() {
        try {
          var saved = window.localStorage.getItem(storageKey);
          if (!saved) {
            return {
              theme: defaultPrefs.theme,
              contrast: defaultPrefs.contrast,
              fontScale: defaultPrefs.fontScale
            };
          }

          var parsed = JSON.parse(saved);
          return {
            theme: parsed.theme === 'night' ? 'night' : 'light',
            contrast: parsed.contrast === true,
            fontScale: parsed.fontScale === 0.9 || parsed.fontScale === 1.1 || parsed.fontScale === 1.2 ? parsed.fontScale : 1
          };
        } catch (error) {
          return {
            theme: defaultPrefs.theme,
            contrast: defaultPrefs.contrast,
            fontScale: defaultPrefs.fontScale
          };
        }
      }

      function writePrefs(prefs) {
        try {
          window.localStorage.setItem(storageKey, JSON.stringify(prefs));
        } catch (error) {
          // Ignore storage restrictions on privacy modes.
        }
      }

      function announce(message) {
        if (liveRegion) {
          liveRegion.textContent = message;
        }
      }

      function applyPrefs(prefs) {
        body.dataset.glpiacessivelTheme = prefs.theme;
        body.dataset.glpiacessivelContrast = prefs.contrast ? 'high' : 'default';
        body.style.fontSize = prefs.fontScale + 'rem';

        if (contrastButton) {
          contrastButton.setAttribute('aria-pressed', prefs.contrast ? 'true' : 'false');
        }

        if (themeButton) {
          themeButton.setAttribute('aria-pressed', prefs.theme === 'night' ? 'true' : 'false');
        }
      }

      var helpLastFocus = null;

      function getHelpFocusableElements() {
        if (!helpPanel) {
          return [];
        }
        return Array.prototype.slice.call(helpPanel.querySelectorAll('a[href], button:not([disabled]), textarea:not([disabled]), input:not([disabled]), select:not([disabled]), [tabindex]:not([tabindex="-1"])'))
          .filter(function (element) {
            return element instanceof HTMLElement && !element.hidden && element.offsetParent !== null;
          });
      }

      function setHelpBackgroundInert(open) {
        var targets = [
          document.querySelector('.glpiacessivel-login-topbar'),
          document.getElementById('glpiacessivel-login-header')
        ];
        var parent = helpPanel ? helpPanel.parentElement : null;
        if (parent) {
          Array.prototype.slice.call(parent.children).forEach(function (element) {
            if (element !== helpPanel) {
              targets.push(element);
            }
          });
        }

        targets.forEach(function (element) {
          if (!(element instanceof HTMLElement)) {
            return;
          }
          if (open) {
            element.setAttribute('inert', '');
          } else {
            element.removeAttribute('inert');
          }
        });
      }

      function setHelpOpen(open) {
        if (!helpButton || !helpPanel) {
          return;
        }

        if (open) {
          helpLastFocus = document.activeElement instanceof HTMLElement ? document.activeElement : helpButton;
        }
        helpButton.setAttribute('aria-expanded', open ? 'true' : 'false');
        helpPanel.hidden = !open;

        if (open) {
          var closeButton = helpPanel.querySelector('[data-glpiacessivel-help-close]');
          if (closeButton) {
            closeButton.focus();
          } else {
            helpPanel.focus();
          }
          setHelpBackgroundInert(true);
        } else {
          setHelpBackgroundInert(false);
          if (helpLastFocus && typeof helpLastFocus.focus === 'function') {
            helpLastFocus.focus();
          }
        }
      }

      function announceExternal(externalLiveRegion, message) {
        announce(message);
        if (externalLiveRegion && externalLiveRegion !== liveRegion && 'textContent' in externalLiveRegion) {
          externalLiveRegion.textContent = message;
        }
      }

      window.glpiacessivelToggleTheme = function (externalLiveRegion) {
        if (!themeButton) {
          return false;
        }
        var contrastWasActive = prefs.contrast;
        if (contrastWasActive) {
          prefs.contrast = false;
        }
        prefs.theme = prefs.theme === 'light' ? 'night' : 'light';
        applyPrefs(prefs);
        writePrefs(prefs);
        var message = (prefs.theme === 'night' ? messages.themeNightOn : messages.themeLightOn) + (contrastWasActive ? ' ' + messages.contrastOff : '');
        announceExternal(externalLiveRegion, message);
        themeButton.focus();
        return true;
      };

      window.glpiacessivelToggleContrast = function (externalLiveRegion) {
        if (!contrastButton) {
          return false;
        }
        prefs.contrast = !prefs.contrast;
        applyPrefs(prefs);
        writePrefs(prefs);
        var message = prefs.contrast ? messages.contrastOn : messages.contrastOff;
        announceExternal(externalLiveRegion, message);
        contrastButton.focus();
        return true;
      };

      window.glpiacessivelToggleHelp = function (externalLiveRegion) {
        if (!helpButton || !helpPanel) {
          return false;
        }
        var isOpen = helpButton.getAttribute('aria-expanded') === 'true';
        setHelpOpen(!isOpen);
        var message = !isOpen ? messages.helpOpened : messages.helpClosed;
        announce(message);
        if (externalLiveRegion && externalLiveRegion !== liveRegion && 'textContent' in externalLiveRegion) {
          externalLiveRegion.textContent = message;
        }
        return true;
      };
      if (loginForm) {
        loginForm.addEventListener('submit', function () {
          announce(messages.authenticationInProgress);
        });
      }


      var prefs = readPrefs();
      applyPrefs(prefs);

      if (themeButton) {
        themeButton.addEventListener('click', function () {
          window.glpiacessivelToggleTheme();
        });
      }

      if (contrastButton) {
        contrastButton.addEventListener('click', function () {
          window.glpiacessivelToggleContrast();
        });
      }

      Array.prototype.slice.call(document.querySelectorAll('[data-glpiacessivel-font]')).forEach(function (button) {
        button.addEventListener('click', function () {
          var action = button.getAttribute('data-glpiacessivel-font');
          if (action === 'increase') {
            prefs.fontScale = Math.min(1.2, prefs.fontScale + 0.1);
          } else if (action === 'decrease') {
            prefs.fontScale = Math.max(0.9, prefs.fontScale - 0.1);
          } else {
            prefs.fontScale = 1;
          }

          applyPrefs(prefs);
          writePrefs(prefs);
          announce(messages.fontSizeAdjusted.replace('{percent}', String(Math.round(prefs.fontScale * 100))));
        });
      });

      if (helpButton && helpPanel) {
        helpButton.addEventListener('click', function () {
          var isOpen = helpButton.getAttribute('aria-expanded') === 'true';
          setHelpOpen(!isOpen);
          announce(!isOpen ? messages.helpOpened : messages.helpClosed);
        });

        helpPanel.addEventListener('keydown', function (event) {
          if (event.key === 'Escape') {
            event.preventDefault();
            setHelpOpen(false);
            announce(messages.helpClosed);
            return;
          }

          if (event.key !== 'Tab') {
            return;
          }

          var focusable = getHelpFocusableElements();
          if (focusable.length === 0) {
            event.preventDefault();
            helpPanel.focus();
            return;
          }

          var first = focusable[0];
          var last = focusable[focusable.length - 1];
          if (event.shiftKey && document.activeElement === first) {
            event.preventDefault();
            last.focus();
          } else if (!event.shiftKey && document.activeElement === last) {
            event.preventDefault();
            first.focus();
          }
        });

        Array.prototype.slice.call(helpCloseButtons).forEach(function (button) {
          button.addEventListener('click', function () {
            setHelpOpen(false);
            announce(messages.helpClosed);
          });
        });
      }
    })();
  </script>
</body>
</html>
