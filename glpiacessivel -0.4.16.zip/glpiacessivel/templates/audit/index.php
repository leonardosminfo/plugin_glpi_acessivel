<?php

$rows = is_array($rows ?? null) ? $rows : [];
$filters = is_array($filters ?? null) ? $filters : [];
$auditModeLabels = [
    'full' => glpiacessivel_t('Completa'),
    'critical' => glpiacessivel_t('Essencial'),
    'disabled' => glpiacessivel_t('Desativada'),
];
?>
<section class="glpiacessivel-card" aria-labelledby="audit-overview-title">
  <h2 id="audit-overview-title"><?= glpiacessivel_e(glpiacessivel_t('Trilha de auditoria operacional')) ?></h2>
  <p><?= glpiacessivel_e(glpiacessivel_t('Esta trilha contém metadados pessoais e de segurança. Consulte-a somente para suporte autorizado, investigação de incidente ou conformidade. Consultas e exportações também ficam registradas.')) ?></p>
  <dl class="glpiacessivel-definition-list">
    <dt><?= glpiacessivel_e(glpiacessivel_t('Modo atual')) ?></dt>
    <dd><?= glpiacessivel_e($auditModeLabels[$audit_mode ?? 'critical'] ?? (string) ($audit_mode ?? 'critical')) ?></dd>
    <dt><?= glpiacessivel_e(glpiacessivel_t('Escopo')) ?></dt>
    <dd><?= glpiacessivel_e(glpiacessivel_t('Perfil, entidade ativa, recursividade e leitura nativa do objeto no GLPI.')) ?></dd>
  </dl>
  <?php if (($audit_mode ?? 'critical') === 'critical'): ?>
    <p class="glpiacessivel-alert glpiacessivel-alert-info" role="status"><?= glpiacessivel_e(glpiacessivel_t('O modo essencial não registra leituras rotineiras. A ausência desses eventos é esperada.')) ?></p>
  <?php elseif (($audit_mode ?? '') === 'disabled'): ?>
    <p class="glpiacessivel-alert glpiacessivel-alert-warning" role="status"><?= glpiacessivel_e(glpiacessivel_t('A auditoria de novos eventos está desativada. Registros históricos permanecem até sua expiração.')) ?></p>
  <?php endif; ?>
</section>

<section class="glpiacessivel-card" aria-labelledby="audit-filter-title">
  <h2 id="audit-filter-title"><?= glpiacessivel_e(glpiacessivel_t('Filtrar registros autorizados')) ?></h2>
  <form method="get" action="<?= glpiacessivel_e(glpiacessivel_url('front/audit.php')) ?>">
    <fieldset class="glpiacessivel-form-fieldset">
      <legend><?= glpiacessivel_e(glpiacessivel_t('Período e identificação')) ?></legend>
      <div class="glpiacessivel-form-grid">
        <div class="glpiacessivel-field">
          <label for="audit-from"><?= glpiacessivel_e(glpiacessivel_t('Data inicial')) ?></label>
          <input id="audit-from" name="from" type="date" value="<?= glpiacessivel_e((string) ($from ?? '')) ?>" required />
        </div>
        <div class="glpiacessivel-field">
          <label for="audit-to"><?= glpiacessivel_e(glpiacessivel_t('Data final')) ?></label>
          <input id="audit-to" name="to" type="date" value="<?= glpiacessivel_e((string) ($to ?? '')) ?>" required />
        </div>
        <div class="glpiacessivel-field">
          <label for="audit-action"><?= glpiacessivel_e(glpiacessivel_t('Código exato do evento')) ?></label>
          <input id="audit-action" name="action" type="text" maxlength="120" value="<?= glpiacessivel_e((string) ($filters['action'] ?? '')) ?>" />
        </div>
        <div class="glpiacessivel-field">
          <label for="audit-ticket"><?= glpiacessivel_e(glpiacessivel_t('Número do chamado')) ?></label>
          <input id="audit-ticket" name="ticket_id" type="number" min="1" value="<?= (int) ($filters['ticket_id'] ?? 0) ?: '' ?>" />
        </div>
        <div class="glpiacessivel-field">
          <label for="audit-user"><?= glpiacessivel_e(glpiacessivel_t('Identificador do usuário')) ?></label>
          <input id="audit-user" name="user_id" type="number" min="1" value="<?= (int) ($filters['user_id'] ?? 0) ?: '' ?>" />
        </div>
      </div>
    </fieldset>
    <button type="submit"><?= glpiacessivel_e(glpiacessivel_t('Aplicar filtros')) ?></button>
  </form>
</section>

<section class="glpiacessivel-card" aria-labelledby="audit-results-title">
  <h2 id="audit-results-title"><?= glpiacessivel_e(glpiacessivel_t('Registros encontrados')) ?></h2>
  <p role="status" aria-live="polite"><?= glpiacessivel_e(sprintf(glpiacessivel_t('%d registros autorizados nesta página.'), count($rows))) ?></p>
  <?php if ($rows === []): ?>
    <p><?= glpiacessivel_e(glpiacessivel_t('Nenhum registro autorizado foi encontrado para os filtros informados.')) ?></p>
  <?php else: ?>
    <div class="glpiacessivel-table-wrap" role="region" aria-label="<?= glpiacessivel_e(glpiacessivel_t('Resultados da auditoria')) ?>" tabindex="0">
      <table class="glpiacessivel-table">
        <caption><?= glpiacessivel_e(glpiacessivel_t('Metadados sanitizados da trilha persistente')) ?></caption>
        <thead><tr>
          <th scope="col"><?= glpiacessivel_e(glpiacessivel_t('Data e hora')) ?></th>
          <th scope="col"><?= glpiacessivel_e(glpiacessivel_t('Evento')) ?></th>
          <th scope="col"><?= glpiacessivel_e(glpiacessivel_t('Resultado')) ?></th>
          <th scope="col"><?= glpiacessivel_e(glpiacessivel_t('Chamado')) ?></th>
          <th scope="col"><?= glpiacessivel_e(glpiacessivel_t('Entidade')) ?></th>
          <th scope="col"><?= glpiacessivel_e(glpiacessivel_t('Usuário')) ?></th>
        </tr></thead>
        <tbody>
        <?php foreach ($rows as $row): ?>
          <tr>
            <td><?= glpiacessivel_e((string) ($row['created_at'] ?? '')) ?></td>
            <td><?= glpiacessivel_e((string) ($row['action_label'] ?? '')) ?></td>
            <td><?= glpiacessivel_e((string) ($row['result'] ?? '')) ?></td>
            <td><?= (int) ($row['tickets_id'] ?? 0) ?: glpiacessivel_e(glpiacessivel_t('Não se aplica')) ?></td>
            <td><?= (int) ($row['entities_id'] ?? 0) ?></td>
            <td><?= (int) ($row['users_id'] ?? 0) ?></td>
          </tr>
        <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  <?php endif; ?>

  <div class="glpiacessivel-actions">
    <?php if (!empty($has_more) && !empty($next_cursor)): ?>
      <?php $nextQuery = http_build_query(array_filter($filters + ['from' => $from ?? '', 'to' => $to ?? '', 'cursor' => $next_cursor], static fn($value): bool => $value !== '' && $value !== 0)); ?>
      <a class="glpiacessivel-button glpiacessivel-button-secondary" href="<?= glpiacessivel_e(glpiacessivel_url('front/audit.php?' . $nextQuery)) ?>"><?= glpiacessivel_e(glpiacessivel_t('Próxima página')) ?></a>
    <?php endif; ?>
    <?php if (!empty($can_export)): ?>
      <form method="post" action="<?= glpiacessivel_e(glpiacessivel_url('front/audit.export.php')) ?>">
        <input type="hidden" name="_glpi_csrf_token" value="<?= glpiacessivel_e((string) ($csrf_token ?? '')) ?>" />
        <?php foreach ($filters as $key => $value): ?>
          <input type="hidden" name="<?= glpiacessivel_e((string) $key) ?>" value="<?= glpiacessivel_e((string) $value) ?>" />
        <?php endforeach; ?>
        <button type="submit" class="glpiacessivel-button glpiacessivel-button-secondary"><?= glpiacessivel_e(glpiacessivel_t('Exportar até 100 registros autorizados')) ?></button>
      </form>
    <?php endif; ?>
  </div>
</section>
