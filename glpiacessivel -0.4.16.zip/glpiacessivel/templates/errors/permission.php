<section class="glpiacessivel-section-head" aria-labelledby="permission-error-title">
  <p class="glpiacessivel-eyebrow"><?= glpiacessivel_e(__('Acesso restrito', 'glpiacessivel')) ?></p>
  <h2 id="permission-error-title"><?= glpiacessivel_e((string) ($title ?? __('Sem permissão', 'glpiacessivel'))) ?></h2>
  <p><?= glpiacessivel_e((string) ($message ?? __('Seu perfil atual não possui permissão para acessar esta funcionalidade.', 'glpiacessivel'))) ?></p>
</section>

<section
  class="glpiacessivel-alert glpiacessivel-alert-warning"
  role="region"
  aria-labelledby="permission-alert-title"
  aria-describedby="permission-alert-message"
>
  <h3 id="permission-alert-title" tabindex="-1" data-glpiacessivel-focus-alert><?= glpiacessivel_e((string) ($alert_title ?? __('Permissão necessária', 'glpiacessivel'))) ?></h3>
  <p id="permission-alert-message"><?= glpiacessivel_e((string) ($alert_message ?? __('As permissões do seu perfil no GLPI não permitem esta ação.', 'glpiacessivel'))) ?></p>
  <p>
    <a class="glpiacessivel-button glpiacessivel-button-secondary" href="<?= glpiacessivel_e((string) ($return_url ?? glpiacessivel_url('front/acessivel.php'))) ?>"><?= glpiacessivel_e(__('Voltar ao portal acessível', 'glpiacessivel')) ?></a>
  </p>
</section>
