(function () {
  'use strict';

  const LABEL_KEYS = {
    id: 'ticket.column.id', name: 'ticket.column.title', status: 'ticket.column.status',
    priority: 'ticket.column.priority', group: 'ticket.column.group',
    requester: 'ticket.column.requester', assignee: 'ticket.column.assignee',
    category: 'ticket.column.category', entity: 'ticket.column.entity',
    location: 'ticket.column.location', date: 'ticket.column.opened_at',
    date_mod: 'ticket.column.updated_at', time_to_resolve: 'ticket.column.resolve_by'
  };

  const i18n = window.__glpiacessivelI18n && window.__glpiacessivelI18n.messages
    ? window.__glpiacessivelI18n.messages
    : null;

  function message(key, replacements) {
    if (!i18n || typeof i18n[key] !== 'string' || i18n[key] === '') {
      return '';
    }
    let value = i18n[key];
    Object.keys(replacements || {}).forEach(function (name) {
      value = value.split('{' + name + '}').join(String(replacements[name]));
    });
    return value;
  }

  function readConfig() {
    const node = document.querySelector('[data-glpiacessivel-ticket-results-config]');
    if (!(node instanceof HTMLScriptElement)) {
      return { config: null, error: 'config_missing' };
    }
    try {
      const config = JSON.parse(node.textContent || '{}');
      return config && config.enabled === true
        ? { config: config, error: '' }
        : { config: null, error: 'config_disabled' };
    } catch (error) {
      return { config: null, error: 'config_invalid' };
    }
  }

  function textCell(value) {
    const cell = document.createElement('td');
    cell.textContent = String(value == null ? '' : value);
    return cell;
  }

  function detailLink(item, button) {
    const link = document.createElement('a');
    link.href = String(item.detail_url || '#');
    link.className = button
      ? 'glpiacessivel-button glpiacessivel-button-secondary'
      : 'glpiacessivel-ticket-title-link';
    link.textContent = button ? message('ticket.action.open') : String(item.name || '');
    if (button) {
      link.setAttribute('aria-label', message('ticket.action.open_named', {
        id: String(item.id || ''),
        title: String(item.name || '')
      }));
    }
    return link;
  }

  function badgeCell(item, field) {
    const cell = document.createElement('td');
    const badge = document.createElement('span');
    const kind = field === 'status' ? 'status' : 'priority';
    badge.className = 'glpiacessivel-badge glpiacessivel-badge-' + kind + '-' + String(item[field + '_class'] || 'neutral');
    badge.textContent = String(item[field + '_label'] || item[field] || '');
    cell.appendChild(badge);
    return cell;
  }

  function ticketRow(item, columns, showGroup, onSelection) {
    const row = document.createElement('tr');
    const selectCell = document.createElement('td');
    const checkbox = document.createElement('input');
    checkbox.type = 'checkbox';
    checkbox.className = 'glpiacessivel-ticket-select';
    checkbox.value = String(item.id || '');
    checkbox.setAttribute('aria-label', message('ticket.action.select', { id: String(item.id || '') }));
    checkbox.addEventListener('change', onSelection);
    selectCell.appendChild(checkbox);
    row.appendChild(selectCell);

    columns.forEach(function (column) {
      if (!showGroup && column === 'group') {
        return;
      }
      if (column === 'name') {
        const cell = document.createElement('td');
        cell.appendChild(detailLink(item, false));
        row.appendChild(cell);
      } else if (column === 'status' || column === 'priority') {
        row.appendChild(badgeCell(item, column));
      } else {
        const values = {
          id: item.id,
          group: item.primary_group_name || message('ticket.value.no_group'),
          requester: item.requester_name,
          assignee: item.assignee_name,
          category: item.category_name,
          entity: item.entity_name,
          location: item.location_name,
          date: item.date,
          date_mod: item.date_mod,
          time_to_resolve: item.time_to_resolve
        };
        row.appendChild(textCell(values[column]));
      }
    });

    const actionCell = document.createElement('td');
    actionCell.appendChild(detailLink(item, true));
    row.appendChild(actionCell);
    return row;
  }

  function ticketTable(items, columns, showGroup, labelledBy, onSelection) {
    const wrap = document.createElement('div');
    wrap.className = 'glpiacessivel-table-wrap';
    wrap.setAttribute('role', 'region');
    wrap.setAttribute('tabindex', '0');
    if (labelledBy) {
      wrap.setAttribute('aria-labelledby', labelledBy);
    } else {
      wrap.setAttribute('aria-label', message('ticket.table.label'));
    }
    const table = document.createElement('table');
    table.className = 'tab_cadre_fixehov glpiacessivel-ticket-table';
    const caption = document.createElement('caption');
    caption.className = 'glpiacessivel-sr-only';
    caption.textContent = message('ticket.table.caption');
    table.appendChild(caption);
    const head = document.createElement('thead');
    const headRow = document.createElement('tr');
    const selectionHead = document.createElement('th');
    selectionHead.scope = 'col';
    const selectionLabel = document.createElement('span');
    selectionLabel.className = 'glpiacessivel-sr-only';
    selectionLabel.textContent = message('ticket.action.select_short');
    selectionHead.appendChild(selectionLabel);
    headRow.appendChild(selectionHead);
    columns.forEach(function (column) {
      if (!showGroup && column === 'group') {
        return;
      }
      const cell = document.createElement('th');
      cell.scope = 'col';
      cell.textContent = message(LABEL_KEYS[column]) || column;
      headRow.appendChild(cell);
    });
    const actionHead = document.createElement('th');
    actionHead.scope = 'col';
    actionHead.textContent = message('ticket.column.action');
    headRow.appendChild(actionHead);
    head.appendChild(headRow);
    table.appendChild(head);
    const body = document.createElement('tbody');
    items.forEach(function (item) {
      body.appendChild(ticketRow(item, columns, showGroup, onSelection));
    });
    table.appendChild(body);
    wrap.appendChild(table);
    return wrap;
  }

  function renderItems(container, result, config, onSelection) {
    const items = Array.isArray(result.items) ? result.items : [];
    const backendReason = String(result.backend_reason || '');
    container.replaceChildren();
    if (items.length === 0) {
      if (backendReason === 'group_scope_without_current_groups') {
        return;
      }
      const empty = document.createElement('div');
      empty.className = 'glpiacessivel-empty';
      const messageNode = document.createElement('p');
      messageNode.textContent = message('ticket.results.empty');
      empty.appendChild(messageNode);
      container.appendChild(empty);
      return;
    }

    const columns = Array.isArray(config.columns) ? config.columns.map(String) : ['id', 'name', 'status', 'priority', 'group', 'date_mod'];
    if (config.group_by === 'group') {
      const groups = new Map();
      items.forEach(function (item) {
        const label = String(item.primary_group_name || message('ticket.value.no_group'));
        if (!groups.has(label)) {
          groups.set(label, []);
        }
        groups.get(label).push(item);
      });
      const grouped = document.createElement('div');
      grouped.className = 'glpiacessivel-ticket-grouped';
      Array.from(groups.keys()).sort(function (a, b) { return a.localeCompare(b, 'pt-BR'); }).forEach(function (label, index) {
        const section = document.createElement('section');
        section.className = 'glpiacessivel-ticket-group';
        const heading = document.createElement('h3');
        heading.id = 'tickets-grupo-async-' + String(index);
        heading.textContent = label + ' (' + message('ticket.group.count_on_page', {
          count: groups.get(label).length
        }) + ')';
        section.setAttribute('aria-labelledby', heading.id);
        section.appendChild(heading);
        section.appendChild(ticketTable(groups.get(label), columns, false, heading.id, onSelection));
        grouped.appendChild(section);
      });
      container.appendChild(grouped);
      return;
    }
    container.appendChild(ticketTable(items, columns, true, '', onSelection));
  }

  function pageUrl(page) {
    const url = new URL(window.location.href);
    url.searchParams.set('page', String(page));
    url.searchParams.set('focus', 'results');
    return url.pathname + '?' + url.searchParams.toString();
  }

  function paginationEntry(labelText, targetPage, enabled) {
    if (enabled) {
      const link = document.createElement('a');
      link.href = pageUrl(targetPage);
      link.textContent = labelText;
      return link;
    }
    const disabled = document.createElement('span');
    disabled.setAttribute('aria-disabled', 'true');
    disabled.textContent = labelText;
    return disabled;
  }

  function renderPagination(node, result, contractVersion) {
    const page = result.page;
    node.replaceChildren();
    node.hidden = false;
    const label = document.createElement('span');
    label.textContent = contractVersion === 1
      ? message('pagination.page_of', { page: page, pages: result.pages })
      : message('pagination.page', { page: page });
    node.appendChild(label);
    node.appendChild(paginationEntry(message('pagination.first'), 1, result.has_previous));
    node.appendChild(paginationEntry(message('pagination.previous'), page - 1, result.has_previous));
    const current = document.createElement('span');
    current.setAttribute('aria-current', 'page');
    current.textContent = message('pagination.current', { page: page });
    node.appendChild(current);
    node.appendChild(paginationEntry(message('pagination.next'), page + 1, result.has_more));
    if (contractVersion === 1) {
      node.appendChild(paginationEntry(message('pagination.last'), result.pages, page < result.pages));
    }
  }

  function isNonNegativeInteger(value) {
    return Number.isInteger(value) && value >= 0;
  }

  function normalizeResult(result, contractVersion) {
    if (!result || typeof result !== 'object' || Array.isArray(result)) {
      throw new Error('invalid_response');
    }
    if (!Array.isArray(result.items) || !Number.isInteger(result.page) || result.page < 1
      || !Number.isInteger(result.page_size) || result.page_size < 1 || result.items.length > result.page_size) {
      throw new Error('invalid_response');
    }
    if (contractVersion === 1) {
      if (!isNonNegativeInteger(result.total) || !Number.isInteger(result.pages) || result.pages < 1) {
        throw new Error('invalid_response');
      }
      return Object.assign({}, result, {
        total_state: 'exact',
        has_previous: result.page > 1,
        has_more: result.page < result.pages
      });
    }
    if (result.page_size > 50 || result.items.some(function (item) {
      return !item || typeof item !== 'object' || Array.isArray(item);
    })) {
      throw new Error('invalid_response');
    }
    const totalStates = ['deferred', 'pending', 'exact', 'unavailable', 'lower_bound'];
    if (typeof result.has_previous !== 'boolean' || typeof result.has_more !== 'boolean'
      || !totalStates.includes(result.total_state)) {
      throw new Error('invalid_response');
    }
    if (result.has_previous !== (result.page > 1) || (result.items.length === 0 && result.has_more)) {
      throw new Error('invalid_response');
    }
    if (result.total_state === 'exact' || result.total_state === 'lower_bound') {
      if (!isNonNegativeInteger(result.total)) {
        throw new Error('invalid_response');
      }
      const lastItem = result.items.length > 0
        ? ((result.page - 1) * result.page_size) + result.items.length
        : 0;
      if (result.total < lastItem) {
        throw new Error('invalid_response');
      }
    } else if (result.total !== null) {
      throw new Error('invalid_response');
    }
    return result;
  }

  function initializeSynchronousRetry() {
    const retry = document.querySelector('[data-glpiacessivel-sync-retry]');
    if (!(retry instanceof HTMLButtonElement)) {
      return false;
    }
    if (retry.dataset.glpiacessivelInitialized === '1') {
      return true;
    }
    retry.dataset.glpiacessivelInitialized = '1';
    const countdown = document.getElementById('tickets-sync-retry-countdown');
    const readyStatus = document.getElementById('tickets-sync-retry-ready');
    const retryUrl = String(retry.dataset.retryUrl || '');
    const singular = String(retry.dataset.waitSingular || '');
    const plural = String(retry.dataset.waitPlural || '');
    const readyMessage = String(retry.dataset.readyMessage || '');
    let remaining = Math.min(3600, Math.max(0, Number(retry.dataset.retryAfter || 0)));

    const markReady = function () {
      retry.disabled = false;
      if (countdown instanceof HTMLElement) {
        countdown.textContent = '';
      }
      if (readyStatus instanceof HTMLElement) {
        readyStatus.textContent = readyMessage;
      }
    };
    const updateCountdown = function () {
      if (remaining <= 0) {
        markReady();
        return false;
      }
      if (countdown instanceof HTMLElement) {
        const template = remaining === 1 ? singular : plural;
        countdown.textContent = template.replace('%d', String(remaining));
      }
      return true;
    };

    retry.addEventListener('click', function () {
      if (!retry.disabled && retryUrl) {
        window.location.assign(retryUrl);
      }
    });
    if (!updateCountdown()) {
      return true;
    }
    const timer = window.setInterval(function () {
      remaining -= 1;
      if (!updateCountdown()) {
        window.clearInterval(timer);
      }
    }, 1000);
    return true;
  }

  function start() {
    const synchronousRetry = initializeSynchronousRetry();
    if (synchronousRetry && !document.querySelector('[data-glpiacessivel-ticket-results-config]')) {
      return;
    }
    const section = document.querySelector('[data-glpiacessivel-ticket-results]');
    const content = document.querySelector('[data-glpiacessivel-ticket-results-content]');
    const summary = document.querySelector('[data-glpiacessivel-ticket-results-summary]');
    const totalStatus = document.querySelector('[data-glpiacessivel-ticket-results-total]');
    const pagination = document.querySelector('[data-glpiacessivel-ticket-results-pagination]');
    const selectionSummary = document.querySelector('[data-glpiacessivel-selection-summary]');
    const selectedCount = document.querySelector('[data-glpiacessivel-selected-count]');
    const selectionStatus = document.querySelector('[data-glpiacessivel-selection-status]');
    const copyButton = document.querySelector('[data-glpiacessivel-copy-selected]');
    if (!(section instanceof HTMLElement) || !(content instanceof HTMLElement)) {
      return;
    }
    if (!i18n || !message('ticket.table.caption')) {
      return;
    }
    if (section.dataset.glpiacessivelAsyncStarted === '1') {
      return;
    }
    section.dataset.glpiacessivelAsyncStarted = '1';
    section.removeAttribute('aria-busy');

    const parsed = readConfig();
    const config = parsed.config;
    const nativeFallbackUrl = String(
      (config && config.native_fallback_url)
      || section.dataset.nativeFallbackUrl
      || '/front/ticket.php'
    );
    const configuredPage = Number(config && config.page);
    const queryPage = Number(new URL(window.location.href).searchParams.get('page'));
    const currentPage = Number.isInteger(configuredPage) && configuredPage > 0
      ? configuredPage
      : (Number.isInteger(queryPage) && queryPage > 0 ? queryPage : 1);
    if (summary instanceof HTMLElement && !summary.id) {
      summary.id = 'tickets-results-status';
    }

    function failureMessage(code) {
      const messages = {
        session_expired: 'ticket.error.session_expired',
        forbidden: 'ticket.error.forbidden',
        context_stale: 'ticket.error.context_stale',
        state_expired: 'ticket.error.state_expired',
        invalid_request: 'ticket.error.invalid_request',
        invalid_security_token: 'ticket.error.invalid_security_token',
        rate_limited: 'ticket.error.rate_limited',
        capacity_limited: 'ticket.error.capacity_limited',
        capacity_unavailable: 'ticket.error.capacity_unavailable',
        bounded_search_execution_unavailable: 'ticket.error.unavailable',
        bounded_search_execution_failed: 'ticket.error.unavailable',
        bounded_search_plan_failed: 'ticket.error.unavailable',
        unavailable: 'ticket.error.unavailable',
        temporarily_unavailable: 'ticket.error.unavailable',
        origin_not_allowed: 'ticket.error.origin_not_allowed',
        timed_out: 'ticket.error.timed_out',
        config_invalid: 'ticket.error.config_invalid',
        config_missing: 'ticket.error.config_missing',
        contract_upgrade_required: 'ticket.error.contract_upgrade_required',
        bounded_search_offset_limit_exceeded: 'ticket.error.bounded_offset_exceeded',
        unexpected_content_type: 'ticket.error.unexpected_content_type',
        invalid_response: 'ticket.error.invalid_response'
      };
      return message(messages[code] || 'ticket.error.generic', { page: currentPage });
    }

    let generation = 0;
    let retryTimer = 0;
    function setSummary(value, accessibleDetail) {
      if (!summary) {
        return;
      }
      const detail = String(accessibleDetail || '');
      const announcement = detail ? value + ' ' + detail : value;
      if (summary.dataset.glpiacessivelAnnouncement === announcement) {
        return;
      }
      const nodes = [document.createTextNode(value)];
      if (detail) {
        const detailNode = document.createElement('span');
        detailNode.className = 'glpiacessivel-sr-only';
        detailNode.textContent = ' ' + detail;
        nodes.push(detailNode);
      }
      summary.replaceChildren.apply(summary, nodes);
      summary.dataset.glpiacessivelAnnouncement = announcement;
    }

    function clearRetryTimer() {
      if (retryTimer) {
        window.clearInterval(retryTimer);
        retryTimer = 0;
      }
    }

    function retryAfterSeconds(response) {
      const raw = String(response.headers.get('retry-after') || '').trim();
      if (/^\d+$/.test(raw)) {
        return Math.min(3600, Number(raw));
      }
      const timestamp = Date.parse(raw);
      if (raw && Number.isFinite(timestamp)) {
        return Math.min(3600, Math.max(0, Math.ceil((timestamp - Date.now()) / 1000)));
      }
      return 0;
    }

    function requestError(code, retryAfter) {
      const error = new Error(code);
      error.retryAfter = retryAfter;
      return error;
    }

    function finishBusy() {
      section.removeAttribute('aria-busy');
      if (totalStatus instanceof HTMLElement) {
        totalStatus.removeAttribute('aria-busy');
      }
    }

    function hidePagination() {
      if (pagination instanceof HTMLElement) {
        pagination.replaceChildren();
        pagination.hidden = true;
      }
    }

    function focusResultsHeading() {
      const heading = document.getElementById('tickets-lista');
      if (heading instanceof HTMLElement) {
        heading.focus();
      }
    }

    function actionButton(labelKey, callback) {
      const button = document.createElement('button');
      button.type = 'button';
      button.className = 'glpiacessivel-button';
      button.textContent = message(labelKey);
      button.addEventListener('click', callback);
      return button;
    }

    function setSelectionVisible(visible) {
      if (selectionSummary instanceof HTMLElement) {
        selectionSummary.hidden = !visible;
      }
      if (!visible) {
        if (selectedCount && selectedCount.textContent !== '0') {
          selectedCount.textContent = '0';
        }
        if (copyButton instanceof HTMLButtonElement) {
          copyButton.disabled = true;
        }
        if (selectionStatus instanceof HTMLElement) {
          selectionStatus.textContent = '';
        }
      }
    }

    function renderFailure(code, retryAfter) {
      clearRetryTimer();
      setSelectionVisible(false);
      const alert = document.createElement('section');
      alert.className = 'glpiacessivel-alert glpiacessivel-alert-error';
      alert.setAttribute('role', 'region');
      alert.setAttribute('aria-labelledby', 'tickets-results-error-heading');
      if (summary instanceof HTMLElement) {
        alert.setAttribute('aria-describedby', summary.id);
      }
      const heading = document.createElement('h3');
      heading.id = 'tickets-results-error-heading';
      heading.textContent = message('ticket.error.heading');
      const actions = document.createElement('p');
      const retryable = ['timed_out', 'unavailable', 'temporarily_unavailable', 'rate_limited',
        'capacity_limited', 'capacity_unavailable', 'bounded_search_execution_unavailable',
        'bounded_search_execution_failed', 'bounded_search_plan_failed',
        'unexpected_content_type', 'invalid_response'];
      const reloadable = ['context_stale', 'state_expired', 'config_invalid', 'config_missing',
        'contract_upgrade_required', 'invalid_security_token'];
      if (code === 'bounded_search_offset_limit_exceeded') {
        const firstPage = document.createElement('a');
        firstPage.className = 'glpiacessivel-button';
        firstPage.href = pageUrl(1);
        firstPage.textContent = message('ticket.action.back_to_first_page');
        actions.appendChild(firstPage);
      } else if (config && config.bootstrap_error) {
        actions.appendChild(actionButton('ticket.action.reload_page', function () {
          window.location.reload();
        }));
      } else if (retryable.includes(code)) {
        const retryButton = actionButton('button.retry', function () {
          focusResultsHeading();
          runRequest();
        });
        let remaining = Math.max(0, Number.isFinite(Number(retryAfter)) ? Math.ceil(Number(retryAfter)) : 0);
        if (remaining > 0) {
          const countdown = document.createElement('p');
          countdown.id = 'tickets-results-retry-countdown';
          countdown.setAttribute('aria-live', 'off');
          retryButton.setAttribute('aria-describedby', countdown.id);
          retryButton.disabled = true;
          const updateCountdown = function () {
            countdown.textContent = message(
              remaining === 1 ? 'ticket.error.retry_wait' : 'ticket.error.retry_wait_plural',
              { seconds: remaining }
            );
          };
          updateCountdown();
          alert.appendChild(countdown);
          retryTimer = window.setInterval(function () {
            remaining -= 1;
            if (remaining <= 0) {
              clearRetryTimer();
              retryButton.disabled = false;
              countdown.textContent = '';
              setSummary(message('ticket.error.retry_ready', { page: currentPage }));
              return;
            }
            updateCountdown();
          }, 1000);
        }
        actions.appendChild(retryButton);
      } else if (reloadable.includes(code)) {
        actions.appendChild(actionButton('ticket.action.reload_page', function () {
          window.location.reload();
        }));
      }
      if (code !== 'invalid_security_token') {
        if (retryable.includes(code)) {
          const fallbackWarning = document.createElement('p');
          fallbackWarning.textContent = message('ticket.error.native_fallback_filter_warning');
          alert.appendChild(fallbackWarning);
        }
        const link = document.createElement('a');
        link.className = 'glpiacessivel-button glpiacessivel-button-secondary';
        link.href = nativeFallbackUrl;
        link.textContent = code === 'session_expired'
          ? message('ticket.action.sign_in_again')
          : message('ticket.action.open_native_general_list');
        actions.appendChild(link);
      }
      alert.prepend(heading);
      alert.appendChild(actions);
      content.replaceChildren(alert);
      setSummary(failureMessage(code));
      if (totalStatus instanceof HTMLElement) {
        totalStatus.textContent = '';
      }
      hidePagination();
      finishBusy();
    }

    if (!config) {
      renderFailure(parsed.error || 'config_invalid');
      return;
    }
    if (config.bootstrap_error) {
      renderFailure(String(config.bootstrap_error));
      return;
    }
    const contractVersion = Number(config.contract_version);
    if (contractVersion !== 1 && contractVersion !== 2) {
      renderFailure('config_invalid');
      return;
    }

    let lastSelectedCount = 0;
    function selectedIds() {
      return Array.from(content.querySelectorAll('.glpiacessivel-ticket-select:checked')).map(function (checkbox) {
        return String(checkbox.value || '');
      }).filter(Boolean);
    }
    function refreshSelection() {
      const ids = selectedIds();
      const countText = String(ids.length);
      if (selectedCount && selectedCount.textContent !== countText) {
        selectedCount.textContent = countText;
      }
      if (ids.length !== lastSelectedCount && selectionStatus instanceof HTMLElement) {
        selectionStatus.textContent = message('ticket.selection.count', { count: ids.length });
      }
      lastSelectedCount = ids.length;
      if (copyButton instanceof HTMLButtonElement) {
        copyButton.disabled = ids.length === 0;
      }
    }
    if (copyButton instanceof HTMLButtonElement && copyButton.dataset.glpiacessivelAsyncBound !== '1') {
      copyButton.dataset.glpiacessivelAsyncBound = '1';
      copyButton.addEventListener('click', function () {
        const text = selectedIds().join(', ');
        if (text && navigator.clipboard && typeof navigator.clipboard.writeText === 'function') {
          navigator.clipboard.writeText(text).catch(function () {});
        }
      });
    }

    function runRequest() {
      clearRetryTimer();
      generation += 1;
      const currentGeneration = generation;
      const requestId = 'tickets_' + Date.now().toString(36) + '_' + Math.random().toString(36).slice(2, 10);
      const controller = new AbortController();
      const deadline = Math.min(6000, Math.max(1000, Number(config.request_timeout_ms || 5000)));
      let terminal = false;

      section.setAttribute('aria-busy', 'true');
      setSelectionVisible(false);
      lastSelectedCount = 0;
      if (totalStatus instanceof HTMLElement) {
        totalStatus.textContent = '';
        totalStatus.setAttribute('aria-busy', 'true');
      }
      hidePagination();
      const loading = document.createElement('div');
      loading.className = 'glpiacessivel-empty';
      loading.textContent = message('ticket.results.loading');
      content.replaceChildren(loading);
      setSummary(message('ticket.results.loading_summary'));

      const timeout = window.setTimeout(function () {
        if (terminal || currentGeneration !== generation) {
          return;
        }
        terminal = true;
        controller.abort();
        renderFailure('timed_out');
      }, deadline);

      fetch(String(config.url || ''), {
        method: 'POST',
        credentials: 'same-origin',
        cache: 'no-store',
        signal: controller.signal,
        headers: {
          'Accept': 'application/json',
          'Content-Type': 'application/json',
          'X-Requested-With': 'XMLHttpRequest',
          'X-GLPI-CSRF-TOKEN': String(config.csrf_token || '')
        },
        body: JSON.stringify({
          contract: 'ticket_results', version: contractVersion,
          state_token: String(config.state_token || ''),
          context_revision: String(config.context_revision || ''),
          request_id: requestId
        })
      }).then(function (response) {
        const retryAfter = retryAfterSeconds(response);
        if (!String(response.headers.get('content-type') || '').toLowerCase().includes('application/json')) {
          throw requestError('unexpected_content_type', retryAfter);
        }
        return response.json().then(function (payload) {
          const nativeGlpiCsrfFailure = response.status === 403
            && payload && typeof payload === 'object'
            && payload.error === true
            && Object.keys(payload).length === 1;
          if (nativeGlpiCsrfFailure) {
            throw requestError('invalid_security_token', retryAfter);
          }
          if (payload.contract !== 'ticket_results' || payload.version !== contractVersion
            || typeof payload.success !== 'boolean') {
            throw requestError('invalid_response', retryAfter);
          }
          if (!response.ok) {
            throw requestError(String(payload.error || 'http_' + response.status), retryAfter);
          }
          if (payload.success !== true || payload.request_id !== requestId || payload.context_revision !== config.context_revision) {
            throw requestError(String(payload.error || 'invalid_response'), retryAfter);
          }
          return normalizeResult(payload.result, contractVersion);
        });
      }).then(function (result) {
        if (terminal || currentGeneration !== generation) {
          return;
        }
        if (result.items.length === 0 && String(result.backend || '') === 'native_saved_search_blocked') {
          throw new Error(String(result.backend_reason || 'unavailable'));
        }
        renderItems(content, result, config, refreshSelection);
        const itemCount = result.items.length;
        setSelectionVisible(itemCount > 0);
        const first = itemCount > 0 ? ((result.page - 1) * result.page_size) + 1 : 0;
        const last = itemCount > 0 ? first + itemCount - 1 : 0;
        let summaryText;
        if (String(result.backend_reason || '') === 'group_scope_without_current_groups') {
          summaryText = message('ticket.results.group_scope_without_current_groups');
        } else if (itemCount === 0 && result.page > 1) {
          summaryText = message('ticket.results.page_empty_after_first', { page: result.page });
        } else if (itemCount === 0) {
          summaryText = message('ticket.results.none_visible');
        } else if (result.total_state === 'exact') {
          summaryText = message('ticket.results.range', { first: first, last: last, total: result.total });
        } else if (result.total_state === 'lower_bound') {
          summaryText = message('ticket.results.range_lower_bound', { first: first, last: last, total: result.total });
        } else {
          summaryText = message(result.has_more
            ? 'ticket.results.page_range_more'
            : 'ticket.results.page_range_end', { first: first, last: last });
        }
        const totalMessages = {
          deferred: 'ticket.results.total_deferred',
          pending: 'ticket.results.total_pending',
          unavailable: 'ticket.results.total_unavailable'
        };
        const totalMessage = totalMessages[result.total_state]
          ? message(totalMessages[result.total_state])
          : '';
        setSummary(summaryText, totalMessage);
        if (totalStatus instanceof HTMLElement) {
          totalStatus.textContent = totalMessage;
        }
        if (pagination instanceof HTMLElement) {
          renderPagination(pagination, result, contractVersion);
        }
        refreshSelection();
        terminal = true;
        finishBusy();
      }).catch(function (error) {
        if (terminal || currentGeneration !== generation) {
          return;
        }
        terminal = true;
        renderFailure(
          String(error && error.message ? error.message : 'unavailable'),
          Number(error && error.retryAfter ? error.retryAfter : 0)
        );
      }).finally(function () {
        window.clearTimeout(timeout);
      });
    }

    runRequest();
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', start, { once: true });
  } else {
    start();
  }
})();
