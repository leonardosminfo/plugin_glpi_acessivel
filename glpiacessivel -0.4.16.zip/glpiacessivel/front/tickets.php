<?php

declare(strict_types=1);

require '../../../inc/includes.php';
require_once dirname(__DIR__) . '/hook.php';

if (isset($_GET['id']) && is_numeric($_GET['id'])) {
    \GlpiPlugin\Glpiacessivel\UI\Controller\TicketController::detail();
} else {
    \GlpiPlugin\Glpiacessivel\UI\Controller\TicketController::index();
}
