<?php

declare(strict_types=1);

// Compatibility route kept for bookmarks created before 0.2.31-beta.
// This redirect must run before the GLPI bootstrap: Formcreator 2.13 replaces
// every helpdesk URL containing "front/ticket.php", including plugin routes.
$query = (string) ($_SERVER['QUERY_STRING'] ?? '');
if (preg_match('/[\x00-\x1F\x7F]/', $query) === 1) {
    $query = '';
}

$location = 'tickets.php' . ($query !== '' ? '?' . $query : '');
$method = strtoupper((string) ($_SERVER['REQUEST_METHOD'] ?? 'GET'));
$status = in_array($method, ['GET', 'HEAD'], true) ? 302 : 307;

header('Location: ' . $location, true, $status);
exit;
