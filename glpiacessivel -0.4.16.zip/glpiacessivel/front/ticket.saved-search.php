<?php

declare(strict_types=1);

require_once dirname(__DIR__, 3) . '/inc/includes.php';
require_once dirname(__DIR__) . '/setup.php';

\GlpiPlugin\Glpiacessivel\UI\Controller\SavedTicketSearchController::action();
