<?php

declare(strict_types=1);

namespace GlpiPlugin\Glpiacessivel\Domain\Ticket;

/**
 * Internal, message-free classification of a failed native revalidation.
 * Never retain the original exception: its message/trace may contain SQL.
 */
final class NativeSavedSearchExecutionException extends \RuntimeException
{
    public function __construct(
        private string $failureStage,
        private int $databaseErrorCode = 0
    ) {
        parent::__construct('native_saved_search_revalidation_failed');
    }

    public function failureStage(): string
    {
        return $this->failureStage;
    }

    public function isTemporary(): bool
    {
        // MySQL/MariaDB driver codes: capacity, lock wait/deadlock,
        // connection loss/unavailability, and server-enforced query timeout.
        return in_array($this->databaseErrorCode, [
            1040, 1203, 1205, 1213, 2002, 2003, 2006, 2013, 1969, 3024,
        ], true);
    }

    public function databaseErrorCode(): int
    {
        return $this->databaseErrorCode;
    }
}
