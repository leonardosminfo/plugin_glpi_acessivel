<?php

declare(strict_types=1);

namespace GlpiPlugin\Glpiacessivel\Application\DynamicForm;

use GlpiPlugin\Glpiacessivel\Domain\DynamicForm\DynamicFormSchema;
use GlpiPlugin\Glpiacessivel\Domain\DynamicForm\DynamicFormSubmissionResult;
use GlpiPlugin\Glpiacessivel\Support\I18n;

final class TicketTemplateSchemaAdapter extends NativeTicketSchemaAdapter
{
    public const SOURCE = 'ticket_template';

    public function source(): string
    {
        return self::SOURCE;
    }

    /**
     * @param array<string, mixed> $context
     */
    public function supports(array $context): bool
    {
        return is_array($context['selected_ticket_template'] ?? null);
    }

    /**
     * @param array<string, mixed> $context
     */
    public function getSchema(array $context): DynamicFormSchema
    {
        $template = is_array($context['selected_ticket_template'] ?? null) ? $context['selected_ticket_template'] : [];
        $context['field_requirements'] = array_merge(
            is_array($context['field_requirements'] ?? null) ? $context['field_requirements'] : [],
            is_array($template['field_requirements'] ?? null) ? $template['field_requirements'] : []
        );
        if (!empty($template['requires_native_fallback'])) {
            $context['requires_native_fallback'] = true;
            $existingReasons = array_values(array_filter(array_map(
                static fn(mixed $reason): string => trim((string) $reason),
                (array) ($context['native_fallback_reasons'] ?? [])
            )));
            if ($existingReasons === []) {
                $unsupported = array_values(array_map('strval', (array) ($template['unsupported_required'] ?? [])));
                $existingReasons[] = $unsupported === []
                    ? I18n::translate('O modelo de chamado exige uma regra ainda não disponível nesta página.')
                    : sprintf(
                        I18n::translate('O modelo de chamado exige campos ainda não disponíveis nesta página: %s.'),
                        implode(', ', $unsupported)
                    );
            }
            $context['native_fallback_reasons'] = $existingReasons;
        }

        $schema = parent::getSchema($context)->toArray();
        return new DynamicFormSchema(
            (string) ($schema['id'] ?? ''),
            self::SOURCE,
            '1.0',
            I18n::translate('Abertura por modelo de chamado'),
            array_map(static fn(array $section): \GlpiPlugin\Glpiacessivel\Domain\DynamicForm\DynamicFormSection => new \GlpiPlugin\Glpiacessivel\Domain\DynamicForm\DynamicFormSection(
                (string) ($section['id'] ?? ''),
                (string) ($section['title'] ?? ''),
                (int) ($section['order'] ?? 0),
                (string) ($section['description'] ?? '')
            ), (array) ($schema['sections'] ?? [])),
            array_map(static fn(array $field): \GlpiPlugin\Glpiacessivel\Domain\DynamicForm\DynamicFormField => new \GlpiPlugin\Glpiacessivel\Domain\DynamicForm\DynamicFormField(
                (string) ($field['id'] ?? ''),
                (string) ($field['name'] ?? ''),
                (string) ($field['type'] ?? 'text'),
                (string) ($field['label'] ?? ''),
                (string) ($field['section_id'] ?? 'main'),
                !empty($field['required']),
                array_key_exists('visible', $field) ? !empty($field['visible']) : true,
                !empty($field['readonly']),
                !empty($field['disabled']),
                !empty($field['multiple']),
                $field['default'] ?? null,
                is_array($field['options'] ?? null) ? $field['options'] : [],
                is_array($field['constraints'] ?? null) ? $field['constraints'] : [],
                self::SOURCE,
                (string) ($field['native_field'] ?? $field['name'] ?? ''),
                (string) ($field['description'] ?? ''),
                is_array($field['metadata'] ?? null) ? $field['metadata'] : []
            ), (array) ($schema['fields'] ?? [])),
            [],
            array_merge((array) ($schema['capabilities'] ?? []), ['supports_ticket_template_projection' => true]),
            (array) ($schema['fallback'] ?? []),
            array_merge((array) ($schema['metadata'] ?? []), [
                'tickettemplates_id' => (int) ($template['id'] ?? 0),
                'tickettemplate_label' => (string) ($template['label'] ?? ''),
            ])
        );
    }

    /**
     * @param array<string, mixed> $answers
     */
    public function submit(array $answers, DynamicFormSchema $schema): DynamicFormSubmissionResult
    {
        return new DynamicFormSubmissionResult(false, [], '', [[
            'field' => 'tickettemplates_id',
            'code' => 'ticket_template_adapter_submit_not_enabled',
            'message' => I18n::translate('Conclua o envio deste modelo de chamado em página completa.'),
        ]]);
    }
}
