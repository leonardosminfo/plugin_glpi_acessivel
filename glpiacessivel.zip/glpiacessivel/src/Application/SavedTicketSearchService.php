<?php

declare(strict_types=1);

namespace GlpiPlugin\Glpiacessivel\Application;

use GlpiPlugin\Glpiacessivel\Domain\Security\Authorization;
use GlpiPlugin\Glpiacessivel\Domain\Ticket\NativeSavedSearchExecutionException;
use GlpiPlugin\Glpiacessivel\Infrastructure\Audit\AuditLogger;
use GlpiPlugin\Glpiacessivel\Infrastructure\Repository\NativeSavedSearchGateway;
use GlpiPlugin\Glpiacessivel\Infrastructure\Security\IdempotencyLedger;

final class SavedTicketSearchService
{
    public function __construct(
        private NativeSavedSearchGateway $gateway,
        private Authorization $authorization,
        private AuditLogger $auditLogger
    ) {
    }

    /** @return array<string,mixed> */
    public function catalog(string $query = '', string $cursor = '', int $pageSize = 25, bool $causalResolution = false): array
    {
        $this->ensureAllowed();
        $page = $this->gateway->page($query, $cursor, $pageSize);
        $defaultKey = '';
        $defaultItem = null;
        $defaultId = $this->gateway->defaultId($causalResolution);
        if ($defaultId > 0) {
            // Resolve through the same execution boundary used when a user
            // explicitly applies a search. A native default may be safe to
            // execute even when the accessible editor cannot represent it.
            $resolvedDefault = $this->resolve('native:' . $defaultId, $causalResolution);
            $default = is_array($resolvedDefault['view'] ?? null)
                ? $resolvedDefault['view']
                : $this->gateway->getAuthorized($defaultId);
            $defaultItem = $default;
            if (
                $default !== null
                && in_array(
                    (string) ($default['capability'] ?? ''),
                    ['editable', 'executable_read_only'],
                    true
                )
            ) {
                $defaultKey = 'native:' . $defaultId;
            }
        }

        return [
            'native' => (array) $page['items'],
            'default_key' => $defaultKey,
            'default_item' => $defaultItem,
            'capabilities' => $this->gateway->capabilities(),
            'next_cursor' => (string) $page['next_cursor'],
            'has_more' => (bool) $page['has_more'],
            'page_size' => (int) $page['page_size'],
            'query' => (string) $page['query'],
        ];
    }

    /** @return array{status:string,value?:array<string,mixed>,error?:string} */
    public function catalogOutcome(string $query = '', string $cursor = '', int $pageSize = 25): array
    {
        return $this->initialResolutionOutcome(fn() => $this->catalog($query, $cursor, $pageSize, true));
    }

    /** @return array{status:string,value?:array<string,mixed>,error?:string} */
    public function resolveOutcome(string $key): array
    {
        return $this->initialResolutionOutcome(fn() => $this->resolve($key, true));
    }

    /**
     * Preserve the existing initial-resolution queries and editor projection,
     * but expose native execution failures before the shell can mark a search
     * missing or silently use the general list instead of a native default.
     *
     * @param callable():?array $resolve
     * @return array{status:string,value?:array<string,mixed>,error?:string}
     */
    private function initialResolutionOutcome(callable $resolve): array
    {
        $outputLevel = ob_get_level();
        ob_start();
        try {
            $value = $resolve();
            return is_array($value) ? ['status' => 'ready', 'value' => $value] : ['status' => 'blocked'];
        } catch (NativeSavedSearchExecutionException $e) {
            return [
                'status' => $e->isTemporary() ? 'temporary_failure' : 'failure',
                'error' => $e->isTemporary()
                    ? 'saved_search_revalidation_unavailable'
                    : 'saved_search_revalidation_failed',
            ];
        } catch (\Throwable $e) {
            // Preserve the existing cursor recovery protocol, not raw errors.
            if ($e instanceof \InvalidArgumentException && $e->getMessage() === 'saved_search_cursor_invalid') {
                throw $e;
            }
            return ['status' => 'failure', 'error' => 'saved_search_revalidation_failed'];
        } finally {
            while (ob_get_level() > $outputLevel) {
                ob_end_clean();
            }
        }
    }

    /** @return array<string,mixed> */
    public function searchCatalog(): array
    {
        $this->ensureAllowed();
        return $this->gateway->searchCatalog();
    }

    /** @return array<string,mixed> */
    public function validationContext(): array
    {
        $this->ensureAllowed();
        return $this->gateway->validationContext(true);
    }

    /** @param array<string,mixed> $definition @return array<string,mixed> */
    public function validateDefinition(array $definition): array
    {
        $this->ensureAllowed();
        return $this->gateway->validateDefinition($definition);
    }

    /** @return array{view:array<string,mixed>,filters:array<string,mixed>}|null */
    public function resolve(string $key, bool $causalResolution = false): ?array
    {
        $this->ensureAllowed();
        if (preg_match('/^native:(\d+)$/', $key, $matches) !== 1) {
            return null;
        }
        $id = (int) $matches[1];
        $view = $this->gateway->getAuthorized($id, null, $causalResolution);
        if ($view === null) {
            return null;
        }

        $filters = ['native_saved_search_id' => $id];
        $execution = $this->gateway->resolveAuthorizedForExecution($id, $causalResolution);
        if ($this->hasTrustedNativeExecution($execution, $view, $id)) {
            /** @var array<string,mixed> $parameters */
            $parameters = $execution['parameters'];
            $filters['native_parameters'] = $parameters;
            $filters['native_criteria'] = $parameters['criteria'];
            $filters['native_metacriteria'] = $parameters['metacriteria'];
            $filters['native_sort'] = $parameters['sort'];
            $filters['native_order'] = $parameters['order'];
            $filters['native_is_deleted'] = $parameters['is_deleted'];
            $filters['native_execution_fingerprint'] = $execution['fingerprint'];
            $filters['q'] = '';
            $filters['scope'] = 'all';

            $editorCapability = (string) ($execution['editor_capability'] ?? 'unavailable');
            $view['capability'] = $editorCapability === 'editable'
                ? 'editable'
                : 'executable_read_only';
            $view['capability_reasons'] = array_values(array_unique(array_merge(
                (array) ($view['capability_reasons'] ?? []),
                (array) ($execution['editor_reasons'] ?? [])
            )));
        } else {
            $view['capability'] = 'native_only';
            $view['capability_reasons'] = array_values(array_unique(array_merge(
                (array) ($view['capability_reasons'] ?? []),
                is_array($execution) ? (array) ($execution['execution_reasons'] ?? []) : [],
                ['native_saved_search_execution_unavailable']
            )));
        }

        // Strict catalog/value validation controls only the accessible editor.
        // Native execution above keeps the canonical parameters resolved by
        // GLPI and therefore remains available when a third-party field or a
        // presentation option cannot be represented by this editor.
        if ((string) ($view['capability'] ?? '') === 'editable') {
            try {
                $definition = (array) ($view['definition'] ?? []);
                $definition['version'] = 3;
                $definition['text'] = '';
                $definition['scope'] = 'all';
                $definition = $this->gateway->validateDefinition($definition);
                if (array_key_exists('columns', $definition)) {
                    $filters['columns'] = (array) $definition['columns'];
                }
                $nativePageSize = (int) ($view['page_size'] ?? 0);
                if (in_array($nativePageSize, [10, 20, 50, 100], true)) {
                    $filters['page_size'] = $nativePageSize;
                }
                $view['definition'] = $definition;
            } catch (\Throwable $e) {
                $view['capability'] = 'executable_read_only';
                $reasons = (array) ($view['capability_reasons'] ?? []);
                $reasons[] = 'native_context_validation_failed';
                $view['capability_reasons'] = array_values(array_unique($reasons));
            }
        } elseif ((string) ($view['capability'] ?? '') === 'executable_read_only') {
            $nativePageSize = (int) ($view['page_size'] ?? 0);
            if (in_array($nativePageSize, [10, 20, 50, 100], true)) {
                $filters['page_size'] = $nativePageSize;
            }
        }

        return ['view' => $view, 'filters' => $filters];
    }

    /**
     * Reauthorize a server-side async execution immediately before it reaches
     * the repository. Returning null is intentionally fail-closed: it means
     * the SavedSearch changed, disappeared, lost READ permission or can no
     * longer be reproduced without semantic loss in the current GLPI context.
     *
     * @return array<string,mixed>|null
     */
    public function revalidateNativeExecution(int $id, string $expectedFingerprint): ?array
    {
        $this->ensureAllowed();
        $outcome = $this->revalidateNativeExecutionOutcome($id, $expectedFingerprint);
        return $outcome['status'] === 'ready' ? $outcome['filters'] : null;
    }

    /**
     * Fail closed without confusing failed native reads with ACL/definition
     * changes. Filters exist only in the ready branch and stay server-side.
     * The legacy nullable method above remains available to existing callers.
     *
     * @return array{status:string,filters?:array<string,mixed>,failure_code?:string,failure_stage?:string}
     */
    public function revalidateNativeExecutionOutcome(int $id, string $expectedFingerprint): array
    {
        if (
            $id <= 0
            || preg_match('/\A[a-f0-9]{64}\z/D', $expectedFingerprint) !== 1
        ) {
            return ['status' => 'blocked', 'failure_code' => 'native_saved_search_execution_unavailable'];
        }
        try {
            if (!$this->authorization->canViewTickets()) {
                return ['status' => 'blocked', 'failure_code' => 'saved_search_access_denied'];
            }
            // Reuse the canonical execution checks, without resolving a
            // presentation/default or asking for UPDATE/DELETE permissions.
            $execution = $this->gateway->resolveAuthorizedForRevalidation($id);
            if (!$this->hasTrustedNativeExecution($execution, ['fingerprint' => $expectedFingerprint], $id)) {
                // Expose only this known, non-sensitive cause, never arbitrary
                // native validation details or a changed query definition.
                $semanticLoss = is_array($execution)
                    && hash_equals($expectedFingerprint, (string) ($execution['fingerprint'] ?? ''))
                    && in_array('native_resolved_semantics_changed', (array) ($execution['execution_reasons'] ?? []), true);
                return ['status' => 'blocked', 'failure_code' => $semanticLoss
                    ? 'native_resolved_semantics_changed'
                    : 'native_saved_search_execution_unavailable'];
            }
            $parameters = $execution['parameters'];
            return [
                'status' => 'ready',
                'filters' => [
                    'native_saved_search_id' => $id,
                    'native_parameters' => $parameters,
                    'native_criteria' => $parameters['criteria'],
                    'native_metacriteria' => $parameters['metacriteria'],
                    'native_sort' => $parameters['sort'],
                    'native_order' => $parameters['order'],
                    'native_is_deleted' => $parameters['is_deleted'],
                    'native_execution_fingerprint' => $execution['fingerprint'],
                ],
            ];
        } catch (NativeSavedSearchExecutionException $e) {
            return [
                'status' => $e->isTemporary() ? 'temporary_failure' : 'failure',
                'failure_code' => 'native_saved_search_revalidation_failed',
                'failure_stage' => $e->failureStage(),
            ];
        } catch (\Throwable $e) {
            return [
                'status' => 'failure',
                'failure_code' => 'native_saved_search_revalidation_failed',
                'failure_stage' => 'revalidation',
            ];
        }
    }

    /**
     * Treat the gateway execution envelope as an internal trust boundary.
     * Authorization and semantic-loss checks belong to the gateway, while the
     * service still rejects malformed or cross-record envelopes before they
     * can reach the ticket repository or the async state store.
     *
     * @param array<string,mixed>|null $execution
     * @param array<string,mixed> $view
     */
    private function hasTrustedNativeExecution(?array $execution, array $view, int $id): bool
    {
        if (
            !is_array($execution)
            || (int) ($execution['id'] ?? 0) !== $id
            || (string) ($execution['execution_capability'] ?? '') !== 'executable'
        ) {
            return false;
        }
        $fingerprint = $execution['fingerprint'] ?? null;
        $viewFingerprint = $view['fingerprint'] ?? null;
        if (
            !is_string($fingerprint)
            || !is_string($viewFingerprint)
            || preg_match('/\A[a-f0-9]{64}\z/D', $fingerprint) !== 1
            || preg_match('/\A[a-f0-9]{64}\z/D', $viewFingerprint) !== 1
            || !hash_equals($viewFingerprint, $fingerprint)
        ) {
            return false;
        }

        $parameters = $execution['parameters'] ?? null;
        if (!is_array($parameters)) {
            return false;
        }
        foreach (['criteria', 'metacriteria', 'sort', 'order'] as $key) {
            if (!array_key_exists($key, $parameters) || !is_array($parameters[$key])) {
                return false;
            }
        }
        if (
            ($parameters['itemtype'] ?? 'Ticket') !== 'Ticket'
            || !array_key_exists('is_deleted', $parameters)
            || !is_int($parameters['is_deleted'])
            || !in_array($parameters['is_deleted'], [0, 1], true)
            || count($parameters['sort']) !== count($parameters['order'])
        ) {
            return false;
        }
        foreach ($parameters['sort'] as $sort) {
            if (!is_int($sort) || $sort <= 0) {
                return false;
            }
        }
        foreach ($parameters['order'] as $order) {
            if (!is_string($order) || !in_array(strtoupper($order), ['ASC', 'DESC'], true)) {
                return false;
            }
        }

        return true;
    }

    /** @return array<string,mixed> */
    public function buildSimpleDefinition(array $filters): array
    {
        $this->ensureAllowed();
        return $this->gateway->buildSimpleDefinition($filters);
    }

    /**
     * @param callable():int $mutation
     * @return array{status:string,result_id:int}
     */
    public function mutateIdempotently(
        IdempotencyLedger $ledger,
        string $scope,
        string $idempotencyKey,
        string $requestHash,
        callable $mutation
    ): array {
        $this->ensureAllowed();
        return $this->gateway->mutateIdempotently(
            $ledger,
            $scope,
            $idempotencyKey,
            $requestHash,
            $mutation
        );
    }

    /** @param array<string,mixed> $options */
    public function create(
        string $name,
        array $definition,
        bool $isDefault = false,
        array $options = []
    ): int {
        $this->ensureAllowed();
        if ($isDefault) {
            $options['set_default'] = true;
        }
        $id = $this->gateway->create($name, $definition, $options);
        $this->auditLogger->log('ticket.saved_search.native.create', [
            'saved_search_id' => $id,
            'is_private' => !array_key_exists('is_private', $options) || !empty($options['is_private']),
            'set_default' => !empty($options['set_default']),
        ]);
        return $id;
    }

    /** @param array<string,mixed> $options */
    public function update(
        int $id,
        string $name,
        array $definition,
        string $expectedFingerprint = '',
        array $options = []
    ): bool {
        $this->ensureAllowed();
        $updated = $this->gateway->update(
            $id,
            $name,
            $definition,
            $expectedFingerprint,
            $options
        );
        $this->auditLogger->log('ticket.saved_search.native.update', [
            'saved_search_id' => $id,
            'updated' => $updated,
            'visibility_changed' => array_key_exists('is_private', $options),
            'default_changed' => array_key_exists('set_default', $options),
        ]);
        return $updated;
    }

    /** @param array<string,mixed> $options */
    public function updateMetadata(
        int $id,
        string $name,
        string $expectedFingerprint = '',
        array $options = []
    ): bool {
        $this->ensureAllowed();
        $updated = $this->gateway->updateMetadata(
            $id,
            $name,
            $expectedFingerprint,
            $options
        );
        $this->auditLogger->log('ticket.saved_search.native.update_metadata', [
            'saved_search_id' => $id,
            'updated' => $updated,
            'default_changed' => array_key_exists('set_default', $options),
        ]);
        return $updated;
    }
    public function delete(int $id, string $expectedFingerprint = ''): bool
    {
        $this->ensureAllowed();
        $deleted = $this->gateway->delete($id, $expectedFingerprint);
        $this->auditLogger->log('ticket.saved_search.native.delete', [
            'saved_search_id' => $id,
            'deleted' => $deleted,
        ]);
        return $deleted;
    }

    public function setDefault(int $id, string $expectedFingerprint = ''): bool
    {
        $this->ensureAllowed();
        $updated = $this->gateway->setDefault($id, $expectedFingerprint);
        $this->auditLogger->log('ticket.saved_search.native.default', [
            'saved_search_id' => $id,
            'updated' => $updated,
        ]);
        return $updated;
    }

    public function unsetDefault(int $id, string $expectedFingerprint = ''): bool
    {
        $this->ensureAllowed();
        $updated = $this->gateway->unsetDefault($id, $expectedFingerprint);
        $this->auditLogger->log('ticket.saved_search.native.unset_default', [
            'saved_search_id' => $id,
            'updated' => $updated,
        ]);
        return $updated;
    }

    private function ensureAllowed(): void
    {
        if (!$this->authorization->canViewTickets()) {
            throw new \RuntimeException('saved_search_access_denied');
        }
    }
}
