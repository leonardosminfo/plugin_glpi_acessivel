<?php

declare(strict_types=1);

namespace GlpiPlugin\Glpiacessivel\Application;

use GlpiPlugin\Glpiacessivel\Application\DynamicForm\DynamicFormFacade;
use GlpiPlugin\Glpiacessivel\Domain\Pii\PiiMasker;
use GlpiPlugin\Glpiacessivel\Domain\Security\Authorization;
use GlpiPlugin\Glpiacessivel\Domain\Ticket\TicketCreationPolicy;
use GlpiPlugin\Glpiacessivel\Domain\Ticket\TicketPolicy;
use GlpiPlugin\Glpiacessivel\Infrastructure\Audit\AuditLogger;
use GlpiPlugin\Glpiacessivel\Infrastructure\Repository\TicketRepository;
use GlpiPlugin\Glpiacessivel\Infrastructure\Search\GlpiResourceSelectorProvider;
use GlpiPlugin\Glpiacessivel\Infrastructure\Search\GlpiResourceSelectorRegistry;
use GlpiPlugin\Glpiacessivel\Infrastructure\Security\IdempotencyClaim;
use GlpiPlugin\Glpiacessivel\Infrastructure\Security\IdempotencyLedger;
use GlpiPlugin\Glpiacessivel\Support\FormValidationException;
use GlpiPlugin\Glpiacessivel\Support\I18n;
use GlpiPlugin\Glpiacessivel\Support\ItilTemplateResolutionException;
use GlpiPlugin\Glpiacessivel\Support\SolutionMutationOutcomeUncertainException;
use GlpiPlugin\Glpiacessivel\Support\UploadedFileMapper;
use GlpiPlugin\Glpiacessivel\Support\Url;

final class TicketService
{
    /** @var TicketRepository */
    private $repository;
    /** @var TicketPolicy */
    private $policy;
    /** @var TicketCreationPolicy */
    private $creationPolicy;
    /** @var AuditLogger */
    private $auditLogger;
    /** @var PiiMasker */
    private $piiMasker;
    /** @var Authorization */
    private $authorization;
    /** @var ConfigService */
    private $configService;
    /** @var GlpiResourceSelectorProvider|null */
    private $resourceSelectorProvider;
    private ?IdempotencyLedger $idempotencyLedger = null;

    public function __construct(
        TicketRepository $repository,
        TicketPolicy $policy,
        TicketCreationPolicy $creationPolicy,
        AuditLogger $auditLogger,
        PiiMasker $piiMasker,
        Authorization $authorization,
        ConfigService $configService,
        ?GlpiResourceSelectorProvider $resourceSelectorProvider = null,
        ?IdempotencyLedger $idempotencyLedger = null
    ) {
        $this->repository = $repository;
        $this->policy = $policy;
        $this->creationPolicy = $creationPolicy;
        $this->auditLogger = $auditLogger;
        $this->piiMasker = $piiMasker;
        $this->authorization = $authorization;
        $this->configService = $configService;
        $this->resourceSelectorProvider = $resourceSelectorProvider;
        $this->idempotencyLedger = $idempotencyLedger;
    }

    public function list(array $filters): array
    {
        $this->ensureCanView();
        $data = $this->repository->listTickets($filters);

        $this->auditLogger->log('ticket.list', [
            'scope' => (string) ($filters['scope'] ?? 'all'),
            'status' => (string) ($filters['status'] ?? ''),
            'page' => (int) ($filters['page'] ?? 1),
            'page_size' => (int) ($data['page_size'] ?? ($filters['page_size'] ?? 20)),
            'sort' => (string) ($filters['sort'] ?? 'date_mod'),
            'direction' => strtoupper((string) ($filters['direction'] ?? 'DESC')) === 'ASC' ? 'ASC' : 'DESC',
            'count' => count($data['items']),
            'total' => (int) ($data['total'] ?? 0),
            'backend' => (string) ($data['backend'] ?? 'unknown'),
            'backend_reason' => (string) ($data['backend_reason'] ?? ''),
            'stage_durations_ms' => is_array($data['backend_diagnostics']['stage_durations_ms'] ?? null)
                ? $data['backend_diagnostics']['stage_durations_ms']
                : [],
            'filters' => [
                'scope' => (string) ($filters['scope'] ?? 'all'),
                'status' => (string) ($filters['status'] ?? ''),
                'q_len' => strlen((string) ($filters['q'] ?? '')),
                'group_id' => (int) ($filters['group_id'] ?? 0),
                'group_by' => (string) ($filters['group_by'] ?? 'none'),
            ],
        ]);

        return $data;
    }

    /** @return array<int, array{id:int,label:string}> */
    public function groupFilterOptions(): array
    {
        $this->ensureCanView();
        $options = $this->repository->getTicketGroupFilterOptions();
        if (!$this->resourceSelectorProvider instanceof GlpiResourceSelectorProvider) {
            return $options;
        }

        $labels = [];
        foreach ($options as $option) {
            $id = (int) ($option['id'] ?? 0);
            if ($id > 0) {
                $labels[$id] = (string) ($option['label'] ?? '');
            }
        }
        if ($labels === []) {
            return [];
        }

        $authorized = [];
        try {
            foreach (array_chunk(array_keys($labels), GlpiResourceSelectorProvider::MAX_SELECTED_IDS) as $ids) {
                $result = $this->resourceSelectorProvider->search(
                    GlpiResourceSelectorRegistry::ASSIGNED_GROUP,
                    '',
                    null,
                    $ids
                );
                foreach ((array) ($result['results'] ?? []) as $row) {
                    $id = is_array($row) ? (int) ($row['id'] ?? 0) : 0;
                    if ($id > 0 && isset($labels[$id])) {
                        $authorized[$id] = true;
                    }
                }
            }
        } catch (\Throwable) {
            return [];
        }

        return array_values(array_filter(
            $options,
            static fn(array $option): bool => isset($authorized[(int) ($option['id'] ?? 0)])
        ));
    }

    public function creationContext(array $input = []): array
    {
        if (!$this->authorization->canCreateTickets()) {
            throw new \RuntimeException(I18n::translate('Usuário sem permissão para criar chamados.'));
        }

        $remoteSelectors = $this->remoteSelectorsEnabled('create');
        $context = $remoteSelectors
            ? $this->repository->getTicketCreationContext(false)
            : $this->repository->getTicketCreationContext();
        $nativeRequesterSelection = !empty($context['requester_editable']);
        $context['requester_editable'] = $remoteSelectors && $nativeRequesterSelection;
        if ($nativeRequesterSelection && !$remoteSelectors) {
            $context['requester_selection_fallback'] = true;
            $context['requester_selection_message'] = I18n::translate(
                'A busca segura de requerentes está desativada. Use o formulário nativo em página completa para abrir em nome de outra pessoa.'
            );
        }
        $templateId = max(0, (int) ($input['tickettemplates_id'] ?? 0));
        if ($templateId > 0) {
            $template = $this->repository->getTicketTemplateMetadata($templateId);
            if ($template !== null) {
                $context['selected_ticket_template'] = $template;
                $context['field_requirements'] = array_merge(
                    (array) ($context['field_requirements'] ?? []),
                    (array) ($template['field_requirements'] ?? [])
                );
                if (!empty($template['requires_native_fallback'])) {
                    $context['requires_native_fallback'] = true;
                    $unsupported = array_values(array_map('strval', (array) ($template['unsupported_required'] ?? [])));
                    $context['native_fallback_reasons'][] = $unsupported === []
                        ? I18n::translate('O modelo selecionado exige campos ainda não suportados neste formulário acessível. Use o formulário nativo do GLPI.')
                        : sprintf(
                            I18n::translate('O modelo selecionado exige campos não suportados neste formulário acessível: %s. Use o formulário nativo do GLPI.'),
                            implode(', ', $unsupported)
                        );
                }
            }
        }

        if ($remoteSelectors) {
            $context['resource_selector'] = $this->resourceSelectorConfig('create');
            $context['selected_resources'] = $this->hydrateSelectedResources(
                $input,
                !empty($context['requester_editable'])
            );
        } else {
            $context['resource_selector'] = ['enabled' => false];
            $context['selected_resources'] = [];
        }

        $context['dynamic_form_schema'] = (new DynamicFormFacade())->ticketCreationSchema($context)->toArray();

        return $context;
    }

    public function canSelectRequesterForCreation(): bool
    {
        if (!$this->remoteSelectorsEnabled('create')) {
            return false;
        }

        try {
            return $this->repository->canSelectRequesterForCreation();
        } catch (\Throwable $e) {
            return false;
        }
    }

    public function create(array $input): int
    {
        if (!$this->authorization->canCreateTickets()) {
            throw new \RuntimeException(I18n::translate('Usuário sem permissão para criar chamados.'));
        }

        foreach (
            [
            '_users_id_assign',
            '_users_id_observer',
            '_groups_id_assign',
            '_groups_id_observer',
            ] as $actorField
        ) {
            if (array_key_exists($actorField, $input)) {
                $input[$actorField] = $this->normalizeActorIds(
                    (array) $input[$actorField],
                    $actorField
                );
            }
        }

        $context = $this->creationContext($input);
        $currentRequesterId = (int) ($context['requester_id'] ?? $_SESSION['glpiID'] ?? 0);
        $requesterId = max(0, (int) ($input['requester_user_id'] ?? $currentRequesterId));
        if ($requesterId <= 0) {
            $requesterId = $currentRequesterId;
        }
        if ($currentRequesterId <= 0) {
            throw new FormValidationException([[
                'field' => 'requester_user_id',
                'code' => 'invalid_session_requester',
                'message' => I18n::translate('Não foi possível confirmar o usuário autenticado como requerente.'),
            ]]);
        }
        if ($requesterId !== $currentRequesterId) {
            if (
                empty($context['requester_editable'])
                || !$this->remoteSelectorsEnabled('create')
                || !$this->resourceSelectorProvider instanceof GlpiResourceSelectorProvider
            ) {
                throw new FormValidationException([[
                    'field' => 'requester_user_id',
                    'code' => 'requester_delegation_forbidden',
                    'message' => I18n::translate('O requerente deve permanecer no usuário autenticado neste contexto.'),
                ]]);
            }
            try {
                $requesterAuthorized = $this->resourceSelectorProvider->authorizeAll(
                    GlpiResourceSelectorRegistry::REQUESTER_USER,
                    [$requesterId]
                );
            } catch (\Throwable $e) {
                $requesterAuthorized = false;
            }
            if (
                !$requesterAuthorized
                || !$this->repository->canCreateTicketForRequester(
                    $requesterId,
                    (int) ($context['entity_id'] ?? -1)
                )
            ) {
                throw new FormValidationException([[
                    'field' => 'requester_user_id',
                    'code' => 'requester_not_authorized',
                    'message' => I18n::translate('Requerente inválido ou não autorizado para a entidade ativa.'),
                ]]);
            }
        }
        $input['requester_user_id'] = $requesterId;
        $input['_users_id_requester'] = [$requesterId];
        $templateId = max(0, (int) ($input['tickettemplates_id'] ?? 0));
        $template = is_array($context['selected_ticket_template'] ?? null) ? $context['selected_ticket_template'] : null;
        if ($templateId > 0 && $template === null) {
            throw new FormValidationException([[
                'field' => 'tickettemplates_id',
                'code' => 'invalid_template',
                'message' => I18n::translate('Modelo de chamado inválido para o contexto atual.'),
            ]]);
        }
        if ($template !== null) {
            $input = $this->enforceTemplatePolicy($input, $template);
        }

        $name = trim((string) ($input['name'] ?? ''));
        if ($name === '') {
            throw new \RuntimeException(I18n::translate('Informe o título do chamado.'));
        }

        $content = trim((string) ($input['content'] ?? ''));
        if ($content === '') {
            throw new \RuntimeException(I18n::translate('Informe a descrição do chamado.'));
        }

        $dynamicErrors = (new DynamicFormFacade())->validateTicketCreation($context, $input);
        if ($dynamicErrors !== []) {
            throw new FormValidationException($dynamicErrors);
        }

        $remoteSelectors = $this->remoteSelectorsEnabled('create');

        $categoryId = (int) ($input['itilcategories_id'] ?? 0);
        if ($categoryId > 0) {
            if (
                $remoteSelectors
                && !$this->resourceSelectorProvider->authorizeAll(
                    GlpiResourceSelectorRegistry::CATEGORY,
                    [$categoryId],
                    ['ticket_type' => (int) ($input['type'] ?? 0)]
                )
            ) {
                throw new \RuntimeException(I18n::translate('Categoria inválida para o contexto atual.'));
            }
            $categories = $context['categories'] ?? [];
            $selectedCategory = null;
            foreach ($categories as $category) {
                if ((int) ($category['id'] ?? 0) === $categoryId) {
                    $selectedCategory = $category;
                    break;
                }
            }

            if ($selectedCategory === null && !$remoteSelectors) {
                throw new \RuntimeException(I18n::translate('Categoria inválida para o contexto atual.'));
            }

            if (!$remoteSelectors) {
                $type = (int) ($input['type'] ?? 0);
                $isIncident = !empty($selectedCategory['is_incident']);
                $isRequest = !empty($selectedCategory['is_request']);
                if (($type === 1 && !$isIncident) || ($type === 2 && !$isRequest)) {
                    throw new \RuntimeException(I18n::translate('A categoria selecionada não pode ser usada com esse tipo de chamado.'));
                }
            }
        }

        $locationId = (int) ($input['locations_id'] ?? 0);
        if ($locationId > 0) {
            if (
                $remoteSelectors
                && !$this->resourceSelectorProvider->authorizeAll(
                    GlpiResourceSelectorRegistry::LOCATION,
                    [$locationId]
                )
            ) {
                throw new \RuntimeException(I18n::translate('Localização inválida para a entidade ativa.'));
            }
            $locations = $context['locations'] ?? [];
            $selectedLocation = null;
            foreach ($locations as $location) {
                if ((int) ($location['id'] ?? 0) === $locationId) {
                    $selectedLocation = $location;
                    break;
                }
            }

            if ($selectedLocation === null && !$remoteSelectors) {
                throw new \RuntimeException(I18n::translate('Localização inválida para a entidade ativa.'));
            }
        }

        $actorCatalogs = [
            '_users_id_assign' => 'assignable_users',
            '_users_id_observer' => 'observer_users',
        ];
        foreach ($actorCatalogs as $actorField => $catalogKey) {
            $ids = $this->normalizeActorIds(
                (array) ($input[$actorField] ?? []),
                $actorField
            );
            $purpose = $actorField === '_users_id_assign'
                ? GlpiResourceSelectorRegistry::ASSIGNED_USER
                : GlpiResourceSelectorRegistry::OBSERVER_USER;
            if (
                $remoteSelectors
                && !$this->resourceSelectorProvider->authorizeAll($purpose, $ids)
            ) {
                throw new \RuntimeException(I18n::translate('Ator selecionado inválido para o contexto atual.'));
            }
            $allowedUsers = [];
            foreach (($context[$catalogKey] ?? []) as $user) {
                $allowedUsers[(int) ($user['id'] ?? 0)] = true;
            }
            foreach ($ids as $id) {
                if (!$remoteSelectors && !isset($allowedUsers[$id])) {
                    throw new \RuntimeException(I18n::translate('Ator selecionado inválido para o contexto atual.'));
                }
            }
            $input[$actorField] = $ids;
        }

        $groupFields = [
            '_groups_id_assign' => [
                'context' => 'assignable_groups',
                'error' => I18n::translate('Grupo técnico inválido para o contexto atual.'),
            ],
            '_groups_id_observer' => [
                'context' => 'observer_groups',
                'error' => I18n::translate('Grupo observador inválido para o contexto atual.'),
            ],
        ];
        foreach ($groupFields as $field => $contract) {
            $allowedGroups = [];
            foreach ((array) ($context[$contract['context']] ?? []) as $group) {
                $id = (int) ($group['id'] ?? 0);
                if ($id > 0) {
                    $allowedGroups[$id] = true;
                }
            }
            $groupIds = $this->normalizeActorIds(
                (array) ($input[$field] ?? []),
                $field
            );
            $purpose = $field === '_groups_id_assign'
                ? GlpiResourceSelectorRegistry::ASSIGNED_GROUP
                : GlpiResourceSelectorRegistry::OBSERVER_GROUP;
            if (
                $remoteSelectors
                && !$this->resourceSelectorProvider->authorizeAll($purpose, $groupIds)
            ) {
                throw new \RuntimeException($contract['error']);
            }
            foreach ($groupIds as $groupId) {
                if (!$remoteSelectors && !isset($allowedGroups[$groupId])) {
                    throw new \RuntimeException($contract['error']);
                }
            }
            $input[$field] = $groupIds;
        }

        $requestSourceId = (int) ($input['requesttypes_id'] ?? 0);
        if ($requestSourceId > 0 && !empty($context['request_source_supported'])) {
            $allowedSources = [];
            foreach (($context['request_source_options'] ?? []) as $source) {
                $allowedSources[(int) ($source['id'] ?? 0)] = true;
            }
            if (!isset($allowedSources[$requestSourceId])) {
                throw new \RuntimeException(I18n::translate('Origem da requisição inválida.'));
            }
        }

        $externalId = trim((string) ($input['externalid'] ?? ''));
        if ($externalId !== '' && mb_strlen($externalId) > 255) {
            throw new \RuntimeException(I18n::translate('ID externo deve ter no máximo 255 caracteres.'));
        }
        $input['externalid'] = $externalId;

        $ticketId = $this->repository->createTicket($input);
        UploadedFileMapper::commit($input);
        $attachmentsCount = count((array) ($input['_filename'] ?? []));
        if ($attachmentsCount > 0) {
            $attachmentDiagnostics = $this->repository->ticketDocumentLinkDiagnostics(
                $ticketId,
                $attachmentsCount,
                $this->expectedAttachmentNames($input)
            );
            if (empty($attachmentDiagnostics['available']) || empty($attachmentDiagnostics['complete'])) {
                $this->auditLogger->log('ticket.create.attachment_unverified', [
                    'attachments_count' => $attachmentsCount,
                    'diagnostic_reason' => (string) ($attachmentDiagnostics['reason'] ?? 'unknown'),
                    'linked_count' => (int) ($attachmentDiagnostics['linked'] ?? 0),
                ], $ticketId);

                throw new FormValidationException([[
                    'field' => 'filename',
                    'code' => 'document_link_unverified',
                    'message' => I18n::translate('Chamado criado, mas o vínculo do anexo ainda não foi confirmado pelo GLPI. Não reenvie o arquivo; abra o chamado para verificar.'),
                ]], I18n::translate('Vínculo do anexo pendente.'), [
                    'partial_success' => true,
                    'created_ticket_id' => $ticketId,
                    'attachment_diagnostics' => $attachmentDiagnostics,
                ]);
            }
        }

        $this->auditLogger->log('ticket.create', [
            'type' => (int) ($input['type'] ?? 0),
            'itilcategories_id' => (int) ($input['itilcategories_id'] ?? 0),
            'locations_id' => $locationId,
            'urgency' => (int) ($input['urgency'] ?? 0),
            'impact' => (int) ($input['impact'] ?? 0),
            'assignees_count' => count((array) ($input['_users_id_assign'] ?? [])),
            'watchers_count' => count((array) ($input['_users_id_observer'] ?? [])),
            'groups_count' => count((array) ($input['_groups_id_assign'] ?? [])),
            'observer_groups_count' => count((array) ($input['_groups_id_observer'] ?? [])),
            'attachments_count' => count((array) ($input['_filename'] ?? [])),
            'requesttypes_id' => (int) ($input['requesttypes_id'] ?? 0),
            'externalid_informed' => $externalId !== '',
            'requester_is_current_user' => $requesterId === $currentRequesterId,
        ], $ticketId);

        return $ticketId;
    }

    private function remoteSelectorsEnabled(string $flow): bool
    {
        if (!$this->resourceSelectorProvider instanceof GlpiResourceSelectorProvider) {
            return false;
        }

        return match ($flow) {
            'create' => $this->configService->isResourceSelectorCreateEnabled(),
            'routing' => $this->configService->isResourceSelectorRoutingEnabled(),
            default => false,
        };
    }

    /** @param mixed[] $ids @return int[] */
    private function normalizeActorIds(array $ids, string $field): array
    {
        if (count($ids) > GlpiResourceSelectorProvider::MAX_SELECTED_IDS) {
            throw new FormValidationException([[
                'field' => $field,
                'code' => 'routing_actor_limit',
                'message' => I18n::translate('Um ou mais atores não são elegíveis no contexto atual.'),
            ]]);
        }

        return array_values(array_unique(array_filter(
            array_map('intval', $ids),
            static fn(int $id): bool => $id > 0
        )));
    }

    /** @return array<string,mixed> */
    private function resourceSelectorConfig(string $flow): array
    {
        if (!$this->remoteSelectorsEnabled($flow)) {
            return ['enabled' => false];
        }

        return [
            'enabled' => true,
            'contract' => GlpiResourceSelectorProvider::CONTRACT,
            'version' => GlpiResourceSelectorProvider::VERSION,
            'endpoint' => Url::plugin('front/ticket.resource-selector.php'),
            'context_revision' => $this->resourceSelectorProvider->contextRevision(),
            'timeout_ms' => 5000,
            'page_size' => GlpiResourceSelectorProvider::PAGE_SIZE,
            'min_query_length' => $this->resourceSelectorProvider->minimumQueryLength(
                GlpiResourceSelectorRegistry::ASSIGNED_USER
            ),
        ];
    }

    /**
     * Hydrate only already-confirmed values needed to rerender a failed form.
     *
     * @param array<string,mixed> $input
     * @return array<string,array<int,array{id:int,label:string}>>
     */
    private function hydrateSelectedResources(array $input, bool $includeRequester = false): array
    {
        $contracts = [
            'itilcategories_id' => [
                'purpose' => GlpiResourceSelectorRegistry::CATEGORY,
                'multiple' => false,
                'dependencies' => ['ticket_type' => (int) ($input['type'] ?? 0)],
            ],
            'locations_id' => [
                'purpose' => GlpiResourceSelectorRegistry::LOCATION,
                'multiple' => false,
                'dependencies' => [],
            ],
            '_users_id_assign' => [
                'purpose' => GlpiResourceSelectorRegistry::ASSIGNED_USER,
                'multiple' => true,
                'dependencies' => [],
            ],
            '_users_id_observer' => [
                'purpose' => GlpiResourceSelectorRegistry::OBSERVER_USER,
                'multiple' => true,
                'dependencies' => [],
            ],
            '_groups_id_assign' => [
                'purpose' => GlpiResourceSelectorRegistry::ASSIGNED_GROUP,
                'multiple' => true,
                'dependencies' => [],
            ],
            '_groups_id_observer' => [
                'purpose' => GlpiResourceSelectorRegistry::OBSERVER_GROUP,
                'multiple' => true,
                'dependencies' => [],
            ],
        ];
        if ($includeRequester) {
            $contracts['requester_user_id'] = [
                'purpose' => GlpiResourceSelectorRegistry::REQUESTER_USER,
                'multiple' => false,
                'dependencies' => [],
            ];
        }
        $hydrated = [];
        foreach ($contracts as $field => $contract) {
            $raw = $contract['multiple']
                ? (array) ($input[$field] ?? [])
                : [$input[$field] ?? 0];
            $ids = array_values(array_unique(array_filter(
                array_map('intval', $raw),
                static fn(int $id): bool => $id > 0
            )));
            if ($ids === []) {
                $hydrated[$field] = [];
                continue;
            }
            try {
                $result = $this->resourceSelectorProvider->search(
                    (string) $contract['purpose'],
                    '',
                    null,
                    $ids,
                    (array) $contract['dependencies']
                );
                $hydrated[$field] = array_values(array_filter(
                    (array) ($result['results'] ?? []),
                    static fn($row): bool => is_array($row)
                        && (int) ($row['id'] ?? 0) > 0
                        && trim((string) ($row['label'] ?? '')) !== ''
                ));
            } catch (\Throwable $e) {
                // Do not revive an unauthorized/stale label on error.
                $hydrated[$field] = [];
            }
        }

        return $hydrated;
    }

    /**
     * Hydrate the actors already linked to a ticket without loading candidate
     * catalogs. Each lookup remains ticket/entity scoped in the provider.
     *
     * @param array<string,mixed> $routing
     * @return array<string,array<int,array{id:int,label:string}>>
     */
    private function hydrateRoutingResources(array $routing, int $ticketId): array
    {
        $contracts = [
            '_users_id_requester' => [
                'purpose' => GlpiResourceSelectorRegistry::REQUESTER_USER,
                'ids' => (array) ($routing['requester_user_ids'] ?? []),
            ],
            '_users_id_assign' => [
                'purpose' => GlpiResourceSelectorRegistry::ASSIGNED_USER,
                'ids' => (array) ($routing['assigned_user_ids'] ?? []),
            ],
            '_users_id_observer' => [
                'purpose' => GlpiResourceSelectorRegistry::OBSERVER_USER,
                'ids' => (array) ($routing['observer_user_ids'] ?? []),
            ],
            '_groups_id_requester' => [
                'purpose' => GlpiResourceSelectorRegistry::REQUESTER_GROUP,
                'ids' => (array) ($routing['requester_group_ids'] ?? []),
            ],
            '_groups_id_assign' => [
                'purpose' => GlpiResourceSelectorRegistry::ASSIGNED_GROUP,
                'ids' => (array) ($routing['assigned_group_ids'] ?? []),
            ],
            '_groups_id_observer' => [
                'purpose' => GlpiResourceSelectorRegistry::OBSERVER_GROUP,
                'ids' => (array) ($routing['observer_group_ids'] ?? []),
            ],
            '_suppliers_id_assign' => [
                'purpose' => GlpiResourceSelectorRegistry::ASSIGNED_SUPPLIER,
                'ids' => (array) ($routing['assigned_supplier_ids'] ?? []),
            ],
        ];
        $hydrated = [];
        foreach ($contracts as $field => $contract) {
            $ids = array_values(array_unique(array_filter(
                array_map('intval', $contract['ids']),
                static fn(int $id): bool => $id > 0
            )));
            if ($ids === []) {
                $hydrated[$field] = [];
                continue;
            }
            try {
                $result = $this->resourceSelectorProvider->search(
                    (string) $contract['purpose'],
                    '',
                    null,
                    $ids,
                    ['ticket_id' => $ticketId]
                );
                $hydrated[$field] = array_values(array_filter(
                    (array) ($result['results'] ?? []),
                    static fn($row): bool => is_array($row)
                        && (int) ($row['id'] ?? 0) > 0
                        && trim((string) ($row['label'] ?? '')) !== ''
                ));
            } catch (\Throwable $e) {
                $hydrated[$field] = [];
            }
        }

        return $hydrated;
    }

    /**
     * @param array<string, mixed> $input
     * @param array<string, mixed> $template
     * @return array<string, mixed>
     */
    private function enforceTemplatePolicy(array $input, array $template): array
    {
        $predefined = (array) ($template['predefined'] ?? []);
        $protected = array_unique(array_merge(
            (array) ($template['hidden_fields'] ?? []),
            (array) ($template['readonly_fields'] ?? [])
        ));

        $errors = [];
        foreach (TicketCreationPolicy::SUPPORTED_CREATE_FIELDS as $field) {
            if ($field === '_filename' || !array_key_exists($field, $input)) {
                continue;
            }

            if (array_key_exists($field, $predefined) && !$this->templateValuesEqual($input[$field], $predefined[$field])) {
                $errors[] = [
                    'field' => $field,
                    'code' => 'template_value_mismatch',
                    'message' => sprintf(
                        I18n::translate('%s deve manter o valor definido pelo modelo.'),
                        TicketCreationPolicy::fieldLabel($field)
                    ),
                ];
                continue;
            }

            if (in_array($field, $protected, true) && !array_key_exists($field, $predefined) && $this->hasTemplateValue($input[$field])) {
                $errors[] = [
                    'field' => $field,
                    'code' => 'template_protected_field',
                    'message' => sprintf(
                        I18n::translate('%s não pode ser alterado neste modelo.'),
                        TicketCreationPolicy::fieldLabel($field)
                    ),
                ];
            }
        }
        if ($errors !== []) {
            throw new FormValidationException($errors);
        }

        foreach ($protected as $field) {
            $field = (string) $field;
            if (!in_array($field, TicketCreationPolicy::SUPPORTED_CREATE_FIELDS, true) || $field === '_filename') {
                continue;
            }

            if (array_key_exists($field, $predefined)) {
                $input[$field] = $predefined[$field];
            } else {
                unset($input[$field]);
            }
        }

        foreach (TicketCreationPolicy::SUPPORTED_CREATE_FIELDS as $field) {
            if ($field === '_filename' || !array_key_exists($field, $predefined)) {
                continue;
            }

            $input[$field] = $predefined[$field];
        }

        return $input;
    }

    private function templateValuesEqual(mixed $left, mixed $right): bool
    {
        if (is_array($left) || is_array($right)) {
            $normalize = static function (mixed $value): array {
                $items = array_map('strval', (array) $value);
                sort($items);
                return $items;
            };

            return $normalize($left) === $normalize($right);
        }

        return trim((string) $left) === trim((string) $right);
    }

    private function hasTemplateValue(mixed $value): bool
    {
        if (is_array($value)) {
            return array_values(array_filter($value, static fn(mixed $item): bool => trim((string) $item) !== '')) !== [];
        }

        $value = trim((string) $value);
        return $value !== '' && $value !== '0';
    }

    /**
     * @param string[] $revealedFields
     */
    public function detail(int $ticketId, array $revealedFields = []): ?array
    {
        $this->ensureCanView();
        $ticket = $this->repository->getTicketById($ticketId);
        if ($ticket === null) {
            return null;
        }

        $contact = $this->repository->getTicketRequesterContact($ticketId);
        $maskContacts = $this->configService->isPiiMaskingEnabled();
        $canReveal = $maskContacts
            && $this->authorization->canRevealPii()
            && $this->repository->canUpdateTicket($ticketId);
        $ticket['requester_email'] = (string) ($contact['email'] ?? '');
        $ticket['requester_phone'] = (string) ($contact['phone'] ?? '');
        $ticket['requester_mobile'] = (string) ($contact['mobile'] ?? '');
        $revealedFields = array_values(array_intersect(
            $revealedFields,
            ['requester_email', 'requester_phone', 'requester_mobile']
        ));
        if ($maskContacts) {
            $ticket['requester_email'] = $this->piiMasker->maskEmail($ticket['requester_email']);
            $ticket['requester_phone'] = $this->piiMasker->maskPhone($ticket['requester_phone']);
            $ticket['requester_mobile'] = $this->piiMasker->maskPhone($ticket['requester_mobile']);
            if ($canReveal) {
                foreach ($revealedFields as $field) {
                    $contactField = substr($field, strlen('requester_'));
                    $ticket[$field] = (string) ($contact[$contactField] ?? '');
                }
            }
        }
        $ticket['pii_masking_enabled'] = $maskContacts;
        $ticket['can_reveal_pii'] = $canReveal;
        $ticket['revealed_pii_fields'] = $maskContacts ? $revealedFields : [];

        $ticket['timeline'] = $this->repository->getTicketTimeline($ticketId);
        $ticket['history_context'] = $this->repository->getTicketHistoryContext($ticketId);
        $ticket['actors'] = $this->repository->getTicketActors($ticketId);
        $ticket['documents'] = $this->repository->getTicketDocuments($ticketId);
        $ticket['allowed_transitions'] = method_exists($this->repository, 'getAllowedStatusTransitions')
            ? $this->repository->getAllowedStatusTransitions($ticketId)
            : $this->policy->getAllowedTransitions((int) ($ticket['status'] ?? 0));
        $ticket['itil_actions'] = $this->repository->getTicketActionContext($ticketId);
        $ticket['solution_decision'] = method_exists($this->repository, 'getSolutionDecisionContext')
            ? $this->repository->getSolutionDecisionContext($ticketId)
            : [
                'state' => 'unavailable',
                'visible' => false,
                'can_decide' => false,
                'current_status' => (int) ($ticket['status'] ?? 0),
                'solution_id' => 0,
                'solution_status' => 0,
                'revision' => '',
            ];
        $ticket['general_edit'] = method_exists($this->repository, 'getTicketGeneralEditContext')
            ? $this->repository->getTicketGeneralEditContext($ticketId)
            : [
                'can_update' => false,
                'revision' => '',
                'editable_fields' => [],
                'values' => [],
            ];
        $ticket['general_edit']['resource_selector'] = $this->resourceSelectorConfig('routing');
        $remoteSelectors = $this->remoteSelectorsEnabled('routing');
        $ticket['routing_context'] = $remoteSelectors
            ? $this->repository->getTicketRoutingContext($ticketId, false)
            : $this->repository->getTicketRoutingContext($ticketId);
        $ticket['routing_context']['resource_selector'] = $this->resourceSelectorConfig('routing');
        $ticket['satisfaction_state'] = $this->repository->getTicketSatisfactionState($ticketId);
        $ticket['followup_templates'] = !empty($ticket['itil_actions']['can_add_followup'])
            ? $this->repository->getFollowupTemplatesForTicket($ticketId)
            : [];
        $ticket['task_templates'] = !empty($ticket['itil_actions']['can_add_task'])
            && method_exists($this->repository, 'getTaskTemplatesForTicket')
                ? $this->repository->getTaskTemplatesForTicket($ticketId)
                : [];
        $ticket['solution_templates'] = !empty($ticket['itil_actions']['can_add_solution'])
            && method_exists($this->repository, 'getSolutionTemplatesForTicket')
                ? $this->repository->getSolutionTemplatesForTicket($ticketId)
                : [];
        $ticket['solution_types'] = !empty($ticket['itil_actions']['can_add_solution'])
            && method_exists($this->repository, 'getSolutionTypesForTicket')
                ? $this->repository->getSolutionTypesForTicket($ticketId)
                : [];

        $this->auditLogger->log('ticket.detail', [
            'can_add_followup' => !empty($ticket['itil_actions']['can_add_followup']),
            'can_add_task' => !empty($ticket['itil_actions']['can_add_task']),
            'routing_can_update' => !empty($ticket['routing_context']['can_update']),
            'satisfaction_available' => !empty($ticket['satisfaction_state']['available']),
            'followup_templates_count' => count((array) ($ticket['followup_templates'] ?? [])),
            'task_templates_count' => count((array) ($ticket['task_templates'] ?? [])),
            'solution_templates_count' => count((array) ($ticket['solution_templates'] ?? [])),
            'solution_types_count' => count((array) ($ticket['solution_types'] ?? [])),
            'history_can_view' => !empty($ticket['history_context']['can_view']),
            'history_available' => !empty($ticket['history_context']['available']),
            'history_count' => count((array) ($ticket['history_context']['items'] ?? [])),
        ], $ticketId);

        return $ticket;
    }

    /**
     * @return array{kind:string,template_id:int,text:string,lossy:bool,effects:array<string,int>}
     */
    public function previewItilTemplate(int $ticketId, string $kind, int $templateId): array
    {
        $this->ensureCanView();
        if ($ticketId <= 0 || $templateId <= 0 || !in_array($kind, ['followup', 'task', 'solution'], true)) {
            throw new \InvalidArgumentException('invalid_template_request');
        }

        if ($kind === 'followup') {
            if (
                !$this->repository->canAddFollowupToTicket($ticketId)
                || !method_exists($this->repository, 'renderFollowupTemplatePlainText')
            ) {
                throw new \RuntimeException('template_not_available');
            }
            $resolved = $this->repository->renderFollowupTemplatePlainText($ticketId, $templateId);
            $effects = [
                'is_private' => !empty($resolved['is_private']) ? 1 : 0,
                'requesttypes_id' => max(0, (int) ($resolved['requesttypes_id'] ?? 0)),
            ];
        } elseif ($kind === 'task') {
            if (
                !$this->repository->canAddTaskToTicket($ticketId)
                || !method_exists($this->repository, 'resolveTaskTemplateForTicket')
            ) {
                throw new \RuntimeException('template_not_available');
            }
            if (method_exists($this->repository, 'resolveTaskTemplateForTicketDetailed')) {
                $diagnostic = $this->repository->resolveTaskTemplateForTicketDetailed(
                    $ticketId,
                    $templateId,
                    true
                );
                $resolved = is_array($diagnostic['result'] ?? null)
                    ? $diagnostic['result']
                    : null;
                if (!is_array($resolved)) {
                    throw new ItilTemplateResolutionException(
                        (string) ($diagnostic['reason'] ?? 'unknown')
                    );
                }
            } else {
                $resolved = $this->repository->resolveTaskTemplateForTicket($ticketId, $templateId);
            }
            if (!is_array($resolved)) {
                throw new \RuntimeException('template_not_available');
            }
            $effects = [];
            foreach (
                [
                'is_private',
                'taskcategories_id',
                'state',
                'actiontime',
                'users_id_tech',
                'groups_id_tech',
                'pendingreasons_id',
                ] as $field
            ) {
                $effects[$field] = max(0, (int) ($resolved[$field] ?? 0));
            }
        } else {
            if (
                !$this->repository->canAddSolutionToTicket($ticketId)
                || !method_exists($this->repository, 'resolveSolutionTemplateForTicket')
            ) {
                throw new \RuntimeException('template_not_available');
            }
            $resolved = $this->repository->resolveSolutionTemplateForTicket($ticketId, $templateId);
            if (!is_array($resolved)) {
                throw new \RuntimeException('template_not_available');
            }
            $effects = [
                'solutiontypes_id' => max(0, (int) ($resolved['solutiontypes_id'] ?? 0)),
            ];
        }

        $this->auditLogger->log('ticket.itil_template.preview', [
            'kind' => $kind,
            'template_id' => $templateId,
            'lossy' => !empty($resolved['lossy']),
            'length' => strlen((string) ($resolved['text'] ?? '')),
        ], $ticketId);

        return [
            'kind' => $kind,
            'template_id' => $templateId,
            'text' => (string) ($resolved['text'] ?? ''),
            'lossy' => !empty($resolved['lossy']),
            'effects' => $effects,
        ];
    }

    public function revealPii(int $ticketId, string $field, ?string $reason): void
    {
        if (!$this->configService->isPiiMaskingEnabled()) {
            throw new \RuntimeException(I18n::translate('O mascaramento de contatos pessoais está desativado.'));
        }

        if (!$this->authorization->canRevealPii()) {
            throw new \RuntimeException(I18n::translate('Sem permissão para revelar PII.'));
        }

        if ($this->repository->getTicketById($ticketId) === null) {
            throw new \RuntimeException(I18n::translate('Chamado não encontrado ou sem acesso.'));
        }

        if (!$this->repository->canUpdateTicket($ticketId)) {
            throw new \RuntimeException(I18n::translate('Sem permissão no chamado para revelar PII.'));
        }

        if (trim((string) $reason) === '') {
            throw new \RuntimeException(I18n::translate('Informe o motivo da revelação de PII.'));
        }

        $this->auditLogger->logPiiReveal($ticketId, $field, $reason);
    }

    public function resolveFollowupPrivacy(
        int $ticketId,
        int $followupTemplateId,
        int $requestedPrivacy
    ): int {
        $isPrivate = $requestedPrivacy === 1 ? 1 : 0;
        if (method_exists($this->repository, 'resolveFollowupPrivacy')) {
            return (int) $this->repository->resolveFollowupPrivacy(
                $ticketId,
                $followupTemplateId,
                $isPrivate
            );
        }

        return $isPrivate;
    }

    public function addFollowup(
        int $ticketId,
        string $content,
        array $filesPayload = [],
        int $followupTemplateId = 0,
        int $isPrivate = 0
    ): bool {
        $isPrivate = $this->resolveFollowupPrivacy($ticketId, $followupTemplateId, $isPrivate);
        if (!$this->repository->canAddFollowupToTicket($ticketId, $isPrivate)) {
            throw new \RuntimeException(I18n::translate('Sem permissão para adicionar acompanhamento neste chamado.'));
        }
        $this->ensureOperationalActionAllowed($ticketId);

        if (trim($content) === '' && $followupTemplateId > 0) {
            $content = method_exists($this->repository, 'renderFollowupTemplatePlainText')
                ? (string) ($this->repository->renderFollowupTemplatePlainText($ticketId, $followupTemplateId)['text'] ?? '')
                : $this->repository->renderFollowupTemplateContent($ticketId, $followupTemplateId);
        }

        $created = $this->repository->addFollowup(
            $ticketId,
            $content,
            $filesPayload,
            $followupTemplateId,
            $isPrivate
        );
        $ok = (bool) $created;
        if ($ok) {
            UploadedFileMapper::commit($filesPayload);
            $attachmentsCount = count((array) ($filesPayload['_filename'] ?? []));
            $this->confirmOperationAttachments(
                'ITILFollowup',
                is_int($created) ? $created : 0,
                $attachmentsCount,
                $filesPayload,
                'followup_document',
                'ticket.followup.attachment_unverified',
                $ticketId
            );
            $this->auditLogger->log('ticket.followup.add', [
                'length' => strlen($content),
                'attachments_count' => $attachmentsCount,
                'itilfollowuptemplates_id' => max(0, $followupTemplateId),
                'is_private' => $isPrivate,
            ], $ticketId);
        }

        return $ok;
    }

    public function addTask(
        int $ticketId,
        string $content,
        array $taskInput = [],
        array $filesPayload = [],
        int $taskTemplateId = 0
    ): bool {
        $resolvedTemplate = null;
        if ($taskTemplateId > 0) {
            if (!method_exists($this->repository, 'resolveTaskTemplateForTicket')) {
                throw new \RuntimeException(I18n::translate('Modelo de tarefa indisponível neste ambiente.'));
            }
            $resolvedTemplate = $this->repository->resolveTaskTemplateForTicket($ticketId, $taskTemplateId);
            if (!is_array($resolvedTemplate)) {
                throw new \RuntimeException(I18n::translate('Modelo de tarefa inválido para este chamado, perfil ou entidade.'));
            }
            if (trim($content) === '') {
                $content = (string) ($resolvedTemplate['text'] ?? '');
            }
            foreach (['taskcategories_id', 'actiontime', 'users_id_tech', 'groups_id_tech'] as $field) {
                if ((int) ($taskInput[$field] ?? 0) <= 0 && (int) ($resolvedTemplate[$field] ?? 0) > 0) {
                    $taskInput[$field] = (int) $resolvedTemplate[$field];
                }
            }
            if (!array_key_exists('state', $taskInput) && array_key_exists('state', $resolvedTemplate)) {
                $taskInput['state'] = (int) $resolvedTemplate['state'];
            }
            if (!empty($resolvedTemplate['is_private'])) {
                $taskInput['is_private'] = 1;
            }
        }
        $taskInput['is_private'] = !empty($taskInput['is_private']) ? 1 : 0;
        if (!$this->repository->canAddTaskToTicket($ticketId, (int) $taskInput['is_private'])) {
            throw new \RuntimeException(I18n::translate('Sem permissão para adicionar tarefa neste chamado.'));
        }
        $this->ensureOperationalActionAllowed($ticketId);
        if (trim($content) === '') {
            throw new \RuntimeException(I18n::translate('Informe a descrição da tarefa.'));
        }

        $remoteSelectors = $this->remoteSelectorsEnabled('routing');
        $routing = $remoteSelectors
            ? $this->repository->getTicketRoutingContext($ticketId, false)
            : $this->repository->getTicketRoutingContext($ticketId);
        $technicianId = (int) ($taskInput['users_id_tech'] ?? 0);
        $technicalGroupId = (int) ($taskInput['groups_id_tech'] ?? 0);
        $templateTechnicianId = (int) ($resolvedTemplate['users_id_tech'] ?? 0);
        $templateGroupId = (int) ($resolvedTemplate['groups_id_tech'] ?? 0);
        if ($remoteSelectors) {
            if (
                $technicianId > 0
                && $technicianId !== $templateTechnicianId
                && !$this->resourceSelectorProvider->authorizeAll(
                    GlpiResourceSelectorRegistry::TASK_TECHNICIAN,
                    [$technicianId],
                    ['ticket_id' => $ticketId]
                )
            ) {
                throw new \RuntimeException(I18n::translate('Técnico inválido para este perfil ou entidade.'));
            }
            if (
                $technicalGroupId > 0
                && $technicalGroupId !== $templateGroupId
                && !$this->resourceSelectorProvider->authorizeAll(
                    GlpiResourceSelectorRegistry::TASK_GROUP,
                    [$technicalGroupId],
                    ['ticket_id' => $ticketId]
                )
            ) {
                throw new \RuntimeException(I18n::translate('Grupo técnico inválido para este perfil ou entidade.'));
            }
        } else {
            if ($technicianId !== $templateTechnicianId) {
                $this->assertOptionAllowed($technicianId, (array) ($routing['assignable_users'] ?? []), I18n::translate('Técnico inválido para este perfil ou entidade.'));
            }
            if ($technicalGroupId !== $templateGroupId) {
                $this->assertOptionAllowed($technicalGroupId, (array) ($routing['task_groups'] ?? $routing['assignable_groups'] ?? []), I18n::translate('Grupo técnico inválido para este perfil ou entidade.'));
            }
        }
        foreach (
            [
            ['taskcategories_id', 'task_categories', 'Categoria de tarefa inválida para este perfil ou entidade.'],
            ['state', 'task_state_options', 'Estado da tarefa inválido.'],
            ['actiontime', 'task_duration_options', 'Duração da tarefa inválida.'],
            ] as [$field, $optionsKey, $error]
        ) {
            $value = (int) ($taskInput[$field] ?? 0);
            if ($value !== (int) ($resolvedTemplate[$field] ?? 0)) {
                $this->assertOptionAllowed($value, (array) ($routing[$optionsKey] ?? []), I18n::translate($error));
            }
        }

        $begin = trim((string) ($taskInput['begin'] ?? ''));
        $end = trim((string) ($taskInput['end'] ?? ''));
        if ($begin !== '' && strtotime(str_replace('T', ' ', $begin)) === false) {
            throw new \RuntimeException(I18n::translate('Data inicial da tarefa inválida.'));
        }
        if ($end !== '' && strtotime(str_replace('T', ' ', $end)) === false) {
            throw new \RuntimeException(I18n::translate('Data final da tarefa inválida.'));
        }
        if (
            $begin !== ''
            && $end !== ''
            && strtotime(str_replace('T', ' ', $end)) <= strtotime(str_replace('T', ' ', $begin))
        ) {
            throw new \RuntimeException(I18n::translate('A data final da tarefa deve ser posterior à data inicial.'));
        }

        $created = $taskTemplateId > 0
            ? $this->repository->addTask($ticketId, $content, $taskInput, $filesPayload, $taskTemplateId)
            : $this->repository->addTask($ticketId, $content, $taskInput, $filesPayload);
        $ok = (bool) $created;
        if ($ok) {
            UploadedFileMapper::commit($filesPayload);
            $attachmentsCount = count((array) ($filesPayload['_filename'] ?? []));
            $this->confirmOperationAttachments(
                'TicketTask',
                is_int($created) ? $created : 0,
                $attachmentsCount,
                $filesPayload,
                'task_document',
                'ticket.task.attachment_unverified',
                $ticketId
            );
            $this->auditLogger->log('ticket.task.add', [
                'length' => strlen($content),
                'state' => (int) ($taskInput['state'] ?? 0),
                'taskcategories_id' => (int) ($taskInput['taskcategories_id'] ?? 0),
                'users_id_tech' => (int) ($taskInput['users_id_tech'] ?? 0),
                'groups_id_tech' => (int) ($taskInput['groups_id_tech'] ?? 0),
                'is_private' => !empty($taskInput['is_private']) ? 1 : 0,
                'attachments_count' => $attachmentsCount,
                'tasktemplates_id' => $taskTemplateId,
            ], $ticketId);
        }

        return $ok;
    }
    public function addSolution(
        int $ticketId,
        string $content,
        int $solutionTemplateId = 0,
        ?int $solutionTypeId = null,
        string $idempotencyKey = ''
    ): bool {
        if ($ticketId <= 0) {
            throw new \RuntimeException(I18n::translate('Chamado inválido. Reabra o chamado e tente novamente.'));
        }
        $canAttemptSolution = method_exists($this->repository, 'canAttemptSolutionToTicket')
            ? $this->repository->canAttemptSolutionToTicket($ticketId)
            : $this->repository->canAddSolutionToTicket($ticketId);
        if (!$canAttemptSolution) {
            throw new \RuntimeException(I18n::translate('Sem permissão para adicionar solução neste chamado.'));
        }
        if (method_exists($this->repository, 'getSolutionOperationState')) {
            $operationState = $this->repository->getSolutionOperationState($ticketId);
            if (is_array($operationState) && ($operationState['state'] ?? '') !== 'ready') {
                if (($operationState['state'] ?? '') !== 'partial') {
                    throw new \RuntimeException(I18n::translate('Não foi possível confirmar o estado da operação de solução. Atualize o chamado antes de tentar novamente.'));
                }
                throw new FormValidationException([[
                    'field' => 'solution',
                    'code' => 'solution_outcome_partial',
                    'message' => I18n::translate('Uma solução já foi registrada, mas o status do chamado ainda não foi confirmado. Não envie novamente; atualize e verifique o estado.'),
                ]], I18n::translate('Resultado da solução pendente de confirmação.'), [
                    'partial_success' => true,
                    'created_itemtype' => 'ITILSolution',
                    'created_item_id' => max(0, (int) ($operationState['solution_id'] ?? 0)),
                    'ticket_id' => $ticketId,
                    'outcome' => 'partial',
                ]);
            }
        }
        $this->ensureOperationalActionAllowed($ticketId);
        $solutionTypeId = $solutionTypeId !== null && $solutionTypeId > 0
            ? $solutionTypeId
            : null;

        $resolvedTemplate = null;
        if ($solutionTemplateId > 0) {
            if (!method_exists($this->repository, 'resolveSolutionTemplateForTicket')) {
                throw new \RuntimeException(I18n::translate('Modelo de solução indisponível neste ambiente.'));
            }
            $resolvedTemplate = $this->repository->resolveSolutionTemplateForTicket(
                $ticketId,
                $solutionTemplateId
            );
            if (!is_array($resolvedTemplate)) {
                throw new \RuntimeException(
                    I18n::translate('Modelo de solução inválido para este chamado, perfil ou entidade.')
                );
            }
            if (trim($content) === '') {
                $content = (string) ($resolvedTemplate['text'] ?? '');
            }
            if ($solutionTypeId === null) {
                $templateTypeId = max(0, (int) ($resolvedTemplate['solutiontypes_id'] ?? 0));
                $solutionTypeId = $templateTypeId > 0 ? $templateTypeId : null;
            }
        }

        if (trim($content) === '') {
            throw new \RuntimeException(I18n::translate('Informe a descrição da solução.'));
        }
        if ($solutionTypeId !== null && $solutionTypeId > 0) {
            if (!method_exists($this->repository, 'getSolutionTypesForTicket')) {
                throw new \RuntimeException(I18n::translate('Tipo de solução indisponível neste ambiente.'));
            }
            $this->assertOptionAllowed(
                $solutionTypeId,
                $this->repository->getSolutionTypesForTicket($ticketId),
                I18n::translate('Tipo de solução inválido para este chamado ou entidade.')
            );
        }

        // Recheck native permission immediately before the only mutation.
        $canAttemptSolution = method_exists($this->repository, 'canAttemptSolutionToTicket')
            ? $this->repository->canAttemptSolutionToTicket($ticketId)
            : $this->repository->canAddSolutionToTicket($ticketId);
        if (!$canAttemptSolution) {
            throw new \RuntimeException(I18n::translate('Sem permissão para adicionar solução neste chamado.'));
        }

        if (method_exists($this->repository, 'validateSolutionPreconditions')) {
            $preconditionErrors = $this->repository->validateSolutionPreconditions($ticketId);
            if (is_array($preconditionErrors) && $preconditionErrors !== []) {
                throw new FormValidationException(
                    $preconditionErrors,
                    I18n::translate('Não foi possível concluir a ação. Revise os dados e tente novamente.')
                );
            }
        }

        $ticketBefore = $this->repository->getTicketById($ticketId);
        $statusBefore = (int) ($ticketBefore['status'] ?? 0);
        $committedOutcome = null;
        $markerCleanupConfirmed = true;
        try {
            if (
                $this->idempotencyLedger instanceof IdempotencyLedger
                && method_exists($this->repository, 'addSolutionIdempotently')
            ) {
                if ($idempotencyKey === '') {
                    $idempotencyKey = bin2hex(random_bytes(16));
                }
                $requestHash = hash('sha256', json_encode([
                    'ticket_id' => $ticketId,
                    'content_hash' => hash('sha256', $content),
                    'solutiontemplates_id' => $solutionTemplateId,
                    'solutiontypes_id' => $solutionTypeId ?? 0,
                    'users_id' => (int) ($_SESSION['glpiID'] ?? 0),
                ], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) ?: '');
                $idempotentResult = $this->repository->addSolutionIdempotently(
                    $this->idempotencyLedger,
                    $idempotencyKey,
                    $requestHash,
                    $ticketId,
                    $content,
                    $solutionTemplateId,
                    $solutionTypeId
                );
                $idempotentStatus = (string) ($idempotentResult['status'] ?? '');
                if (in_array($idempotentStatus, [IdempotencyClaim::IN_PROGRESS, IdempotencyClaim::CONFLICT], true)) {
                    $this->auditLogger->log('ticket.solution.rejected', [
                        'stage' => 'idempotency_' . $idempotentStatus,
                        'ticket_status_before' => $statusBefore,
                    ], $ticketId);
                    throw new FormValidationException([[
                        'field' => 'solution',
                        'code' => 'solution_submission_already_processing',
                        'message' => I18n::translate('Esta solução já está sendo processada ou não corresponde à confirmação original. Atualize o chamado antes de tentar novamente.'),
                    ]], '', ['outcome' => 'rejected', 'audit_recorded' => true]);
                }
                if ($idempotentStatus === IdempotencyClaim::REPLAY) {
                    // Completion in the ledger is the immutable result of the
                    // original verified transaction. Do not reclassify or
                    // emit a second terminal audit after a later reopen/refusal.
                    return true;
                }
                if ($idempotentStatus === IdempotencyClaim::ACQUIRED) {
                    $committedOutcome = is_array($idempotentResult['outcome'] ?? null)
                        ? $idempotentResult['outcome']
                        : null;
                    if ($committedOutcome === null) {
                        throw new SolutionMutationOutcomeUncertainException(
                            max(0, (int) ($idempotentResult['result_id'] ?? 0))
                        );
                    }
                }
                $markerCleanupConfirmed = (bool) ($idempotentResult['marker_cleared'] ?? false);
                $created = $idempotentStatus === 'rejected'
                    ? false
                    : (int) ($idempotentResult['result_id'] ?? 0);
            } else {
                $created = $this->repository->addSolution(
                    $ticketId,
                    $content,
                    $solutionTemplateId,
                    $solutionTypeId
                );
            }
        } catch (SolutionMutationOutcomeUncertainException $e) {
            $sharedMarkerPersisted = $e->sharedMarkerPersisted();
            if (!$sharedMarkerPersisted && method_exists($this->repository, 'rememberSolutionOperationPartial')) {
                try {
                    $sharedMarkerPersisted = $this->repository->rememberSolutionOperationPartial(
                        $ticketId,
                        $e->solutionId()
                    ) !== false;
                } catch (\Throwable) {
                    $sharedMarkerPersisted = false;
                }
            }
            $this->auditLogger->log('ticket.solution.partial', [
                'stage' => 'native_add',
                'exception_class' => get_class($e),
                'solutiontemplates_id' => $solutionTemplateId,
                'solutiontypes_id' => $solutionTypeId ?? 0,
                'ticket_status_before' => $statusBefore,
                'shared_marker_persisted' => $sharedMarkerPersisted,
            ], $ticketId);
            throw new FormValidationException([[
                'field' => 'solution',
                'code' => 'solution_outcome_uncertain',
                'message' => I18n::translate('O GLPI não confirmou se a solução foi registrada. Não envie novamente antes de atualizar e verificar o chamado.'),
            ]], I18n::translate('Resultado da solução pendente de confirmação.'), [
                'partial_success' => true,
                'created_itemtype' => 'ITILSolution',
                'created_item_id' => $e->solutionId(),
                'ticket_id' => $ticketId,
                'outcome' => 'partial',
                'audit_recorded' => true,
            ]);
        } catch (FormValidationException $e) {
            throw $e;
        } catch (\Throwable $e) {
            $this->auditLogger->log('ticket.solution.rejected', [
                'stage' => 'pre_mutation_failure',
                'exception_class' => get_class($e),
                'ticket_status_before' => $statusBefore,
            ], $ticketId);
            throw new FormValidationException([[
                'field' => 'solution',
                'code' => 'solution_pre_mutation_failure',
                'message' => I18n::translate('A solução não foi gravada. Atualize o chamado, revise os dados e tente novamente.'),
            ]], '', [
                'outcome' => 'rejected',
                'audit_recorded' => true,
                'ticket_id' => $ticketId,
            ]);
        }

        if ($created === false) {
            if (method_exists($this->repository, 'clearSolutionOperationPartial')) {
                try {
                    $markerCleanupConfirmed = $this->repository->clearSolutionOperationPartial($ticketId) !== false;
                } catch (\Throwable) {
                    $markerCleanupConfirmed = false;
                }
            }
            $this->auditLogger->log('ticket.solution.rejected', [
                'stage' => 'native_add_rejected',
                'solutiontemplates_id' => $solutionTemplateId,
                'solutiontypes_id' => $solutionTypeId ?? 0,
                'ticket_status_before' => $statusBefore,
                'marker_cleanup_confirmed' => $markerCleanupConfirmed,
            ], $ticketId);

            if (method_exists($this->repository, 'getLastSolutionErrors')) {
                $nativeErrors = $this->repository->getLastSolutionErrors();
                if (is_array($nativeErrors) && $nativeErrors !== []) {
                    throw new FormValidationException(
                        $nativeErrors,
                        I18n::translate('Não foi possível registrar a solução no GLPI. Atualize o chamado antes de tentar novamente.'),
                        [
                            'outcome' => 'rejected',
                            'audit_recorded' => true,
                            'ticket_id' => $ticketId,
                        ]
                    );
                }
            }
            return false;
        }

        $solutionId = is_int($created) && $created > 0 ? $created : 0;
        if ($solutionId <= 0) {
            $sharedMarkerPersisted = false;
            if (method_exists($this->repository, 'rememberSolutionOperationPartial')) {
                try {
                    $sharedMarkerPersisted = $this->repository->rememberSolutionOperationPartial(
                        $ticketId,
                        0
                    ) !== false;
                } catch (\Throwable) {
                    $sharedMarkerPersisted = false;
                }
            }
            $this->auditLogger->log('ticket.solution.partial', [
                'stage' => 'native_contract_invalid',
                'solutiontemplates_id' => $solutionTemplateId,
                'solutiontypes_id' => $solutionTypeId ?? 0,
                'ticket_status_before' => $statusBefore,
                'shared_marker_persisted' => $sharedMarkerPersisted,
            ], $ticketId);
            throw new FormValidationException([[
                'field' => 'solution',
                'code' => 'solution_native_result_invalid',
                'message' => I18n::translate('O GLPI não devolveu o identificador da solução. Não envie novamente antes de atualizar e verificar o chamado.'),
            ]], I18n::translate('Resultado da solução pendente de confirmação.'), [
                'partial_success' => true,
                'created_itemtype' => 'ITILSolution',
                'created_item_id' => 0,
                'ticket_id' => $ticketId,
                'outcome' => 'partial',
                'audit_recorded' => true,
            ]);
        }

        if (is_array($committedOutcome)) {
            // This snapshot was verified while the ticket row was locked and
            // before commit. A second authoritative read here would introduce
            // a TOCTOU race with legitimate native reopen/refusal actions.
            $outcome = $committedOutcome;
            $statusAfter = (int) ($outcome['ticket_status'] ?? 0);
        } else {
            try {
                $outcome = null;
                if (method_exists($this->repository, 'verifySolutionOutcome')) {
                    $outcome = $this->repository->verifySolutionOutcome(
                        $solutionId,
                        $ticketId,
                        $solutionTypeId,
                        (int) ($_SESSION['glpiID'] ?? 0)
                    );
                }
                $ticketAfter = $this->repository->getTicketById($ticketId);
                $statusAfter = (int) ($ticketAfter['status'] ?? 0);
            } catch (\Throwable $e) {
                $sharedMarkerPersisted = false;
                if (method_exists($this->repository, 'rememberSolutionOperationPartial')) {
                    try {
                        $sharedMarkerPersisted = $this->repository->rememberSolutionOperationPartial(
                            $ticketId,
                            $solutionId
                        ) !== false;
                    } catch (\Throwable) {
                        $sharedMarkerPersisted = false;
                    }
                }
                $this->auditLogger->log('ticket.solution.partial', [
                    'stage' => 'post_add_verification_failure',
                    'solution_id' => $solutionId,
                    'exception_class' => get_class($e),
                    'ticket_status_before' => $statusBefore,
                    'shared_marker_persisted' => $sharedMarkerPersisted,
                ], $ticketId);
                throw new FormValidationException([[
                    'field' => 'solution',
                    'code' => 'solution_outcome_partial',
                    'message' => I18n::translate('A solução foi registrada, mas a verificação final falhou. Não envie novamente; atualize e verifique o chamado.'),
                ]], '', [
                    'partial_success' => true,
                    'created_itemtype' => 'ITILSolution',
                    'created_item_id' => $solutionId,
                    'ticket_id' => $ticketId,
                    'outcome' => 'partial',
                    'audit_recorded' => true,
                ]);
            }
        }
        $verified = is_array($outcome)
            && !empty($outcome['persisted'])
            && !empty($outcome['type_confirmed'])
            && !empty($outcome['author_confirmed'])
            && !empty($outcome['ticket_readable'])
            && !empty($outcome['status_confirmed']);
        $verification = $verified ? 'verified' : 'partial';

        $auditPayload = [
            'length' => strlen($content),
            'solutiontemplates_id' => $solutionTemplateId,
            'solutiontypes_id' => $solutionTypeId ?? 0,
            'lossy' => !empty($resolvedTemplate['lossy']),
            'solution_id' => $solutionId,
            'verification' => $verification,
            'persisted' => !empty($outcome['persisted']),
            'type_confirmed' => !empty($outcome['type_confirmed']),
            'author_confirmed' => !empty($outcome['author_confirmed']),
            'ticket_status_before' => $statusBefore,
            'ticket_status_after' => $statusAfter,
            'status_confirmed' => !empty($outcome['status_confirmed']),
        ];

        if (!$verified) {
            $sharedMarkerPersisted = false;
            if (method_exists($this->repository, 'rememberSolutionOperationPartial')) {
                try {
                    $sharedMarkerPersisted = $this->repository->rememberSolutionOperationPartial(
                        $ticketId,
                        $solutionId
                    ) !== false;
                } catch (\Throwable) {
                    $sharedMarkerPersisted = false;
                }
            }
            $auditPayload['shared_marker_persisted'] = $sharedMarkerPersisted;
            $this->auditLogger->log('ticket.solution.partial', $auditPayload, $ticketId);
            throw new FormValidationException([[
                'field' => 'solution',
                'code' => 'solution_outcome_partial',
                'message' => I18n::translate('A solução foi registrada, mas o GLPI não confirmou o status final do chamado. Não envie novamente; atualize e verifique o estado.'),
            ]], I18n::translate('Resultado da solução pendente de confirmação.'), [
                'partial_success' => true,
                'created_itemtype' => 'ITILSolution',
                'created_item_id' => $solutionId,
                'ticket_id' => $ticketId,
                'verification' => $verification,
                'outcome' => 'partial',
                'audit_recorded' => true,
            ]);
        }

        if (method_exists($this->repository, 'clearSolutionOperationPartial')) {
            try {
                $markerCleanupConfirmed = $this->repository->clearSolutionOperationPartial($ticketId) !== false;
            } catch (\Throwable) {
                $markerCleanupConfirmed = false;
            }
        }
        $auditPayload['marker_cleanup_confirmed'] = $markerCleanupConfirmed;
        $this->auditLogger->log('ticket.solution.verified', $auditPayload, $ticketId);
        return true;
    }

    public function changeStatus(int $ticketId, int $newStatus): bool
    {
        if ($newStatus <= 0) {
            throw new \RuntimeException(I18n::translate('Selecione um novo status antes de continuar.'));
        }
        if (!$this->repository->canChangeStatusToTicket($ticketId)) {
            throw new \RuntimeException(I18n::translate('Sem permissão para alterar status neste chamado.'));
        }
        $this->ensureOperationalActionAllowed($ticketId);

        $current = $this->repository->getTicketById($ticketId);
        if ($current === null) {
            return false;
        }

        $currentStatus = (int) ($current['status'] ?? 0);
        if ($newStatus === $currentStatus) {
            throw new \RuntimeException(I18n::translate('O novo status deve ser diferente do status atual.'));
        }
        $transitionAllowed = method_exists($this->repository, 'isStatusTransitionAllowed')
            ? $this->repository->isStatusTransitionAllowed($ticketId, $newStatus)
            : $this->policy->isTransitionAllowed($currentStatus, $newStatus);
        if (!$transitionAllowed) {
            throw new \RuntimeException(I18n::translate('Status alvo inválido para o fluxo atual.'));
        }

        $ok = $this->repository->changeStatus($ticketId, $newStatus);
        if ($ok) {
            $this->auditLogger->log('ticket.status.change', [
                'from' => $currentStatus,
                'to' => $newStatus,
            ], $ticketId);
        }

        return $ok;
    }

    /** @return array<string,mixed> */
    public function approveSolution(
        int $ticketId,
        string $comment = '',
        array $filesPayload = [],
        string $expectedRevision = '',
        string $requestKey = ''
    ): array {
        return $this->decideSolution(
            $ticketId,
            'approve',
            $comment,
            $filesPayload,
            $expectedRevision,
            $requestKey
        );
    }

    /** @return array<string,mixed> */
    public function refuseSolution(
        int $ticketId,
        string $comment,
        array $filesPayload = [],
        string $expectedRevision = '',
        string $requestKey = ''
    ): array {
        return $this->decideSolution(
            $ticketId,
            'refuse',
            $comment,
            $filesPayload,
            $expectedRevision,
            $requestKey
        );
    }

    /** @param array<string,mixed> $filesPayload @return array<string,mixed> */
    private function decideSolution(
        int $ticketId,
        string $decision,
        string $comment,
        array $filesPayload,
        string $expectedRevision,
        string $requestKey
    ): array {
        if ($decision === 'refuse' && trim($comment) === '') {
            UploadedFileMapper::cleanup($filesPayload);
            throw new FormValidationException([[
                'field' => 'solution_decision_comment',
                'code' => 'solution_refusal_reason_required',
                'message' => I18n::translate('Informe o motivo da recusa da solução.'),
            ]]);
        }
        if (preg_match('/\A[a-f0-9]{64}\z/D', $expectedRevision) !== 1) {
            UploadedFileMapper::cleanup($filesPayload);
            throw new FormValidationException([[
                'field' => 'solution_decision',
                'code' => 'solution_decision_context_stale',
                'message' => I18n::translate('A solução atual não pôde ser conferida. Recarregue o chamado e revise a decisão.'),
            ]]);
        }
        if (preg_match('/\A[a-f0-9]{32}\z/D', $requestKey) !== 1) {
            UploadedFileMapper::cleanup($filesPayload);
            throw new FormValidationException([[
                'field' => 'solution_decision',
                'code' => 'solution_decision_confirmation_invalid',
                'message' => I18n::translate('A confirmação desta decisão expirou. Recarregue o chamado e confirme novamente.'),
            ]]);
        }
        if (!$this->idempotencyLedger instanceof IdempotencyLedger) {
            UploadedFileMapper::cleanup($filesPayload);
            throw new FormValidationException([[
                'field' => 'solution_decision',
                'code' => 'solution_decision_coordination_unavailable',
                'message' => I18n::translate('A decisão está temporariamente indisponível porque o controle de repetição não pôde ser iniciado.'),
            ]]);
        }

        try {
            $attachmentHashes = $this->solutionDecisionAttachmentFingerprints($filesPayload);
        } catch (\Throwable) {
            UploadedFileMapper::cleanup($filesPayload);
            throw new FormValidationException([[
                'field' => 'solution_decision_filename',
                'code' => 'solution_decision_attachment_fingerprint_failed',
                'message' => I18n::translate('Os anexos não puderam ser conferidos com segurança. Selecione os arquivos novamente.'),
            ]]);
        }
        $profile = is_array($_SESSION['glpiactiveprofile'] ?? null)
            ? (int) ($_SESSION['glpiactiveprofile']['id'] ?? 0)
            : 0;
        $requestHash = hash('sha256', json_encode([
            'ticket_id' => $ticketId,
            'decision' => $decision,
            'users_id' => (int) ($_SESSION['glpiID'] ?? 0),
            'profiles_id' => $profile,
            'entities_id' => (int) ($_SESSION['glpiactive_entity'] ?? 0),
            'revision' => $expectedRevision,
            'comment_hash' => hash('sha256', $comment),
            'attachment_hashes' => $attachmentHashes,
        ], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) ?: '');

        try {
            $result = $this->repository->decideSolutionNatively(
                $this->idempotencyLedger,
                $requestKey,
                $requestHash,
                $expectedRevision,
                $ticketId,
                $decision,
                $comment,
                $filesPayload
            );
        } catch (\Throwable $e) {
            UploadedFileMapper::cleanup($filesPayload);
            $this->auditLogger->log('ticket.solution.decision.rejected', [
                'decision' => $decision,
                'stage' => 'pre_mutation_failure',
                'exception_class' => get_class($e),
            ], $ticketId);
            throw new FormValidationException([[
                'field' => 'solution_decision',
                'code' => 'solution_decision_failure',
                'message' => I18n::translate('A decisão não foi registrada. Atualize o chamado antes de tentar novamente.'),
            ]], '', ['audit_recorded' => true]);
        }

        $status = (string) ($result['status'] ?? 'rejected');
        $outcome = is_array($result['outcome'] ?? null) ? $result['outcome'] : [];
        if (
            in_array($status, [IdempotencyClaim::ACQUIRED, IdempotencyClaim::REPLAY], true)
            && !empty($outcome['verified'])
        ) {
            if ($status === IdempotencyClaim::ACQUIRED) {
                UploadedFileMapper::commit($filesPayload);
            } else {
                UploadedFileMapper::cleanup($filesPayload);
            }
            $this->auditLogger->log('ticket.solution.decision.verified', [
                'decision' => $decision,
                'followup_id' => max(0, (int) ($result['followup_id'] ?? 0)),
                'ticket_status' => max(0, (int) ($outcome['ticket_status'] ?? 0)),
                'solution_status' => max(0, (int) ($outcome['solution_status'] ?? 0)),
                'attachments_count' => count((array) ($filesPayload['_filename'] ?? [])),
                'replayed' => $status === IdempotencyClaim::REPLAY,
                'marker_cleared' => !empty($result['marker_cleared']),
            ], $ticketId);
            return [
                'status' => 'verified',
                'decision' => $decision,
                'followup_id' => max(0, (int) ($result['followup_id'] ?? 0)),
                'ticket_status' => max(0, (int) ($outcome['ticket_status'] ?? 0)),
                'solution_status' => max(0, (int) ($outcome['solution_status'] ?? 0)),
                'replayed' => $status === IdempotencyClaim::REPLAY,
            ];
        }

        UploadedFileMapper::cleanup($filesPayload);
        if ($status === 'uncertain' || ($status === IdempotencyClaim::REPLAY && empty($outcome['verified']))) {
            $this->auditLogger->log('ticket.solution.decision.partial', [
                'decision' => $decision,
                'followup_id' => max(0, (int) ($result['followup_id'] ?? 0)),
                'ticket_status' => max(0, (int) ($outcome['ticket_status'] ?? 0)),
                'solution_status' => max(0, (int) ($outcome['solution_status'] ?? 0)),
                'attachments_count' => count((array) ($filesPayload['_filename'] ?? [])),
                'attachments_confirmed' => !empty($outcome['attachments_confirmed']),
            ], $ticketId);
            throw new FormValidationException([[
                'field' => 'solution_decision',
                'code' => 'solution_decision_outcome_uncertain',
                'message' => I18n::translate('A decisão pode ter sido registrada, mas o estado final não foi confirmado. Não envie novamente; atualize o chamado. Os anexos temporários foram removidos e, se necessário, deverão ser selecionados novamente.'),
            ]], '', [
                'partial_success' => true,
                'created_itemtype' => 'ITILFollowup',
                'created_item_id' => max(0, (int) ($result['followup_id'] ?? 0)),
                'audit_recorded' => true,
            ]);
        }

        $message = match ($status) {
            'context_stale' => I18n::translate('A solução foi alterada por outra pessoa. Atualize o chamado e revise a decisão.'),
            IdempotencyClaim::IN_PROGRESS, IdempotencyClaim::CONFLICT => I18n::translate('Outra decisão sobre esta solução está em andamento. Atualize o chamado antes de tentar novamente.'),
            default => I18n::translate('O GLPI recusou a decisão. Confira o estado do chamado e suas permissões.'),
        };
        throw new FormValidationException([[
            'field' => 'solution_decision',
            'code' => 'solution_decision_rejected',
            'message' => $message,
        ]]);
    }

    /** @param array<string,mixed> $filesPayload @return string[] */
    private function solutionDecisionAttachmentFingerprints(array $filesPayload): array
    {
        $storedFiles = array_values(array_map('strval', (array) ($filesPayload['_filename'] ?? [])));
        $prefixes = array_values(array_map('strval', (array) ($filesPayload['_prefix_filename'] ?? [])));
        if ($storedFiles === []) {
            return [];
        }
        if (!defined('GLPI_TMP_DIR')) {
            throw new \RuntimeException('solution_decision_attachment_directory_unavailable');
        }

        $base = rtrim((string) GLPI_TMP_DIR, DIRECTORY_SEPARATOR);
        $fingerprints = [];
        foreach ($storedFiles as $index => $storedFile) {
            if ($storedFile === '' || basename($storedFile) !== $storedFile) {
                throw new \RuntimeException('solution_decision_attachment_name_invalid');
            }
            $prefix = (string) ($prefixes[$index] ?? '');
            $originalName = $prefix !== '' && str_starts_with($storedFile, $prefix)
                ? substr($storedFile, strlen($prefix))
                : $storedFile;
            $path = $base . DIRECTORY_SEPARATOR . $storedFile;
            $size = @filesize($path);
            $contentHash = @hash_file('sha256', $path);
            if (!is_int($size) || $size < 0 || !is_string($contentHash) || $contentHash === '') {
                throw new \RuntimeException('solution_decision_attachment_read_failed');
            }
            $fingerprints[] = hash('sha256', json_encode([
                'name' => mb_strtolower(basename($originalName), 'UTF-8'),
                'size' => $size,
                'content_sha256' => $contentHash,
            ], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) ?: '');
        }
        sort($fingerprints, SORT_STRING);
        return $fingerprints;
    }

    public function registerRequesterDecision(int $ticketId, int $decision, string $comment): bool
    {
        $ticket = $this->repository->getTicketById($ticketId);
        if ($ticket === null) {
            throw new \RuntimeException(I18n::translate('Chamado não encontrado ou sem acesso.'));
        }

        $requesterId = (int) ($ticket['requester_id'] ?? 0);
        $currentUser = (int) ($_SESSION['glpiID'] ?? 0);
        if ($requesterId <= 0 || ($requesterId !== $currentUser && !$this->authorization->canUpdateTickets())) {
            throw new \RuntimeException(I18n::translate('Apenas o requisitante ou perfis técnicos podem registrar a decisão.'));
        }

        if ($decision < 1 || $decision > 5) {
            throw new \RuntimeException(I18n::translate('Nota de satisfação inválida.'));
        }

        $satisfactionState = $this->repository->getTicketSatisfactionState($ticketId);
        if (empty($satisfactionState['available']) || empty($satisfactionState['can_answer'])) {
            throw new \RuntimeException(I18n::translate('Pesquisa de satisfação indisponível para este chamado.'));
        }

        $ok = $this->repository->applyRequesterDecision($ticketId, $decision, $comment);
        if ($ok) {
            $this->auditLogger->log('ticket.requester_decision', [
                'decision' => $decision,
                'comment_len' => strlen($comment),
            ], $ticketId);
        }

        return $ok;
    }

    /** @return array{status:string,user_id:int} */
    public function assignTicketToMe(int $ticketId, ?string $expectedRevision = null): array
    {
        if ($ticketId <= 0 || preg_match('/\A[a-f0-9]{64}\z/D', (string) $expectedRevision) !== 1) {
            throw new FormValidationException([[
                'field' => 'self_assign',
                'code' => 'self_assign_context_stale',
                'message' => I18n::translate('A atribuição atual não pôde ser conferida. Recarregue o chamado antes de atribuí-lo a você.'),
            ]]);
        }

        // Do not reuse routing permissions or a replacement set of actors.
        // The repository derives the user from the authenticated native session.
        try {
            $outcome = $this->repository->assignTicketToMe($ticketId, $expectedRevision);
        } catch (\Throwable) {
            $outcome = ['status' => 'uncertain', 'user_id' => 0];
        }
        $status = (string) ($outcome['status'] ?? 'uncertain');
        if (!in_array($status, ['verified', 'unchanged', 'denied', 'context_stale', 'rejected', 'uncertain'], true)) {
            $status = 'uncertain';
        }
        $userId = max(0, (int) ($outcome['user_id'] ?? 0));
        if (in_array($status, ['verified', 'unchanged'], true) && $userId <= 0) {
            $status = 'uncertain';
        }

        $successful = in_array($status, ['verified', 'unchanged'], true);
        $this->auditLogger->log(
            $successful ? 'ticket.self_assign' : 'ticket.self_assign.failed',
            ['result' => $status],
            $ticketId
        );
        if ($successful) {
            return ['status' => $status, 'user_id' => $userId];
        }

        $message = match ($status) {
            'denied' => I18n::translate('O GLPI não permite atribuir este chamado a você no contexto atual.'),
            'context_stale' => I18n::translate('O chamado ou suas permissões mudaram. Recarregue a página e revise antes de atribuí-lo a você.'),
            'rejected' => I18n::translate('O GLPI não confirmou sua inclusão como técnico. Confira os responsáveis e as regras do chamado.'),
            default => I18n::translate('Não foi possível confirmar sua atribuição. Não envie novamente; recarregue o chamado e confira os responsáveis.'),
        };
        throw new FormValidationException([[
            'field' => 'self_assign',
            'code' => 'self_assign_' . $status,
            'message' => $message,
        ]], 'Atribuição a mim não confirmada.', [
            'partial_success' => $status === 'uncertain',
            'audit_recorded' => true,
            'ticket_id' => $ticketId,
        ]);
    }

    public function escalateTicketRouting(
        int $ticketId,
        ?array $assignees,
        ?array $watchers,
        string $reason = '',
        ?array $groups = null,
        ?array $observerGroups = null,
        ?string $expectedRevision = null,
        ?array $requesterUsers = null,
        ?array $requesterGroups = null,
        ?array $assignedSuppliers = null
    ): bool {
        if (!method_exists($this->repository, 'canRouteTicket') || !$this->repository->canRouteTicket($ticketId)) {
            throw new \RuntimeException(I18n::translate('Sem permissão no chamado para escalonamento.'));
        }
        $this->ensureOperationalActionAllowed($ticketId);

        $ticket = $this->repository->getTicketById($ticketId);
        if ($ticket === null) {
            throw new \RuntimeException(I18n::translate('Chamado não encontrado ou sem acesso.'));
        }

        $assignees = $assignees === null
            ? null
            : $this->normalizeActorIds($assignees, '_users_id_assign');
        $watchers = $watchers === null
            ? null
            : $this->normalizeActorIds($watchers, '_users_id_observer');
        $groups = $groups === null
            ? null
            : $this->normalizeActorIds($groups, '_groups_id_assign');
        $observerGroups = $observerGroups === null
            ? null
            : $this->normalizeActorIds($observerGroups, '_groups_id_observer');
        $requesterUsers = $requesterUsers === null
            ? null
            : $this->normalizeActorIds($requesterUsers, '_users_id_requester');
        $requesterGroups = $requesterGroups === null
            ? null
            : $this->normalizeActorIds($requesterGroups, '_groups_id_requester');
        $assignedSuppliers = $assignedSuppliers === null
            ? null
            : $this->normalizeActorIds($assignedSuppliers, '_suppliers_id_assign');

        $assignmentRequested = $assignees !== null || $groups !== null || $assignedSuppliers !== null;
        $observersRequested = $watchers !== null || $observerGroups !== null;
        $requestersRequested = $requesterUsers !== null || $requesterGroups !== null;
        $canAssignActors = method_exists($this->repository, 'canAssignTicketActors')
            ? $this->repository->canAssignTicketActors($ticketId)
            : $this->repository->canRouteTicket($ticketId);
        $canObserveActors = method_exists($this->repository, 'canObserveTicketActors')
            ? $this->repository->canObserveTicketActors($ticketId)
            : $this->repository->canRouteTicket($ticketId);
        $canAdminRequesters = method_exists($this->repository, 'canAdminTicketRequesters')
            ? $this->repository->canAdminTicketRequesters($ticketId)
            : false;
        if (
            ($assignmentRequested && !$canAssignActors)
            || ($observersRequested && !$canObserveActors)
            || ($requestersRequested && !$canAdminRequesters)
        ) {
            throw new \RuntimeException(I18n::translate('Sem permissão no chamado para escalonamento.'));
        }

        $routingFields = [];
        $sets = [];
        if ($assignees !== null) {
            $routingFields['_users_id_assign'] = $assignees;
            $sets[GlpiResourceSelectorRegistry::ASSIGNED_USER] = $assignees;
        }
        if ($watchers !== null) {
            $routingFields['_users_id_observer'] = $watchers;
            $sets[GlpiResourceSelectorRegistry::OBSERVER_USER] = $watchers;
        }
        if ($groups !== null) {
            $routingFields['_groups_id_assign'] = $groups;
            $sets[GlpiResourceSelectorRegistry::ASSIGNED_GROUP] = $groups;
        }
        if ($observerGroups !== null) {
            $routingFields['_groups_id_observer'] = $observerGroups;
            $sets[GlpiResourceSelectorRegistry::OBSERVER_GROUP] = $observerGroups;
        }
        if ($requesterUsers !== null) {
            $routingFields['_users_id_requester'] = $requesterUsers;
            $sets[GlpiResourceSelectorRegistry::REQUESTER_USER] = $requesterUsers;
        }
        if ($requesterGroups !== null) {
            $routingFields['_groups_id_requester'] = $requesterGroups;
            $sets[GlpiResourceSelectorRegistry::REQUESTER_GROUP] = $requesterGroups;
        }
        if ($assignedSuppliers !== null) {
            $routingFields['_suppliers_id_assign'] = $assignedSuppliers;
            $sets[GlpiResourceSelectorRegistry::ASSIGNED_SUPPLIER] = $assignedSuppliers;
        }
        $remoteSelectors = $this->remoteSelectorsEnabled('routing');
        $routingContext = $remoteSelectors
            ? $this->repository->getTicketRoutingContext($ticketId, false)
            : $this->repository->getTicketRoutingContext($ticketId);
        $supportsVerifiedRouting = method_exists($this->repository, 'updateTicketRouting');
        if ($supportsVerifiedRouting && empty($routingContext['routing_selection_complete'])) {
            throw new FormValidationException([[
                'field' => 'routing_actors',
                'code' => 'routing_selection_incomplete',
                'message' => I18n::translate('A atribuição atual não pôde ser conferida. Nenhuma alteração foi enviada.'),
            ]]);
        }
        $currentRevision = strtolower(trim((string) ($routingContext['routing_revision'] ?? '')));
        if ($supportsVerifiedRouting && preg_match('/\A[a-f0-9]{64}\z/D', $currentRevision) !== 1) {
            throw new FormValidationException([[
                'field' => 'routing_actors',
                'code' => 'routing_revision_unavailable',
                'message' => I18n::translate('A versão atual da atribuição não pôde ser confirmada. Nenhuma alteração foi enviada.'),
            ]]);
        }
        if ($supportsVerifiedRouting && $expectedRevision === null) {
            $expectedRevision = $currentRevision;
        } elseif (
            $supportsVerifiedRouting
            && !hash_equals($currentRevision, strtolower((string) $expectedRevision))
        ) {
            throw new FormValidationException([[
                'field' => 'routing_actors',
                'code' => 'routing_context_stale',
                'message' => I18n::translate('A atribuição mudou desde que a tela foi carregada. Recarregue o chamado antes de tentar novamente.'),
            ]]);
        }

        if ($remoteSelectors) {
            $currentByPurpose = [
                GlpiResourceSelectorRegistry::ASSIGNED_USER => (array) ($routingContext['assigned_user_ids'] ?? []),
                GlpiResourceSelectorRegistry::OBSERVER_USER => (array) ($routingContext['observer_user_ids'] ?? []),
                GlpiResourceSelectorRegistry::ASSIGNED_GROUP => (array) ($routingContext['assigned_group_ids'] ?? []),
                GlpiResourceSelectorRegistry::OBSERVER_GROUP => (array) ($routingContext['observer_group_ids'] ?? []),
                GlpiResourceSelectorRegistry::REQUESTER_USER => (array) ($routingContext['requester_user_ids'] ?? []),
                GlpiResourceSelectorRegistry::REQUESTER_GROUP => (array) ($routingContext['requester_group_ids'] ?? []),
                GlpiResourceSelectorRegistry::ASSIGNED_SUPPLIER => (array) ($routingContext['assigned_supplier_ids'] ?? []),
            ];
            try {
                foreach ($sets as $purpose => $ids) {
                    $additions = array_values(array_diff(
                        $ids,
                        array_map('intval', (array) ($currentByPurpose[$purpose] ?? []))
                    ));
                    if (
                        !$this->resourceSelectorProvider->authorizeAll(
                            $purpose,
                            $additions,
                            ['ticket_id' => $ticketId]
                        )
                    ) {
                        throw new FormValidationException([[
                            'field' => 'routing_actors',
                            'code' => 'routing_actor_not_eligible',
                            'message' => I18n::translate('Um ou mais atores não são elegíveis no contexto atual.'),
                        ]]);
                    }
                }
            } catch (FormValidationException $e) {
                throw $e;
            } catch (\Throwable $e) {
                throw new FormValidationException([[
                    'field' => 'routing_actors',
                    'code' => 'routing_authorization_unavailable',
                    'message' => I18n::translate('Não foi possível confirmar os atores neste momento. Nenhuma alteração foi enviada.'),
                ]]);
            }
        }

        $allowedUsers = [];
        foreach (($routingContext['assignable_users'] ?? []) as $user) {
            $allowedUsers[(int) ($user['id'] ?? 0)] = true;
        }
        if ($assignees !== null) {
            foreach ($assignees as $id) {
                if (!$remoteSelectors && !isset($allowedUsers[$id])) {
                    throw new \RuntimeException(I18n::translate('Ator inválido para a entidade ativa.'));
                }
            }
        }

        $allowedObserverUsers = [];
        foreach (($routingContext['observer_users'] ?? []) as $user) {
            $allowedObserverUsers[(int) ($user['id'] ?? 0)] = true;
        }
        if ($watchers !== null) {
            foreach ($watchers as $id) {
                if (!$remoteSelectors && !isset($allowedObserverUsers[$id])) {
                    throw new \RuntimeException(I18n::translate('Observador inválido para a entidade ativa.'));
                }
            }
        }

        $allowedGroups = [];
        foreach (($routingContext['assignable_groups'] ?? []) as $group) {
            $allowedGroups[(int) ($group['id'] ?? 0)] = true;
        }
        if ($groups !== null) {
            foreach ($groups as $id) {
                if (!$remoteSelectors && !isset($allowedGroups[$id])) {
                    throw new \RuntimeException(I18n::translate('Grupo técnico inválido para a entidade ativa.'));
                }
            }
        }

        $allowedObserverGroups = [];
        foreach (($routingContext['observer_groups'] ?? []) as $group) {
            $allowedObserverGroups[(int) ($group['id'] ?? 0)] = true;
        }
        if ($observerGroups !== null) {
            foreach ($observerGroups as $id) {
                if (!$remoteSelectors && !isset($allowedObserverGroups[$id])) {
                    throw new \RuntimeException(I18n::translate('Grupo observador inválido para a entidade ativa.'));
                }
            }
        }

        $allowedRequesterUsers = [];
        foreach (($routingContext['requester_users'] ?? []) as $user) {
            $allowedRequesterUsers[(int) ($user['id'] ?? 0)] = true;
        }
        if ($requesterUsers !== null) {
            foreach ($requesterUsers as $id) {
                if (!$remoteSelectors && !isset($allowedRequesterUsers[$id])) {
                    throw new \RuntimeException(I18n::translate('Requerente inválido para a entidade ativa.'));
                }
            }
        }

        $allowedRequesterGroups = [];
        foreach (($routingContext['requester_groups'] ?? []) as $group) {
            $allowedRequesterGroups[(int) ($group['id'] ?? 0)] = true;
        }
        if ($requesterGroups !== null) {
            foreach ($requesterGroups as $id) {
                if (!$remoteSelectors && !isset($allowedRequesterGroups[$id])) {
                    throw new \RuntimeException(I18n::translate('Grupo requerente inválido para a entidade ativa.'));
                }
            }
        }

        $allowedSuppliers = [];
        foreach (($routingContext['assignable_suppliers'] ?? []) as $supplier) {
            $allowedSuppliers[(int) ($supplier['id'] ?? 0)] = true;
        }
        if ($assignedSuppliers !== null) {
            foreach ($assignedSuppliers as $id) {
                if (!$remoteSelectors && !isset($allowedSuppliers[$id])) {
                    throw new \RuntimeException(I18n::translate('Fornecedor inválido para a entidade ativa.'));
                }
            }
        }

        $result = ['status' => 'unchanged', 'changed_fields' => []];
        if ($routingFields !== []) {
            $result = method_exists($this->repository, 'updateTicketRouting')
                ? $this->repository->updateTicketRouting($ticketId, $routingFields, $expectedRevision)
                : [
                    'status' => $this->repository->updateTicketFields($ticketId, $routingFields)
                        ? 'verified'
                        : 'rejected',
                    'changed_fields' => array_keys($routingFields),
                ];
        }
        $resultStatus = (string) ($result['status'] ?? 'rejected');
        if ($resultStatus === 'context_stale') {
            throw new FormValidationException([[
                'field' => 'routing_actors',
                'code' => 'routing_context_stale',
                'message' => I18n::translate('A atribuição mudou desde que esta página foi aberta. Recarregue e revise antes de enviar.'),
            ]]);
        }
        if (in_array($resultStatus, ['verified', 'unchanged'], true)) {
            $this->auditLogger->log('ticket.routing.escalate', [
                'assignees_count' => count($assignees ?? []),
                'watchers_count' => count($watchers ?? []),
                'groups_count' => count($groups ?? []),
                'observer_groups_count' => count($observerGroups ?? []),
                'requester_users_count' => count($requesterUsers ?? []),
                'requester_groups_count' => count($requesterGroups ?? []),
                'assigned_suppliers_count' => count($assignedSuppliers ?? []),
                'fields_changed' => array_keys($routingFields),
                'result' => $resultStatus,
                'reason_len' => strlen(trim($reason)),
            ], $ticketId);
            return true;
        }

        $this->auditLogger->log('ticket.routing.escalate_failed', [
            'result' => $resultStatus === 'uncertain' ? 'uncertain' : 'rejected',
            'fields_changed' => array_values(array_map(
                'strval',
                (array) ($result['changed_fields'] ?? array_keys($routingFields))
            )),
            'reason_len' => strlen(trim($reason)),
        ], $ticketId);

        if ($resultStatus === 'uncertain') {
            throw new FormValidationException([[
                'field' => 'routing_actors',
                'code' => 'routing_update_uncertain',
                'message' => I18n::translate('A confirmação do estado final não foi possível. Confira o chamado antes de tentar novamente.'),
            ]], 'Resultado de atribuição não confirmado.', [
                'partial_success' => true,
                'created_itemtype' => 'Ticket',
                'created_item_id' => $ticketId,
            ]);
        }

        throw new FormValidationException([[
            'field' => 'routing_actors',
            'code' => 'routing_update_rejected',
            'message' => I18n::translate('A atribuição não foi alterada. Revise os atores selecionados.'),
        ]]);
    }

    public function reclassifyTicket(int $ticketId, int $categoryId, ?int $type = null, string $reason = ''): bool
    {
        if (!$this->authorization->canUpdateTickets()) {
            throw new \RuntimeException(I18n::translate('Sem permissão para reclassificar chamado.'));
        }
        if (!$this->repository->canUpdateTicket($ticketId)) {
            throw new \RuntimeException(I18n::translate('Sem permissão no chamado para reclassificação.'));
        }
        $this->ensureOperationalActionAllowed($ticketId);

        $ticket = $this->repository->getTicketById($ticketId);
        if ($ticket === null) {
            throw new \RuntimeException(I18n::translate('Chamado não encontrado ou sem acesso.'));
        }

        if ($categoryId <= 0) {
            throw new \RuntimeException(I18n::translate('Informe uma categoria válida.'));
        }

        $remoteSelectors = $this->remoteSelectorsEnabled('routing');
        $context = $remoteSelectors
            ? $this->repository->getTicketCreationContext(false)
            : $this->repository->getTicketCreationContext();
        if (
            $remoteSelectors
            && !$this->resourceSelectorProvider->authorizeAll(
                GlpiResourceSelectorRegistry::CATEGORY,
                [$categoryId],
                ['ticket_type' => $type ?? (int) ($ticket['type'] ?? 0)]
            )
        ) {
            throw new \RuntimeException(I18n::translate('Categoria inválida para o contexto atual.'));
        }
        $selectedCategory = null;
        foreach (($context['categories'] ?? []) as $category) {
            if ((int) ($category['id'] ?? 0) === $categoryId) {
                $selectedCategory = $category;
                break;
            }
        }
        if ($selectedCategory === null && !$remoteSelectors) {
            throw new \RuntimeException(I18n::translate('Categoria inválida para o contexto atual.'));
        }

        if ($type !== null && !$remoteSelectors) {
            $incidentType = 1;
            $requestType = 2;
            foreach (($context['type_options'] ?? []) as $option) {
                $label = mb_strtolower((string) ($option['label'] ?? ''), 'UTF-8');
                if (str_contains($label, 'incidente')) {
                    $incidentType = (int) ($option['id'] ?? $incidentType);
                }
                if (str_contains($label, 'requis')) {
                    $requestType = (int) ($option['id'] ?? $requestType);
                }
            }

            $isIncident = !empty($selectedCategory['is_incident']);
            $isRequest = !empty($selectedCategory['is_request']);
            if (($type === $incidentType && !$isIncident) || ($type === $requestType && !$isRequest)) {
                throw new \RuntimeException(I18n::translate('Categoria não compatível com o tipo informado.'));
            }
        }

        $payload = ['itilcategories_id' => $categoryId];
        if ($type !== null) {
            $payload['type'] = $type;
        }

        $ok = $this->repository->updateTicketFields($ticketId, $payload);
        if ($ok) {
            $this->auditLogger->log('ticket.reclassify', [
                'itilcategories_id' => $categoryId,
                'type' => $type ?? 0,
                'reason_len' => strlen(trim($reason)),
            ], $ticketId);
        }

        return $ok;
    }

    public function reprioritizeTicket(int $ticketId, int $urgency, int $impact, string $reason = ''): bool
    {
        if (!$this->authorization->canUpdateTickets()) {
            throw new \RuntimeException(I18n::translate('Sem permissão para priorizar chamado.'));
        }
        if (!$this->repository->canUpdateTicket($ticketId)) {
            throw new \RuntimeException(I18n::translate('Sem permissão no chamado para priorização.'));
        }
        $this->ensureOperationalActionAllowed($ticketId);

        $ticket = $this->repository->getTicketById($ticketId);
        if ($ticket === null) {
            throw new \RuntimeException(I18n::translate('Chamado não encontrado ou sem acesso.'));
        }

        if ($urgency < 1 || $urgency > 5 || $impact < 1 || $impact > 5) {
            throw new \RuntimeException(I18n::translate('Urgência e impacto devem estar entre 1 e 5.'));
        }

        $ok = $this->repository->updateTicketFields($ticketId, [
            'urgency' => $urgency,
            'impact' => $impact,
        ]);
        if ($ok) {
            $this->auditLogger->log('ticket.reprioritize', [
                'urgency' => $urgency,
                'impact' => $impact,
                'reason_len' => strlen(trim($reason)),
            ], $ticketId);
        }

        return $ok;
    }

    /**
     * Update scalar native Ticket fields after creation using an optimistic
     * snapshot supplied by detail()['general_edit']['revision'].
     *
     * @param array<string,mixed> $input
     * @return array{status:string,changed_fields:string[],revision:string}
     */
    public function updateGeneralFields(
        int $ticketId,
        array $input,
        ?string $expectedRevision = null,
        string $reason = ''
    ): array {
        $this->ensureCanView();
        $fieldAllowlist = [
            'name',
            'content',
            'type',
            'itilcategories_id',
            'locations_id',
            'requesttypes_id',
            'urgency',
            'impact',
            'priority',
        ];
        $fields = array_intersect_key($input, array_fill_keys($fieldAllowlist, true));
        $unknownFields = array_diff(array_keys($input), $fieldAllowlist);
        if ($unknownFields !== []) {
            throw new FormValidationException([[
                'field' => 'general_fields',
                'code' => 'ticket_general_field_not_allowed',
                'message' => I18n::translate('Um ou mais campos não podem ser alterados por este fluxo.'),
            ]]);
        }
        // Item-scoped native authorization is the source of truth. Requiring
        // Ticket::canUpdate() here would wrongly deny requester/self-service
        // cases that Ticket::can($id, UPDATE) explicitly permits.
        if (!$this->repository->canUpdateTicket($ticketId)) {
            throw new FormValidationException([[
                'field' => 'general_fields',
                'code' => 'ticket_general_update_denied',
                'message' => I18n::translate('Sem permissão para alterar os dados deste chamado.'),
            ]]);
        }
        if (!method_exists($this->repository, 'updateTicketGeneralFields')) {
            throw new FormValidationException([[
                'field' => 'general_fields',
                'code' => 'ticket_general_update_unavailable',
                'message' => I18n::translate('A edição acessível dos dados do chamado não está disponível nesta instalação.'),
            ]]);
        }

        $result = $this->repository->updateTicketGeneralFields(
            $ticketId,
            $fields,
            $expectedRevision
        );
        $status = (string) ($result['status'] ?? 'rejected');
        $changedFields = array_values(array_map(
            'strval',
            (array) ($result['changed_fields'] ?? array_keys($fields))
        ));
        $revision = (string) ($result['revision'] ?? '');
        $normalized = [
            'status' => in_array($status, ['verified', 'unchanged', 'context_stale', 'rejected', 'uncertain'], true)
                ? $status
                : 'rejected',
            'changed_fields' => $changedFields,
            'revision' => preg_match('/\A[a-f0-9]{64}\z/D', $revision) === 1 ? $revision : '',
        ];

        $this->auditLogger->log(
            in_array($normalized['status'], ['verified', 'unchanged'], true)
                ? 'ticket.general.update'
                : 'ticket.general.update_failed',
            [
                'fields_changed' => $changedFields,
                'result' => $normalized['status'],
                'reason_len' => strlen(trim($reason)),
            ],
            $ticketId
        );

        return $normalized;
    }

    public function cockpitMetrics(): array
    {
        $this->ensureCanView();
        $metrics = $this->repository->getCockpitMetrics();
        $auditMetrics = [];
        foreach (['total_open', 'pending', 'solved_today', 'mine_open', 'group_open'] as $key) {
            $metric = is_array($metrics[$key] ?? null) ? $metrics[$key] : [];
            $auditMetrics[$key] = [
                'value' => is_int($metric['value'] ?? null) ? $metric['value'] : null,
                'available' => !empty($metric['available']),
                'completeness' => (string) ($metric['completeness'] ?? 'unknown'),
                'scope' => (string) ($metric['scope'] ?? ''),
                'backend' => (string) ($metric['backend'] ?? 'unavailable'),
                'error_code' => (string) ($metric['error_code'] ?? ''),
                'query_duration_ms' => max(0, (int) ($metric['query_duration_ms'] ?? 0)),
                'native_search_duration_ms' => max(0, (int) ($metric['query_duration_ms'] ?? 0)),
                'duration_ms' => max(0, (int) ($metric['duration_ms'] ?? 0)),
                'non_search_duration_ms' => max(0, (int) ($metric['non_search_duration_ms'] ?? 0)),
            ];
        }
        $this->auditLogger->log('cockpit.view', [
            'generated_at' => (string) ($metrics['generated_at'] ?? ''),
            'timezone' => (string) ($metrics['timezone'] ?? ''),
            'scope' => (string) ($metrics['scope'] ?? ''),
            'backend' => (string) ($metrics['backend'] ?? 'unavailable'),
            'metrics' => $auditMetrics,
            'stage_durations_ms' => (array) ($metrics['stage_durations_ms'] ?? []),
        ]);
        return $metrics;
    }

    /**
     * @return string[]
     */
    private function expectedAttachmentNames(array $payload): array
    {
        $storedNames = array_values(array_map('strval', (array) ($payload['_filename'] ?? [])));
        $prefixes = array_values(array_map('strval', (array) ($payload['_prefix_filename'] ?? [])));
        $names = [];
        foreach ($storedNames as $index => $storedName) {
            $storedName = basename($storedName);
            $prefix = (string) ($prefixes[$index] ?? '');
            $name = $prefix !== '' && str_starts_with($storedName, $prefix)
                ? substr($storedName, strlen($prefix))
                : $storedName;
            if ($name !== '') {
                $names[] = $name;
            }
        }

        return array_values(array_unique($names));
    }

    private function confirmOperationAttachments(
        string $itemtype,
        int $itemId,
        int $attachmentsCount,
        array $filesPayload,
        string $field,
        string $auditEvent,
        int $ticketId
    ): void {
        if ($attachmentsCount <= 0) {
            return;
        }

        $diagnostics = $itemId > 0 && method_exists($this->repository, 'documentItemLinkDiagnostics')
            ? $this->repository->documentItemLinkDiagnostics(
                $itemtype,
                $itemId,
                $attachmentsCount,
                $this->expectedAttachmentNames($filesPayload)
            )
            : [
                'available' => false,
                'complete' => false,
                'reason' => 'created_item_id_unavailable',
                'linked' => 0,
            ];

        if (!empty($diagnostics['available']) && !empty($diagnostics['complete'])) {
            return;
        }

        $this->auditLogger->log($auditEvent, [
            'attachments_count' => $attachmentsCount,
            'diagnostic_reason' => (string) ($diagnostics['reason'] ?? 'unknown'),
            'linked_count' => (int) ($diagnostics['linked'] ?? 0),
            'created_itemtype' => $itemtype,
            'created_item_id' => $itemId,
        ], $ticketId);

        throw new FormValidationException([[
            'field' => $field,
            'code' => 'document_link_unverified',
            'message' => I18n::translate('A ação foi registrada, mas o vínculo do anexo ainda não foi confirmado pelo GLPI. Não reenvie o arquivo; atualize o chamado para verificar.'),
        ]], I18n::translate('Vínculo do anexo pendente.'), [
            'partial_success' => true,
            'created_itemtype' => $itemtype,
            'created_item_id' => $itemId,
            'ticket_id' => $ticketId,
            'attachment_diagnostics' => $diagnostics,
        ]);
    }
    private function ensureCanView(): void
    {
        if (!$this->authorization->canViewTickets()) {
            throw new \RuntimeException(I18n::translate('Usuário sem permissão para visualizar chamados.'));
        }
    }

    private function ensureOperationalActionAllowed(int $ticketId): void
    {
        $ticket = $this->repository->getTicketById($ticketId);
        if ($ticket === null) {
            throw new \RuntimeException(I18n::translate('Chamado não encontrado ou sem acesso.'));
        }

        $status = (int) ($ticket['status'] ?? 0);
        if ($status === $this->solvedStatus() || $status === $this->closedStatus()) {
            throw new \RuntimeException(I18n::translate('Este chamado já está solucionado ou fechado. Use o fluxo de aprovação ou recusa da solução quando disponível.'));
        }
    }

    private function solvedStatus(): int
    {
        return defined('\CommonITILObject::SOLVED') ? (int) \CommonITILObject::SOLVED : 5;
    }

    private function closedStatus(): int
    {
        return defined('\CommonITILObject::CLOSED') ? (int) \CommonITILObject::CLOSED : 6;
    }

    /**
     * @param array<int, array{id:int}> $options
     */
    private function assertOptionAllowed(int $selectedId, array $options, string $message): void
    {
        if ($selectedId <= 0) {
            return;
        }

        foreach ($options as $option) {
            if ((int) ($option['id'] ?? 0) === $selectedId) {
                return;
            }
        }

        throw new \RuntimeException($message);
    }

    private function maskTimelineContent(string $content): string
    {
        $content = preg_replace_callback(
            '/[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}/i',
            fn(array $matches): string => $this->piiMasker->maskEmail((string) $matches[0]),
            $content
        ) ?? $content;

        return preg_replace_callback(
            '/(?<!\d)(?:\+?\d[\d\s().-]{7,}\d)/',
            fn(array $matches): string => $this->piiMasker->maskPhone((string) $matches[0]),
            $content
        ) ?? $content;
    }
}
