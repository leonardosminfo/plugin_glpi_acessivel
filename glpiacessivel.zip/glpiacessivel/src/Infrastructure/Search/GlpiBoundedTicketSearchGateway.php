<?php

declare(strict_types=1);

namespace GlpiPlugin\Glpiacessivel\Infrastructure\Search;

final class GlpiBoundedTicketSearchGateway implements BoundedTicketSearchGatewayInterface
{
    public function __construct(
        private ?BoundedTicketSearchAdapterInterface $adapter,
        private TicketIdQueryExecutorInterface $queryExecutor
    ) {
    }

    public static function forCurrentRuntime(
        int $statementTimeoutMilliseconds = MySqlMariaDbQueryBudget::STATEMENT_TIMEOUT_DEFAULT_MILLISECONDS,
        bool $applyStatementTimeout = true
    ): self {
        $runtimeVersion = defined('GLPI_VERSION') ? (string) constant('GLPI_VERSION') : '';
        $major = self::major($runtimeVersion);
        $adapter = null;
        if ($major === 10) {
            $adapter = new Glpi10BoundedTicketSearchAdapter($runtimeVersion);
        } elseif ($major === 11) {
            $adapter = new Glpi11BoundedTicketSearchAdapter($runtimeVersion);
        }

        return new self(
            $adapter,
            new GlpiTicketIdQueryExecutor(
                new MySqlMariaDbQueryBudget($statementTimeoutMilliseconds, $applyStatementTimeout)
            )
        );
    }

    public function capability(): BoundedTicketSearchCapability
    {
        if ($this->adapter === null) {
            return BoundedTicketSearchCapability::unavailable('bounded_search_glpi_version_unsupported');
        }

        return $this->adapter->capability();
    }

    public function search(BoundedTicketSearchRequest $request): BoundedTicketSearchResult
    {
        if ($this->adapter === null) {
            return BoundedTicketSearchResult::unavailable('bounded_search_glpi_version_unsupported');
        }
        $plan = $this->adapter->buildPlan($request);
        if (!$plan->availableInRuntime()) {
            return BoundedTicketSearchResult::unavailable($plan->reason(), $plan->adapter());
        }

        $startedAt = microtime(true);
        $ids = $this->queryExecutor->fetchIds($plan->sql(), $plan->rowLimit());
        $duration = (int) round((microtime(true) - $startedAt) * 1000);
        if (!is_array($ids) || count($ids) > $plan->rowLimit()) {
            $reason = 'bounded_search_execution_unavailable';
            if ($this->queryExecutor instanceof TicketIdQueryDiagnosticsInterface) {
                $executorReason = $this->queryExecutor->lastFailureReason();
                if ($executorReason === 'bounded_search_statement_timeout') {
                    $reason = $executorReason;
                }
            }
            return BoundedTicketSearchResult::unavailable(
                $reason,
                $plan->adapter()
            );
        }

        $normalized = [];
        foreach ($ids as $id) {
            $id = (int) $id;
            if ($id <= 0 || isset($normalized[$id])) {
                return BoundedTicketSearchResult::unavailable(
                    'bounded_search_ids_invalid',
                    $plan->adapter()
                );
            }
            $normalized[$id] = $id;
        }
        $hasMore = count($normalized) > $request->pageSize();
        $pageIds = array_slice(array_values($normalized), 0, $request->pageSize());

        return BoundedTicketSearchResult::success(
            $pageIds,
            $hasMore,
            $plan->adapter(),
            $duration,
            $plan->effectiveNativeSearch()
        );
    }

    private static function major(string $version): int
    {
        if (preg_match('/\A\s*(\d+)/', $version, $matches) !== 1) {
            return 0;
        }

        return (int) $matches[1];
    }
}
