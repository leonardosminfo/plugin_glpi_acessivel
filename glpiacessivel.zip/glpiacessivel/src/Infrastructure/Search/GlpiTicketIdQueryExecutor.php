<?php

declare(strict_types=1);

namespace GlpiPlugin\Glpiacessivel\Infrastructure\Search;

use GlpiPlugin\Glpiacessivel\Infrastructure\Database\GlpiDatabaseQuery;

final class GlpiTicketIdQueryExecutor implements
    TicketIdQueryExecutorInterface,
    TicketIdQueryDiagnosticsInterface
{
    private const MYSQL_STATEMENT_TIMEOUT_ERROR = 3024;
    private const MARIADB_STATEMENT_TIMEOUT_ERROR = 1969;
    private MySqlMariaDbQueryBudget $queryBudget;
    private ?object $databaseOverride;
    private string $lastFailureReason = '';
    private string $lastDialect = 'unknown';

    public function __construct(
        ?MySqlMariaDbQueryBudget $queryBudget = null,
        ?object $databaseOverride = null
    ) {
        $this->queryBudget = $queryBudget ?? new MySqlMariaDbQueryBudget();
        $this->databaseOverride = $databaseOverride;
    }

    public function fetchIds(string $sql, int $maximumRows): ?array
    {
        $this->lastFailureReason = '';
        $this->lastDialect = 'unknown';

        if (!$this->isBoundedSelect($sql, $maximumRows)) {
            $this->lastFailureReason = 'bounded_select_invalid';
            return null;
        }

        $database = $this->resolveDatabase();
        if (!is_object($database) || !GlpiDatabaseQuery::isSupported($database)) {
            $this->lastFailureReason = 'database_connection_unavailable';
            return null;
        }

        try {
            $outcome = $this->queryBudget->execute(
                $database,
                $sql,
                fn (string $budgetedSql): ?array => $this->executeStatement(
                    $database,
                    $budgetedSql,
                    $maximumRows
                )
            );
        } catch (\Throwable $e) {
            $this->lastFailureReason = 'query_budget_unavailable';
            return null;
        }

        $this->lastDialect = $outcome['dialect'];
        $this->lastFailureReason = $outcome['reason'];

        return $outcome['ids'];
    }

    public function lastFailureReason(): string
    {
        return $this->lastFailureReason;
    }

    public function lastDialect(): string
    {
        return $this->lastDialect;
    }

    private function resolveDatabase(): ?object
    {
        global $DB;

        if ($this->databaseOverride !== null) {
            return $this->databaseOverride;
        }
        try {
            if (class_exists('\DBConnection') && method_exists('\DBConnection', 'getReadConnection')) {
                $database = (new \ReflectionMethod('\DBConnection', 'getReadConnection'))->invoke(null);
                return is_object($database) ? $database : null;
            }
        } catch (\Throwable $e) {
            return null;
        }

        return isset($DB) && is_object($DB) ? $DB : null;
    }

    /** @return int[]|null */
    private function executeStatement(object $database, string $sql, int $maximumRows): ?array
    {
        $outputLevel = ob_get_level();
        ob_start();
        try {
            $result = GlpiDatabaseQuery::execute($database, $sql);
            $errorNumber = $result === false ? $this->databaseErrorNumber($database) : 0;
        } catch (\Throwable $e) {
            $errorNumber = $this->databaseErrorNumber($database);
            if ($errorNumber <= 0) {
                $errorNumber = (int) $e->getCode();
            }
            if ($this->isStatementTimeoutError($errorNumber)) {
                throw new BoundedSearchStatementTimeoutException($errorNumber);
            }
            throw $e;
        } finally {
            // GLPI's SQL error handler may render the complete statement in
            // debug/API mode. A bounded endpoint must never mix that HTML with
            // its JSON contract. SQL remains available in GLPI's server log.
            while (ob_get_level() > $outputLevel) {
                ob_end_clean();
            }
        }
        if ($result === false) {
            if ($this->isStatementTimeoutError($errorNumber)) {
                throw new BoundedSearchStatementTimeoutException($errorNumber);
            }
            return null;
        }

        $ids = [];
        while (count($ids) < $maximumRows) {
            $row = $this->fetchRow($database, $result);
            if ($row === null) {
                return $ids;
            }
            if (!isset($row['id']) || !is_numeric($row['id'])) {
                return null;
            }
            $ids[] = (int) $row['id'];
        }

        // A database/driver that ignores the canonical LIMIT must fail closed.
        return $this->fetchRow($database, $result) === null ? $ids : null;
    }

    private function databaseErrorNumber(object $database): int
    {
        if (!is_callable([$database, 'errno'])) {
            return 0;
        }
        try {
            $errorNumber = $database->errno();
            return is_numeric($errorNumber) ? max(0, (int) $errorNumber) : 0;
        } catch (\Throwable $e) {
            return 0;
        }
    }

    private function isStatementTimeoutError(int $errorNumber): bool
    {
        return in_array($errorNumber, [
            self::MYSQL_STATEMENT_TIMEOUT_ERROR,
            self::MARIADB_STATEMENT_TIMEOUT_ERROR,
        ], true);
    }

    private function isBoundedSelect(string $sql, int $maximumRows): bool
    {
        if ($maximumRows < 1 || $maximumRows > BoundedTicketSearchRequest::MAX_PAGE_SIZE + 1) {
            return false;
        }
        if (preg_match('/\A\s*SELECT\b/is', $sql) !== 1 || $this->hasStatementDelimiter($sql)) {
            return false;
        }
        if (preg_match('/\bLIMIT\s+\d+\s*,\s*(\d+)\s*\z/i', $sql, $matches) !== 1) {
            return false;
        }

        return (int) $matches[1] === $maximumRows;
    }

    private function hasStatementDelimiter(string $sql): bool
    {
        $quote = '';
        $length = strlen($sql);
        for ($index = 0; $index < $length; $index++) {
            $character = $sql[$index];
            if ($quote === '') {
                if ($character === "'" || $character === '"' || $character === '`') {
                    $quote = $character;
                } elseif ($character === ';') {
                    return true;
                }
                continue;
            }
            if ($character === '\\') {
                $index++;
                continue;
            }
            if ($character !== $quote) {
                continue;
            }
            if (($index + 1) < $length && $sql[$index + 1] === $quote) {
                $index++;
                continue;
            }
            $quote = '';
        }

        return $quote !== '';
    }

    /** @param object $database @param mixed $result @return array<string, mixed>|null */
    private function fetchRow(object $database, $result): ?array
    {
        if (method_exists($database, 'fetchAssoc')) {
            $row = $database->fetchAssoc($result);
            return is_array($row) ? $row : null;
        }
        if (is_object($result) && method_exists($result, 'fetch_assoc')) {
            $row = $result->fetch_assoc();
            return is_array($row) ? $row : null;
        }

        return null;
    }
}
