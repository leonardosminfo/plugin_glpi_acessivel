<?php

declare(strict_types=1);

namespace GlpiPlugin\Glpiacessivel\Infrastructure\Search;

abstract class AbstractGlpiBoundedTicketSearchAdapter implements BoundedTicketSearchAdapterInterface
{
    public function __construct(private string $runtimeVersion)
    {
    }

    abstract protected function supportedMajor(): int;

    abstract protected function adapterName(): string;

    public function capability(): BoundedTicketSearchCapability
    {
        $major = $this->runtimeMajor();
        if ($major !== $this->supportedMajor()) {
            return BoundedTicketSearchCapability::unavailable(
                'bounded_search_glpi_version_unsupported',
                $this->adapterName()
            );
        }
        foreach (['manageParams', 'prepareDatasForSearch', 'constructSQL'] as $method) {
            if (!method_exists('\Search', $method)) {
                return BoundedTicketSearchCapability::unavailable(
                    'bounded_search_search_facade_unavailable',
                    $this->adapterName()
                );
            }
        }
        if (!class_exists('\Ticket') || !method_exists('\Ticket', 'getTable')) {
            return BoundedTicketSearchCapability::unavailable(
                'bounded_search_ticket_contract_unavailable',
                $this->adapterName()
            );
        }

        return BoundedTicketSearchCapability::available($this->adapterName());
    }

    public function buildPlan(BoundedTicketSearchRequest $request): BoundedTicketSearchPlan
    {
        $capability = $this->capability();
        if (!$capability->availableInRuntime()) {
            return BoundedTicketSearchPlan::unavailable($capability->reason(), $capability->adapter());
        }
        if ($request->validationError() !== '') {
            return BoundedTicketSearchPlan::unavailable(
                $request->validationError(),
                $this->adapterName()
            );
        }
        if ($request->itemtype() !== \Ticket::class || $request->idOption() <= 0) {
            return BoundedTicketSearchPlan::unavailable(
                'bounded_search_request_invalid',
                $this->adapterName()
            );
        }

        $hadSession = isset($_SESSION);
        $sessionBefore = $hadSession ? $_SESSION : null;
        try {
            // Omitting all semantic keys is intentional on the native-default
            // path. Empty criteria or reset would suppress GLPI's own default.
            $parameters = $request->shouldResolveNativeDefault()
                ? []
                : $request->parameters();
            if (!$request->shouldResolveNativeDefault()) {
                $parameters['start'] = $request->offset();
                $parameters['list_limit'] = $request->sentinelLimit();
                $parameters['export_all'] = 0;
            }
            $parameters = \Search::manageParams($request->itemtype(), $parameters, false, false);
            if (!is_array($parameters)) {
                return BoundedTicketSearchPlan::unavailable(
                    'bounded_search_parameters_unavailable',
                    $this->adapterName()
                );
            }
            $parameters['start'] = $request->offset();
            $parameters['list_limit'] = $request->sentinelLimit();
            $parameters['export_all'] = 0;

            $prepareMethod = new \ReflectionMethod('\Search', 'prepareDatasForSearch');
            $data = $prepareMethod->invoke(
                null,
                $request->itemtype(),
                $parameters,
                [$request->idOption()]
            );
            if (!is_array($data) || !is_array($data['search'] ?? null)) {
                return BoundedTicketSearchPlan::unavailable(
                    'bounded_search_preparation_unavailable',
                    $this->adapterName()
                );
            }

            $data['search']['start'] = $request->offset();
            $data['search']['list_limit'] = $request->sentinelLimit();
            $data['search']['export_all'] = 0;
            $effectiveNativeSearch = $this->effectiveNativeSearchSnapshot($data['search']);
            $this->appendStableIdSort($data, $request->idOption());
            $constructMethod = new \ReflectionMethod('\Search', 'constructSQL');
            $constructed = $constructMethod->invokeArgs(null, [&$data]);
            if ($constructed === false || !is_array($data['sql']['raw'] ?? null)) {
                return BoundedTicketSearchPlan::unavailable(
                    'bounded_search_sql_shape_unavailable',
                    $this->adapterName()
                );
            }

            return $this->buildNativeLimitedPlan(
                $data['sql']['raw'],
                $request,
                $effectiveNativeSearch
            );
        } catch (\Throwable $e) {
            return BoundedTicketSearchPlan::unavailable(
                'bounded_search_plan_failed',
                $this->adapterName()
            );
        } finally {
            if ($hadSession) {
                $_SESSION = $sessionBefore;
            } else {
                unset($_SESSION);
            }
        }
    }

    /** @param array<string, mixed> $data */
    private function appendStableIdSort(array &$data, int $idOption): void
    {
        $sort = array_values(array_filter(
            (array) ($data['search']['sort'] ?? []),
            static fn($value): bool => is_numeric($value) && (int) $value > 0
        ));
        $orders = array_values((array) ($data['search']['order'] ?? []));
        if (!in_array($idOption, array_map('intval', $sort), true)) {
            $sort[] = $idOption;
            $orders[] = 'ASC';
        }
        while (count($orders) < count($sort)) {
            $orders[] = 'ASC';
        }

        $data['search']['sort'] = array_map('intval', $sort);
        $data['search']['order'] = array_map(
            static fn($value): string => strtoupper((string) $value) === 'DESC' ? 'DESC' : 'ASC',
            array_slice($orders, 0, count($sort))
        );
    }

    /**
     * @param array<string, mixed> $raw
     */
    private function buildNativeLimitedPlan(
        array $raw,
        BoundedTicketSearchRequest $request,
        array $effectiveNativeSearch
    ): BoundedTicketSearchPlan {
        $fragments = NativeTicketSearchSqlFragments::fromRaw($raw);
        if ($fragments === null) {
            return BoundedTicketSearchPlan::unavailable(
                'bounded_search_sql_shape_unavailable',
                $this->adapterName()
            );
        }

        return BoundedTicketSearchPlan::available(
            $fragments->withCanonicalLimit($request->offset(), $request->sentinelLimit()),
            $this->adapterName(),
            $request->sentinelLimit(),
            $effectiveNativeSearch
        );
    }

    /**
     * Preserve only the semantic, non-SQL portion of the exact Search plan.
     * This runs before the plugin adds its technical ID tie-breaker.
     *
     * @param array<string,mixed> $search
     * @return array<string,mixed>
     */
    private function effectiveNativeSearchSnapshot(array $search): array
    {
        $snapshot = [
            'criteria' => is_array($search['criteria'] ?? null) ? $search['criteria'] : [],
            'metacriteria' => is_array($search['metacriteria'] ?? null) ? $search['metacriteria'] : [],
            'sort' => is_array($search['sort'] ?? null) ? array_values($search['sort']) : [],
            'order' => is_array($search['order'] ?? null) ? array_values($search['order']) : [],
            'is_deleted' => (int) ($search['is_deleted'] ?? 0),
        ];
        return $snapshot;
    }

    private function runtimeMajor(): int
    {
        if (preg_match('/\A\s*(\d+)/', $this->runtimeVersion, $matches) !== 1) {
            return 0;
        }

        return (int) $matches[1];
    }
}
