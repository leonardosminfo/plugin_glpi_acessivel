<?php

declare(strict_types=1);

namespace GlpiPlugin\Glpiacessivel\Infrastructure\Search;

use GlpiPlugin\Glpiacessivel\Infrastructure\Database\GlpiDatabaseQuery;

/**
 * Applies a server-side execution budget without rewriting the native GLPI SQL.
 */
final class MySqlMariaDbQueryBudget
{
    public const STATEMENT_TIMEOUT_MINIMUM_MILLISECONDS = 1000;
    public const STATEMENT_TIMEOUT_MAXIMUM_MILLISECONDS = 9000;
    public const STATEMENT_TIMEOUT_DEFAULT_MILLISECONDS = 3000;
    /** @deprecated Use STATEMENT_TIMEOUT_DEFAULT_MILLISECONDS. */
    public const STATEMENT_TIMEOUT_MILLISECONDS = self::STATEMENT_TIMEOUT_DEFAULT_MILLISECONDS;
    public const GROUP_CONCAT_MAX_LENGTH = 8194304;
    public const MINIMUM_CAPACITY_LEASE_SECONDS = 8;

    private const DIALECT_MYSQL = 'mysql';
    private const DIALECT_MARIADB = 'mariadb';

    private int $statementTimeoutMilliseconds;
    private int $lastEffectiveTimeoutMilliseconds;

    public function __construct(
        int $statementTimeoutMilliseconds = self::STATEMENT_TIMEOUT_DEFAULT_MILLISECONDS,
        private bool $applyStatementTimeout = true
    ) {
        $this->statementTimeoutMilliseconds = min(
            self::STATEMENT_TIMEOUT_MAXIMUM_MILLISECONDS,
            max(self::STATEMENT_TIMEOUT_MINIMUM_MILLISECONDS, $statementTimeoutMilliseconds)
        );
        $this->lastEffectiveTimeoutMilliseconds = $applyStatementTimeout ? $this->statementTimeoutMilliseconds : 0;
    }

    public function configuredTimeoutMilliseconds(): int
    {
        return $this->statementTimeoutMilliseconds;
    }

    public function lastEffectiveTimeoutMilliseconds(): int
    {
        return $this->lastEffectiveTimeoutMilliseconds;
    }

    /**
     * @param callable(string):?array<int, int> $executeStatement
     * @return array{ids:?array<int, int>,reason:string,dialect:string}
     */
    public function execute(object $database, string $sql, callable $executeStatement): array
    {
        $dialect = $this->detectDialect($database);
        if ($dialect === null) {
            return $this->failure('database_dialect_unsupported');
        }

        if ($dialect === self::DIALECT_MARIADB) {
            return $this->executeMariaDb($database, $sql, $executeStatement);
        }

        return $this->executeMySql($database, $sql, $executeStatement);
    }

    /**
     * @param callable(string):?array<int, int> $executeStatement
     * @return array{ids:?array<int, int>,reason:string,dialect:string}
     */
    private function executeMariaDb(object $database, string $sql, callable $executeStatement): array
    {
        $sessionTimeoutSeconds = $this->applyStatementTimeout ? $this->readNonNegativeNumber(
            $database,
            'SELECT @@SESSION.max_statement_time AS configured_value'
        ) : 0.0;
        if ($sessionTimeoutSeconds === null) {
            return $this->failure('session_statement_timeout_snapshot_failed', self::DIALECT_MARIADB);
        }
        $effectiveTimeoutMilliseconds = $this->effectiveTimeoutMilliseconds(
            $sessionTimeoutSeconds > 0.0
                ? max(1, (int) floor($sessionTimeoutSeconds * 1000))
                : 0
        );
        $timeoutSeconds = number_format(
            $effectiveTimeoutMilliseconds / 1000,
            3,
            '.',
            ''
        );
        // Preserve aggregation semantics even without our timeout. Never set the
        // environment's timeout to zero or replace a stricter server limit.
        $budgetedSql = 'SET STATEMENT '
            . ($this->applyStatementTimeout ? 'max_statement_time=' . $timeoutSeconds . ', ' : '')
            . 'group_concat_max_len=' . self::GROUP_CONCAT_MAX_LENGTH
            . ' FOR ' . $sql;

        try {
            $ids = $executeStatement($budgetedSql);
        } catch (BoundedSearchStatementTimeoutException $e) {
            return $this->failure('bounded_search_statement_timeout', self::DIALECT_MARIADB);
        } catch (\Throwable $e) {
            return $this->failure('statement_execution_failed', self::DIALECT_MARIADB);
        }

        if (!is_array($ids)) {
            return $this->failure('statement_execution_failed', self::DIALECT_MARIADB);
        }

        return [
            'ids' => $ids,
            'reason' => '',
            'dialect' => self::DIALECT_MARIADB,
        ];
    }

    /**
     * @param callable(string):?array<int, int> $executeStatement
     * @return array{ids:?array<int, int>,reason:string,dialect:string}
     */
    private function executeMySql(object $database, string $sql, callable $executeStatement): array
    {
        $sessionStatementTimeout = $this->applyStatementTimeout ? $this->readNonNegativeInteger(
            $database,
            'SELECT @@SESSION.max_execution_time AS configured_value'
        ) : 0;
        if ($sessionStatementTimeout === null) {
            return $this->failure('session_statement_timeout_snapshot_failed', self::DIALECT_MYSQL);
        }
        $effectiveTimeoutMilliseconds = $this->effectiveTimeoutMilliseconds($sessionStatementTimeout);
        $originalGroupConcatLength = $this->readPositiveInteger(
            $database,
            'SELECT @@SESSION.group_concat_max_len AS configured_value'
        );
        if ($originalGroupConcatLength === null) {
            return $this->failure('session_budget_snapshot_failed', self::DIALECT_MYSQL);
        }

        $restoreRequired = $originalGroupConcatLength < self::GROUP_CONCAT_MAX_LENGTH;
        $restored = true;
        $ids = null;
        $reason = '';

        try {
            if (
                $restoreRequired
                && !$this->executeControlStatement(
                    $database,
                    'SET SESSION group_concat_max_len=' . self::GROUP_CONCAT_MAX_LENGTH
                )
            ) {
                $reason = 'session_budget_apply_failed';
            } else {
                $budgetedSql = $this->applyStatementTimeout
                    ? $this->withMySqlTimeoutHint($sql, $effectiveTimeoutMilliseconds)
                    : $sql;
                if ($budgetedSql === null) {
                    $reason = 'statement_budget_apply_failed';
                } else {
                    $ids = $executeStatement($budgetedSql);
                    if (!is_array($ids)) {
                        $reason = 'statement_execution_failed';
                    }
                }
            }
        } catch (BoundedSearchStatementTimeoutException $e) {
            $ids = null;
            $reason = 'bounded_search_statement_timeout';
        } catch (\Throwable $e) {
            $ids = null;
            $reason = 'statement_execution_failed';
        } finally {
            if ($restoreRequired) {
                try {
                    $restored = $this->executeControlStatement(
                        $database,
                        'SET SESSION group_concat_max_len=' . $originalGroupConcatLength
                    );
                } catch (\Throwable $e) {
                    $restored = false;
                }
            }
        }

        if (!$restored) {
            return $this->failure('session_budget_restore_failed', self::DIALECT_MYSQL);
        }
        if ($reason !== '' || !is_array($ids)) {
            return $this->failure(
                $reason !== '' ? $reason : 'statement_execution_failed',
                self::DIALECT_MYSQL
            );
        }

        return [
            'ids' => $ids,
            'reason' => '',
            'dialect' => self::DIALECT_MYSQL,
        ];
    }

    private function withMySqlTimeoutHint(string $sql, int $timeoutMilliseconds): ?string
    {
        if (preg_match('/\A(\s*SELECT\b)/i', $sql, $matches) !== 1) {
            return null;
        }

        $prefixLength = strlen($matches[1]);
        return substr($sql, 0, $prefixLength)
            . ' /*+ MAX_EXECUTION_TIME(' . $timeoutMilliseconds . ') */'
            . substr($sql, $prefixLength);
    }

    private function detectDialect(object $database): ?string
    {
        $version = $this->readScalar($database, 'SELECT VERSION() AS configured_value');
        if (!is_string($version) && !is_numeric($version)) {
            return null;
        }
        $version = (string) $version;
        if (stripos($version, 'mariadb') !== false) {
            if (preg_match('/(\d+\.\d+(?:\.\d+)?)\s*-MariaDB/i', $version, $matches) !== 1) {
                return null;
            }
            $numericVersion = $matches[1];
            return version_compare($numericVersion, '10.2.0', '>=')
                ? self::DIALECT_MARIADB
                : null;
        }
        if (preg_match('/\A\s*(\d+\.\d+(?:\.\d+)?)/', $version, $matches) !== 1) {
            return null;
        }
        return version_compare($matches[1], '5.7.8', '>=')
            ? self::DIALECT_MYSQL
            : null;
    }

    private function readPositiveInteger(object $database, string $sql): ?int
    {
        $value = $this->readScalar($database, $sql);
        if (!is_numeric($value)) {
            return null;
        }
        $value = (int) $value;

        return $value > 0 ? $value : null;
    }

    private function readNonNegativeInteger(object $database, string $sql): ?int
    {
        $value = $this->readScalar($database, $sql);
        if (!is_numeric($value) || (float) $value < 0) {
            return null;
        }

        return (int) $value;
    }

    private function readNonNegativeNumber(object $database, string $sql): ?float
    {
        $value = $this->readScalar($database, $sql);
        if (!is_numeric($value)) {
            return null;
        }
        $number = (float) $value;

        return is_finite($number) && $number >= 0.0 ? $number : null;
    }

    private function effectiveTimeoutMilliseconds(int $sessionTimeoutMilliseconds): int
    {
        if (!$this->applyStatementTimeout) {
            // Unknown/inherited, not proof that the database has no deadline.
            return $this->lastEffectiveTimeoutMilliseconds = 0;
        }
        $effective = $this->statementTimeoutMilliseconds;
        if ($sessionTimeoutMilliseconds > 0) {
            $effective = min($effective, $sessionTimeoutMilliseconds);
        }
        $this->lastEffectiveTimeoutMilliseconds = max(1, $effective);

        return $this->lastEffectiveTimeoutMilliseconds;
    }

    /** @return mixed */
    private function readScalar(object $database, string $sql)
    {
        $result = GlpiDatabaseQuery::execute($database, $sql);
        if ($result === false) {
            return null;
        }
        $row = $this->fetchRow($database, $result);

        return is_array($row) && array_key_exists('configured_value', $row)
            ? $row['configured_value']
            : null;
    }

    private function executeControlStatement(object $database, string $sql): bool
    {
        return GlpiDatabaseQuery::execute($database, $sql) !== false;
    }

    /** @param mixed $result @return array<string, mixed>|null */
    private function fetchRow(object $database, $result): ?array
    {
        if (method_exists($database, 'fetchAssoc')) {
            $row = $database->fetchAssoc($result);
            return is_array($row) ? $row : null;
        }
        if (is_object($result) && method_exists($result, 'fetch_assoc')) {
            $row = $result->fetch_assoc();
            return is_array($row) ? $row : null;
        }

        return null;
    }

    /** @return array{ids:null,reason:string,dialect:string} */
    private function failure(string $reason, string $dialect = 'unknown'): array
    {
        return [
            'ids' => null,
            'reason' => $reason,
            'dialect' => $dialect,
        ];
    }
}
