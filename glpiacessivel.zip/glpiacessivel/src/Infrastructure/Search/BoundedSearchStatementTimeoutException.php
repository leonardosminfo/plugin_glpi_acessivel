<?php

declare(strict_types=1);

namespace GlpiPlugin\Glpiacessivel\Infrastructure\Search;

/**
 * Internal signal for a database-enforced timeout of a bounded ticket search.
 *
 * The exception deliberately carries no SQL or database error message. Only
 * the numeric error code is retained so upper layers can return a stable,
 * non-sensitive failure reason.
 */
final class BoundedSearchStatementTimeoutException extends \RuntimeException
{
    public function __construct(private int $databaseErrorCode)
    {
        parent::__construct('bounded_search_statement_timeout', $databaseErrorCode);
    }

    public function databaseErrorCode(): int
    {
        return $this->databaseErrorCode;
    }
}
