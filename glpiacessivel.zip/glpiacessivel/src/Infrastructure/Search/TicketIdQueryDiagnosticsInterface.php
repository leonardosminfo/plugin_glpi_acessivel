<?php

declare(strict_types=1);

namespace GlpiPlugin\Glpiacessivel\Infrastructure\Search;

/**
 * Optional diagnostics contract kept separate from TicketIdQueryExecutorInterface
 * so existing adapters and test doubles remain source-compatible.
 */
interface TicketIdQueryDiagnosticsInterface
{
    public function lastFailureReason(): string;

    public function lastDialect(): string;
}
