<?php

declare(strict_types=1);

namespace GlpiPlugin\Glpiacessivel\Infrastructure\Search;

final class BoundedTicketSearchResult
{
    /** @param int[] $ticketIds */
    private function __construct(
        private bool $available,
        private array $ticketIds,
        private bool $hasMore,
        private string $reason,
        private string $adapter,
        private int $queryDurationMs,
        private array $effectiveNativeSearch
    ) {
    }

    /** @param int[] $ticketIds */
    public static function success(
        array $ticketIds,
        bool $hasMore,
        string $adapter,
        int $queryDurationMs,
        array $effectiveNativeSearch = []
    ): self {
        return new self(
            true,
            $ticketIds,
            $hasMore,
            '',
            $adapter,
            max(0, $queryDurationMs),
            $effectiveNativeSearch
        );
    }

    public static function unavailable(string $reason, string $adapter = ''): self
    {
        return new self(false, [], false, $reason, $adapter, 0, []);
    }

    public function available(): bool
    {
        return $this->available;
    }

    /** @return int[] */
    public function ticketIds(): array
    {
        return $this->ticketIds;
    }

    public function hasMore(): bool
    {
        return $this->hasMore;
    }

    public function reason(): string
    {
        return $this->reason;
    }

    public function adapter(): string
    {
        return $this->adapter;
    }

    public function queryDurationMs(): int
    {
        return $this->queryDurationMs;
    }

    /** @return array<string,mixed> */
    public function effectiveNativeSearch(): array
    {
        return $this->effectiveNativeSearch;
    }
}
