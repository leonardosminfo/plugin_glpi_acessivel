<?php

declare(strict_types=1);

namespace GlpiPlugin\Glpiacessivel\Infrastructure\Search;

final class BoundedTicketSearchRequest
{
    public const MAX_PAGE_SIZE = 50;
    public const MAX_OFFSET = 10000;

    /**
     * @param array<string, mixed> $parameters
     */
    public function __construct(
        private string $itemtype,
        private array $parameters,
        private int $idOption,
        private int $page,
        private int $pageSize,
        private bool $resolveNativeDefault = false
    ) {
    }

    public function itemtype(): string
    {
        return $this->itemtype;
    }

    /** @return array<string, mixed> */
    public function parameters(): array
    {
        return $this->parameters;
    }

    public function idOption(): int
    {
        return $this->idOption;
    }

    public function page(): int
    {
        return $this->page;
    }

    public function pageSize(): int
    {
        return $this->pageSize;
    }

    public function shouldResolveNativeDefault(): bool
    {
        return $this->resolveNativeDefault;
    }

    public function validationError(): string
    {
        if ($this->page < 1) {
            return 'bounded_search_page_invalid';
        }
        if ($this->pageSize < 1 || $this->pageSize > self::MAX_PAGE_SIZE) {
            return 'bounded_search_page_size_out_of_range';
        }

        // Validate before multiplying so a hostile page cannot overflow an
        // integer (or be coerced to a float) on PHP 8.1+.
        if (($this->page - 1) > intdiv(self::MAX_OFFSET, $this->pageSize)) {
            return 'bounded_search_offset_limit_exceeded';
        }

        return '';
    }

    public function offset(): int
    {
        if ($this->validationError() !== '') {
            return 0;
        }

        return ($this->page() - 1) * $this->pageSize();
    }

    public function sentinelLimit(): int
    {
        return $this->pageSize() + 1;
    }
}
