<?php

declare(strict_types=1);

namespace GlpiPlugin\Glpiacessivel\Infrastructure\Repository;

use GlpiPlugin\Glpiacessivel\Domain\Ticket\TicketCreationPolicy;
use GlpiPlugin\Glpiacessivel\Domain\Ticket\NativeSearchDefinitionValidator;
use GlpiPlugin\Glpiacessivel\Infrastructure\Database\GlpiDatabaseQuery;
use GlpiPlugin\Glpiacessivel\Infrastructure\Search\GlpiSearchOptionCatalog;
use GlpiPlugin\Glpiacessivel\Infrastructure\Search\BoundedTicketSearchGatewayInterface;
use GlpiPlugin\Glpiacessivel\Infrastructure\Search\BoundedTicketSearchRequest;
use GlpiPlugin\Glpiacessivel\Infrastructure\Search\GlpiBoundedTicketSearchGateway;
use GlpiPlugin\Glpiacessivel\Infrastructure\Search\GlpiTicketActorSearchOptionResolver;
use GlpiPlugin\Glpiacessivel\Infrastructure\Search\GlpiTicketStatusCriterionCodec;
use GlpiPlugin\Glpiacessivel\Infrastructure\Search\GlpiResourceSelectorProvider;
use GlpiPlugin\Glpiacessivel\Infrastructure\Search\GlpiResourceSelectorRegistry;
use GlpiPlugin\Glpiacessivel\Infrastructure\Security\IdempotencyClaim;
use GlpiPlugin\Glpiacessivel\Infrastructure\Security\IdempotencyLedger;
use GlpiPlugin\Glpiacessivel\Security\SessionContextGuard;
use GlpiPlugin\Glpiacessivel\Support\I18n;
use GlpiPlugin\Glpiacessivel\Support\RichTextToPlainText;
use GlpiPlugin\Glpiacessivel\Support\SolutionMutationOutcomeUncertainException;
use GlpiPlugin\Glpiacessivel\Support\TextNormalizer;

final class TicketRepository
{
    private const SOLUTION_DECISION_BASELINE_OFFSET = 8_000_000_000_000_000_000;
    private const SOLUTION_DECISION_ORPHAN_SECONDS = 3600;
    private const MAX_HYDRATED_RELATION_ROWS_PER_PAGE = 1000;
    private const SOLUTION_OPERATION_SESSION_KEY = 'glpiacessivel_solution_operations';

    /**
     * Scalar Ticket fields represented by the accessible post-creation editor.
     *
     * This is deliberately an allowlist. Entity transfers, status changes and
     * actor relations have distinct native authorization/workflow contracts and
     * must never enter the generic scalar update path.
     */
    private const GENERAL_EDIT_FIELDS = [
        'name',
        'content',
        'type',
        'itilcategories_id',
        'locations_id',
        'requesttypes_id',
        'urgency',
        'impact',
        'priority',
    ];

    private BoundedTicketSearchGatewayInterface $boundedTicketSearchGateway;
    private ?IdempotencyLedger $solutionIdempotencyLedger = null;
    private ?string $activeSolutionGuardKeyHash = null;
    private ?string $activeSolutionDecisionGuardKeyHash = null;

    /** @var array<int, array{field:string,code:string,message:string}> */
    private array $lastSolutionErrors = [];

    public function __construct(
        ?BoundedTicketSearchGatewayInterface $boundedTicketSearchGateway = null,
        ?IdempotencyLedger $solutionIdempotencyLedger = null
    ) {
        $this->boundedTicketSearchGateway = $boundedTicketSearchGateway
            ?? GlpiBoundedTicketSearchGateway::forCurrentRuntime();
        $this->solutionIdempotencyLedger = $solutionIdempotencyLedger;
    }

    public function getTicketCreationContext(bool $includeRemoteResources = true): array
    {
        $activeEntity = $this->getConcreteActiveEntityId();
        $defaultRequestSourceId = $this->getDefaultRequestSourceId();
        $requesterEditable = $this->canSelectRequesterForCreation();
        $centralInterface = $this->isCentralInterface();

        return [
            'entity_id' => $activeEntity,
            'entity_name' => $this->getEntityName($activeEntity),
            'requester_id' => (int) ($_SESSION['glpiID'] ?? 0),
            'requester_name' => $this->getCurrentUserName(),
            'opening_date_preview' => date('d/m/Y H:i'),
            'status_preview' => I18n::translate('Novo'),
            'requester_editable' => $requesterEditable,
            'requester_selection_fallback' => $centralInterface && !$requesterEditable,
            'requester_selection_message' => $centralInterface && !$requesterEditable
                ? I18n::translate('O núcleo do GLPI não confirmou com segurança a abertura em nome de outra pessoa. Use o formulário nativo em página completa.')
                : I18n::translate('No Autoatendimento, o requerente permanece fixado no usuário autenticado.'),
            'categories' => $includeRemoteResources ? $this->getTicketCategories() : [],
            'locations' => $includeRemoteResources ? $this->getTicketLocations() : [],
            'assignable_users' => $includeRemoteResources ? $this->getAssignableUsers($activeEntity) : [],
            'observer_users' => $includeRemoteResources ? $this->getObserverUsers($activeEntity) : [],
            'assignable_groups' => $includeRemoteResources ? $this->getAssignableGroups($activeEntity) : [],
            'observer_groups' => $includeRemoteResources ? $this->getObserverGroups($activeEntity) : [],
            'type_options' => $this->getTicketTypeOptions(),
            'urgency_options' => $this->getUrgencyOptions(),
            'impact_options' => $this->getImpactOptions(),
            'request_source_options' => $this->getRequestSourceOptions(),
            'request_source_supported' => $this->ticketSupportsRequestSource(),
            'default_request_source_id' => $defaultRequestSourceId,
            'default_request_source_label' => $this->resolveRequestSourceLabel($defaultRequestSourceId),
            'external_id_supported' => $this->ticketSupportsExternalId(),
            'group_assignment_supported' => $this->tableExists('glpi_groups'),
            'duration_total_help' => I18n::translate(
                'A duração total passa a ser contabilizada pelo atendimento após a abertura do chamado.'
            ),
            'priority_preview' => $this->computePriorityPreview(3, 3),
            'field_requirements' => $this->getTicketCreationFieldRequirements(),
            'ticket_templates' => $this->getTicketTemplates(),
            'service_catalog' => $this->getServiceCatalogContext(),
        ];
    }

    /**
     * The accessible requester selector is intentionally narrower than the
     * native delegate rules: only the central interface may expose it. The
     * Self-Service interface therefore always creates for the authenticated
     * user, even when that user participates in a native delegate group.
     */
    public function canSelectRequesterForCreation(): bool
    {
        if (
            !$this->isCentralInterface()
            || (int) ($_SESSION['glpiID'] ?? 0) <= 0
            || !class_exists('\Ticket')
            || !method_exists('\Ticket', 'canCreate')
            || !\Ticket::canCreate()
            || !method_exists('\Ticket', 'canDelegateeCreateTicket')
            || !class_exists('\CommonITILActor')
            || !defined('\CommonITILActor::REQUESTER')
        ) {
            return false;
        }

        try {
            $entityId = $this->getConcreteActiveEntityId();
            $descriptor = (new GlpiResourceSelectorRegistry())->descriptor(
                GlpiResourceSelectorRegistry::REQUESTER_USER
            );
            $right = $descriptor['value']['native']['right'] ?? null;
            $ticket = new \Ticket();
            if (!method_exists($ticket, 'getDefaultActorRightSearch')) {
                return false;
            }
            $nativeRight = $ticket->getDefaultActorRightSearch(\CommonITILActor::REQUESTER);

            return $entityId >= 0
                && is_string($nativeRight)
                && $nativeRight !== ''
                && hash_equals((string) $right, $nativeRight);
        } catch (\Throwable $e) {
            return false;
        }
    }

    public function canCreateTicketForRequester(int $requesterId, ?int $entityId = null): bool
    {
        $currentUserId = (int) ($_SESSION['glpiID'] ?? 0);
        if ($requesterId <= 0 || $currentUserId <= 0) {
            return false;
        }
        if ($requesterId === $currentUserId) {
            return true;
        }
        if (!$this->canSelectRequesterForCreation()) {
            return false;
        }

        try {
            $entityId ??= $this->getConcreteActiveEntityId();
            if (
                $entityId < 0
                || (
                    class_exists('\Session')
                    && method_exists('\Session', 'haveAccessToEntity')
                    && !\Session::haveAccessToEntity($entityId, false)
                )
            ) {
                return false;
            }

            return (bool) \Ticket::canDelegateeCreateTicket($requesterId, $entityId);
        } catch (\Throwable $e) {
            return false;
        }
    }

    /**
     * Authorize exact resource-selector IDs without reusing the paginated
     * Dropdown lookup. Candidate discovery, hydration and POST final call this
     * same predicate for the ticket-bound actor purposes.
     *
     * @param int[] $ids
     * @param array<string,int> $dependencies
     */
    public function authorizeResourceSelectorIds(
        string $purpose,
        array $ids,
        array $dependencies = []
    ): bool {
        if (count($ids) > GlpiResourceSelectorProvider::MAX_SELECTED_IDS) {
            return false;
        }
        $ids = array_values(array_unique(array_filter(
            array_map('intval', $ids),
            static fn(int $id): bool => $id > 0
        )));
        if ($ids === []) {
            return true;
        }

        if ($purpose === GlpiResourceSelectorRegistry::REQUESTER_USER) {
            $ticketId = (int) ($dependencies['ticket_id'] ?? 0);
            if ($ticketId > 0) {
                if (!$this->canAdminTicketRequesters($ticketId)) {
                    return false;
                }
                $ticket = new \Ticket();
                if (!method_exists($ticket, 'getFromDB') || !$ticket->getFromDB($ticketId)) {
                    return false;
                }
                $entityId = (int) ($ticket->fields['entities_id'] ?? -1);
            } else {
                $entityId = $this->getConcreteActiveEntityId();
            }
            foreach ($ids as $id) {
                if (
                    !$this->isActiveUserInEntity($id, $entityId)
                    || ($ticketId <= 0 && !$this->canCreateTicketForRequester($id, $entityId))
                ) {
                    return false;
                }
            }
            return true;
        }

        $contracts = [
            GlpiResourceSelectorRegistry::ASSIGNED_USER => ['kind' => 'user', 'right' => 'own_ticket'],
            GlpiResourceSelectorRegistry::OBSERVER_USER => ['kind' => 'user', 'right' => 'all'],
            GlpiResourceSelectorRegistry::ASSIGNED_GROUP => ['kind' => 'group', 'capability' => 'is_assign'],
            GlpiResourceSelectorRegistry::ASSIGNED_SUPPLIER => ['kind' => 'supplier'],
            GlpiResourceSelectorRegistry::REQUESTER_GROUP => ['kind' => 'group', 'capability' => 'is_requester'],
            GlpiResourceSelectorRegistry::OBSERVER_GROUP => ['kind' => 'group', 'capability' => 'is_watcher'],
            GlpiResourceSelectorRegistry::TASK_TECHNICIAN => ['kind' => 'user', 'right' => 'own_ticket'],
            GlpiResourceSelectorRegistry::TASK_GROUP => ['kind' => 'group', 'capability' => 'is_task'],
        ];
        if (!isset($contracts[$purpose])) {
            return false;
        }

        $ticketId = (int) ($dependencies['ticket_id'] ?? 0);
        if ($ticketId > 0) {
            $assignmentPurpose = in_array($purpose, [
                GlpiResourceSelectorRegistry::ASSIGNED_USER,
                GlpiResourceSelectorRegistry::ASSIGNED_GROUP,
                GlpiResourceSelectorRegistry::ASSIGNED_SUPPLIER,
            ], true);
            $requesterPurpose = in_array($purpose, [
                GlpiResourceSelectorRegistry::REQUESTER_GROUP,
            ], true);
            $observerPurpose = in_array($purpose, [
                GlpiResourceSelectorRegistry::OBSERVER_USER,
                GlpiResourceSelectorRegistry::OBSERVER_GROUP,
            ], true);
            $taskPurpose = in_array($purpose, [
                GlpiResourceSelectorRegistry::TASK_TECHNICIAN,
                GlpiResourceSelectorRegistry::TASK_GROUP,
            ], true);
            if (
                ($assignmentPurpose && !$this->canAssignTicketActors($ticketId))
                || ($requesterPurpose && !$this->canAdminTicketRequesters($ticketId))
                || ($observerPurpose && !$this->canObserveTicketActors($ticketId))
                || ($taskPurpose && !$this->canAddTaskToTicket($ticketId))
                || (!$assignmentPurpose && !$requesterPurpose && !$observerPurpose && !$taskPurpose)
            ) {
                return false;
            }
            $ticket = new \Ticket();
            if (!method_exists($ticket, 'getFromDB') || !$ticket->getFromDB($ticketId)) {
                return false;
            }
            $entityId = (int) ($ticket->fields['entities_id'] ?? -1);
        } else {
            if (
                !class_exists('\Ticket')
                || !method_exists('\Ticket', 'canCreate')
                || !\Ticket::canCreate()
            ) {
                return false;
            }
            $entityId = $this->getConcreteActiveEntityId();
        }
        if ($entityId < 0) {
            return false;
        }

        $contract = $contracts[$purpose];
        if ($contract['kind'] === 'group') {
            return $this->exactActorGroupIdsAreEligible(
                $ids,
                (string) $contract['capability'],
                $entityId
            );
        }
        if ($contract['kind'] === 'supplier') {
            return $this->exactActorSupplierIdsAreEligible($ids, $entityId);
        }

        foreach ($ids as $id) {
            if (!$this->isActiveUserInEntity($id, $entityId)) {
                return false;
            }
            if (
                $contract['right'] === 'own_ticket'
                && (
                    !class_exists('\Profile')
                    || !method_exists('\Profile', 'haveUserRight')
                    || !defined('\Ticket::OWN')
                    || !\Profile::haveUserRight($id, 'ticket', \Ticket::OWN, $entityId)
                )
            ) {
                return false;
            }
        }

        return true;
    }

    private function isActiveUserInEntity(int $userId, int $entityId): bool
    {
        if (
            $userId <= 0
            || $entityId < 0
            || !class_exists('\User')
            || !class_exists('\Profile_User')
            || !method_exists('\Profile_User', 'getUserEntities')
        ) {
            return false;
        }

        try {
            $user = new \User();
            if (!method_exists($user, 'getFromDB') || !$user->getFromDB($userId)) {
                return false;
            }
            $fields = is_array($user->fields ?? null) ? $user->fields : [];
            if (!empty($fields['is_deleted']) || empty($fields['is_active'])) {
                return false;
            }
            $now = time();
            $begin = trim((string) ($fields['begin_date'] ?? ''));
            $end = trim((string) ($fields['end_date'] ?? ''));
            if ($begin !== '' && ($beginAt = strtotime($begin)) !== false && $beginAt >= $now) {
                return false;
            }
            if ($end !== '' && ($endAt = strtotime($end)) !== false && $endAt <= $now) {
                return false;
            }

            $entities = array_values(array_map(
                'intval',
                (array) \Profile_User::getUserEntities($userId, true)
            ));
            return in_array($entityId, $entities, true);
        } catch (\Throwable $e) {
            return false;
        }
    }

    private function isCentralInterface(): bool
    {
        if (!class_exists('\Session') || !method_exists('\Session', 'getCurrentInterface')) {
            return false;
        }

        try {
            return \Session::getCurrentInterface() === 'central';
        } catch (\Throwable $e) {
            return false;
        }
    }

    public function listTickets(array $filters): array
    {
        $startedAt = hrtime(true);
        $stageDurations = [
            'request_preparation' => null,
            'search_pipeline' => 0,
            'batch_hydration' => 0,
        ];
        $result = $this->listTicketsResult($filters, $stageDurations, $startedAt);
        $stageDurations['repository_total'] = $this->elapsedMilliseconds($startedAt);
        $stageDurations['request_preparation'] ??= $stageDurations['repository_total'];
        $result['backend_diagnostics']['stage_durations_ms'] = array_replace(
            (array) ($result['backend_diagnostics']['stage_durations_ms'] ?? []),
            $stageDurations
        );

        return $result;
    }

    /** @param array<string,int|null> $stageDurations */
    private function listTicketsResult(array $filters, array &$stageDurations, float $startedAt): array
    {
        $page = max(1, (int) ($filters['page'] ?? 1));
        $pageSize = min(
            BoundedTicketSearchRequest::MAX_PAGE_SIZE,
            max(10, (int) ($filters['page_size'] ?? 20))
        );

        if (!empty($filters['saved_search_invalid'])) {
            return $this->blockedSavedSearchResult($filters, $pageSize, 'saved_search_unavailable');
        }
        if (
            !empty($filters['native_saved_search_id'])
            && !$this->hasCompleteNativeSavedSearchExecution($filters)
        ) {
            return $this->blockedSavedSearchResult(
                $filters,
                $pageSize,
                'native_saved_search_unavailable'
            );
        }
        if (!empty($filters['native_default_search'])) {
            if (
                !empty($filters['native_saved_search_id'])
                || array_key_exists('native_parameters', $filters)
                || array_key_exists('native_criteria', $filters)
            ) {
                return $this->blockedSavedSearchResult(
                    $filters,
                    $pageSize,
                    'native_default_search_context_invalid'
                );
            }
        }

        $groupScope = $this->currentUserGroupScopeResolution($filters);
        if ($groupScope['state'] === 'empty') {
            return $this->emptyGroupScopeResult($filters, $pageSize, $groupScope['reason']);
        }
        if ($groupScope['state'] === 'unavailable') {
            return $this->blockedSavedSearchResult($filters, $pageSize, $groupScope['reason']);
        }

        $sort = (string) ($filters['sort'] ?? 'date_mod');
        $direction = strtoupper((string) ($filters['direction'] ?? 'DESC')) === 'ASC' ? 'ASC' : 'DESC';

        $searchApiResult = $this->listTicketsFromSearchApi(
            $filters,
            $page,
            $pageSize,
            $sort,
            $direction,
            $stageDurations,
            $startedAt
        );
        if ($searchApiResult !== null) {
            return $searchApiResult;
        }

        return $this->blockedSavedSearchResult(
            $filters,
            $pageSize,
            !empty($filters['native_saved_search_id'])
                ? 'native_saved_search_unavailable'
                : $this->getSearchApiFallbackReason($filters)
        );
    }

    /** @return array<string, mixed> */
    private function emptyGroupScopeResult(array $filters, int $pageSize, string $reason): array
    {
        $diagnostics = $this->ticketListBackendDiagnostics($filters, 'scope_empty', false, 0);
        $diagnostics['backend_reason'] = $reason;

        return [
            'items' => [],
            'total' => 0,
            'total_state' => 'exact',
            'total_is_lower_bound' => false,
            'partial_results' => false,
            'page' => 1,
            'page_size' => $pageSize,
            'pages' => 1,
            'has_previous' => false,
            'has_more' => false,
            'has_next' => false,
            'backend' => 'scope_empty',
            'backend_reason' => $reason,
            'backend_limit' => 0,
            'backend_limited' => false,
            'fallback_limit_hit' => false,
            'assigned_group_search_option' => 0,
            'backend_diagnostics' => $diagnostics,
        ];
    }

    /** @return array<string, mixed> */
    private function blockedSavedSearchResult(array $filters, int $pageSize, string $reason): array
    {
        $diagnostics = $this->ticketListBackendDiagnostics(
            $filters,
            'native_saved_search_blocked',
            false
        );
        $diagnostics['backend_reason'] = $reason;

        return [
            'items' => [],
            'total' => null,
            'total_state' => 'unavailable',
            'total_is_lower_bound' => false,
            'partial_results' => false,
            'page' => 1,
            'page_size' => $pageSize,
            'pages' => null,
            'has_previous' => false,
            'has_more' => false,
            'has_next' => false,
            'backend' => 'native_saved_search_blocked',
            'backend_reason' => $reason,
            'backend_limit' => 0,
            'backend_limited' => false,
            'fallback_limit_hit' => false,
            'assigned_group_search_option' => $this->getTicketAssignedGroupSearchOptionNumber(),
            'backend_diagnostics' => $diagnostics,
        ];
    }

    /** @param array<string,mixed> $filters */
    private function hasCompleteNativeSavedSearchExecution(array $filters): bool
    {
        if (
            ($filters['native_saved_search_execution_ready'] ?? null) !== true
            || (int) ($filters['native_saved_search_id'] ?? 0) <= 0
            || !is_string($filters['native_execution_fingerprint'] ?? null)
            || preg_match(
                '/\A[a-f0-9]{64}\z/D',
                (string) $filters['native_execution_fingerprint']
            ) !== 1
            || !is_array($filters['native_parameters'] ?? null)
        ) {
            return false;
        }

        $parameters = $filters['native_parameters'];
        if (($parameters['itemtype'] ?? 'Ticket') !== 'Ticket') {
            return false;
        }
        foreach (['native_criteria', 'native_metacriteria', 'native_sort', 'native_order'] as $key) {
            if (!array_key_exists($key, $filters) || !is_array($filters[$key])) {
                return false;
            }
        }
        foreach (
            [
                'criteria' => 'native_criteria',
                'metacriteria' => 'native_metacriteria',
                'sort' => 'native_sort',
                'order' => 'native_order',
            ] as $parameterKey => $filterKey
        ) {
            if (
                !is_array($parameters[$parameterKey] ?? null)
                || $parameters[$parameterKey] !== $filters[$filterKey]
            ) {
                return false;
            }
        }
        if (
            !array_key_exists('native_is_deleted', $filters)
            || !is_int($filters['native_is_deleted'])
            || !in_array($filters['native_is_deleted'], [0, 1], true)
            || !is_int($parameters['is_deleted'] ?? null)
            || $parameters['is_deleted'] !== $filters['native_is_deleted']
            || count($filters['native_sort']) !== count($filters['native_order'])
        ) {
            return false;
        }
        foreach ($parameters['sort'] as $sort) {
            if (!is_int($sort) || $sort <= 0) {
                return false;
            }
        }
        foreach ($parameters['order'] as $order) {
            if (!is_string($order) || !in_array(strtoupper($order), ['ASC', 'DESC'], true)) {
                return false;
            }
        }

        // is_deleted=0 is a real active-record scope, not an absent value. The
        // required-key checks above distinguish it from a missing definition.
        return true;
    }

    /** @param array<string,int|null> $stageDurations */
    private function listTicketsFromSearchApi(
        array $filters,
        int $page,
        int $pageSize,
        string $sort,
        string $direction,
        array &$stageDurations,
        float $preparationStartedAt
    ): ?array {
        if (
            !$this->canUseSearchApiForTicketList($filters)
            || !$this->boundedTicketSearchGateway->capability()->availableInRuntime()
        ) {
            return null;
        }

        try {
            $itemtype = \Ticket::class;
            $idOption = $this->getTicketSearchOptionNumber('id');
            if ($idOption <= 0) {
                return null;
            }

            if (!empty($filters['native_saved_search_id'])) {
                // SavedSearch::getParameters() is the semantic source of truth.
                // Do not rebuild, append portal criteria or translate values a
                // second time: Search::manageParams() below must receive the
                // same resolved definition as GLPI's native list. Only bounded
                // presentation controls are replaced by the adapter.
                if (!$this->hasCompleteNativeSavedSearchExecution($filters)) {
                    return null;
                }
                $params = $filters['native_parameters'];
                unset($params['start'], $params['list_limit'], $params['export_all']);
            } else {
                // Other trusted server-side flows (notably compatibility tests
                // and the resolved native default) may already provide native
                // parameters without identifying a SavedSearch record.
                $nativeParameters = is_array($filters['native_parameters'] ?? null)
                    ? $filters['native_parameters']
                    : [];
                $hasNativeSort = array_key_exists('sort', $nativeParameters)
                    || array_key_exists('native_sort', $filters);
                $nativeSort = (array) ($nativeParameters['sort'] ?? $filters['native_sort'] ?? []);
                $sortOptions = [];
                if ($nativeSort !== []) {
                    foreach ($nativeSort as $value) {
                        if (!is_numeric($value) || (int) $value <= 0) {
                            return null;
                        }
                        $sortOptions[] = (int) $value;
                    }
                } elseif (!$hasNativeSort) {
                    $sortOption = $this->getTicketSearchOptionForSort($sort);
                    if ($sortOption <= 0) {
                        return null;
                    }
                    $sortOptions[] = $sortOption;
                }
                $hasNativeCriteria = array_key_exists('criteria', $nativeParameters)
                    || array_key_exists('native_criteria', $filters);
                $criteria = array_key_exists('criteria', $nativeParameters)
                    ? (is_array($nativeParameters['criteria']) ? $nativeParameters['criteria'] : null)
                    : ($hasNativeCriteria
                        ? (is_array($filters['native_criteria']) ? $filters['native_criteria'] : null)
                        : $this->buildTicketSearchCriteria($filters));
                if ($criteria === null) {
                    return null;
                }
                if ($hasNativeCriteria) {
                    $semanticCriteria = $this->buildTicketSearchCriteria($filters);
                    if ($semanticCriteria === null) {
                        return null;
                    }
                    $criteria = array_merge($criteria, $semanticCriteria);
                }
                $metacriteria = array_key_exists('metacriteria', $nativeParameters)
                    ? (is_array($nativeParameters['metacriteria']) ? $nativeParameters['metacriteria'] : null)
                    : (array_key_exists('native_metacriteria', $filters)
                        ? (is_array($filters['native_metacriteria']) ? $filters['native_metacriteria'] : null)
                        : []);
                if ($metacriteria === null) {
                    return null;
                }

                $statusCriterionCodec = new GlpiTicketStatusCriterionCodec();
                $criteria = $statusCriterionCodec->compileForGlpi($criteria, $itemtype);
                $metacriteria = $statusCriterionCodec->compileForGlpi($metacriteria, $itemtype);

                $nativeOrder = (array) ($nativeParameters['order'] ?? $filters['native_order'] ?? []);
                $orders = [];
                if ($hasNativeSort) {
                    if (count($nativeOrder) !== count($sortOptions)) {
                        return null;
                    }
                    foreach ($nativeOrder as $value) {
                        $normalizedOrder = strtoupper((string) $value);
                        if (!in_array($normalizedOrder, ['ASC', 'DESC'], true)) {
                            return null;
                        }
                        $orders[] = $normalizedOrder;
                    }
                } else {
                    if ($nativeOrder !== []) {
                        return null;
                    }
                    $orders[] = strtoupper($direction) === 'ASC' ? 'ASC' : 'DESC';
                }

                $isDeleted = (int) ($nativeParameters['is_deleted'] ?? $filters['native_is_deleted'] ?? 0);
                if (!in_array($isDeleted, [0, 1], true)) {
                    return null;
                }
                $params = [
                    'is_deleted' => $isDeleted,
                    // The bounded request validates and computes the offset before
                    // the Search adapter receives it. Never multiply input here.
                    'start' => 0,
                    'list_limit' => $pageSize,
                    'criteria' => $criteria,
                    'metacriteria' => $metacriteria,
                    'reset' => 'reset',
                ];
                if (!$hasNativeSort || $sortOptions !== []) {
                    $params['sort'] = $sortOptions;
                    $params['order'] = $orders;
                }
            }

            $resolveNativeDefault = !empty($filters['native_default_search']);
            if ($resolveNativeDefault) {
                // Empty means "let GLPI resolve its current default". Sending
                // reset or empty semantic keys would change native behaviour.
                $params = [];
            }
            $stageDurations['request_preparation'] = $this->elapsedMilliseconds($preparationStartedAt);
            $searchStartedAt = hrtime(true);
            try {
                // Includes native plan construction, not only the ID statement.
                // This is observation, not a request deadline or a new limit.
                $boundedResult = $this->boundedTicketSearchGateway->search(new BoundedTicketSearchRequest(
                    $itemtype,
                    $params,
                    $idOption,
                    $page,
                    $pageSize,
                    $resolveNativeDefault
                ));
            } finally {
                $stageDurations['search_pipeline'] = $this->elapsedMilliseconds($searchStartedAt);
            }
            if (!$boundedResult->available()) {
                return $this->blockedBoundedSearchResult(
                    $filters,
                    $page,
                    $pageSize,
                    $boundedResult->reason()
                );
            }

            $ticketIds = $boundedResult->ticketIds();
            $hasMore = $boundedResult->hasMore();
            $searchDurationMs = $boundedResult->queryDurationMs();
            if ($ticketIds === []) {
                $emptyReason = !empty($filters['native_saved_search_id'])
                    ? 'native_saved_search'
                    : 'bounded_native_search';
                return [
                    'items' => [],
                    'total' => null,
                    'total_state' => 'deferred',
                    'total_is_lower_bound' => false,
                    'partial_results' => false,
                    'page' => $page,
                    'page_size' => $pageSize,
                    'pages' => null,
                    'has_previous' => $page > 1,
                    'has_more' => false,
                    'has_next' => false,
                    'backend' => 'search_api',
                    'backend_reason' => $emptyReason,
                    'backend_limit' => 0,
                    'backend_limited' => false,
                    'fallback_limit_hit' => false,
                    'assigned_group_search_option' => $this->getTicketAssignedGroupSearchOptionNumber(),
                    'effective_native_search' => $boundedResult->effectiveNativeSearch(),
                    'backend_diagnostics' => $this->ticketListBackendDiagnostics(
                        $filters,
                        'search_api',
                        false
                    ) + [
                        'stage_durations_ms' => [
                            'native_search' => $searchDurationMs,
                            'batch_hydration' => 0,
                        ],
                        'search_adapter' => $boundedResult->adapter(),
                    ],
                ];
            }

            // The GLPI Search engine constructs ACL, criteria and ordering. The
            // bounded gateway executes only the authorized ID query and removes
            // the page_size + 1 sentinel before this batch hydration.
            $hydrationStartedAt = hrtime(true);
            try {
                $items = $this->hydrateTicketListRows($ticketIds);
            } catch (\OverflowException) {
                return $this->blockedBoundedSearchResult(
                    $filters,
                    $page,
                    $pageSize,
                    'bounded_search_hydration_relation_limit_exceeded'
                );
            } finally {
                $stageDurations['batch_hydration'] = $this->elapsedMilliseconds($hydrationStartedAt);
            }
            $hydrationDurationMs = $stageDurations['batch_hydration'];
            if ($items === null || count($items) !== count($ticketIds)) {
                return null;
            }

            return [
                'items' => $items,
                'total' => null,
                'total_state' => 'deferred',
                'total_is_lower_bound' => false,
                'partial_results' => false,
                'page' => $page,
                'page_size' => $pageSize,
                'pages' => null,
                'has_previous' => $page > 1,
                'has_more' => $hasMore,
                'has_next' => $hasMore,
                'backend' => 'search_api',
                'backend_reason' => 'bounded_native_search',
                'backend_limit' => 0,
                'backend_limited' => false,
                'fallback_limit_hit' => false,
                'assigned_group_search_option' => $this->getTicketAssignedGroupSearchOptionNumber(),
                'effective_native_search' => $boundedResult->effectiveNativeSearch(),
                'backend_diagnostics' => $this->ticketListBackendDiagnostics(
                    $filters,
                    'search_api',
                    false
                ) + [
                    'stage_durations_ms' => [
                        'native_search' => $searchDurationMs,
                        'batch_hydration' => $hydrationDurationMs,
                    ],
                    'search_adapter' => $boundedResult->adapter(),
                ],
            ];
        } catch (\Throwable $e) {
            return $this->blockedBoundedSearchResult(
                $filters,
                $page,
                $pageSize,
                'bounded_search_execution_failed'
            );
        }
    }

    /** @return array<string, mixed> */
    private function blockedBoundedSearchResult(
        array $filters,
        int $page,
        int $pageSize,
        string $reason
    ): array {
        $result = $this->blockedSavedSearchResult($filters, $pageSize, $reason);
        $result['page'] = max(1, $page);
        $result['has_previous'] = $page > 1;
        return $result;
    }

    private function canUseSearchApiForTicketList(array $filters): bool
    {
        if (!class_exists('\Search') || !class_exists('\Ticket')) {
            return false;
        }

        if (
            !empty($filters['native_saved_search_id'])
            && !$this->hasCompleteNativeSavedSearchExecution($filters)
        ) {
            return false;
        }
        if (array_key_exists('native_criteria', $filters) && !is_array($filters['native_criteria'])) {
            return false;
        }

        $scope = (string) ($filters['scope'] ?? 'all');
        $groupId = (int) ($filters['group_id'] ?? 0);
        if ($scope === 'mine') {
            return (int) ($_SESSION['glpiID'] ?? 0) > 0
                && $this->getTicketUserSearchOptionNumbersByType() !== [];
        }

        if ($scope === 'group') {
            $groupScope = $this->currentUserGroupScopeResolution($filters);
            return $groupScope['state'] === 'resolved'
                && $this->getTicketAssignedGroupSearchOptionNumber() > 0;
        }

        if ($scope !== 'all') {
            return false;
        }

        if ($groupId > 0) {
            return $this->getTicketAssignedGroupSearchOptionNumber() > 0;
        }

        return true;
    }

    /**
     * @return array<string, mixed>
     */
    private function ticketListBackendDiagnostics(
        array $filters,
        string $backend,
        bool $fallbackLimitHit,
        ?int $assignedGroupOption = null
    ): array {
        $query = trim((string) ($filters['q'] ?? ''));
        $assignedGroupOption = $assignedGroupOption ?? $this->getTicketAssignedGroupSearchOptionNumber();

        return [
            'backend' => $backend,
            'backend_reason' => $backend === 'search_api'
                ? 'bounded_native_search'
                : $this->getSearchApiFallbackReason($filters),
            'scope' => (string) ($filters['scope'] ?? 'all'),
            'group_id' => max(0, (int) ($filters['group_id'] ?? 0)),
            'status' => (string) ($filters['status'] ?? ''),
            'page' => max(1, (int) ($filters['page'] ?? 1)),
            'page_size' => min(
                BoundedTicketSearchRequest::MAX_PAGE_SIZE,
                max(10, (int) ($filters['page_size'] ?? 20))
            ),
            'sort' => (string) ($filters['sort'] ?? 'date_mod'),
            'direction' => strtoupper((string) ($filters['direction'] ?? 'DESC')) === 'ASC' ? 'ASC' : 'DESC',
            'query_len' => strlen($query),
            'assigned_group_search_option' => $assignedGroupOption,
            'current_user_group_count' => count($this->getCurrentUserGroupIds()),
            'fallback_scan_limit' => 0,
            'fallback_limit_hit' => $fallbackLimitHit,
            'fallback_limit_policy' => 'search_api_only_for_ticket_list',
        ];
    }

    private function getSearchApiFallbackReason(array $filters): string
    {
        if (!class_exists('\Search') || !class_exists('\Ticket')) {
            return 'search_api_unavailable';
        }
        $capability = $this->boundedTicketSearchGateway->capability();
        if (!$capability->availableInRuntime()) {
            return $capability->reason() !== ''
                ? $capability->reason()
                : 'bounded_search_unavailable';
        }

        $scope = (string) ($filters['scope'] ?? 'all');
        $groupId = (int) ($filters['group_id'] ?? 0);
        if ($scope === 'mine' && $this->getTicketUserSearchOptionNumbersByType() === []) {
            return 'mine_scope_search_options_unavailable';
        }

        if ($scope === 'group') {
            $groupScope = $this->currentUserGroupScopeResolution($filters);
            if ($groupScope['state'] !== 'resolved') {
                return $groupScope['reason'];
            }
        }

        if (($scope === 'group' || $groupId > 0) && $this->getTicketAssignedGroupSearchOptionNumber() <= 0) {
            return 'assigned_group_search_option_unavailable';
        }

        if ($scope !== 'all' && $scope !== 'group') {
            return 'scope_requires_portal_filter';
        }

        return 'search_api_response_unusable';
    }

    /**
     * @param string[] $selectedColumns
     * @return int[]
     */
    private function getTicketSearchForcedDisplay(array $selectedColumns = []): array
    {
        $fields = ['id', 'name', 'status', 'priority', 'date', 'date_mod', 'content', 'entities_id', 'users_id_recipient'];
        $options = [];
        foreach ($fields as $field) {
            $option = $this->getTicketSearchOptionNumber($field);
            if ($option > 0) {
                $options[$option] = $option;
            }
        }

        $selected = array_fill_keys(array_values(array_filter(array_map(
            static fn($column): string => is_scalar($column) ? trim((string) $column) : '',
            $selectedColumns
        ))), true);
        if ($selected !== []) {
            $catalog = (new GlpiSearchOptionCatalog())->forTickets();
            foreach ((array) ($catalog['columns'] ?? []) as $column) {
                if (!is_array($column) || empty($column['available'])) {
                    continue;
                }
                $identifier = (string) ($column['identifier'] ?? '');
                $option = (int) ($column['option_id'] ?? 0);
                if (isset($selected[$identifier]) && $option > 0) {
                    $options[$option] = $option;
                }
            }
        }

        return array_values($options);
    }

    private function getTicketSearchOptionForSort(string $sort): int
    {
        $allowed = ['id', 'name', 'status', 'priority', 'date', 'date_mod'];
        $field = in_array($sort, $allowed, true) ? $sort : 'date_mod';
        return $this->getTicketSearchOptionNumber($field);
    }

    private function getTicketSearchOptionNumber(string $field): int
    {
        if (method_exists('\Search', 'getOptionNumber')) {
            $option = (int) \Search::getOptionNumber(\Ticket::class, $field);
            if ($option > 0) {
                return $option;
            }
        }

        if (!method_exists('\Search', 'getOptions')) {
            return 0;
        }

        $ticketTable = method_exists('\Ticket', 'getTable') ? (string) \Ticket::getTable() : 'glpi_tickets';
        foreach ((array) \Search::getOptions(\Ticket::class) as $number => $option) {
            if (!is_numeric($number) || !is_array($option)) {
                continue;
            }

            if ((string) ($option['field'] ?? '') !== $field) {
                continue;
            }

            $table = (string) ($option['table'] ?? $ticketTable);
            if ($table === '' || $table === $ticketTable) {
                return (int) $number;
            }
        }

        return 0;
    }

    /**
     * @return array<int, array<string, mixed>>|null
     */
    private function buildTicketSearchCriteria(array $filters): ?array
    {
        $criteria = [];
        $status = (string) ($filters['status'] ?? '');
        if ($status !== '' && ctype_digit($status)) {
            $statusOption = $this->getTicketSearchOptionNumber('status');
            if ($statusOption <= 0) {
                return null;
            }
            $criteria[] = [
                'link' => 'AND',
                'field' => $statusOption,
                'searchtype' => 'equals',
                'value' => (string) ((int) $status),
            ];
        }

        $query = trim((string) ($filters['q'] ?? ''));
        if ($query !== '') {
            if (ctype_digit($query)) {
                $idOption = $this->getTicketSearchOptionNumber('id');
                if ($idOption <= 0) {
                    return null;
                }
                $criteria[] = [
                    'link' => 'AND',
                    'field' => $idOption,
                    'searchtype' => 'equals',
                    'value' => (string) ((int) $query),
                ];
            } else {
                $textCriteria = $this->buildTicketTextSearchCriteria($query);
                if ($textCriteria === null) {
                    return null;
                }
                foreach ($textCriteria as $criterion) {
                    $criteria[] = $criterion;
                }
            }
        }

        $groupCriteria = $this->buildTicketAssignedGroupSearchCriteria($filters);
        if ($groupCriteria === null) {
            return null;
        }

        foreach ($groupCriteria as $criterion) {
            $criteria[] = $criterion;
        }

        return $criteria;
    }

    /**
     * @return array<int, array<string, mixed>>|null
     */
    private function buildTicketAssignedGroupSearchCriteria(array $filters): ?array
    {
        $scope = (string) ($filters['scope'] ?? 'all');
        $groupId = (int) ($filters['group_id'] ?? 0);
        if ($scope !== 'group' && $groupId <= 0) {
            return $scope === 'mine' ? $this->buildTicketMineSearchCriteria() : [];
        }

        $option = $this->getTicketAssignedGroupSearchOptionNumber();
        if ($option <= 0) {
            return null;
        }

        $groups = $groupId > 0 ? [$groupId] : $this->getCurrentUserGroupIds();
        $groups = array_values(array_unique(array_filter(array_map('intval', $groups), static fn(int $id): bool => $id > 0)));
        if ($groups === []) {
            return null;
        }

        $alternatives = [];
        foreach ($groups as $index => $currentGroupId) {
            $alternatives[] = [
                'link' => $index === 0 ? 'AND' : 'OR',
                'field' => $option,
                'searchtype' => 'equals',
                'value' => (string) $currentGroupId,
            ];
        }

        return [[
            'link' => 'AND',
            'criteria' => $alternatives,
        ]];
    }

    /**
     * Require both title and content Search Options to preserve fallback semantics.
     *
     * @return array<int, array<string, mixed>>|null
     */
    private function buildTicketTextSearchCriteria(string $query): ?array
    {
        $nameOption = $this->getTicketSearchOptionNumber('name');
        $contentOption = $this->getTicketSearchOptionNumber('content');
        if ($nameOption <= 0 || $contentOption <= 0) {
            return null;
        }

        return [[
            'link' => 'AND',
            'criteria' => [
                ['link' => 'AND', 'field' => $nameOption, 'searchtype' => 'contains', 'value' => $query],
                ['link' => 'OR', 'field' => $contentOption, 'searchtype' => 'contains', 'value' => $query],
            ],
        ]];
    }

    /**
     * Detect requester, assigned and observer Search Options by their native link type.
     * No hard-coded option numbers are used because GLPI 10 and 11 differ.
     *
     * @return array<int, int> keyed by ITIL user type (1 requester, 2 assigned, 3 observer)
     */
    private function getTicketUserSearchOptionNumbersByType(): array
    {
        $resolved = (new GlpiTicketActorSearchOptionResolver())->resolve();
        return $resolved['supported'] ? $resolved['options'] : [];
    }

    /** @return array<int, array<string, mixed>>|null */
    private function buildTicketMineSearchCriteria(): ?array
    {
        $compiled = (new GlpiTicketActorSearchOptionResolver())->compileMineCriteria(
            (int) ($_SESSION['glpiID'] ?? 0)
        );
        return $compiled['supported'] ? $compiled['criteria'] : null;
    }
    private function getTicketAssignedGroupSearchOptionNumber(): int
    {
        if (!method_exists('\Search', 'getOptions')) {
            return 0;
        }

        foreach ((array) \Search::getOptions(\Ticket::class) as $number => $option) {
            if (!is_numeric($number) || !is_array($option)) {
                continue;
            }

            if ($this->searchOptionLooksLikeAssignedGroup($option)) {
                return (int) $number;
            }
        }

        return 0;
    }

    /** @param array<string, mixed> $option */
    private function searchOptionLooksLikeAssignedGroup(array $option): bool
    {
        $table = (string) ($option['table'] ?? '');
        $field = (string) ($option['field'] ?? '');
        $linkfield = (string) ($option['linkfield'] ?? '');
        $serialized = strtolower(json_encode($option, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE) ?: '');

        if ($table === 'glpi_groups_tickets' && in_array($field, ['groups_id', 'id'], true)) {
            return $this->serializedSearchOptionContainsAssignedGroupType($serialized);
        }

        if ($table === 'glpi_groups' && ($linkfield === 'groups_id' || str_contains($serialized, 'glpi_groups_tickets'))) {
            return $this->serializedSearchOptionContainsAssignedGroupType($serialized);
        }

        return false;
    }

    private function serializedSearchOptionContainsAssignedGroupType(string $serialized): bool
    {
        if ($serialized === '' || !str_contains($serialized, 'glpi_groups_tickets')) {
            return false;
        }

        return preg_match('/(?:type|\bglpi_groups_tickets\.type\b)[^0-9]{0,40}2/', $serialized) === 1
            || str_contains($serialized, 'groups_id_assign')
            || str_contains($serialized, '_groups_id_assign');
    }

    /**
     * @return array<int, array<string, mixed>>
     */
    private function extractSearchRows(array $data): array
    {
        $rows = $data['data']['rows'] ?? $data['rows'] ?? [];
        if (!is_array($rows)) {
            return [];
        }

        return array_values(array_filter($rows, 'is_array'));
    }

    private function extractSearchTotal(array $data): int
    {
        foreach (['totalcount', 'count'] as $key) {
            if (isset($data['data'][$key]) && is_numeric($data['data'][$key])) {
                return max(0, (int) $data['data'][$key]);
            }
        }

        if (isset($data['totalcount']) && is_numeric($data['totalcount'])) {
            return max(0, (int) $data['totalcount']);
        }

        return count($this->extractSearchRows($data));
    }

    private function extractTicketIdFromSearchRow(array $row): int
    {
        foreach (['id', 'item_id', 'tickets_id'] as $key) {
            if (isset($row[$key]) && is_numeric($row[$key])) {
                return max(0, (int) $row[$key]);
            }
        }

        foreach (['raw', 'values'] as $containerKey) {
            if (isset($row[$containerKey]) && is_array($row[$containerKey])) {
                $ticketId = $this->extractTicketIdFromSearchValues($row[$containerKey]);
                if ($ticketId > 0) {
                    return $ticketId;
                }
            }
        }

        return 0;
    }

    private function extractTicketIdFromSearchValues(array $values): int
    {
        foreach ($values as $key => $value) {
            $key = (string) $key;
            if (is_numeric($value) && preg_match('/(?:^|_)Ticket_(?:id|2|80)$/i', $key)) {
                return max(0, (int) $value);
            }

            if (is_array($value)) {
                $nested = $this->extractTicketIdFromSearchValues($value);
                if ($nested > 0) {
                    return $nested;
                }
            }
        }

        return 0;
    }

    private function getTicketListRowById(int $ticketId): ?array
    {
        $ticketId = max(1, $ticketId);
        if (!$this->canReadTicket($ticketId)) {
            return null;
        }

        $ticket = new \Ticket();
        if (!$ticket->getFromDB($ticketId)) {
            return null;
        }

        return $this->mapTicketFieldsToListRow($ticket->fields);
    }

    /**
     * Hydrate one already-authorized native Search page with a fixed number of
     * database requests. No identifier outside the Search result is introduced.
     *
     * @param int[] $ticketIds
     * @return array<int, array<string, mixed>>|null
     */
    private function hydrateTicketListRows(array $ticketIds): ?array
    {
        global $DB;

        $ticketIds = array_values(array_map('intval', $ticketIds));
        if ($ticketIds === []) {
            return [];
        }
        if (
            !isset($DB)
            || !method_exists($DB, 'request')
            || !$this->tableExists('glpi_tickets')
            || !$this->tableExists('glpi_tickets_users')
            || !$this->tableExists('glpi_groups_tickets')
        ) {
            return null;
        }

        $uniqueTicketIds = array_values(array_unique(array_filter(
            $ticketIds,
            static fn(int $id): bool => $id > 0
        )));
        if (count($uniqueTicketIds) !== count($ticketIds)) {
            return null;
        }

        try {
            $ticketRows = [];
            $ticketColumns = array_values(array_intersect(
                [
                    'id', 'name', 'status', 'priority', 'urgency', 'impact', 'date', 'date_mod',
                    'entities_id', 'itilcategories_id', 'locations_id', 'time_to_resolve',
                    'users_id_recipient',
                ],
                $this->getTableColumns('glpi_tickets')
            ));
            if (!in_array('id', $ticketColumns, true)) {
                return null;
            }
            foreach (
                $DB->request([
                'SELECT' => $ticketColumns,
                'FROM' => 'glpi_tickets',
                'WHERE' => ['id' => $uniqueTicketIds],
                ]) as $row
            ) {
                $row = (array) $row;
                $id = (int) ($row['id'] ?? 0);
                if ($id > 0) {
                    $ticketRows[$id] = $row;
                }
            }

            if (count($ticketRows) !== count($uniqueTicketIds)) {
                return null;
            }

            $usersByTicket = [];
            $userIds = [];
            $userRelationRows = $this->requestBoundedRelationRows([
                'SELECT' => ['tickets_id', 'users_id', 'type'],
                'FROM' => 'glpi_tickets_users',
                'WHERE' => [
                    'tickets_id' => $uniqueTicketIds,
                    'type' => [1, 2],
                ],
            ], self::MAX_HYDRATED_RELATION_ROWS_PER_PAGE);
            foreach ($userRelationRows as $row) {
                $ticketId = (int) ($row['tickets_id'] ?? 0);
                $userId = (int) ($row['users_id'] ?? 0);
                $type = (int) ($row['type'] ?? 0);
                if ($ticketId > 0 && $userId > 0 && in_array($type, [1, 2], true)) {
                    $usersByTicket[$ticketId][$type][$userId] = $userId;
                    $userIds[$userId] = $userId;
                }
            }

            $userLabels = [];
            if ($userIds !== [] && $this->tableExists('glpi_users')) {
                foreach (
                    $DB->request([
                    'SELECT' => ['id', 'name', 'firstname', 'realname'],
                    'FROM' => 'glpi_users',
                    'WHERE' => ['id' => array_values($userIds)],
                    ]) as $row
                ) {
                    $row = (array) $row;
                    $id = (int) ($row['id'] ?? 0);
                    if ($id > 0) {
                        $userLabels[$id] = $this->formatUserName($row, $id);
                    }
                }
            }

            $groupsByTicket = [];
            $groupIds = [];
            $remainingRelationBudget = self::MAX_HYDRATED_RELATION_ROWS_PER_PAGE
                - count($userRelationRows);
            $groupRelationRows = $this->requestBoundedRelationRows([
                'SELECT' => ['tickets_id', 'groups_id'],
                'FROM' => 'glpi_groups_tickets',
                'WHERE' => [
                    'tickets_id' => $uniqueTicketIds,
                    'type' => 2,
                ],
            ], $remainingRelationBudget);
            foreach ($groupRelationRows as $row) {
                $ticketId = (int) ($row['tickets_id'] ?? 0);
                $groupId = (int) ($row['groups_id'] ?? 0);
                if ($ticketId > 0 && $groupId > 0) {
                    $groupsByTicket[$ticketId][$groupId] = $groupId;
                    $groupIds[$groupId] = $groupId;
                }
            }

            $groupLabels = $this->batchDropdownLabels('glpi_groups', array_values($groupIds), 'Grupo');
            $entityLabels = $this->batchDropdownLabels(
                'glpi_entities',
                $this->collectForeignIds($ticketRows, 'entities_id'),
                'Entidade'
            );
            $categoryLabels = $this->batchDropdownLabels(
                'glpi_itilcategories',
                $this->collectForeignIds($ticketRows, 'itilcategories_id'),
                'Categoria'
            );
            $locationLabels = $this->batchDropdownLabels(
                'glpi_locations',
                $this->collectForeignIds($ticketRows, 'locations_id'),
                I18n::translate('Localização')
            );
        } catch (\OverflowException $e) {
            throw $e;
        } catch (\Throwable $e) {
            return null;
        }

        $itemsById = [];
        foreach ($ticketRows as $ticketId => $fields) {
            $requesterNames = $this->labelsForIds(
                array_values((array) ($usersByTicket[$ticketId][1] ?? [])),
                $userLabels,
                I18n::translate('Usuário')
            );
            $assigneeNames = $this->labelsForIds(
                array_values((array) ($usersByTicket[$ticketId][2] ?? [])),
                $userLabels,
                I18n::translate('Usuário')
            );
            $ticketGroupIds = array_values((array) ($groupsByTicket[$ticketId] ?? []));
            usort($ticketGroupIds, static function (int $left, int $right) use ($groupLabels): int {
                return strcasecmp(
                    (string) ($groupLabels[$left] ?? ('Grupo #' . $left)),
                    (string) ($groupLabels[$right] ?? ('Grupo #' . $right))
                );
            });
            $groupNames = $this->labelsForIds($ticketGroupIds, $groupLabels, 'Grupo');

            $itemsById[$ticketId] = $this->mapTicketFieldsToListRowWithRelations(
                $fields,
                $requesterNames,
                $assigneeNames,
                $ticketGroupIds,
                $groupNames,
                $entityLabels,
                $categoryLabels,
                $locationLabels
            );
        }

        $items = [];
        foreach ($ticketIds as $ticketId) {
            if (!isset($itemsById[$ticketId]) || !is_array($itemsById[$ticketId])) {
                return null;
            }
            $items[] = $itemsById[$ticketId];
        }

        return $items;
    }

    /**
     * @param array<string,mixed> $query
     * @return array<int,array<string,mixed>>
     */
    private function requestBoundedRelationRows(array $query, int $maximumRows): array
    {
        global $DB;
        if (
            $maximumRows < 0
            || $maximumRows > self::MAX_HYDRATED_RELATION_ROWS_PER_PAGE
            || !isset($DB)
            || !method_exists($DB, 'request')
        ) {
            throw new \RuntimeException('bounded_relation_query_unavailable');
        }

        $query['LIMIT'] = $maximumRows + 1;
        $rows = [];
        foreach ($DB->request($query) as $row) {
            if (count($rows) >= $maximumRows) {
                throw new \OverflowException('bounded_search_hydration_relation_limit_exceeded');
            }
            $rows[] = (array) $row;
        }

        return $rows;
    }

    /** @param array<int, array<string, mixed>> $rows @return int[] */
    private function collectForeignIds(array $rows, string $field): array
    {
        $ids = [];
        foreach ($rows as $row) {
            $id = (int) ($row[$field] ?? 0);
            if ($id > 0) {
                $ids[$id] = $id;
            }
        }

        return array_values($ids);
    }

    /**
     * @param int[] $ids
     * @return array<int, string>
     */
    private function batchDropdownLabels(string $table, array $ids, string $fallbackPrefix): array
    {
        global $DB;

        $ids = array_values(array_unique(array_filter(array_map('intval', $ids), static fn(int $id): bool => $id > 0)));
        if ($ids === [] || !isset($DB) || !method_exists($DB, 'request') || !$this->tableExists($table)) {
            return [];
        }

        $availableColumns = $this->getTableColumns($table);
        $select = array_values(array_intersect(['id', 'completename', 'name'], $availableColumns));
        if (!in_array('id', $select, true)) {
            return [];
        }

        $labels = [];
        foreach (
            $DB->request([
            'SELECT' => $select,
            'FROM' => $table,
            'WHERE' => ['id' => $ids],
            ]) as $row
        ) {
            $id = (int) ($row['id'] ?? 0);
            if ($id <= 0) {
                continue;
            }
            $label = trim((string) ($row['completename'] ?? $row['name'] ?? ''));
            $labels[$id] = TextNormalizer::fromGlpi($label !== '' ? $label : $fallbackPrefix . ' ' . $id);
        }

        return $labels;
    }

    /** @param int[] $ids @param array<int, string> $labels @return string[] */
    private function labelsForIds(array $ids, array $labels, string $fallbackPrefix): array
    {
        $resolved = [];
        foreach ($ids as $id) {
            $id = (int) $id;
            if ($id > 0) {
                $resolved[] = (string) ($labels[$id] ?? ($fallbackPrefix . ' #' . $id));
            }
        }

        return array_values($resolved);
    }

    /**
     * @param string[] $requesterNames
     * @param string[] $assigneeNames
     * @param int[] $groupIds
     * @param string[] $groupNames
     * @param array<int, string> $entityLabels
     * @param array<int, string> $categoryLabels
     * @param array<int, string> $locationLabels
     * @return array<string, mixed>|null
     */
    private function mapTicketFieldsToListRowWithRelations(
        array $fields,
        array $requesterNames,
        array $assigneeNames,
        array $groupIds,
        array $groupNames,
        array $entityLabels,
        array $categoryLabels,
        array $locationLabels
    ): ?array {
        $ticketId = (int) ($fields['id'] ?? 0);
        if ($ticketId <= 0) {
            return null;
        }

        $entityId = (int) ($fields['entities_id'] ?? 0);
        $categoryId = (int) ($fields['itilcategories_id'] ?? 0);
        $locationId = (int) ($fields['locations_id'] ?? 0);

        return [
            'id' => $ticketId,
            'name' => TextNormalizer::fromGlpi((string) ($fields['name'] ?? '')),
            'content' => TextNormalizer::fromGlpi((string) ($fields['content'] ?? '')),
            'status' => (int) ($fields['status'] ?? 0),
            'priority' => (int) ($fields['priority'] ?? 0),
            'urgency' => (int) ($fields['urgency'] ?? 0),
            'impact' => (int) ($fields['impact'] ?? 0),
            'date' => (string) ($fields['date'] ?? ''),
            'date_mod' => (string) ($fields['date_mod'] ?? ''),
            'entities_id' => $entityId,
            'itilcategories_id' => $categoryId,
            'locations_id' => $locationId,
            'entity_name' => (string) ($entityLabels[$entityId] ?? ('Entidade ' . $entityId)),
            'category_name' => $categoryId > 0
                ? (string) ($categoryLabels[$categoryId] ?? sprintf(I18n::translate('Categoria %d'), $categoryId))
                : I18n::translate('Não informado'),
            'location_name' => $locationId > 0
                ? (string) ($locationLabels[$locationId] ?? sprintf(I18n::translate('Localização %d'), $locationId))
                : I18n::translate('Não informado'),
            'time_to_resolve' => (string) ($fields['time_to_resolve'] ?? ''),
            'users_id_recipient' => (int) ($fields['users_id_recipient'] ?? 0),
            'requester_name' => TextNormalizer::fromGlpi(implode(', ', $requesterNames)),
            'assignee_name' => TextNormalizer::fromGlpi(implode(', ', $assigneeNames)),
            'group_names' => $groupNames,
            'group_ids' => $groupIds,
            'primary_group_name' => $groupNames[0] ?? 'Sem grupo',
            'primary_group_id' => $groupIds[0] ?? 0,
        ];
    }

    /** @return array<int, array{id:int,label:string}> */
    public function getTicketGroupFilterOptions(): array
    {
        $map = [];
        foreach ($this->getCurrentUserGroupIds() as $groupId) {
            $label = $this->resolveGroupName((int) $groupId);
            if ($label !== '') {
                $map[(int) $groupId] = $label;
            }
        }

        asort($map, SORT_NATURAL | SORT_FLAG_CASE);
        $options = [];
        foreach ($map as $id => $label) {
            $options[] = ['id' => (int) $id, 'label' => TextNormalizer::fromGlpi((string) $label)];
        }

        return $options;
    }

    public function getTicketById(int $ticketId): ?array
    {
        $ticketId = max(1, $ticketId);
        if (!$this->canReadTicket($ticketId)) {
            return null;
        }

        $ticket = new \Ticket();
        if (!$ticket->getFromDB($ticketId)) {
            return null;
        }

        $row = $ticket->fields;
        $requesterIds = $this->getTicketUserIdsByType($ticketId, 1);
        $requesterId = (int) ($requesterIds[0] ?? 0);
        $requester = $this->getUserContact($requesterId);

        $row['requester_id'] = $requesterId;
        $row['requester_firstname'] = $requester['firstname'] ?? '';
        $row['requester_realname'] = $requester['realname'] ?? '';
        $row['requester_email'] = '';
        $row['requester_phone'] = '';
        $row['requester_mobile'] = '';
        $row['requester_decision'] = $this->getTicketSatisfaction((int) $ticketId);
        $row['satisfaction_state'] = $this->getTicketSatisfactionState((int) $ticketId);
        $row['entity_name'] = $this->getEntityName((int) ($row['entities_id'] ?? 0));
        $row['category_name'] = $this->resolveTicketCategoryName((int) ($row['itilcategories_id'] ?? 0));
        $row['locations_id'] = $this->readTicketLocationId($ticket, $ticketId);
        $row['location_name'] = $this->resolveTicketLocationName((int) $row['locations_id']);

        return $row;
    }

    /**
     * Return requester contact only after the caller has already established
     * ticket access. The application service masks these values by default and
     * reveals them only through the audited PII flow.
     *
     * @return array{firstname:string,realname:string,email:string,phone:string,mobile:string}
     */
    public function getTicketRequesterContact(int $ticketId): array
    {
        $empty = ['firstname' => '', 'realname' => '', 'email' => '', 'phone' => '', 'mobile' => ''];
        if (!$this->canReadTicket($ticketId)) {
            return $empty;
        }

        $requesterIds = $this->getTicketUserIdsByType($ticketId, 1);
        $requesterId = (int) ($requesterIds[0] ?? 0);
        if ($requesterId <= 0) {
            return $empty;
        }

        return $this->getUserContact($requesterId);
    }

    private function nativeTicketOrder(string $sort, string $direction): string
    {
        $direction = strtoupper($direction) === 'ASC' ? 'ASC' : 'DESC';
        $allowed = ['id', 'name', 'status', 'priority', 'date', 'date_mod'];
        $field = in_array($sort, $allowed, true) ? $sort : 'date_mod';
        return $field . ' ' . $direction;
    }

    private function ticketMatchesPortalFilters(array $fields, array $filters): bool
    {
        $ticketId = (int) ($fields['id'] ?? 0);
        if ($ticketId <= 0 || !$this->canReadTicket($ticketId)) {
            return false;
        }

        if (isset($fields['entities_id']) && !in_array((int) $fields['entities_id'], $this->getCurrentEntities(), true)) {
            return false;
        }

        $status = (string) ($filters['status'] ?? '');
        if ($status !== '' && ctype_digit($status) && (int) ($fields['status'] ?? 0) !== (int) $status) {
            return false;
        }

        $scope = (string) ($filters['scope'] ?? 'all');
        if ($scope === 'mine' && !$this->isCurrentUserTicketParticipant($ticketId)) {
            return false;
        }
        if ($scope === 'group' && !$this->isCurrentUserGroupTicket($ticketId)) {
            return false;
        }

        $groupId = (int) ($filters['group_id'] ?? 0);
        if ($groupId > 0 && !in_array($groupId, $this->getTicketGroupIdsByType($ticketId, 2), true)) {
            return false;
        }

        $search = trim((string) ($filters['q'] ?? ''));
        if ($search !== '') {
            $haystack = $this->normalizeSearchText(
                (string) ($fields['id'] ?? '') . ' ' .
                (string) ($fields['name'] ?? '') . ' ' .
                (string) ($fields['content'] ?? '')
            );
            if (!str_contains($haystack, $this->normalizeSearchText($search))) {
                return false;
            }
        }

        return true;
    }

    private function mapTicketFieldsToListRow(array $fields): ?array
    {
        $ticketId = (int) ($fields['id'] ?? 0);
        if ($ticketId <= 0) {
            return null;
        }

        $requesterNames = $this->getTicketUserNamesByType($ticketId, 1);
        $assigneeNames = $this->getTicketUserNamesByType($ticketId, 2);
        $groups = $this->getTicketAssignedGroups($ticketId);

        $groupNames = array_values(array_map(
            static fn(array $group): string => (string) ($group['name'] ?? ''),
            $groups
        ));
        $groupIds = array_values(array_map(
            static fn(array $group): int => (int) ($group['id'] ?? 0),
            $groups
        ));

        return [
            'id' => $ticketId,
            'name' => TextNormalizer::fromGlpi((string) ($fields['name'] ?? '')),
            'content' => TextNormalizer::fromGlpi((string) ($fields['content'] ?? '')),
            'status' => (int) ($fields['status'] ?? 0),
            'priority' => (int) ($fields['priority'] ?? 0),
            'urgency' => (int) ($fields['urgency'] ?? 0),
            'impact' => (int) ($fields['impact'] ?? 0),
            'date' => (string) ($fields['date'] ?? ''),
            'date_mod' => (string) ($fields['date_mod'] ?? ''),
            'entities_id' => (int) ($fields['entities_id'] ?? 0),
            'itilcategories_id' => (int) ($fields['itilcategories_id'] ?? 0),
            'locations_id' => (int) ($fields['locations_id'] ?? 0),
            'entity_name' => TextNormalizer::fromGlpi($this->getEntityName((int) ($fields['entities_id'] ?? 0))),
            'category_name' => TextNormalizer::fromGlpi($this->resolveTicketCategoryName((int) ($fields['itilcategories_id'] ?? 0))),
            'location_name' => TextNormalizer::fromGlpi($this->resolveTicketLocationName((int) ($fields['locations_id'] ?? 0))),
            'time_to_resolve' => (string) ($fields['time_to_resolve'] ?? ''),
            'users_id_recipient' => (int) ($fields['users_id_recipient'] ?? 0),
            'requester_name' => TextNormalizer::fromGlpi(implode(', ', $requesterNames)),
            'assignee_name' => TextNormalizer::fromGlpi(implode(', ', $assigneeNames)),
            'group_names' => $groupNames,
            'group_ids' => $groupIds,
            'primary_group_name' => $groupNames[0] ?? 'Sem grupo',
            'primary_group_id' => $groupIds[0] ?? 0,
        ];
    }

    /**
     * @param array<int, array<string, mixed>> $rows
     */
    private function sortTicketRows(array &$rows, string $sort, string $direction): void
    {
        $allowed = ['id', 'name', 'status', 'priority', 'date', 'date_mod'];
        $field = in_array($sort, $allowed, true) ? $sort : 'date_mod';
        $multiplier = strtoupper($direction) === 'ASC' ? 1 : -1;

        usort($rows, static function (array $left, array $right) use ($field, $multiplier): int {
            $leftValue = $left[$field] ?? '';
            $rightValue = $right[$field] ?? '';
            if (is_numeric($leftValue) && is_numeric($rightValue)) {
                return ((int) $leftValue <=> (int) $rightValue) * $multiplier;
            }

            return strcmp((string) $leftValue, (string) $rightValue) * $multiplier;
        });
    }

    private function isCurrentUserTicketParticipant(int $ticketId): bool
    {
        $userId = (int) ($_SESSION['glpiID'] ?? 0);
        if ($userId <= 0) {
            return false;
        }

        foreach ([1, 2, 3] as $type) {
            if (in_array($userId, $this->getTicketUserIdsByType($ticketId, $type), true)) {
                return true;
            }
        }

        return false;
    }

    private function isCurrentUserGroupTicket(int $ticketId): bool
    {
        $currentGroups = $this->getCurrentUserGroupIds();
        if ($currentGroups === []) {
            return false;
        }

        // Search API uses the native assigned-group relation (type=2).
        // Keep the compatibility backend semantically identical.
        if (array_intersect($currentGroups, $this->getTicketGroupIdsByType($ticketId, 2)) !== []) {
            return true;
        }

        return false;
    }

    /**
     * @return int[]
     */
    private function getTicketUserIdsByType(int $ticketId, int $type): array
    {
        if (!class_exists('\Ticket_User')) {
            return [];
        }

        $ticketUser = new \Ticket_User();
        $ids = [];
        foreach ($ticketUser->find(['tickets_id' => max(1, $ticketId), 'type' => $type]) as $row) {
            $id = (int) ($row['users_id'] ?? 0);
            if ($id > 0) {
                $ids[$id] = $id;
            }
        }

        return array_values($ids);
    }

    /**
     * @return string[]
     */
    private function getTicketUserNamesByType(int $ticketId, int $type): array
    {
        $names = [];
        foreach ($this->getTicketUserIdsByType($ticketId, $type) as $userId) {
            $names[] = $this->resolveUserName($userId);
        }

        return $names;
    }

    /**
     * @return int[]
     */
    private function getTicketGroupIdsByType(int $ticketId, int $type): array
    {
        if (!class_exists('\Group_Ticket')) {
            return [];
        }

        $groupTicket = new \Group_Ticket();
        $ids = [];
        foreach ($groupTicket->find(['tickets_id' => max(1, $ticketId), 'type' => $type]) as $row) {
            $id = (int) ($row['groups_id'] ?? 0);
            if ($id > 0) {
                $ids[$id] = $id;
            }
        }

        return array_values($ids);
    }

    /**
     * @return int[]
     */
    public function getCurrentUserGroupIds(): array
    {
        return $this->currentUserGroupContext()['ids'];
    }

    /**
     * GLPI 10 and 11 populate glpigroups for the active entity context. An
     * explicitly empty array is authoritative; a missing or malformed value
     * must remain unavailable so it is never mistaken for an exact zero.
     *
     * @return array{state:'resolved'|'unavailable',ids:int[]}
     */
    private function currentUserGroupContext(): array
    {
        $loadConfirmed = $_SESSION[SessionContextGuard::GROUP_CONTEXT_LOAD_CONFIRMED_SESSION_KEY] ?? null;
        if ($loadConfirmed === false) {
            return ['state' => 'unavailable', 'ids' => []];
        }
        if (!array_key_exists('glpigroups', $_SESSION) || !is_array($_SESSION['glpigroups'])) {
            return ['state' => 'unavailable', 'ids' => []];
        }

        $ids = [];
        foreach ($_SESSION['glpigroups'] as $key => $value) {
            $candidate = 0;
            if (is_numeric($value)) {
                $candidate = (int) $value;
            } elseif (is_array($value) && is_numeric($value['id'] ?? null)) {
                $candidate = (int) $value['id'];
            } elseif (is_numeric($key)) {
                $candidate = (int) $key;
            }

            if ($candidate <= 0) {
                return ['state' => 'unavailable', 'ids' => []];
            }
            $ids[$candidate] = $candidate;
        }

        $ids = array_values($ids);
        sort($ids, SORT_NUMERIC);
        return ['state' => 'resolved', 'ids' => $ids];
    }

    /** @return array{state:'not_applicable'|'resolved'|'empty'|'unavailable',reason:string} */
    private function currentUserGroupScopeResolution(array $filters): array
    {
        if ((string) ($filters['scope'] ?? 'all') !== 'group') {
            return ['state' => 'not_applicable', 'reason' => ''];
        }

        $context = $this->currentUserGroupContext();
        if ($context['state'] !== 'resolved') {
            return ['state' => 'unavailable', 'reason' => 'group_scope_context_unavailable'];
        }

        $groupId = max(0, (int) ($filters['group_id'] ?? 0));
        if ($groupId > 0 && !in_array($groupId, $context['ids'], true)) {
            return ['state' => 'empty', 'reason' => 'group_scope_group_not_in_current_groups'];
        }
        if ($groupId <= 0 && $context['ids'] === []) {
            return ['state' => 'empty', 'reason' => 'group_scope_without_current_groups'];
        }

        return ['state' => 'resolved', 'reason' => ''];
    }

    private function resolveUserName(int $userId): string
    {
        if ($userId <= 0 || !class_exists('\User')) {
            return $userId > 0 ? sprintf(I18n::translate('Usuário #%d'), $userId) : '';
        }

        $user = new \User();
        if (!$user->getFromDB($userId)) {
            return sprintf(I18n::translate('Usuário #%d'), $userId);
        }

        return $this->formatUserName($user->fields, $userId);
    }

    private function formatUserName(array $fields, int $fallbackId): string
    {
        $name = trim((string) (($fields['firstname'] ?? '') . ' ' . ($fields['realname'] ?? '')));
        if ($name !== '') {
            return $name;
        }

        $login = trim((string) ($fields['name'] ?? ''));
        return $login !== '' ? $login : sprintf(I18n::translate('Usuário #%d'), $fallbackId);
    }

    private function resolveGroupName(int $groupId): string
    {
        if ($groupId <= 0 || !class_exists('\Group')) {
            return $groupId > 0 ? 'Grupo ' . $groupId : '';
        }

        $group = new \Group();
        if (!$group->getFromDB($groupId)) {
            return 'Grupo ' . $groupId;
        }

        return TextNormalizer::fromGlpi((string) ($group->fields['completename'] ?? $group->fields['name'] ?? ('Grupo ' . $groupId)));
    }

    /**
     * @return array{firstname:string,realname:string,email:string,phone:string,mobile:string}
     */
    private function getUserContact(int $userId): array
    {
        $contact = [
            'firstname' => '',
            'realname' => '',
            'email' => '',
            'phone' => '',
            'mobile' => '',
        ];

        if ($userId <= 0 || !class_exists('\User')) {
            return $contact;
        }

        $user = new \User();
        if (!$user->getFromDB($userId)) {
            return $contact;
        }

        $contact['firstname'] = (string) ($user->fields['firstname'] ?? '');
        $contact['realname'] = (string) ($user->fields['realname'] ?? '');
        $contact['phone'] = (string) ($user->fields['phone'] ?? '');
        $contact['mobile'] = (string) ($user->fields['mobile'] ?? '');
        $contact['email'] = (string) ($user->fields['email'] ?? '');

        if (class_exists('\UserEmail')) {
            $email = new \UserEmail();
            $rows = $email->find(['users_id' => $userId, 'is_default' => 1]);
            if ($rows === []) {
                $rows = $email->find(['users_id' => $userId]);
            }
            $first = is_array($rows) ? reset($rows) : false;
            if (is_array($first) && trim((string) ($first['email'] ?? '')) !== '') {
                $contact['email'] = (string) $first['email'];
            }
        }

        return $contact;
    }

    private function getTicketSatisfaction(int $ticketId): int
    {
        if (!class_exists('\TicketSatisfaction')) {
            return 0;
        }

        $satisfaction = new \TicketSatisfaction();
        $rows = $satisfaction->find(['tickets_id' => max(1, $ticketId)]);
        $first = is_array($rows) ? reset($rows) : false;
        return is_array($first) ? (int) ($first['satisfaction'] ?? 0) : 0;
    }

    public function getTicketSatisfactionState(int $ticketId): array
    {
        $ticketId = max(1, $ticketId);
        $state = [
            'exists' => false,
            'available' => false,
            'can_answer' => false,
            'is_closed' => false,
            'id' => 0,
            'score' => null,
            'comment' => '',
            'date_answered' => '',
        ];

        if (!class_exists('\Ticket') || !class_exists('\TicketSatisfaction') || !$this->canReadTicket($ticketId)) {
            return $state;
        }

        $ticket = new \Ticket();
        if (!$ticket->getFromDB($ticketId)) {
            return $state;
        }

        $status = (int) ($ticket->fields['status'] ?? 0);
        $closedStatuses = method_exists(\Ticket::class, 'getClosedStatusArray') ? \Ticket::getClosedStatusArray() : [6];
        $state['is_closed'] = in_array($status, array_map('intval', (array) $closedStatuses), true);

        $satisfaction = new \TicketSatisfaction();
        $rows = $satisfaction->find(['tickets_id' => $ticketId]);
        $first = is_array($rows) ? reset($rows) : false;
        if (!is_array($first) || empty($first['id'])) {
            return $state;
        }

        $state['exists'] = true;
        $state['id'] = (int) $first['id'];
        $state['score'] = isset($first['satisfaction']) ? (int) $first['satisfaction'] : null;
        $state['comment'] = (string) ($first['comment'] ?? '');
        $state['date_answered'] = (string) ($first['date_answered'] ?? '');
        $state['available'] = (bool) $state['is_closed'];

        $current = new \TicketSatisfaction();
        if ($state['available'] && $current->getFromDB((int) $state['id'])) {
            $state['can_answer'] = method_exists($current, 'canUpdateItem')
                ? (bool) $current->canUpdateItem()
                : $this->canReadTicket($ticketId);
        }

        return $state;
    }

    public function getTicketActors(int $ticketId): array
    {
        if (!$this->canReadTicket($ticketId)) {
            return [];
        }

        $actors = [
            'requesters' => [],
            'assignees' => [],
            'watchers' => [],
        ];

        $ticketUser = new \Ticket_User();
        foreach ($ticketUser->find(['tickets_id' => max(1, $ticketId)]) as $row) {
            $type = (int) ($row['type'] ?? 0);
            $userId = (int) ($row['users_id'] ?? 0);
            if ($userId <= 0) {
                continue;
            }

            $item = [
                'id' => $userId,
                'name' => $this->resolveUserName($userId),
                'kind' => 'user',
            ];

            if ($type === 1) {
                $actors['requesters'][] = $item;
            } elseif ($type === 2) {
                $actors['assignees'][] = $item;
            } elseif ($type === 3) {
                $actors['watchers'][] = $item;
            }
        }

        if (class_exists('\Group_Ticket')) {
            $groupTicket = new \Group_Ticket();
            foreach ($groupTicket->find(['tickets_id' => max(1, $ticketId)]) as $row) {
                $type = (int) ($row['type'] ?? 0);
                $groupId = (int) ($row['groups_id'] ?? 0);
                if ($groupId <= 0) {
                    continue;
                }
                $item = [
                    'id' => $groupId,
                    'name' => $this->resolveGroupName($groupId),
                    'kind' => 'group',
                ];

                if ($type === 1) {
                    $actors['requesters'][] = $item;
                } elseif ($type === 2) {
                    $actors['assignees'][] = $item;
                } elseif ($type === 3) {
                    $actors['watchers'][] = $item;
                }
            }
        }

        if (class_exists('\Supplier_Ticket')) {
            $supplierTicket = new \Supplier_Ticket();
            foreach ($supplierTicket->find(['tickets_id' => max(1, $ticketId), 'type' => 2]) as $row) {
                $supplierId = (int) ($row['suppliers_id'] ?? 0);
                if ($supplierId <= 0) {
                    continue;
                }
                $label = $this->currentTicketActorLabel('supplier', $supplierId);
                $actors['assignees'][] = [
                    'id' => $supplierId,
                    'name' => $label ?? ('#' . $supplierId),
                    'kind' => 'supplier',
                ];
            }
        }

        return $actors;
    }

    public function getTicketActionContext(int $ticketId): array
    {
        $canRead = $ticketId > 0 && $this->canReadTicket($ticketId);
        $canUpdate = $canRead && $this->canUpdateTicket($ticketId);
        $canAddFollowup = $canRead && $this->canAddFollowupToTicket($ticketId);
        $canAddTask = $canRead && $this->canAddTaskToTicket($ticketId);
        $canAddPrivateFollowup = $canAddFollowup && $this->canAddPrivateFollowup($ticketId);
        $canAddPrivateTask = $canAddTask && $this->canAddPrivateTask($ticketId);
        $solutionOperation = $canRead
            ? $this->getSolutionOperationState($ticketId)
            : $this->emptySolutionOperationState('unavailable');
        $canAddSolution = $canRead
            && ($solutionOperation['state'] ?? '') === 'ready'
            && $this->canAddSolutionToTicket($ticketId);
        $canChangeStatus = $canRead && $this->canChangeStatusToTicket($ticketId);
        $canAssignActors = $canRead && $this->canAssignTicketActors($ticketId);
        $canObserveActors = $canRead && $this->canObserveTicketActors($ticketId);
        $canAdminActors = $canRead && $this->canAdminTicketRequesters($ticketId);
        $canRoute = $canAssignActors || $canObserveActors || $canAdminActors;
        $selfAssignment = $canRead ? $this->getTicketSelfAssignmentContext($ticketId) : [];

        return [
            'can_read' => $canRead,
            'can_update' => $canUpdate,
            'can_add_followup' => $canAddFollowup,
            'can_add_task' => $canAddTask,
            'can_add_private_followup' => $canAddPrivateFollowup,
            'can_add_private_task' => $canAddPrivateTask,
            'can_add_solution' => $canAddSolution,
            'solution_operation' => $solutionOperation,
            'can_change_status' => $canChangeStatus,
            'can_route' => $canRoute,
            'can_assign_actors' => $canAssignActors,
            'can_self_assign' => !empty($selfAssignment['can_self_assign']),
            'self_assign_revision' => (string) ($selfAssignment['revision'] ?? ''),
            'can_observe_actors' => $canObserveActors,
            'can_admin_actors' => $canAdminActors,
            'default_followup_is_private' => $canAddPrivateFollowup && $this->defaultTimelineItemPrivacy(
                \ITILFollowup::class,
                'glpifollowup_private'
            ),
            'default_task_is_private' => $canAddPrivateTask && $this->defaultTimelineItemPrivacy(
                \TicketTask::class,
                'glpitask_private'
            ),
        ];
    }

    /**
     * Return the exact native GLPI contract used to show and revalidate the
     * approval/refusal controls for the latest ticket solution.
     *
     * @return array{
     *   state:string,visible:bool,can_decide:bool,current_status:int,
     *   solution_id:int,solution_status:int,revision:string
     * }
     */
    public function getSolutionDecisionContext(int $ticketId): array
    {
        $context = $this->emptySolutionDecisionContext('unavailable');
        if (
            $ticketId <= 0
            || !class_exists('\Ticket')
            || !class_exists('\ITILSolution')
        ) {
            return $context;
        }

        try {
            $ticket = new \Ticket();
            if (!$ticket->getFromDB($ticketId) || !$ticket->canViewItem()) {
                return $context;
            }

            $ticketFields = is_array($ticket->fields ?? null) ? $ticket->fields : [];
            $context['visible'] = true;
            $context['current_status'] = max(0, (int) ($ticketFields['status'] ?? 0));
            $isSolved = method_exists($ticket, 'isSolved') && $ticket->isSolved();
            $partial = $this->solutionIdempotencyLedger instanceof IdempotencyLedger
                ? $this->solutionIdempotencyLedger->latestPartial('ticket.solution-decision:' . $ticketId)
                : null;
            if (!$isSolved && !is_array($partial)) {
                $context['state'] = 'not_solved';
                return $context;
            }

            $solution = $this->latestSolutionForTicket($ticketId);
            $context['solution_id'] = max(0, (int) ($solution['id'] ?? 0));
            $context['solution_status'] = max(0, (int) ($solution['status'] ?? 0));
            $context['revision'] = $this->solutionDecisionRevision($ticketFields, $solution);

            if ($this->solutionIdempotencyLedger instanceof IdempotencyLedger && is_array($partial)) {
                $guardState = $this->reconcileSolutionDecisionGuard($ticketId, $ticketFields, $solution, $partial);
                if (!in_array((string) ($guardState['state'] ?? ''), ['clear', 'approved', 'refused', 'active'], true)) {
                    $context['state'] = 'in_progress';
                    return $context;
                }
            }

            if (!$isSolved) {
                $context['state'] = 'not_solved';
                return $context;
            }
            if ($context['solution_id'] <= 0) {
                return $context;
            }
            if (!method_exists($ticket, 'canApprove') || !$ticket->canApprove()) {
                $context['state'] = 'not_approver';
                return $context;
            }
            if (!method_exists($ticket, 'canAddFollowups') || !$ticket->canAddFollowups()) {
                $context['state'] = 'followup_denied';
                return $context;
            }
            if (
                !method_exists($ticket, 'isAllowedStatus')
                || !$ticket->isAllowedStatus($context['current_status'], $this->closedStatus())
            ) {
                $context['state'] = 'transition_denied';
                return $context;
            }

            $context['state'] = 'ready';
            $context['can_decide'] = true;
            return $context;
        } catch (\Throwable) {
            return $context;
        }
    }

    public function getTicketRoutingContext(int $ticketId, bool $includeRemoteResources = true): array
    {
        $actions = $this->getTicketActionContext($ticketId);
        $canUpdate = !empty($actions['can_update']);
        $canAddTask = !empty($actions['can_add_task']);
        $canAssignActors = !empty($actions['can_assign_actors']);
        $canObserveActors = !empty($actions['can_observe_actors']);
        $canAdminActors = !empty($actions['can_admin_actors']);
        $canRoute = $canAssignActors || $canObserveActors || $canAdminActors;
        $ticket = !empty($actions['can_read'])
            ? $this->getTicketById($ticketId)
            : null;
        $ticketEntityId = is_array($ticket) && array_key_exists('entities_id', $ticket)
            ? (int) $ticket['entities_id']
            : null;

        $currentSelection = $canRoute
            ? $this->getCurrentTicketRoutingSelection($ticketId)
            : [
                'complete' => true,
                'revision' => '',
                'roles' => [],
            ];

        return [
            'can_update' => $canUpdate,
            'can_add_task' => $canAddTask,
            'can_route' => $canRoute,
            'can_assign_actors' => $canAssignActors,
            'can_observe_actors' => $canObserveActors,
            'can_admin_actors' => $canAdminActors,
            'requester_users' => $includeRemoteResources
                && $canAdminActors
                && $ticketEntityId !== null
                ? $this->getRequesterUsers($ticketEntityId)
                : [],
            'assignable_users' => $includeRemoteResources
                && ($canAddTask || $canAssignActors)
                && $ticketEntityId !== null
                ? $this->getAssignableUsers($ticketEntityId)
                : [],
            'observer_users' => $includeRemoteResources
                && $canObserveActors
                && $ticketEntityId !== null
                ? $this->getObserverUsers($ticketEntityId)
                : [],
            'assignable_groups' => $includeRemoteResources && $canAssignActors && $ticketEntityId !== null
                ? $this->getAssignableGroups($ticketEntityId)
                : [],
            'task_groups' => $includeRemoteResources && $canAddTask && $ticketEntityId !== null
                ? $this->getTaskGroups($ticketEntityId)
                : [],
            'observer_groups' => $includeRemoteResources && $canObserveActors && $ticketEntityId !== null
                ? $this->getObserverGroups($ticketEntityId)
                : [],
            'requester_groups' => $includeRemoteResources && $canAdminActors && $ticketEntityId !== null
                ? $this->getRequesterGroups($ticketEntityId)
                : [],
            'assignable_suppliers' => $includeRemoteResources && $canAssignActors && $ticketEntityId !== null
                ? $this->getAssignableSuppliers($ticketEntityId)
                : [],
            'task_categories' => $canAddTask ? $this->getTaskCategories($ticketEntityId) : [],
            'task_state_options' => $canAddTask ? $this->getTaskStateOptions() : [],
            'task_duration_options' => $canAddTask ? $this->getTaskDurationOptions() : [],
            'assigned_user_ids' => (array) ($currentSelection['roles']['_users_id_assign']['expected_ids'] ?? []),
            'observer_user_ids' => (array) ($currentSelection['roles']['_users_id_observer']['expected_ids'] ?? []),
            'assigned_group_ids' => (array) ($currentSelection['roles']['_groups_id_assign']['expected_ids'] ?? []),
            'observer_group_ids' => (array) ($currentSelection['roles']['_groups_id_observer']['expected_ids'] ?? []),
            'requester_user_ids' => (array) ($currentSelection['roles']['_users_id_requester']['expected_ids'] ?? []),
            'requester_group_ids' => (array) ($currentSelection['roles']['_groups_id_requester']['expected_ids'] ?? []),
            'assigned_supplier_ids' => (array) ($currentSelection['roles']['_suppliers_id_assign']['expected_ids'] ?? []),
            'routing_selection_complete' => !empty($currentSelection['complete']),
            'routing_revision' => (string) ($currentSelection['revision'] ?? ''),
            'selected_resources' => array_map(
                static fn(array $role): array => (array) ($role['items'] ?? []),
                (array) ($currentSelection['roles'] ?? [])
            ),
            'routing_selection' => $currentSelection,
        ];
    }

    /**
     * Read actors already linked to the ticket without applying the eligibility
     * rules used to discover new candidates. A partial result is never treated
     * as an authoritative empty selection.
     *
     * @return array{
     *   complete:bool,
     *   revision:string,
     *   roles:array<string,array{complete:bool,expected_ids:int[],items:array<int,array{id:int,label:string}>,missing_ids:int[]}>
     * }
     */
    public function getCurrentTicketRoutingSelection(int $ticketId): array
    {
        $contracts = [
            '_users_id_assign' => ['snapshot' => 'assigned_users', 'kind' => 'user'],
            '_users_id_observer' => ['snapshot' => 'observer_users', 'kind' => 'user'],
            '_groups_id_assign' => ['snapshot' => 'assigned_groups', 'kind' => 'group'],
            '_groups_id_observer' => ['snapshot' => 'observer_groups', 'kind' => 'group'],
            '_users_id_requester' => ['snapshot' => 'requester_users', 'kind' => 'user'],
            '_groups_id_requester' => ['snapshot' => 'requester_groups', 'kind' => 'group'],
            '_suppliers_id_assign' => ['snapshot' => 'assigned_suppliers', 'kind' => 'supplier'],
        ];
        $roles = [];
        foreach ($contracts as $field => $contract) {
            $roles[$field] = [
                'complete' => false,
                'expected_ids' => [],
                'items' => [],
                'missing_ids' => [],
            ];
        }

        if ($ticketId <= 0 || !$this->canReadTicket($ticketId)) {
            return ['complete' => false, 'revision' => '', 'roles' => $roles];
        }

        $snapshot = $this->ticketRoutingActorSnapshot($ticketId);
        if ($snapshot === null) {
            return ['complete' => false, 'revision' => '', 'roles' => $roles];
        }

        $allComplete = true;
        foreach ($contracts as $field => $contract) {
            $ids = array_values(array_map('intval', (array) ($snapshot[$contract['snapshot']] ?? [])));
            sort($ids, SORT_NUMERIC);
            $items = [];
            $missing = [];
            if (count($ids) > GlpiResourceSelectorProvider::MAX_SELECTED_IDS) {
                $missing = $ids;
            } else {
                foreach ($ids as $id) {
                    $label = $this->currentTicketActorLabel((string) $contract['kind'], $id);
                    if ($label === null) {
                        $missing[] = $id;
                        continue;
                    }
                    $items[] = ['id' => $id, 'label' => $label];
                }
            }
            $complete = $missing === [] && count($items) === count($ids);
            $roles[$field] = [
                'complete' => $complete,
                'expected_ids' => $ids,
                'items' => $items,
                'missing_ids' => $missing,
            ];
            $allComplete = $allComplete && $complete;
        }

        return [
            'complete' => $allComplete,
            'revision' => $this->ticketRoutingSnapshotRevision($snapshot),
            'roles' => $roles,
        ];
    }

    private function currentTicketActorLabel(string $kind, int $id): ?string
    {
        if ($id <= 0 || !in_array($kind, ['user', 'group', 'supplier'], true)) {
            return null;
        }
        try {
            if ($kind === 'user' && class_exists('\User')) {
                $item = new \User();
                if ($item->getFromDB($id)) {
                    $label = trim($this->formatUserName((array) $item->fields, $id));
                    return $label !== '' ? $label : null;
                }
            }
            if ($kind === 'group' && class_exists('\Group')) {
                $item = new \Group();
                if ($item->getFromDB($id)) {
                    $label = TextNormalizer::fromGlpi(
                        (string) ($item->fields['completename'] ?? $item->fields['name'] ?? '')
                    );
                    return $label !== '' ? $label : null;
                }
            }
            if ($kind === 'supplier' && class_exists('\Supplier')) {
                $item = new \Supplier();
                if ($item->getFromDB($id)) {
                    $label = TextNormalizer::fromGlpi((string) ($item->fields['name'] ?? ''));
                    return $label !== '' ? $label : null;
                }
            }
        } catch (\Throwable) {
            return null;
        }

        return null;
    }

    /**
     * @param string[] $expectedFilenames
     * @return array<string, mixed>
     */
    public function ticketDocumentLinkDiagnostics(
        int $ticketId,
        int $expectedLinks = 1,
        array $expectedFilenames = []
    ): array {
        return $this->documentItemLinkDiagnostics('Ticket', $ticketId, $expectedLinks, $expectedFilenames);
    }

    /**
     * @param string[] $expectedFilenames
     * @return array<string, mixed>
     */
    public function documentItemLinkDiagnostics(
        string $itemtype,
        int $itemId,
        int $expectedLinks = 1,
        array $expectedFilenames = []
    ): array {
        $expectedLinks = max(0, $expectedLinks);
        $itemtype = trim($itemtype);
        if ($itemId <= 0 || $itemtype === '' || $expectedLinks <= 0) {
            return [
                'available' => true,
                'expected' => $expectedLinks,
                'linked' => 0,
                'matched' => 0,
                'document_ids' => [],
                'filenames' => [],
                'complete' => true,
                'reason' => 'not_required',
            ];
        }
        if (!class_exists('\Document_Item') || !class_exists('\Document')) {
            return [
                'available' => false,
                'expected' => $expectedLinks,
                'linked' => 0,
                'matched' => 0,
                'document_ids' => [],
                'filenames' => [],
                'complete' => false,
                'reason' => 'document_item_api_unavailable',
            ];
        }

        $document = new \Document();
        $documentIds = [];
        $filenames = [];
        $link = new \Document_Item();
        foreach ((array) $link->find(['itemtype' => $itemtype, 'items_id' => $itemId]) as $row) {
            $documentId = (int) (((array) $row)['documents_id'] ?? 0);
            if ($documentId <= 0 || in_array($documentId, $documentIds, true)) {
                continue;
            }
            if (!$document->getFromDB($documentId)) {
                continue;
            }
            $documentIds[] = $documentId;
            $filenames[] = basename((string) ($document->fields['filename'] ?? $document->fields['name'] ?? ''));
        }

        $expectedFilenames = array_values(array_filter(array_map(
            static fn(string $filename): string => basename(trim($filename)),
            array_map('strval', $expectedFilenames)
        )));
        $normalizedLinked = array_map(
            static fn(string $filename): string => mb_strtolower($filename, 'UTF-8'),
            $filenames
        );
        $linkedMultiplicity = array_count_values($normalizedLinked);
        $matched = 0;
        foreach ($expectedFilenames as $expectedFilename) {
            $normalizedExpected = mb_strtolower($expectedFilename, 'UTF-8');
            if (($linkedMultiplicity[$normalizedExpected] ?? 0) > 0) {
                $matched++;
                $linkedMultiplicity[$normalizedExpected]--;
            }
        }
        $complete = count($documentIds) >= $expectedLinks
            && (
                $expectedFilenames === []
                || $matched >= min($expectedLinks, count($expectedFilenames))
            );

        return [
            'available' => true,
            'expected' => $expectedLinks,
            'linked' => count($documentIds),
            'matched' => $matched,
            'document_ids' => $documentIds,
            'filenames' => $filenames,
            'complete' => $complete,
            'reason' => $complete ? 'confirmed' : 'document_item_link_missing',
        ];
    }
    public function ticketHasDocumentLinks(int $ticketId, int $minimumLinks = 1): bool
    {
        $diagnostics = $this->ticketDocumentLinkDiagnostics($ticketId, $minimumLinks);
        return $diagnostics['available'] && $diagnostics['complete'];
    }

    public function getTicketDocuments(int $ticketId): array
    {
        return $this->getReadableDocumentsForParent($ticketId, 'Ticket', $ticketId);
    }

    public function applyRequesterDecision(int $ticketId, int $decision, string $comment): bool
    {
        if (!$this->canReadTicket($ticketId)) {
            return false;
        }

        $decision = max(1, min(5, $decision));
        $comment = trim($comment);
        $userId = (int) ($_SESSION['glpiID'] ?? 0);

        $satisfaction = new \TicketSatisfaction();
        $existing = $satisfaction->find([
            'tickets_id' => max(1, $ticketId),
        ]);

        if (!$existing) {
            throw new \RuntimeException(I18n::translate('Não há pesquisa de satisfação gerada para este chamado.'));
        }

        $input = [
            'tickets_id' => max(1, $ticketId),
            'users_id' => $userId,
            'satisfaction' => $decision,
            'comment' => $comment,
            'date_answered' => date('Y-m-d H:i:s'),
        ];

        if ($existing) {
            $first = array_shift($existing);
            if (is_array($first) && isset($first['id'])) {
                $input['id'] = (int) $first['id'];
                $current = new \TicketSatisfaction();
                if ($current->getFromDB((int) $input['id']) && method_exists($current, 'canUpdateItem') && !$current->canUpdateItem()) {
                    throw new \RuntimeException(I18n::translate('Sem permissão para responder à pesquisa de satisfação.'));
                }

                return (bool) $satisfaction->update($input);
            }
        }

        return false;
    }

    public function getTicketTimeline(int $ticketId): array
    {
        if ($ticketId <= 0 || !$this->canReadTicket($ticketId)) {
            return [];
        }

        $events = [];

        if (class_exists('\ITILFollowup')) {
            $canViewPrivateFollowups = $this->canViewPrivateFollowups();
            $followupCriteria = ['itemtype' => 'Ticket', 'items_id' => $ticketId];
            if (!$canViewPrivateFollowups) {
                $followupCriteria['is_private'] = 0;
            }

            $followup = new \ITILFollowup();
            foreach ($followup->find($followupCriteria, 'date ASC') as $row) {
                $followupId = (int) ($row['id'] ?? 0);
                $isPrivate = !empty($row['is_private']) ? 1 : 0;
                if (
                    ($isPrivate === 1 && !$canViewPrivateFollowups)
                    || !$this->canReadTimelineItem(\ITILFollowup::class, $followupId, $isPrivate)
                ) {
                    continue;
                }

                $userId = (int) ($row['users_id'] ?? 0);
                $events[] = [
                    'id' => $followupId,
                    'type' => 'followup',
                    'date' => (string) ($row['date'] ?? ''),
                    'content' => (string) ($row['content'] ?? ''),
                    'users_id' => $userId,
                    'author_name' => $this->resolveUserName($userId),
                    'is_private' => $isPrivate,
                    'documents' => $this->getReadableDocumentsForParent(
                        $ticketId,
                        'ITILFollowup',
                        $followupId,
                        $isPrivate
                    ),
                ];
            }
        }

        if (class_exists('\TicketTask')) {
            $canViewPrivateTasks = $this->canViewPrivateTasks();
            $taskCriteria = ['tickets_id' => $ticketId];
            if (!$canViewPrivateTasks) {
                $taskCriteria['is_private'] = 0;
            }

            $task = new \TicketTask();
            foreach ($task->find($taskCriteria, 'date ASC') as $row) {
                $taskId = (int) ($row['id'] ?? 0);
                $isPrivate = !empty($row['is_private']) ? 1 : 0;
                if (
                    ($isPrivate === 1 && !$canViewPrivateTasks)
                    || !$this->canReadTimelineItem(\TicketTask::class, $taskId, $isPrivate)
                ) {
                    continue;
                }

                $userId = (int) ($row['users_id'] ?? $row['users_id_tech'] ?? 0);
                $events[] = [
                    'id' => $taskId,
                    'type' => 'task',
                    'date' => (string) ($row['date'] ?? ''),
                    'content' => (string) ($row['content'] ?? ''),
                    'users_id' => $userId,
                    'author_name' => $this->resolveUserName($userId),
                    'is_private' => $isPrivate,
                    'documents' => $this->getReadableDocumentsForParent(
                        $ticketId,
                        'TicketTask',
                        $taskId,
                        $isPrivate
                    ),
                ];
            }
        }

        if (class_exists('\ITILSolution')) {
            $solution = new \ITILSolution();
            foreach ($solution->find(['itemtype' => 'Ticket', 'items_id' => $ticketId], 'date_creation ASC') as $row) {
                $solutionId = (int) ($row['id'] ?? 0);
                if (!$this->canReadTimelineItem(\ITILSolution::class, $solutionId)) {
                    continue;
                }

                $userId = (int) ($row['users_id'] ?? 0);
                $events[] = [
                    'id' => $solutionId,
                    'type' => 'solution',
                    'date' => (string) ($row['date_creation'] ?? ''),
                    'content' => (string) ($row['content'] ?? ''),
                    'users_id' => $userId,
                    'author_name' => $this->resolveUserName($userId),
                ];
            }
        }

        usort($events, static fn(array $a, array $b): int => strcmp((string) $a['date'], (string) $b['date']));

        return $events;
    }

    /**
     * @return array<int, array<string, mixed>>
     */
    private function getReadableDocumentsForParent(
        int $ticketId,
        string $parentType,
        int $parentId,
        int $isPrivate = 0
    ): array {
        if (
            $ticketId <= 0
            || $parentId <= 0
            || !in_array($parentType, ['Ticket', 'ITILFollowup', 'TicketTask'], true)
            || !class_exists('\Document_Item')
            || !class_exists('\Document')
            || !$this->canReadTicket($ticketId)
            || !$this->canReadDocumentParent($ticketId, $parentType, $parentId, $isPrivate)
        ) {
            return [];
        }

        $documents = [];
        $seenDocumentIds = [];
        $link = new \Document_Item();
        foreach ((array) $link->find(['itemtype' => $parentType, 'items_id' => $parentId]) as $row) {
            $documentId = (int) (((array) $row)['documents_id'] ?? 0);
            if ($documentId <= 0 || isset($seenDocumentIds[$documentId])) {
                continue;
            }

            $document = new \Document();
            try {
                if (
                    !$document->getFromDB($documentId)
                    || !method_exists($document, 'canViewFile')
                    || !$document->canViewFile([
                        'itemtype' => $parentType,
                        'items_id' => $parentId,
                    ])
                ) {
                    continue;
                }
            } catch (\Throwable $e) {
                continue;
            }

            $seenDocumentIds[$documentId] = true;
            $filename = basename(trim((string) ($document->fields['filename'] ?? '')));
            $name = trim((string) ($document->fields['name'] ?? ''));
            $displayName = $filename !== '' ? $filename : $name;
            if ($displayName === '') {
                $displayName = sprintf('Documento #%d', $documentId);
            }

            $documents[] = [
                'id' => $documentId,
                'name' => $name,
                'filename' => $filename,
                'display_name' => $displayName,
                'mime' => trim((string) ($document->fields['mime'] ?? '')),
                'size' => max(0, (int) ($document->fields['filesize'] ?? 0)),
                'date_mod' => (string) ($document->fields['date_mod'] ?? ''),
                'parent_itemtype' => $parentType,
                'parent_id' => $parentId,
                'is_private' => $isPrivate === 1,
                'download_url' => $this->nativeDocumentDownloadUrl(
                    $documentId,
                    $ticketId,
                    $parentType,
                    $parentId
                ),
            ];
        }

        usort(
            $documents,
            static fn(array $left, array $right): int => strcmp(
                (string) ($right['date_mod'] ?? ''),
                (string) ($left['date_mod'] ?? '')
            )
        );

        return $documents;
    }

    private function canReadDocumentParent(
        int $ticketId,
        string $parentType,
        int $parentId,
        int $isPrivate
    ): bool {
        if ($parentType === 'Ticket') {
            return $parentId === $ticketId && $this->canReadTicket($ticketId);
        }

        if ($parentType === 'ITILFollowup') {
            if ($isPrivate === 1 && !$this->canViewPrivateFollowups()) {
                return false;
            }

            return $this->timelineParentBelongsToTicket(
                \ITILFollowup::class,
                $parentId,
                $ticketId,
                'items_id',
                $isPrivate,
                'itemtype'
            );
        }

        if ($parentType === 'TicketTask') {
            if ($isPrivate === 1 && !$this->canViewPrivateTasks()) {
                return false;
            }

            return $this->timelineParentBelongsToTicket(
                \TicketTask::class,
                $parentId,
                $ticketId,
                'tickets_id',
                $isPrivate
            );
        }

        return false;
    }

    private function timelineParentBelongsToTicket(
        string $itemClass,
        int $itemId,
        int $ticketId,
        string $ticketField,
        int $expectedPrivacy,
        string $itemtypeField = ''
    ): bool {
        if ($itemId <= 0 || !class_exists($itemClass)) {
            return false;
        }

        try {
            $item = new $itemClass();
            if (
                !method_exists($item, 'can')
                || !method_exists($item, 'getFromDB')
                || !$item->can($itemId, READ)
                || !$item->getFromDB($itemId)
                || (int) ($item->fields[$ticketField] ?? 0) !== $ticketId
                || (int) (!empty($item->fields['is_private'])) !== $expectedPrivacy
            ) {
                return false;
            }

            return $itemtypeField === ''
                || (string) ($item->fields[$itemtypeField] ?? '') === 'Ticket';
        } catch (\Throwable $e) {
            return false;
        }
    }

    private function nativeDocumentDownloadUrl(
        int $documentId,
        int $ticketId,
        string $parentType,
        int $parentId
    ): string {
        global $CFG_GLPI;

        $root = rtrim((string) ($CFG_GLPI['root_doc'] ?? ''), '/');
        $query = [
            'docid' => max(1, $documentId),
            'itemtype' => $parentType,
            'items_id' => max(1, $parentId),
        ];
        if ($parentType === 'Ticket') {
            $query['tickets_id'] = max(1, $ticketId);
        }

        return $root . '/front/document.send.php?' . http_build_query($query, '', '&', PHP_QUERY_RFC3986);
    }

    private function canReadTimelineItem(string $itemClass, int $itemId, int $isPrivate = 0): bool
    {
        if ($itemId <= 0 || !class_exists($itemClass)) {
            return false;
        }
        if ($isPrivate === 1) {
            if ($itemClass === \ITILFollowup::class && !$this->canViewPrivateFollowups()) {
                return false;
            }
            if ($itemClass === \TicketTask::class && !$this->canViewPrivateTasks()) {
                return false;
            }
        }

        try {
            $item = new $itemClass();
            return method_exists($item, 'can') && (bool) $item->can($itemId, READ);
        } catch (\Throwable $e) {
            return false;
        }
    }

    private function defaultTimelineItemPrivacy(string $itemClass, string $sessionKey): bool
    {
        if (class_exists($itemClass)) {
            try {
                $item = new $itemClass();
                if (method_exists($item, 'getEmpty')) {
                    $item->getEmpty();
                    if (isset($item->fields['is_private'])) {
                        return !empty($item->fields['is_private']);
                    }
                }
            } catch (\Throwable $e) {
                // Fall back to the native session preference used by GLPI 10 and 11.
            }
        }

        return !empty($_SESSION[$sessionKey]);
    }

    public function canAddPrivateFollowup(int $ticketId): bool
    {
        return $this->canAddFollowupToTicket($ticketId, 1);
    }

    public function canAddPrivateTask(int $ticketId): bool
    {
        return $this->canAddTaskToTicket($ticketId, 1);
    }

    private function canViewPrivateFollowups(): bool
    {
        return $this->hasTimelinePrivateRight('followup', [\ITILFollowup::class]);
    }

    private function canViewPrivateTasks(): bool
    {
        return $this->hasTimelinePrivateRight('task', [\TicketTask::class, '\CommonITILTask']);
    }

    /**
     * @param string[] $itemClasses
     */
    private function hasTimelinePrivateRight(string $rightName, array $itemClasses): bool
    {
        if (!class_exists('\Session') || !method_exists('\Session', 'haveRight')) {
            return false;
        }

        foreach ($itemClasses as $itemClass) {
            $constantName = ltrim($itemClass, '\\') . '::SEEPRIVATE';
            if (!defined($constantName)) {
                continue;
            }

            try {
                return (bool) \Session::haveRight($rightName, (int) constant($constantName));
            } catch (\Throwable $e) {
                return false;
            }
        }

        return false;
    }

    public function canReadTicketHistory(int $ticketId): bool
    {
        $ticketId = max(1, $ticketId);
        if (!$this->canReadTicket($ticketId)) {
            return false;
        }

        try {
            if (class_exists('\Log') && method_exists('\Log', 'canView') && (bool) \Log::canView()) {
                return true;
            }
        } catch (\Throwable $e) {
            return false;
        }

        if (class_exists('\Session') && method_exists('\Session', 'haveRight') && defined('READ')) {
            return (bool) \Session::haveRight('logs', READ)
                || (bool) \Session::haveRight('log', READ);
        }

        return false;
    }

    /**
     * @return array{can_view:bool,available:bool,limit:int,items:array<int,array<string,string|int>>}
     */
    public function getTicketHistoryContext(int $ticketId, int $limit = 50): array
    {
        $limit = min(100, max(10, $limit));
        $context = [
            'can_view' => $this->canReadTicketHistory($ticketId),
            'available' => false,
            'limit' => $limit,
            'items' => [],
        ];
        if (!$context['can_view']) {
            return $context;
        }

        $context['items'] = $this->getTicketHistory($ticketId, $limit);
        $context['available'] = class_exists('\Log') || $this->tableExists('glpi_logs');
        return $context;
    }

    /**
     * @return array<int, array<string, string|int>>
     */
    public function getTicketHistory(int $ticketId, int $limit = 50): array
    {
        $ticketId = max(1, $ticketId);
        $limit = min(100, max(10, $limit));
        if (!$this->canReadTicketHistory($ticketId)) {
            return [];
        }

        $fromNative = $this->getTicketHistoryFromNativeLog($ticketId, $limit);
        if ($fromNative !== []) {
            return $fromNative;
        }

        return $this->getTicketHistoryFromLogTable($ticketId, $limit);
    }

    /**
     * @return array<int, array<string, string|int>>
     */
    private function getTicketHistoryFromNativeLog(int $ticketId, int $limit): array
    {
        if (!class_exists('\Log') || !method_exists('\Log', 'getHistoryData') || !class_exists('\Ticket')) {
            return [];
        }

        try {
            $ticket = new \Ticket();
            if (!$ticket->getFromDB($ticketId)) {
                return [];
            }

            $data = \Log::getHistoryData($ticket, 0, $limit);
            if (!is_array($data)) {
                return [];
            }

            return $this->normalizeTicketHistoryRows($data, $limit);
        } catch (\Throwable $e) {
            return [];
        }
    }

    /**
     * @return array<int, array<string, string|int>>
     */
    private function getTicketHistoryFromLogTable(int $ticketId, int $limit): array
    {
        global $DB;
        if (!isset($DB) || !method_exists($DB, 'request') || !$this->tableExists('glpi_logs')) {
            return [];
        }

        $columns = $this->getTableColumns('glpi_logs');
        if ($columns === []) {
            return [];
        }

        try {
            $rows = $DB->request([
                'SELECT' => $columns,
                'FROM' => 'glpi_logs',
                'WHERE' => [
                    'itemtype' => 'Ticket',
                    'items_id' => $ticketId,
                ],
                'ORDER' => ['id DESC'],
                'LIMIT' => $limit,
            ]);
        } catch (\Throwable $e) {
            return [];
        }

        $history = [];
        foreach ($rows as $row) {
            $history[] = $this->normalizeTicketHistoryRow((array) $row);
        }

        return array_values(array_filter($history, static fn(array $row): bool => trim((string) ($row['summary'] ?? '')) !== ''));
    }

    /**
     * @param array<string, mixed> $data
     * @return array<int, array<string, string|int>>
     */
    private function normalizeTicketHistoryRows(array $data, int $limit): array
    {
        $candidateRows = $data['history'] ?? $data['data'] ?? $data['rows'] ?? $data;
        if (!is_array($candidateRows)) {
            return [];
        }

        $history = [];
        foreach ($candidateRows as $row) {
            if (!is_array($row)) {
                continue;
            }
            $normalized = $this->normalizeTicketHistoryRow($row);
            if (trim((string) ($normalized['summary'] ?? '')) === '') {
                continue;
            }
            $history[] = $normalized;
            if (count($history) >= $limit) {
                break;
            }
        }

        return $history;
    }

    /**
     * @param array<string, mixed> $row
     * @return array<string, string|int>
     */
    private function normalizeTicketHistoryRow(array $row): array
    {
        $id = (int) ($row['id'] ?? $row['logs_id'] ?? 0);
        $date = (string) ($row['date_mod'] ?? $row['date'] ?? $row['date_creation'] ?? '');
        $user = (string) ($row['user_name'] ?? $row['user'] ?? $row['username'] ?? '');
        $field = (string) ($row['field'] ?? $row['fieldname'] ?? $row['id_search_option'] ?? $row['itemtype_link'] ?? '');
        $action = (string) ($row['linked_action'] ?? $row['action'] ?? '');
        $summaryCandidates = [
            $row['change'] ?? null,
            $row['changes'] ?? null,
            $row['message'] ?? null,
            $row['display_history'] ?? null,
            $row['old_value'] ?? null,
            $row['new_value'] ?? null,
        ];
        $summaryParts = [];
        foreach ($summaryCandidates as $candidate) {
            if (is_array($candidate)) {
                $candidate = implode(' ', array_map(static fn($value): string => is_scalar($value) ? (string) $value : '', $candidate));
            }
            if (!is_scalar($candidate)) {
                continue;
            }
            $clean = $this->normalizeHistoryText((string) $candidate);
            if ($clean !== '' && !in_array($clean, $summaryParts, true)) {
                $summaryParts[] = $clean;
            }
        }

        $summary = implode(' -> ', $summaryParts);
        if ($summary === '' && $field !== '') {
            $summary = sprintf(
                I18n::translate('Alteração registrada em %s'),
                $this->normalizeHistoryText($field)
            );
        }

        return [
            'id' => $id,
            'date' => $this->normalizeHistoryText($date),
            'user' => $this->normalizeHistoryText($user),
            'field' => $this->normalizeHistoryText($field),
            'action' => $this->normalizeHistoryText($action),
            'summary' => $summary,
        ];
    }

    private function normalizeHistoryText(string $value): string
    {
        $value = html_entity_decode(strip_tags($value), ENT_QUOTES | ENT_HTML5, 'UTF-8');
        $value = preg_replace('/\s+/u', ' ', $value) ?? $value;
        return trim($value);
    }
    public function getCockpitMetrics(): array
    {
        $startedAt = hrtime(true);
        $timezone = $this->cockpitTimezone();
        $clock = new \DateTimeImmutable('now', $timezone);
        $generatedAt = $clock->format(DATE_ATOM);
        $definitions = $this->cockpitMetricDefinitions($clock);
        $definitionsDurationMs = $this->elapsedMilliseconds($startedAt);
        $countsStartedAt = hrtime(true);
        $metrics = [];

        foreach ($definitions as $key => $descriptor) {
            $metricStartedAt = hrtime(true);
            $definition = is_array($descriptor['definition'] ?? null)
                ? $descriptor['definition']
                : null;
            $result = $definition !== null
                ? $this->countTicketsFromSearchApi($definition)
                : $this->unknownCockpitCount('search_option_unavailable');
            $exact = ($result['completeness'] ?? 'unknown') === 'exact';
            $value = $exact && is_int($result['value'] ?? null)
                ? $result['value']
                : null;
            $metricDurationMs = $this->elapsedMilliseconds($metricStartedAt);
            $searchDurationMs = max(0, (int) ($result['query_duration_ms'] ?? 0));

            $metrics[$key] = [
                'value' => $value,
                'count' => $value,
                'available' => $exact,
                'completeness' => $exact ? 'exact' : 'unknown',
                'label' => (string) ($descriptor['label'] ?? $key),
                'period' => (string) ($descriptor['period'] ?? 'current'),
                'scope' => (string) ($descriptor['scope'] ?? 'allowed'),
                'generated_at' => $generatedAt,
                'data_as_of' => $generatedAt,
                'updated_at' => $generatedAt,
                'timezone' => $timezone->getName(),
                'drilldown_filters' => $definition ?? [],
                'url_definition' => $definition ?? [],
                'drilldown_url' => '',
                'url' => '',
                'backend' => $exact ? (string) ($result['backend'] ?? 'search_api') : 'unavailable',
                'error_code' => $exact ? '' : (string) ($result['error_code'] ?? 'search_total_unavailable'),
                'query_duration_ms' => $searchDurationMs,
                'duration_ms' => $metricDurationMs,
                // Scope resolution, criteria, manageParams and result mapping.
                // getDatas itself may execute multiple native SQL statements.
                'non_search_duration_ms' => max(0, $metricDurationMs - $searchDurationMs),
            ];
        }

        $allExact = $metrics !== [] && count(array_filter(
            $metrics,
            static fn(array $metric): bool => ($metric['completeness'] ?? 'unknown') === 'exact'
        )) === count($metrics);

        return $metrics + [
            'generated_at' => $generatedAt,
            'data_as_of' => $generatedAt,
            'updated_at' => $generatedAt,
            'timezone' => $timezone->getName(),
            'scope' => 'allowed',
            'scope_label' => 'Todos os chamados permitidos',
            'backend' => $allExact ? 'search_api' : 'unavailable',
            'stage_durations_ms' => [
                'definitions' => $definitionsDurationMs,
                'native_counts' => $this->elapsedMilliseconds($countsStartedAt),
                'repository_total' => $this->elapsedMilliseconds($startedAt),
            ],
        ];
    }

    /**
     * Build only server-owned definitions. The browser never supplies cockpit
     * criteria, Search Option identifiers, entity scope or participant IDs.
     *
     * @return array<string,array<string,mixed>>
     */
    private function cockpitMetricDefinitions(\DateTimeImmutable $clock): array
    {
        $today = $clock->format('Y-m-d');
        $dayStart = $clock->setTime(0, 0, 0);
        $dayLowerBound = $dayStart->modify('-1 second')->format('Y-m-d H:i:s');
        $dayUpperBound = $dayStart->modify('+1 day')->format('Y-m-d H:i:s');
        $statusOption = $this->getTicketSearchOptionNumber('status');
        $solvedDateOption = $this->getTicketSearchOptionNumber('solvedate');
        $openCriteria = $statusOption > 0
            ? $this->cockpitStatusCriteria($statusOption, [1, 2, 3, 4])
            : null;
        $pendingCriteria = $statusOption > 0
            ? $this->cockpitStatusCriteria($statusOption, [4])
            : null;
        $solvedTodayCriteria = $statusOption > 0 && $solvedDateOption > 0
            ? array_merge(
                $this->cockpitStatusCriteria($statusOption, [5]),
                [[
                    'link' => 'AND',
                    'field' => $solvedDateOption,
                    'searchtype' => 'morethan',
                    'value' => $dayLowerBound,
                ], [
                    'link' => 'AND',
                    'field' => $solvedDateOption,
                    'searchtype' => 'lessthan',
                    'value' => $dayUpperBound,
                ]]
            )
            : null;

        return [
            'total_open' => [
                'label' => 'Abertos',
                'period' => 'current',
                'scope' => 'allowed',
                'definition' => $openCriteria === null
                    ? null
                    : $this->cockpitSearchDefinition('all', $openCriteria),
            ],
            'pending' => [
                'label' => 'Pendentes',
                'period' => 'current',
                'scope' => 'allowed',
                'definition' => $pendingCriteria === null
                    ? null
                    : $this->cockpitSearchDefinition('all', $pendingCriteria),
            ],
            'solved_today' => [
                'label' => 'Solucionados hoje',
                'period' => $today,
                'scope' => 'allowed',
                'definition' => $solvedTodayCriteria === null
                    ? null
                    : $this->cockpitSearchDefinition('all', $solvedTodayCriteria),
            ],
            'mine_open' => [
                'label' => 'Meus abertos',
                'period' => 'current',
                'scope' => 'mine',
                'definition' => $openCriteria === null
                    ? null
                    : $this->cockpitSearchDefinition('mine', $openCriteria),
            ],
            'group_open' => [
                'label' => 'Grupo aberto',
                'period' => 'current',
                'scope' => 'group',
                'definition' => $openCriteria === null
                    ? null
                    : $this->cockpitSearchDefinition('group', $openCriteria),
            ],
        ];
    }

    /** @return array<int,array<string,mixed>> */
    private function cockpitStatusCriteria(int $statusOption, array $statuses): array
    {
        $alternatives = [];
        foreach (array_values(array_unique(array_map('intval', $statuses))) as $index => $status) {
            if ($status < 1) {
                continue;
            }
            $alternatives[] = [
                'link' => $index === 0 ? 'AND' : 'OR',
                'field' => $statusOption,
                'searchtype' => 'equals',
                'value' => (string) $status,
            ];
        }

        return $alternatives === [] ? [] : [[
            'link' => 'AND',
            'criteria' => $alternatives,
        ]];
    }

    /** @return array<string,mixed> */
    private function cockpitSearchDefinition(string $scope, array $criteria): array
    {
        return [
            'version' => NativeSearchDefinitionValidator::VERSION,
            'itemtype' => 'Ticket',
            'text' => '',
            'scope' => $scope,
            'criteria' => $criteria,
            'metacriteria' => [],
            'sort' => [],
            'order' => [],
            'is_deleted' => 0,
            'columns' => ['id', 'name'],
        ];
    }

    /**
     * Count the complete ACL-filtered Search API universe without hydrating
     * rows. Only an explicit native total is accepted as exact.
     *
     * @param array<string,mixed> $definition
     * @return array{value:?int,completeness:string,backend:string,error_code:string,query_duration_ms:int}
     */
    private function countTicketsFromSearchApi(array $definition): array
    {
        $filters = [
            'scope' => (string) ($definition['scope'] ?? 'all'),
            'q' => (string) ($definition['text'] ?? ''),
            'native_criteria' => (array) ($definition['criteria'] ?? []),
            'native_metacriteria' => (array) ($definition['metacriteria'] ?? []),
            'native_is_deleted' => (int) ($definition['is_deleted'] ?? 0),
        ];
        $groupScope = $this->currentUserGroupScopeResolution($filters);
        if ($groupScope['state'] === 'empty') {
            return [
                'value' => 0,
                'completeness' => 'exact',
                'backend' => 'scope_empty',
                'error_code' => '',
                'query_duration_ms' => 0,
            ];
        }
        if ($groupScope['state'] === 'unavailable') {
            return $this->unknownCockpitCount($groupScope['reason']);
        }
        if (!method_exists('\Search', 'getDatas') || !$this->canUseSearchApiForTicketList($filters)) {
            return $this->unknownCockpitCount($this->getSearchApiFallbackReason($filters));
        }

        $idOption = $this->getTicketSearchOptionNumber('id');
        if ($idOption <= 0) {
            return $this->unknownCockpitCount('search_option_unavailable');
        }

        $semanticCriteria = $this->buildTicketSearchCriteria($filters);
        if ($semanticCriteria === null) {
            return $this->unknownCockpitCount('scope_unavailable');
        }
        $statusCriterionCodec = new GlpiTicketStatusCriterionCodec();
        $criteria = $statusCriterionCodec->compileForGlpi(
            array_merge((array) $filters['native_criteria'], $semanticCriteria),
            \Ticket::class
        );
        $metacriteria = $statusCriterionCodec->compileForGlpi(
            (array) $filters['native_metacriteria'],
            \Ticket::class
        );
        $params = [
            'is_deleted' => (int) $filters['native_is_deleted'],
            'start' => 0,
            'list_limit' => 1,
            'criteria' => $criteria,
            'metacriteria' => $metacriteria,
            'reset' => 'reset',
        ];

        $duration = 0;
        try {
            if (method_exists('\Search', 'manageParams')) {
                $params = \Search::manageParams(\Ticket::class, $params, false, false);
                if (!is_array($params)) {
                    return $this->unknownCockpitCount('search_request_unavailable');
                }
            }

            $startedAt = hrtime(true);
            try {
                $data = \Search::getDatas(\Ticket::class, $params, [$idOption]);
            } finally {
                $duration = $this->elapsedMilliseconds($startedAt);
            }
            if (!is_array($data)) {
                return $this->unknownCockpitCount('search_response_unavailable', $duration);
            }
            $total = $this->extractExactSearchTotal($data);
            if ($total === null) {
                return $this->unknownCockpitCount('search_total_unavailable', $duration);
            }

            return [
                'value' => $total,
                'completeness' => 'exact',
                'backend' => 'search_api',
                'error_code' => '',
                'query_duration_ms' => $duration,
            ];
        } catch (\Throwable $e) {
            return $this->unknownCockpitCount('search_execution_failed', $duration);
        }
    }

    private function elapsedMilliseconds(float $startedAt): int
    {
        return max(0, (int) round((hrtime(true) - $startedAt) / 1_000_000));
    }

    private function extractExactSearchTotal(array $data): ?int
    {
        foreach ([['data', 'totalcount'], ['data', 'count']] as $path) {
            $value = $data[$path[0]][$path[1]] ?? null;
            if (is_numeric($value) && (int) $value >= 0) {
                return (int) $value;
            }
        }
        $value = $data['totalcount'] ?? null;
        return is_numeric($value) && (int) $value >= 0 ? (int) $value : null;
    }

    /** @return array{value:null,completeness:string,backend:string,error_code:string,query_duration_ms:int} */
    private function unknownCockpitCount(string $errorCode, int $duration = 0): array
    {
        return [
            'value' => null,
            'completeness' => 'unknown',
            'backend' => 'unavailable',
            'error_code' => $errorCode,
            'query_duration_ms' => max(0, $duration),
        ];
    }

    private function cockpitTimezone(): \DateTimeZone
    {
        global $CFG_GLPI;

        $candidates = [
            $_SESSION['glpitimezone'] ?? null,
            is_array($CFG_GLPI ?? null) ? ($CFG_GLPI['timezone'] ?? null) : null,
            date_default_timezone_get(),
            'UTC',
        ];
        foreach ($candidates as $candidate) {
            if (!is_string($candidate) || trim($candidate) === '') {
                continue;
            }
            try {
                return new \DateTimeZone(trim($candidate));
            } catch (\Throwable $e) {
                continue;
            }
        }

        return new \DateTimeZone('UTC');
    }

    public function getKnowledgeArticles(string $query = '', int $limit = 30): array
    {
        $result = $this->searchKnowledgeArticles([
            'query' => $query,
            'public_only' => true,
            'page' => 1,
            'page_size' => $limit,
        ]);

        return $result['items'] ?? [];
    }

    public function searchKnowledgeArticles(array $filters): array
    {
        $query = trim((string) ($filters['query'] ?? ''));
        $categoryId = max(0, (int) ($filters['category_id'] ?? 0));
        $publicOnly = (bool) ($filters['public_only'] ?? false);
        $page = max(1, (int) ($filters['page'] ?? 1));
        $pageSize = min(20, max(1, (int) ($filters['page_size'] ?? 10)));

        if ($query === '' && $categoryId === 0) {
            return [
                'items' => [],
                'total' => 0,
                'page' => $page,
                'page_size' => $pageSize,
                'pages' => 1,
            ];
        }

        $items = $this->fetchKnowledgeCandidates([
            'query' => $query,
            'category_id' => $categoryId,
            'public_only' => $publicOnly,
            'limit' => max(50, $pageSize * 12),
            'order' => 'updated',
        ]);

        if ($query !== '') {
            usort($items, function (array $left, array $right) use ($query): int {
                $scoreDiff = $this->scoreKnowledgeArticle($right, $query) <=> $this->scoreKnowledgeArticle($left, $query);
                if ($scoreDiff !== 0) {
                    return $scoreDiff;
                }

                return strcmp((string) ($right['date_mod'] ?? ''), (string) ($left['date_mod'] ?? ''));
            });
        }

        $total = count($items);
        $pages = max(1, (int) ceil(max(1, $total) / $pageSize));
        $page = min($page, $pages);
        $offset = ($page - 1) * $pageSize;

        return [
            'items' => array_slice($items, $offset, $pageSize),
            'total' => $total,
            'page' => $page,
            'page_size' => $pageSize,
            'pages' => $pages,
        ];
    }

    public function getKnowledgeHomeLists(bool $publicOnly, int $limit = 5): array
    {
        $limit = min(10, max(1, $limit));

        return [
            'recentes' => array_slice($this->fetchKnowledgeCandidates([
                'public_only' => $publicOnly,
                'limit' => $limit,
                'order' => 'recent',
            ]), 0, $limit),
            'atualizadas' => array_slice($this->fetchKnowledgeCandidates([
                'public_only' => $publicOnly,
                'limit' => $limit,
                'order' => 'updated',
            ]), 0, $limit),
            'populares' => array_slice($this->fetchKnowledgeCandidates([
                'public_only' => $publicOnly,
                'limit' => $limit,
                'order' => 'popular',
            ]), 0, $limit),
        ];
    }

    public function getKnowledgeCategories(bool $publicOnly, int $limit = 200): array
    {
        $items = $this->fetchKnowledgeCandidates([
            'public_only' => $publicOnly,
            'limit' => max(40, min(300, $limit)),
            'order' => 'updated',
        ]);

        $categories = [];
        foreach ($items as $item) {
            $categoryId = (int) ($item['category_id'] ?? 0);
            $label = trim((string) ($item['category'] ?? ''));
            if ($categoryId <= 0 || $label === '') {
                continue;
            }

            $categories[$categoryId] = [
                'id' => $categoryId,
                'label' => $label,
            ];
        }

        uasort($categories, static fn(array $left, array $right): int => strcasecmp($left['label'], $right['label']));

        return array_values($categories);
    }

    public function getKnowledgeArticle(int $articleId, bool $publicOnly = false): ?array
    {
        $articleId = max(1, $articleId);
        $kb = new \KnowbaseItem();
        if (!$kb->can($articleId, READ) || !$kb->getFromDB($articleId)) {
            return null;
        }

        $item = $this->mapKnowledgeItem($kb);
        if ($publicOnly) {
            $columns = $this->getTableColumns('glpi_knowbaseitems');
            if (in_array('is_faq', $columns, true) && empty($item['is_faq'])) {
                return null;
            }
        }

        return $item;
    }

    /**
     * Varredura controlada para gerar sugestoes de roteiro do chatbot.
     * Mantem os mesmos filtros nativos usados nas telas de KB e limita o volume
     * para evitar carga indevida em homologacao/producao.
     *
     * @return array<int, array<string, mixed>>
     */
    public function scanKnowledgeArticles(bool $publicOnly, int $limit = 80): array
    {
        return $this->fetchKnowledgeCandidates([
            'public_only' => $publicOnly,
            'limit' => min(200, max(10, $limit)),
            'order' => 'updated',
        ]);
    }

    /**
     * @return array<int, array<string, mixed>>
     */
    private function fetchKnowledgeCandidates(array $filters): array
    {
        $columns = $this->getTableColumns('glpi_knowbaseitems');
        if ($columns === [] || !class_exists('\KnowbaseItem')) {
            return [];
        }

        $query = trim((string) ($filters['query'] ?? ''));
        $categoryId = max(0, (int) ($filters['category_id'] ?? 0));
        $publicOnly = (bool) ($filters['public_only'] ?? false);
        $limit = min(250, max(1, (int) ($filters['limit'] ?? 20)));
        $order = (string) ($filters['order'] ?? 'updated');

        $criteria = [];

        if ($publicOnly && in_array('is_faq', $columns, true)) {
            $criteria['is_faq'] = 1;
        }
        if (in_array('is_deleted', $columns, true)) {
            $criteria['is_deleted'] = 0;
        }
        if ($categoryId > 0 && in_array('knowbaseitemcategories_id', $columns, true)) {
            $criteria['knowbaseitemcategories_id'] = $categoryId;
        }
        if ($query !== '') {
            $searchable = [];
            foreach (['name', 'question', 'answer'] as $field) {
                if (in_array($field, $columns, true)) {
                    $searchable[$field] = ['LIKE', '%' . $query . '%'];
                }
            }
            if ($searchable !== []) {
                $criteria['OR'] = $searchable;
            }
        }

        $orderClause = $this->getKnowledgeNativeOrder($columns, $order);
        $items = [];
        $seen = [];
        $maxScan = min(100, max($limit * 2, $limit));
        $kbFinder = new \KnowbaseItem();
        $rows = $kbFinder->find($criteria, $orderClause, $maxScan);

        foreach ((array) $rows as $row) {
            $id = (int) ($row['id'] ?? 0);
            if ($id <= 0 || isset($seen[$id])) {
                continue;
            }
            $seen[$id] = true;

            $kb = new \KnowbaseItem();
            if (!$kb->can($id, READ) || !$kb->getFromDB($id)) {
                continue;
            }

            $item = $this->mapKnowledgeItem($kb);
            if ($publicOnly && empty($item['is_faq']) && in_array('is_faq', $columns, true)) {
                continue;
            }
            if ($categoryId > 0 && (int) ($item['category_id'] ?? 0) !== $categoryId) {
                continue;
            }
            if ($query !== '' && !$this->knowledgeMatchesQuery($item, $query)) {
                continue;
            }

            $items[] = $item;
            if (count($items) >= $limit) {
                break;
            }
        }

        return $items;
    }

    private function getKnowledgeNativeOrder(array $columns, string $order): string
    {
        $dateCreationField = in_array('date_creation', $columns, true) ? 'date_creation' : 'id';
        $dateModField = in_array('date_mod', $columns, true) ? 'date_mod' : $dateCreationField;
        $popularityField = null;

        foreach (['view', 'views', 'visits', 'numviews'] as $field) {
            if (in_array($field, $columns, true)) {
                $popularityField = $field;
                break;
            }
        }

        return match ($order) {
            'recent' => $dateCreationField . ' DESC, id DESC',
            'popular' => ($popularityField ?? $dateModField) . ' DESC, ' . $dateModField . ' DESC',
            default => $dateModField . ' DESC, id DESC',
        };
    }

    private function getKnowledgeOrderClause(array $columns, string $order): string
    {
        $dateCreationField = in_array('date_creation', $columns, true) ? 'k.date_creation' : 'k.id';
        $dateModField = in_array('date_mod', $columns, true) ? 'k.date_mod' : $dateCreationField;
        $popularityField = null;

        foreach (['view', 'views', 'visits', 'numviews'] as $field) {
            if (in_array($field, $columns, true)) {
                $popularityField = 'k.' . $field;
                break;
            }
        }

        return match ($order) {
            'recent' => $dateCreationField . ' DESC, k.id DESC',
            'popular' => ($popularityField ?? $dateModField) . ' DESC, ' . $dateModField . ' DESC',
            default => $dateModField . ' DESC, k.id DESC',
        };
    }

    /**
     * @return array<string, mixed>
     */
    private function mapKnowledgeItem(\KnowbaseItem $kb): array
    {
        $fields = $kb->fields;
        $title = trim((string) ($fields['name'] ?? ''));
        if ($title === '') {
            $title = trim((string) ($fields['question'] ?? ''));
        }
        if ($title === '') {
            $title = 'Artigo #' . (int) ($fields['id'] ?? 0);
        }

        $questionHtml = $this->sanitizeKnowledgeHtml((string) ($fields['question'] ?? ''));
        $answerHtml = $this->sanitizeKnowledgeHtml((string) ($fields['answer'] ?? ''));
        $bodyHtml = $answerHtml !== '' ? $answerHtml : $questionHtml;
        $questionText = $this->toKnowledgePlainText($questionHtml);
        $answerText = $this->toKnowledgePlainText($answerHtml);
        $bodyText = $this->toKnowledgePlainText($bodyHtml);
        $summary = $bodyText;
        if (mb_strlen($summary) > 220) {
            $summary = rtrim(mb_substr($summary, 0, 217)) . '...';
        }

        $categoryId = (int) ($fields['knowbaseitemcategories_id'] ?? 0);
        $associated = $this->getKnowledgeAssociatedElements((int) ($fields['id'] ?? 0));

        return [
            'id' => (int) ($fields['id'] ?? 0),
            'assunto' => $title,
            'question' => $questionText,
            'answer' => $answerText,
            'question_html' => $questionHtml,
            'answer_html' => $answerHtml,
            'summary' => $summary,
            'body' => $bodyText,
            'body_html' => $bodyHtml,
            'category_id' => $categoryId,
            'category' => $this->resolveKnowledgeCategoryName($categoryId),
            'associados' => $associated,
            'date_creation' => (string) ($fields['date_creation'] ?? ''),
            'date_mod' => (string) ($fields['date_mod'] ?? ''),
            'is_faq' => !empty($fields['is_faq']),
            'popularity' => (int) ($fields['view'] ?? $fields['views'] ?? $fields['visits'] ?? $fields['numviews'] ?? 0),
        ];
    }

    private function resolveKnowledgeCategoryName(int $categoryId): string
    {
        if ($categoryId <= 0) {
            return 'Sem categoria';
        }

        if (class_exists('\Dropdown') && method_exists('\Dropdown', 'getDropdownName')) {
            $label = TextNormalizer::fromGlpi((string) \Dropdown::getDropdownName('glpi_knowbaseitemcategories', $categoryId));
            if ($label !== '') {
                return $label;
            }
        }

        if (class_exists('\KnowbaseItemCategory')) {
            $category = new \KnowbaseItemCategory();
            if ($category->getFromDB($categoryId)) {
                return TextNormalizer::fromGlpi((string) ($category->fields['completename'] ?? $category->fields['name'] ?? ('Categoria ' . $categoryId)));
            }
        }

        return 'Categoria ' . $categoryId;
    }

    private function getKnowledgeAssociatedElements(int $articleId): string
    {
        global $DB;

        if ($articleId <= 0 || !$this->tableExists('glpi_items_knowbaseitems')) {
            return I18n::translate('Não informado');
        }

        $counts = [];
        foreach (
            $DB->request([
            'SELECT' => ['itemtype'],
            'FROM' => 'glpi_items_knowbaseitems',
            'WHERE' => ['knowbaseitems_id' => $articleId],
            ]) as $row
        ) {
            $itemtype = (string) ($row['itemtype'] ?? '');
            if ($itemtype === '') {
                continue;
            }
            $counts[$itemtype] = ($counts[$itemtype] ?? 0) + 1;
        }

        arsort($counts);

        $items = [];
        foreach (array_slice($counts, 0, 3, true) as $itemtype => $total) {
            $label = $this->resolveItemTypeLabel((string) $itemtype, (int) $total);
            if ($label !== '') {
                $items[] = $label;
            }
        }

        return $items === [] ? I18n::translate('Não informado') : implode(', ', $items);
    }

    private function resolveItemTypeLabel(string $itemtype, int $count): string
    {
        $itemtype = trim($itemtype);
        if ($itemtype === '') {
            return '';
        }

        if (class_exists($itemtype) && method_exists($itemtype, 'getTypeName')) {
            $label = (string) $itemtype::getTypeName($count);
            if ($label !== '') {
                return $label;
            }
        }

        $short = str_contains($itemtype, '\\') ? substr($itemtype, (int) strrpos($itemtype, '\\') + 1) : $itemtype;
        $short = preg_replace('/(?<!^)([A-Z])/', ' $1', $short) ?? $short;
        return trim($short);
    }

    private function knowledgeMatchesQuery(array $item, string $query): bool
    {
        $needle = $this->normalizeSearchText($query);
        if ($needle === '') {
            return true;
        }

        foreach ([$item['assunto'] ?? '', $item['summary'] ?? '', $item['body'] ?? '', $item['category'] ?? ''] as $haystack) {
            if (str_contains($this->normalizeSearchText((string) $haystack), $needle)) {
                return true;
            }
        }

        return false;
    }

    private function scoreKnowledgeArticle(array $item, string $query): int
    {
        $terms = array_values(array_filter(preg_split('/\s+/u', $this->normalizeSearchText($query)) ?: []));
        if ($terms === []) {
            return 0;
        }

        $title = $this->normalizeSearchText((string) ($item['assunto'] ?? ''));
        $summary = $this->normalizeSearchText((string) ($item['summary'] ?? ''));
        $body = $this->normalizeSearchText((string) ($item['body'] ?? ''));
        $category = $this->normalizeSearchText((string) ($item['category'] ?? ''));

        $score = 0;
        foreach ($terms as $term) {
            if ($term === '') {
                continue;
            }
            if (str_contains($title, $term)) {
                $score += 6;
            }
            if (str_contains($summary, $term)) {
                $score += 4;
            }
            if (str_contains($body, $term)) {
                $score += 2;
            }
            if (str_contains($category, $term)) {
                $score += 1;
            }
        }

        return $score;
    }

    private function normalizeSearchText(string $value): string
    {
        $value = mb_strtolower($value, 'UTF-8');
        $converted = iconv('UTF-8', 'ASCII//TRANSLIT//IGNORE', $value);
        if ($converted !== false) {
            $value = $converted;
        }

        return trim(preg_replace('/\s+/', ' ', $value) ?? $value);
    }

    private function sanitizeKnowledgeHtml(string $value): string
    {
        $value = html_entity_decode($value, ENT_QUOTES | ENT_HTML5, 'UTF-8');

        $safeHtml = $this->sanitizeHtmlWithGlpiCore($value);
        if ($safeHtml !== null) {
            return $this->normalizeKnowledgeHeadingHierarchy(
                $this->normalizeKnowledgeMediaHtml($safeHtml)
            );
        }

        $value = preg_replace('#<script(.*?)>(.*?)</script>#is', '', $value) ?? $value;
        $value = preg_replace('#<style(.*?)>(.*?)</style>#is', '', $value) ?? $value;
        $value = preg_replace('/\s+on[a-z]+\s*=\s*"[^"]*"/i', '', $value) ?? $value;
        $value = preg_replace("/\s+on[a-z]+\s*=\s*'[^']*'/i", '', $value) ?? $value;
        $value = preg_replace('/\s+on[a-z]+\s*=\s*[^\s>]+/i', '', $value) ?? $value;
        $value = preg_replace('/\s+style\s*=\s*"[^"]*"/i', '', $value) ?? $value;
        $value = preg_replace("/\s+style\s*=\s*'[^']*'/i", '', $value) ?? $value;
        $value = preg_replace('/\s+style\s*=\s*[^\s>]+/i', '', $value) ?? $value;
        $value = preg_replace('/\s+class\s*=\s*"[^"]*"/i', '', $value) ?? $value;
        $value = preg_replace("/\s+class\s*=\s*'[^']*'/i", '', $value) ?? $value;
        $value = preg_replace('/\s+class\s*=\s*[^\s>]+/i', '', $value) ?? $value;
        $value = preg_replace('/href\s*=\s*"javascript:[^"]*"/i', 'href="#"', $value) ?? $value;
        $value = preg_replace("/href\s*=\s*'javascript:[^']*'/i", 'href="#"', $value) ?? $value;

        $allowed = '<p><br><strong><b><em><i><u><ul><ol><li><a><h1><h2><h3><h4><h5><h6><blockquote><code><pre><img><figure><figcaption><table><thead><tbody><tfoot><tr><th><td>';
        $clean = strip_tags($value, $allowed);
        $clean = $this->normalizeKnowledgeMediaHtml($clean);
        $clean = $this->normalizeKnowledgeHeadingHierarchy($clean);
        $clean = preg_replace("/\r\n?/", "\n", $clean) ?? $clean;
        return trim($clean);
    }

    private function sanitizeHtmlWithGlpiCore(string $value): ?string
    {
        if (class_exists('\Glpi\RichText\RichText') && is_callable(['\Glpi\RichText\RichText', 'getSafeHtml'])) {
            return trim((string) \Glpi\RichText\RichText::getSafeHtml($value));
        }

        if (class_exists('\Html') && is_callable(['\Html', 'clean'])) {
            return trim((string) \Html::clean($value));
        }

        return null;
    }

    private function normalizeKnowledgeMediaHtml(string $value): string
    {
        $value = $this->rewriteKnowledgeUrlAttributes($value, 'src');
        $value = $this->rewriteKnowledgeUrlAttributes($value, 'href');
        $value = preg_replace('/<img\b(?![^>]*\balt=)/i', '<img alt="Imagem do artigo"', $value) ?? $value;
        $value = preg_replace('/<img\b(?![^>]*\bloading=)/i', '<img loading="lazy"', $value) ?? $value;
        $value = preg_replace('/<img\b(?![^>]*\bdecoding=)/i', '<img decoding="async"', $value) ?? $value;
        $value = preg_replace('/<a\b(?![^>]*\brel=)/i', '<a rel="noopener noreferrer"', $value) ?? $value;

        return $value;
    }

    private function normalizeKnowledgeHeadingHierarchy(string $value): string
    {
        if (trim($value) === '' || !class_exists(\DOMDocument::class)) {
            return $value;
        }

        $previousErrorSetting = libxml_use_internal_errors(true);
        try {
            $document = new \DOMDocument('1.0', 'UTF-8');
            $loaded = $document->loadHTML(
                '<?xml encoding="UTF-8"><div data-glpiacessivel-kb-root="1">' . $value . '</div>',
                LIBXML_HTML_NOIMPLIED | LIBXML_HTML_NODEFDTD
            );
            $root = $document->documentElement;
            if (!$loaded || !$root instanceof \DOMElement) {
                return $value;
            }

            $xpath = new \DOMXPath($document);
            $headingNodes = $xpath->query(
                './/*[self::h1 or self::h2 or self::h3 or self::h4 or self::h5 or self::h6]',
                $root
            );
            if ($headingNodes === false || $headingNodes->length === 0) {
                return $value;
            }

            $headings = [];
            foreach ($headingNodes as $headingNode) {
                if ($headingNode instanceof \DOMElement) {
                    $headings[] = $headingNode;
                }
            }

            $baseOriginalLevel = null;
            $previousLevel = 3;
            foreach ($headings as $heading) {
                $originalLevel = (int) substr(strtolower($heading->tagName), 1);
                $baseOriginalLevel ??= $originalLevel;
                $normalizedLevel = 4 + $originalLevel - $baseOriginalLevel;
                $normalizedLevel = max(4, min(6, $normalizedLevel));
                $normalizedLevel = min($normalizedLevel, $previousLevel + 1);

                $replacement = $document->createElement('h' . $normalizedLevel);
                foreach ($heading->attributes as $attribute) {
                    $replacement->setAttribute($attribute->nodeName, $attribute->nodeValue);
                }
                while ($heading->firstChild !== null) {
                    $replacement->appendChild($heading->firstChild);
                }
                $heading->parentNode?->replaceChild($replacement, $heading);
                $previousLevel = $normalizedLevel;
            }

            $normalized = '';
            foreach ($root->childNodes as $childNode) {
                $serialized = $document->saveHTML($childNode);
                if (!is_string($serialized)) {
                    return $value;
                }
                $normalized .= $serialized;
            }

            return $normalized;
        } catch (\Throwable) {
            return $value;
        } finally {
            libxml_clear_errors();
            libxml_use_internal_errors($previousErrorSetting);
        }
    }

    private function rewriteKnowledgeUrlAttributes(string $value, string $attribute): string
    {
        return preg_replace_callback(
            '/\s' . preg_quote($attribute, '/') . '\s*=\s*(["\'])(.*?)\1/i',
            function (array $matches) use ($attribute): string {
                $url = html_entity_decode((string) ($matches[2] ?? ''), ENT_QUOTES | ENT_HTML5, 'UTF-8');
                $safeUrl = $this->normalizeKnowledgeAssetUrl($url, $attribute === 'src');
                if ($safeUrl === '') {
                    return $attribute === 'href' ? ' href="#"' : '';
                }

                return ' ' . $attribute . '="' . htmlspecialchars($safeUrl, ENT_QUOTES, 'UTF-8') . '"';
            },
            $value
        ) ?? $value;
    }

    private function normalizeKnowledgeAssetUrl(string $url, bool $isImage): string
    {
        global $CFG_GLPI;

        $url = trim($url);
        if ($url === '') {
            return '';
        }

        $decoded = html_entity_decode($url, ENT_QUOTES | ENT_HTML5, 'UTF-8');
        if (preg_match('/^\s*(javascript|vbscript):/i', $decoded)) {
            return '';
        }

        if ($isImage && preg_match('#^data:image/(png|gif|jpe?g|webp);base64,[a-z0-9+/=\s]+$#i', $decoded)) {
            return preg_replace('/\s+/', '', $decoded) ?? $decoded;
        }

        if (preg_match('#^https?://#i', $decoded)) {
            return $decoded;
        }

        $root = rtrim((string) ($CFG_GLPI['root_doc'] ?? ''), '/');
        if ($root === '') {
            $root = '';
        }

        if (str_starts_with($decoded, '/')) {
            return $root !== '' && !str_starts_with($decoded, $root . '/') ? $root . $decoded : $decoded;
        }

        $trimmedRelative = preg_replace('#^(\./|\.\./)+#', '', $decoded) ?? $decoded;
        if (str_starts_with($trimmedRelative, 'front/') || str_starts_with($trimmedRelative, 'ajax/') || str_starts_with($trimmedRelative, 'plugins/')) {
            return $root . '/' . $trimmedRelative;
        }

        if (str_starts_with($decoded, 'front/') || str_starts_with($decoded, 'ajax/') || str_starts_with($decoded, 'plugins/')) {
            return $root . '/' . $decoded;
        }

        if (str_starts_with($decoded, './')) {
            return $root . '/' . ltrim(substr($decoded, 2), '/');
        }

        return $isImage ? '' : $decoded;
    }

    private function toKnowledgePlainText(string $value): string
    {
        $value = str_replace(
            ['<br>', '<br/>', '<br />', '</p>', '</div>', '</li>', '<li>'],
            ["\n", "\n", "\n", "\n\n", "\n\n", "\n", "- "],
            $value
        );
        $value = html_entity_decode(strip_tags($value), ENT_QUOTES | ENT_HTML5, 'UTF-8');
        $value = preg_replace("/\r\n?/", "\n", $value) ?? $value;
        $value = preg_replace("/\n{3,}/", "\n\n", $value) ?? $value;
        $value = preg_replace('/[ \t]+/', ' ', $value) ?? $value;
        return trim($value);
    }

    /**
     * @return string[]
     */
    private function getTableColumns(string $table): array
    {
        global $DB;

        $knownColumns = [
            'glpi_tickets' => [
                'id', 'name', 'content', 'status', 'type', 'urgency', 'impact', 'priority',
                'entities_id', 'itilcategories_id', 'locations_id', 'requesttypes_id',
                'users_id_recipient', 'externalid', 'date', 'date_mod', 'date_creation',
                'time_to_resolve', 'is_deleted',
            ],
            'glpi_knowbaseitems' => [
                'id', 'name', 'answer', 'is_faq', 'is_recursive', 'view',
                'knowbaseitemcategories_id', 'date_mod', 'date_creation',
            ],
            'glpi_users' => ['id', 'name', 'firstname', 'realname', 'is_deleted', 'is_active'],
            'glpi_groups' => [
                'id', 'name', 'completename', 'is_deleted', 'is_active',
                'entities_id', 'is_recursive', 'is_assign', 'is_watcher',
            ],
            'glpi_entities' => ['id', 'name', 'completename'],
            'glpi_itilcategories' => [
                'id', 'name', 'completename', 'is_deleted', 'is_active',
                'entities_id', 'is_recursive', 'is_incident', 'is_request',
            ],
            'glpi_locations' => [
                'id', 'name', 'completename', 'is_deleted', 'is_active',
                'entities_id', 'is_recursive',
            ],
            'glpi_requesttypes' => ['id', 'name', 'is_active'],
            'glpi_taskcategories' => ['id', 'name', 'completename', 'is_deleted', 'is_active', 'entities_id', 'is_recursive'],
            'glpi_logs' => [
                'id', 'itemtype', 'items_id', 'itemtype_link', 'linked_action',
                'id_search_option', 'user_name', 'date_mod', 'old_value', 'new_value',
            ],
        ];

        $columns = $knownColumns[$table] ?? [];
        if ($columns === [] || !method_exists($DB, 'fieldExists')) {
            return $columns;
        }

        return array_values(array_filter(
            $columns,
            static fn(string $column): bool => (bool) $DB->fieldExists($table, $column)
        ));
    }

    private function columnExists(string $table, string $column): bool
    {
        global $DB;

        if (method_exists($DB, 'fieldExists')) {
            return (bool) $DB->fieldExists($table, $column);
        }

        return in_array($column, $this->getTableColumns($table), true);
    }

    private function ticketColumnExists(string $column): bool
    {
        return $this->columnExists('glpi_tickets', $column);
    }

    private function tableExists(string $table): bool
    {
        global $DB;

        if (method_exists($DB, 'tableExists')) {
            return (bool) $DB->tableExists($table);
        }

        return in_array($table, [
            'glpi_tickets',
            'glpi_knowbaseitems',
            'glpi_items_knowbaseitems',
            'glpi_users',
            'glpi_groups',
            'glpi_entities',
            'glpi_itilcategories',
            'glpi_locations',
            'glpi_tickets_users',
            'glpi_groups_tickets',
            'glpi_requesttypes',
            'glpi_taskcategories',
            'glpi_solutiontemplates',
            'glpi_solutiontypes',
            'glpi_logs',
        ], true);
    }

    /**
     * @return array<int, array{id:int,name:string,is_private:int,requesttypes_id:int}>
     */
    public function getFollowupTemplatesForTicket(int $ticketId): array
    {
        if (!$this->canReadTicket($ticketId) || !class_exists('\ITILFollowupTemplate')) {
            return [];
        }

        $template = new \ITILFollowupTemplate();
        $table = \ITILFollowupTemplate::getTable();
        if (!$this->tableExists($table)) {
            return [];
        }

        $criteria = [];
        if ($this->columnExists($table, 'is_active')) {
            $criteria['is_active'] = 1;
        }

        $ticket = new \Ticket();
        if (!$ticket->getFromDB(max(1, $ticketId))) {
            return [];
        }

        $templates = [];
        foreach ($template->find($criteria, 'name ASC', 200) as $row) {
            $templateId = (int) ($row['id'] ?? 0);
            $name = trim((string) ($row['name'] ?? ''));
            if ($templateId <= 0 || $name === '') {
                continue;
            }

            $entityId = (int) ($row['entities_id'] ?? 0);
            $recursive = (bool) ($row['is_recursive'] ?? false);
            $targetEntityId = (int) ($ticket->fields['entities_id'] ?? 0);
            if (!$this->canUseTemplateEntity($entityId, $recursive, $targetEntityId)) {
                continue;
            }

            $loaded = new \ITILFollowupTemplate();
            if (!$loaded->getFromDB($templateId) || !$this->canReadTemplateItem($loaded, $templateId)) {
                continue;
            }
            if (!empty($loaded->fields['is_private']) && !$this->canAddPrivateFollowup($ticketId)) {
                continue;
            }

            $templates[] = [
                'id' => $templateId,
                'name' => $name,
                'is_private' => (int) ($loaded->fields['is_private'] ?? 0),
                'requesttypes_id' => (int) ($loaded->fields['requesttypes_id'] ?? 0),
            ];
        }

        return $templates;
    }

    public function renderFollowupTemplateContent(int $ticketId, int $templateId): string
    {
        if ($templateId <= 0 || !$this->canReadTicket($ticketId) || !class_exists('\ITILFollowupTemplate')) {
            return '';
        }

        $ticket = new \Ticket();
        $template = new \ITILFollowupTemplate();
        if (
            !$ticket->getFromDB(max(1, $ticketId))
            || !$template->getFromDB($templateId)
            || !$this->canReadTemplateItem($template, $templateId)
        ) {
            return '';
        }

        $entityId = (int) ($template->fields['entities_id'] ?? 0);
        $recursive = !empty($template->fields['is_recursive']);
        $targetEntityId = (int) ($ticket->fields['entities_id'] ?? 0);
        if (!$this->canUseTemplateEntity($entityId, $recursive, $targetEntityId)) {
            return '';
        }

        return $this->renderFollowupTemplateContentFromItem($template, $ticket);
    }

    /** @return array{text:string,is_private:int,requesttypes_id:int,lossy:bool} */
    public function renderFollowupTemplatePlainText(int $ticketId, int $templateId): array
    {
        if (!$this->canUseFollowupTemplateForTicket($ticketId, $templateId)) {
            throw new \RuntimeException('followup_template_not_available');
        }

        $template = new \ITILFollowupTemplate();
        $ticket = new \Ticket();
        if (!$template->getFromDB($templateId) || !$ticket->getFromDB(max(1, $ticketId))) {
            throw new \RuntimeException('followup_template_not_available');
        }

        $converted = (new RichTextToPlainText())->convert(
            $this->renderFollowupTemplateContentFromItem($template, $ticket)
        );

        return [
            'text' => $converted['text'],
            'lossy' => $converted['lossy'],
            'is_private' => !empty($template->fields['is_private']) ? 1 : 0,
            'requesttypes_id' => max(0, (int) ($template->fields['requesttypes_id'] ?? 0)),
        ];
    }

    /** @return array<int, array{id:int,name:string,is_private:int}> */
    public function getTaskTemplatesForTicket(int $ticketId): array
    {
        if (!$this->canReadTicket($ticketId) || !class_exists('\TaskTemplate')) {
            return [];
        }

        $prototype = new \TaskTemplate();
        $table = \TaskTemplate::getTable();
        if (!$this->tableExists($table)) {
            return [];
        }

        $ticket = new \Ticket();
        if (!$ticket->getFromDB(max(1, $ticketId))) {
            return [];
        }

        $criteria = [];
        if ($this->columnExists($table, 'is_active')) {
            $criteria['is_active'] = 1;
        }
        $templates = [];
        foreach ($prototype->find($criteria, 'name ASC', 200) as $row) {
            $templateId = (int) ($row['id'] ?? 0);
            $name = trim((string) ($row['name'] ?? ''));
            if ($templateId <= 0 || $name === '') {
                continue;
            }
            $loaded = new \TaskTemplate();
            if (
                !$loaded->getFromDB($templateId)
                || ($this->resolveLoadedTaskTemplateForTicketDetailed(
                    $ticket,
                    $loaded,
                    $ticketId,
                    $templateId,
                    false
                )['result'] ?? null) === null
            ) {
                continue;
            }
            $templates[] = [
                'id' => $templateId,
                'name' => $name,
                'is_private' => !empty($loaded->fields['is_private']) ? 1 : 0,
            ];
        }

        return $templates;
    }

    /**
     * @return array{
     *   text:string,lossy:bool,is_private:int,taskcategories_id:int,state:int,
     *   actiontime:int,users_id_tech:int,groups_id_tech:int,pendingreasons_id:int
     * }|null
     */
    public function resolveTaskTemplateForTicket(int $ticketId, int $templateId): ?array
    {
        return $this->resolveTaskTemplateForTicketDetailed($ticketId, $templateId, true)['result'];
    }

    /**
     * Canonical TaskTemplate resolver shared by catalog, preview and mutation.
     * The reason is intended for audit logs only and must not expose template
     * content or record names to the browser.
     *
     * @return array{result:?array<string,mixed>,reason:string}
     */
    public function resolveTaskTemplateForTicketDetailed(
        int $ticketId,
        int $templateId,
        bool $render = true
    ): array {
        if ($ticketId <= 0 || $templateId <= 0 || !class_exists('\TaskTemplate')) {
            return ['result' => null, 'reason' => 'invalid_identifier'];
        }
        if (!$this->canReadTicket($ticketId)) {
            return ['result' => null, 'reason' => 'ticket_read'];
        }

        $ticket = new \Ticket();
        $template = new \TaskTemplate();
        if (!$ticket->getFromDB($ticketId)) {
            return ['result' => null, 'reason' => 'ticket_load'];
        }
        if (!$template->getFromDB($templateId)) {
            return ['result' => null, 'reason' => 'template_load'];
        }

        return $this->resolveLoadedTaskTemplateForTicketDetailed(
            $ticket,
            $template,
            $ticketId,
            $templateId,
            $render
        );
    }

    /**
     * Evaluate an already loaded ticket/template pair. Catalog construction
     * uses this path to avoid loading the same ticket and template repeatedly.
     *
     * @return array{result:?array<string,mixed>,reason:string}
     */
    private function resolveLoadedTaskTemplateForTicketDetailed(
        \Ticket $ticket,
        \TaskTemplate $template,
        int $ticketId,
        int $templateId,
        bool $render
    ): array {
        if (!$this->canReadTemplateItem($template, $templateId)) {
            return ['result' => null, 'reason' => 'template_read'];
        }
        $ticketEntityId = (int) ($ticket->fields['entities_id'] ?? -1);
        if (
            $ticketEntityId < 0
            || !$this->canUseTemplateEntity(
                (int) ($template->fields['entities_id'] ?? 0),
                !empty($template->fields['is_recursive']),
                $ticketEntityId
            )
        ) {
            return ['result' => null, 'reason' => 'entity'];
        }
        if (!empty($template->fields['is_private']) && !$this->canAddPrivateTask($ticketId)) {
            return ['result' => null, 'reason' => 'privacy'];
        }

        $technicianId = (int) ($template->fields['users_id_tech'] ?? 0);
        if ($technicianId === -1 || !empty($template->fields['use_current_user'])) {
            $technicianId = (int) ($_SESSION['glpiID'] ?? 0);
        }
        $categoryId = max(0, (int) ($template->fields['taskcategories_id'] ?? 0));
        $state = max(0, (int) ($template->fields['state'] ?? 0));
        $duration = max(0, (int) ($template->fields['actiontime'] ?? 0));
        $groupId = max(0, (int) ($template->fields['groups_id_tech'] ?? 0));
        $pendingReasonId = max(0, (int) ($template->fields['pendingreasons_id'] ?? 0));

        if ($categoryId > 0 && !$this->taskCategoryIdIsEligible($categoryId, $ticketEntityId)) {
            return ['result' => null, 'reason' => 'category'];
        }
        if (!$this->optionListContains($this->getTaskStateOptions(), $state)) {
            return ['result' => null, 'reason' => 'state'];
        }
        if ($duration > 2678400) {
            return ['result' => null, 'reason' => 'duration'];
        }
        if ($technicianId > 0 && !$this->taskTechnicianIdIsEligible($technicianId, $ticketEntityId)) {
            return ['result' => null, 'reason' => 'technician'];
        }
        if ($groupId > 0 && !$this->exactActorGroupIdsAreEligible([$groupId], 'is_task', $ticketEntityId)) {
            return ['result' => null, 'reason' => 'group'];
        }
        if ($pendingReasonId > 0) {
            return ['result' => null, 'reason' => 'pending_reason_requires_native'];
        }

        $converted = ['text' => '', 'lossy' => false];
        if ($render) {
            if (!method_exists($template, 'getRenderedContent')) {
                return ['result' => null, 'reason' => 'render_unsupported'];
            }
            try {
                $renderedContent = (string) $template->getRenderedContent($ticket);
                $converted = (new RichTextToPlainText())->convert($renderedContent);
            } catch (\Throwable) {
                return ['result' => null, 'reason' => 'render'];
            }
            if ($this->containsUnresolvedTemplateMarker($converted['text'])) {
                return ['result' => null, 'reason' => 'unresolved_marker'];
            }
        }

        return ['result' => [
            'text' => $converted['text'],
            'lossy' => $converted['lossy'],
            'is_private' => !empty($template->fields['is_private']) ? 1 : 0,
            'taskcategories_id' => $categoryId,
            'state' => $state,
            'actiontime' => $duration,
            'users_id_tech' => max(0, $technicianId),
            'groups_id_tech' => $groupId,
            'pendingreasons_id' => $pendingReasonId,
        ], 'reason' => 'ready'];
    }

    private function taskCategoryIdIsEligible(int $categoryId, int $ticketEntityId): bool
    {
        if ($categoryId <= 0 || !class_exists('\TaskCategory')) {
            return false;
        }
        try {
            $category = new \TaskCategory();
            return $category->getFromDB($categoryId)
                && $this->canUseTemplateEntity(
                    (int) ($category->fields['entities_id'] ?? 0),
                    !empty($category->fields['is_recursive']),
                    $ticketEntityId
                );
        } catch (\Throwable) {
            return false;
        }
    }

    private function taskTechnicianIdIsEligible(int $userId, int $ticketEntityId): bool
    {
        if ($userId <= 0 || !$this->isActiveUserInEntity($userId, $ticketEntityId)) {
            return false;
        }
        if ($userId === (int) ($_SESSION['glpiID'] ?? 0)) {
            return true;
        }
        return class_exists('\Profile')
            && method_exists('\Profile', 'haveUserRight')
            && defined('\Ticket::OWN')
            && \Profile::haveUserRight($userId, 'ticket', \Ticket::OWN, $ticketEntityId);
    }

    /** @return array<int, array{id:int,name:string,solutiontypes_id:int}> */
    public function getSolutionTemplatesForTicket(int $ticketId): array
    {
        if (
            !$this->canReadTicket($ticketId)
            || !$this->canAddSolutionToTicket($ticketId)
            || !class_exists('\SolutionTemplate')
        ) {
            return [];
        }

        $prototype = new \SolutionTemplate();
        $table = \SolutionTemplate::getTable();
        if (!$this->tableExists($table)) {
            return [];
        }

        $ticket = new \Ticket();
        if (!$ticket->getFromDB(max(1, $ticketId))) {
            return [];
        }

        $criteria = [];
        if ($this->columnExists($table, 'is_active')) {
            $criteria['is_active'] = 1;
        }
        $solutionTypes = $this->getSolutionTypesForTicket($ticketId);
        $templates = [];
        foreach ($prototype->find($criteria, 'name ASC', 200) as $row) {
            $templateId = (int) ($row['id'] ?? 0);
            $name = trim((string) ($row['name'] ?? ''));
            if ($templateId <= 0 || $name === '') {
                continue;
            }

            $loaded = new \SolutionTemplate();
            if (
                !$loaded->getFromDB($templateId)
                || !$this->canReadSolutionTemplate($loaded, $templateId)
                || !$this->canUseTemplateEntity(
                    (int) ($loaded->fields['entities_id'] ?? 0),
                    !empty($loaded->fields['is_recursive']),
                    (int) ($ticket->fields['entities_id'] ?? 0)
                )
            ) {
                continue;
            }

            $solutionTypeId = max(0, (int) ($loaded->fields['solutiontypes_id'] ?? 0));
            if (
                $solutionTypeId > 0
                && !$this->optionListContains($solutionTypes, $solutionTypeId)
            ) {
                continue;
            }

            $templates[] = [
                'id' => $templateId,
                'name' => $name,
                'solutiontypes_id' => $solutionTypeId,
            ];
        }

        return $templates;
    }

    /** @return array<int, array{id:int,label:string}> */
    public function getSolutionTypesForTicket(int $ticketId): array
    {
        if (
            !$this->canReadTicket($ticketId)
            || !$this->canAddSolutionToTicket($ticketId)
            || !class_exists('\SolutionType')
        ) {
            return [];
        }

        $ticket = new \Ticket();
        $prototype = new \SolutionType();
        $table = \SolutionType::getTable();
        if (!$this->tableExists($table) || !$ticket->getFromDB(max(1, $ticketId))) {
            return [];
        }

        $criteria = [];
        if ($this->columnExists($table, 'is_active')) {
            $criteria['is_active'] = 1;
        }
        $incidentType = defined('\Ticket::INCIDENT_TYPE') ? (int) constant('\Ticket::INCIDENT_TYPE') : 1;
        $applicabilityField = (int) ($ticket->fields['type'] ?? 0) === $incidentType
            ? 'is_incident'
            : 'is_request';
        if ($this->columnExists($table, $applicabilityField)) {
            $criteria[$applicabilityField] = 1;
        }

        $targetEntityId = (int) ($ticket->fields['entities_id'] ?? 0);
        $options = [];
        foreach ($prototype->find($criteria, 'name ASC', 200) as $row) {
            $typeId = (int) ($row['id'] ?? 0);
            $label = trim((string) ($row['name'] ?? ''));
            if (
                $typeId <= 0
                || $label === ''
                || !$this->canUseTemplateEntity(
                    (int) ($row['entities_id'] ?? 0),
                    !empty($row['is_recursive']),
                    $targetEntityId
                )
            ) {
                continue;
            }
            $options[] = ['id' => $typeId, 'label' => $label];
        }

        return $options;
    }

    /** @return array{text:string,lossy:bool,solutiontypes_id:int}|null */
    public function resolveSolutionTemplateForTicket(int $ticketId, int $templateId): ?array
    {
        if (
            $templateId <= 0
            || !$this->canReadTicket($ticketId)
            || !$this->canAddSolutionToTicket($ticketId)
            || !class_exists('\SolutionTemplate')
        ) {
            return null;
        }

        $ticket = new \Ticket();
        $template = new \SolutionTemplate();
        if (
            !$ticket->getFromDB(max(1, $ticketId))
            || !$template->getFromDB($templateId)
            || !$this->canReadSolutionTemplate($template, $templateId)
            || !$this->canUseTemplateEntity(
                (int) ($template->fields['entities_id'] ?? 0),
                !empty($template->fields['is_recursive']),
                (int) ($ticket->fields['entities_id'] ?? 0)
            )
        ) {
            return null;
        }

        $solutionTypeId = max(0, (int) ($template->fields['solutiontypes_id'] ?? 0));
        if (
            $solutionTypeId > 0
            && !$this->optionListContains($this->getSolutionTypesForTicket($ticketId), $solutionTypeId)
        ) {
            return null;
        }

        if (!method_exists($template, 'getRenderedContent')) {
            return null;
        }
        try {
            $converted = (new RichTextToPlainText())->convert(
                (string) $template->getRenderedContent($ticket)
            );
        } catch (\Throwable) {
            return null;
        }
        if ($this->containsUnresolvedTemplateMarker($converted['text'])) {
            return null;
        }

        return [
            'text' => $converted['text'],
            'lossy' => $converted['lossy'],
            'solutiontypes_id' => $solutionTypeId,
        ];
    }

    private function canReadSolutionTemplate(object $template, int $templateId): bool
    {
        if (!method_exists($template, 'can') || !defined('READ')) {
            return false;
        }

        try {
            return (bool) $template->can($templateId, constant('READ'));
        } catch (\Throwable) {
            return false;
        }
    }

    private function canReadTemplateItem(object $template, int $templateId): bool
    {
        if (!method_exists($template, 'can') || !defined('READ')) {
            return false;
        }

        try {
            return (bool) $template->can($templateId, constant('READ'));
        } catch (\Throwable) {
            return false;
        }
    }

    /** @param array<int,array{id:int,label:string}> $options */
    private function optionListContains(array $options, int $expectedId): bool
    {
        foreach ($options as $option) {
            if ((int) ($option['id'] ?? 0) === $expectedId) {
                return true;
            }
        }
        return false;
    }

    private function containsUnresolvedTemplateMarker(string $text): bool
    {
        return preg_match('/(?:\{\{|\{%|\{#)/u', $text) === 1;
    }

    private function canUseFollowupTemplateForTicket(int $ticketId, int $templateId): bool
    {
        if ($templateId <= 0 || !$this->canReadTicket($ticketId) || !class_exists('\ITILFollowupTemplate')) {
            return false;
        }

        $ticket = new \Ticket();
        $template = new \ITILFollowupTemplate();
        if (
            !$ticket->getFromDB(max(1, $ticketId))
            || !$template->getFromDB($templateId)
            || !$this->canReadTemplateItem($template, $templateId)
        ) {
            return false;
        }
        if (!empty($template->fields['is_private']) && !$this->canAddPrivateFollowup($ticketId)) {
            return false;
        }

        return $this->canUseTemplateEntity(
            (int) ($template->fields['entities_id'] ?? 0),
            !empty($template->fields['is_recursive']),
            (int) ($ticket->fields['entities_id'] ?? 0)
        );
    }

    private function renderFollowupTemplateContentFromItem(\ITILFollowupTemplate $template, \Ticket $ticket): string
    {
        if (method_exists($template, 'getRenderedContent')) {
            return (string) $template->getRenderedContent($ticket);
        }

        return (string) ($template->fields['content'] ?? '');
    }

    private function canUseTemplateEntity(int $entityId, bool $recursive, ?int $targetEntityId = null): bool
    {
        if (class_exists('\Session') && method_exists('\Session', 'haveAccessToEntity')) {
            if (!(bool) \Session::haveAccessToEntity($entityId, $recursive)) {
                return false;
            }
        } elseif (!in_array($entityId, $this->getCurrentEntities(), true)) {
            return false;
        }

        $targetEntityId = $targetEntityId ?? (int) ($_SESSION['glpiactive_entity'] ?? 0);
        if ($targetEntityId === $entityId) {
            return true;
        }
        if (!$recursive || !function_exists('getSonsOf')) {
            return false;
        }

        $descendants = array_map('intval', (array) getSonsOf('glpi_entities', $entityId));
        return in_array($targetEntityId, $descendants, true);
    }

    public function resolveFollowupPrivacy(
        int $ticketId,
        int $followupTemplateId,
        int $requestedPrivacy
    ): int {
        $isPrivate = $requestedPrivacy === 1 ? 1 : 0;
        if (
            $ticketId <= 0
            || $followupTemplateId <= 0
            || !class_exists('\ITILFollowupTemplate')
            || !$this->canUseFollowupTemplateForTicket($ticketId, $followupTemplateId)
        ) {
            return $isPrivate;
        }

        try {
            $template = new \ITILFollowupTemplate();
            if ($template->getFromDB($followupTemplateId) && !empty($template->fields['is_private'])) {
                return 1;
            }
        } catch (\Throwable $e) {
            return $isPrivate;
        }

        return $isPrivate;
    }

    public function addFollowup(
        int $ticketId,
        string $content,
        array $filesPayload = [],
        int $followupTemplateId = 0,
        int $isPrivate = 0
    ): int {
        $isPrivate = $this->resolveFollowupPrivacy($ticketId, $followupTemplateId, $isPrivate);
        if (!$this->canAddFollowupToTicket($ticketId, $isPrivate)) {
            return 0;
        }

        $payload = [
            'itemtype' => 'Ticket',
            'items_id' => $ticketId,
            'content' => $content,
            'users_id' => (int) ($_SESSION['glpiID'] ?? 0),
            'is_private' => $isPrivate,
        ];

        if ($followupTemplateId > 0 && class_exists('\ITILFollowupTemplate')) {
            if (!$this->canUseFollowupTemplateForTicket($ticketId, $followupTemplateId)) {
                return 0;
            }

            $rendered = $this->renderFollowupTemplatePlainText($ticketId, $followupTemplateId)['text'];
            $payload['_itilfollowuptemplates_id'] = $followupTemplateId;
            $template = new \ITILFollowupTemplate();
            if (!$template->getFromDB($followupTemplateId)) {
                return 0;
            }
            if (!empty($template->fields['is_private'])) {
                $payload['is_private'] = 1;
            }
            if (trim($content) === '') {
                $payload['content'] = $rendered;
            }
        }

        if (trim((string) $payload['content']) === '') {
            return 0;
        }

        foreach (['_filename', '_tag_filename', '_prefix_filename'] as $key) {
            if (!empty($filesPayload[$key]) && is_array($filesPayload[$key])) {
                $payload[$key] = array_values($filesPayload[$key]);
            }
        }

        $followup = new \ITILFollowup();
        return (int) $followup->add($payload);
    }

    public function addTask(
        int $ticketId,
        string $content,
        array $taskInput = [],
        array $filesPayload = [],
        int $taskTemplateId = 0
    ): int {
        $isPrivate = !empty($taskInput['is_private']) ? 1 : 0;
        if (!$this->canAddTaskToTicket($ticketId, $isPrivate)) {
            return 0;
        }

        $state = array_key_exists('state', $taskInput)
            ? (int) $taskInput['state']
            : $this->getDefaultTaskState();
        if (!$this->optionListContains($this->getTaskStateOptions(), $state)) {
            return 0;
        }

        $taskInput['is_private'] = $isPrivate;
        $currentUserId = (int) ($_SESSION['glpiID'] ?? 0);
        $payload = [
            'tickets_id' => $ticketId,
            'content' => $content,
            'users_id_tech' => max(0, (int) ($taskInput['users_id_tech'] ?? $currentUserId)),
            'state' => $state,
            'actiontime' => max(0, (int) ($taskInput['actiontime'] ?? 0)),
        ];

        if ($taskTemplateId > 0) {
            if ($this->resolveTaskTemplateForTicket($ticketId, $taskTemplateId) === null) {
                return 0;
            }
            $payload['_tasktemplates_id'] = $taskTemplateId;
        }

        if ($this->columnExists('glpi_tickettasks', 'users_id')) {
            $payload['users_id'] = $currentUserId;
        }
        if ($this->columnExists('glpi_tickettasks', 'groups_id_tech')) {
            $payload['groups_id_tech'] = max(0, (int) ($taskInput['groups_id_tech'] ?? 0));
        }
        if ($this->columnExists('glpi_tickettasks', 'taskcategories_id')) {
            $payload['taskcategories_id'] = max(0, (int) ($taskInput['taskcategories_id'] ?? 0));
        }
        if ($this->columnExists('glpi_tickettasks', 'is_private')) {
            $payload['is_private'] = !empty($taskInput['is_private']) ? 1 : 0;
        }

        $begin = $this->normalizeDateTime((string) ($taskInput['begin'] ?? ''));
        $end = $this->normalizeDateTime((string) ($taskInput['end'] ?? ''));
        if ($begin !== '' && $end === '' && $payload['actiontime'] > 0) {
            $end = date('Y-m-d H:i:s', strtotime($begin) + (int) $payload['actiontime']);
        }
        if ($begin !== '' && $this->columnExists('glpi_tickettasks', 'begin')) {
            $payload['begin'] = $begin;
        }
        if ($end !== '' && $this->columnExists('glpi_tickettasks', 'end')) {
            $payload['end'] = $end;
        }
        if ($begin !== '' && $end !== '') {
            $payload['plan'] = ['begin' => $begin, 'end' => $end];
        }

        foreach (['_filename', '_tag_filename', '_prefix_filename'] as $key) {
            if (!empty($filesPayload[$key]) && is_array($filesPayload[$key])) {
                $payload[$key] = array_values($filesPayload[$key]);
            }
        }

        $task = new \TicketTask();
        return (int) $task->add($payload);
    }

    public function addSolution(
        int $ticketId,
        string $content,
        int $solutionTemplateId = 0,
        ?int $solutionTypeId = null
    ): int|false {
        $this->lastSolutionErrors = [];
        if ($ticketId <= 0) {
            $this->lastSolutionErrors = [$this->solutionError(
                'solution',
                'invalid_ticket',
                I18n::translate('Chamado inválido. Reabra o chamado e tente novamente.')
            )];
            return false;
        }

        $solutionTypeId = $solutionTypeId !== null && $solutionTypeId > 0
            ? $solutionTypeId
            : null;

        if ($solutionTemplateId > 0 && $this->resolveSolutionTemplateForTicket($ticketId, $solutionTemplateId) === null) {
            $this->lastSolutionErrors = [$this->solutionError(
                'solutiontemplates_id',
                'invalid_solution_template',
                I18n::translate('Modelo de solução inválido para este chamado, perfil ou entidade.')
            )];
            return false;
        }
        if (
            $solutionTypeId !== null
            && $solutionTypeId > 0
            && !$this->optionListContains($this->getSolutionTypesForTicket($ticketId), $solutionTypeId)
        ) {
            $this->lastSolutionErrors = [$this->solutionError(
                'solutiontypes_id',
                'invalid_solution_type',
                I18n::translate('Tipo de solução inválido para este chamado ou entidade.')
            )];
            return false;
        }

        $solution = new \ITILSolution();
        $payload = [
            'itemtype' => 'Ticket',
            'items_id' => $ticketId,
            'content' => $content,
            'users_id' => (int) ($_SESSION['glpiID'] ?? 0),
        ];
        if ($solutionTemplateId > 0) {
            $payload['_solutiontemplates_id'] = $solutionTemplateId;
        }
        if ($solutionTypeId !== null) {
            $payload['solutiontypes_id'] = $solutionTypeId;
        }

        $ticket = new \Ticket();
        if (!$ticket->getFromDB($ticketId)) {
            $this->lastSolutionErrors = [$this->solutionError(
                'solution',
                'ticket_unavailable',
                I18n::translate('Chamado não encontrado ou sem acesso.')
            )];
            return false;
        }

        if (!$this->passesNativeSolutionTicketGate($ticket, false)) {
            $this->lastSolutionErrors = [$this->solutionError(
                'solution',
                'native_solution_permission_denied',
                I18n::translate('Sem permissão para adicionar solução neste chamado.')
            )];
            return false;
        }

        $operationState = $this->getSolutionOperationState($ticketId);
        if (($operationState['state'] ?? '') !== 'ready') {
            $this->lastSolutionErrors = [$this->solutionError(
                'solution',
                ($operationState['state'] ?? '') === 'partial'
                    ? 'solution_outcome_partial'
                    : 'solution_operation_unavailable',
                ($operationState['state'] ?? '') === 'partial'
                    ? I18n::translate('Uma solução desta tentativa já foi registrada, mas o status do chamado ainda não foi confirmado. Não envie novamente; atualize e verifique o estado.')
                    : I18n::translate('Não foi possível confirmar o estado da operação de solução. Atualize o chamado antes de tentar novamente.')
            )];
            return false;
        }

        $preconditionErrors = $this->solutionPreconditionErrorsForTicket($ticket);
        if ($preconditionErrors !== []) {
            $this->lastSolutionErrors = $preconditionErrors;
            return false;
        }

        if (!$this->checkNativeSolutionCreate($ticket, $payload)) {
            $this->lastSolutionErrors = [$this->solutionError(
                'solution',
                'native_solution_permission_denied',
                I18n::translate('Sem permissão para adicionar solução neste chamado.')
            )];
            return false;
        }

        // Exactly one native add. An uncertain readback is handled by the
        // application layer and must never result in an automatic retry.
        $messagesBefore = $this->solutionMessageStrings();
        try {
            $nativeResult = $solution->add($payload);
        } catch (\Throwable $e) {
            throw new SolutionMutationOutcomeUncertainException(0, $e);
        }
        $solutionId = is_int($nativeResult) && $nativeResult > 0 ? $nativeResult : 0;

        if ($solutionId <= 0) {
            $nativeMessages = $this->newSolutionMessageStrings($messagesBefore);
            $this->lastSolutionErrors = $this->solutionErrorsFromNativeMessages($nativeMessages);
            if ($this->lastSolutionErrors === []) {
                $this->lastSolutionErrors = [$this->solutionError(
                    'solution',
                    'native_solution_rejected',
                    I18n::translate('Não foi possível registrar a solução no GLPI. Atualize o chamado antes de tentar novamente.')
                )];
            }
        }

        return $solutionId > 0 ? $solutionId : false;
    }

    /**
     * Reserve the request, lock the native ticket row, execute one native add
     * and commit only when both the solution row and the native status change
     * are observable. No Ticket::update() is performed by the plugin.
     *
     * @return array{
     *   status:string,
     *   result_id:int,
     *   outcome?:array<string,mixed>,
     *   replayed?:bool
     * }
     */
    public function addSolutionIdempotently(
        IdempotencyLedger $ledger,
        string $idempotencyKey,
        string $requestHash,
        int $ticketId,
        string $content,
        int $solutionTemplateId = 0,
        ?int $solutionTypeId = null
    ): array {
        global $DB;
        if (
            !isset($DB)
            || !method_exists($DB, 'beginTransaction')
            || !method_exists($DB, 'commit')
            || !method_exists($DB, 'rollBack')
        ) {
            throw new \RuntimeException('solution_idempotency_database_unavailable');
        }

        $scope = 'ticket.solution:' . $ticketId;
        if ($ledger->latestPartial($scope) !== null) {
            return ['status' => IdempotencyClaim::IN_PROGRESS, 'result_id' => 0];
        }
        $guard = $ledger->acquirePartialGuard(
            $scope,
            hash('sha256', 'ticket.solution.guard:' . $ticketId),
            $requestHash
        );
        if (!$guard->isAcquired()) {
            return ['status' => $guard->status(), 'result_id' => 0];
        }

        // The marker is committed before the native mutation. Other sessions
        // see it as partial; only this repository instance may ignore its own
        // exact guard while holding the native ticket row lock.
        $this->activeSolutionGuardKeyHash = $guard->keyHash();
        $transactionStarted = false;
        $mutationStarted = false;
        $solutionId = 0;
        try {
            if ($DB->beginTransaction() === false) {
                throw new \RuntimeException('solution_idempotency_transaction_failed');
            }
            $transactionStarted = true;
            $claim = $ledger->reserve(
                $scope,
                $idempotencyKey,
                $requestHash
            );
            if ($claim->isReplay()) {
                if ($DB->commit() === false) {
                    throw new \RuntimeException('solution_idempotency_replay_commit_failed');
                }
                $transactionStarted = false;
                $markerCleared = $this->releaseSolutionPartialGuard($ledger, $guard);
                return [
                    'status' => IdempotencyClaim::REPLAY,
                    'result_id' => max(0, (int) $claim->resultId()),
                    'replayed' => true,
                    'marker_cleared' => $markerCleared,
                ];
            }
            if (!$claim->isAcquired()) {
                if ($DB->rollBack() === false) {
                    throw new \RuntimeException('solution_idempotency_conflict_rollback_failed');
                }
                $transactionStarted = false;
                return [
                    'status' => $claim->status(),
                    'result_id' => 0,
                    'marker_cleared' => $this->releaseSolutionPartialGuard($ledger, $guard),
                ];
            }
            if (!$this->lockTicketForRouting($ticketId)) {
                throw new \RuntimeException('solution_ticket_lock_failed');
            }

            $operation = $this->getSolutionOperationState($ticketId);
            if (($operation['state'] ?? '') !== 'ready') {
                throw new \RuntimeException('solution_operation_not_ready');
            }

            $mutationStarted = true;
            $created = $this->addSolution(
                $ticketId,
                $content,
                $solutionTemplateId,
                $solutionTypeId
            );
            if (!is_int($created) || $created <= 0) {
                if (!$ledger->release($claim) || $DB->commit() === false) {
                    throw new \RuntimeException('solution_idempotency_rejection_finalize_failed');
                }
                $transactionStarted = false;
                return [
                    'status' => 'rejected',
                    'result_id' => 0,
                    'marker_cleared' => $this->releaseSolutionPartialGuard($ledger, $guard),
                ];
            }
            $solutionId = $created;

            $outcome = $this->verifySolutionOutcome(
                $solutionId,
                $ticketId,
                $solutionTypeId,
                (int) ($_SESSION['glpiID'] ?? 0)
            );
            if (!$this->isVerifiedSolutionOutcome($outcome)) {
                throw new SolutionMutationOutcomeUncertainException($solutionId);
            }
            if (!$ledger->complete($claim, $solutionId)) {
                throw new SolutionMutationOutcomeUncertainException($solutionId);
            }
            if ($DB->commit() === false) {
                throw new SolutionMutationOutcomeUncertainException($solutionId);
            }
            $transactionStarted = false;
            $markerCleared = $this->releaseSolutionPartialGuard($ledger, $guard);
            return [
                'status' => IdempotencyClaim::ACQUIRED,
                'result_id' => $solutionId,
                'outcome' => $outcome,
                'replayed' => false,
                'marker_cleared' => $markerCleared,
            ];
        } catch (\Throwable $e) {
            $rolledBack = false;
            if ($transactionStarted) {
                try {
                    $rolledBack = $DB->rollBack() !== false;
                } catch (\Throwable) {
                    $rolledBack = false;
                }
            }

            if ($mutationStarted) {
                $afterRollback = $solutionId > 0
                    ? $this->verifySolutionOutcome(
                        $solutionId,
                        $ticketId,
                        $solutionTypeId,
                        (int) ($_SESSION['glpiID'] ?? 0)
                    )
                    : [];
                if (!$rolledBack || !empty($afterRollback['persisted'])) {
                    // The durable guard predates the mutation. Updating its
                    // diagnostic ID is best-effort; failure cannot remove the
                    // already-persisted cross-session block.
                    try {
                        $ledger->updatePartialGuard($guard, $solutionId);
                    } catch (\Throwable) {
                        // Keep the original zero-ID guard as the safe block.
                    }
                    throw new SolutionMutationOutcomeUncertainException($solutionId, $e, true);
                }
                $markerCleared = $this->releaseSolutionPartialGuard($ledger, $guard);
                $this->lastSolutionErrors = [$this->solutionError(
                    'solution',
                    'solution_native_outcome_rolled_back',
                    I18n::translate('O GLPI não confirmou a conclusão da solução. A gravação foi desfeita com segurança; revise o chamado antes de tentar novamente.')
                )];
                return [
                    'status' => 'rejected',
                    'result_id' => 0,
                    'marker_cleared' => $markerCleared,
                ];
            }

            $this->releaseSolutionPartialGuard($ledger, $guard);
            throw $e;
        } finally {
            $this->activeSolutionGuardKeyHash = null;
        }
    }

    /** @param array<string,mixed> $outcome */
    private function isVerifiedSolutionOutcome(array $outcome): bool
    {
        return !empty($outcome['persisted'])
            && !empty($outcome['type_confirmed'])
            && !empty($outcome['author_confirmed'])
            && !empty($outcome['ticket_readable'])
            && !empty($outcome['status_confirmed']);
    }

    private function releaseSolutionPartialGuard(
        IdempotencyLedger $ledger,
        IdempotencyClaim $guard
    ): bool {
        try {
            return $ledger->releasePartialGuard($guard);
        } catch (\Throwable) {
            // Cleanup never changes the already-established native outcome.
            // A stale durable guard is fail-closed and can be reconciled later.
            return false;
        }
    }

    /**
     * Validate native ticket-template requirements without attempting an
     * ITILSolution mutation. The service invokes this immediately before the
     * single native add, so a missing field can be returned as a form error.
     *
     * @return array<int, array{field:string,code:string,message:string}>
     */
    public function validateSolutionPreconditions(int $ticketId): array
    {
        if ($ticketId <= 0 || !class_exists('\Ticket')) {
            return [$this->solutionError(
                'solution',
                'invalid_ticket',
                I18n::translate('Chamado inválido. Reabra o chamado e tente novamente.')
            )];
        }

        try {
            $ticket = new \Ticket();
            if (!$ticket->getFromDB($ticketId)) {
                return [$this->solutionError(
                    'solution',
                    'ticket_unavailable',
                    I18n::translate('Chamado não encontrado ou sem acesso.')
                )];
            }

            if (!$this->passesNativeSolutionTicketGate($ticket, false)) {
                return [$this->solutionError(
                    'solution',
                    'native_solution_permission_denied',
                    I18n::translate('Sem permissão para adicionar solução neste chamado.')
                )];
            }

            return $this->solutionPreconditionErrorsForTicket($ticket);
        } catch (\Throwable) {
            return [$this->solutionError(
                'solution',
                'solution_precondition_unavailable',
                I18n::translate('Não foi possível concluir a ação. Revise os dados e tente novamente.')
            )];
        }
    }

    /** @return array<int, array{field:string,code:string,message:string}> */
    public function getLastSolutionErrors(): array
    {
        return $this->lastSolutionErrors;
    }

    private function passesNativeSolutionTicketGate(object $ticket, bool $checkRequiredFields): bool
    {
        if (
            !class_exists('\\Ticket')
            || !method_exists('\\Ticket', 'canUpdate')
            || !\Ticket::canUpdate()
            || !method_exists($ticket, 'canSolve')
            || !$ticket->canSolve()
        ) {
            return false;
        }

        $fields = is_array($ticket->fields ?? null) ? $ticket->fields : [];
        $status = (int) ($fields['status'] ?? 0);
        if ($status <= 0 || in_array($status, [$this->solvedStatus(), $this->closedStatus()], true)) {
            return false;
        }

        // GLPI 11 uses this extra predicate in its native timeline. GLPI 10
        // does not expose the method, so method_exists preserves compatibility.
        if ($checkRequiredFields && method_exists($ticket, 'checkRequiredFieldsFilled')) {
            try {
                return (bool) $ticket->checkRequiredFieldsFilled();
            } catch (\Throwable) {
                return false;
            }
        }

        return true;
    }

    /** @param array<string,mixed> $payload */
    private function checkNativeSolutionCreate(object $ticket, array &$payload): bool
    {
        if (!$this->passesNativeSolutionTicketGate($ticket, true)) {
            return false;
        }

        try {
            $solution = new \ITILSolution();
            $solution->input = $payload;
            $solution->fields = $payload;
            if (!method_exists($solution, 'can') || !$solution->can(-1, CREATE, $payload)) {
                return false;
            }

            // On both GLPI 10 and 11 CommonDBTM::check delegates to can().
            // Calling it only after the non-blocking predicate avoids exposing
            // GLPI 10's native access-error page while preserving core checks.
            if (method_exists($solution, 'check')) {
                $solution->check(-1, CREATE, $payload);
            }

            return true;
        } catch (\Throwable) {
            return false;
        }
    }

    /** @return array<int, array{field:string,code:string,message:string}> */
    private function solutionPreconditionErrorsForTicket(object $ticket): array
    {
        $fields = is_array($ticket->fields ?? null) ? $ticket->fields : [];
        $mandatory = [];
        $templateResolved = false;

        if (method_exists($ticket, 'getITILTemplateToUse')) {
            try {
                $method = new \ReflectionMethod($ticket, 'getITILTemplateToUse');
                if ($method->isPublic()) {
                    $arguments = [];
                    foreach ($method->getParameters() as $position => $parameter) {
                        $name = mb_strtolower($parameter->getName(), 'UTF-8');
                        $arguments[] = match ($position) {
                            0 => 0,
                            1 => (int) ($fields['type'] ?? 0),
                            2 => (int) ($fields['itilcategories_id'] ?? 0),
                            3 => (int) ($fields['entities_id'] ?? 0),
                            default => $parameter->isDefaultValueAvailable()
                                ? $parameter->getDefaultValue()
                                : (str_contains($name, 'entit')
                                    ? (int) ($fields['entities_id'] ?? 0)
                                    : 0),
                        };
                    }
                    $template = $method->invokeArgs($ticket, $arguments);
                    if (is_object($template)) {
                        $templateResolved = true;
                        $mandatory = $this->normalizeTicketTemplateFieldList($template->mandatory ?? []);
                    }
                }
            } catch (\Throwable) {
                // GLPI 10/11 differ in the helper signature; use the native
                // public predicate below when it is available.
            }
        }

        $errors = [];
        foreach ($mandatory as $field) {
            $field = (string) $field;
            if ($field === '' || $this->solutionFieldHasValue($fields[$field] ?? null)) {
                continue;
            }
            $label = TicketCreationPolicy::fieldLabel($field);
            $errors[] = $this->solutionError(
                $field,
                'required',
                sprintf(
                    I18n::translate('Informe %s.'),
                    mb_strtolower($label, 'UTF-8')
                )
            );
        }
        if ($errors !== []) {
            return $errors;
        }

        // GLPI 11 exposes the exact non-mutating predicate used by its native
        // timeline. It complements the template inspection above and retains
        // native diagnostic messages for fields represented differently.
        if (method_exists($ticket, 'checkRequiredFieldsFilled')) {
            $before = $this->solutionMessageStrings();
            try {
                if (!$ticket->checkRequiredFieldsFilled()) {
                    $nativeErrors = $this->solutionErrorsFromNativeMessages(
                        $this->newSolutionMessageStrings($before)
                    );
                    return $nativeErrors !== [] ? $nativeErrors : [$this->solutionError(
                        'solution',
                        'ticket_required_field_missing',
                        I18n::translate('Não foi possível concluir a ação. Revise os dados e tente novamente.')
                    )];
                }
            } catch (\Throwable) {
                return [$this->solutionError(
                    'solution',
                    'solution_precondition_unavailable',
                    I18n::translate('Não foi possível concluir a ação. Revise os dados e tente novamente.')
                )];
            }
        } elseif (!$templateResolved) {
            // GLPI 10 has no public required-field predicate. A missing native
            // template API must fail closed instead of probing with add().
            return [$this->solutionError(
                'solution',
                'solution_precondition_unavailable',
                I18n::translate('Não foi possível concluir a ação. Revise os dados e tente novamente.')
            )];
        }

        return [];
    }

    private function solutionFieldHasValue(mixed $value): bool
    {
        if (is_array($value)) {
            foreach ($value as $item) {
                if ($this->solutionFieldHasValue($item)) {
                    return true;
                }
            }
            return false;
        }

        if (is_bool($value)) {
            return $value;
        }

        $normalized = trim((string) $value);
        return $normalized !== '' && $normalized !== '0' && $normalized !== '0000-00-00 00:00:00';
    }

    /** @return string[] */
    private function solutionMessageStrings(): array
    {
        $messages = $_SESSION['MESSAGE_AFTER_REDIRECT'] ?? [];
        $strings = [];
        $walk = static function (mixed $value) use (&$walk, &$strings): void {
            if (is_array($value)) {
                foreach ($value as $item) {
                    $walk($item);
                }
                return;
            }
            if (!is_scalar($value)) {
                return;
            }
            $text = TextNormalizer::fromGlpi(strip_tags(html_entity_decode(
                (string) $value,
                ENT_QUOTES | ENT_HTML5,
                'UTF-8'
            )));
            $text = trim(preg_replace('/\s+/u', ' ', $text) ?? $text);
            if ($text !== '') {
                $strings[] = $text;
            }
        };
        $walk($messages);

        return $strings;
    }

    /** @param string[] $before @return string[] */
    private function newSolutionMessageStrings(array $before): array
    {
        $counts = array_count_values($before);
        $new = [];
        foreach ($this->solutionMessageStrings() as $message) {
            if (($counts[$message] ?? 0) > 0) {
                $counts[$message]--;
                continue;
            }
            $new[] = $message;
        }

        return $new;
    }

    /**
     * @param string[] $messages
     * @return array<int, array{field:string,code:string,message:string}>
     */
    private function solutionErrorsFromNativeMessages(array $messages): array
    {
        $errors = [];
        foreach ($messages as $message) {
            $message = trim((string) $message);
            if ($message === '') {
                continue;
            }
            $folded = mb_strtolower($message, 'UTF-8');
            $location = str_contains($folded, 'localização') || str_contains($folded, 'location');
            $errors[] = $this->solutionError(
                $location ? 'locations_id' : 'solution',
                $location ? 'required' : 'native_solution_rejected',
                $message
            );
        }

        return $errors;
    }

    /** @return array{field:string,code:string,message:string} */
    private function solutionError(string $field, string $code, string $message): array
    {
        return [
            'field' => $field,
            'code' => $code,
            'message' => trim($message),
        ];
    }

    /**
     * Verify the native solution row and the status transition performed by
     * ITILSolution::post_addItem(). The result is diagnostic and must never be
     * used to retry the mutation automatically.
     *
     * @return array{
     *   persisted:bool,type_confirmed:bool,author_confirmed:bool,
     *   ticket_readable:bool,ticket_status:int,status_confirmed:bool
     * }
     */
    public function verifySolutionOutcome(
        int $solutionId,
        int $ticketId,
        ?int $solutionTypeId = null,
        ?int $expectedUserId = null
    ): array {
        $outcome = [
            'persisted' => false,
            'type_confirmed' => false,
            'author_confirmed' => false,
            'ticket_readable' => false,
            'ticket_status' => 0,
            'status_confirmed' => false,
        ];
        if ($solutionId <= 0 || $ticketId <= 0 || !class_exists('\ITILSolution') || !class_exists('\Ticket')) {
            return $outcome;
        }

        try {
            $solution = new \ITILSolution();
            if ($solution->getFromDB($solutionId)) {
                $fields = is_array($solution->fields ?? null) ? $solution->fields : [];
                $outcome['persisted'] = (string) ($fields['itemtype'] ?? '') === 'Ticket'
                    && (int) ($fields['items_id'] ?? 0) === $ticketId
                    && trim((string) ($fields['content'] ?? '')) !== '';
                $outcome['type_confirmed'] = $solutionTypeId === null
                    || (int) ($fields['solutiontypes_id'] ?? 0) === $solutionTypeId;
                $expectedUserId = $expectedUserId !== null && $expectedUserId > 0
                    ? $expectedUserId
                    : (int) ($_SESSION['glpiID'] ?? 0);
                $outcome['author_confirmed'] = $expectedUserId > 0
                    && (int) ($fields['users_id'] ?? 0) === $expectedUserId;
            }

            $ticket = new \Ticket();
            if ($ticket->getFromDB($ticketId)) {
                $outcome['ticket_readable'] = true;
                $outcome['ticket_status'] = (int) ($ticket->fields['status'] ?? 0);
                $outcome['status_confirmed'] = in_array(
                    $outcome['ticket_status'],
                    [$this->solvedStatus(), $this->closedStatus()],
                    true
                );
            }
        } catch (\Throwable) {
            return $outcome;
        }

        return $outcome;
    }

    /**
     * Read back the native row after ITILSolution::add(). A failed readback is
     * diagnostic only: the caller must not retry an already persisted mutation.
     */
    public function verifySolutionPersistence(
        int $solutionId,
        int $ticketId,
        ?int $solutionTypeId = null
    ): bool {
        if ($solutionId <= 0 || $ticketId <= 0 || !class_exists('\ITILSolution')) {
            return false;
        }

        try {
            $solution = new \ITILSolution();
            if (!$solution->getFromDB($solutionId)) {
                return false;
            }

            $fields = is_array($solution->fields ?? null) ? $solution->fields : [];
            if (
                (string) ($fields['itemtype'] ?? '') !== 'Ticket'
                || (int) ($fields['items_id'] ?? 0) !== $ticketId
                || trim((string) ($fields['content'] ?? '')) === ''
            ) {
                return false;
            }

            return $solutionTypeId === null
                || $solutionTypeId <= 0
                || (int) ($fields['solutiontypes_id'] ?? 0) === $solutionTypeId;
        } catch (\Throwable $e) {
            return false;
        }
    }

    /**
     * Execute exactly one native solution decision. The plugin coordinates the
     * request, while ITILFollowup/ParentStatus remain the sole owners of ticket
     * status, solution status, history, notifications and satisfaction.
     *
     * @param array<string,mixed> $filesPayload
     * @return array{status:string,followup_id:int,outcome?:array<string,mixed>,replayed?:bool,marker_cleared?:bool}
     */
    public function decideSolutionNatively(
        IdempotencyLedger $ledger,
        string $requestKey,
        string $requestHash,
        string $expectedRevision,
        int $ticketId,
        string $decision,
        string $content,
        array $filesPayload = []
    ): array {
        global $DB;
        if (
            !isset($DB)
            || !method_exists($DB, 'beginTransaction')
            || !method_exists($DB, 'commit')
            || !method_exists($DB, 'rollBack')
            || !class_exists('\ITILFollowup')
        ) {
            throw new \RuntimeException('solution_decision_database_unavailable');
        }
        if (
            $ticketId <= 0
            || !in_array($decision, ['approve', 'refuse'], true)
            || preg_match('/\A[a-f0-9]{64}\z/D', $expectedRevision) !== 1
        ) {
            return ['status' => 'rejected', 'followup_id' => 0];
        }
        if ($decision === 'refuse' && trim($content) === '') {
            return ['status' => 'rejected', 'followup_id' => 0];
        }

        $followupBefore = $this->latestFollowupIdForTicket($ticketId);
        if ($followupBefore === null) {
            throw new \RuntimeException('solution_decision_followup_snapshot_unavailable');
        }
        $scope = 'ticket.solution-decision:' . $ticketId;
        if ($ledger->latestPartial($scope) !== null) {
            return ['status' => IdempotencyClaim::IN_PROGRESS, 'followup_id' => 0];
        }
        $guard = $ledger->acquirePartialGuard(
            $scope,
            hash('sha256', 'ticket.solution-decision.guard:' . $ticketId),
            $requestHash,
            self::SOLUTION_DECISION_BASELINE_OFFSET + $followupBefore
        );
        if (!$guard->isAcquired()) {
            return ['status' => $guard->status(), 'followup_id' => 0];
        }

        $this->activeSolutionDecisionGuardKeyHash = $guard->keyHash();
        $transactionStarted = false;
        $mutationStarted = false;
        $followupId = 0;
        try {
            if ($DB->beginTransaction() === false) {
                throw new \RuntimeException('solution_decision_transaction_failed');
            }
            $transactionStarted = true;
            $claim = $ledger->reserve($scope, $requestKey, $requestHash);
            if ($claim->isReplay()) {
                $followupId = max(0, (int) $claim->resultId());
                $outcome = $this->verifySolutionDecisionOutcome(
                    $followupId,
                    $ticketId,
                    $decision,
                    $filesPayload,
                    (int) ($_SESSION['glpiID'] ?? 0)
                );
                if ($DB->commit() === false) {
                    throw new \RuntimeException('solution_decision_replay_commit_failed');
                }
                $transactionStarted = false;
                return [
                    'status' => IdempotencyClaim::REPLAY,
                    'followup_id' => $followupId,
                    'outcome' => $outcome,
                    'replayed' => true,
                    'marker_cleared' => $this->releaseSolutionDecisionGuard($ledger, $guard),
                ];
            }
            if (!$claim->isAcquired()) {
                if ($DB->rollBack() === false) {
                    throw new \RuntimeException('solution_decision_conflict_rollback_failed');
                }
                $transactionStarted = false;
                return [
                    'status' => $claim->status(),
                    'followup_id' => 0,
                    'marker_cleared' => $this->releaseSolutionDecisionGuard($ledger, $guard),
                ];
            }
            if (!$this->lockTicketForRouting($ticketId)) {
                throw new \RuntimeException('solution_decision_ticket_lock_failed');
            }

            $context = $this->getSolutionDecisionContext($ticketId);
            if (
                !hash_equals((string) ($context['revision'] ?? ''), $expectedRevision)
                || (string) ($context['state'] ?? '') !== 'ready'
                || empty($context['can_decide'])
            ) {
                if (!$ledger->release($claim) || $DB->commit() === false) {
                    throw new \RuntimeException('solution_decision_stale_finalize_failed');
                }
                $transactionStarted = false;
                return [
                    'status' => 'context_stale',
                    'followup_id' => 0,
                    'marker_cleared' => $this->releaseSolutionDecisionGuard($ledger, $guard),
                ];
            }

            $payload = [
                'itemtype' => 'Ticket',
                'items_id' => $ticketId,
                'requesttypes_id' => 0,
                'content' => $content,
                'is_private' => 0,
                ($decision === 'approve' ? 'add_close' : 'add_reopen') => 1,
            ];
            foreach (['_filename', '_tag_filename', '_prefix_filename'] as $key) {
                if (!empty($filesPayload[$key]) && is_array($filesPayload[$key])) {
                    $payload[$key] = array_values($filesPayload[$key]);
                }
            }

            $mutationStarted = true;
            $followup = new \ITILFollowup();
            $nativeResult = $followup->add($payload);
            $followupId = is_int($nativeResult) && $nativeResult > 0 ? $nativeResult : 0;
            if ($followupId <= 0) {
                if ($DB->rollBack() === false) {
                    throw new \RuntimeException('solution_decision_rejection_rollback_failed');
                }
                $transactionStarted = false;
                $afterRollback = $this->getSolutionDecisionContext($ticketId);
                $rollbackConfirmed = hash_equals(
                    $expectedRevision,
                    (string) ($afterRollback['revision'] ?? '')
                ) && (string) ($afterRollback['state'] ?? '') === 'ready'
                    && $this->latestFollowupIdForTicket($ticketId) === $followupBefore;
                if (!$rollbackConfirmed) {
                    try {
                        $ledger->updatePartialGuard($guard, 0);
                    } catch (\Throwable) {
                        // The original durable guard remains authoritative.
                    }
                    return [
                        'status' => 'uncertain',
                        'followup_id' => 0,
                        'outcome' => [],
                        'marker_cleared' => false,
                    ];
                }
                return [
                    'status' => 'rejected',
                    'followup_id' => 0,
                    'marker_cleared' => $this->releaseSolutionDecisionGuard($ledger, $guard),
                ];
            }

            $outcome = $this->verifySolutionDecisionOutcome(
                $followupId,
                $ticketId,
                $decision,
                $filesPayload,
                (int) ($_SESSION['glpiID'] ?? 0)
            );
            if (empty($outcome['verified'])) {
                throw new \RuntimeException('solution_decision_outcome_unverified');
            }
            if (!$ledger->complete($claim, $followupId)) {
                throw new \RuntimeException('solution_decision_ledger_completion_failed');
            }
            if ($DB->commit() === false) {
                throw new \RuntimeException('solution_decision_commit_failed');
            }
            $transactionStarted = false;
            return [
                'status' => IdempotencyClaim::ACQUIRED,
                'followup_id' => $followupId,
                'outcome' => $outcome,
                'replayed' => false,
                'marker_cleared' => $this->releaseSolutionDecisionGuard($ledger, $guard),
            ];
        } catch (\Throwable $e) {
            $rolledBack = false;
            if ($transactionStarted) {
                try {
                    $rolledBack = $DB->rollBack() !== false;
                } catch (\Throwable) {
                    $rolledBack = false;
                }
            }

            if ($mutationStarted) {
                $outcome = $followupId > 0
                    ? $this->verifySolutionDecisionOutcome(
                        $followupId,
                        $ticketId,
                        $decision,
                        $filesPayload,
                        (int) ($_SESSION['glpiID'] ?? 0)
                    )
                    : [];
                if (!$rolledBack || !empty($outcome['persisted'])) {
                    try {
                        $ledger->updatePartialGuard($guard, $followupId);
                    } catch (\Throwable) {
                        // The zero-ID durable guard still blocks unsafe retry.
                    }
                    return [
                        'status' => 'uncertain',
                        'followup_id' => $followupId,
                        'outcome' => $outcome,
                        'marker_cleared' => false,
                    ];
                }
                return [
                    'status' => 'rejected',
                    'followup_id' => 0,
                    'marker_cleared' => $this->releaseSolutionDecisionGuard($ledger, $guard),
                ];
            }

            $this->releaseSolutionDecisionGuard($ledger, $guard);
            throw $e;
        } finally {
            $this->activeSolutionDecisionGuardKeyHash = null;
        }
    }

    public function changeStatus(int $ticketId, int $status): bool
    {
        return $this->updateTicketStatus($ticketId, $status, true);
    }

    private function updateTicketStatus(int $ticketId, int $status, bool $requireUpdateRight = false): bool
    {
        $ticket = new \Ticket();
        if (!$ticket->getFromDB(max(1, $ticketId)) || !$ticket->canViewItem()) {
            return false;
        }
        if ($requireUpdateRight && !$this->canChangeStatusToTicket($ticketId)) {
            return false;
        }

        $payload = [
            'id' => $ticketId,
            'status' => $status,
        ];
        if (method_exists($ticket, 'enforceReadonlyFields')) {
            $payload = $ticket->enforceReadonlyFields($payload);
        }

        return (bool) $ticket->update($payload);
    }

    /** @return array<string,mixed> */
    private function latestSolutionForTicket(int $ticketId): array
    {
        if ($ticketId <= 0 || !class_exists('\ITILSolution')) {
            return [];
        }
        try {
            $solution = new \ITILSolution();
            $rows = $solution->find(
                ['itemtype' => 'Ticket', 'items_id' => $ticketId],
                'date_creation DESC, id DESC',
                1
            );
            $row = is_array($rows) ? reset($rows) : false;
            return is_array($row) ? $row : [];
        } catch (\Throwable) {
            return [];
        }
    }

    private function latestFollowupIdForTicket(int $ticketId): ?int
    {
        if ($ticketId <= 0 || !class_exists('\ITILFollowup')) {
            return null;
        }
        try {
            $followup = new \ITILFollowup();
            $rows = $followup->find(
                ['itemtype' => 'Ticket', 'items_id' => $ticketId],
                'date_creation DESC, id DESC',
                1
            );
            $row = is_array($rows) ? reset($rows) : false;
            return is_array($row) ? max(0, (int) ($row['id'] ?? 0)) : 0;
        } catch (\Throwable) {
            return null;
        }
    }

    /**
     * Clear only a guard whose native outcome is already conclusive. A pending
     * solution remains blocked because replay could duplicate its follow-up.
     *
     * @param array<string,mixed>|null $ticketFields
     * @param array<string,mixed>|null $solution
     * @param array<string,mixed>|null $partial
     * @return array{state:string,cleared:bool,result_id:int}
     */
    public function reconcileSolutionDecisionGuard(
        int $ticketId,
        ?array $ticketFields = null,
        ?array $solution = null,
        ?array $partial = null
    ): array {
        $result = ['state' => 'unavailable', 'cleared' => false, 'result_id' => 0];
        if ($ticketId <= 0 || !$this->solutionIdempotencyLedger instanceof IdempotencyLedger) {
            return $result;
        }
        $scope = 'ticket.solution-decision:' . $ticketId;
        $partial ??= $this->solutionIdempotencyLedger->latestPartial($scope);
        if (!is_array($partial)) {
            return ['state' => 'clear', 'cleared' => false, 'result_id' => 0];
        }
        $result['result_id'] = max(0, (int) ($partial['result_id'] ?? 0));
        if (
            hash_equals(
                (string) ($partial['operation_key_hash'] ?? ''),
                (string) ($this->activeSolutionDecisionGuardKeyHash ?? '')
            )
        ) {
            return ['state' => 'active', 'cleared' => false, 'result_id' => $result['result_id']];
        }

        try {
            if ($ticketFields === null) {
                $ticket = new \Ticket();
                if (!$ticket->getFromDB($ticketId)) {
                    return $result;
                }
                $ticketFields = is_array($ticket->fields ?? null) ? $ticket->fields : [];
            }
            $solution ??= $this->latestSolutionForTicket($ticketId);
            $ticketStatus = max(0, (int) ($ticketFields['status'] ?? 0));
            $solutionStatus = max(0, (int) ($solution['status'] ?? 0));
            $approved = $ticketStatus === $this->closedStatus()
                && $solutionStatus === $this->acceptedSolutionStatus();
            $refused = !in_array($ticketStatus, [$this->solvedStatus(), $this->closedStatus()], true)
                && $solutionStatus === $this->refusedSolutionStatus();
            $encodedBaseline = $result['result_id'] >= self::SOLUTION_DECISION_BASELINE_OFFSET;
            $baselineFollowupId = $encodedBaseline
                ? $result['result_id'] - self::SOLUTION_DECISION_BASELINE_OFFSET
                : -1;
            $updatedAt = strtotime((string) ($partial['updated_at'] ?? ''));
            $orphanExpired = $updatedAt !== false
                && (time() - $updatedAt) >= self::SOLUTION_DECISION_ORPHAN_SECONDS;
            $pendingUnchanged = $encodedBaseline
                && $orphanExpired
                && $ticketStatus === $this->solvedStatus()
                && (int) ($solution['id'] ?? 0) > 0
                && !in_array(
                    $solutionStatus,
                    [$this->acceptedSolutionStatus(), $this->refusedSolutionStatus()],
                    true
                )
                && $this->latestFollowupIdForTicket($ticketId) === $baselineFollowupId;
            if (!$approved && !$refused && !$pendingUnchanged) {
                return ['state' => 'partial', 'cleared' => false, 'result_id' => $result['result_id']];
            }

            $cleared = $this->solutionIdempotencyLedger->clearPartials($scope);
            return [
                'state' => $cleared
                    ? ($approved ? 'approved' : ($refused ? 'refused' : 'clear'))
                    : 'unavailable',
                'cleared' => $cleared,
                'result_id' => $result['result_id'],
            ];
        } catch (\Throwable) {
            return $result;
        }
    }

    /** @param array<string,mixed> $ticketFields @param array<string,mixed> $solution */
    private function solutionDecisionRevision(array $ticketFields, array $solution): string
    {
        return hash('sha256', json_encode([
            'ticket_id' => (int) ($ticketFields['id'] ?? 0),
            'ticket_status' => (int) ($ticketFields['status'] ?? 0),
            'ticket_date_mod' => (string) ($ticketFields['date_mod'] ?? ''),
            'solution_id' => (int) ($solution['id'] ?? 0),
            'solution_status' => (int) ($solution['status'] ?? 0),
            'solution_date_mod' => (string) ($solution['date_mod'] ?? ''),
            'solution_date_approval' => (string) ($solution['date_approval'] ?? ''),
        ], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) ?: '');
    }

    /**
     * @param array<string,mixed> $filesPayload
     * @return array<string,mixed>
     */
    public function verifySolutionDecisionOutcome(
        int $followupId,
        int $ticketId,
        string $decision,
        array $filesPayload = [],
        ?int $expectedUserId = null
    ): array {
        $outcome = [
            'verified' => false,
            'persisted' => false,
            'author_confirmed' => false,
            'public_confirmed' => false,
            'attachments_confirmed' => false,
            'solution_confirmed' => false,
            'decision_user_confirmed' => false,
            'decision_date_confirmed' => false,
            'ticket_confirmed' => false,
            'ticket_status' => 0,
            'solution_status' => 0,
        ];
        if (
            $followupId <= 0
            || $ticketId <= 0
            || !in_array($decision, ['approve', 'refuse'], true)
            || !class_exists('\ITILFollowup')
            || !class_exists('\Ticket')
        ) {
            return $outcome;
        }

        try {
            $expectedUserId = $expectedUserId !== null && $expectedUserId > 0
                ? $expectedUserId
                : (int) ($_SESSION['glpiID'] ?? 0);
            $followup = new \ITILFollowup();
            if ($followup->getFromDB($followupId)) {
                $fields = is_array($followup->fields ?? null) ? $followup->fields : [];
                $outcome['persisted'] = (string) ($fields['itemtype'] ?? '') === 'Ticket'
                    && (int) ($fields['items_id'] ?? 0) === $ticketId;
                $outcome['author_confirmed'] = $expectedUserId > 0
                    && (int) ($fields['users_id'] ?? 0) === $expectedUserId;
                $outcome['public_confirmed'] = (int) ($fields['is_private'] ?? 0) === 0;
            }

            $expectedFiles = [];
            $storedFiles = array_values(array_map('strval', (array) ($filesPayload['_filename'] ?? [])));
            $prefixes = array_values(array_map('strval', (array) ($filesPayload['_prefix_filename'] ?? [])));
            foreach ($storedFiles as $index => $storedFile) {
                $prefix = (string) ($prefixes[$index] ?? '');
                $expectedFiles[] = $prefix !== '' && str_starts_with($storedFile, $prefix)
                    ? substr($storedFile, strlen($prefix))
                    : basename($storedFile);
            }
            $documentDiagnostics = $this->documentItemLinkDiagnostics(
                'ITILFollowup',
                $followupId,
                count($storedFiles),
                $expectedFiles
            );
            $outcome['attachments_confirmed'] = !empty($documentDiagnostics['complete']);

            $solution = $this->latestSolutionForTicket($ticketId);
            $outcome['solution_status'] = max(0, (int) ($solution['status'] ?? 0));
            $expectedSolutionStatus = $decision === 'approve'
                ? $this->acceptedSolutionStatus()
                : $this->refusedSolutionStatus();
            $outcome['solution_confirmed'] = (int) ($solution['id'] ?? 0) > 0
                && $outcome['solution_status'] === $expectedSolutionStatus;
            $outcome['decision_user_confirmed'] = $expectedUserId > 0
                && (int) ($solution['users_id_approval'] ?? 0) === $expectedUserId;
            $outcome['decision_date_confirmed'] = trim((string) ($solution['date_approval'] ?? '')) !== '';

            $ticket = new \Ticket();
            if ($ticket->getFromDB($ticketId)) {
                $ticketFields = is_array($ticket->fields ?? null) ? $ticket->fields : [];
                $outcome['ticket_status'] = max(0, (int) ($ticketFields['status'] ?? 0));
                $outcome['ticket_confirmed'] = $decision === 'approve'
                    ? $outcome['ticket_status'] === $this->closedStatus()
                        && trim((string) ($ticketFields['closedate'] ?? '')) !== ''
                    : !in_array(
                        $outcome['ticket_status'],
                        [$this->solvedStatus(), $this->closedStatus()],
                        true
                    );
            }

            $outcome['verified'] = $outcome['persisted']
                && $outcome['author_confirmed']
                && $outcome['public_confirmed']
                && $outcome['attachments_confirmed']
                && $outcome['solution_confirmed']
                && $outcome['decision_user_confirmed']
                && $outcome['decision_date_confirmed']
                && $outcome['ticket_confirmed'];
        } catch (\Throwable) {
            return $outcome;
        }

        return $outcome;
    }

    private function releaseSolutionDecisionGuard(
        IdempotencyLedger $ledger,
        IdempotencyClaim $guard
    ): bool {
        try {
            return $ledger->releasePartialGuard($guard);
        } catch (\Throwable) {
            return false;
        }
    }

    /** @return array{state:string,visible:bool,can_decide:bool,current_status:int,solution_id:int,solution_status:int,revision:string} */
    private function emptySolutionDecisionContext(string $state): array
    {
        return [
            'state' => $state,
            'visible' => false,
            'can_decide' => false,
            'current_status' => 0,
            'solution_id' => 0,
            'solution_status' => 0,
            'revision' => '',
        ];
    }

    private function solvedStatus(): int
    {
        return defined('\CommonITILObject::SOLVED') ? (int) \CommonITILObject::SOLVED : 5;
    }

    private function closedStatus(): int
    {
        return defined('\CommonITILObject::CLOSED') ? (int) \CommonITILObject::CLOSED : 6;
    }

    private function acceptedSolutionStatus(): int
    {
        if (defined('\CommonITILValidation::ACCEPTED')) {
            return (int) constant('CommonITILValidation::ACCEPTED');
        }
        return defined('\ITILSolution::ACCEPTED') ? (int) \ITILSolution::ACCEPTED : 3;
    }

    private function refusedSolutionStatus(): int
    {
        if (defined('\CommonITILValidation::REFUSED')) {
            return (int) constant('CommonITILValidation::REFUSED');
        }
        return defined('\ITILSolution::REFUSED') ? (int) \ITILSolution::REFUSED : 4;
    }

    /**
     * Return the native, item-scoped contract used by the accessible general
     * ticket editor after creation.
     *
     * @return array{
     *   can_update:bool,
     *   revision:string,
     *   editable_fields:string[],
     *   mandatory_fields:string[],
     *   values:array<string,mixed>,
     *   entity_id:int,
     *   selected_resources:array<string,array<int,array{id:int,label:string}>>,
     *   categories:array<int,array{id:int,label:string,is_incident:bool,is_request:bool}>,
     *   locations:array<int,array{id:int,label:string}>,
     *   type_options:array<int,array{id:int,label:string}>,
     *   request_source_options:array<int,array{id:int,label:string}>,
     *   urgency_options:array<int,array{id:int,label:string}>,
     *   impact_options:array<int,array{id:int,label:string}>,
     *   priority_options:array<int,array{id:int,label:string}>
     * }
     */
    public function getTicketGeneralEditContext(int $ticketId): array
    {
        $empty = [
            'can_update' => false,
            'revision' => '',
            'editable_fields' => [],
            'mandatory_fields' => [],
            'values' => [],
            'entity_id' => -1,
            'selected_resources' => [
                'itilcategories_id' => [],
                'locations_id' => [],
            ],
            'categories' => [],
            'locations' => [],
            'type_options' => $this->getTicketTypeOptions(),
            'request_source_options' => $this->ticketSupportsRequestSource()
                ? $this->getRequestSourceOptions()
                : [],
            'urgency_options' => $this->getUrgencyOptions(),
            'impact_options' => $this->getImpactOptions(),
            'priority_options' => $this->getPriorityOptions(),
        ];

        $ticketId = max(1, $ticketId);
        try {
            $ticket = new \Ticket();
            if (
                !$this->canReadTicket($ticketId)
                || !$ticket->getFromDB($ticketId)
                || !$ticket->canViewItem()
            ) {
                return $empty;
            }

            $entityId = (int) ($ticket->fields['entities_id'] ?? -1);
            if ($entityId < 0 || !$this->canAccessTicketEntity($entityId)) {
                return $empty;
            }

            $values = $this->ticketGeneralSnapshot($ticket, $ticketId);
            $rules = $this->ticketGeneralTemplateRules($ticket);
            $canUpdate = $this->canUpdateTicket($ticketId) && $rules['resolved'];
            $editableFields = [];
            if ($canUpdate) {
                foreach (self::GENERAL_EDIT_FIELDS as $field) {
                    if (
                        !$this->ticketColumnExists($field)
                        || ($field === 'priority' && !$this->canChangeTicketPriority())
                        || ($field === 'content' && empty($values['_content_projection_available']))
                        || in_array($field, $rules['hidden'], true)
                        || in_array($field, $rules['readonly'], true)
                    ) {
                        continue;
                    }
                    $editableFields[] = $field;
                }
            }

            $categoryId = (int) ($values['itilcategories_id'] ?? 0);
            $locationId = (int) ($values['locations_id'] ?? 0);
            $selectedResources = [
                'itilcategories_id' => $categoryId > 0 ? [[
                    'id' => $categoryId,
                    'label' => $this->resolveTicketCategoryName($categoryId),
                ]] : [],
                'locations_id' => $locationId > 0 ? [[
                    'id' => $locationId,
                    'label' => $this->resolveTicketLocationName($locationId),
                ]] : [],
            ];
            $publicValues = $values;
            unset($publicValues['_content_raw'], $publicValues['_content_projection_available']);

            return array_replace($empty, [
                'can_update' => $canUpdate,
                'revision' => $this->ticketGeneralSnapshotRevision($values),
                'editable_fields' => $editableFields,
                // Publish only requirements the accessible form can satisfy.
                // Hidden/readonly native fields remain enforced by GLPI but
                // must not become impossible controls in this editor.
                'mandatory_fields' => array_values(array_intersect(
                    $rules['mandatory'],
                    $editableFields
                )),
                'values' => $publicValues,
                'entity_id' => $entityId,
                'selected_resources' => $selectedResources,
                // These bounded-by-native-object fallbacks keep the editor
                // functional when remote selectors are disabled. Their entity
                // scope is the ticket's entity, never the broader active tree.
                'categories' => $canUpdate ? $this->getTicketCategoriesForEntity($entityId) : [],
                'locations' => $canUpdate ? $this->getTicketLocationsForEntity($entityId) : [],
            ]);
        } catch (\Throwable) {
            return $empty;
        }
    }

    /**
     * Apply an optimistic, item-scoped scalar update exclusively through the
     * native Ticket object, then verify the persisted state.
     *
     * @param array<string,mixed> $fields
     * @return array{status:string,changed_fields:string[],revision:string}
     */
    public function updateTicketGeneralFields(
        int $ticketId,
        array $fields,
        ?string $expectedRevision = null
    ): array {
        $ticketId = max(1, $ticketId);
        $requestedFields = array_values(array_filter(
            array_keys($fields),
            static fn(mixed $field): bool => is_string($field)
        ));
        $result = static fn(string $status, array $changedFields = [], string $revision = ''): array => [
            'status' => $status,
            'changed_fields' => array_values($changedFields),
            'revision' => $revision,
        ];

        if (
            array_diff($requestedFields, self::GENERAL_EDIT_FIELDS) !== []
            || $expectedRevision === null
            || preg_match('/\A[a-f0-9]{64}\z/D', strtolower($expectedRevision)) !== 1
        ) {
            return $result('context_stale', $requestedFields);
        }

        try {
            $ticket = new \Ticket();
            if (
                !$ticket->getFromDB($ticketId)
                || !$ticket->canViewItem()
                || !$this->canUpdateTicket($ticketId)
            ) {
                return $result('rejected', $requestedFields);
            }
            $entityId = (int) ($ticket->fields['entities_id'] ?? -1);
            if ($entityId < 0 || !$this->canAccessTicketEntity($entityId)) {
                return $result('rejected', $requestedFields);
            }

            $before = $this->ticketGeneralSnapshot($ticket, $ticketId);
            $beforeRevision = $this->ticketGeneralSnapshotRevision($before);
            if (!hash_equals($beforeRevision, strtolower($expectedRevision))) {
                return $result('context_stale', $requestedFields, $beforeRevision);
            }
            if ($requestedFields === []) {
                return $result('unchanged', [], $beforeRevision);
            }

            // Resolve the template against the submitted type/category, just
            // like the native form does. GLPI 10 has no enforceReadonlyFields,
            // so an unresolved model contract must fail closed here.
            $rules = $this->ticketGeneralTemplateRules($ticket, $fields);
            if (
                !$rules['resolved']
                || array_intersect($requestedFields, $rules['hidden']) !== []
                || array_intersect($requestedFields, $rules['readonly']) !== []
                || (in_array('priority', $requestedFields, true) && !$this->canChangeTicketPriority())
            ) {
                return $result('rejected', $requestedFields, $beforeRevision);
            }

            $normalized = $this->normalizeTicketGeneralUpdate($fields, $before, $entityId, $rules['mandatory']);
            if ($normalized === null) {
                return $result('rejected', $requestedFields, $beforeRevision);
            }

            $changedFields = [];
            $payload = ['id' => $ticketId];
            foreach ($normalized as $field => $value) {
                $beforeValue = $before[$field] ?? null;
                if (
                    $this->ticketGeneralComparableValue($field, $beforeValue)
                    === $this->ticketGeneralComparableValue($field, $value)
                ) {
                    continue;
                }
                if ($field === 'content') {
                    if (empty($before['_content_projection_available'])) {
                        return $result('rejected', [$field], $beforeRevision);
                    }
                    $payload[$field] = $this->ticketGeneralPlainTextToHtml((string) $value);
                } else {
                    $payload[$field] = $value;
                }
                $changedFields[] = $field;
            }
            if ($changedFields === []) {
                return $result('unchanged', [], $beforeRevision);
            }

            // GLPI 11 exposes this additional native template/model guard. A
            // field removed or rewritten by it is not silently accepted. On
            // GLPI 10, the resolved template rules above are the fail-closed
            // guard because enforceReadonlyFields() is not available there.
            if (method_exists($ticket, 'enforceReadonlyFields')) {
                $enforced = $ticket->enforceReadonlyFields($payload);
                if (!is_array($enforced)) {
                    return $result('rejected', $changedFields, $beforeRevision);
                }
                foreach ($changedFields as $field) {
                    if ($field === 'content') {
                        // GLPI may canonicalize safe HTML during update. The
                        // postcondition below compares the inert plain-text
                        // projection instead of exact markup bytes.
                        if (!array_key_exists($field, $enforced)) {
                            return $result('rejected', $changedFields, $beforeRevision);
                        }
                        continue;
                    }
                    if (
                        !array_key_exists($field, $enforced)
                        || $this->ticketGeneralComparableValue($field, $enforced[$field])
                            !== $this->ticketGeneralComparableValue($field, $payload[$field])
                    ) {
                        return $result('rejected', $changedFields, $beforeRevision);
                    }
                }
                $payload = $enforced;
                $payload['id'] = $ticketId;
            }

            $nativeUpdated = (bool) $ticket->update($payload);
            $afterTicket = new \Ticket();
            if (!$afterTicket->getFromDB($ticketId) || !$afterTicket->canViewItem()) {
                return $result('uncertain', $changedFields);
            }
            $after = $this->ticketGeneralSnapshot($afterTicket, $ticketId);
            $afterRevision = $this->ticketGeneralSnapshotRevision($after);
            $verified = true;
            foreach ($changedFields as $field) {
                $afterValue = $after[$field] ?? null;
                if (
                    $this->ticketGeneralComparableValue($field, $afterValue)
                    !== $this->ticketGeneralComparableValue($field, $normalized[$field])
                ) {
                    $verified = false;
                    break;
                }
            }
            if ($verified) {
                return $result('verified', $changedFields, $afterRevision);
            }

            // A false native return with the original snapshot intact is a
            // clean rejection. Any divergent state requires manual readback;
            // automatic retries could overwrite a concurrent native update.
            if (!$nativeUpdated && hash_equals($beforeRevision, $afterRevision)) {
                return $result('rejected', $changedFields, $afterRevision);
            }

            return $result('uncertain', $changedFields, $afterRevision);
        } catch (\Throwable) {
            return $result('rejected', $requestedFields);
        }
    }

    /** @return array<string,mixed> */
    private function ticketGeneralSnapshot(object $ticket, int $ticketId): array
    {
        $fields = is_array($ticket->fields ?? null) ? $ticket->fields : [];
        $snapshot = [
            'entities_id' => (int) ($fields['entities_id'] ?? -1),
            'date_mod' => (string) ($fields['date_mod'] ?? ''),
        ];
        foreach (self::GENERAL_EDIT_FIELDS as $field) {
            if ($field === 'locations_id') {
                $snapshot[$field] = $this->readTicketLocationId($ticket, $ticketId);
                continue;
            }
            if ($field === 'content') {
                $rawContent = (string) ($fields['content'] ?? '');
                $snapshot['_content_raw'] = $rawContent;
                try {
                    $projection = (new RichTextToPlainText())->convert($rawContent);
                    $snapshot['content'] = $this->ticketGeneralComparableValue('content', $projection['text']);
                    $snapshot['content_lossy'] = !empty($projection['lossy']) ? 1 : 0;
                    $snapshot['_content_projection_available'] = 1;
                } catch (\Throwable) {
                    $snapshot['content'] = '';
                    $snapshot['content_lossy'] = 1;
                    $snapshot['_content_projection_available'] = 0;
                }
                continue;
            }
            $snapshot[$field] = $this->ticketGeneralComparableValue($field, $fields[$field] ?? null);
        }
        ksort($snapshot);
        return $snapshot;
    }

    /** @param array<string,mixed> $snapshot */
    private function ticketGeneralSnapshotRevision(array $snapshot): string
    {
        ksort($snapshot);
        $encoded = json_encode($snapshot, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
        return hash('sha256', is_string($encoded) ? $encoded : serialize($snapshot));
    }

    private function ticketGeneralComparableValue(string $field, mixed $value): int|string
    {
        if (in_array($field, ['name', 'content', 'date_mod'], true)) {
            $text = str_replace(["\r\n", "\r"], "\n", (string) $value);
            return $field === 'content' ? $text : trim($text);
        }
        return (int) $value;
    }

    private function ticketGeneralPlainTextToHtml(string $text): string
    {
        $text = str_replace(["\r\n", "\r"], "\n", $text);
        return str_replace(
            "\n",
            '<br>',
            htmlspecialchars($text, ENT_QUOTES | ENT_SUBSTITUTE | ENT_HTML5, 'UTF-8')
        );
    }

    /**
     * @param array<string,mixed> $fields
     * @param array<string,mixed> $before
     * @param string[] $mandatoryFields
     * @return array<string,int|string>|null
     */
    private function normalizeTicketGeneralUpdate(
        array $fields,
        array $before,
        int $entityId,
        array $mandatoryFields
    ): ?array {
        $normalized = [];
        foreach ($fields as $field => $value) {
            if (!is_string($field) || !in_array($field, self::GENERAL_EDIT_FIELDS, true)) {
                return null;
            }
            if (in_array($field, ['name', 'content'], true)) {
                if (!is_scalar($value) && $value !== null) {
                    return null;
                }
                $normalized[$field] = $this->ticketGeneralComparableValue($field, $value);
                if ($field === 'name' && $normalized[$field] === '') {
                    return null;
                }
                continue;
            }
            if (
                (!is_int($value) && !is_string($value))
                || preg_match('/\A(?:0|[1-9]\d*)\z/D', (string) $value) !== 1
                || strlen((string) $value) > 10
            ) {
                return null;
            }
            $normalized[$field] = (int) $value;
        }

        $type = (int) ($normalized['type'] ?? $before['type'] ?? 0);
        if (isset($normalized['type']) && !$this->optionListContains($this->getTicketTypeOptions(), $type)) {
            return null;
        }
        foreach (['urgency', 'impact', 'priority'] as $levelField) {
            if (isset($normalized[$levelField]) && ((int) $normalized[$levelField] < 1 || (int) $normalized[$levelField] > 5)) {
                return null;
            }
        }
        if (
            isset($normalized['requesttypes_id'])
            && (
                !$this->ticketSupportsRequestSource()
                || (int) $normalized['requesttypes_id'] <= 0
                || !$this->optionListContains($this->getRequestSourceOptions(), (int) $normalized['requesttypes_id'])
            )
        ) {
            return null;
        }
        if (
            isset($normalized['itilcategories_id'])
            && !$this->ticketGeneralResourceIsEligible(
                'itilcategories_id',
                (int) $normalized['itilcategories_id'],
                $entityId,
                $type
            )
        ) {
            return null;
        }
        if (
            isset($normalized['locations_id'])
            && !$this->ticketGeneralResourceIsEligible(
                'locations_id',
                (int) $normalized['locations_id'],
                $entityId,
                $type
            )
        ) {
            return null;
        }

        foreach ($mandatoryFields as $field) {
            if (!array_key_exists($field, $normalized)) {
                continue;
            }
            $value = $normalized[$field];
            if ((is_string($value) && trim($value) === '') || (!is_string($value) && (int) $value <= 0)) {
                return null;
            }
        }
        return $normalized;
    }

    private function ticketGeneralResourceIsEligible(
        string $field,
        int $resourceId,
        int $ticketEntityId,
        int $ticketType
    ): bool {
        // Clearing an optional native dropdown remains possible. Mandatory
        // template fields are rejected separately above.
        if ($resourceId === 0) {
            return true;
        }
        try {
            $itemClass = $field === 'itilcategories_id'
                ? '\ITILCategory'
                : ($field === 'locations_id' ? '\Location' : '');
            if ($itemClass === '' || !class_exists($itemClass)) {
                return false;
            }
            $item = new $itemClass();
            if (!method_exists($item, 'getFromDB') || !$item->getFromDB($resourceId)) {
                return false;
            }
            $itemVariables = get_object_vars($item);
            $resourceFields = is_array($itemVariables['fields'] ?? null)
                ? $itemVariables['fields']
                : [];
            if (!empty($resourceFields['is_deleted']) || (isset($resourceFields['is_active']) && empty($resourceFields['is_active']))) {
                return false;
            }
            if (
                !$this->ticketGeneralResourceEntityMatches(
                    (int) ($resourceFields['entities_id'] ?? 0),
                    !empty($resourceFields['is_recursive']),
                    $ticketEntityId
                )
            ) {
                return false;
            }
            if ($field === 'itilcategories_id') {
                if ($ticketType === $this->getIncidentTicketType() && isset($resourceFields['is_incident']) && empty($resourceFields['is_incident'])) {
                    return false;
                }
                if ($ticketType === $this->getDemandTicketType() && isset($resourceFields['is_request']) && empty($resourceFields['is_request'])) {
                    return false;
                }
            }
            return true;
        } catch (\Throwable) {
            return false;
        }
    }

    /**
     * @param array<string,mixed> $overrides
     * @return array{mandatory:string[],hidden:string[],readonly:string[],resolved:bool}
     */
    private function ticketGeneralTemplateRules(object $ticket, array $overrides = []): array
    {
        $rules = ['mandatory' => [], 'hidden' => [], 'readonly' => [], 'resolved' => false];
        if (!method_exists($ticket, 'getITILTemplateToUse')) {
            return $rules;
        }
        try {
            $method = new \ReflectionMethod($ticket, 'getITILTemplateToUse');
            if (!$method->isPublic()) {
                return $rules;
            }
            $fields = is_array($ticket->fields ?? null) ? $ticket->fields : [];
            $arguments = [];
            foreach ($method->getParameters() as $parameter) {
                $name = mb_strtolower($parameter->getName(), 'UTF-8');
                $arguments[] = match (true) {
                    str_contains($name, 'force'), str_contains($name, 'template') => 0,
                    $name === 'type' || str_ends_with($name, '_type') => (int) ($overrides['type'] ?? $fields['type'] ?? 0),
                    str_contains($name, 'categor') => (int) ($overrides['itilcategories_id'] ?? $fields['itilcategories_id'] ?? 0),
                    str_contains($name, 'entit') => (int) ($fields['entities_id'] ?? 0),
                    default => $parameter->isDefaultValueAvailable()
                        ? $parameter->getDefaultValue()
                        : throw new \RuntimeException('ticket_template_signature_unsupported'),
                };
            }
            $template = $method->invokeArgs($ticket, $arguments);
            if (!is_object($template)) {
                return $rules;
            }
            return [
                'mandatory' => $this->normalizeTicketTemplateFieldList($template->mandatory ?? []),
                'hidden' => $this->normalizeTicketTemplateFieldList($template->hidden ?? []),
                'readonly' => $this->normalizeTicketTemplateFieldList($template->readonly ?? []),
                'resolved' => true,
            ];
        } catch (\Throwable) {
            // GLPI 10 has no native readonly enforcement during update. A
            // changed/unknown signature therefore cannot be treated as an
            // empty unrestricted model.
            return $rules;
        }
    }

    private function canAccessTicketEntity(int $entityId): bool
    {
        try {
            if (class_exists('\Session') && method_exists('\Session', 'haveAccessToEntity')) {
                return (bool) \Session::haveAccessToEntity($entityId);
            }
            return in_array($entityId, $this->getCurrentEntities(), true);
        } catch (\Throwable) {
            return false;
        }
    }

    private function ticketGeneralResourceEntityMatches(
        int $resourceEntityId,
        bool $recursive,
        int $ticketEntityId
    ): bool {
        if ($resourceEntityId === $ticketEntityId) {
            return true;
        }
        if (!$recursive || $resourceEntityId < 0 || $ticketEntityId < 0) {
            return false;
        }

        // A recursively published category/location may belong to an ancestor
        // that the operator does not select directly. The authorization target
        // is the ticket entity; requiring access to the resource's owning
        // ancestor would be stricter than GLPI's native dropdown semantics.
        try {
            if (function_exists('getAncestorsOf')) {
                $ancestors = (array) getAncestorsOf('glpi_entities', $ticketEntityId);
                $ids = array_values(array_unique(array_merge(
                    array_map('intval', array_keys($ancestors)),
                    array_map('intval', array_values($ancestors))
                )));
                if (in_array($resourceEntityId, $ids, true)) {
                    return true;
                }
            }
            if (function_exists('getSonsOf')) {
                $descendants = (array) getSonsOf('glpi_entities', $resourceEntityId);
                $ids = array_values(array_unique(array_merge(
                    array_map('intval', array_keys($descendants)),
                    array_map('intval', array_values($descendants))
                )));
                return in_array($ticketEntityId, $ids, true);
            }
        } catch (\Throwable) {
            return false;
        }
        return false;
    }

    private function canChangeTicketPriority(): bool
    {
        try {
            $ticketClassVariables = get_class_vars('\Ticket');
            $rightName = (string) ($ticketClassVariables['rightname'] ?? 'ticket');
            return class_exists('\Session')
                && method_exists('\Session', 'haveRight')
                && defined('\Ticket::CHANGEPRIORITY')
                && (bool) \Session::haveRight($rightName, (int) constant('\Ticket::CHANGEPRIORITY'));
        } catch (\Throwable) {
            return false;
        }
    }

    /** @return array<int,array{id:int,label:string,is_incident:bool,is_request:bool}> */
    private function getTicketCategoriesForEntity(int $entityId): array
    {
        $rows = [];
        if (!class_exists('\ITILCategory')) {
            return $rows;
        }
        try {
            $category = new \ITILCategory();
            foreach ($category->find($this->nativeDropdownCriteria('glpi_itilcategories'), 'completename ASC') as $row) {
                if (
                    !$this->ticketGeneralResourceEntityMatches(
                        (int) ($row['entities_id'] ?? 0),
                        !empty($row['is_recursive']),
                        $entityId
                    )
                ) {
                    continue;
                }
                $id = (int) ($row['id'] ?? 0);
                $label = TextNormalizer::fromGlpi((string) ($row['completename'] ?? $row['name'] ?? ''));
                if ($id > 0 && $label !== '') {
                    $rows[] = [
                        'id' => $id,
                        'label' => $label,
                        'is_incident' => !isset($row['is_incident']) || (int) $row['is_incident'] === 1,
                        'is_request' => !isset($row['is_request']) || (int) $row['is_request'] === 1,
                    ];
                }
            }
        } catch (\Throwable) {
            return [];
        }
        return $rows;
    }

    /** @return array<int,array{id:int,label:string}> */
    private function getTicketLocationsForEntity(int $entityId): array
    {
        $rows = [];
        if (!class_exists('\Location')) {
            return $rows;
        }
        try {
            $location = new \Location();
            foreach ($location->find($this->nativeDropdownCriteria('glpi_locations'), 'completename ASC') as $row) {
                if (
                    !$this->ticketGeneralResourceEntityMatches(
                        (int) ($row['entities_id'] ?? 0),
                        !empty($row['is_recursive']),
                        $entityId
                    )
                ) {
                    continue;
                }
                $id = (int) ($row['id'] ?? 0);
                $label = TextNormalizer::fromGlpi((string) ($row['completename'] ?? $row['name'] ?? ''));
                if ($id > 0 && $label !== '') {
                    $rows[] = ['id' => $id, 'label' => $label];
                }
            }
        } catch (\Throwable) {
            return [];
        }
        return $rows;
    }

    /** @return array<int,array{id:int,label:string}> */
    private function getPriorityOptions(): array
    {
        return $this->getUrgencyOptions();
    }

    public function updateTicketFields(int $ticketId, array $fields): bool
    {
        $ticketId = max(1, $ticketId);
        $ticket = new \Ticket();
        if (!$ticket->getFromDB($ticketId) || !$ticket->canViewItem()) {
            return false;
        }

        $assignmentFields = ['_users_id_assign', '_groups_id_assign'];
        $observerFields = ['_users_id_observer', '_groups_id_observer'];
        $routingFields = array_merge($assignmentFields, $observerFields);
        $assignmentRequested = array_intersect(array_keys($fields), $assignmentFields) !== [];
        $observationRequested = array_intersect(array_keys($fields), $observerFields) !== [];
        $nonRoutingRequested = array_diff(array_keys($fields), $routingFields) !== [];
        if (
            ($assignmentRequested && !$this->canAssignTicketActors($ticketId))
            || ($observationRequested && !$this->canObserveTicketActors($ticketId))
            || ($nonRoutingRequested && !\Ticket::canUpdate())
        ) {
            return false;
        }

        $userReplacements = [];
        $userContracts = [
            '_users_id_assign' => [
                'type' => 2,
                'purpose' => GlpiResourceSelectorRegistry::ASSIGNED_USER,
            ],
            '_users_id_observer' => [
                'type' => 3,
                'purpose' => GlpiResourceSelectorRegistry::OBSERVER_USER,
            ],
        ];
        foreach ($userContracts as $field => $contract) {
            if (!array_key_exists($field, $fields)) {
                continue;
            }
            if (!is_array($fields[$field])) {
                return false;
            }
            $ids = array_values(array_unique(array_filter(
                array_map('intval', $fields[$field]),
                static fn(int $id): bool => $id > 0
            )));
            $authorization = $this->authorizedTicketUserIds(
                $ticketId,
                $ids,
                (int) $contract['type'],
                (string) $contract['purpose']
            );
            if ($authorization === null) {
                return false;
            }
            $userReplacements[$field] = [
                'type' => (int) $contract['type'],
                'ids' => $authorization['desired'],
                'removable_ids' => $authorization['allowed'],
            ];
        }

        $groupReplacements = [];
        $groupContracts = [
            '_groups_id_assign' => ['type' => 2, 'capability' => 'is_assign'],
            '_groups_id_observer' => ['type' => 3, 'capability' => 'is_watcher'],
        ];
        foreach ($groupContracts as $field => $contract) {
            if (!array_key_exists($field, $fields)) {
                continue;
            }
            if (!is_array($fields[$field])) {
                return false;
            }
            $ids = array_values(array_unique(array_filter(
                array_map('intval', $fields[$field]),
                static fn(int $id): bool => $id > 0
            )));
            $authorization = $this->authorizedTicketGroupIds(
                $ticket,
                $ids,
                (string) $contract['capability']
            );
            if ($authorization === null) {
                return false;
            }
            $groupReplacements[$field] = [
                'type' => (int) $contract['type'],
                'ids' => $authorization['desired'],
                'removable_ids' => $authorization['allowed'],
            ];
        }

        $payload = ['id' => $ticketId];

        if (isset($fields['urgency'])) {
            $payload['urgency'] = max(1, min(5, (int) $fields['urgency']));
        }
        if (isset($fields['impact'])) {
            $payload['impact'] = max(1, min(5, (int) $fields['impact']));
        }
        if (isset($fields['type'])) {
            $payload['type'] = max(1, (int) $fields['type']);
        }
        if (isset($fields['itilcategories_id'])) {
            $payload['itilcategories_id'] = max(0, (int) $fields['itilcategories_id']);
        }
        if (method_exists($ticket, 'enforceReadonlyFields')) {
            $payload = $ticket->enforceReadonlyFields($payload);
        }

        foreach ($userReplacements as $field => $replacement) {
            $userDiff = $this->ticketUserDiffPayload(
                $ticketId,
                (int) $replacement['type'],
                (array) $replacement['ids'],
                (array) $replacement['removable_ids'],
                $field
            );
            if ($userDiff === null) {
                return false;
            }
            $payload = array_merge($payload, $userDiff);
        }

        foreach ($groupReplacements as $field => $replacement) {
            $groupDiff = $this->ticketGroupDiffPayload(
                $ticketId,
                (int) $replacement['type'],
                (array) $replacement['ids'],
                (array) $replacement['removable_ids'],
                $field
            );
            if ($groupDiff === null) {
                return false;
            }
            $payload = array_merge($payload, $groupDiff);
        }

        return count($payload) === 1 || (bool) $ticket->update($payload);
    }

    /**
     * Add only the authenticated technician through the native take-ticket
     * operation. This is not a replacement of the ticket's actor collections.
     *
     * @return array{status:string,user_id:int}
     */
    public function assignTicketToMe(int $ticketId, ?string $expectedRevision = null): array
    {
        global $DB;

        $context = $this->getTicketSelfAssignmentContext($ticketId);
        $userId = (int) $context['user_id'];
        $result = static fn(string $status): array => ['status' => $status, 'user_id' => $userId];
        if (empty($context['readable'])) {
            return $result('denied');
        }
        // A repeated request must not duplicate the relation or its events,
        // even when taking the ticket is no longer available after the add.
        if ($context['already_assigned'] === true) {
            // An existing relation can itself be provisional in an outer
            // transaction; do not present that state as a completed no-op.
            if (
                !isset($DB)
                || !is_object($DB)
                || $this->ticketSelfAssignmentTransactionIsActive($DB) !== false
            ) {
                return $result('rejected');
            }
            return $result('unchanged');
        }
        if ($context['already_assigned'] === null) {
            return $result('rejected');
        }
        if (empty($context['can_self_assign'])) {
            return $result('denied');
        }
        if ($expectedRevision === null || preg_match('/\A[a-f0-9]{64}\z/D', $expectedRevision) !== 1) {
            return $result('context_stale');
        }

        if (
            !isset($DB)
            || !is_callable([$DB, 'beginTransaction'])
            || !is_callable([$DB, 'commit'])
            || !is_callable([$DB, 'rollBack'])
        ) {
            return $result('rejected');
        }

        $transactionStarted = false;
        $mutationAttempted = false;
        try {
            // An outer transaction would make our commit/readback provisional.
            // Unknown state is unsafe too: GLPI 11 may only release a savepoint.
            if ($this->ticketSelfAssignmentTransactionIsActive($DB) !== false) {
                return $result('rejected');
            }
            if ($DB->beginTransaction() === false) {
                return $result('rejected');
            }
            $transactionStarted = true;
            if (!$this->lockTicketForRouting($ticketId)) {
                throw new \RuntimeException('ticket_self_assignment_lock_failed');
            }

            // Lock first, then reload both authorization and the exact native
            // actor relation. Two portal requests cannot plan the same add.
            $context = $this->getTicketSelfAssignmentContext($ticketId);
            $stopStatus = null;
            if (empty($context['readable']) || (int) $context['user_id'] !== $userId) {
                $stopStatus = 'denied';
            } elseif ($context['already_assigned'] === true) {
                $stopStatus = 'unchanged';
            } elseif ($context['already_assigned'] === null) {
                $stopStatus = 'rejected';
            } elseif (empty($context['can_self_assign'])) {
                $stopStatus = 'denied';
            } elseif (!hash_equals((string) $context['revision'], $expectedRevision)) {
                $stopStatus = 'context_stale';
            }
            if ($stopStatus !== null) {
                if ($DB->rollBack() === false) {
                    throw new \RuntimeException('ticket_self_assignment_rollback_failed');
                }
                $transactionStarted = false;
                return $result($stopStatus);
            }

            $ticket = $context['ticket'];
            $mutationAttempted = true;
            $ticket->update([
                'id' => $ticketId,
                '_itil_assign' => [
                    '_type' => 'user',
                    'users_id' => $userId,
                    'use_notification' => 1,
                ],
            ]);

            // Do not restore an actor/status snapshot: native rules and hooks
            // may legitimately change those fields. update() alone is not
            // evidence that the requested assignment was actually accepted.
            if ($DB->commit() === false) {
                throw new \RuntimeException('ticket_self_assignment_commit_failed');
            }
            if ($this->ticketSelfAssignmentTransactionIsActive($DB) !== false) {
                throw new \RuntimeException('ticket_self_assignment_commit_still_provisional');
            }
            $transactionStarted = false;
            $after = $this->getTicketSelfAssignmentContext($ticketId);
            if (
                empty($after['readable'])
                || (int) $after['user_id'] !== $userId
                || $after['already_assigned'] === null
            ) {
                return $result('uncertain');
            }

            return $result($after['already_assigned'] ? 'verified' : 'rejected');
        } catch (\Throwable) {
            if ($transactionStarted) {
                try {
                    $DB->rollBack();
                } catch (\Throwable) {
                    // A failed update/commit may already have external effects.
                }
            }
            // Never retry a native mutation after an ambiguous failure, even
            // if a rollback appears to have removed its database relation.
            return $result($mutationAttempted ? 'uncertain' : 'rejected');
        }
    }

    /**
     * GLPI 10 exposes inTransaction(); older releases return null before the
     * first transaction because their private untyped flag has no initializer.
     * GLPI 11 keeps its transaction nesting level private and its private
     * isInTransaction() helper must not be called here. Narrowly checked,
     * read-only reflection supports these two known native layouts only.
     * A changed/unknown layout fails closed before beginTransaction().
     */
    private function ticketSelfAssignmentTransactionIsActive(object $database): ?bool
    {
        try {
            foreach (['inTransaction', 'isInTransaction'] as $accessor) {
                if (is_callable([$database, $accessor])) {
                    $state = $database->{$accessor}();
                    if (is_bool($state)) {
                        return $state;
                    }
                    if (
                        $state !== null
                        || $accessor !== 'inTransaction'
                        || !class_exists('\DBmysql')
                        || !($database instanceof \DBmysql)
                    ) {
                        return null;
                    }
                    // GLPI 10.0.10: only the real inherited native accessor and
                    // its untouched null flag mean no transaction has begun.
                    // An override or a generic null-returning adapter is not
                    // evidence that its transaction is inactive.
                    $method = new \ReflectionMethod($database, $accessor);
                    $property = new \ReflectionProperty(\DBmysql::class, 'in_transaction');
                    if (
                        !$method->isPublic()
                        || $method->getDeclaringClass()->getName() !== \DBmysql::class
                        || $property->getDeclaringClass()->getName() !== \DBmysql::class
                        || !$property->isPrivate()
                        || $property->isStatic()
                        || $property->getType() !== null
                        || !$property->isInitialized($database)
                        || $property->getValue($database) !== null
                    ) {
                        return null;
                    }
                    return false;
                }
            }

            if (!class_exists('\DBmysql') || !($database instanceof \DBmysql)) {
                return null;
            }
            $property = new \ReflectionProperty(\DBmysql::class, 'transaction_level');
            $type = $property->getType();
            if (
                $property->getDeclaringClass()->getName() !== \DBmysql::class
                || !$property->isPrivate()
                || $property->isStatic()
                || !($type instanceof \ReflectionNamedType)
                || $type->getName() !== 'int'
                || $type->allowsNull()
                || !$property->isInitialized($database)
            ) {
                return null;
            }
            // PHP >= 8.1 allows reading a private property through reflection.
            // Never change this field or take ownership of an outer transaction.
            $level = $property->getValue($database);
            return is_int($level) && $level >= 0 ? $level > 0 : null;
        } catch (\Throwable) {
            return null;
        }
    }

    /**
     * Apply a routing replacement and verify the seven persisted relation sets.
     *
     * @param array<string,mixed> $fields
     * @return array{status:string,changed_fields:string[]}
     */
    public function updateTicketRouting(int $ticketId, array $fields, ?string $expectedRevision = null): array
    {
        $contracts = [
            '_users_id_assign' => 'assigned_users',
            '_users_id_observer' => 'observer_users',
            '_groups_id_assign' => 'assigned_groups',
            '_groups_id_observer' => 'observer_groups',
            '_users_id_requester' => 'requester_users',
            '_groups_id_requester' => 'requester_groups',
            '_suppliers_id_assign' => 'assigned_suppliers',
        ];
        $normalizedFields = [];
        foreach ($contracts as $field => $snapshotKey) {
            if (!array_key_exists($field, $fields)) {
                continue;
            }
            if (!is_array($fields[$field])) {
                return ['status' => 'rejected', 'changed_fields' => []];
            }
            $ids = $this->normalizeActorIdsForMutation($fields[$field]);
            if ($ids === null) {
                return ['status' => 'rejected', 'changed_fields' => []];
            }
            sort($ids, SORT_NUMERIC);
            $normalizedFields[$field] = $ids;
        }

        if ($normalizedFields === []) {
            return ['status' => 'unchanged', 'changed_fields' => []];
        }
        if ($expectedRevision === null || preg_match('/\A[a-f0-9]{64}\z/D', $expectedRevision) !== 1) {
            return ['status' => 'context_stale', 'changed_fields' => array_keys($normalizedFields)];
        }

        global $DB;
        if (
            !isset($DB)
            || !method_exists($DB, 'beginTransaction')
            || !method_exists($DB, 'commit')
            || !method_exists($DB, 'rollBack')
        ) {
            // Multiple actor relations cannot be safely reconciled without an
            // all-or-nothing boundary. GLPI 10 and 11 both provide it.
            return ['status' => 'rejected', 'changed_fields' => array_keys($normalizedFields)];
        }

        $transactionStarted = false;
        $before = null;
        $changedFields = array_keys($normalizedFields);
        try {
            if ($DB->beginTransaction() === false) {
                return ['status' => 'rejected', 'changed_fields' => $changedFields];
            }
            $transactionStarted = true;
            if (!$this->lockTicketForRouting($ticketId)) {
                throw new \RuntimeException('ticket_routing_lock_failed');
            }

            // Re-read only after acquiring the row lock. This baseline and the
            // authorization/diff plan therefore describe the same DB state.
            $before = $this->ticketRoutingActorSnapshot($ticketId);
            if ($before === null) {
                throw new \RuntimeException('ticket_routing_snapshot_failed');
            }
            if (
                !hash_equals($this->ticketRoutingSnapshotRevision($before), $expectedRevision)
            ) {
                if ($DB->rollBack() === false) {
                    throw new \RuntimeException('ticket_routing_rollback_failed');
                }
                $transactionStarted = false;
                return ['status' => 'context_stale', 'changed_fields' => array_keys($normalizedFields)];
            }

            $desired = $before;
            $changedFields = [];
            foreach ($contracts as $field => $snapshotKey) {
                if (!array_key_exists($field, $normalizedFields)) {
                    continue;
                }
                $desired[$snapshotKey] = $normalizedFields[$field];
                if ($normalizedFields[$field] !== $before[$snapshotKey]) {
                    $changedFields[] = $field;
                }
            }

            if ($changedFields === []) {
                if ($DB->commit() === false) {
                    throw new \RuntimeException('ticket_routing_commit_failed');
                }
                $transactionStarted = false;
                return ['status' => 'unchanged', 'changed_fields' => []];
            }

            // Authorize and build every role-specific operation before the
            // first write. Deletions and additions are separate native updates,
            // so a stale deletion list can never target a just-added relation.
            $plan = $this->ticketRoutingMutationPlan($ticketId, $normalizedFields);
            if ($plan === null) {
                throw new \RuntimeException('ticket_routing_plan_rejected');
            }
            foreach ($plan as $payload) {
                if (!$this->applyTicketRoutingPayload($ticketId, $payload)) {
                    throw new \RuntimeException('ticket_routing_native_update_failed');
                }
            }

            $after = $this->ticketRoutingActorSnapshot($ticketId);
            if ($after !== $desired) {
                throw new \RuntimeException('ticket_routing_verification_failed');
            }
            if ($DB->commit() === false) {
                throw new \RuntimeException('ticket_routing_commit_failed');
            }
            $transactionStarted = false;

            return ['status' => 'verified', 'changed_fields' => $changedFields];
        } catch (\Throwable) {
            if ($transactionStarted) {
                try {
                    $DB->rollBack();
                } catch (\Throwable) {
                    // The readback below decides whether the result is uncertain.
                }
            }
        }

        $afterRollback = $this->ticketRoutingActorSnapshot($ticketId);
        return $before !== null && $afterRollback === $before
            ? ['status' => 'rejected', 'changed_fields' => $changedFields]
            : ['status' => 'uncertain', 'changed_fields' => $changedFields];
    }

    /** @param mixed[] $ids @return int[]|null */
    private function normalizeActorIdsForMutation(array $ids): ?array
    {
        if (count($ids) > GlpiResourceSelectorProvider::MAX_SELECTED_IDS) {
            return null;
        }

        return array_values(array_unique(array_filter(
            array_map('intval', $ids),
            static fn(int $id): bool => $id > 0
        )));
    }

    private function lockTicketForRouting(int $ticketId): bool
    {
        global $DB;
        if ($ticketId <= 0 || !isset($DB) || !method_exists($DB, 'numrows')) {
            return false;
        }

        try {
            $result = GlpiDatabaseQuery::execute(
                $DB,
                'SELECT `id` FROM `glpi_tickets` WHERE `id` = ' . $ticketId . ' FOR UPDATE'
            );
            return $result !== false && (int) $DB->numrows($result) === 1;
        } catch (\Throwable) {
            return false;
        }
    }

    /**
     * @param array<string,int[]> $fields
     * @return array<int,array<string,mixed>>|null
     */
    private function ticketRoutingMutationPlan(int $ticketId, array $fields): ?array
    {
        $ticket = new \Ticket();
        if (
            !$ticket->getFromDB($ticketId)
            || !$ticket->canViewItem()
        ) {
            return null;
        }

        $assignmentRequested = array_key_exists('_users_id_assign', $fields)
            || array_key_exists('_groups_id_assign', $fields)
            || array_key_exists('_suppliers_id_assign', $fields);
        $observersRequested = array_key_exists('_users_id_observer', $fields)
            || array_key_exists('_groups_id_observer', $fields);
        $requestersRequested = array_key_exists('_users_id_requester', $fields)
            || array_key_exists('_groups_id_requester', $fields);
        if (
            ($assignmentRequested && !$this->canAssignTicketActors($ticketId))
            || ($observersRequested && !$this->canObserveTicketActors($ticketId))
            || ($requestersRequested && !$this->canAdminTicketRequesters($ticketId))
        ) {
            return null;
        }

        $operations = [];
        $userContracts = [
            '_users_id_requester' => [
                'type' => 1,
                'purpose' => GlpiResourceSelectorRegistry::REQUESTER_USER,
            ],
            '_users_id_assign' => [
                'type' => 2,
                'purpose' => GlpiResourceSelectorRegistry::ASSIGNED_USER,
            ],
            '_users_id_observer' => [
                'type' => 3,
                'purpose' => GlpiResourceSelectorRegistry::OBSERVER_USER,
            ],
        ];
        foreach ($userContracts as $field => $contract) {
            if (!array_key_exists($field, $fields)) {
                continue;
            }
            $authorization = $this->authorizedTicketUserIds(
                $ticketId,
                $fields[$field],
                (int) $contract['type'],
                (string) $contract['purpose']
            );
            if ($authorization === null) {
                return null;
            }
            $diff = $this->ticketUserDiffPayload(
                $ticketId,
                (int) $contract['type'],
                $authorization['desired'],
                $authorization['allowed'],
                $field
            );
            if ($diff === null) {
                return null;
            }
            $this->appendTicketRoutingRoleOperations($operations, $diff, $field);
        }

        $groupContracts = [
            '_groups_id_requester' => ['type' => 1, 'capability' => 'is_requester'],
            '_groups_id_assign' => ['type' => 2, 'capability' => 'is_assign'],
            '_groups_id_observer' => ['type' => 3, 'capability' => 'is_watcher'],
        ];
        foreach ($groupContracts as $field => $contract) {
            if (!array_key_exists($field, $fields)) {
                continue;
            }
            $authorization = $this->authorizedTicketGroupIds(
                $ticket,
                $fields[$field],
                (string) $contract['capability']
            );
            if ($authorization === null) {
                return null;
            }
            $diff = $this->ticketGroupDiffPayload(
                $ticketId,
                (int) $contract['type'],
                $authorization['desired'],
                $authorization['allowed'],
                $field
            );
            if ($diff === null) {
                return null;
            }
            $this->appendTicketRoutingRoleOperations($operations, $diff, $field);
        }

        if (array_key_exists('_suppliers_id_assign', $fields)) {
            $authorization = $this->authorizedTicketSupplierIds($ticket, $fields['_suppliers_id_assign']);
            if ($authorization === null) {
                return null;
            }
            $diff = $this->ticketSupplierDiffPayload(
                $ticketId,
                $authorization['desired'],
                $authorization['allowed']
            );
            if ($diff === null) {
                return null;
            }
            $this->appendTicketRoutingRoleOperations($operations, $diff, '_suppliers_id_assign');
        }

        return $operations;
    }

    /**
     * @param array<int,array<string,mixed>> $operations
     * @param array<string,mixed> $diff
     */
    private function appendTicketRoutingRoleOperations(array &$operations, array $diff, string $field): void
    {
        $deletedField = $field . '_deleted';
        if (!empty($diff[$deletedField]) && is_array($diff[$deletedField])) {
            $operations[] = [$deletedField => $diff[$deletedField]];
        }
        if (!empty($diff[$field]) && is_array($diff[$field])) {
            $operations[] = [$field => $diff[$field]];
        }
    }

    /** @param array<string,mixed> $payload */
    private function applyTicketRoutingPayload(int $ticketId, array $payload): bool
    {
        if ($payload === []) {
            return true;
        }

        $keys = array_keys($payload);
        $assignment = count(array_intersect($keys, [
            '_users_id_assign',
            '_users_id_assign_deleted',
            '_groups_id_assign',
            '_groups_id_assign_deleted',
            '_suppliers_id_assign',
            '_suppliers_id_assign_deleted',
        ])) > 0;
        $requesters = count(array_intersect($keys, [
            '_users_id_requester',
            '_users_id_requester_deleted',
            '_groups_id_requester',
            '_groups_id_requester_deleted',
        ])) > 0;
        $observers = count(array_intersect($keys, [
            '_users_id_observer',
            '_users_id_observer_deleted',
            '_groups_id_observer',
            '_groups_id_observer_deleted',
        ])) > 0;
        if (
            ($assignment && !$this->canAssignTicketActors($ticketId))
            || ($observers && !$this->canObserveTicketActors($ticketId))
            || ($requesters && !$this->canAdminTicketRequesters($ticketId))
        ) {
            return false;
        }

        $ticket = new \Ticket();
        if (!$ticket->getFromDB($ticketId) || !$ticket->canViewItem()) {
            return false;
        }

        return (bool) $ticket->update(['id' => $ticketId] + $payload);
    }

    /**
     * @return array{requester_users:int[],assigned_users:int[],observer_users:int[],requester_groups:int[],assigned_groups:int[],observer_groups:int[],assigned_suppliers:int[]}|null
     */
    private function ticketRoutingActorSnapshot(int $ticketId): ?array
    {
        $requesterUsers = $this->currentTicketUserIdsByType($ticketId, 1);
        $assignedUsers = $this->currentTicketUserIdsByType($ticketId, 2);
        $observerUsers = $this->currentTicketUserIdsByType($ticketId, 3);
        $requesterGroups = $this->currentTicketGroupIdsByType($ticketId, 1);
        $assignedGroups = $this->currentTicketGroupIdsByType($ticketId, 2);
        $observerGroups = $this->currentTicketGroupIdsByType($ticketId, 3);
        $assignedSuppliers = $this->currentTicketSupplierIds($ticketId);
        if (
            $requesterUsers === null
            || $assignedUsers === null
            || $observerUsers === null
            || $requesterGroups === null
            || $assignedGroups === null
            || $observerGroups === null
            || $assignedSuppliers === null
        ) {
            return null;
        }
        sort($requesterUsers, SORT_NUMERIC);
        sort($assignedUsers, SORT_NUMERIC);
        sort($observerUsers, SORT_NUMERIC);
        sort($requesterGroups, SORT_NUMERIC);
        sort($assignedGroups, SORT_NUMERIC);
        sort($observerGroups, SORT_NUMERIC);
        sort($assignedSuppliers, SORT_NUMERIC);

        return [
            'requester_users' => $requesterUsers,
            'assigned_users' => $assignedUsers,
            'observer_users' => $observerUsers,
            'requester_groups' => $requesterGroups,
            'assigned_groups' => $assignedGroups,
            'observer_groups' => $observerGroups,
            'assigned_suppliers' => $assignedSuppliers,
        ];
    }

    /** @param array{requester_users:int[],assigned_users:int[],observer_users:int[],requester_groups:int[],assigned_groups:int[],observer_groups:int[],assigned_suppliers:int[]} $snapshot */
    private function ticketRoutingSnapshotRevision(array $snapshot): string
    {
        $normalized = [];
        $roleKeys = [
            'requester_users',
            'assigned_users',
            'observer_users',
            'requester_groups',
            'assigned_groups',
            'observer_groups',
            'assigned_suppliers',
        ];
        foreach ($roleKeys as $key) {
            $ids = array_values(array_unique(array_map('intval', (array) ($snapshot[$key] ?? []))));
            sort($ids, SORT_NUMERIC);
            $normalized[$key] = $ids;
        }

        return hash('sha256', (string) json_encode($normalized, JSON_UNESCAPED_SLASHES));
    }

    /**
     * @param int[] $ids
     * @return array{desired:int[],allowed:int[]}|null
     */
    private function authorizedTicketGroupIds(\Ticket $ticket, array $ids, string $capability): ?array
    {
        if (!in_array($capability, ['is_assign', 'is_requester', 'is_watcher'], true)) {
            return null;
        }
        $ticketFields = is_array($ticket->fields ?? null) ? $ticket->fields : [];
        if (!array_key_exists('entities_id', $ticketFields)) {
            return null;
        }
        $type = $capability === 'is_requester' ? 1 : ($capability === 'is_assign' ? 2 : 3);
        $ticketId = (int) ($ticketFields['id'] ?? 0);
        if ($ticketId <= 0 && method_exists($ticket, 'getID')) {
            $ticketId = (int) $ticket->getID();
        }
        $current = $this->currentTicketGroupIdsByType($ticketId, $type);
        if ($current === null) {
            return null;
        }
        $additions = array_values(array_diff($ids, $current));
        if (
            !$this->exactActorGroupIdsAreEligible(
                $additions,
                $capability,
                (int) $ticketFields['entities_id']
            )
        ) {
            return null;
        }

        return [
            'desired' => $ids,
            'allowed' => $current,
        ];
    }

    /**
     * Revalidate every desired user against the exact role policy. Current
     * relations are accepted only as removal targets, so an inactive user or
     * one whose profile changed cannot make an otherwise authorized cleanup
     * impossible.
     *
     * @param int[] $ids
     * @return array{desired:int[],allowed:int[]}|null
     */
    private function authorizedTicketUserIds(
        int $ticketId,
        array $ids,
        int $type,
        string $purpose
    ): ?array {
        $purposes = [
            1 => GlpiResourceSelectorRegistry::REQUESTER_USER,
            2 => GlpiResourceSelectorRegistry::ASSIGNED_USER,
            3 => GlpiResourceSelectorRegistry::OBSERVER_USER,
        ];
        if (($purposes[$type] ?? '') !== $purpose || !class_exists('\Ticket_User')) {
            return null;
        }

        $current = $this->currentTicketUserIdsByType($ticketId, $type);
        if ($current === null) {
            return null;
        }

        $additions = array_values(array_diff($ids, $current));
        if (!$this->authorizeResourceSelectorIds($purpose, $additions, ['ticket_id' => $ticketId])) {
            return null;
        }

        return [
            'desired' => $ids,
            // A user who became inactive or lost the ticket profile may still
            // be removed by an operator who can route the ticket. Anonymous
            // e-mail relations remain untouched by ticketUserDiffPayload().
            'allowed' => $current,
        ];
    }

    /**
     * @param int[] $ids
     * @return array{desired:int[],allowed:int[]}|null
     */
    private function authorizedTicketSupplierIds(\Ticket $ticket, array $ids): ?array
    {
        $ticketFields = is_array($ticket->fields ?? null) ? $ticket->fields : [];
        $ticketId = (int) ($ticketFields['id'] ?? 0);
        $entityId = (int) ($ticketFields['entities_id'] ?? -1);
        if ($ticketId <= 0 || $entityId < 0) {
            return null;
        }
        $current = $this->currentTicketSupplierIds($ticketId);
        if ($current === null) {
            return null;
        }
        $additions = array_values(array_diff($ids, $current));
        if (!$this->exactActorSupplierIdsAreEligible($additions, $entityId)) {
            return null;
        }

        return ['desired' => $ids, 'allowed' => $current];
    }

    /** @return int[]|null */
    private function currentTicketUserIdsByType(int $ticketId, int $type): ?array
    {
        if (!class_exists('\Ticket_User') || !in_array($type, [1, 2, 3], true)) {
            return null;
        }
        $model = new \Ticket_User();
        if (!method_exists($model, 'find')) {
            return null;
        }

        $ids = [];
        foreach ($model->find(['tickets_id' => $ticketId, 'type' => $type]) as $row) {
            $relationId = (int) ($row['id'] ?? 0);
            $userId = (int) ($row['users_id'] ?? 0);
            if ($relationId <= 0) {
                return null;
            }
            if ($userId > 0) {
                $ids[$userId] = $userId;
            }
        }

        return array_values($ids);
    }

    /** @return int[]|null */
    private function currentTicketGroupIdsByType(int $ticketId, int $type): ?array
    {
        if (!class_exists('\Group_Ticket') || !in_array($type, [1, 2, 3], true)) {
            return null;
        }
        $model = new \Group_Ticket();
        if (!method_exists($model, 'find')) {
            return null;
        }

        $ids = [];
        foreach ($model->find(['tickets_id' => $ticketId, 'type' => $type]) as $row) {
            $relationId = (int) ($row['id'] ?? 0);
            $groupId = (int) ($row['groups_id'] ?? 0);
            if ($relationId <= 0 || $groupId <= 0) {
                return null;
            }
            $ids[$groupId] = $groupId;
        }

        return array_values($ids);
    }

    /** @return int[]|null */
    private function currentTicketSupplierIds(int $ticketId): ?array
    {
        if (!class_exists('\Supplier_Ticket')) {
            return null;
        }
        $model = new \Supplier_Ticket();
        if (!method_exists($model, 'find')) {
            return null;
        }
        $ids = [];
        foreach ($model->find(['tickets_id' => $ticketId, 'type' => 2]) as $row) {
            $relationId = (int) ($row['id'] ?? 0);
            $supplierId = (int) ($row['suppliers_id'] ?? 0);
            if ($relationId <= 0 || $supplierId <= 0) {
                return null;
            }
            $ids[$supplierId] = $supplierId;
        }

        return array_values($ids);
    }

    /**
     * @param int[] $desiredIds
     * @param int[] $removableIds
     * @return array<string,mixed>|null
     */
    private function ticketSupplierDiffPayload(
        int $ticketId,
        array $desiredIds,
        array $removableIds
    ): ?array {
        if (!class_exists('\Supplier_Ticket')) {
            return null;
        }
        $model = new \Supplier_Ticket();
        if (!method_exists($model, 'find')) {
            return null;
        }
        $current = [];
        foreach ($model->find(['tickets_id' => $ticketId, 'type' => 2]) as $row) {
            $relationId = (int) ($row['id'] ?? 0);
            $supplierId = (int) ($row['suppliers_id'] ?? 0);
            if ($relationId <= 0 || $supplierId <= 0) {
                return null;
            }
            $current[$supplierId][] = $relationId;
        }

        $desired = array_fill_keys($desiredIds, true);
        $removable = array_fill_keys($removableIds, true);
        $deleteIds = [];
        foreach ($current as $supplierId => $relationIds) {
            if (!isset($desired[$supplierId])) {
                if (isset($removable[$supplierId])) {
                    array_push($deleteIds, ...$relationIds);
                }
                continue;
            }
            array_push($deleteIds, ...array_slice($relationIds, 1));
        }
        $addIds = array_values(array_filter(
            $desiredIds,
            static fn(int $supplierId): bool => !isset($current[$supplierId])
        ));

        $payload = [];
        if ($addIds !== []) {
            $payload['_suppliers_id_assign'] = $addIds;
        }
        if ($deleteIds !== []) {
            $payload['_suppliers_id_assign_deleted'] = array_map(
                static fn(int $relationId): array => [
                    'itemtype' => \Supplier::class,
                    'id' => $relationId,
                ],
                $deleteIds
            );
        }

        return $payload;
    }

    /**
     * Build a native actor diff for one group role only. Relation IDs are used
     * for deletions so users, suppliers and the opposite group role survive.
     *
     * @param int[] $desiredIds
     * @param int[] $removableIds
     * @return array<string,mixed>|null
     */
    private function ticketGroupDiffPayload(
        int $ticketId,
        int $type,
        array $desiredIds,
        array $removableIds,
        string $field
    ): ?array {
        $contracts = [
            1 => '_groups_id_requester',
            2 => '_groups_id_assign',
            3 => '_groups_id_observer',
        ];
        if (
            !class_exists('\Group_Ticket')
            || ($contracts[$type] ?? '') !== $field
        ) {
            return null;
        }

        $model = new \Group_Ticket();
        if (!method_exists($model, 'find')) {
            return null;
        }
        $current = [];
        foreach ($model->find(['tickets_id' => $ticketId, 'type' => $type]) as $row) {
            $relationId = (int) ($row['id'] ?? 0);
            $groupId = (int) ($row['groups_id'] ?? 0);
            if ($relationId <= 0 || $groupId <= 0) {
                return null;
            }
            $current[$groupId][] = $relationId;
        }

        $desired = array_fill_keys($desiredIds, true);
        $removable = array_fill_keys($removableIds, true);
        $deleteIds = [];
        foreach ($current as $groupId => $relationIds) {
            if (!isset($desired[$groupId])) {
                if (isset($removable[$groupId])) {
                    array_push($deleteIds, ...$relationIds);
                }
                continue;
            }
            array_push($deleteIds, ...array_slice($relationIds, 1));
        }
        $addIds = array_values(array_filter(
            $desiredIds,
            static fn(int $groupId): bool => !isset($current[$groupId])
        ));

        $payload = [];
        if ($addIds !== []) {
            $payload[$field] = $addIds;
        }
        if ($deleteIds !== []) {
            $payload[$field . '_deleted'] = array_map(
                static fn(int $relationId): array => [
                    'itemtype' => \Group::class,
                    'id' => $relationId,
                ],
                $deleteIds
            );
        }

        return $payload;
    }

    /**
     * Build a native actor diff for one user role only. The GLPI update
     * contract receives additions or relation deletions only when non-empty;
     * requester users and the opposite user role are never loaded or changed.
     *
     * @param int[] $desiredIds
     * @param int[] $removableIds
     * @return array<string,mixed>|null
     */
    private function ticketUserDiffPayload(
        int $ticketId,
        int $type,
        array $desiredIds,
        array $removableIds,
        string $field
    ): ?array {
        $contracts = [
            1 => '_users_id_requester',
            2 => '_users_id_assign',
            3 => '_users_id_observer',
        ];
        if (
            !class_exists('\Ticket_User')
            || ($contracts[$type] ?? '') !== $field
        ) {
            return null;
        }

        $model = new \Ticket_User();
        if (!method_exists($model, 'find')) {
            return null;
        }
        $current = [];
        foreach ($model->find(['tickets_id' => $ticketId, 'type' => $type]) as $row) {
            $relationId = (int) ($row['id'] ?? 0);
            $userId = (int) ($row['users_id'] ?? 0);
            if ($relationId <= 0) {
                return null;
            }
            // Anonymous e-mail actors are not represented by this selector.
            if ($userId <= 0) {
                continue;
            }
            $current[$userId][] = $relationId;
        }

        $desired = array_fill_keys($desiredIds, true);
        $removable = array_fill_keys($removableIds, true);
        $deleteIds = [];
        foreach ($current as $userId => $relationIds) {
            if (!isset($desired[$userId])) {
                if (isset($removable[$userId])) {
                    array_push($deleteIds, ...$relationIds);
                }
                continue;
            }
            array_push($deleteIds, ...array_slice($relationIds, 1));
        }
        $addIds = array_values(array_filter(
            $desiredIds,
            static fn(int $userId): bool => !isset($current[$userId])
        ));

        $payload = [];
        if ($addIds !== []) {
            $payload[$field] = $addIds;
        }
        if ($deleteIds !== []) {
            $payload[$field . '_deleted'] = array_map(
                static fn(int $relationId): array => [
                    'itemtype' => \User::class,
                    'id' => $relationId,
                ],
                $deleteIds
            );
        }

        return $payload;
    }
    public function canReadTicket(int $ticketId): bool
    {
        $ticket = new \Ticket();
        return $ticket->can(max(1, $ticketId), READ);
    }

    public function canUpdateTicket(int $ticketId): bool
    {
        $ticketId = max(1, $ticketId);
        $ticket = new \Ticket();
        try {
            if (method_exists($ticket, 'can')) {
                return (bool) $ticket->can($ticketId, UPDATE);
            }

            return $ticket->getFromDB($ticketId)
                && $ticket->canViewItem()
                && \Ticket::canUpdate();
        } catch (\Throwable $e) {
            return false;
        }
    }

    public function canRouteTicket(int $ticketId): bool
    {
        return $this->canAssignTicketActors($ticketId)
            || $this->canObserveTicketActors($ticketId)
            || $this->canAdminTicketRequesters($ticketId);
    }

    public function canAssignTicketActors(int $ticketId): bool
    {
        $ticket = $this->readableTicketForActorAdministration($ticketId);
        if ($ticket === null) {
            return false;
        }

        try {
            return method_exists($ticket, 'canAssign')
                && (bool) $ticket->canAssign();
        } catch (\Throwable) {
            return false;
        }
    }

    public function canSelfAssignTicket(int $ticketId): bool
    {
        return !empty($this->getTicketSelfAssignmentContext($ticketId)['can_self_assign']);
    }

    /**
     * The native canAssignToMe() gate is deliberately independent of canAssign()
     * and UPDATE. In particular, an OWN-only user may see the native operation
     * while the core subsequently rejects its update; persisted readback wins.
     *
     * @return array{readable:bool,can_self_assign:bool,already_assigned:?bool,revision:string,user_id:int,ticket:?object}
     */
    private function getTicketSelfAssignmentContext(int $ticketId): array
    {
        $context = [
            'readable' => false,
            'can_self_assign' => false,
            'already_assigned' => null,
            'revision' => '',
            'user_id' => 0,
            'ticket' => null,
        ];
        if (
            $ticketId <= 0
            || !class_exists('\Ticket')
            || !class_exists('\Session')
            || !method_exists('\Session', 'getLoginUserID')
            || !defined('READ')
        ) {
            return $context;
        }

        try {
            $userId = max(0, (int) \Session::getLoginUserID());
            $context['user_id'] = $userId;
            if ($userId <= 0) {
                return $context;
            }
            $ticket = new \Ticket();
            if (
                !method_exists($ticket, 'can')
                || !$ticket->can($ticketId, READ)
                || !$ticket->getFromDB($ticketId)
                || !$ticket->canViewItem()
            ) {
                return $context;
            }
            $fields = is_array($ticket->fields ?? null) ? $ticket->fields : [];
            $entityId = (int) ($fields['entities_id'] ?? -1);
            if (
                (int) ($fields['id'] ?? 0) !== $ticketId
                || $entityId < 0
                || (
                    method_exists('\Session', 'haveAccessToEntity')
                    && !\Session::haveAccessToEntity($entityId, false)
                )
            ) {
                return $context;
            }
            $context['readable'] = true;
            $context['ticket'] = $ticket;
            $assignedUsers = $this->ticketSelfAssignmentUserIds($ticketId);
            if ($assignedUsers === null) {
                return $context;
            }
            $context['already_assigned'] = in_array($userId, $assignedUsers, true);
            $context['can_self_assign'] = !$context['already_assigned']
                && empty($fields['is_deleted'])
                && (int) ($fields['status'] ?? 0) !== $this->closedStatus()
                && method_exists($ticket, 'canAssignToMe')
                && (bool) $ticket->canAssignToMe();
            $context['revision'] = $this->ticketSelfAssignmentRevision($fields, $assignedUsers, $userId);
            return $context;
        } catch (\Throwable) {
            // Preserve readable/known relation evidence only. No exception may
            // accidentally turn an unavailable native gate into permission.
            $context['can_self_assign'] = false;
            $context['revision'] = '';
            return $context;
        }
    }

    /** @return int[]|null */
    private function ticketSelfAssignmentUserIds(int $ticketId): ?array
    {
        if (!class_exists('\Ticket_User')) {
            return null;
        }
        $model = new \Ticket_User();
        if (!method_exists($model, 'find')) {
            return null;
        }
        $rows = $model->find(['tickets_id' => $ticketId, 'type' => 2]);
        if (!is_iterable($rows)) {
            return null;
        }
        $ids = [];
        foreach ($rows as $row) {
            if (
                !is_array($row)
                || (int) ($row['id'] ?? 0) <= 0
                || (int) ($row['tickets_id'] ?? 0) !== $ticketId
                || (int) ($row['type'] ?? 0) !== 2
                || !array_key_exists('users_id', $row)
                || (int) $row['users_id'] < 0
            ) {
                return null;
            }
            // Native countUsers(ASSIGN) also counts anonymous (user 0) actors.
            // Keep that presence in the revision, never as the session identity.
            $userId = (int) $row['users_id'];
            $ids[$userId] = $userId;
        }
        $ids = array_values($ids);
        sort($ids, SORT_NUMERIC);
        return $ids;
    }

    /** @param array<string,mixed> $fields @param int[] $assignedUsers */
    private function ticketSelfAssignmentRevision(array $fields, array $assignedUsers, int $userId): string
    {
        $activeEntities = array_values(array_unique(array_map('intval', (array) ($_SESSION['glpiactiveentities'] ?? []))));
        sort($activeEntities, SORT_NUMERIC);
        $scope = [
            'user_id' => $userId,
            'profile_id' => (int) ($_SESSION['glpiactiveprofile']['id'] ?? 0),
            'interface' => (string) ($_SESSION['glpiactiveprofile']['interface'] ?? ''),
            'ticket_rights' => (int) ($_SESSION['glpiactiveprofile']['ticket'] ?? 0),
            'active_entity' => (string) ($_SESSION['glpiactive_entity'] ?? ''),
            'active_entities' => $activeEntities,
            'recursive' => !empty($_SESSION['glpiactive_entity_recursive']),
            'groups' => $this->currentUserGroupContext(),
        ];
        $revision = [
            'operation' => 'ticket.self-assign.v1',
            'ticket_id' => (int) ($fields['id'] ?? 0),
            'entity_id' => (int) ($fields['entities_id'] ?? -1),
            'status' => (int) ($fields['status'] ?? 0),
            'deleted' => !empty($fields['is_deleted']),
            'date_mod' => (string) ($fields['date_mod'] ?? ''),
            'assigned_users' => $assignedUsers,
            'session' => $scope,
        ];

        return hash('sha256', (string) json_encode($revision, JSON_UNESCAPED_SLASHES | JSON_THROW_ON_ERROR));
    }

    public function canObserveTicketActors(int $ticketId): bool
    {
        $ticket = $this->readableTicketForActorAdministration($ticketId);
        if ($ticket === null) {
            return false;
        }

        try {
            return method_exists($ticket, 'canAdminActors')
                && (bool) $ticket->canAdminActors();
        } catch (\Throwable) {
            return false;
        }
    }

    public function canAdminTicketRequesters(int $ticketId): bool
    {
        $ticket = $this->readableTicketForActorAdministration($ticketId);
        if ($ticket === null || !$this->canUpdateTicket($ticketId)) {
            return false;
        }

        try {
            return method_exists($ticket, 'canAdminActors')
                && (bool) $ticket->canAdminActors();
        } catch (\Throwable) {
            return false;
        }
    }

    private function readableTicketForActorAdministration(int $ticketId): ?object
    {
        if ($ticketId <= 0 || !$this->canReadTicket($ticketId)) {
            return null;
        }

        try {
            $ticket = new \Ticket();
            return $ticket->getFromDB($ticketId) && $ticket->canViewItem()
                ? $ticket
                : null;
        } catch (\Throwable) {
            return null;
        }
    }

    public function canAddFollowupToTicket(int $ticketId, int $isPrivate = 0): bool
    {
        if ($ticketId <= 0 || !$this->canReadTicket($ticketId) || !class_exists('\ITILFollowup')) {
            return false;
        }
        try {
            $followup = new \ITILFollowup();
            $input = [
                'itemtype' => 'Ticket',
                'items_id' => $ticketId,
                'content' => 'Verificação de permissão',
                'users_id' => (int) ($_SESSION['glpiID'] ?? 0),
                'is_private' => $isPrivate === 1 ? 1 : 0,
            ];
            $followup->input = $input;
            $followup->fields = $input;

            if (method_exists($followup, 'can')) {
                return (bool) $followup->can(-1, CREATE, $input);
            }
            if (method_exists($followup, 'canCreateItem')) {
                return (bool) $followup->canCreateItem();
            }
        } catch (\Throwable $e) {
            return false;
        }

        return false;
    }

    public function canAddTaskToTicket(int $ticketId, int $isPrivate = 0): bool
    {
        if ($ticketId <= 0 || !$this->canReadTicket($ticketId) || !class_exists('\TicketTask')) {
            return false;
        }
        try {
            $task = new \TicketTask();
            $input = [
                'tickets_id' => $ticketId,
                'content' => 'Verificação de permissão',
                'users_id_tech' => (int) ($_SESSION['glpiID'] ?? 0),
                'is_private' => $isPrivate === 1 ? 1 : 0,
            ];
            $task->input = $input;
            $task->fields = $input;

            if (method_exists($task, 'can')) {
                return (bool) $task->can(-1, CREATE, $input);
            }
            if (method_exists($task, 'canCreateItem')) {
                return (bool) $task->canCreateItem();
            }
        } catch (\Throwable $e) {
            return false;
        }

        return false;
    }

    /**
     * Describe whether a previous native solution still requires status
     * reconciliation. A non-refused solution on a non-terminal ticket is an
     * inconsistent native state and must not be duplicated by this portal.
     *
     * @return array{state:string,solution_id:int,solution_status:int,ticket_status:int}
     */
    public function getSolutionOperationState(int $ticketId): array
    {
        $state = $this->emptySolutionOperationState('unavailable');
        if (
            $ticketId <= 0
            || !$this->canReadTicket($ticketId)
            || !class_exists('\\Ticket')
            || !class_exists('\\ITILSolution')
        ) {
            return $state;
        }

        try {
            $ticket = new \Ticket();
            if (!$ticket->getFromDB($ticketId)) {
                return $state;
            }

            $ticketStatus = (int) ($ticket->fields['status'] ?? 0);
            $state['ticket_status'] = $ticketStatus;
            if (in_array($ticketStatus, [$this->solvedStatus(), $this->closedStatus()], true)) {
                // Cleanup is housekeeping. A confirmed native terminal state
                // must not be reclassified if deleting a stale marker fails.
                try {
                    $this->clearSolutionOperationPartial($ticketId);
                } catch (\Throwable) {
                    // The terminal ticket remains authoritative.
                }
                $state['state'] = 'terminal';
                return $state;
            }

            $operation = null;
            if ($this->solutionIdempotencyLedger instanceof IdempotencyLedger) {
                $persistent = $this->solutionIdempotencyLedger->latestPartial(
                    'ticket.solution:' . $ticketId
                );
                if (
                    is_array($persistent)
                    && !hash_equals(
                        (string) ($persistent['operation_key_hash'] ?? ''),
                        (string) ($this->activeSolutionGuardKeyHash ?? '')
                    )
                ) {
                    $operation = ['solution_id' => max(0, (int) ($persistent['result_id'] ?? 0))];
                }
            }
            if ($operation === null) {
                $operations = is_array($_SESSION[self::SOLUTION_OPERATION_SESSION_KEY] ?? null)
                    ? $_SESSION[self::SOLUTION_OPERATION_SESSION_KEY]
                    : [];
                $operation = is_array($operations[$ticketId] ?? null)
                    ? $operations[$ticketId]
                    : null;
            }
            if ($operation === null) {
                $state['state'] = 'ready';
                return $state;
            }

            $state['solution_id'] = max(0, (int) ($operation['solution_id'] ?? 0));
            if ($state['solution_id'] <= 0) {
                $state['state'] = 'partial';
                return $state;
            }

            $solution = new \ITILSolution();
            if (!$solution->getFromDB($state['solution_id'])) {
                // A failed read does not prove that a mutation was rolled back.
                // Keep the shared guard until positive reconciliation.
                $state['state'] = 'partial';
                return $state;
            }
            $fields = is_array($solution->fields ?? null) ? $solution->fields : [];
            if (
                (string) ($fields['itemtype'] ?? '') !== 'Ticket'
                || (int) ($fields['items_id'] ?? 0) !== $ticketId
            ) {
                $state['state'] = 'partial';
                return $state;
            }

            $state['solution_status'] = max(0, (int) ($fields['status'] ?? 0));
            if ($state['solution_status'] === $this->refusedSolutionStatus()) {
                $state['state'] = $this->clearSolutionOperationPartial($ticketId)
                    ? 'ready'
                    : 'unavailable';
                return $state;
            }
            $state['state'] = 'partial';
            return $state;
        } catch (\Throwable) {
            return $state;
        }
    }

    public function rememberSolutionOperationPartial(int $ticketId, int $solutionId = 0): bool
    {
        if ($ticketId <= 0) {
            return false;
        }
        if (
            !isset($_SESSION[self::SOLUTION_OPERATION_SESSION_KEY])
            || !is_array($_SESSION[self::SOLUTION_OPERATION_SESSION_KEY])
        ) {
            $_SESSION[self::SOLUTION_OPERATION_SESSION_KEY] = [];
        }
        $_SESSION[self::SOLUTION_OPERATION_SESSION_KEY][$ticketId] = [
            'solution_id' => max(0, $solutionId),
            'recorded_at' => time(),
        ];
        if (!$this->solutionIdempotencyLedger instanceof IdempotencyLedger) {
            return false;
        }
        $scope = 'ticket.solution:' . $ticketId;
        if ($this->solutionIdempotencyLedger->latestPartial($scope) !== null) {
            return true;
        }
        $operationKey = hash('sha256', 'ticket.solution.partial:' . $ticketId . ':' . max(0, $solutionId));
        $requestHash = hash('sha256', 'ticket.solution.reconcile:' . $ticketId . ':' . max(0, $solutionId));
        if (
            !$this->solutionIdempotencyLedger->recordPartial(
                $scope,
                $operationKey,
                $requestHash,
                $solutionId
            )
        ) {
            throw new \RuntimeException('solution_partial_marker_persist_failed');
        }
        return true;
    }

    public function clearSolutionOperationPartial(int $ticketId): bool
    {
        if ($ticketId > 0 && isset($_SESSION[self::SOLUTION_OPERATION_SESSION_KEY][$ticketId])) {
            unset($_SESSION[self::SOLUTION_OPERATION_SESSION_KEY][$ticketId]);
        }
        if ($ticketId > 0 && $this->solutionIdempotencyLedger instanceof IdempotencyLedger) {
            return $this->solutionIdempotencyLedger->clearPartials('ticket.solution:' . $ticketId);
        }
        return true;
    }

    /** @return array{state:string,solution_id:int,solution_status:int,ticket_status:int} */
    private function emptySolutionOperationState(string $state): array
    {
        return [
            'state' => $state,
            'solution_id' => 0,
            'solution_status' => 0,
            'ticket_status' => 0,
        ];
    }

    public function canAddSolutionToTicket(int $ticketId): bool
    {
        if ($ticketId <= 0 || !$this->canReadTicket($ticketId) || !class_exists('\ITILSolution')) {
            return false;
        }

        try {
            $ticket = new \Ticket();
            if (!$ticket->getFromDB($ticketId)) {
                return false;
            }

            // Match the predicate used by CommonITILObject's native timeline.
            // The concrete ITILSolution CREATE check is repeated on POST with
            // the final payload immediately before the single native add.
            return $this->passesNativeSolutionTicketGate($ticket, true);
        } catch (\Throwable $e) {
            return false;
        }

        return false;
    }

    public function canAttemptSolutionToTicket(int $ticketId): bool
    {
        if ($ticketId <= 0 || !$this->canReadTicket($ticketId) || !class_exists('\ITILSolution')) {
            return false;
        }

        try {
            $ticket = new \Ticket();
            return $ticket->getFromDB($ticketId)
                && $this->passesNativeSolutionTicketGate($ticket, false);
        } catch (\Throwable) {
            return false;
        }
    }

    public function canChangeStatusToTicket(int $ticketId): bool
    {
        if ($ticketId <= 0) {
            return false;
        }
        if (!$this->canUpdateTicket($ticketId)) {
            return false;
        }

        if (!class_exists('\Ticket') || !method_exists('\Ticket', 'canUpdate') || !\Ticket::canUpdate()) {
            return false;
        }

        return $this->getAllowedStatusTransitions($ticketId) !== [];
    }

    /**
     * Return only transitions accepted by the native GLPI status matrix.
     *
     * @return int[]
     */
    public function getAllowedStatusTransitions(int $ticketId): array
    {
        if ($ticketId <= 0) {
            return [];
        }
        if (!$this->canReadTicket($ticketId)) {
            return [];
        }

        $ticket = new \Ticket();
        try {
            if (!$ticket->getFromDB($ticketId)) {
                return [];
            }
            $currentStatus = (int) ($ticket->fields['status'] ?? 0);
            if ($currentStatus <= 0 || !class_exists('\Ticket') || !method_exists('\Ticket', 'getAllowedStatusArray')) {
                return [];
            }

            $allowed = (array) \Ticket::getAllowedStatusArray($currentStatus);
            $transitions = [];
            foreach ($allowed as $key => $value) {
                $candidate = is_int($key) || ctype_digit((string) $key) ? (int) $key : (int) $value;
                if ($candidate > 0 && $candidate !== $currentStatus) {
                    $transitions[] = $candidate;
                }
            }

            return array_values(array_unique($transitions));
        } catch (\Throwable $e) {
            return [];
        }
    }

    public function isStatusTransitionAllowed(int $ticketId, int $newStatus): bool
    {
        if ($ticketId <= 0) {
            return false;
        }
        $newStatus = (int) $newStatus;
        if ($newStatus <= 0 || !$this->canChangeStatusToTicket($ticketId)) {
            return false;
        }

        return in_array($newStatus, $this->getAllowedStatusTransitions($ticketId), true);
    }

    /**
     * @return array<int, array{id:int,name:string}>
     */
    private function getTicketAssignedGroups(int $ticketId): array
    {
        if (!class_exists('\Group_Ticket')) {
            return [];
        }

        $ticketId = max(1, $ticketId);
        $groups = [];
        $groupTicket = new \Group_Ticket();
        foreach ($groupTicket->find(['tickets_id' => $ticketId, 'type' => 2]) as $row) {
            $groupId = (int) ($row['groups_id'] ?? 0);
            if ($groupId > 0) {
                $groups[] = [
                    'id' => $groupId,
                    'name' => $this->resolveGroupName($groupId),
                ];
            }
        }

        usort($groups, static fn(array $left, array $right): int => strcasecmp((string) ($left['name'] ?? ''), (string) ($right['name'] ?? '')));

        return $groups;
    }

    /**
     * @return array<string, array<string, mixed>>
     */
    private function getTicketCreationFieldRequirements(): array
    {
        $fields = [];
        foreach (TicketCreationPolicy::SUPPORTED_CREATE_FIELDS as $field) {
            $fields[$field] = [
                'label' => TicketCreationPolicy::fieldLabel($field),
                'required' => in_array($field, ['name', 'content', 'type', 'urgency', 'impact'], true),
                'visible' => true,
                'readonly' => false,
                'source' => 'portal_default',
            ];
        }

        return $fields;
    }

    /**
     * @return array<int, array<string, mixed>>
     */
    private function getTicketTemplates(): array
    {
        if (!class_exists('\TicketTemplate')) {
            return [];
        }

        $template = new \TicketTemplate();
        $table = method_exists('\TicketTemplate', 'getTable') ? (string) \TicketTemplate::getTable() : 'glpi_tickettemplates';
        if (!$this->tableExists($table)) {
            return [];
        }

        $criteria = [];
        if ($this->columnExists($table, 'is_active')) {
            $criteria['is_active'] = 1;
        }

        $templates = [];
        foreach ($template->find($criteria, 'name ASC', 80) as $row) {
            $id = (int) ($row['id'] ?? 0);
            $name = trim((string) ($row['name'] ?? ''));
            if ($id <= 0 || $name === '') {
                continue;
            }
            $entityId = (int) ($row['entities_id'] ?? 0);
            $recursive = (bool) ($row['is_recursive'] ?? false);
            if (!$this->canUseTemplateEntity($entityId, $recursive)) {
                continue;
            }

            $metadata = $this->getTicketTemplateMetadata($id);
            if ($metadata !== null) {
                $templates[] = $metadata;
            }
        }

        return $templates;
    }

    /**
     * @return array<string, mixed>|null
     */
    public function getTicketTemplateMetadata(int $templateId): ?array
    {
        if ($templateId <= 0 || !class_exists('\TicketTemplate')) {
            return null;
        }

        try {
            $template = new \TicketTemplate();
            $loaded = method_exists($template, 'getFromDBWithData')
                ? $template->getFromDBWithData($templateId)
                : $template->getFromDB($templateId);
            if (!$loaded) {
                return null;
            }

            $entityId = (int) ($template->fields['entities_id'] ?? 0);
            $recursive = !empty($template->fields['is_recursive']);
            if (!$this->canUseTemplateEntity($entityId, $recursive)) {
                return null;
            }

            $mandatory = $this->normalizeTicketTemplateFieldList($template->mandatory ?? []);
            $hidden = $this->normalizeTicketTemplateFieldList($template->hidden ?? []);
            $readonly = $this->normalizeTicketTemplateFieldList($template->readonly ?? []);
            $predefined = $this->normalizeTicketTemplatePredefinedFields((array) ($template->predefined ?? []));
            $policy = new TicketCreationPolicy();
            $unsupportedRequired = $policy->unsupportedMandatoryFields($mandatory);
            $fieldRequirements = [];
            foreach ($mandatory as $field) {
                $fieldRequirements[$field] = [
                    'label' => TicketCreationPolicy::fieldLabel($field),
                    'required' => true,
                    'visible' => !in_array($field, $hidden, true),
                    'readonly' => in_array($field, $readonly, true),
                    'source' => 'ticket_template',
                ];
            }

            $supportedPredefined = [];
            $supported = array_fill_keys(TicketCreationPolicy::SUPPORTED_CREATE_FIELDS, true);
            foreach ($predefined as $field => $value) {
                if (isset($supported[(string) $field])) {
                    $supportedPredefined[(string) $field] = $value;
                }
            }

            return [
                'id' => $templateId,
                'label' => TextNormalizer::fromGlpi((string) ($template->fields['name'] ?? ('Modelo #' . $templateId))),
                'field_requirements' => $fieldRequirements,
                'mandatory_fields' => $mandatory,
                'hidden_fields' => $hidden,
                'readonly_fields' => $readonly,
                'predefined' => $supportedPredefined,
                'unsupported_required' => $unsupportedRequired,
                'requires_native_fallback' => $unsupportedRequired !== [],
            ];
        } catch (\Throwable $e) {
            return null;
        }
    }

    /**
     * @return string[]
     */
    private function normalizeTicketTemplateFieldList(mixed $fields): array
    {
        if (!is_array($fields)) {
            return [];
        }

        $normalized = [];
        foreach ($fields as $key => $value) {
            $field = '';
            if (is_string($key) && !ctype_digit($key)) {
                $field = $key;
            } elseif (is_array($value)) {
                foreach (['field', 'name', 'num'] as $candidateKey) {
                    if (isset($value[$candidateKey]) && is_scalar($value[$candidateKey])) {
                        $field = $this->resolveTicketTemplateFieldName($value[$candidateKey]);
                        break;
                    }
                }
            } elseif (is_scalar($value)) {
                $field = $this->resolveTicketTemplateFieldName($value);
            }

            $field = trim($field);
            if ($field !== '') {
                $normalized[$field] = $field;
            }
        }

        return array_values($normalized);
    }

    /**
     * @param array<string|int, mixed> $predefined
     * @return array<string, mixed>
     */
    private function normalizeTicketTemplatePredefinedFields(array $predefined): array
    {
        $normalized = [];
        foreach ($predefined as $field => $value) {
            $resolved = $this->resolveTicketTemplateFieldName($field);
            if ($resolved === '') {
                continue;
            }
            $normalized[$resolved] = $value;
        }

        return $normalized;
    }

    private function resolveTicketTemplateFieldName(mixed $field): string
    {
        if (!is_scalar($field)) {
            return '';
        }

        $field = trim((string) $field);
        if ($field === '') {
            return '';
        }

        if (ctype_digit($field)) {
            $resolved = $this->ticketSearchOptionToCreateField((int) $field);
            return $resolved !== '' ? $resolved : 'search_option_' . $field;
        }

        return $field;
    }

    private function ticketSearchOptionToCreateField(int $optionNumber): string
    {
        if ($optionNumber <= 0 || !class_exists('\Search') || !class_exists('\Ticket') || !method_exists('\Search', 'getOptions')) {
            return '';
        }

        $supported = array_fill_keys(TicketCreationPolicy::SUPPORTED_CREATE_FIELDS, true);
        $tableMap = [
            'glpi_itilcategories' => 'itilcategories_id',
            'glpi_locations' => 'locations_id',
            'glpi_requesttypes' => 'requesttypes_id',
            'glpi_groups' => '_groups_id_assign',
            'glpi_users' => '_users_id_assign',
        ];

        $options = (array) \Search::getOptions(\Ticket::class);
        $option = is_array($options[$optionNumber] ?? null) ? $options[$optionNumber] : null;
        if ($option === null) {
            return '';
        }

        foreach (['linkfield', 'field'] as $key) {
            $candidate = trim((string) ($option[$key] ?? ''));
            if ($candidate !== '' && isset($supported[$candidate])) {
                return $candidate;
            }
        }

        $table = trim((string) ($option['table'] ?? ''));
        if ($table !== '' && isset($tableMap[$table])) {
            return $tableMap[$table];
        }

        return '';
    }

    /**
     * @return array<string, mixed>
     */
    private function getServiceCatalogContext(): array
    {
        global $CFG_GLPI;

        $available = class_exists('\Glpi\Form\ServiceCatalog\ServiceCatalog')
            || class_exists('\Glpi\Controller\ServiceCatalog\IndexController');
        $enabled = false;
        $entityId = (int) ($_SESSION['glpiactive_entity'] ?? 0);
        if ($available && class_exists('\Entity') && $entityId >= 0) {
            try {
                $entity = new \Entity();
                if ($entity->getFromDB($entityId) && method_exists($entity, 'isServiceCatalogEnabled')) {
                    $enabled = (bool) $entity->isServiceCatalogEnabled();
                }
            } catch (\Throwable $e) {
                $enabled = false;
            }
        }

        return [
            'available' => $available,
            'enabled' => $enabled,
            'url' => (string) ($CFG_GLPI['root_doc'] ?? '') . '/ServiceCatalog',
            'message' => $available
                ? I18n::translate('O GLPI 11 possui Catálogo de Serviços. Use o fluxo nativo quando a solicitação exigir formulário dinâmico ainda não representado aqui.')
                : I18n::translate('Catálogo de Serviços não disponível nesta versão/instalação do GLPI.'),
        ];
    }

    public function createTicket(array $input): int
    {
        $ticket = new \Ticket();

        if (!$ticket::canCreate()) {
            throw new \RuntimeException(I18n::translate('Usuário sem permissão para criar chamado.'));
        }

        $currentUserId = (int) ($_SESSION['glpiID'] ?? 0);
        if ($currentUserId <= 0) {
            throw new \RuntimeException(I18n::translate('Sessão de usuário inválida para criar chamado.'));
        }
        $requesterIds = array_values(array_unique(array_filter(
            array_map('intval', (array) ($input['_users_id_requester'] ?? [$currentUserId])),
            static fn(int $id): bool => $id > 0
        )));
        if (count($requesterIds) !== 1) {
            throw new \RuntimeException(I18n::translate('Requerente inválido para o contexto atual.'));
        }
        $requesterId = $requesterIds[0];
        $entityId = $this->getConcreteActiveEntityId();
        if (!$this->canCreateTicketForRequester($requesterId, $entityId)) {
            throw new \RuntimeException(I18n::translate('Sem permissão para abrir chamado em nome do requerente informado.'));
        }

        $payload = [
            'name' => (string) ($input['name'] ?? ''),
            'content' => (string) ($input['content'] ?? ''),
            'type' => (int) ($input['type'] ?? $this->getDefaultTicketType()),
            'itilcategories_id' => max(0, (int) ($input['itilcategories_id'] ?? 0)),
            'locations_id' => max(0, (int) ($input['locations_id'] ?? 0)),
            'urgency' => (int) ($input['urgency'] ?? 3),
            'impact' => (int) ($input['impact'] ?? 3),
            'entities_id' => $entityId,
            '_users_id_requester' => [$requesterId],
            // Ask the native engine to repeat its delegatee check. If this
            // flag or the native capability disappears in a future GLPI, the
            // capability gate above fails closed and the UI offers fallback.
            'check_delegatee' => true,
        ];

        if (!empty($input['_users_id_assign']) && is_array($input['_users_id_assign'])) {
            $ids = $this->normalizeActorIdsForMutation($input['_users_id_assign']);
            if ($ids === null) {
                throw new \RuntimeException(I18n::translate('Ator selecionado inválido para o contexto atual.'));
            }
            $payload['_users_id_assign'] = $ids;
        }
        if (!empty($input['_users_id_observer']) && is_array($input['_users_id_observer'])) {
            $ids = $this->normalizeActorIdsForMutation($input['_users_id_observer']);
            if ($ids === null) {
                throw new \RuntimeException(I18n::translate('Ator selecionado inválido para o contexto atual.'));
            }
            $payload['_users_id_observer'] = $ids;
        }
        if (!empty($input['_groups_id_assign']) && is_array($input['_groups_id_assign'])) {
            $ids = $this->normalizeActorIdsForMutation($input['_groups_id_assign']);
            if ($ids === null) {
                throw new \RuntimeException(I18n::translate('Grupo técnico inválido para o contexto atual.'));
            }
            $payload['_groups_id_assign'] = $ids;
        }
        if (!empty($input['_groups_id_observer']) && is_array($input['_groups_id_observer'])) {
            $ids = $this->normalizeActorIdsForMutation($input['_groups_id_observer']);
            if ($ids === null) {
                throw new \RuntimeException(I18n::translate('Grupo observador inválido para o contexto atual.'));
            }
            $payload['_groups_id_observer'] = $ids;
        }
        if (!empty($input['requesttypes_id']) && $this->ticketSupportsRequestSource()) {
            $payload['requesttypes_id'] = (int) $input['requesttypes_id'];
        }
        if (isset($input['externalid']) && trim((string) $input['externalid']) !== '' && $this->ticketSupportsExternalId()) {
            $payload['externalid'] = trim((string) $input['externalid']);
        }
        if (!empty($input['tickettemplates_id']) && class_exists('\TicketTemplate')) {
            $templateId = (int) $input['tickettemplates_id'];
            if ($this->getTicketTemplateMetadata($templateId) === null) {
                throw new \RuntimeException(I18n::translate('Modelo de chamado inválido para a entidade ativa.'));
            }

            $templateField = method_exists('\TicketTemplate', 'getForeignKeyField') ? \TicketTemplate::getForeignKeyField() : 'tickettemplates_id';
            $payload[$templateField] = $templateId;
        }
        $filePayload = [];
        foreach (['_filename', '_tag_filename', '_prefix_filename'] as $key) {
            if (!empty($input[$key]) && is_array($input[$key])) {
                $filePayload[$key] = array_values($input[$key]);
                $payload[$key] = $filePayload[$key];
            }
        }

        if (method_exists($ticket, 'check')) {
            $ticket->check(-1, CREATE, $payload);
        }

        if (method_exists($ticket, 'enforceReadonlyFields')) {
            $payload = $ticket->enforceReadonlyFields($payload, true);
            foreach ($filePayload as $key => $value) {
                $payload[$key] = $value;
            }
        }

        // Recheck at the final mutation boundary and restore the native guard
        // if a compatibility layer normalised auxiliary payload keys.
        if (!$this->canCreateTicketForRequester($requesterId, $entityId)) {
            throw new \RuntimeException(I18n::translate('Sem permissão para abrir chamado em nome do requerente informado.'));
        }
        $payload['check_delegatee'] = true;

        $newId = $ticket->add($payload);
        if (!$newId) {
            throw new \RuntimeException(I18n::translate('Não foi possível registrar o chamado no GLPI.'));
        }

        return (int) $newId;
    }

    /**
     * @return int[]
     */
    private function getCurrentEntities(): array
    {
        $activeEntities = $_SESSION['glpiactiveentities'] ?? null;
        if (is_array($activeEntities)) {
            $entities = [];
            foreach ($activeEntities as $key => $value) {
                $candidate = is_int($value) || ctype_digit((string) $value) ? (int) $value : (is_int($key) || ctype_digit((string) $key) ? (int) $key : 0);
                if ($candidate >= 0) {
                    $entities[$candidate] = $candidate;
                }
            }
            if ($entities !== []) {
                return array_values($entities);
            }
        } elseif (is_string($activeEntities) && trim($activeEntities) !== '') {
            $entities = array_values(array_unique(array_filter(array_map('intval', preg_split('/[;,]/', $activeEntities) ?: []))));
            if ($entities !== []) {
                return $entities;
            }
        }

        $activeEntity = $this->getConcreteActiveEntityId();
        $recursive = !empty($_SESSION['glpiactive_entity_recursive']);
        if ($recursive && function_exists('getSonsOf')) {
            $entities = array_map('intval', (array) getSonsOf('glpi_entities', $activeEntity));
            if ($entities !== []) {
                return array_values(array_unique($entities));
            }
        }

        return [$activeEntity];
    }

    private function getConcreteActiveEntityId(): int
    {
        $entityId = (int) ($_SESSION['glpiactive_entity'] ?? 0);
        if (class_exists('\Session') && method_exists('\Session', 'haveAccessToEntity')) {
            if (!(bool) \Session::haveAccessToEntity($entityId, false)) {
                throw new \RuntimeException(I18n::translate('Selecione uma entidade concreta permitida antes de criar ou consultar chamados.'));
            }
        }

        if (class_exists('\Entity')) {
            $entity = new \Entity();
            if (!$entity->getFromDB($entityId)) {
                throw new \RuntimeException(I18n::translate('A entidade ativa não existe ou não está disponível neste contexto.'));
            }
        }

        return $entityId;
    }

    private function getEntityName(int $entityId): string
    {
        if (class_exists('\Entity')) {
            $entity = new \Entity();
            if ($entity->getFromDB($entityId)) {
                return TextNormalizer::fromGlpi((string) ($entity->fields['completename'] ?? $entity->fields['name'] ?? ('Entidade ' . $entityId)));
            }
        }

        return 'Entidade ' . $entityId;
    }

    private function getCurrentUserName(): string
    {
        $userId = (int) ($_SESSION['glpiID'] ?? 0);
        if ($userId <= 0 || !class_exists('\User')) {
            return (string) ($_SESSION['glpiname'] ?? I18n::translate('Usuário atual'));
        }

        $user = new \User();
        if (!$user->getFromDB($userId)) {
            return (string) ($_SESSION['glpiname'] ?? I18n::translate('Usuário atual'));
        }

        $parts = array_filter([
            trim((string) ($user->fields['firstname'] ?? '')),
            trim((string) ($user->fields['realname'] ?? '')),
        ]);

        if ($parts !== []) {
            return implode(' ', $parts);
        }

        return (string) ($user->fields['name'] ?? $_SESSION['glpiname'] ?? I18n::translate('Usuário atual'));
    }

    private function getTicketTypeOptions(): array
    {
        return [
            ['id' => $this->getIncidentTicketType(), 'label' => I18n::translate('Incidente')],
            ['id' => $this->getDemandTicketType(), 'label' => I18n::translate('Requisição')],
        ];
    }

    private function getUrgencyOptions(): array
    {
        return [
            ['id' => 1, 'label' => I18n::translate('Muito baixa')],
            ['id' => 2, 'label' => I18n::translate('Baixa')],
            ['id' => 3, 'label' => I18n::translate('Média')],
            ['id' => 4, 'label' => I18n::translate('Alta')],
            ['id' => 5, 'label' => I18n::translate('Muito alta')],
        ];
    }

    private function getImpactOptions(): array
    {
        return [
            ['id' => 1, 'label' => I18n::translate('Muito baixo')],
            ['id' => 2, 'label' => I18n::translate('Baixo')],
            ['id' => 3, 'label' => I18n::translate('Médio')],
            ['id' => 4, 'label' => I18n::translate('Alto')],
            ['id' => 5, 'label' => I18n::translate('Muito alto')],
        ];
    }

    private function nativeDropdownCriteria(string $table): array
    {
        $criteria = [];
        if ($this->columnExists($table, 'is_deleted')) {
            $criteria['is_deleted'] = 0;
        }

        return $criteria;
    }

    private function dropdownVisibleInCurrentEntity(array $row): bool
    {
        if (!isset($row['entities_id'])) {
            return true;
        }

        $entityId = (int) ($row['entities_id'] ?? 0);
        if (in_array($entityId, $this->getCurrentEntities(), true)) {
            return true;
        }

        return !empty($row['is_recursive']);
    }

    /**
     * @return array<int, array{id:int,label:string}>
     */
    public function getTaskCategories(?int $targetEntityId = null): array
    {
        if (!class_exists('\TaskCategory') || !$this->tableExists('glpi_taskcategories')) {
            return [];
        }

        $category = new \TaskCategory();
        $criteria = $this->nativeDropdownCriteria('glpi_taskcategories');
        $rows = [];
        foreach ($category->find($criteria, 'completename ASC, name ASC') as $row) {
            $visible = $targetEntityId === null
                ? $this->dropdownVisibleInCurrentEntity($row)
                : $this->canUseTemplateEntity(
                    (int) ($row['entities_id'] ?? 0),
                    !empty($row['is_recursive']),
                    $targetEntityId
                );
            if (!$visible) {
                continue;
            }

            $id = (int) ($row['id'] ?? 0);
            $label = TextNormalizer::fromGlpi((string) ($row['completename'] ?? $row['name'] ?? ''));
            if ($id > 0 && $label !== '') {
                $rows[] = ['id' => $id, 'label' => $label];
            }
        }

        return $rows;
    }

    /**
     * @return array<int, array{id:int,label:string}>
     */
    public function getTaskStateOptions(): array
    {
        $states = [];
        $candidates = [
            'INFO' => I18n::translate('Informação'),
            'TODO' => I18n::translate('A fazer'),
            'DONE' => I18n::translate('Feita'),
        ];

        if (class_exists('\Planning')) {
            foreach ($candidates as $constant => $fallback) {
                $constantName = \Planning::class . '::' . $constant;
                if (!defined($constantName)) {
                    continue;
                }

                $value = (int) constant($constantName);
                $label = $fallback;
                if (method_exists('\Planning', 'getState')) {
                    $nativeLabel = trim((string) \Planning::getState($value));
                    if ($nativeLabel !== '') {
                        $label = $nativeLabel;
                    }
                }
                $states[] = ['id' => $value, 'label' => $label];
            }
        }

        return $states !== []
            ? $states
            : [
                ['id' => 0, 'label' => I18n::translate('Informação')],
                ['id' => 1, 'label' => I18n::translate('A fazer')],
                ['id' => 2, 'label' => I18n::translate('Feita')],
            ];
    }

    /**
     * @return array<int, array{id:int,label:string}>
     */
    public function getTaskDurationOptions(): array
    {
        return [
            ['id' => 0, 'label' => I18n::translate('Não informar')],
            ['id' => 900, 'label' => I18n::translate('15 minutos')],
            ['id' => 1800, 'label' => I18n::translate('30 minutos')],
            ['id' => 3600, 'label' => I18n::translate('1 hora')],
            ['id' => 7200, 'label' => I18n::translate('2 horas')],
            ['id' => 14400, 'label' => I18n::translate('4 horas')],
            ['id' => 28800, 'label' => I18n::translate('8 horas')],
        ];
    }

    private function getDefaultTaskState(): int
    {
        return defined(\Planning::class . '::TODO') ? (int) \Planning::TODO : 1;
    }

    private function normalizeDateTime(string $value): string
    {
        $value = trim(str_replace('T', ' ', $value));
        if ($value === '') {
            return '';
        }

        $timestamp = strtotime($value);
        if ($timestamp === false) {
            return '';
        }

        return date('Y-m-d H:i:s', $timestamp);
    }

    private function getTicketCategories(): array
    {
        if (!class_exists('\ITILCategory')) {
            return [];
        }

        $category = new \ITILCategory();
        $criteria = $this->nativeDropdownCriteria('glpi_itilcategories');
        $rows = [];
        foreach ($category->find($criteria, 'completename ASC') as $row) {
            if (!$this->dropdownVisibleInCurrentEntity($row)) {
                continue;
            }

            $rows[] = [
                'id' => (int) ($row['id'] ?? 0),
                'label' => TextNormalizer::fromGlpi((string) ($row['completename'] ?? $row['name'] ?? '')),
                'is_incident' => !isset($row['is_incident']) || (int) $row['is_incident'] === 1,
                'is_request' => !isset($row['is_request']) || (int) $row['is_request'] === 1,
            ];
        }

        return $rows;
    }

    private function getTicketLocations(): array
    {
        if (!class_exists('\Location')) {
            return [];
        }

        $location = new \Location();
        $criteria = $this->nativeDropdownCriteria('glpi_locations');
        $rows = [];
        foreach ($location->find($criteria, 'completename ASC') as $row) {
            if (!$this->dropdownVisibleInCurrentEntity($row)) {
                continue;
            }

            $rows[] = [
                'id' => (int) ($row['id'] ?? 0),
                'label' => TextNormalizer::fromGlpi((string) ($row['completename'] ?? $row['name'] ?? '')),
            ];
        }

        return $rows;
    }

    private function resolveTicketCategoryName(int $categoryId): string
    {
        if ($categoryId <= 0) {
            return I18n::translate('Não informado');
        }

        if (class_exists('\Dropdown') && method_exists('\Dropdown', 'getDropdownName')) {
            $label = TextNormalizer::fromGlpi((string) \Dropdown::getDropdownName('glpi_itilcategories', $categoryId));
            if ($label !== '') {
                return $label;
            }
        }

        return sprintf(I18n::translate('Categoria %d'), $categoryId);
    }

    private function resolveTicketLocationName(int $locationId): string
    {
        if ($locationId <= 0) {
            return I18n::translate('Não informado');
        }

        if (class_exists('\Dropdown') && method_exists('\Dropdown', 'getDropdownName')) {
            $label = TextNormalizer::fromGlpi((string) \Dropdown::getDropdownName('glpi_locations', $locationId));
            if ($label !== '') {
                return $label;
            }
        }

        return sprintf(I18n::translate('Localização %d'), $locationId);
    }

    /**
     * Read the native foreign key consistently on GLPI 10 and 11. Some native
     * projections expose an incomplete fields array after ACL hydration; the
     * bounded primary-key lookup is only a fallback after ticket access has
     * already been established.
     */
    private function readTicketLocationId(object $ticket, int $ticketId): int
    {
        $fields = is_array($ticket->fields ?? null) ? $ticket->fields : [];
        if (array_key_exists('locations_id', $fields)) {
            $locationId = max(0, (int) $fields['locations_id']);
            if ($locationId > 0) {
                return $locationId;
            }
        }

        if (method_exists($ticket, 'getField')) {
            try {
                $locationId = max(0, (int) $ticket->getField('locations_id'));
                if ($locationId > 0) {
                    return $locationId;
                }
            } catch (\Throwable) {
                // Continue with the authoritative bounded database read.
            }
        }

        global $DB;
        if (
            $ticketId <= 0
            || !isset($DB)
            || !method_exists($DB, 'request')
            || !$this->tableExists('glpi_tickets')
            || !$this->columnExists('glpi_tickets', 'locations_id')
        ) {
            return 0;
        }

        try {
            $rows = $DB->request([
                'SELECT' => ['locations_id'],
                'FROM' => 'glpi_tickets',
                'WHERE' => ['id' => $ticketId],
                'LIMIT' => 1,
            ]);
            foreach ($rows as $row) {
                return max(0, (int) ($row['locations_id'] ?? 0));
            }
        } catch (\Throwable) {
            return 0;
        }

        return 0;
    }

    private function getIncidentTicketType(): int
    {
        return defined(\Ticket::class . '::INCIDENT_TYPE') ? (int) \Ticket::INCIDENT_TYPE : 1;
    }

    private function getDemandTicketType(): int
    {
        return defined(\Ticket::class . '::DEMAND_TYPE') ? (int) \Ticket::DEMAND_TYPE : 2;
    }

    private function getDefaultTicketType(): int
    {
        return $this->getIncidentTicketType();
    }

    private function getAssignableUsers(?int $targetEntityId = null): array
    {
        return $this->getActorUsers('own_ticket', $targetEntityId);
    }

    private function getObserverUsers(?int $targetEntityId = null): array
    {
        return $this->getActorUsers('all', $targetEntityId);
    }

    private function getRequesterUsers(?int $targetEntityId = null): array
    {
        return $this->getActorUsers('all', $targetEntityId);
    }

    /** @return array<int,array{id:int,label:string}> */
    private function getActorUsers(string $nativeRight, ?int $targetEntityId = null): array
    {
        if (!class_exists('\User') || !in_array($nativeRight, ['own_ticket', 'all'], true)) {
            return [];
        }

        $user = new \User();
        $criteria = [];
        if ($this->columnExists('glpi_users', 'is_deleted')) {
            $criteria['is_deleted'] = 0;
        }
        if ($this->columnExists('glpi_users', 'is_active')) {
            $criteria['is_active'] = 1;
        }

        $rows = [];
        $targetEntityId ??= $this->getConcreteActiveEntityId();
        if ($targetEntityId < 0) {
            return [];
        }
        foreach ($user->find($criteria, 'realname ASC, firstname ASC, name ASC', 250) as $row) {
            $id = (int) ($row['id'] ?? 0);
            if ($id <= 0 || !$this->isActiveUserInEntity($id, $targetEntityId)) {
                continue;
            }
            if (method_exists($user, 'can') && !$user->can($id, READ)) {
                continue;
            }
            if (
                $nativeRight === 'own_ticket'
                && (
                    !class_exists('\Profile')
                    || !method_exists('\Profile', 'haveUserRight')
                    || !defined('\Ticket::OWN')
                    || !\Profile::haveUserRight($id, 'ticket', \Ticket::OWN, $targetEntityId)
                )
            ) {
                continue;
            }

            $rows[] = [
                'id' => $id,
                'label' => $this->formatUserName($row, $id),
            ];
        }

        return $rows;
    }

    private function getAssignableGroups(?int $targetEntityId = null): array
    {
        return $this->getActorGroups('is_assign', $targetEntityId);
    }

    private function getRequesterGroups(?int $targetEntityId = null): array
    {
        return $this->getActorGroups('is_requester', $targetEntityId);
    }

    private function getObserverGroups(?int $targetEntityId = null): array
    {
        return $this->getActorGroups('is_watcher', $targetEntityId);
    }

    private function getTaskGroups(?int $targetEntityId = null): array
    {
        return $this->getActorGroups('is_task', $targetEntityId);
    }

    /** @param int[] $ids */
    private function exactActorGroupIdsAreEligible(
        array $ids,
        string $capabilityColumn,
        int $targetEntityId
    ): bool {
        $ids = $this->normalizeActorIdsForMutation($ids);
        if ($ids === null) {
            return false;
        }
        if ($ids === []) {
            return true;
        }
        if (
            !class_exists('\Group')
            || !$this->tableExists('glpi_groups')
            || !in_array($capabilityColumn, ['is_assign', 'is_requester', 'is_watcher', 'is_task'], true)
        ) {
            return false;
        }

        $criteria = ['id' => $ids];
        if ($this->columnExists('glpi_groups', 'is_deleted')) {
            $criteria['is_deleted'] = 0;
        }
        if ($this->columnExists('glpi_groups', 'is_active')) {
            $criteria['is_active'] = 1;
        }
        if ($this->columnExists('glpi_groups', $capabilityColumn)) {
            $criteria[$capabilityColumn] = 1;
        }

        $requested = array_fill_keys($ids, true);
        $eligible = [];
        $rowsSeen = 0;
        try {
            $group = new \Group();
            // GLPI 10 renders an empty explicit order as `ORDER BY ``` and
            // rejects the query. A stable primary-key order is valid in both
            // GLPI 10 and 11 and keeps the bounded exact-set check deterministic.
            foreach ($group->find($criteria, 'id ASC', count($ids) + 1) as $row) {
                $rowsSeen++;
                if ($rowsSeen > count($ids)) {
                    return false;
                }
                $id = (int) ($row['id'] ?? 0);
                if (
                    $id <= 0
                    || !isset($requested[$id])
                    || !$this->canUseTemplateEntity(
                        (int) ($row['entities_id'] ?? 0),
                        !empty($row['is_recursive']),
                        $targetEntityId
                    )
                ) {
                    return false;
                }
                $eligible[$id] = true;
            }
        } catch (\Throwable) {
            return false;
        }

        return count($eligible) === count($requested);
    }

    /** @param int[] $ids */
    private function exactActorSupplierIdsAreEligible(array $ids, int $targetEntityId): bool
    {
        $ids = $this->normalizeActorIdsForMutation($ids);
        if ($ids === null) {
            return false;
        }
        if ($ids === []) {
            return true;
        }
        if (!class_exists('\Supplier') || !$this->tableExists('glpi_suppliers')) {
            return false;
        }

        $criteria = ['id' => $ids];
        if ($this->columnExists('glpi_suppliers', 'is_deleted')) {
            $criteria['is_deleted'] = 0;
        }
        if ($this->columnExists('glpi_suppliers', 'is_active')) {
            $criteria['is_active'] = 1;
        }
        $requested = array_fill_keys($ids, true);
        $eligible = [];
        try {
            $supplier = new \Supplier();
            foreach ($supplier->find($criteria, 'id ASC', count($ids) + 1) as $row) {
                $id = (int) ($row['id'] ?? 0);
                if (
                    $id <= 0
                    || !isset($requested[$id])
                    || !$this->canUseTemplateEntity(
                        (int) ($row['entities_id'] ?? 0),
                        !empty($row['is_recursive']),
                        $targetEntityId
                    )
                ) {
                    return false;
                }
                $eligible[$id] = true;
            }
        } catch (\Throwable) {
            return false;
        }

        return count($eligible) === count($requested);
    }

    /** @return array<int,array{id:int,label:string}> */
    private function getAssignableSuppliers(?int $targetEntityId = null): array
    {
        if (!class_exists('\Supplier') || !$this->tableExists('glpi_suppliers')) {
            return [];
        }
        $criteria = [];
        if ($this->columnExists('glpi_suppliers', 'is_deleted')) {
            $criteria['is_deleted'] = 0;
        }
        if ($this->columnExists('glpi_suppliers', 'is_active')) {
            $criteria['is_active'] = 1;
        }
        $targetEntityId ??= $this->getConcreteActiveEntityId();
        if ($targetEntityId < 0) {
            return [];
        }
        $rows = [];
        try {
            $supplier = new \Supplier();
            foreach ($supplier->find($criteria, 'name ASC', 250) as $row) {
                $id = (int) ($row['id'] ?? 0);
                $label = TextNormalizer::fromGlpi((string) ($row['name'] ?? ''));
                if (
                    $id <= 0
                    || $label === ''
                    || !$this->canUseTemplateEntity(
                        (int) ($row['entities_id'] ?? 0),
                        !empty($row['is_recursive']),
                        $targetEntityId
                    )
                ) {
                    continue;
                }
                $rows[] = ['id' => $id, 'label' => $label];
            }
        } catch (\Throwable) {
            return [];
        }

        return $rows;
    }

    /**
     * @return array<int, array{id:int,label:string}>
     */
    private function getActorGroups(string $capabilityColumn, ?int $targetEntityId = null): array
    {
        if (
            !class_exists('\Group')
            || !$this->tableExists('glpi_groups')
            || !in_array($capabilityColumn, ['is_assign', 'is_requester', 'is_watcher', 'is_task'], true)
        ) {
            return [];
        }

        $group = new \Group();
        $criteria = [];
        if ($this->columnExists('glpi_groups', 'is_deleted')) {
            $criteria['is_deleted'] = 0;
        }
        if ($this->columnExists('glpi_groups', 'is_active')) {
            $criteria['is_active'] = 1;
        }
        if ($this->columnExists('glpi_groups', $capabilityColumn)) {
            $criteria[$capabilityColumn] = 1;
        }

        $rows = [];
        $targetEntityId ??= $this->getConcreteActiveEntityId();
        foreach ($group->find($criteria, 'completename ASC') as $row) {
            $visible = $this->canUseTemplateEntity(
                (int) ($row['entities_id'] ?? 0),
                !empty($row['is_recursive']),
                $targetEntityId
            );
            if (!$visible) {
                continue;
            }

            $id = (int) ($row['id'] ?? 0);
            $label = TextNormalizer::fromGlpi(
                (string) ($row['completename'] ?? $row['name'] ?? '')
            );
            if ($id <= 0 || $label === '') {
                continue;
            }
            $rows[] = [
                'id' => $id,
                'label' => $label,
            ];
        }

        return $rows;
    }

    private function getRequestSourceOptions(): array
    {
        if (class_exists('\RequestType')) {
            $requestType = new \RequestType();
            $rows = [];
            $criteria = [];
            if ($this->columnExists('glpi_requesttypes', 'is_active')) {
                $criteria['is_active'] = 1;
            }
            foreach ($requestType->find($criteria, 'name ASC') as $row) {
                $id = (int) ($row['id'] ?? 0);
                $label = trim((string) ($row['name'] ?? ''));
                if ($id > 0 && $label !== '') {
                    $rows[] = ['id' => $id, 'label' => $label];
                }
            }
            if ($rows !== []) {
                return $rows;
            }
        }

        return [
            ['id' => 1, 'label' => I18n::translate('Central de atendimento')],
            ['id' => 2, 'label' => 'Email'],
            ['id' => 3, 'label' => 'Telefone'],
            ['id' => 4, 'label' => 'Fax'],
            ['id' => 6, 'label' => 'Outro'],
        ];
    }

    private function getDefaultRequestSourceId(): int
    {
        return 1;
    }

    private function resolveRequestSourceLabel(int $requestSourceId): string
    {
        foreach ($this->getRequestSourceOptions() as $option) {
            if ((int) ($option['id'] ?? 0) === $requestSourceId) {
                return (string) ($option['label'] ?? I18n::translate('Central de atendimento'));
            }
        }

        return I18n::translate('Central de atendimento');
    }

    private function computePriorityPreview(int $urgency, int $impact): array
    {
        $urgency = max(1, min(5, $urgency));
        $impact = max(1, min(5, $impact));
        $score = $urgency + $impact;

        $label = match (true) {
            $score <= 3 => I18n::translate('Muito baixa'),
            $score <= 5 => I18n::translate('Baixa'),
            $score <= 7 => I18n::translate('Média'),
            $score <= 9 => I18n::translate('Alta'),
            default => I18n::translate('Muito alta'),
        };

        return [
            'score' => $score,
            'label' => $label,
        ];
    }

    private function ticketSupportsExternalId(): bool
    {
        if (!$this->tableExists('glpi_tickets')) {
            return false;
        }

        return in_array('externalid', $this->getTableColumns('glpi_tickets'), true);
    }

    private function ticketSupportsRequestSource(): bool
    {
        if (!$this->tableExists('glpi_tickets')) {
            return false;
        }

        return in_array('requesttypes_id', $this->getTableColumns('glpi_tickets'), true);
    }
}
