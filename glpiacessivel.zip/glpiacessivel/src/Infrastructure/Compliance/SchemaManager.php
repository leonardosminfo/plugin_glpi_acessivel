<?php

declare(strict_types=1);

namespace GlpiPlugin\Glpiacessivel\Infrastructure\Compliance;

use DBmysql;
use DBConnection;
use GlpiPlugin\Glpiacessivel\Infrastructure\Audit\AuditRetentionCronTask;
use GlpiPlugin\Glpiacessivel\Infrastructure\Audit\AuditRights;
use GlpiPlugin\Glpiacessivel\Infrastructure\Database\GlpiDatabaseQuery;
use GlpiPlugin\Glpiacessivel\Infrastructure\Migration\PluginMigrationRunner;
use Migration;

final class SchemaManager
{
    public const RUNTIME_EPOCH = '20260907-01';

    private const LEGACY_TICKET_VIEWS_TABLE = 'glpi_plugin_glpiacessivel_ticketviews';

    /** @var DBmysql */
    private $db;

    public function __construct(DBmysql $db)
    {
        $this->db = $db;
    }

    public function install(): bool
    {
        if (!$this->removeLegacyTicketViewsIfEmpty()) {
            return false;
        }

        $runner = new PluginMigrationRunner(
            $this->db,
            DBConnection::getDefaultCharset(),
            DBConnection::getDefaultCollation()
        );

        if (
            !$runner->run(
                'V0001_baseline_schema',
                hash('sha256', 'glpiacessivel:V0001:baseline-schema:20260825'),
                fn(): bool => $this->installBaseline()
            )
        ) {
            return false;
        }

        if (
            !$runner->run(
                'V0002_audit_governance_rights',
                hash('sha256', 'glpiacessivel:V0002:audit-governance-rights:20260830'),
                fn(): bool => $this->installAuditGovernance()
            )
        ) {
            return false;
        }

        if (
            !$runner->run(
                'V0003_audit_schema_normalization',
                hash('sha256', 'glpiacessivel:V0003:audit-schema-normalization:20260830'),
                fn(): bool => $this->normalizeAuditGovernanceSchema()
            )
        ) {
            return false;
        }

        if (
            !$runner->run(
                'V0004_ticket_list_rate_calibration',
                hash('sha256', 'glpiacessivel:V0004:ticket-list-rate-calibration:20260830'),
                fn(): bool => $this->calibrateTicketListRateDefaults()
            )
        ) {
            return false;
        }

        return $runner->run(
            'V0005_ticket_list_performance_limits_switch',
            hash('sha256', 'glpiacessivel:V0005:ticket-list-performance-limits-switch:20260905'),
            fn(): bool => $this->installTicketListPerformanceLimitsSwitch()
        );
    }

    private function installBaseline(): bool
    {
        $defaultCharset = DBConnection::getDefaultCharset();
        $defaultCollation = DBConnection::getDefaultCollation();
        $migration = new Migration(defined('PLUGIN_GLPIACESSIVEL_VERSION') ? PLUGIN_GLPIACESSIVEL_VERSION : '1.0.0');

        $queries = [
            "CREATE TABLE IF NOT EXISTS `glpi_plugin_glpiacessivel_auditlogs` (
                `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
                `users_id` INT UNSIGNED NOT NULL DEFAULT 0,
                `entities_id` INT UNSIGNED NOT NULL DEFAULT 0,
                `resource_entities_id` INT UNSIGNED NOT NULL DEFAULT 0,
                `context_entities_id` INT UNSIGNED NOT NULL DEFAULT 0,
                `scope_kind` VARCHAR(16) NOT NULL DEFAULT 'entity',
                `tickets_id` INT UNSIGNED DEFAULT NULL,
                `action` VARCHAR(120) NOT NULL,
                `payload` LONGTEXT NULL,
                `ip` VARCHAR(64) NULL,
                `created_at` DATETIME NOT NULL,
                PRIMARY KEY (`id`),
                KEY `idx_users_id` (`users_id`),
                KEY `idx_entities_id` (`entities_id`),
                KEY `idx_resource_entity_id` (`resource_entities_id`, `id`),
                KEY `idx_tickets_id` (`tickets_id`),
                KEY `idx_action` (`action`),
                KEY `idx_created_id` (`created_at`, `id`)
            ) ENGINE=InnoDB DEFAULT CHARSET={$defaultCharset} COLLATE={$defaultCollation}",
            "CREATE TABLE IF NOT EXISTS `glpi_plugin_glpiacessivel_piireveals` (
                `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
                `users_id` INT UNSIGNED NOT NULL DEFAULT 0,
                `entities_id` INT UNSIGNED NOT NULL DEFAULT 0,
                `tickets_id` INT UNSIGNED DEFAULT NULL,
                `field_name` VARCHAR(100) NOT NULL,
                `reason` VARCHAR(255) NULL,
                `created_at` DATETIME NOT NULL,
                PRIMARY KEY (`id`),
                KEY `idx_users_id` (`users_id`),
                KEY `idx_tickets_id` (`tickets_id`),
                KEY `idx_created_id` (`created_at`, `id`)
            ) ENGINE=InnoDB DEFAULT CHARSET={$defaultCharset} COLLATE={$defaultCollation}",
            "CREATE TABLE IF NOT EXISTS `glpi_plugin_glpiacessivel_configs` (
                `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
                `key_name` VARCHAR(150) NOT NULL,
                `value_text` LONGTEXT NULL,
                `updated_at` DATETIME NOT NULL,
                PRIMARY KEY (`id`),
                UNIQUE KEY `uniq_key_name` (`key_name`)
            ) ENGINE=InnoDB DEFAULT CHARSET={$defaultCharset} COLLATE={$defaultCollation}",
            "CREATE TABLE IF NOT EXISTS `glpi_plugin_glpiacessivel_playbookjobs` (
                `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
                `users_id` INT UNSIGNED NOT NULL DEFAULT 0,
                `entities_id` INT UNSIGNED NOT NULL DEFAULT 0,
                `job_type` VARCHAR(40) NOT NULL,
                `status` VARCHAR(30) NOT NULL,
                `source_scope` VARCHAR(60) NOT NULL,
                `options_json` LONGTEXT NULL,
                `cursor_json` LONGTEXT NULL,
                `processed_count` INT UNSIGNED NOT NULL DEFAULT 0,
                `suggestions_count` INT UNSIGNED NOT NULL DEFAULT 0,
                `message` VARCHAR(255) NULL,
                `started_at` DATETIME NULL,
                `finished_at` DATETIME NULL,
                `created_at` DATETIME NOT NULL,
                `updated_at` DATETIME NOT NULL,
                PRIMARY KEY (`id`),
                KEY `idx_users_id` (`users_id`),
                KEY `idx_status` (`status`),
                KEY `idx_job_type` (`job_type`)
            ) ENGINE=InnoDB DEFAULT CHARSET={$defaultCharset} COLLATE={$defaultCollation}",
            "CREATE TABLE IF NOT EXISTS `glpi_plugin_glpiacessivel_playbooksuggestions` (
                `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
                `jobs_id` INT UNSIGNED NOT NULL DEFAULT 0,
                `entities_id` INT UNSIGNED NOT NULL DEFAULT 0,
                `source_type` VARCHAR(40) NOT NULL,
                `title` VARCHAR(255) NOT NULL,
                `intent` VARCHAR(80) NOT NULL,
                `confidence` DECIMAL(5,2) NOT NULL DEFAULT 0.00,
                `keywords_json` LONGTEXT NULL,
                `questions_json` LONGTEXT NULL,
                `kb_articles_json` LONGTEXT NULL,
                `category_hint` VARCHAR(255) NULL,
                `group_hint` VARCHAR(255) NULL,
                `ticket_template_json` LONGTEXT NULL,
                `status` VARCHAR(30) NOT NULL DEFAULT 'pending',
                `content_json` LONGTEXT NULL,
                `reviewed_by` INT UNSIGNED NOT NULL DEFAULT 0,
                `reviewed_at` DATETIME NULL,
                `created_at` DATETIME NOT NULL,
                `updated_at` DATETIME NOT NULL,
                PRIMARY KEY (`id`),
                KEY `idx_jobs_id` (`jobs_id`),
                KEY `idx_status` (`status`),
                KEY `idx_intent` (`intent`)
            ) ENGINE=InnoDB DEFAULT CHARSET={$defaultCharset} COLLATE={$defaultCollation}",
            "CREATE TABLE IF NOT EXISTS `glpi_plugin_glpiacessivel_playbooks` (
                `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
                `entities_id` INT UNSIGNED NOT NULL DEFAULT 0,
                `name` VARCHAR(255) NOT NULL,
                `intent` VARCHAR(80) NOT NULL,
                `is_active` TINYINT(1) NOT NULL DEFAULT 1,
                `source_suggestion_id` INT UNSIGNED NOT NULL DEFAULT 0,
                `keywords_json` LONGTEXT NULL,
                `questions_json` LONGTEXT NULL,
                `kb_articles_json` LONGTEXT NULL,
                `category_hint` VARCHAR(255) NULL,
                `group_hint` VARCHAR(255) NULL,
                `ticket_template_json` LONGTEXT NULL,
                `content_json` LONGTEXT NULL,
                `created_at` DATETIME NOT NULL,
                `updated_at` DATETIME NOT NULL,
                PRIMARY KEY (`id`),
                KEY `idx_intent` (`intent`),
                KEY `idx_is_active` (`is_active`),
                KEY `idx_source_suggestion_id` (`source_suggestion_id`)
            ) ENGINE=InnoDB DEFAULT CHARSET={$defaultCharset} COLLATE={$defaultCollation}",
            "CREATE TABLE IF NOT EXISTS `glpi_plugin_glpiacessivel_idempotency` (
                `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
                `scope_hash` CHAR(64) NOT NULL,
                `idempotency_key_hash` CHAR(64) NOT NULL,
                `request_hash` CHAR(64) NOT NULL,
                `reservation_token_hash` CHAR(64) NOT NULL,
                `status` VARCHAR(16) NOT NULL,
                `result_id` BIGINT UNSIGNED DEFAULT NULL,
                `expires_at` DATETIME NOT NULL,
                `created_at` DATETIME NOT NULL,
                `updated_at` DATETIME NOT NULL,
                PRIMARY KEY (`id`),
                UNIQUE KEY `uniq_scope_key` (`scope_hash`, `idempotency_key_hash`),
                KEY `idx_expires_at` (`expires_at`)
            ) ENGINE=InnoDB DEFAULT CHARSET={$defaultCharset} COLLATE={$defaultCollation}",
        ];

        foreach ($queries as $sql) {
            if (!GlpiDatabaseQuery::execute($this->db, $sql)) {
                return false;
            }
        }

        // Migration::addKey checks for an existing index, making upgrades and
        // repeated installation calls idempotent while fresh installs already
        // receive the same key in their CREATE TABLE statements.
        $migration->addKey(
            'glpi_plugin_glpiacessivel_auditlogs',
            ['created_at', 'id'],
            'idx_created_id'
        );
        $migration->addKey(
            'glpi_plugin_glpiacessivel_piireveals',
            ['created_at', 'id'],
            'idx_created_id'
        );

        $now = date('Y-m-d H:i:s');
        $legacyFormsEnabled = $this->existingConfigValue('forms_enabled', '1');
        $legacyChatbotEnabled = $this->existingConfigValue('chatbot_enabled', '1');
        $defaults = [
            'accessibility_mode' => 'hybrid',
            'plugin_fallback_locale' => 'pt_BR',
            'vlibras_scope' => 'plugin_pages',
            'forms_enabled' => '1',
            'pii_masking_enabled' => '0',
            'forms_native_flow_mode' => 'native_embedded',
            'formcreator_minimal_embed_enabled' => '0',
            'native_form_accessibility_bridge_enabled' => '0',
            'chatbot_enabled' => '1',
            'module_ticket_create_state' => 'available',
            'module_forms_state' => $legacyFormsEnabled === '0' ? 'disabled' : 'available',
            'module_tickets_state' => 'available',
            'module_cockpit_state' => 'available',
            'module_knowledge_state' => 'available',
            'module_chatbot_state' => $legacyChatbotEnabled === '0' ? 'disabled' : 'available',
            'module_playbooks_state' => 'available',
            'chatbot_display_name' => 'Assistente',
            'chatbot_floating_button_enabled' => '1',
            'chatbot_floating_scope' => 'all_logged_pages',
            'chatbot_voice_enabled' => '1',
            'chatbot_voice_locale' => 'pt-BR',
            'chatbot_voice_asset_mode' => 'local_preferred',
            'chatbot_stt_engine' => 'vosklet',
            'chatbot_tts_engine' => 'browser_native',
            'chatbot_tts_browser_native_migration_applied' => '1',
            'chatbot_stt_script_local_path' => 'public/assets/vendor/vosklet/Vosklet.js',
            'chatbot_stt_model_local_path' => 'public/assets/voice/vosk/pt-BR/vosk-model-small-pt-0.3.zip',
            'chatbot_tts_script_local_path' => 'public/assets/vendor/piper/piper-tts-web.js',
            'chatbot_tts_onnx_runtime_local_path' => 'public/assets/vendor/onnxruntime-web/1.18.0/ort.esm.js',
            'chatbot_tts_onnx_wasm_local_path' => 'public/assets/vendor/onnxruntime-web/1.18.0',
            'chatbot_tts_piper_wasm_local_path' => 'public/assets/vendor/piper-wasm/1.0.0/piper_phonemize.wasm',
            'chatbot_tts_piper_data_local_path' => 'public/assets/vendor/piper-wasm/1.0.0/piper_phonemize.data',
            'chatbot_tts_voice_model_local_path' => 'public/assets/voice/piper/pt-BR/faber-medium/pt_BR-faber-medium.onnx',
            'chatbot_tts_voice_config_local_path' => 'public/assets/voice/piper/pt-BR/faber-medium/pt_BR-faber-medium.onnx.json',
            'chatbot_stt_script_url' => 'https://cdn.jsdelivr.net/gh/msqr1/Vosklet@1.2.1/Examples/Vosklet.js',
            'chatbot_stt_model_url' => 'https://alphacephei.com/vosk/models/vosk-model-small-pt-0.3.zip',
            'chatbot_stt_model_label' => 'Portugues (Brasil)',
            'chatbot_stt_model_cache_id' => 'glpi-vosk-ptbr',
            'chatbot_tts_script_url' => 'https://esm.run/@mintplex-labs/piper-tts-web',
            'chatbot_tts_voice_id' => 'pt_BR-faber-medium',
            'audit_retention_days' => '365',
            'audit_retention_batch_size' => '500',
            'audit_mode' => 'critical',
            'ticket_async_list_enabled' => '1',
            'ticket_list_configurable_timeout_enabled' => '1',
            'ticket_list_statement_timeout_ms' => '3000',
            'ticket_list_performance_limits_enabled' => '1',
            'ticket_list_capacity_guard_enabled' => '1',
            'ticket_list_capacity_backend' => 'apcu',
            'ticket_list_capacity_max_concurrent' => '2',
            'ticket_list_capacity_lease_seconds' => '8',
            'ticket_list_capacity_retry_after_seconds' => '5',
            'ticket_list_rate_limit' => '30',
            'ticket_list_rate_window_seconds' => '60',
            'ticket_list_rate_burst' => '5',
        ];

        foreach ($defaults as $key => $value) {
            $existing = $this->db->request([
                'SELECT' => ['id'],
                'FROM'   => 'glpi_plugin_glpiacessivel_configs',
                'WHERE'  => ['key_name' => $key],
                'LIMIT'  => 1,
            ])->current();

            if ($existing) {
                continue;
            }

            if (
                !$this->db->insert('glpi_plugin_glpiacessivel_configs', [
                'key_name'   => $key,
                'value_text' => $value,
                'updated_at' => $now,
                ])
            ) {
                return false;
            }
        }

        $migration->executeMigration();

        if (!$this->registerAuditRetentionCronTask()) {
            return false;
        }

        return true;
    }

    private function installAuditGovernance(): bool
    {
        $migration = new Migration(
            defined('PLUGIN_GLPIACESSIVEL_VERSION') ? PLUGIN_GLPIACESSIVEL_VERSION : '1.0.0'
        );
        $table = 'glpi_plugin_glpiacessivel_auditlogs';
        $migration->addField($table, 'resource_entities_id', 'fkey', [
            'value' => 0,
            'after' => 'entities_id',
        ]);
        $migration->addField($table, 'context_entities_id', 'fkey', [
            'value' => 0,
            'after' => 'resource_entities_id',
        ]);
        $migration->addField($table, 'scope_kind', $this->auditScopeType(), [
            'nodefault' => true,
            'after' => 'context_entities_id',
        ]);
        $migration->addKey($table, ['resource_entities_id', 'id'], 'idx_resource_entity_id');
        $migration->executeMigration();

        if (!$this->configExists('audit_mode')) {
            if (
                !$this->db->insert('glpi_plugin_glpiacessivel_configs', [
                'key_name' => 'audit_mode',
                'value_text' => 'full',
                'updated_at' => date('Y-m-d H:i:s'),
                ])
            ) {
                return false;
            }
        }

        return AuditRights::install();
    }

    private function installTicketListPerformanceLimitsSwitch(): bool
    {
        $key = 'ticket_list_performance_limits_enabled';
        if ($this->configExists($key)) {
            return true;
        }

        return (bool) $this->db->insert('glpi_plugin_glpiacessivel_configs', [
            'key_name' => $key,
            'value_text' => '1',
            'updated_at' => date('Y-m-d H:i:s'),
        ]);
    }

    private function normalizeAuditGovernanceSchema(): bool
    {
        $migration = new Migration(
            defined('PLUGIN_GLPIACESSIVEL_VERSION') ? PLUGIN_GLPIACESSIVEL_VERSION : '1.0.0'
        );
        $table = 'glpi_plugin_glpiacessivel_auditlogs';
        $migration->changeField($table, 'resource_entities_id', 'resource_entities_id', 'fkey');
        $migration->changeField($table, 'context_entities_id', 'context_entities_id', 'fkey');
        $migration->changeField(
            $table,
            'scope_kind',
            'scope_kind',
            $this->auditScopeType(),
            ['nodefault' => true]
        );

        return $migration->executeMigration() !== false;
    }

    private function calibrateTicketListRateDefaults(): bool
    {
        if (
            !method_exists($this->db, 'beginTransaction')
            || !method_exists($this->db, 'commit')
            || !method_exists($this->db, 'rollBack')
            || !method_exists($this->db, 'affectedRows')
        ) {
            return false;
        }

        if ($this->db->beginTransaction() === false) {
            return false;
        }

        $transactionOpen = true;
        try {
            $legacy = [
                'ticket_list_rate_limit' => '6',
                'ticket_list_rate_window_seconds' => '60',
                'ticket_list_rate_burst' => '2',
            ];
            $replacement = [
                'ticket_list_rate_limit' => '30',
                'ticket_list_rate_burst' => '5',
            ];
            $current = [];
            foreach (array_keys($legacy) as $key) {
                $row = $this->db->request([
                    'SELECT' => ['value_text'],
                    'FROM' => 'glpi_plugin_glpiacessivel_configs',
                    'WHERE' => ['key_name' => $key],
                    'LIMIT' => 1,
                ])->current();
                if (!is_array($row) || !array_key_exists('value_text', $row)) {
                    $current = [];
                    break;
                }
                $current[$key] = (string) $row['value_text'];
            }

            // Only the exact historical default trio is migrated. Any custom
            // or partial configuration is an administrator decision and is
            // intentionally preserved.
            if ($current === $legacy) {
                $now = date('Y-m-d H:i:s');
                foreach ($replacement as $key => $value) {
                    if (
                        !$this->db->update(
                            'glpi_plugin_glpiacessivel_configs',
                            ['value_text' => $value, 'updated_at' => $now],
                            ['key_name' => $key, 'value_text' => $legacy[$key]]
                        )
                        || $this->db->affectedRows() !== 1
                    ) {
                        throw new \RuntimeException('ticket_list_rate_calibration_conflict');
                    }
                }
            }

            if ($this->db->commit() === false) {
                throw new \RuntimeException('ticket_list_rate_calibration_commit_failed');
            }
            $transactionOpen = false;
            return true;
        } catch (\Throwable $e) {
            if ($transactionOpen) {
                try {
                    $this->db->rollBack();
                } catch (\Throwable $rollbackError) {
                    // Returning false keeps the migration absent from the ledger.
                }
            }
            return false;
        }
    }

    private function auditScopeType(): string
    {
        return "VARCHAR(16) COLLATE " . DBConnection::getDefaultCollation()
            . " NOT NULL DEFAULT 'entity'";
    }

    private function registerAuditRetentionCronTask(): bool
    {
        if (!class_exists('\CronTask') || !method_exists('\CronTask', 'register')) {
            // Unit tooling and partial bootstrap contexts do not expose GLPI's
            // scheduler. The real plugin installer does, and registers below.
            return true;
        }

        $itemtype = AuditRetentionCronTask::class;
        $name = 'PurgeAuditLogs';
        $task = new \CronTask();
        if (method_exists($task, 'getFromDBbyName') && $task->getFromDBbyName($itemtype, $name)) {
            return true;
        }

        $frequency = defined('HOUR_TIMESTAMP') ? (int) HOUR_TIMESTAMP : 3600;
        $options = [
            'state' => defined('CronTask::STATE_WAITING') ? \CronTask::STATE_WAITING : 1,
            'comment' => 'Retencao em lotes da auditoria do plugin glpiacessivel',
        ];

        if (\CronTask::register($itemtype, $name, $frequency, $options)) {
            return true;
        }

        // A concurrent/idempotent installer may have registered the task
        // between the read and the insert.
        return method_exists($task, 'getFromDBbyName')
            && $task->getFromDBbyName($itemtype, $name);
    }

    private function removeLegacyTicketViewsIfEmpty(): bool
    {
        if (!method_exists($this->db, 'tableExists')) {
            return false;
        }

        try {
            if (!$this->db->tableExists(self::LEGACY_TICKET_VIEWS_TABLE)) {
                return true;
            }
        } catch (\Throwable $e) {
            return false;
        }

        $locked = false;
        try {
            $locked = (bool) GlpiDatabaseQuery::execute(
                $this->db,
                'LOCK TABLES `' . self::LEGACY_TICKET_VIEWS_TABLE . '` WRITE'
            );
            if (!$locked) {
                return false;
            }

            $unexpectedRow = $this->db->request([
                'SELECT' => ['id'],
                'FROM' => self::LEGACY_TICKET_VIEWS_TABLE,
                'LIMIT' => 1,
            ])->current();
            if ($unexpectedRow !== false && $unexpectedRow !== null) {
                return false;
            }

            return (bool) GlpiDatabaseQuery::execute(
                $this->db,
                'DROP TABLE `' . self::LEGACY_TICKET_VIEWS_TABLE . '`'
            );
        } catch (\Throwable $e) {
            return false;
        } finally {
            if ($locked) {
                try {
                    GlpiDatabaseQuery::execute($this->db, 'UNLOCK TABLES');
                } catch (\Throwable $e) {
                    // The installation has already failed closed or DROP released the lock.
                }
            }
        }
    }

    private function existingConfigValue(string $key, string $default): string
    {
        $row = $this->db->request([
            'SELECT' => ['value_text'],
            'FROM' => 'glpi_plugin_glpiacessivel_configs',
            'WHERE' => ['key_name' => $key],
            'LIMIT' => 1,
        ])->current();

        return is_array($row) && array_key_exists('value_text', $row)
            ? (string) $row['value_text']
            : $default;
    }

    private function configExists(string $key): bool
    {
        $row = $this->db->request([
            'SELECT' => ['id'],
            'FROM' => 'glpi_plugin_glpiacessivel_configs',
            'WHERE' => ['key_name' => $key],
            'LIMIT' => 1,
        ])->current();

        return is_array($row);
    }

    public function uninstall(): bool
    {
        if (!GlpiDatabaseQuery::isSupported($this->db)) {
            return false;
        }

        if (!AuditRights::uninstall()) {
            return false;
        }
        $queries = [
            // The runtime availability gate uses this ledger as a teardown
            // sentinel. Dropping it first makes requests starting in another
            // worker fail closed before functional tables are removed.
            'DROP TABLE IF EXISTS `glpi_plugin_glpiacessivel_migrations`',
            'DROP TABLE IF EXISTS `glpi_plugin_glpiacessivel_ticketviews`',
            'DROP TABLE IF EXISTS `glpi_plugin_glpiacessivel_idempotency`',
            'DROP TABLE IF EXISTS `glpi_plugin_glpiacessivel_playbooks`',
            'DROP TABLE IF EXISTS `glpi_plugin_glpiacessivel_playbooksuggestions`',
            'DROP TABLE IF EXISTS `glpi_plugin_glpiacessivel_playbookjobs`',
            'DROP TABLE IF EXISTS `glpi_plugin_glpiacessivel_auditlogs`',
            'DROP TABLE IF EXISTS `glpi_plugin_glpiacessivel_piireveals`',
            'DROP TABLE IF EXISTS `glpi_plugin_glpiacessivel_configs`',
        ];

        try {
            foreach ($queries as $sql) {
                if (!GlpiDatabaseQuery::execute($this->db, $sql)) {
                    return false;
                }
            }
        } catch (\Throwable) {
            return false;
        }

        return true;
    }
}
