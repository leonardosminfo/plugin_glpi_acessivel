<?php

declare(strict_types=1);

namespace GlpiPlugin\Glpiacessivel\Support;

use GlpiPlugin\Glpiacessivel\Infrastructure\Compliance\SchemaManager;

final class Bootstrap
{
    public const RUNTIME_EPOCH = '20260907-01';

    private const CONFIG_TABLE = 'glpi_plugin_glpiacessivel_configs';
    private const MIGRATION_TABLE = 'glpi_plugin_glpiacessivel_migrations';

    private static bool $initialized = false;
    private static ?object $configStorageDatabase = null;
    private static ?bool $configStorageAvailable = null;
    private static ?object $runtimeSchemaDatabase = null;
    private static ?bool $runtimeSchemaAvailable = null;

    public static function beginUninstall(): void
    {
        $GLOBALS['plugin_glpiacessivel_uninstalling'] = true;
    }

    public static function isUninstalling(): bool
    {
        return !empty($GLOBALS['plugin_glpiacessivel_uninstalling']);
    }

    public static function configStorageAvailable(?object $database = null): bool
    {
        if (self::isUninstalling()) {
            return false;
        }

        $database = self::resolveDatabase($database);
        if ($database === null || !is_callable([$database, 'tableExists'])) {
            return false;
        }
        if (self::$configStorageDatabase === $database && self::$configStorageAvailable !== null) {
            return self::$configStorageAvailable;
        }

        try {
            $available = $database->tableExists(self::CONFIG_TABLE);
        } catch (\Throwable) {
            $available = false;
        }

        self::$configStorageDatabase = $database;
        self::$configStorageAvailable = $available;
        return $available;
    }

    public static function runtimeSchemaAvailable(?object $database = null): bool
    {
        if (self::isUninstalling()) {
            return false;
        }

        $database = self::resolveDatabase($database);
        if ($database === null || !is_callable([$database, 'tableExists'])) {
            return false;
        }
        if (self::$runtimeSchemaDatabase === $database && self::$runtimeSchemaAvailable !== null) {
            return self::$runtimeSchemaAvailable;
        }

        try {
            $available = $database->tableExists(self::MIGRATION_TABLE)
                && self::configStorageAvailable($database);
        } catch (\Throwable) {
            $available = false;
        }

        self::$runtimeSchemaDatabase = $database;
        self::$runtimeSchemaAvailable = $available;
        return $available;
    }

    public static function init(): void
    {
        if (self::$initialized) {
            return;
        }

        self::$initialized = true;
    }

    public static function install(): bool
    {
        global $DB;
        $schema = new SchemaManager($DB);
        $installed = $schema->install();
        if ($installed) {
            self::resetAvailabilityCache();
        }

        return $installed;
    }

    public static function uninstall(): bool
    {
        self::beginUninstall();
        global $DB;
        $schema = new SchemaManager($DB);
        return $schema->uninstall();
    }

    private static function resolveDatabase(?object $database): ?object
    {
        if ($database !== null) {
            return $database;
        }

        global $DB;
        return isset($DB) && is_object($DB) ? $DB : null;
    }

    private static function resetAvailabilityCache(): void
    {
        self::$configStorageDatabase = null;
        self::$configStorageAvailable = null;
        self::$runtimeSchemaDatabase = null;
        self::$runtimeSchemaAvailable = null;
    }
}
