<?php

declare(strict_types=1);

namespace GlpiPlugin\Glpiacessivel\UI\Presenter;

use GlpiPlugin\Glpiacessivel\Support\I18n;
use GlpiPlugin\Glpiacessivel\Support\TicketStatusLabels;

/**
 * Produces an ACL-safe, text-only description of the effective ticket search.
 * The view may render this structure without JavaScript or knowledge of GLPI ids.
 */
final class TicketSearchSummaryPresenter
{
    /**
     * Produces the summary for the ordinary list controls from the effective
     * filters sent to TicketService. Pagination is deliberately omitted: it
     * changes the result window, not the query being described.
     *
     * @param array<string,mixed> $filters
     * @param array<int,array<string,mixed>> $groupOptions
     * @return array{active:bool,source:string,heading:string,saved_search_name:string,sections:array<int,array{key:string,label:string,items:array<int,string>}>,warnings:array<int,string>,plain_text:string}
     */
    public function presentFrequentFilters(array $filters, array $groupOptions = []): array
    {
        $sections = [];
        $scope = (string) ($filters['scope'] ?? 'all');
        $scopeLabels = [
            'all' => I18n::translate('Todos os chamados permitidos'),
            'mine' => I18n::translate('Meus chamados'),
            'group' => I18n::translate('Chamados do grupo'),
        ];
        $sections[] = $this->section('scope', I18n::translate('Escopo'), [
            $scopeLabels[$scope] ?? $scopeLabels['all'],
        ]);

        $text = trim((string) ($filters['q'] ?? ''));
        if ($text !== '') {
            $sections[] = $this->section('text', I18n::translate('Busca'), [$text]);
        }

        $status = trim((string) ($filters['status'] ?? ''));
        if ($status !== '') {
            $statusLabel = ctype_digit($status)
                ? TicketStatusLabels::label((int) $status)
                : $status;
            $sections[] = $this->section('status', I18n::translate('Status'), [$statusLabel]);
        } else {
            $sections[] = $this->section('status', I18n::translate('Status'), [
                I18n::translate('Sem filtro adicional de status'),
            ]);
        }

        $groupId = max(0, (int) ($filters['group_id'] ?? 0));
        if ($groupId > 0) {
            $groupLabel = I18n::translate('Grupo selecionado');
            foreach ($groupOptions as $groupOption) {
                if ((int) ($groupOption['id'] ?? 0) !== $groupId) {
                    continue;
                }
                $candidate = trim((string) ($groupOption['label'] ?? ''));
                if ($candidate !== '') {
                    $groupLabel = $candidate;
                }
                break;
            }
            $sections[] = $this->section(
                'group',
                I18n::translate('Grupo responsável'),
                [$groupLabel]
            );
        }

        if ((string) ($filters['group_by'] ?? 'none') === 'group') {
            $sections[] = $this->section('group_by', I18n::translate('Classificação'), [
                I18n::translate('Agrupar por grupo'),
            ]);
        }

        $heading = I18n::translate('Resumo da consulta atual');
        $plainParts = [$heading];
        foreach ($sections as $section) {
            $plainParts[] = $section['label'] . ': ' . implode('; ', $section['items']);
        }

        return [
            'active' => $sections !== [],
            'source' => 'frequent_filters',
            'heading' => $heading,
            'saved_search_name' => '',
            'sections' => $sections,
            'warnings' => [],
            'plain_text' => implode('. ', $plainParts),
        ];
    }

    /**
     * @param array<string,mixed> $definition
     * @param array<string,mixed> $catalog
     * @param array<string,mixed> $savedSearch
     * @param array<string,mixed> $filters
     * @return array{active:bool,source:string,heading:string,saved_search_name:string,sections:array<int,array{key:string,label:string,items:array<int,string>}>,warnings:array<int,string>,plain_text:string}
     */
    public function present(
        array $definition,
        array $catalog,
        array $savedSearch = [],
        array $filters = []
    ): array {
        $sections = [];
        $warnings = [];
        $name = trim((string) ($savedSearch['name'] ?? ''));
        $source = $name !== '' ? 'glpi_saved_search' : 'advanced_search';

        $text = trim((string) ($definition['text'] ?? ''));
        if ($text !== '') {
            $sections[] = $this->section('text', I18n::translate('Texto livre'), [$text]);
        }

        $scope = (string) ($definition['scope'] ?? 'all');
        $scopeLabels = [
            'all' => I18n::translate('Todos os chamados permitidos pelo seu perfil'),
            'mine' => I18n::translate('Meus chamados'),
            'group' => I18n::translate('Chamados dos meus grupos'),
        ];
        if ($scope !== 'all') {
            $sections[] = $this->section('scope', I18n::translate('Escopo'), [
                $scopeLabels[$scope] ?? $scopeLabels['all'],
            ]);
        }

        $ticketOptions = $this->ticketOptions($catalog);
        $metaOptions = $this->metaOptionsByItemtype((array) ($catalog['meta_itemtypes'] ?? []));
        $criteria = $this->narrateCriteria(
            (array) ($definition['criteria'] ?? []),
            $ticketOptions,
            $metaOptions,
            $warnings
        );
        if ($criteria !== []) {
            $sections[] = $this->section('criteria', I18n::translate('Critérios'), $criteria);
        }

        $metaCriteria = $this->narrateMetaCriteria(
            (array) ($definition['metacriteria'] ?? []),
            $metaOptions,
            $warnings
        );
        if ($metaCriteria !== []) {
            $sections[] = $this->section('metacriteria', I18n::translate('Critérios relacionados'), $metaCriteria);
        }

        $sections[] = $this->section('deleted_scope', I18n::translate('Registros excluídos'), [
            (int) ($definition['is_deleted'] ?? 0) === 1
                ? I18n::translate('Somente chamados excluídos')
                : I18n::translate('Somente chamados ativos'),
        ]);

        $sortItems = $this->narrateSorts($definition, $ticketOptions, $warnings);
        if ($sortItems !== []) {
            $sections[] = $this->section('sort', I18n::translate('Ordenação'), $sortItems);
        }

        $columnItems = $this->narrateColumns(
            (array) ($definition['columns'] ?? $filters['columns'] ?? []),
            (array) ($catalog['columns'] ?? []),
            $warnings
        );
        if ($columnItems !== []) {
            $sections[] = $this->section('columns', I18n::translate('Colunas'), $columnItems);
        }

        $pageSize = (int) ($filters['page_size'] ?? 0);
        if (in_array($pageSize, [10, 20, 50, 100], true)) {
            $sections[] = $this->section('page_size', I18n::translate('Resultados por página'), [
                (string) $pageSize,
            ]);
        }

        foreach ((array) ($savedSearch['presentation_warnings'] ?? []) as $warning) {
            if ($warning === 'native_column_unavailable') {
                $warnings[] = I18n::translate('Algumas colunas salvas não estão disponíveis neste perfil ou entidade.');
            }
        }
        $warnings = array_values(array_unique($warnings));
        $heading = $name !== ''
            ? I18n::translate('Pesquisa salva aplicada:') . ' ' . $name
            : I18n::translate('Pesquisa aplicada');
        $plainParts = [$heading];
        foreach ($sections as $section) {
            $plainParts[] = $section['label'] . ': ' . implode('; ', $section['items']);
        }
        foreach ($warnings as $warning) {
            $plainParts[] = I18n::translate('Aviso:') . ' ' . $warning;
        }

        return [
            'active' => $sections !== [],
            'source' => $source,
            'heading' => $heading,
            'saved_search_name' => $name,
            'sections' => $sections,
            'warnings' => $warnings,
            'plain_text' => implode('. ', $plainParts),
        ];
    }

    /**
     * Convert the semantic snapshot of the executed GLPI Search plan into a
     * text-only DTO. Numeric option IDs and the raw native definition never
     * cross the controller boundary.
     *
     * @param array<string,mixed> $effectiveSearch
     * @param array<string,mixed> $catalog
     * @param array<string,mixed> $savedSearch
     * @return array<string,mixed>
     */
    public function presentEffectiveNativeSearch(
        array $effectiveSearch,
        array $catalog,
        array $savedSearch = []
    ): array {
        $presented = $this->present($effectiveSearch, $catalog, $savedSearch);
        $items = [];
        if ((array) ($effectiveSearch['criteria'] ?? []) === []) {
            $items[] = I18n::translate('Sem filtro adicional de status');
        }
        foreach ((array) ($presented['sections'] ?? []) as $section) {
            if (!is_array($section)) {
                continue;
            }
            $label = trim((string) ($section['label'] ?? ''));
            foreach ((array) ($section['items'] ?? []) as $item) {
                $item = trim((string) $item);
                if ($item === '') {
                    continue;
                }
                if (in_array((string) ($section['key'] ?? ''), ['criteria', 'metacriteria'], true)) {
                    $items[] = $this->withoutLeadingConnector($item);
                } elseif ($label !== '') {
                    $items[] = $label . ': ' . $item;
                }
            }
        }
        $heading = I18n::translate('Resumo da consulta atual');
        $automaticLabel = I18n::translate('Filtro aplicado automaticamente pelo GLPI');
        $note = I18n::translate(
            'Definido pelo GLPI para o perfil e a entidade atuais; este filtro não foi selecionado nesta tela.'
        );
        $warnings = array_values(array_filter(
            (array) ($presented['warnings'] ?? []),
            'is_string'
        ));
        $plainParts = [$heading, $automaticLabel . ': ' . implode('; ', $items), $note];
        foreach ($warnings as $warning) {
            $plainParts[] = I18n::translate('Aviso:') . ' ' . $warning;
        }

        return [
            'active' => true,
            'source' => 'native_effective_search',
            'heading' => $heading,
            'saved_search_name' => trim((string) ($savedSearch['name'] ?? '')),
            'sections' => [$this->section('automatic_glpi', $automaticLabel, $items)],
            'warnings' => $warnings,
            'note' => $note,
            'plain_text' => implode('. ', $plainParts),
        ];
    }

    /** @return array{key:string,label:string,items:array<int,string>} */
    private function section(string $key, string $label, array $items): array
    {
        return ['key' => $key, 'label' => $label, 'items' => array_values($items)];
    }

    /** @return array<int,array<string,mixed>> */
    private function ticketOptions(array $catalog): array
    {
        $options = [];
        foreach ((array) ($catalog['options'] ?? []) as $option) {
            if (is_array($option) && (int) ($option['id'] ?? 0) > 0) {
                $options[(int) $option['id']] = $option;
            }
        }
        return $options;
    }

    /** @return array<int,string> */
    private function narrateCriteria(
        array $criteria,
        array $options,
        array $metaOptions,
        array &$warnings,
        int $depth = 0
    ): array {
        $items = [];
        foreach ($criteria as $criterion) {
            if (!is_array($criterion)) {
                $warnings[] = I18n::translate('Um critério salvo não está disponível neste perfil ou entidade.');
                continue;
            }
            $connector = $this->connector((string) ($criterion['link'] ?? 'AND'));
            if (is_array($criterion['criteria'] ?? null)) {
                $children = $this->narrateCriteria(
                    $criterion['criteria'],
                    $options,
                    $metaOptions,
                    $warnings,
                    $depth + 1
                );
                if ($children !== []) {
                    $items[] = $connector . ' ' . I18n::translate('grupo:') . ' ' . implode('; ', $children);
                }
                continue;
            }

            $rawField = $criterion['field'] ?? 0;
            $isMeta = (int) ($criterion['meta'] ?? 0) === 1
                || array_key_exists('itemtype', $criterion);
            if ($isMeta) {
                $itemtype = (string) ($criterion['itemtype'] ?? '');
                $field = (int) $rawField;
                if (!isset($metaOptions[$itemtype]['options'][$field])) {
                    $warnings[] = I18n::translate('Um critério relacionado não está disponível neste perfil ou entidade.');
                    continue;
                }
                $relation = (string) $metaOptions[$itemtype]['label'];
                $items[] = $connector
                    . ' ' . ($relation !== '' ? $relation . ': ' : '')
                    . $this->narrateLeaf($criterion, $metaOptions[$itemtype]['options'][$field]);
                continue;
            }

            $special = is_string($rawField) ? $this->specialCriterionOption($rawField) : null;
            $field = (int) $rawField;
            $option = $special ?? ($options[$field] ?? null);
            if (!is_array($option)) {
                $warnings[] = I18n::translate('Um critério salvo não está disponível neste perfil ou entidade.');
                continue;
            }
            $items[] = $connector . ' ' . $this->narrateLeaf($criterion, $option);
        }
        return $items;
    }

    /** @return array<string,array{label:string,options:array<int,array<string,mixed>>}> */
    private function metaOptionsByItemtype(array $metaCatalogs): array
    {
        $byItemtype = [];
        foreach ($metaCatalogs as $metaCatalog) {
            if (!is_array($metaCatalog)) {
                continue;
            }
            $options = [];
            foreach ((array) ($metaCatalog['options'] ?? []) as $option) {
                if (is_array($option) && (int) ($option['id'] ?? 0) > 0) {
                    $options[(int) $option['id']] = $option;
                }
            }
            $byItemtype[(string) ($metaCatalog['itemtype'] ?? '')] = [
                'label' => trim((string) ($metaCatalog['label'] ?? '')),
                'options' => $options,
            ];
        }
        return $byItemtype;
    }

    /**
     * @param array<string,array{label:string,options:array<int,array<string,mixed>>}> $byItemtype
     * @return array<int,string>
     */
    private function narrateMetaCriteria(array $criteria, array $byItemtype, array &$warnings): array
    {
        $items = [];
        foreach ($criteria as $criterion) {
            if (!is_array($criterion)) {
                $warnings[] = I18n::translate('Um critério relacionado não está disponível neste perfil ou entidade.');
                continue;
            }
            $itemtype = (string) ($criterion['itemtype'] ?? '');
            $field = (int) ($criterion['field'] ?? 0);
            if (!isset($byItemtype[$itemtype]['options'][$field])) {
                $warnings[] = I18n::translate('Um critério relacionado não está disponível neste perfil ou entidade.');
                continue;
            }
            $relation = (string) $byItemtype[$itemtype]['label'];
            $items[] = $this->connector((string) ($criterion['link'] ?? 'AND'))
                . ' ' . ($relation !== '' ? $relation . ': ' : '')
                . $this->narrateLeaf($criterion, $byItemtype[$itemtype]['options'][$field]);
        }
        return $items;
    }

    /** @return null|array<string,mixed> */
    private function specialCriterionOption(string $field): ?array
    {
        $labels = [
            'all' => I18n::translate('Todos os campos'),
            'view' => I18n::translate('Campos exibidos'),
        ];
        if (!isset($labels[$field])) {
            return null;
        }
        $operatorLabels = [
            'contains' => I18n::translate('contém'),
            'notcontains' => I18n::translate('não contém'),
            'equals' => I18n::translate('é'),
            'notequals' => I18n::translate('não é'),
            'empty' => I18n::translate('está vazio'),
            'notempty' => I18n::translate('não está vazio'),
        ];
        return [
            'label' => $labels[$field],
            'operators' => array_map(
                static fn(string $operator, string $label): array => [
                    'value' => $operator,
                    'label' => $label,
                    'value_contract' => ['kind' => 'text'],
                ],
                array_keys($operatorLabels),
                array_values($operatorLabels)
            ),
            'value' => ['mode' => 'text', 'options' => []],
        ];
    }

    private function narrateLeaf(array $criterion, array $option): string
    {
        $operator = (string) ($criterion['searchtype'] ?? 'contains');
        $operatorLabel = $operator;
        $contractKind = 'text';
        $nativeOperatorLabels = [
            'notold' => I18n::translate('não solucionado'),
            'notclosed' => I18n::translate('não fechado'),
        ];
        if (isset($nativeOperatorLabels[$operator])) {
            $operatorLabel = $nativeOperatorLabels[$operator];
        }
        foreach ((array) ($option['operators'] ?? []) as $descriptor) {
            if (is_array($descriptor) && (string) ($descriptor['value'] ?? '') === $operator) {
                $operatorLabel = (string) ($descriptor['label'] ?? $operator);
                $contractKind = (string) (($descriptor['value_contract'] ?? [])['kind'] ?? 'text');
                break;
            }
        }
        $value = (string) ($criterion['value'] ?? '');
        if (in_array($operator, ['empty', 'notempty', 'notold', 'notclosed'], true)) {
            $value = '';
        } elseif ($contractKind === 'remote_select') {
            $value = I18n::translate('valor selecionado');
        } else {
            foreach ((array) (($option['value'] ?? [])['options'] ?? []) as $valueOption) {
                if (!is_array($valueOption)) {
                    continue;
                }
                $candidate = (string) ($valueOption['value'] ?? $valueOption['id'] ?? '');
                if ($candidate === $value) {
                    $value = (string) ($valueOption['label'] ?? $valueOption['name'] ?? $value);
                    break;
                }
            }
        }
        return trim((string) ($option['label'] ?? I18n::translate('Campo')) . ' ' . $operatorLabel . ' ' . $value);
    }

    /** @return array<int,string> */
    private function narrateSorts(array $definition, array $options, array &$warnings): array
    {
        $items = [];
        foreach ((array) ($definition['sort'] ?? []) as $index => $field) {
            $field = (int) $field;
            if (!isset($options[$field])) {
                $warnings[] = I18n::translate('Uma ordenação salva não está disponível neste perfil ou entidade.');
                continue;
            }
            $direction = strtoupper((string) (((array) ($definition['order'] ?? []))[$index] ?? 'ASC'));
            $items[] = (string) $options[$field]['label']
                . ($direction === 'DESC'
                    ? ' — ' . I18n::translate('decrescente')
                    : ' — ' . I18n::translate('crescente'));
        }
        return $items;
    }

    /** @return array<int,string> */
    private function narrateColumns(array $columns, array $catalog, array &$warnings): array
    {
        $labels = [];
        foreach ($catalog as $column) {
            if (is_array($column)) {
                $labels[(string) ($column['identifier'] ?? '')] = (string) ($column['label'] ?? '');
            }
        }
        $items = [];
        foreach ($columns as $column) {
            $column = (string) $column;
            if ($column === '' || !isset($labels[$column]) || $labels[$column] === '') {
                $warnings[] = I18n::translate('Uma coluna salva não está disponível neste perfil ou entidade.');
                continue;
            }
            $items[] = $labels[$column];
        }
        return array_values(array_unique($items));
    }

    private function connector(string $link): string
    {
        return [
            'OR' => I18n::translate('OU'),
            'AND NOT' => I18n::translate('E NÃO'),
            'OR NOT' => I18n::translate('OU NÃO'),
        ][strtoupper(trim($link))] ?? I18n::translate('E');
    }

    private function withoutLeadingConnector(string $item): string
    {
        foreach (
            [
                I18n::translate('E NÃO'),
                I18n::translate('OU NÃO'),
                I18n::translate('OU'),
                I18n::translate('E'),
            ] as $connector
        ) {
            $prefix = $connector . ' ';
            if (str_starts_with($item, $prefix)) {
                return substr($item, strlen($prefix));
            }
        }

        return $item;
    }
}
