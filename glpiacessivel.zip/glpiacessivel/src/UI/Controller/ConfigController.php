<?php

declare(strict_types=1);

namespace GlpiPlugin\Glpiacessivel\UI\Controller;

use GlpiPlugin\Glpiacessivel\Application\ConfigService;
use GlpiPlugin\Glpiacessivel\Security\InputSanitizer;
use GlpiPlugin\Glpiacessivel\UI\View\View;

final class ConfigController extends BaseController
{
    public static function index(): void
    {
        self::requireLogin();

        if (!\Session::haveRight('config', UPDATE)) {
            self::denyAccess(
                __('Sem permissão', 'glpiacessivel'),
                __('Seu perfil atual não possui permissão para acessar esta funcionalidade.', 'glpiacessivel'),
                'config.permission_denied',
                ['required_right' => 'config_update']
            );
            return;
        }

        $sanitizer = new InputSanitizer();
        $saved = false;
        $config = self::container()->configService();
        $config->migrateLegacyVoiceDefaults();
        $config->migrateLegacyVoiceAssetPaths();
        $previousChatbotDisplayName = $config->getChatbotDisplayName();
        $previousModuleStates = $config->getPortalModuleStates();
        $previousAuthenticationEntryMode = $config->getAuthenticationEntryMode();
        $previousLoginAccessibilityNotice = $config->isLoginAccessibilityNoticeEnabled();
        $previousAuditMode = $config->getAuditMode();
        $previousTicketListStatementTimeoutMs = $config->getTicketListStatementTimeoutMilliseconds();

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            if (
                !self::validateCsrfOrRedirect(
                    \GlpiPlugin\Glpiacessivel\Support\Url::plugin('front/config.php'),
                    'config.csrf_rejected'
                )
            ) {
                return;
            }

            $moduleStates = $config->sanitizePortalModuleStates(
                is_array($_POST['module_states'] ?? null)
                    ? $_POST['module_states']
                    : $config->getPortalModuleStates()
            );
            $chatbotEnabled = $moduleStates[ConfigService::MODULE_CHATBOT] === ConfigService::MODULE_STATE_DISABLED
                ? '0'
                : '1';
            $chatbotDisplayName = $config->sanitizeChatbotDisplayName(
                $sanitizer->text(
                    $_POST['chatbot_display_name'] ?? $config->getChatbotDisplayName(),
                    ConfigService::CHATBOT_DISPLAY_NAME_MAX_LENGTH
                )
            );
            $chatbotFloatingScope = $sanitizer->enum(
                $_POST['chatbot_floating_scope'] ?? $config->getChatbotFloatingScope(),
                ConfigService::CHATBOT_FLOATING_SCOPES,
                $config->getChatbotFloatingScope()
            );
            $chatbotVoiceEnabled = $sanitizer->enum($_POST['chatbot_voice_enabled'] ?? '1', ['0', '1'], '1');
            $pluginFallbackLocale = $sanitizer->enum(
                $_POST['plugin_fallback_locale'] ?? $config->getPluginFallbackLocale(),
                ConfigService::SUPPORTED_LOCALES,
                $config->getPluginFallbackLocale()
            );
            $vlibrasScope = $sanitizer->enum(
                $_POST['vlibras_scope'] ?? $config->getVlibrasScope(),
                ConfigService::VLIBRAS_SCOPES,
                $config->getVlibrasScope()
            );
            $formsEnabled = $moduleStates[ConfigService::MODULE_FORMS] === ConfigService::MODULE_STATE_DISABLED
                ? '0'
                : '1';
            $piiMaskingEnabled = $sanitizer->enum(
                $_POST['pii_masking_enabled'] ?? ($config->isPiiMaskingEnabled() ? '1' : '0'),
                ['0', '1'],
                $config->isPiiMaskingEnabled() ? '1' : '0'
            );
            $formsNativeFlowMode = $sanitizer->enum(
                $_POST['forms_native_flow_mode'] ?? $config->getFormsNativeFlowMode(),
                ConfigService::FORMS_NATIVE_FLOW_MODES,
                $config->getFormsNativeFlowMode()
            );
            $formcreatorMinimalEmbedEnabled = $sanitizer->enum(
                $_POST['formcreator_minimal_embed_enabled']
                    ?? ($config->isFormcreatorMinimalEmbedEnabled() ? '1' : '0'),
                ['0', '1'],
                $config->isFormcreatorMinimalEmbedEnabled() ? '1' : '0'
            );
            $nativeFormAccessibilityBridgeEnabled = $sanitizer->enum(
                $_POST['native_form_accessibility_bridge_enabled']
                    ?? ($config->isNativeFormAccessibilityBridgeEnabled() ? '1' : '0'),
                ['0', '1'],
                $config->isNativeFormAccessibilityBridgeEnabled() ? '1' : '0'
            );
            $ticketAsyncListEnabled = $sanitizer->enum(
                $_POST['ticket_async_list_enabled'] ?? ($config->isTicketAsyncListEnabled() ? '1' : '0'),
                ['0', '1'],
                $config->isTicketAsyncListEnabled() ? '1' : '0'
            );
            $ticketListPerformanceLimitsEnabled = $sanitizer->enum(
                $_POST['ticket_list_performance_limits_enabled']
                    ?? ($config->isTicketListPerformanceLimitsEnabled() ? '1' : '0'),
                ['0', '1'],
                $config->isTicketListPerformanceLimitsEnabled() ? '1' : '0'
            );
            $ticketListCapacityGuardEnabled = $sanitizer->enum(
                $_POST['ticket_list_capacity_guard_enabled']
                    ?? ($config->isTicketListCapacityGuardEnabled() ? '1' : '0'),
                ['0', '1'],
                $config->isTicketListCapacityGuardEnabled() ? '1' : '0'
            );
            $ticketListCapacityBackend = $sanitizer->enum(
                $_POST['ticket_list_capacity_backend'] ?? $config->getTicketListCapacityBackend(),
                ConfigService::TICKET_LIST_CAPACITY_BACKENDS,
                $config->getTicketListCapacityBackend()
            );
            $ticketListStatementTimeoutMs = $config->sanitizeTicketListStatementTimeoutMilliseconds(
                $_POST['ticket_list_statement_timeout_ms'] ?? $previousTicketListStatementTimeoutMs,
                $previousTicketListStatementTimeoutMs
            );
            $exceptionalTicketListTimeout = $ticketListPerformanceLimitsEnabled === '1'
                && $ticketListStatementTimeoutMs
                    > ConfigService::TICKET_LIST_STATEMENT_TIMEOUT_MS_EXCEPTIONAL_THRESHOLD;
            if (
                $exceptionalTicketListTimeout
                && (string) ($_POST['ticket_list_timeout_risk_confirm'] ?? '0') !== '1'
            ) {
                self::setMessage(
                    'error',
                    __('O tempo excepcional não foi salvo. Confirme os requisitos de capacidade e infraestrutura.', 'glpiacessivel')
                );
                \Html::redirect(\GlpiPlugin\Glpiacessivel\Support\Url::plugin('front/config.php'));
                return;
            }
            $ticketListCapacityMaxConcurrent = min(
                ConfigService::TICKET_LIST_CAPACITY_MAX_CONCURRENT_MAX,
                max(
                    ConfigService::TICKET_LIST_CAPACITY_MAX_CONCURRENT_MIN,
                    $sanitizer->int(
                        $_POST['ticket_list_capacity_max_concurrent']
                            ?? ConfigService::TICKET_LIST_CAPACITY_MAX_CONCURRENT_DEFAULT,
                        ConfigService::TICKET_LIST_CAPACITY_MAX_CONCURRENT_DEFAULT
                    )
                )
            );
            $ticketListCapacityLeaseSeconds = min(
                ConfigService::TICKET_LIST_CAPACITY_LEASE_SECONDS_MAX,
                max(
                    ConfigService::TICKET_LIST_CAPACITY_LEASE_SECONDS_MIN,
                    $sanitizer->int(
                        $_POST['ticket_list_capacity_lease_seconds']
                            ?? ConfigService::TICKET_LIST_CAPACITY_LEASE_SECONDS_DEFAULT,
                        ConfigService::TICKET_LIST_CAPACITY_LEASE_SECONDS_DEFAULT
                    )
                )
            );
            $ticketListCapacityRetryAfterSeconds = min(
                ConfigService::TICKET_LIST_CAPACITY_RETRY_AFTER_MAX,
                max(
                    ConfigService::TICKET_LIST_CAPACITY_RETRY_AFTER_MIN,
                    $sanitizer->int(
                        $_POST['ticket_list_capacity_retry_after_seconds']
                            ?? ConfigService::TICKET_LIST_CAPACITY_RETRY_AFTER_DEFAULT,
                        ConfigService::TICKET_LIST_CAPACITY_RETRY_AFTER_DEFAULT
                    )
                )
            );
            if ($exceptionalTicketListTimeout) {
                // Long-running list queries are never allowed to bypass the
                // asynchronous shell, admission control or single-flight cap.
                $ticketAsyncListEnabled = '1';
                $ticketListCapacityGuardEnabled = '1';
                $ticketListCapacityMaxConcurrent = 1;
            }
            if ($ticketListPerformanceLimitsEnabled === '1') {
                $ticketListCapacityLeaseSeconds = max(
                    $ticketListCapacityLeaseSeconds,
                    ConfigService::deriveMinimumTicketListCapacityLeaseSeconds(
                        $ticketListStatementTimeoutMs
                    )
                );
                $ticketListCapacityRetryAfterSeconds = ConfigService::deriveEffectiveTicketListRetryAfterSeconds(
                    $ticketListStatementTimeoutMs,
                    $ticketListCapacityRetryAfterSeconds
                );
            }
            $ticketListRateLimit = min(
                ConfigService::TICKET_LIST_RATE_LIMIT_MAX,
                max(
                    ConfigService::TICKET_LIST_RATE_LIMIT_MIN,
                    $sanitizer->int(
                        $_POST['ticket_list_rate_limit'] ?? ConfigService::TICKET_LIST_RATE_LIMIT_DEFAULT,
                        ConfigService::TICKET_LIST_RATE_LIMIT_DEFAULT
                    )
                )
            );
            $ticketListRateWindowSeconds = min(
                ConfigService::TICKET_LIST_RATE_WINDOW_MAX,
                max(
                    ConfigService::TICKET_LIST_RATE_WINDOW_MIN,
                    $sanitizer->int(
                        $_POST['ticket_list_rate_window_seconds'] ?? ConfigService::TICKET_LIST_RATE_WINDOW_DEFAULT,
                        ConfigService::TICKET_LIST_RATE_WINDOW_DEFAULT
                    )
                )
            );
            $ticketListRateBurst = min(
                $ticketListRateLimit,
                ConfigService::TICKET_LIST_RATE_BURST_MAX,
                max(
                    ConfigService::TICKET_LIST_RATE_BURST_MIN,
                    $sanitizer->int(
                        $_POST['ticket_list_rate_burst'] ?? ConfigService::TICKET_LIST_RATE_BURST_DEFAULT,
                        ConfigService::TICKET_LIST_RATE_BURST_DEFAULT
                    )
                )
            );
            $resourceSelectorEnabled = $sanitizer->enum(
                $_POST['resource_selector_enabled'] ?? ($config->isResourceSelectorEnabled() ? '1' : '0'),
                ['0', '1'],
                $config->isResourceSelectorEnabled() ? '1' : '0'
            );
            $resourceSelectorCreateEnabled = $sanitizer->enum(
                $_POST['resource_selector_create_enabled'] ?? ($config->isResourceSelectorCreateEnabled() ? '1' : '0'),
                ['0', '1'],
                $config->isResourceSelectorCreateEnabled() ? '1' : '0'
            );
            $resourceSelectorRoutingEnabled = $sanitizer->enum(
                $_POST['resource_selector_routing_enabled'] ?? ($config->isResourceSelectorRoutingEnabled() ? '1' : '0'),
                ['0', '1'],
                $config->isResourceSelectorRoutingEnabled() ? '1' : '0'
            );
            $formCatalogV2Enabled = $sanitizer->enum(
                $_POST['form_catalog_v2_enabled'] ?? ($config->isFormCatalogV2Enabled() ? '1' : '0'),
                ['0', '1'],
                $config->isFormCatalogV2Enabled() ? '1' : '0'
            );
            $accessibilityMode = $sanitizer->enum(
                $_POST['accessibility_mode'] ?? ConfigService::ACCESSIBILITY_MODE_HYBRID,
                [
                    ConfigService::ACCESSIBILITY_MODE_PORTAL,
                    ConfigService::ACCESSIBILITY_MODE_EMBEDDED,
                    ConfigService::ACCESSIBILITY_MODE_HYBRID,
                ],
                ConfigService::ACCESSIBILITY_MODE_HYBRID
            );
            $authenticationEntryMode = $config->sanitizeAuthenticationEntryMode(
                $sanitizer->text(
                    $_POST['authentication_entry_mode'] ?? $config->getAuthenticationEntryMode(),
                    64
                )
            );
            $showLoginAccessibilityNotice = $sanitizer->enum(
                $_POST['show_login_accessibility_notice']
                    ?? ($config->isLoginAccessibilityNoticeEnabled() ? '1' : '0'),
                ['0', '1'],
                $config->isLoginAccessibilityNoticeEnabled() ? '1' : '0'
            );
            $auditRetentionDays = min(3650, max(30, $sanitizer->int($_POST['audit_retention_days'] ?? 365, 365)));
            $auditRetentionBatchSize = min(
                ConfigService::AUDIT_RETENTION_BATCH_SIZE_MAX,
                max(
                    ConfigService::AUDIT_RETENTION_BATCH_SIZE_MIN,
                    $sanitizer->int(
                        $_POST['audit_retention_batch_size'] ?? ConfigService::AUDIT_RETENTION_BATCH_SIZE_DEFAULT,
                        ConfigService::AUDIT_RETENTION_BATCH_SIZE_DEFAULT
                    )
                )
            );
            $requestedAuditMode = $sanitizer->enum(
                $_POST['audit_mode'] ?? $previousAuditMode,
                ConfigService::AUDIT_MODES,
                $previousAuditMode
            );
            if (
                $requestedAuditMode === ConfigService::AUDIT_MODE_DISABLED
                && (
                    !$config->isAuditDisabledAllowed()
                    || ((string) ($_POST['audit_disabled_confirm'] ?? '0')) !== '1'
                )
            ) {
                self::setMessage(
                    'error',
                    __('A auditoria não foi desativada. É necessária habilitação local e confirmação explícita.', 'glpiacessivel')
                );
                \Html::redirect(\GlpiPlugin\Glpiacessivel\Support\Url::plugin('front/config.php'));
                return;
            }
            $auditMode = $config->sanitizeAuditMode($requestedAuditMode, $previousAuditMode);
            $requestedIntents = array_values(array_unique(array_map(
                static fn($value): string => $sanitizer->text($value, 80),
                (array) ($_POST['chatbot_enabled_intents'] ?? [])
            )));
            $chatbotVoiceLocale = $sanitizer->text($_POST['chatbot_voice_locale'] ?? 'pt-BR', 8);
            $chatbotVoiceAssetMode = $sanitizer->enum(
                $_POST['chatbot_voice_asset_mode'] ?? 'local_preferred',
                ConfigService::CHATBOT_VOICE_ASSET_MODES,
                'local_preferred'
            );
            $chatbotSttEngine = $sanitizer->enum(
                $_POST['chatbot_stt_engine'] ?? 'vosklet',
                ConfigService::CHATBOT_STT_ENGINES,
                'vosklet'
            );
            $chatbotTtsEngine = $sanitizer->enum(
                $_POST['chatbot_tts_engine'] ?? 'browser_native',
                ConfigService::CHATBOT_TTS_ENGINES,
                'browser_native'
            );
            $chatbotSttScriptUrl = $config->sanitizeChatbotExternalVoiceUrl(
                $sanitizer->text($_POST['chatbot_stt_script_url'] ?? '', 500),
                $config->getChatbotSttScriptUrl()
            );
            $chatbotSttModelUrl = $config->sanitizeChatbotExternalVoiceUrl(
                $sanitizer->text($_POST['chatbot_stt_model_url'] ?? '', 500),
                $config->getChatbotSttModelUrl()
            );
            $chatbotSttModelLabel = $sanitizer->text($_POST['chatbot_stt_model_label'] ?? '', 120);
            $chatbotSttModelCacheId = $sanitizer->text($_POST['chatbot_stt_model_cache_id'] ?? '', 120);
            $chatbotSttModelCacheId = preg_replace('/[^a-z0-9\-_]/i', '-', $chatbotSttModelCacheId) ?? 'glpi-vosk-ptbr';
            $chatbotTtsScriptUrl = $config->sanitizeChatbotExternalVoiceUrl(
                $sanitizer->text($_POST['chatbot_tts_script_url'] ?? '', 500),
                $config->getChatbotTtsScriptUrl()
            );
            $chatbotTtsVoiceId = $sanitizer->text($_POST['chatbot_tts_voice_id'] ?? '', 120);
            $chatbotSttScriptLocalPath = $config->sanitizeChatbotSttScriptLocalPath(
                $sanitizer->text($_POST['chatbot_stt_script_local_path'] ?? '', 300)
            );
            $chatbotSttModelLocalPath = $config->sanitizeChatbotSttModelLocalPath(
                $sanitizer->text($_POST['chatbot_stt_model_local_path'] ?? '', 300)
            );
            $chatbotTtsScriptLocalPath = $config->sanitizeChatbotTtsScriptLocalPath(
                $sanitizer->text($_POST['chatbot_tts_script_local_path'] ?? '', 300)
            );
            $chatbotTtsOnnxRuntimeLocalPath = $config->sanitizeChatbotTtsOnnxRuntimeLocalPath(
                $sanitizer->text($_POST['chatbot_tts_onnx_runtime_local_path'] ?? '', 300)
            );
            $chatbotTtsOnnxWasmLocalPath = $config->sanitizeChatbotTtsOnnxWasmLocalPath(
                $sanitizer->text($_POST['chatbot_tts_onnx_wasm_local_path'] ?? '', 300)
            );
            $chatbotTtsPiperWasmLocalPath = $config->sanitizeChatbotTtsPiperWasmLocalPath(
                $sanitizer->text($_POST['chatbot_tts_piper_wasm_local_path'] ?? '', 300)
            );
            $chatbotTtsPiperDataLocalPath = $config->sanitizeChatbotTtsPiperDataLocalPath(
                $sanitizer->text($_POST['chatbot_tts_piper_data_local_path'] ?? '', 300)
            );
            $chatbotTtsVoiceModelLocalPath = $config->sanitizeChatbotTtsVoiceModelLocalPath(
                $sanitizer->text($_POST['chatbot_tts_voice_model_local_path'] ?? '', 300)
            );
            $chatbotTtsVoiceConfigLocalPath = $config->sanitizeChatbotTtsVoiceConfigLocalPath(
                $sanitizer->text($_POST['chatbot_tts_voice_config_local_path'] ?? '', 300)
            );

            $config->setPortalModuleStates($moduleStates);
            $config->setValue('chatbot_display_name', $chatbotDisplayName);
            $config->setValue('chatbot_floating_scope', $chatbotFloatingScope);
            $config->setValue('chatbot_floating_button_enabled', $chatbotFloatingScope === 'disabled' ? '0' : '1');
            $config->setValue('chatbot_voice_enabled', $chatbotVoiceEnabled);
            $config->setValue('plugin_fallback_locale', $pluginFallbackLocale);
            $config->setValue('vlibras_scope', $vlibrasScope);
            $config->setValue('pii_masking_enabled', $piiMaskingEnabled);
            $config->setValue('forms_native_flow_mode', $formsNativeFlowMode);
            $config->setValue('formcreator_minimal_embed_enabled', $formcreatorMinimalEmbedEnabled);
            $config->setValue(
                'native_form_accessibility_bridge_enabled',
                $nativeFormAccessibilityBridgeEnabled
            );
            $config->setValue('ticket_async_list_enabled', $ticketAsyncListEnabled);
            $config->setValue('ticket_list_performance_limits_enabled', $ticketListPerformanceLimitsEnabled);
            $config->setValue('ticket_list_capacity_guard_enabled', $ticketListCapacityGuardEnabled);
            $config->setValue('ticket_list_capacity_backend', $ticketListCapacityBackend);
            $config->setValue(
                'ticket_list_statement_timeout_ms',
                (string) $ticketListStatementTimeoutMs
            );
            $config->setValue('ticket_list_capacity_max_concurrent', (string) $ticketListCapacityMaxConcurrent);
            $config->setValue('ticket_list_capacity_lease_seconds', (string) $ticketListCapacityLeaseSeconds);
            $config->setValue(
                'ticket_list_capacity_retry_after_seconds',
                (string) $ticketListCapacityRetryAfterSeconds
            );
            $config->setValue('ticket_list_rate_limit', (string) $ticketListRateLimit);
            $config->setValue('ticket_list_rate_window_seconds', (string) $ticketListRateWindowSeconds);
            $config->setValue('ticket_list_rate_burst', (string) $ticketListRateBurst);
            $config->setValue('resource_selector_enabled', $resourceSelectorEnabled);
            $config->setValue('resource_selector_create_enabled', $resourceSelectorCreateEnabled);
            $config->setValue('resource_selector_routing_enabled', $resourceSelectorRoutingEnabled);
            $config->setValue('form_catalog_v2_enabled', $formCatalogV2Enabled);
            $config->setValue('accessibility_mode', $accessibilityMode);
            $config->setValue('authentication_entry_mode', $authenticationEntryMode);
            $config->setValue('show_login_accessibility_notice', $showLoginAccessibilityNotice);
            $config->setValue('audit_retention_days', (string) $auditRetentionDays);
            $config->setValue('audit_retention_batch_size', (string) $auditRetentionBatchSize);
            $config->setValue('audit_mode', $auditMode);
            $config->setValue('chatbot_voice_locale', $chatbotVoiceLocale);
            $config->setValue('chatbot_voice_asset_mode', $chatbotVoiceAssetMode);
            $config->setValue('chatbot_stt_engine', $chatbotSttEngine);
            $config->setValue('chatbot_tts_engine', $chatbotTtsEngine);
            $config->setValue('chatbot_stt_script_local_path', $chatbotSttScriptLocalPath);
            $config->setValue('chatbot_stt_model_local_path', $chatbotSttModelLocalPath);
            $config->setValue('chatbot_tts_script_local_path', $chatbotTtsScriptLocalPath);
            $config->setValue('chatbot_tts_onnx_runtime_local_path', $chatbotTtsOnnxRuntimeLocalPath);
            $config->setValue('chatbot_tts_onnx_wasm_local_path', $chatbotTtsOnnxWasmLocalPath);
            $config->setValue('chatbot_tts_piper_wasm_local_path', $chatbotTtsPiperWasmLocalPath);
            $config->setValue('chatbot_tts_piper_data_local_path', $chatbotTtsPiperDataLocalPath);
            $config->setValue('chatbot_tts_voice_model_local_path', $chatbotTtsVoiceModelLocalPath);
            $config->setValue('chatbot_tts_voice_config_local_path', $chatbotTtsVoiceConfigLocalPath);
            $config->setValue('chatbot_stt_script_url', $chatbotSttScriptUrl);
            $config->setValue('chatbot_stt_model_url', $chatbotSttModelUrl);
            $config->setValue('chatbot_stt_model_label', $chatbotSttModelLabel);
            $config->setValue('chatbot_stt_model_cache_id', $chatbotSttModelCacheId);
            $config->setValue('chatbot_tts_script_url', $chatbotTtsScriptUrl);
            $config->setValue('chatbot_tts_voice_id', $chatbotTtsVoiceId);
            $config->setChatbotEnabledIntents($requestedIntents);

            self::container()->auditLogger()->log('config.update', [
                'chatbot_enabled' => $chatbotEnabled,
                'chatbot_display_name_changed' => $chatbotDisplayName !== $previousChatbotDisplayName,
                'chatbot_display_name_length' => mb_strlen($chatbotDisplayName, 'UTF-8'),
                'chatbot_floating_scope' => $chatbotFloatingScope,
                'chatbot_voice_enabled' => $chatbotVoiceEnabled,
                'plugin_fallback_locale' => $pluginFallbackLocale,
                'vlibras_scope' => $vlibrasScope,
                'forms_enabled' => $formsEnabled,
                'module_states' => $moduleStates,
                'pii_masking_enabled' => $piiMaskingEnabled,
                'forms_native_flow_mode' => $formsNativeFlowMode,
                'formcreator_minimal_embed_enabled' => $formcreatorMinimalEmbedEnabled,
                'native_form_accessibility_bridge_enabled' => $nativeFormAccessibilityBridgeEnabled,
                'ticket_async_list_enabled' => $ticketAsyncListEnabled,
                'ticket_list_performance_limits_enabled' => $ticketListPerformanceLimitsEnabled,
                'ticket_list_capacity_guard_enabled' => $ticketListCapacityGuardEnabled,
                'ticket_list_capacity_backend' => $ticketListCapacityBackend,
                'ticket_list_statement_timeout_ms' => $ticketListStatementTimeoutMs,
                'ticket_list_request_timeout_ms' => $config->getTicketListRequestTimeoutMilliseconds(),
                'ticket_list_timeout_exceptional' => $exceptionalTicketListTimeout,
                'ticket_list_capacity_max_concurrent' => $ticketListCapacityMaxConcurrent,
                'ticket_list_capacity_lease_seconds' => $ticketListCapacityLeaseSeconds,
                'ticket_list_capacity_retry_after_seconds' => $ticketListCapacityRetryAfterSeconds,
                'ticket_list_rate_limit' => $ticketListRateLimit,
                'ticket_list_rate_window_seconds' => $ticketListRateWindowSeconds,
                'ticket_list_rate_burst' => $ticketListRateBurst,
                'resource_selector_enabled' => $resourceSelectorEnabled,
                'resource_selector_create_enabled' => $resourceSelectorCreateEnabled,
                'resource_selector_routing_enabled' => $resourceSelectorRoutingEnabled,
                'form_catalog_v2_enabled' => $formCatalogV2Enabled,
                'accessibility_mode' => $accessibilityMode,
                'authentication_entry_mode' => $authenticationEntryMode,
                'show_login_accessibility_notice' => $showLoginAccessibilityNotice,
                'audit_retention_days' => $auditRetentionDays,
                'audit_retention_batch_size' => $auditRetentionBatchSize,
                'audit_mode' => $auditMode,
                'chatbot_voice_locale' => $chatbotVoiceLocale,
                'chatbot_voice_asset_mode' => $chatbotVoiceAssetMode,
                'chatbot_stt_engine' => $chatbotSttEngine,
                'chatbot_tts_engine' => $chatbotTtsEngine,
                'chatbot_enabled_intents_count' => count($config->getChatbotEnabledIntents()),
            ]);
            if ($moduleStates !== $previousModuleStates) {
                self::container()->auditLogger()->log('config.modules_updated', [
                    'previous' => $previousModuleStates,
                    'current' => $moduleStates,
                ]);
            }
            if ($authenticationEntryMode !== $previousAuthenticationEntryMode) {
                self::container()->auditLogger()->log('config.authentication_entry_mode_updated', [
                    'previous' => $previousAuthenticationEntryMode,
                    'current' => $authenticationEntryMode,
                ]);
            }
            if (($showLoginAccessibilityNotice === '1') !== $previousLoginAccessibilityNotice) {
                self::container()->auditLogger()->log('config.login_accessibility_notice_updated', [
                    'previous' => $previousLoginAccessibilityNotice ? '1' : '0',
                    'current' => $showLoginAccessibilityNotice,
                ]);
            }
            if ($ticketListStatementTimeoutMs !== $previousTicketListStatementTimeoutMs) {
                self::container()->auditLogger()->log('config.ticket_list_timeout_updated', [
                    'previous_timeout_ms' => $previousTicketListStatementTimeoutMs,
                    'current_timeout_ms' => $ticketListStatementTimeoutMs,
                    'request_timeout_ms' => $config->getTicketListRequestTimeoutMilliseconds(),
                    'effective_lease_seconds' => $ticketListCapacityLeaseSeconds,
                    'exceptional' => $exceptionalTicketListTimeout,
                ]);
            }
            unset($_SESSION['glpimenu']);
            $saved = true;
        }

        View::render('config/index', [
            'title' => __('Configuração do plugin', 'glpiacessivel'),
            'saved' => $saved,
            'csrf_token' => self::csrf()->token(),
            'chatbot_enabled' => $config->isChatbotEnabled() ? '1' : '0',
            'chatbot_display_name' => $config->getChatbotDisplayName(),
            'chatbot_floating_scope' => $config->getChatbotFloatingScope(),
            'chatbot_floating_scopes' => ConfigService::CHATBOT_FLOATING_SCOPES,
            'chatbot_voice_enabled' => $config->isChatbotVoiceEnabled() ? '1' : '0',
            'plugin_fallback_locale' => $config->getPluginFallbackLocale(),
            'supported_locales' => ConfigService::SUPPORTED_LOCALES,
            'vlibras_scope' => $config->getVlibrasScope(),
            'vlibras_scopes' => ConfigService::VLIBRAS_SCOPES,
            'forms_enabled' => $config->isFormsEnabled() ? '1' : '0',
            'portal_modules' => ConfigService::PORTAL_MODULES,
            'portal_module_states' => $config->getPortalModuleStates(),
            'portal_module_effective_states' => self::container()->portalModulePolicy()->getEffectiveStates(),
            'portal_module_labels' => self::portalModuleLabels(),
            'portal_module_descriptions' => self::portalModuleDescriptions(),
            'portal_module_state_labels' => self::portalModuleStateLabels(),
            'portal_module_state_descriptions' => self::portalModuleStateDescriptions(),
            'portal_module_presets' => ConfigService::MODULE_PRESETS,
            'portal_module_preset_labels' => self::portalModulePresetLabels(),
            'pii_masking_enabled' => $config->isPiiMaskingEnabled() ? '1' : '0',
            'forms_native_flow_mode' => $config->getFormsNativeFlowMode(),
            'forms_native_flow_modes' => ConfigService::FORMS_NATIVE_FLOW_MODES,
            'formcreator_minimal_embed_enabled' => $config->isFormcreatorMinimalEmbedEnabled() ? '1' : '0',
            'native_form_accessibility_bridge_enabled' => $config->isNativeFormAccessibilityBridgeEnabled()
                ? '1'
                : '0',
            'ticket_async_list_enabled' => $config->isTicketAsyncListEnabled() ? '1' : '0',
            'ticket_list_performance_limits_enabled' => $config->isTicketListPerformanceLimitsEnabled() ? '1' : '0',
            'ticket_list_capacity_guard_enabled' => $config->isTicketListCapacityGuardEnabled() ? '1' : '0',
            'ticket_list_capacity_backend' => $config->getTicketListCapacityBackend(),
            'ticket_list_capacity_backends' => ConfigService::TICKET_LIST_CAPACITY_BACKENDS,
            'ticket_list_capacity_max_concurrent' => $config->getTicketListCapacityMaxConcurrent(),
            'ticket_list_capacity_lease_seconds' => $config->getTicketListCapacityLeaseSeconds(),
            'ticket_list_capacity_retry_after_seconds' => $config->getTicketListCapacityRetryAfterSeconds(),
            'ticket_list_statement_timeout_ms' => $config->getTicketListStatementTimeoutMilliseconds(),
            'ticket_list_request_timeout_ms' => $config->getTicketListRequestTimeoutMilliseconds(),
            'ticket_list_effective_capacity_lease_seconds' => $config->getEffectiveTicketListCapacityLeaseSeconds(),
            'ticket_list_effective_max_concurrent' => $config->getEffectiveTicketListCapacityMaxConcurrent(),
            'ticket_list_rate_limit' => $config->getTicketListRateLimit(),
            'ticket_list_rate_window_seconds' => $config->getTicketListRateWindowSeconds(),
            'ticket_list_rate_burst' => $config->getTicketListRateBurst(),
            'resource_selector_enabled' => $config->isResourceSelectorEnabled() ? '1' : '0',
            'resource_selector_create_enabled' => $config->isResourceSelectorCreateEnabled() ? '1' : '0',
            'resource_selector_routing_enabled' => $config->isResourceSelectorRoutingEnabled() ? '1' : '0',
            'form_catalog_v2_enabled' => $config->isFormCatalogV2Enabled() ? '1' : '0',
            'i18n_diagnostics' => $config->getI18nDiagnostics(),
            'operational_diagnostics' => $config->getOperationalDiagnostics(),
            'accessibility_mode' => $config->getAccessibilityMode(),
            'authentication_entry_mode' => $config->getAuthenticationEntryMode(),
            'authentication_entry_supported_modes' => ConfigService::AUTHENTICATION_ENTRY_SUPPORTED_MODES,
            'show_login_accessibility_notice' => $config->isLoginAccessibilityNoticeEnabled() ? '1' : '0',
            'audit_retention_days' => $config->getAuditRetentionDays(),
            'audit_retention_batch_size' => $config->getAuditRetentionBatchSize(),
            'audit_mode' => $config->getAuditMode(),
            'audit_modes' => ConfigService::AUDIT_MODES,
            'audit_disabled_allowed' => $config->isAuditDisabledAllowed(),
            'can_read_audit' => self::container()->auditAuthorization()->canRead(),
            'chatbot_intents' => ConfigService::CHATBOT_INTENTS,
            'chatbot_enabled_intents' => $config->getChatbotEnabledIntents(),
            'chatbot_intent_labels' => self::chatbotIntentLabels(),
            'chatbot_voice_locale' => $config->getChatbotVoiceLocale(),
            'chatbot_voice_asset_modes' => ConfigService::CHATBOT_VOICE_ASSET_MODES,
            'chatbot_voice_asset_mode' => $config->getChatbotVoiceAssetMode(),
            'chatbot_stt_engines' => ConfigService::CHATBOT_STT_ENGINES,
            'chatbot_tts_engines' => ConfigService::CHATBOT_TTS_ENGINES,
            'chatbot_stt_engine' => $config->getChatbotSttEngine(),
            'chatbot_tts_engine' => $config->getChatbotTtsEngine(),
            'chatbot_stt_script_local_path' => $config->getChatbotSttScriptLocalPath(),
            'chatbot_stt_model_local_path' => $config->getChatbotSttModelLocalPath(),
            'chatbot_tts_script_local_path' => $config->getChatbotTtsScriptLocalPath(),
            'chatbot_tts_onnx_runtime_local_path' => $config->getChatbotTtsOnnxRuntimeLocalPath(),
            'chatbot_tts_onnx_wasm_local_path' => $config->getChatbotTtsOnnxWasmLocalPath(),
            'chatbot_tts_piper_wasm_local_path' => $config->getChatbotTtsPiperWasmLocalPath(),
            'chatbot_tts_piper_data_local_path' => $config->getChatbotTtsPiperDataLocalPath(),
            'chatbot_tts_voice_model_local_path' => $config->getChatbotTtsVoiceModelLocalPath(),
            'chatbot_tts_voice_config_local_path' => $config->getChatbotTtsVoiceConfigLocalPath(),
            'chatbot_stt_script_url' => $config->getChatbotSttScriptUrl(),
            'chatbot_stt_model_url' => $config->getChatbotSttModelUrl(),
            'chatbot_stt_model_label' => $config->getChatbotSttModelLabel(),
            'chatbot_stt_model_cache_id' => $config->getChatbotSttModelCacheId(),
            'chatbot_tts_script_url' => $config->getChatbotTtsScriptUrl(),
            'chatbot_tts_voice_id' => $config->getChatbotTtsVoiceId(),
        ]);
    }

    /** @return array<string, string> */
    private static function portalModuleLabels(): array
    {
        return [
            ConfigService::MODULE_TICKET_CREATE => __('Abrir chamado', 'glpiacessivel'),
            ConfigService::MODULE_FORMS => __('Formulários', 'glpiacessivel'),
            ConfigService::MODULE_TICKETS => __('Chamados', 'glpiacessivel'),
            ConfigService::MODULE_COCKPIT => __('Cockpit', 'glpiacessivel'),
            ConfigService::MODULE_KNOWLEDGE => __('Base de conhecimento', 'glpiacessivel'),
            ConfigService::MODULE_CHATBOT => __('Chatbot operacional', 'glpiacessivel'),
            ConfigService::MODULE_PLAYBOOKS => __('Roteiros do chatbot', 'glpiacessivel'),
        ];
    }

    /** @return array<string, string> */
    private static function portalModuleDescriptions(): array
    {
        return [
            ConfigService::MODULE_TICKET_CREATE => __('Criação direta de chamados pelo portal acessível.', 'glpiacessivel'),
            ConfigService::MODULE_FORMS => __('Catálogo de formulários do GLPI 11 ou Formcreator do GLPI 10.', 'glpiacessivel'),
            ConfigService::MODULE_TICKETS => __('Listagem, detalhes e interações permitidas nos chamados.', 'glpiacessivel'),
            ConfigService::MODULE_COCKPIT => __('Indicadores operacionais derivados dos chamados visíveis.', 'glpiacessivel'),
            ConfigService::MODULE_KNOWLEDGE => __('Pesquisa e leitura da base de conhecimento.', 'glpiacessivel'),
            ConfigService::MODULE_CHATBOT => __('Assistente operacional com intenções limitadas pelos demais módulos e pelas permissões do GLPI.', 'glpiacessivel'),
            ConfigService::MODULE_PLAYBOOKS => __('Administração e curadoria dos roteiros do chatbot.', 'glpiacessivel'),
        ];
    }

    /** @return array<string, string> */
    private static function portalModuleStateLabels(): array
    {
        return [
            ConfigService::MODULE_STATE_AVAILABLE => __('Disponível no portal', 'glpiacessivel'),
            ConfigService::MODULE_STATE_HIDDEN => __('Oculto da navegação', 'glpiacessivel'),
            ConfigService::MODULE_STATE_DISABLED => __('Indisponível', 'glpiacessivel'),
        ];
    }

    /** @return array<string, string> */
    private static function portalModuleStateDescriptions(): array
    {
        return [
            ConfigService::MODULE_STATE_AVAILABLE => __('Aparece nos menus e atalhos quando as permissões do GLPI permitirem.', 'glpiacessivel'),
            ConfigService::MODULE_STATE_HIDDEN => __('Não aparece na navegação, mas o acesso direto continua sujeito às permissões do GLPI.', 'glpiacessivel'),
            ConfigService::MODULE_STATE_DISABLED => __('Não aparece e suas rotas de consulta e alteração ficam bloqueadas.', 'glpiacessivel'),
        ];
    }

    /** @return array<string, string> */
    private static function portalModulePresetLabels(): array
    {
        return [
            'complete' => __('Experiência completa', 'glpiacessivel'),
            'presentation_basic' => __('Apresentação básica', 'glpiacessivel'),
            'read_only_demo' => __('Demonstração de consulta', 'glpiacessivel'),
            'self_service_pilot' => __('Piloto Self-Service', 'glpiacessivel'),
            'technical_pilot' => __('Piloto técnico', 'glpiacessivel'),
        ];
    }
    private static function chatbotIntentLabels(): array
    {
        return [
            'mine_tickets' => __('Listar meus chamados', 'glpiacessivel'),
            'ticket_lookup' => __('Consultar chamado por número', 'glpiacessivel'),
            'ticket_criar_guiado' => __('Criar chamado guiado', 'glpiacessivel'),
            'ticket_triagem_inicial' => __('Triagem inicial', 'glpiacessivel'),
            'ticket_escalonar' => __('Encaminhar chamado', 'glpiacessivel'),
            'ticket_reclassificar' => __('Alterar categoria ou tipo', 'glpiacessivel'),
            'ticket_priorizar' => __('Priorizar por urgência e impacto', 'glpiacessivel'),
            'ticket_sla_status' => __('Consultar risco de prazo', 'glpiacessivel'),
            'ticket_followup_operacional' => __('Registrar acompanhamento operacional', 'glpiacessivel'),
            'ticket_encerrar_com_validacao' => __('Encerrar com validação', 'glpiacessivel'),
            'kb_recomendar_contextual' => __('Recomendar artigos da base', 'glpiacessivel'),
            'comunicacao_usuario' => __('Sugerir comunicação ao requisitante', 'glpiacessivel'),
            'auditoria_consulta' => __('Consultar trilha de auditoria', 'glpiacessivel'),
            'handoff_humano' => __('Encaminhar para atendimento humano', 'glpiacessivel'),
        ];
    }
}
