<section class="glpiacessivel-card" aria-labelledby="config-title">
  <h2 id="config-title"><?= glpiacessivel_e(glpiacessivel_t('Parâmetros')) ?></h2>
  <?php if (!empty($saved)) : ?>
    <p role="status" aria-live="polite"><?= glpiacessivel_e(glpiacessivel_t('Configuração salva com sucesso.')) ?></p>
      <?php
  endif; ?>

  <form method="post" action="<?= glpiacessivel_e(glpiacessivel_url('front/config.php')) ?>" class="glpiacessivel-form-grid">
    <input type="hidden" name="_glpi_csrf_token" value="<?= glpiacessivel_e($csrf_token) ?>" />
    <?php
      $moduleStates = is_array($portal_module_states ?? null) ? $portal_module_states : [];
      $moduleEffectiveStates = is_array($portal_module_effective_states ?? null) ? $portal_module_effective_states : $moduleStates;
      $modulePresetsJson = json_encode(
          $portal_module_presets ?? [],
          JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES
      ) ?: '{}';
        ?>
    <section class="glpiacessivel-module-settings" aria-labelledby="portal-modules-title">
      <h3 id="portal-modules-title"><?= glpiacessivel_e(glpiacessivel_t('Funcionalidades disponíveis no portal')) ?></h3>
      <p id="portal-modules-help" class="glpiacessivel-help-text">
        <?= glpiacessivel_e(glpiacessivel_t('A disponibilidade nunca amplia permissões: o perfil, a entidade e as regras de acesso do GLPI continuam sendo validados.')) ?>
      </p>

      <div class="glpiacessivel-module-preset">
        <div class="glpiacessivel-field">
          <label for="portal_module_preset"><?= glpiacessivel_e(glpiacessivel_t('Configuração predefinida')) ?></label>
          <select
            id="portal_module_preset"
            data-glpiacessivel-module-preset
            data-presets="<?= glpiacessivel_e($modulePresetsJson) ?>"
            aria-describedby="portal-module-preset-help"
          >
            <?php foreach (($portal_module_presets ?? []) as $presetKey => $presetStates) : ?>
              <option value="<?= glpiacessivel_e((string) $presetKey) ?>">
                <?= glpiacessivel_e((string) (($portal_module_preset_labels[$presetKey] ?? $presetKey))) ?>
              </option>
            <?php endforeach; ?>
          </select>
          <p id="portal-module-preset-help" class="glpiacessivel-help-text">
            <?= glpiacessivel_e(glpiacessivel_t('A configuração predefinida apenas prepara os controles. Revise as opções e selecione Salvar para confirmar.')) ?>
          </p>
        </div>
        <button
          type="button"
          class="glpiacessivel-button glpiacessivel-button-secondary"
          data-glpiacessivel-module-preset-apply
          data-announcement="<?= glpiacessivel_e(glpiacessivel_t('Configuração predefinida aplicada. Revise as funcionalidades e salve a configuração.')) ?>"
        >
          <?= glpiacessivel_e(glpiacessivel_t('Aplicar configuração predefinida ao formulário')) ?>
        </button>
      </div>

      <p
        id="portal-module-preset-status"
        class="glpiacessivel-help-text"
        role="status"
        aria-live="polite"
        data-glpiacessivel-module-status
      ></p>
      <p
        id="portal-module-dependency-status"
        class="glpiacessivel-alert glpiacessivel-alert-warning"
        role="status"
        aria-live="polite"
        data-glpiacessivel-module-dependency
        data-disabled-message="<?= glpiacessivel_e(glpiacessivel_t('O cockpit também ficará indisponível porque depende do módulo Chamados.')) ?>"
        data-hidden-message="<?= glpiacessivel_e(glpiacessivel_t('O cockpit também ficará oculto porque depende do módulo Chamados.')) ?>"
        hidden
      ></p>

      <div class="glpiacessivel-module-grid" aria-describedby="portal-modules-help">
        <?php foreach (($portal_modules ?? []) as $module) : ?>
            <?php
            $moduleKey = (string) $module;
            $moduleState = (string) ($moduleStates[$moduleKey] ?? 'available');
            $effectiveState = (string) ($moduleEffectiveStates[$moduleKey] ?? $moduleState);
            $moduleId = 'portal-module-' . preg_replace('/[^a-z0-9_-]/i', '-', $moduleKey);
            ?>
          <fieldset
            class="glpiacessivel-module-card"
            data-glpiacessivel-module="<?= glpiacessivel_e($moduleKey) ?>"
            aria-describedby="<?= glpiacessivel_e($moduleId) ?>-description"
          >
            <legend><?= glpiacessivel_e((string) ($portal_module_labels[$moduleKey] ?? $moduleKey)) ?></legend>
            <p id="<?= glpiacessivel_e($moduleId) ?>-description" class="glpiacessivel-help-text">
              <?= glpiacessivel_e((string) ($portal_module_descriptions[$moduleKey] ?? '')) ?>
            </p>
            <div class="glpiacessivel-module-state-options">
              <?php foreach (($portal_module_state_labels ?? []) as $stateKey => $stateLabel) : ?>
                    <?php $stateId = $moduleId . '-' . preg_replace('/[^a-z0-9_-]/i', '-', (string) $stateKey); ?>
                <label for="<?= glpiacessivel_e($stateId) ?>" class="glpiacessivel-module-state-option">
                  <input
                    id="<?= glpiacessivel_e($stateId) ?>"
                    type="radio"
                    name="module_states[<?= glpiacessivel_e($moduleKey) ?>]"
                    value="<?= glpiacessivel_e((string) $stateKey) ?>"
                    <?= $moduleState === $stateKey ? 'checked' : '' ?>
                  />
                  <span>
                    <strong><?= glpiacessivel_e((string) $stateLabel) ?></strong>
                    <small><?= glpiacessivel_e((string) ($portal_module_state_descriptions[$stateKey] ?? '')) ?></small>
                  </span>
                </label>
              <?php endforeach; ?>
            </div>
            <?php if ($effectiveState !== $moduleState) : ?>
              <p class="glpiacessivel-help-text">
                <?= glpiacessivel_e(glpiacessivel_t('Estado efetivo ajustado por dependência:')) ?>
                <strong><?= glpiacessivel_e((string) ($portal_module_state_labels[$effectiveState] ?? $effectiveState)) ?></strong>
              </p>
            <?php endif; ?>
          </fieldset>
        <?php endforeach; ?>
      </div>
    </section>

    <label for="accessibility_mode"><?= glpiacessivel_e(glpiacessivel_t('Modo de acessibilidade')) ?></label>
    <select id="accessibility_mode" name="accessibility_mode">
      <option value="portal" <?= ($accessibility_mode ?? 'hybrid') === 'portal' ? 'selected' : '' ?>>
        <?= glpiacessivel_e(glpiacessivel_t('Portal acessível')) ?>
      </option>
      <option value="embedded" <?= ($accessibility_mode ?? 'hybrid') === 'embedded' ? 'selected' : '' ?>>
        <?= glpiacessivel_e(glpiacessivel_t('Embutido no GLPI')) ?>
      </option>
      <option value="hybrid" <?= ($accessibility_mode ?? 'hybrid') === 'hybrid' ? 'selected' : '' ?>>
        <?= glpiacessivel_e(glpiacessivel_t('Híbrido')) ?>
      </option>
    </select>

    <div class="glpiacessivel-field" style="grid-column: 1 / -1;">
      <p class="glpiacessivel-help-text">
        <?= glpiacessivel_e(glpiacessivel_t('Escolha como a experiência acessível deve funcionar com o GLPI padrão.')) ?>
      </p>
      <div class="glpiacessivel-config-path-list" aria-label="<?= glpiacessivel_e(glpiacessivel_t('Resumo dos modos de acessibilidade')) ?>">
        <p><strong><?= glpiacessivel_e(glpiacessivel_t('Portal acessível:')) ?></strong> <?= glpiacessivel_e(glpiacessivel_t('usa as telas do plugin como caminho principal, com maior independência da interface do GLPI e maior controle dos requisitos WCAG e eMAG.')) ?></p>
        <p><strong><?= glpiacessivel_e(glpiacessivel_t('Embutido no GLPI:')) ?></strong> <?= glpiacessivel_e(glpiacessivel_t('usa o plugin como apoio dentro do GLPI, inclusive com a entrada acessível, mas oferece menor controle de acessibilidade de ponta a ponta.')) ?></p>
        <p><strong><?= glpiacessivel_e(glpiacessivel_t('Híbrido:')) ?></strong> <?= glpiacessivel_e(glpiacessivel_t('É o modo recomendado para produção: combina o portal acessível com a continuidade operacional no GLPI.')) ?></p>
      </div>
    </div>

    <label for="authentication_entry_mode"><?= glpiacessivel_e(glpiacessivel_t('Entrada antes da autenticação')) ?></label>
    <select
      id="authentication_entry_mode"
      name="authentication_entry_mode"
      aria-describedby="authentication-entry-mode-help"
    >
      <?php
        $authenticationEntryLabels = [
          'native_only' => glpiacessivel_t('Usar somente o login unificado do GLPI (recomendado)'),
          'accessible_bridge' => glpiacessivel_t('Permitir formulário acessível alternativo (compatibilidade)'),
        ];
        ?>
      <?php foreach (($authentication_entry_supported_modes ?? ['native_only', 'accessible_bridge']) as $entryMode) :
            ?>
        <option
          value="<?= glpiacessivel_e((string) $entryMode) ?>"
            <?= (($authentication_entry_mode ?? 'native_only') === $entryMode) ? 'selected' : '' ?>
        >
            <?= glpiacessivel_e((string) ($authenticationEntryLabels[$entryMode] ?? $entryMode)) ?>
        </option>
            <?php
      endforeach; ?>
    </select>
    <div id="authentication-entry-mode-help" class="glpiacessivel-help-text" style="grid-column: 1 / -1;">
      <p><?= glpiacessivel_e(glpiacessivel_t('Somente login unificado: o plugin não exibe campos de senha e encaminha acessos anônimos ao login oficial do GLPI, preservando SSO e MFA.')) ?></p>
      <p><?= glpiacessivel_e(glpiacessivel_t('Formulário alternativo: mantém a entrada acessível anterior somente para compatibilidade e retorno à configuração anterior.')) ?></p>
    </div>

    <label for="show_login_accessibility_notice"><?= glpiacessivel_e(glpiacessivel_t('Aviso de acessibilidade na tela de login')) ?></label>
    <select
      id="show_login_accessibility_notice"
      name="show_login_accessibility_notice"
      aria-describedby="login-accessibility-notice-help"
    >
      <option value="0" <?= ($show_login_accessibility_notice ?? '0') === '0' ? 'selected' : '' ?>>
        <?= glpiacessivel_e(glpiacessivel_t('Não exibir (padrão seguro)')) ?>
      </option>
      <option value="1" <?= ($show_login_accessibility_notice ?? '0') === '1' ? 'selected' : '' ?>>
        <?= glpiacessivel_e(glpiacessivel_t('Exibir aviso informativo')) ?>
      </option>
    </select>
    <div id="login-accessibility-notice-help" class="glpiacessivel-help-text" style="grid-column: 1 / -1;">
      <p><?= glpiacessivel_e(glpiacessivel_t('No modo de login unificado, mostra uma nota estática na tela de login: Portal Acessível disponível após o login.')) ?></p>
      <p><?= glpiacessivel_e(glpiacessivel_t('O aviso não é um link, não recebe credenciais e não cria uma rota alternativa. No modo de compatibilidade, a entrada acessível substitui o aviso para evitar duplicidade.')) ?></p>
    </div>

    <label for="plugin_fallback_locale"><?= glpiacessivel_e(glpiacessivel_t('Idioma alternativo do plugin')) ?></label>
    <select id="plugin_fallback_locale" name="plugin_fallback_locale" aria-describedby="plugin-fallback-locale-help">
      <?php foreach (($supported_locales ?? ['pt_BR']) as $locale) : ?>
        <option value="<?= glpiacessivel_e((string) $locale) ?>" <?= (($plugin_fallback_locale ?? 'pt_BR') === $locale) ? 'selected' : '' ?>>
            <?= glpiacessivel_e((string) $locale) ?>
        </option>
      <?php endforeach; ?>
    </select>
    <p id="plugin-fallback-locale-help" class="glpiacessivel-help-text"><?= glpiacessivel_e(glpiacessivel_t('O idioma principal continua herdado do GLPI. O idioma alternativo é usado apenas quando uma tradução do plugin estiver ausente.')) ?></p>
    <label for="vlibras_scope"><?= glpiacessivel_e(glpiacessivel_t('VLibras')) ?></label>
    <select id="vlibras_scope" name="vlibras_scope" aria-describedby="vlibras-scope-help">
      <?php
        $vlibrasLabels = [
          'disabled' => glpiacessivel_t('Desativado'),
          'public_only' => glpiacessivel_t('Somente páginas públicas'),
          'plugin_pages' => glpiacessivel_t('Páginas do plugin'),
          'all_pages' => glpiacessivel_t('Todas as páginas que carregam o plugin'),
        ];
        ?>
      <?php foreach (($vlibras_scopes ?? ['plugin_pages']) as $scope) : ?>
        <option value="<?= glpiacessivel_e((string) $scope) ?>" <?= (($vlibras_scope ?? 'plugin_pages') === $scope) ? 'selected' : '' ?>>
            <?= glpiacessivel_e((string) ($vlibrasLabels[$scope] ?? $scope)) ?>
        </option>
      <?php endforeach; ?>
    </select>
    <p id="vlibras-scope-help" class="glpiacessivel-help-text"><?= glpiacessivel_e(glpiacessivel_t('VLibras é uma integração externa opcional. Pode exigir a autorização do domínio vlibras.gov.br na política de segurança e não substitui WCAG, eMAG, teclado, foco, contraste e semântica.')) ?></p>
    <fieldset class="glpiacessivel-form-fieldset" style="grid-column: 1 / -1;">
      <legend><?= glpiacessivel_e(glpiacessivel_t('Proteção de dados pessoais')) ?></legend>
      <label for="pii_masking_enabled"><?= glpiacessivel_e(glpiacessivel_t('Mascarar contatos pessoais')) ?></label>
      <select id="pii_masking_enabled" name="pii_masking_enabled" aria-describedby="pii-masking-help">
        <option value="0" <?= ($pii_masking_enabled ?? '0') === '0' ? 'selected' : '' ?>><?= glpiacessivel_e(glpiacessivel_t('Desativado')) ?></option>
        <option value="1" <?= ($pii_masking_enabled ?? '0') === '1' ? 'selected' : '' ?>><?= glpiacessivel_e(glpiacessivel_t('Habilitado')) ?></option>
      </select>
      <p id="pii-masking-help" class="glpiacessivel-help-text"><?= glpiacessivel_e(glpiacessivel_t('Quando ativado, o e-mail e os telefones do requisitante ficam mascarados. A exibição temporária exige permissão, justificativa e auditoria. Quando desativado, o plugin não cria registros de revelação de dados pessoais.')) ?></p>
    </fieldset>
    <label for="forms_native_flow_mode"><?= glpiacessivel_e(glpiacessivel_t('Modo de abertura dos formulários')) ?></label>
    <select id="forms_native_flow_mode" name="forms_native_flow_mode" aria-describedby="forms-native-flow-help">
      <?php
        $formsNativeFlowLabels = [
          'native_embedded' => glpiacessivel_t('Incorporar formulário nativo no portal'),
          'native_embedded_minimal' => glpiacessivel_t('Incorporar formulário com interface GLPI reduzida'),
          'native_link' => glpiacessivel_t('Abrir no GLPI/Formcreator nativo'),
          'plugin_converted_with_native_callback' => glpiacessivel_t('Usar formulário acessível convertido quando seguro'),
        ];
        ?>
      <?php foreach (($forms_native_flow_modes ?? ['native_embedded', 'native_embedded_minimal', 'native_link', 'plugin_converted_with_native_callback']) as $mode) :
            ?>
        <option value="<?= glpiacessivel_e((string) $mode) ?>" <?= (($forms_native_flow_mode ?? 'native_embedded') === $mode) ? 'selected' : '' ?>>
            <?= glpiacessivel_e((string) ($formsNativeFlowLabels[$mode] ?? $mode)) ?>
        </option>
      <?php endforeach; ?>
    </select>
    <div id="forms-native-flow-help" class="glpiacessivel-help-text">
      <p><?= glpiacessivel_e(glpiacessivel_t('Incorporar formulário nativo: exibe o formulário oficial dentro do portal, quando permitido.')) ?></p>
      <p><?= glpiacessivel_e(glpiacessivel_t('Interface GLPI reduzida: tenta ocultar apenas a navegação nativa reconhecida. Se a compatibilidade visual não for confirmada, preserva a página completa.')) ?></p>
      <p><?= glpiacessivel_e(glpiacessivel_t('Abrir no GLPI/Formcreator nativo: redireciona para a tela oficial completa.')) ?></p>
      <p><?= glpiacessivel_e(glpiacessivel_t('Usar formulário acessível convertido quando seguro: usa a apresentação do plugin somente quando a compatibilidade estiver validada. Caso contrário, retorna ao formulário nativo incorporado.')) ?></p>
    </div>

    <fieldset class="glpiacessivel-form-fieldset" style="grid-column: 1 / -1;">
      <legend><?= glpiacessivel_e(glpiacessivel_t('Liberação controlada de melhorias')) ?></legend>
      <p class="glpiacessivel-help-text">
        <?= glpiacessivel_e(glpiacessivel_t('Ative cada melhoria separadamente, primeiro em homologação. Desativar uma opção restaura o fluxo anterior sem reduzir as validações de permissão do GLPI.')) ?>
      </p>
      <div class="glpiacessivel-form-grid">
        <div class="glpiacessivel-field">
          <label for="formcreator_minimal_embed_enabled"><?= glpiacessivel_e(glpiacessivel_t('Apresentação mínima do Formcreator')) ?></label>
          <select id="formcreator_minimal_embed_enabled" name="formcreator_minimal_embed_enabled" aria-describedby="formcreator-minimal-embed-help">
            <option value="0" <?= ($formcreator_minimal_embed_enabled ?? '0') === '0' ? 'selected' : '' ?>><?= glpiacessivel_e(glpiacessivel_t('Desativada')) ?></option>
            <option value="1" <?= ($formcreator_minimal_embed_enabled ?? '0') === '1' ? 'selected' : '' ?>><?= glpiacessivel_e(glpiacessivel_t('Ativada')) ?></option>
          </select>
          <p id="formcreator-minimal-embed-help" class="glpiacessivel-help-text"><?= glpiacessivel_e(glpiacessivel_t('Ativar esta opção também solicita a interface reduzida no modo incorporado padrão. Escolher Interface GLPI reduzida no modo de abertura já solicita o mesmo tratamento. Em ambos os casos, a página completa é preservada quando origem, rota, versão ou estrutura não forem confirmadas.')) ?></p>
        </div>
        <div class="glpiacessivel-field">
          <label for="native_form_accessibility_bridge_enabled"><?= glpiacessivel_e(glpiacessivel_t('Integração WCAG/eMAG no formulário incorporado')) ?></label>
          <select id="native_form_accessibility_bridge_enabled" name="native_form_accessibility_bridge_enabled" aria-describedby="native-form-accessibility-bridge-help">
            <option value="0" <?= ($native_form_accessibility_bridge_enabled ?? '0') === '0' ? 'selected' : '' ?>><?= glpiacessivel_e(glpiacessivel_t('Desativada')) ?></option>
            <option value="1" <?= ($native_form_accessibility_bridge_enabled ?? '0') === '1' ? 'selected' : '' ?>><?= glpiacessivel_e(glpiacessivel_t('Ativada')) ?></option>
          </select>
          <p id="native-form-accessibility-bridge-help" class="glpiacessivel-help-text"><?= glpiacessivel_e(glpiacessivel_t('Após validar origem, rota e identidade do formulário, sincroniza tema, contraste, escala de texto e foco visível. A integração não altera campos, respostas, permissões, token CSRF ou envio nativo.')) ?></p>
        </div>
        <div class="glpiacessivel-field">
          <label for="ticket_async_list_enabled"><?= glpiacessivel_e(glpiacessivel_t('Lista assíncrona de chamados')) ?></label>
          <select id="ticket_async_list_enabled" name="ticket_async_list_enabled" aria-describedby="ticket-async-list-help">
            <option value="0" <?= ($ticket_async_list_enabled ?? '0') === '0' ? 'selected' : '' ?>><?= glpiacessivel_e(glpiacessivel_t('Desativada')) ?></option>
            <option value="1" <?= ($ticket_async_list_enabled ?? '0') === '1' ? 'selected' : '' ?>><?= glpiacessivel_e(glpiacessivel_t('Ativada')) ?></option>
          </select>
          <p id="ticket-async-list-help" class="glpiacessivel-help-text"><?= glpiacessivel_e(glpiacessivel_t('Carrega primeiro a estrutura da página e depois os resultados, preservando a consulta e as permissões do GLPI.')) ?></p>
        </div>
        <div class="glpiacessivel-field">
          <label for="ticket_list_performance_limits_enabled"><?= glpiacessivel_e(glpiacessivel_t('Aplicar limites adicionais de desempenho à lista de chamados')) ?></label>
          <select id="ticket_list_performance_limits_enabled" name="ticket_list_performance_limits_enabled" aria-describedby="ticket-list-performance-help">
            <option value="1" <?= ($ticket_list_performance_limits_enabled ?? '1') === '1' ? 'selected' : '' ?>><?= glpiacessivel_e(glpiacessivel_t('Ativado')) ?></option>
            <option value="0" <?= ($ticket_list_performance_limits_enabled ?? '1') === '0' ? 'selected' : '' ?>><?= glpiacessivel_e(glpiacessivel_t('Desativado')) ?></option>
          </select>
          <p id="ticket-list-performance-help" class="glpiacessivel-help-text"><?= glpiacessivel_e(glpiacessivel_t('Quando desativado, não aplica os limites adicionais de tempo SQL, frequência por sessão ou capacidade simultânea da listagem. O navegador aguarda sem prazo adicional do plugin. Continuam valendo os limites do banco, PHP e servidor, as permissões do GLPI e a paginação. Consultas lentas podem ocupar recursos por mais tempo. Os valores abaixo ficam preservados para reativação.')) ?></p>
        </div>
        <div class="glpiacessivel-field">
          <label for="ticket_list_capacity_guard_enabled"><?= glpiacessivel_e(glpiacessivel_t('Proteção de capacidade da lista de chamados')) ?></label>
          <select id="ticket_list_capacity_guard_enabled" name="ticket_list_capacity_guard_enabled" aria-describedby="ticket-list-capacity-guard-help">
            <option value="1" <?= ($ticket_list_capacity_guard_enabled ?? '1') === '1' ? 'selected' : '' ?>><?= glpiacessivel_e(glpiacessivel_t('Ativada')) ?></option>
            <option value="0" <?= ($ticket_list_capacity_guard_enabled ?? '1') === '0' ? 'selected' : '' ?>><?= glpiacessivel_e(glpiacessivel_t('Desativada')) ?></option>
          </select>
          <p id="ticket-list-capacity-guard-help" class="glpiacessivel-help-text"><?= glpiacessivel_e(glpiacessivel_t('Limita consultas simultâneas antes de acessar a pesquisa nativa. Quando o backend configurado não está disponível, a proteção recusa a consulta de forma segura.')) ?></p>
        </div>
        <div class="glpiacessivel-field">
          <label for="ticket_list_capacity_backend"><?= glpiacessivel_e(glpiacessivel_t('Backend da proteção de capacidade')) ?></label>
          <select id="ticket_list_capacity_backend" name="ticket_list_capacity_backend" aria-describedby="ticket-list-capacity-backend-help">
            <?php foreach (($ticket_list_capacity_backends ?? ['apcu', 'external']) as $capacityBackend) : ?>
              <option value="<?= glpiacessivel_e((string) $capacityBackend) ?>" <?= ($ticket_list_capacity_backend ?? 'apcu') === $capacityBackend ? 'selected' : '' ?>>
                <?= glpiacessivel_e($capacityBackend === 'apcu' ? glpiacessivel_t('Local ao servidor (APCu ou lock de arquivo)') : glpiacessivel_t('Externo configurado pela implantação')) ?>
              </option>
            <?php endforeach; ?>
          </select>
          <p id="ticket-list-capacity-backend-help" class="glpiacessivel-help-text"><?= glpiacessivel_e(glpiacessivel_t('APCu coordena os processos do mesmo servidor; quando indisponível, locks de arquivo locais mantêm o limite sem usar o banco de dados. O backend externo exige um adaptador fornecido pela implantação; sem ele, as consultas são recusadas.')) ?></p>
        </div>
        <?php
          $ticketListStatementTimeoutMs = (int) ($ticket_list_statement_timeout_ms ?? 3000);
          $ticketListPerformanceLimitsEnabled = ($ticket_list_performance_limits_enabled ?? '1') !== '0';
          $ticketListTimeoutExceptional = $ticketListPerformanceLimitsEnabled && $ticketListStatementTimeoutMs > 5000;
          $ticketListRequestTimeoutMs = (int) ($ticket_list_request_timeout_ms ?? ($ticketListStatementTimeoutMs + 4000));
          $ticketListEffectiveLeaseSeconds = (int) ($ticket_list_effective_capacity_lease_seconds ?? 9);
        ?>
        <div
          class="glpiacessivel-field"
          data-glpiacessivel-ticket-timeout-config
          data-disabled-template="<?= glpiacessivel_e(glpiacessivel_t('Limites adicionais desativados. O tempo configurado está preservado, mas não será aplicado. Permanecem os limites do ambiente.')) ?>"
          data-normal-template="<?= glpiacessivel_e(glpiacessivel_t('Prazo do navegador: {request} ms. Reserva mínima efetiva: {lease} segundos.')) ?>"
          data-exceptional-template="<?= glpiacessivel_e(glpiacessivel_t('Uso excepcional e temporário. Prazo do navegador: {request} ms; reserva mínima efetiva: {lease} segundos. A lista assíncrona e a proteção de capacidade serão ativadas, com uma consulta pesada simultânea.')) ?>"
          data-invalid-message="<?= glpiacessivel_e(glpiacessivel_t('Informe um valor entre 1000 e 9000 milissegundos, em passos de 500.')) ?>"
        >
          <label for="ticket_list_statement_timeout_ms"><?= glpiacessivel_e(glpiacessivel_t('Tempo máximo da consulta SQL da lista de chamados (milissegundos)')) ?></label>
          <input
            id="ticket_list_statement_timeout_ms"
            name="ticket_list_statement_timeout_ms"
            type="number"
            min="1000"
            max="9000"
            step="500"
            value="<?= $ticketListStatementTimeoutMs ?>"
            required
            aria-describedby="ticket-list-timeout-help ticket-list-timeout-summary ticket-list-timeout-warning"
            data-glpiacessivel-ticket-timeout-input
          />
          <p id="ticket-list-timeout-help" class="glpiacessivel-help-text"><?= glpiacessivel_e(glpiacessivel_t('Limita somente a pesquisa da lista e não altera o banco globalmente. Padrão recomendado: 3000 ms. Valores maiores não corrigem consultas lentas.')) ?></p>
          <p
            id="ticket-list-timeout-summary"
            class="glpiacessivel-help-text"
            role="status"
            aria-live="polite"
            aria-atomic="true"
            data-glpiacessivel-ticket-timeout-summary
          ><?= glpiacessivel_e(!$ticketListPerformanceLimitsEnabled
            ? glpiacessivel_t('Limites adicionais desativados. O tempo configurado está preservado, mas não será aplicado. Permanecem os limites do ambiente.')
            : sprintf(
              $ticketListTimeoutExceptional
                ? glpiacessivel_t('Uso excepcional e temporário. Prazo do navegador: %1$d ms; reserva mínima efetiva: %2$d segundos. A lista assíncrona e a proteção de capacidade serão ativadas, com uma consulta pesada simultânea.')
                : glpiacessivel_t('Prazo do navegador: %1$d ms. Reserva mínima efetiva: %2$d segundos.'),
              $ticketListRequestTimeoutMs,
              $ticketListEffectiveLeaseSeconds
          )) ?></p>
          <p
            id="ticket-list-timeout-warning"
            class="glpiacessivel-alert glpiacessivel-alert-warning"
            data-glpiacessivel-ticket-timeout-warning
            <?= $ticketListTimeoutExceptional ? '' : 'hidden' ?>
          ><?= glpiacessivel_e(glpiacessivel_t('Consultas acima de 5000 ms aumentam a ocupação do banco e dos processos PHP. Confirme que PHP-FPM, proxy e balanceador possuem timeout mínimo de 20 segundos.')) ?></p>
          <div data-glpiacessivel-ticket-timeout-confirm <?= $ticketListTimeoutExceptional ? '' : 'hidden' ?>>
            <input
              id="ticket_list_timeout_risk_confirm"
              name="ticket_list_timeout_risk_confirm"
              type="checkbox"
              value="1"
              <?= $ticketListTimeoutExceptional ? 'required' : '' ?>
              aria-describedby="ticket-list-timeout-warning"
            />
            <label for="ticket_list_timeout_risk_confirm"><?= glpiacessivel_e(glpiacessivel_t('Confirmo que a infraestrutura suporta o prazo mínimo indicado e que a consulta será testada sob carga.')) ?></label>
          </div>
          <button type="button" class="glpiacessivel-button glpiacessivel-button-secondary" data-glpiacessivel-ticket-timeout-reset><?= glpiacessivel_e(glpiacessivel_t('Restaurar o padrão de 3000 ms')) ?></button>
        </div>
        <div class="glpiacessivel-field">
          <label for="ticket_list_capacity_max_concurrent"><?= glpiacessivel_e(glpiacessivel_t('Consultas simultâneas por servidor')) ?></label>
          <input id="ticket_list_capacity_max_concurrent" name="ticket_list_capacity_max_concurrent" type="number" min="1" max="10" value="<?= (int) ($ticket_list_capacity_max_concurrent ?? 2) ?>" required />
        </div>
        <div class="glpiacessivel-field">
          <label for="ticket_list_capacity_lease_seconds"><?= glpiacessivel_e(glpiacessivel_t('Validade da reserva de capacidade (segundos)')) ?></label>
          <input id="ticket_list_capacity_lease_seconds" name="ticket_list_capacity_lease_seconds" type="number" min="8" max="30" value="<?= (int) ($ticket_list_capacity_lease_seconds ?? 8) ?>" required />
        </div>
        <div class="glpiacessivel-field">
          <label for="ticket_list_capacity_retry_after_seconds"><?= glpiacessivel_e(glpiacessivel_t('Espera sugerida após recusa (segundos)')) ?></label>
          <input id="ticket_list_capacity_retry_after_seconds" name="ticket_list_capacity_retry_after_seconds" type="number" min="1" max="60" value="<?= (int) ($ticket_list_capacity_retry_after_seconds ?? 5) ?>" required />
        </div>
        <div class="glpiacessivel-field">
          <label for="ticket_list_rate_limit"><?= glpiacessivel_e(glpiacessivel_t('Ritmo de consultas por sessão')) ?></label>
          <input id="ticket_list_rate_limit" name="ticket_list_rate_limit" type="number" min="1" max="30" value="<?= (int) ($ticket_list_rate_limit ?? 30) ?>" required aria-describedby="ticket-list-rate-help" />
          <p id="ticket-list-rate-help" class="glpiacessivel-help-text"><?= glpiacessivel_e(glpiacessivel_t('Quantidade de consultas repostas gradualmente durante a janela configurada.')) ?></p>
        </div>
        <div class="glpiacessivel-field">
          <label for="ticket_list_rate_window_seconds"><?= glpiacessivel_e(glpiacessivel_t('Janela de reposição do limite (segundos)')) ?></label>
          <input id="ticket_list_rate_window_seconds" name="ticket_list_rate_window_seconds" type="number" min="10" max="300" value="<?= (int) ($ticket_list_rate_window_seconds ?? 60) ?>" required />
        </div>
        <div class="glpiacessivel-field">
          <label for="ticket_list_rate_burst"><?= glpiacessivel_e(glpiacessivel_t('Rajada inicial permitida')) ?></label>
          <input id="ticket_list_rate_burst" name="ticket_list_rate_burst" type="number" min="1" max="5" value="<?= (int) ($ticket_list_rate_burst ?? 5) ?>" required />
        </div>
        <div class="glpiacessivel-field">
          <label for="resource_selector_enabled"><?= glpiacessivel_e(glpiacessivel_t('Seletores com preenchimento automático paginado')) ?></label>
          <select id="resource_selector_enabled" name="resource_selector_enabled" aria-describedby="resource-selector-help">
            <option value="0" <?= ($resource_selector_enabled ?? '0') === '0' ? 'selected' : '' ?>><?= glpiacessivel_e(glpiacessivel_t('Desativados')) ?></option>
            <option value="1" <?= ($resource_selector_enabled ?? '0') === '1' ? 'selected' : '' ?>><?= glpiacessivel_e(glpiacessivel_t('Ativados')) ?></option>
          </select>
          <p id="resource-selector-help" class="glpiacessivel-help-text"><?= glpiacessivel_e(glpiacessivel_t('Controle principal. Habilite também, abaixo, somente os fluxos já homologados.')) ?></p>
        </div>
        <div class="glpiacessivel-field">
          <label for="resource_selector_create_enabled"><?= glpiacessivel_e(glpiacessivel_t('Preenchimento automático na abertura de chamados')) ?></label>
          <select id="resource_selector_create_enabled" name="resource_selector_create_enabled" aria-describedby="resource-selector-create-help">
            <option value="0" <?= ($resource_selector_create_enabled ?? '0') === '0' ? 'selected' : '' ?>><?= glpiacessivel_e(glpiacessivel_t('Desativado')) ?></option>
            <option value="1" <?= ($resource_selector_create_enabled ?? '0') === '1' ? 'selected' : '' ?>><?= glpiacessivel_e(glpiacessivel_t('Ativado')) ?></option>
          </select>
          <p id="resource-selector-create-help" class="glpiacessivel-help-text"><?= glpiacessivel_e(glpiacessivel_t('Pesquisa categorias, locais, técnicos, grupos e observadores durante a abertura.')) ?></p>
        </div>
        <div class="glpiacessivel-field">
          <label for="resource_selector_routing_enabled"><?= glpiacessivel_e(glpiacessivel_t('Preenchimento automático no encaminhamento de chamados')) ?></label>
          <select id="resource_selector_routing_enabled" name="resource_selector_routing_enabled" aria-describedby="resource-selector-routing-help">
            <option value="0" <?= ($resource_selector_routing_enabled ?? '0') === '0' ? 'selected' : '' ?>><?= glpiacessivel_e(glpiacessivel_t('Desativado')) ?></option>
            <option value="1" <?= ($resource_selector_routing_enabled ?? '0') === '1' ? 'selected' : '' ?>><?= glpiacessivel_e(glpiacessivel_t('Ativado')) ?></option>
          </select>
          <p id="resource-selector-routing-help" class="glpiacessivel-help-text"><?= glpiacessivel_e(glpiacessivel_t('Pesquisa técnicos, grupos e observadores no chamado, conforme as permissões e a entidade do chamado.')) ?></p>
        </div>
        <div class="glpiacessivel-field">
          <label for="form_catalog_v2_enabled"><?= glpiacessivel_e(glpiacessivel_t('Catálogo ampliado de formulários')) ?></label>
          <select id="form_catalog_v2_enabled" name="form_catalog_v2_enabled" aria-describedby="form-catalog-v2-help">
            <option value="0" <?= ($form_catalog_v2_enabled ?? '0') === '0' ? 'selected' : '' ?>><?= glpiacessivel_e(glpiacessivel_t('Desativado')) ?></option>
            <option value="1" <?= ($form_catalog_v2_enabled ?? '0') === '1' ? 'selected' : '' ?>><?= glpiacessivel_e(glpiacessivel_t('Ativado')) ?></option>
          </select>
          <p id="form-catalog-v2-help" class="glpiacessivel-help-text"><?= glpiacessivel_e(glpiacessivel_t('Usa a descoberta compatível com GLPI 10/Formcreator e GLPI 11, mantendo o fluxo nativo quando a fonte não estiver homologada.')) ?></p>
        </div>
      </div>
    </fieldset>

    <label for="chatbot_display_name"><?= glpiacessivel_e(glpiacessivel_t('Nome exibido do chatbot')) ?></label>
    <div class="glpiacessivel-field">
      <input
        id="chatbot_display_name"
        type="text"
        name="chatbot_display_name"
        value="<?= glpiacessivel_e((string) ($chatbot_display_name ?? 'Assistente')) ?>"
        maxlength="60"
        required
        autocomplete="off"
        aria-describedby="chatbot-display-name-help"
      />
      <p id="chatbot-display-name-help" class="glpiacessivel-help-text"><?= glpiacessivel_e(glpiacessivel_t('Este nome aparece na interface, nas respostas, na voz e nos rótulos acessíveis. O valor padrão é Assistente.')) ?></p>
    </div>

    <label for="chatbot_floating_scope"><?= glpiacessivel_e(glpiacessivel_t('Onde mostrar o botão flutuante do chatbot')) ?></label>
    <select id="chatbot_floating_scope" name="chatbot_floating_scope">
      <option value="plugin_only" <?= ($chatbot_floating_scope ?? 'all_logged_pages') === 'plugin_only' ? 'selected' : '' ?>><?= glpiacessivel_e(glpiacessivel_t('Somente no portal e nas páginas do plugin')) ?></option>
      <option value="all_logged_pages" <?= ($chatbot_floating_scope ?? 'all_logged_pages') === 'all_logged_pages' ? 'selected' : '' ?>><?= glpiacessivel_e(glpiacessivel_t('Em todas as páginas para usuários autenticados')) ?></option>
      <option value="disabled" <?= ($chatbot_floating_scope ?? 'all_logged_pages') === 'disabled' ? 'selected' : '' ?>><?= glpiacessivel_e(glpiacessivel_t('Desativado')) ?></option>
    </select>

    <label for="chatbot_voice_enabled"><?= glpiacessivel_e(glpiacessivel_t('Chatbot por voz (pt-BR)')) ?></label>
    <select id="chatbot_voice_enabled" name="chatbot_voice_enabled">
      <option value="1" <?= ($chatbot_voice_enabled ?? '1') === '1' ? 'selected' : '' ?>><?= glpiacessivel_e(glpiacessivel_t('Sim')) ?></option>
      <option value="0" <?= ($chatbot_voice_enabled ?? '1') === '0' ? 'selected' : '' ?>><?= glpiacessivel_e(glpiacessivel_t('Não')) ?></option>
    </select>

    <div class="glpiacessivel-field" style="grid-column: 1 / -1;">
      <span id="chatbot-intents-label"><strong><?= glpiacessivel_e(glpiacessivel_t('Intenções liberadas para o chatbot')) ?></strong></span>
      <p class="glpiacessivel-help-text"><?= glpiacessivel_e(glpiacessivel_t('Desmarque as intenções que não devem ser executadas automaticamente neste ambiente.')) ?></p>
      <?php
        $rightUpdate = defined('UPDATE') ? (int) constant('UPDATE') : 2;
        $canManagePlaybooks = ($moduleEffectiveStates['playbooks'] ?? 'available') === 'available'
            && class_exists('Session')
            && \Session::haveRight('config', $rightUpdate);
        ?>
      <?php if ($canManagePlaybooks) : ?>
        <p class="glpiacessivel-help-text">
            <?= glpiacessivel_e(glpiacessivel_t('Os roteiros do chatbot ficam no painel administrativo do portal.')) ?>
          <a class="glpiacessivel-link" href="<?= glpiacessivel_e(glpiacessivel_url('front/playbooks.php')) ?>">
            <?= glpiacessivel_e(glpiacessivel_t('Abrir roteiros do chatbot')) ?>
          </a>
        </p>
      <?php endif; ?>
      <fieldset aria-labelledby="chatbot-intents-label" class="glpiacessivel-grid-2" style="border:1px solid #c8d3e3;border-radius:8px;padding:0.75rem;">
        <?php foreach (($chatbot_intents ?? []) as $intent) : ?>
            <?php
            $intentKey = (string) $intent;
            $intentId = 'intent_' . preg_replace('/[^a-z0-9_]/', '_', $intentKey);
            $isEnabled = in_array($intentKey, (array) ($chatbot_enabled_intents ?? []), true);
            $label = (string) (($chatbot_intent_labels[$intentKey] ?? $intentKey));
            $isMandatory = $intentKey === 'handoff_humano';
            ?>
          <label for="<?= glpiacessivel_e($intentId) ?>" style="font-weight:600;">
            <input
              id="<?= glpiacessivel_e($intentId) ?>"
              type="checkbox"
              name="chatbot_enabled_intents[]"
              value="<?= glpiacessivel_e($intentKey) ?>"
              <?= $isEnabled ? 'checked' : '' ?>
              <?= $isMandatory ? 'disabled' : '' ?>
            />
            <?= glpiacessivel_e($label) ?>
            <?php if ($isMandatory) :
                ?><small><?= glpiacessivel_e(glpiacessivel_t('(sempre ativo)')) ?></small><?php
            endif; ?>
          </label>
            <?php if ($isMandatory) : ?>
            <input type="hidden" name="chatbot_enabled_intents[]" value="<?= glpiacessivel_e($intentKey) ?>" />
            <?php endif; ?>
        <?php endforeach; ?>
      </fieldset>
    </div>

    <div class="glpiacessivel-field" style="grid-column: 1 / -1;">
      <span id="chatbot-voice-label"><strong><?= glpiacessivel_e(glpiacessivel_t('Recursos de voz no navegador')) ?></strong></span>
      <p class="glpiacessivel-help-text"><?= glpiacessivel_e(glpiacessivel_t('O plugin reconhece a voz pelo Vosklet ou pelo navegador e reproduz a resposta com o sintetizador do navegador. Piper WASM permanece disponível apenas para testes.')) ?></p>
      <fieldset aria-labelledby="chatbot-voice-label" class="glpiacessivel-form-fieldset">
        <div class="glpiacessivel-config-block">
          <h3><?= glpiacessivel_e(glpiacessivel_t('Comportamento geral')) ?></h3>
          <p class="glpiacessivel-help-text"><?= glpiacessivel_e(glpiacessivel_t('Use "Priorizar arquivos locais do servidor" em homologação e produção. Os caminhos locais são sempre relativos ao diretório do plugin.')) ?></p>
          <div class="glpiacessivel-form-grid">
            <div class="glpiacessivel-field">
              <label for="chatbot_voice_locale"><?= glpiacessivel_e(glpiacessivel_t('Localidade da voz')) ?></label>
              <input id="chatbot_voice_locale" type="text" name="chatbot_voice_locale" value="<?= glpiacessivel_e((string) ($chatbot_voice_locale ?? 'pt-BR')) ?>" placeholder="pt-BR" />
            </div>

            <div class="glpiacessivel-field">
              <label for="chatbot_voice_asset_mode"><?= glpiacessivel_e(glpiacessivel_t('Origem dos arquivos de voz')) ?></label>
              <select id="chatbot_voice_asset_mode" name="chatbot_voice_asset_mode">
                <option value="local_preferred" <?= (($chatbot_voice_asset_mode ?? 'local_preferred') === 'local_preferred') ? 'selected' : '' ?>><?= glpiacessivel_e(glpiacessivel_t('Priorizar arquivos locais do servidor')) ?></option>
                <option value="local_only" <?= (($chatbot_voice_asset_mode ?? 'local_preferred') === 'local_only') ? 'selected' : '' ?>><?= glpiacessivel_e(glpiacessivel_t('Somente arquivos locais')) ?></option>
                <option value="external_only" <?= (($chatbot_voice_asset_mode ?? 'local_preferred') === 'external_only') ? 'selected' : '' ?>><?= glpiacessivel_e(glpiacessivel_t('Somente endereços externos')) ?></option>
              </select>
            </div>

            <div class="glpiacessivel-field">
              <label for="chatbot_stt_engine"><?= glpiacessivel_e(glpiacessivel_t('Reconhecimento de fala (ouvir usuário)')) ?></label>
              <select id="chatbot_stt_engine" name="chatbot_stt_engine">
                <?php foreach (($chatbot_stt_engines ?? []) as $engine) : ?>
                  <option value="<?= glpiacessivel_e((string) $engine) ?>" <?= (($chatbot_stt_engine ?? 'vosklet') === $engine) ? 'selected' : '' ?>>
                    <?= glpiacessivel_e((string) $engine) ?>
                  </option>
                <?php endforeach; ?>
              </select>
            </div>

            <div class="glpiacessivel-field">
              <label for="chatbot_tts_engine"><?= glpiacessivel_e(glpiacessivel_t('Síntese de voz (falar resposta)')) ?></label>
              <select id="chatbot_tts_engine" name="chatbot_tts_engine">
                <?php
                  $ttsEngineLabels = [
                    'browser_native' => glpiacessivel_t('Nativo do navegador (recomendado)'),
                    'piper_wasm' => glpiacessivel_t('Piper WASM (experimental)'),
                    'none' => glpiacessivel_t('Desativado'),
                  ];
                    ?>
                <?php foreach (($chatbot_tts_engines ?? []) as $engine) : ?>
                  <option value="<?= glpiacessivel_e((string) $engine) ?>" <?= (($chatbot_tts_engine ?? 'browser_native') === $engine) ? 'selected' : '' ?>>
                    <?= glpiacessivel_e((string) ($ttsEngineLabels[$engine] ?? $engine)) ?>
                  </option>
                <?php endforeach; ?>
              </select>
            </div>
          </div>
        </div>

        <div class="glpiacessivel-config-block">
          <h3><?= glpiacessivel_e(glpiacessivel_t('Arquivos locais recomendados')) ?></h3>
          <p class="glpiacessivel-help-text"><?= glpiacessivel_e(glpiacessivel_t('Estes são os caminhos atuais do pacote 0.40 ou mais recente. Configurações com a extensão .mjs antiga ou com o prefixo plugins/glpiacessivel/ serão corrigidas automaticamente.')) ?></p>
          <div class="glpiacessivel-config-path-list" aria-label="<?= glpiacessivel_e(glpiacessivel_t('Caminhos locais recomendados')) ?>">
            <p><strong><?= glpiacessivel_e(glpiacessivel_t('Script de reconhecimento de fala:')) ?></strong> <code>public/assets/vendor/vosklet/Vosklet.js</code></p>
            <p><strong><?= glpiacessivel_e(glpiacessivel_t('Modelo de reconhecimento pt-BR:')) ?></strong> <code>public/assets/voice/vosk/pt-BR/vosk-model-small-pt-0.3.zip</code></p>
            <p><strong><?= glpiacessivel_e(glpiacessivel_t('Módulo de síntese de voz:')) ?></strong> <code>public/assets/vendor/piper/piper-tts-web.js</code></p>
            <p><strong><?= glpiacessivel_e(glpiacessivel_t('Biblioteca ONNX:')) ?></strong> <code>public/assets/vendor/onnxruntime-web/1.18.0/ort.esm.js</code></p>
            <p><strong><?= glpiacessivel_e(glpiacessivel_t('Arquivos WASM do ONNX:')) ?></strong> <code>public/assets/vendor/onnxruntime-web/1.18.0</code></p>
            <p><strong><?= glpiacessivel_e(glpiacessivel_t('Arquivo WASM do Piper:')) ?></strong> <code>public/assets/vendor/piper-wasm/1.0.0/piper_phonemize.wasm</code></p>
            <p><strong><?= glpiacessivel_e(glpiacessivel_t('Dados do Piper:')) ?></strong> <code>public/assets/vendor/piper-wasm/1.0.0/piper_phonemize.data</code></p>
            <p><strong><?= glpiacessivel_e(glpiacessivel_t('Voz pt-BR:')) ?></strong> <code>public/assets/voice/piper/pt-BR/faber-medium/pt_BR-faber-medium.onnx</code></p>
            <p><strong><?= glpiacessivel_e(glpiacessivel_t('Configuração da voz:')) ?></strong> <code>public/assets/voice/piper/pt-BR/faber-medium/pt_BR-faber-medium.onnx.json</code></p>
          </div>
          <div class="glpiacessivel-form-grid">
            <div class="glpiacessivel-field">
              <label for="chatbot_stt_script_local_path"><?= glpiacessivel_e(glpiacessivel_t('Caminho local do script de reconhecimento de fala')) ?></label>
              <input id="chatbot_stt_script_local_path" type="text" name="chatbot_stt_script_local_path" value="<?= glpiacessivel_e((string) ($chatbot_stt_script_local_path ?? '')) ?>" placeholder="public/assets/vendor/vosklet/Vosklet.js" />
            </div>

            <div class="glpiacessivel-field">
              <label for="chatbot_stt_model_local_path"><?= glpiacessivel_e(glpiacessivel_t('Caminho local do modelo de reconhecimento pt-BR')) ?></label>
              <input id="chatbot_stt_model_local_path" type="text" name="chatbot_stt_model_local_path" value="<?= glpiacessivel_e((string) ($chatbot_stt_model_local_path ?? '')) ?>" placeholder="public/assets/voice/vosk/pt-BR/vosk-model-small-pt-0.3.zip" />
            </div>

            <div class="glpiacessivel-field">
              <label for="chatbot_tts_script_local_path"><?= glpiacessivel_e(glpiacessivel_t('Caminho local do módulo de síntese de voz')) ?></label>
              <input id="chatbot_tts_script_local_path" type="text" name="chatbot_tts_script_local_path" value="<?= glpiacessivel_e((string) ($chatbot_tts_script_local_path ?? '')) ?>" placeholder="public/assets/vendor/piper/piper-tts-web.js" />
            </div>

            <div class="glpiacessivel-field">
              <label for="chatbot_tts_onnx_runtime_local_path"><?= glpiacessivel_e(glpiacessivel_t('Caminho local da biblioteca ONNX')) ?></label>
              <input id="chatbot_tts_onnx_runtime_local_path" type="text" name="chatbot_tts_onnx_runtime_local_path" value="<?= glpiacessivel_e((string) ($chatbot_tts_onnx_runtime_local_path ?? '')) ?>" placeholder="public/assets/vendor/onnxruntime-web/1.18.0/ort.esm.js" />
            </div>

            <div class="glpiacessivel-field">
              <label for="chatbot_tts_onnx_wasm_local_path"><?= glpiacessivel_e(glpiacessivel_t('Diretório local dos arquivos WASM do ONNX')) ?></label>
              <input id="chatbot_tts_onnx_wasm_local_path" type="text" name="chatbot_tts_onnx_wasm_local_path" value="<?= glpiacessivel_e((string) ($chatbot_tts_onnx_wasm_local_path ?? '')) ?>" placeholder="public/assets/vendor/onnxruntime-web/1.18.0" />
            </div>

            <div class="glpiacessivel-field">
              <label for="chatbot_tts_piper_wasm_local_path"><?= glpiacessivel_e(glpiacessivel_t('Caminho local do arquivo WASM do Piper')) ?></label>
              <input id="chatbot_tts_piper_wasm_local_path" type="text" name="chatbot_tts_piper_wasm_local_path" value="<?= glpiacessivel_e((string) ($chatbot_tts_piper_wasm_local_path ?? '')) ?>" placeholder="public/assets/vendor/piper-wasm/1.0.0/piper_phonemize.wasm" />
            </div>

            <div class="glpiacessivel-field">
              <label for="chatbot_tts_piper_data_local_path"><?= glpiacessivel_e(glpiacessivel_t('Caminho local dos dados do Piper')) ?></label>
              <input id="chatbot_tts_piper_data_local_path" type="text" name="chatbot_tts_piper_data_local_path" value="<?= glpiacessivel_e((string) ($chatbot_tts_piper_data_local_path ?? '')) ?>" placeholder="public/assets/vendor/piper-wasm/1.0.0/piper_phonemize.data" />
            </div>

            <div class="glpiacessivel-field">
              <label for="chatbot_tts_voice_model_local_path"><?= glpiacessivel_e(glpiacessivel_t('Caminho local do modelo de voz pt-BR')) ?></label>
              <input id="chatbot_tts_voice_model_local_path" type="text" name="chatbot_tts_voice_model_local_path" value="<?= glpiacessivel_e((string) ($chatbot_tts_voice_model_local_path ?? '')) ?>" placeholder="public/assets/voice/piper/pt-BR/faber-medium/pt_BR-faber-medium.onnx" />
            </div>

            <div class="glpiacessivel-field">
              <label for="chatbot_tts_voice_config_local_path"><?= glpiacessivel_e(glpiacessivel_t('Caminho local da configuração da voz pt-BR')) ?></label>
              <input id="chatbot_tts_voice_config_local_path" type="text" name="chatbot_tts_voice_config_local_path" value="<?= glpiacessivel_e((string) ($chatbot_tts_voice_config_local_path ?? '')) ?>" placeholder="public/assets/voice/piper/pt-BR/faber-medium/pt_BR-faber-medium.onnx.json" />
            </div>
          </div>
        </div>

        <div class="glpiacessivel-config-block">
          <h3><?= glpiacessivel_e(glpiacessivel_t('Alternativa externa')) ?></h3>
          <p class="glpiacessivel-help-text"><?= glpiacessivel_e(glpiacessivel_t('Preencha apenas se quiser usar endereços externos quando os arquivos locais não estiverem publicados no servidor.')) ?></p>
          <div class="glpiacessivel-form-grid">
            <div class="glpiacessivel-field">
              <label for="chatbot_stt_script_url"><?= glpiacessivel_e(glpiacessivel_t('Endereço do script de reconhecimento de fala (Vosklet)')) ?></label>
              <input id="chatbot_stt_script_url" type="text" name="chatbot_stt_script_url" value="<?= glpiacessivel_e((string) ($chatbot_stt_script_url ?? '')) ?>" />
            </div>

            <div class="glpiacessivel-field">
              <label for="chatbot_stt_model_url"><?= glpiacessivel_e(glpiacessivel_t('Endereço do modelo de reconhecimento pt-BR (Vosklet)')) ?></label>
              <input id="chatbot_stt_model_url" type="text" name="chatbot_stt_model_url" value="<?= glpiacessivel_e((string) ($chatbot_stt_model_url ?? '')) ?>" placeholder="https://.../vosk-model-small-pt-0.3.zip" />
            </div>

            <div class="glpiacessivel-field">
              <label for="chatbot_tts_script_url"><?= glpiacessivel_e(glpiacessivel_t('Endereço do módulo de síntese de voz (Piper WASM)')) ?></label>
              <input id="chatbot_tts_script_url" type="text" name="chatbot_tts_script_url" value="<?= glpiacessivel_e((string) ($chatbot_tts_script_url ?? '')) ?>" />
            </div>
          </div>
        </div>

        <div class="glpiacessivel-config-block">
          <h3><?= glpiacessivel_e(glpiacessivel_t('Identificação do modelo e da voz')) ?></h3>
          <div class="glpiacessivel-form-grid">
            <div class="glpiacessivel-field">
              <label for="chatbot_stt_model_label"><?= glpiacessivel_e(glpiacessivel_t('Descrição do modelo de reconhecimento de fala')) ?></label>
              <input id="chatbot_stt_model_label" type="text" name="chatbot_stt_model_label" value="<?= glpiacessivel_e((string) ($chatbot_stt_model_label ?? glpiacessivel_t('Português (Brasil)'))) ?>" />
            </div>

            <div class="glpiacessivel-field">
              <label for="chatbot_stt_model_cache_id"><?= glpiacessivel_e(glpiacessivel_t('Identificador do cache do modelo de reconhecimento')) ?></label>
              <input id="chatbot_stt_model_cache_id" type="text" name="chatbot_stt_model_cache_id" value="<?= glpiacessivel_e((string) ($chatbot_stt_model_cache_id ?? 'glpi-vosk-ptbr')) ?>" />
            </div>

            <div class="glpiacessivel-field">
              <label for="chatbot_tts_voice_id"><?= glpiacessivel_e(glpiacessivel_t('Identificador da voz (Piper)')) ?></label>
              <input id="chatbot_tts_voice_id" type="text" name="chatbot_tts_voice_id" value="<?= glpiacessivel_e((string) ($chatbot_tts_voice_id ?? 'pt_BR-faber-medium')) ?>" />
            </div>
          </div>
        </div>
      </fieldset>
    </div>

    <fieldset class="glpiacessivel-form-fieldset" style="grid-column: 1 / -1;">
      <legend><?= glpiacessivel_e(glpiacessivel_t('Auditoria persistente')) ?></legend>
      <p id="audit-mode-help" class="glpiacessivel-help-text"><?= glpiacessivel_e(glpiacessivel_t('A auditoria é independente do mascaramento. O modo essencial é recomendado para produção porque preserva alterações e segurança sem registrar leituras rotineiras.')) ?></p>
      <?php
        $auditModeLabels = [
          'full' => glpiacessivel_t('Completa'),
          'critical' => glpiacessivel_t('Essencial'),
          'disabled' => glpiacessivel_t('Desativada'),
        ];
        $auditModeDescriptions = [
          'full' => glpiacessivel_t('Registra eventos críticos e operações rotineiras. Produz maior volume.'),
          'critical' => glpiacessivel_t('Registra alterações, segurança, configuração e revelações autorizadas. Recomendado para produção.'),
          'disabled' => glpiacessivel_t('Não cria novos eventos. A revelação de dados protegidos fica indisponível e a retenção histórica continua.'),
        ];
        ?>
      <?php foreach (($audit_modes ?? ['full', 'critical', 'disabled']) as $mode): ?>
        <?php $modeId = 'audit-mode-' . $mode; ?>
        <div class="glpiacessivel-checkbox-row">
          <input
            id="<?= glpiacessivel_e($modeId) ?>"
            type="radio"
            name="audit_mode"
            value="<?= glpiacessivel_e($mode) ?>"
            <?= (($audit_mode ?? 'critical') === $mode) ? 'checked' : '' ?>
            <?= ($mode === 'disabled' && empty($audit_disabled_allowed)) ? 'disabled' : '' ?>
            aria-describedby="<?= glpiacessivel_e($modeId) ?>-help"
          />
          <label for="<?= glpiacessivel_e($modeId) ?>"><?= glpiacessivel_e($auditModeLabels[$mode] ?? $mode) ?></label>
          <span id="<?= glpiacessivel_e($modeId) ?>-help" class="glpiacessivel-help-text"><?= glpiacessivel_e($auditModeDescriptions[$mode] ?? '') ?></span>
        </div>
      <?php endforeach; ?>
      <?php if (!empty($audit_disabled_allowed)): ?>
        <div class="glpiacessivel-checkbox-row">
          <input id="audit-disabled-confirm" type="checkbox" name="audit_disabled_confirm" value="1" />
          <label for="audit-disabled-confirm"><?= glpiacessivel_e(glpiacessivel_t('Confirmo que, no modo desativado, nenhuma revelação de dado pessoal protegido será permitida.')) ?></label>
        </div>
      <?php else: ?>
        <p class="glpiacessivel-help-text"><?= glpiacessivel_e(glpiacessivel_t('O modo desativado exige habilitação local explícita e não está disponível nesta instalação.')) ?></p>
      <?php endif; ?>
      <p class="glpiacessivel-help-text"><?= glpiacessivel_e(glpiacessivel_t('Alterar o modo afeta somente novos eventos. Registros existentes permanecem até o término da retenção ou preservação legal.')) ?></p>
      <?php if (!empty($can_read_audit)): ?>
        <p><a href="<?= glpiacessivel_e(glpiacessivel_url('front/audit.php')) ?>"><?= glpiacessivel_e(glpiacessivel_t('Abrir trilha de auditoria operacional')) ?></a></p>
      <?php else: ?>
        <p class="glpiacessivel-help-text"><?= glpiacessivel_e(glpiacessivel_t('O perfil atual pode configurar o plugin, mas não recebeu o direito separado de consultar a trilha.')) ?></p>
      <?php endif; ?>
    </fieldset>

    <label for="audit_retention_days"><?= glpiacessivel_e(glpiacessivel_t('Retenção de auditoria (dias)')) ?></label>
    <input
      id="audit_retention_days"
      name="audit_retention_days"
      type="number"
      min="30"
      max="3650"
      value="<?= (int) ($audit_retention_days ?? 365) ?>"
      required
    />

    <label for="audit_retention_batch_size"><?= glpiacessivel_e(glpiacessivel_t('Registros removidos por lote de retenção')) ?></label>
    <input
      id="audit_retention_batch_size"
      name="audit_retention_batch_size"
      type="number"
      min="100"
      max="5000"
      value="<?= (int) ($audit_retention_batch_size ?? 500) ?>"
      aria-describedby="audit-retention-batch-help"
      required
    />
    <p id="audit-retention-batch-help" class="glpiacessivel-help-text"><?= glpiacessivel_e(glpiacessivel_t('A ação automática remove no máximo este volume por tabela e execução, evitando uma exclusão ampla durante requisições de usuários.')) ?></p>

    <button type="submit"><?= glpiacessivel_e(glpiacessivel_t('Salvar')) ?></button>
  </form>
</section>

<section class="glpiacessivel-card" aria-labelledby="config-diagnostics-title">
  <h2 id="config-diagnostics-title"><?= glpiacessivel_e(glpiacessivel_t('Diagnóstico operacional')) ?></h2>
  <p class="glpiacessivel-help-text"><?= glpiacessivel_e(glpiacessivel_t('Informações somente para consulta durante homologação, suporte e auditoria. Elas não substituem os testes reais no GLPI 10 e 11.')) ?></p>
  <?php $i18nDiagnostics = is_array($i18n_diagnostics ?? null) ? $i18n_diagnostics : []; ?>
  <h3><?= glpiacessivel_e(glpiacessivel_t('Idioma e internacionalização')) ?></h3>
  <dl class="glpiacessivel-definition-list">
    <dt><?= glpiacessivel_e(glpiacessivel_t('Política de idioma')) ?></dt>
    <dd><?= glpiacessivel_e(glpiacessivel_t('Herdar do GLPI')) ?></dd>
    <dt><?= glpiacessivel_e(glpiacessivel_t('Localidade do GLPI e da sessão')) ?></dt>
    <dd><?= glpiacessivel_e((string) ($i18nDiagnostics['glpi_session_locale'] ?? '')) ?: glpiacessivel_e(glpiacessivel_t('Não informado')) ?></dd>
    <dt><?= glpiacessivel_e(glpiacessivel_t('Localidade efetiva do plugin')) ?></dt>
    <dd><?= glpiacessivel_e((string) ($i18nDiagnostics['effective_locale'] ?? '')) ?></dd>
    <dt><?= glpiacessivel_e(glpiacessivel_t('Idioma declarado no HTML')) ?></dt>
    <dd><?= glpiacessivel_e((string) ($i18nDiagnostics['html_lang'] ?? '')) ?></dd>
    <dt><?= glpiacessivel_e(glpiacessivel_t('Idioma alternativo configurado')) ?></dt>
    <dd><?= glpiacessivel_e((string) ($i18nDiagnostics['fallback_locale'] ?? '')) ?></dd>
    <dt><?= glpiacessivel_e(glpiacessivel_t('Domínio de tradução')) ?></dt>
    <dd><code><?= glpiacessivel_e((string) ($i18nDiagnostics['domain'] ?? 'glpiacessivel')) ?></code></dd>
    <dt><?= glpiacessivel_e(glpiacessivel_t('Mensagens de JavaScript')) ?></dt>
    <dd><?= (int) ($i18nDiagnostics['javascript_catalog_messages'] ?? 0) ?></dd>
  </dl>

  <?php $catalogStatus = is_array($i18nDiagnostics['catalog_status'] ?? null) ? $i18nDiagnostics['catalog_status'] : []; ?>
  <div class="glpiacessivel-table-wrapper">
    <table class="glpiacessivel-table">
      <caption><?= glpiacessivel_e(glpiacessivel_t('Estado dos catálogos de tradução')) ?></caption>
      <thead>
        <tr>
          <th scope="col"><?= glpiacessivel_e(glpiacessivel_t('Localidade')) ?></th>
          <th scope="col"><?= glpiacessivel_e(glpiacessivel_t('PO')) ?></th>
          <th scope="col"><?= glpiacessivel_e(glpiacessivel_t('MO')) ?></th>
        </tr>
      </thead>
      <tbody>
        <?php foreach ($catalogStatus as $locale => $status) : ?>
          <tr>
            <th scope="row"><?= glpiacessivel_e((string) $locale) ?></th>
            <td><?= glpiacessivel_e(!empty($status['po']) ? glpiacessivel_t('Encontrado') : glpiacessivel_t('Ausente')) ?></td>
            <td><?= glpiacessivel_e(!empty($status['mo']) ? glpiacessivel_t('Encontrado') : glpiacessivel_t('Ausente')) ?></td>
          </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>

  <?php $operationalDiagnostics = is_array($operational_diagnostics ?? null) ? $operational_diagnostics : []; ?>
  <?php
    $diagnosticAccessibilityModeLabels = [
      'portal' => glpiacessivel_t('Portal acessível'),
      'embedded' => glpiacessivel_t('Embutido no GLPI'),
      'hybrid' => glpiacessivel_t('Híbrido'),
    ];
    $diagnosticAuthenticationModeLabels = [
      'native_only' => glpiacessivel_t('Somente login unificado do GLPI'),
      'accessible_bridge' => glpiacessivel_t('Formulário acessível alternativo'),
    ];
    $diagnosticVoiceModeLabels = [
      'local_preferred' => glpiacessivel_t('Priorizar arquivos locais do servidor'),
      'local_only' => glpiacessivel_t('Somente arquivos locais'),
      'external_only' => glpiacessivel_t('Somente endereços externos'),
    ];
    ?>
  <h3><?= glpiacessivel_e(glpiacessivel_t('Ambiente de execução')) ?></h3>
  <?php
    $runtimeUpdate = is_array($operationalDiagnostics['runtime_update'] ?? null)
      ? $operationalDiagnostics['runtime_update']
      : [];
    $runtimeStateLabels = [
      'current' => glpiacessivel_t('Código carregado e pacote em disco estão sincronizados'),
      'package_update_pending' => glpiacessivel_t('Há um pacote mais novo em disco aguardando recarga segura'),
      'package_rollback_pending' => glpiacessivel_t('O pacote em disco é anterior ao código carregado'),
      'runtime_stale' => glpiacessivel_t('Atualização detectada; os hooks foram suspensos nesta requisição'),
      'loaded_version_unknown' => glpiacessivel_t('Pacote válido; versão carregada ainda não identificada'),
      'marker_missing_or_invalid' => glpiacessivel_t('Marcador VERSION ausente ou inválido'),
    ];
  ?>
  <dl class="glpiacessivel-definition-list">
    <dt><?= glpiacessivel_e(glpiacessivel_t('Versão do plugin')) ?></dt>
    <dd><?= glpiacessivel_e((string) ($operationalDiagnostics['plugin_version'] ?? glpiacessivel_t('Não informado'))) ?></dd>
    <dt><?= glpiacessivel_e(glpiacessivel_t('Versão do pacote em disco')) ?></dt>
    <dd><?= glpiacessivel_e((string) ($runtimeUpdate['disk_version'] ?? glpiacessivel_t('Não informado'))) ?></dd>
    <dt><?= glpiacessivel_e(glpiacessivel_t('Estado da atualização')) ?></dt>
    <?php $runtimeState = (string) ($runtimeUpdate['state'] ?? 'marker_missing_or_invalid'); ?>
    <dd><?= glpiacessivel_e((string) ($runtimeStateLabels[$runtimeState] ?? $runtimeState)) ?></dd>
    <dt><?= glpiacessivel_e(glpiacessivel_t('Canal de atualização')) ?></dt>
    <dd><?= glpiacessivel_e(($runtimeUpdate['update_channel'] ?? '') === 'glpi_marketplace' ? glpiacessivel_t('Marketplace do GLPI') : glpiacessivel_t('Não configurado')) ?></dd>
    <dt><?= glpiacessivel_e(glpiacessivel_t('OPcache')) ?></dt>
    <dd><?= glpiacessivel_e(!empty($runtimeUpdate['opcache_enabled']) ? glpiacessivel_t('Ativo; invalidação restrita disponível no fluxo de atualização') : glpiacessivel_t('Desativado')) ?></dd>
    <dt><?= glpiacessivel_e(glpiacessivel_t('Fingerprint de runtime')) ?></dt>
    <dd><?= glpiacessivel_e(!empty($runtimeUpdate['runtime_epoch_consistent']) ? glpiacessivel_t('Consistente') : glpiacessivel_t('Inconsistente ou ainda não verificado')) ?></dd>
    <dt><?= glpiacessivel_e(glpiacessivel_t('GLPI')) ?></dt>
    <dd><?= glpiacessivel_e((string) ($operationalDiagnostics['glpi_version'] ?? glpiacessivel_t('Não informado'))) ?></dd>
    <dt><?= glpiacessivel_e(glpiacessivel_t('PHP')) ?></dt>
    <dd><?= glpiacessivel_e((string) ($operationalDiagnostics['php_version'] ?? PHP_VERSION)) ?></dd>
    <dt><?= glpiacessivel_e(glpiacessivel_t('Modo de acessibilidade')) ?></dt>
    <?php $diagnosticAccessibilityMode = (string) ($operationalDiagnostics['accessibility_mode'] ?? ''); ?>
    <dd><?= glpiacessivel_e((string) ($diagnosticAccessibilityModeLabels[$diagnosticAccessibilityMode] ?? $diagnosticAccessibilityMode)) ?></dd>
    <dt><?= glpiacessivel_e(glpiacessivel_t('Entrada antes da autenticação')) ?></dt>
    <?php $diagnosticAuthenticationMode = (string) ($operationalDiagnostics['authentication_entry_mode'] ?? 'native_only'); ?>
    <dd><?= glpiacessivel_e((string) ($diagnosticAuthenticationModeLabels[$diagnosticAuthenticationMode] ?? $diagnosticAuthenticationMode)) ?></dd>
    <dt><?= glpiacessivel_e(glpiacessivel_t('Aviso de acessibilidade no login')) ?></dt>
    <dd><?= glpiacessivel_e((($operationalDiagnostics['show_login_accessibility_notice'] ?? '0') === '1') ? glpiacessivel_t('Ativo') : glpiacessivel_t('Desativado')) ?></dd>
    <dt><?= glpiacessivel_e(glpiacessivel_t('Escopo do VLibras')) ?></dt>
    <?php $diagnosticVlibrasScope = (string) ($operationalDiagnostics['vlibras_scope'] ?? ''); ?>
    <dd><?= glpiacessivel_e((string) ($vlibrasLabels[$diagnosticVlibrasScope] ?? $diagnosticVlibrasScope)) ?></dd>
    <dt><?= glpiacessivel_e(glpiacessivel_t('Formulários no portal')) ?></dt>
    <dd><?= glpiacessivel_e(((string) ($operationalDiagnostics['forms_enabled'] ?? '1')) === '1' ? glpiacessivel_t('Habilitado') : glpiacessivel_t('Desativado')) ?></dd>
    <dt><?= glpiacessivel_e(glpiacessivel_t('Modo de abertura dos formulários')) ?></dt>
    <?php $diagnosticFormsMode = (string) ($operationalDiagnostics['forms_native_flow_mode'] ?? 'native_embedded'); ?>
    <dd><?= glpiacessivel_e((string) ($formsNativeFlowLabels[$diagnosticFormsMode] ?? $diagnosticFormsMode)) ?></dd>
    <dt><?= glpiacessivel_e(glpiacessivel_t('Origem dos arquivos de voz')) ?></dt>
    <?php $diagnosticVoiceMode = (string) ($operationalDiagnostics['voice_asset_mode'] ?? ''); ?>
    <dd><?= glpiacessivel_e((string) ($diagnosticVoiceModeLabels[$diagnosticVoiceMode] ?? $diagnosticVoiceMode)) ?></dd>
    <dt><?= glpiacessivel_e(glpiacessivel_t('Retenção de auditoria')) ?></dt>
    <?php $retentionDays = (int) ($operationalDiagnostics['audit_retention_days'] ?? 0); ?>
    <dd><?= glpiacessivel_e(sprintf(_n('%d dia', '%d dias', $retentionDays, 'glpiacessivel'), $retentionDays)) ?></dd>
  </dl>

  <?php $voiceSources = is_array($operationalDiagnostics['voice_sources'] ?? null) ? $operationalDiagnostics['voice_sources'] : []; ?>
  <?php
    $voiceAssetLabels = [
      'sttScriptSource' => glpiacessivel_t('Script de reconhecimento de fala'),
      'sttModelSource' => glpiacessivel_t('Modelo de reconhecimento de fala'),
      'ttsScriptSource' => glpiacessivel_t('Módulo de síntese de voz'),
      'ttsOnnxRuntimeSource' => glpiacessivel_t('Biblioteca ONNX'),
      'ttsOnnxWasmBaseSource' => glpiacessivel_t('Arquivos WASM do ONNX'),
      'ttsPiperWasmSource' => glpiacessivel_t('Arquivo WASM do Piper'),
      'ttsPiperDataSource' => glpiacessivel_t('Dados do Piper'),
      'ttsVoiceModelSource' => glpiacessivel_t('Modelo de voz'),
      'ttsVoiceConfigSource' => glpiacessivel_t('Configuração da voz'),
    ];
    $voiceSourceLabels = [
      'local' => glpiacessivel_t('Arquivo local'),
      'external' => glpiacessivel_t('Endereço externo'),
      'external_fallback' => glpiacessivel_t('Endereço externo alternativo'),
      'missing_local' => glpiacessivel_t('Arquivo local ausente'),
      'missing_external' => glpiacessivel_t('Endereço externo ausente'),
    ];
    ?>
  <?php if ($voiceSources !== []) : ?>
    <div class="glpiacessivel-table-wrapper">
      <table class="glpiacessivel-table">
        <caption><?= glpiacessivel_e(glpiacessivel_t('Origem dos arquivos de voz')) ?></caption>
        <thead>
          <tr>
            <th scope="col"><?= glpiacessivel_e(glpiacessivel_t('Arquivo')) ?></th>
            <th scope="col"><?= glpiacessivel_e(glpiacessivel_t('Origem')) ?></th>
          </tr>
        </thead>
        <tbody>
          <?php foreach ($voiceSources as $asset => $source) : ?>
            <tr>
              <th scope="row"><?= glpiacessivel_e((string) ($voiceAssetLabels[$asset] ?? $asset)) ?></th>
              <td><?= glpiacessivel_e((string) ($voiceSourceLabels[$source] ?? $source)) ?></td>
            </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  <?php endif; ?>
</section>

<section class="glpiacessivel-card" aria-labelledby="config-mode-help">
  <h2 id="config-mode-help"><?= glpiacessivel_e(glpiacessivel_t('Como os modos funcionam')) ?></h2>
  <p><strong><?= glpiacessivel_e(glpiacessivel_t('Portal acessível:')) ?></strong> <?= glpiacessivel_e(glpiacessivel_t('indicado quando a central quer priorizar acessibilidade, previsibilidade visual e controle detalhado da jornada do usuário.')) ?></p>
  <p><strong><?= glpiacessivel_e(glpiacessivel_t('Embutido no GLPI:')) ?></strong> <?= glpiacessivel_e(glpiacessivel_t('indicado quando a prioridade é trabalhar principalmente na interface do GLPI, com menor controle de acessibilidade de ponta a ponta.')) ?></p>
  <p><strong><?= glpiacessivel_e(glpiacessivel_t('Híbrido:')) ?></strong> <?= glpiacessivel_e(glpiacessivel_t('mantém o portal como rota acessível principal e usa o GLPI embutido para dar continuidade ao trabalho.')) ?></p>
</section>
