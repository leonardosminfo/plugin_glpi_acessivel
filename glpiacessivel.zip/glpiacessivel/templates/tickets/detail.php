<?php
$t = static fn(string $text): string => glpiacessivel_t($text);
$routing = is_array($ticket['routing_context'] ?? null) ? $ticket['routing_context'] : [];
$itilActions = is_array($ticket['itil_actions'] ?? null) ? $ticket['itil_actions'] : [];
$satisfaction = is_array($ticket['satisfaction_state'] ?? null) ? $ticket['satisfaction_state'] : [];
$historyContext = is_array($ticket['history_context'] ?? null) ? $ticket['history_context'] : [];
$historyItems = array_values((array) ($historyContext['items'] ?? []));
$criticalConfirmations = is_array($critical_confirmations ?? null) ? $critical_confirmations : [];
$solutionDecisionOperationId = is_string($solution_decision_operation_id ?? null)
    ? (string) $solution_decision_operation_id
    : '';
$assignedUserIds = array_values(array_map('intval', (array) ($routing['assigned_user_ids'] ?? [])));
$observerUserIds = array_values(array_map('intval', (array) ($routing['observer_user_ids'] ?? [])));
$requesterUserIds = array_values(array_map('intval', (array) ($routing['requester_user_ids'] ?? [])));
$assignedGroupIds = array_values(array_map('intval', (array) ($routing['assigned_group_ids'] ?? [])));
$observerGroupIds = array_values(array_map('intval', (array) ($routing['observer_group_ids'] ?? [])));
$requesterGroupIds = array_values(array_map('intval', (array) ($routing['requester_group_ids'] ?? [])));
$assignedSupplierIds = array_values(array_map('intval', (array) ($routing['assigned_supplier_ids'] ?? [])));
$followupTemplates = array_values((array) ($ticket['followup_templates'] ?? []));
$taskTemplates = array_values((array) ($ticket['task_templates'] ?? []));
$solutionTemplates = array_values((array) ($ticket['solution_templates'] ?? []));
$solutionTypes = array_values((array) ($ticket['solution_types'] ?? []));
$solutionOperation = is_array($itilActions['solution_operation'] ?? null)
    ? $itilActions['solution_operation']
    : ['state' => 'unavailable', 'solution_id' => 0, 'ticket_status' => 0];
$solutionOperationState = (string) ($solutionOperation['state'] ?? 'unavailable');
$solutionDecision = is_array($ticket['solution_decision'] ?? null)
    ? $ticket['solution_decision']
    : [
        'state' => 'unavailable',
        'visible' => false,
        'can_decide' => false,
        'current_status' => 0,
        'solution_id' => 0,
        'solution_status' => 0,
        'revision' => '',
    ];
$solutionDecisionState = (string) ($solutionDecision['state'] ?? 'unavailable');
$solutionDecisionRevision = trim((string) ($solutionDecision['revision'] ?? ''));
$generalEdit = is_array($ticket['general_edit'] ?? null) ? $ticket['general_edit'] : [];
$generalEditableFields = array_values(array_unique(array_filter(
    array_map('strval', (array) ($generalEdit['editable_fields'] ?? [])),
    static fn(string $field): bool => in_array($field, [
        'name',
        'content',
        'type',
        'itilcategories_id',
        'locations_id',
        'requesttypes_id',
        'urgency',
        'impact',
        'priority',
    ], true)
)));
$generalValues = is_array($generalEdit['values'] ?? null) ? $generalEdit['values'] : [];
$generalMandatoryFields = array_values(array_intersect(
    array_map('strval', (array) ($generalEdit['mandatory_fields'] ?? [])),
    $generalEditableFields
));
foreach ([
    'name',
    'content',
    'type',
    'itilcategories_id',
    'locations_id',
    'requesttypes_id',
    'urgency',
    'impact',
    'priority',
] as $generalField) {
    if (!array_key_exists($generalField, $generalValues) && array_key_exists($generalField, $ticket)) {
        $generalValues[$generalField] = $ticket[$generalField];
    }
}
$generalRevision = trim((string) ($generalEdit['revision'] ?? ''));
$generalFormReady = !empty($generalEdit['can_update'])
    && $generalEditableFields !== []
    && preg_match('/\A[a-f0-9]{64}\z/D', $generalRevision) === 1;
$generalCanEdit = static fn(string $field): bool => in_array($field, $generalEditableFields, true);
$generalIsRequired = static fn(string $field): bool => in_array($field, $generalMandatoryFields, true);
$generalSelectedResources = is_array($generalEdit['selected_resources'] ?? null)
    ? $generalEdit['selected_resources']
    : [];
$generalResourceSelectorConfig = is_array($generalEdit['resource_selector'] ?? null)
    ? $generalEdit['resource_selector']
    : [];
$generalResourceSelectorEnabled = $generalFormReady
    && !empty($generalResourceSelectorConfig['enabled']);
$generalCategories = $generalResourceSelectorEnabled
    ? array_values((array) ($generalSelectedResources['itilcategories_id'] ?? []))
    : array_values((array) ($generalEdit['categories'] ?? []));
$generalLocations = $generalResourceSelectorEnabled
    ? array_values((array) ($generalSelectedResources['locations_id'] ?? []))
    : array_values((array) ($generalEdit['locations'] ?? []));
$generalTypeOptions = array_values((array) ($generalEdit['type_options'] ?? []));
$generalRequestSourceOptions = array_values((array) ($generalEdit['request_source_options'] ?? []));
$generalUrgencyOptions = array_values((array) ($generalEdit['urgency_options'] ?? []));
$generalImpactOptions = array_values((array) ($generalEdit['impact_options'] ?? []));
$generalPriorityOptions = array_values((array) ($generalEdit['priority_options'] ?? []));
$generalMergeCurrentOption = static function (array $options, int $id, string $label): array {
    $normalized = [];
    foreach ($options as $option) {
        if (!is_array($option)) {
            continue;
        }
        $optionId = (int) ($option['id'] ?? 0);
        $optionLabel = trim((string) ($option['label'] ?? ''));
        if ($optionId > 0 && $optionLabel !== '') {
            $normalized[$optionId] = ['id' => $optionId, 'label' => $optionLabel];
        }
    }
    if ($id > 0 && !isset($normalized[$id]) && trim($label) !== '') {
        $normalized[$id] = ['id' => $id, 'label' => trim($label)];
    }
    return array_values($normalized);
};
$generalCategories = $generalMergeCurrentOption(
    $generalCategories,
    (int) ($generalValues['itilcategories_id'] ?? 0),
    (string) ($ticket['category_name'] ?? '')
);
$generalLocations = $generalMergeCurrentOption(
    $generalLocations,
    (int) ($generalValues['locations_id'] ?? 0),
    (string) ($ticket['location_name'] ?? '')
);
$generalContent = (string) ($generalValues['content_plain'] ?? $generalValues['content'] ?? '');
if (!array_key_exists('content_plain', $generalValues) && $generalContent !== '') {
    try {
        $generalContent = (new \GlpiPlugin\Glpiacessivel\Support\RichTextToPlainText())
            ->convert($generalContent)['text'];
    } catch (\Throwable) {
        // Keep the inert, escaped source available rather than silently
        // discarding content when DOM support is unavailable.
    }
}
$taskCategories = array_values((array) ($routing['task_categories'] ?? []));
$taskStateOptions = array_values((array) ($routing['task_state_options'] ?? []));
$taskDurationOptions = array_values((array) ($routing['task_duration_options'] ?? []));
$assignableUsers = array_values((array) ($routing['assignable_users'] ?? []));
$observerUsers = array_values((array) ($routing['observer_users'] ?? []));
$requesterUsers = array_values((array) ($routing['requester_users'] ?? []));
$assignableGroups = array_values((array) ($routing['assignable_groups'] ?? []));
$taskGroups = array_values((array) ($routing['task_groups'] ?? $assignableGroups));
$observerGroups = array_values((array) ($routing['observer_groups'] ?? []));
$requesterGroups = array_values((array) ($routing['requester_groups'] ?? []));
$assignableSuppliers = array_values((array) ($routing['assignable_suppliers'] ?? []));
$resourceSelectorConfig = is_array($routing['resource_selector'] ?? null) ? $routing['resource_selector'] : [];
$selectedResources = is_array($routing['selected_resources'] ?? null) ? $routing['selected_resources'] : [];
$routingSelectionComplete = !empty($routing['routing_selection_complete']);
$routingRevision = trim((string) ($routing['routing_revision'] ?? ''));
$routingFormReady = $routingSelectionComplete
    && preg_match('/\A[a-f0-9]{64}\z/D', $routingRevision) === 1;
// Existing routing is enhanced only after the server has safely hydrated every
// current actor. A partial result must never become a submitted empty selection.
$resourceSelectorEnabled = !empty($resourceSelectorConfig['enabled'])
    && $routingFormReady;
$mergeRoutingOptions = static function (array $current, array $candidates): array {
    $merged = [];
    foreach (array_merge($current, $candidates) as $item) {
        if (!is_array($item)) {
            continue;
        }
        $id = (int) ($item['id'] ?? 0);
        $label = trim((string) ($item['label'] ?? ''));
        if ($id > 0 && $label !== '') {
            $merged[$id] = ['id' => $id, 'label' => $label];
        }
    }
    return array_values($merged);
};
if ($routingFormReady) {
    $currentAssignableUsers = array_values((array) ($selectedResources['_users_id_assign'] ?? []));
    $currentObserverUsers = array_values((array) ($selectedResources['_users_id_observer'] ?? []));
    $currentRequesterUsers = array_values((array) ($selectedResources['_users_id_requester'] ?? []));
    $currentAssignableGroups = array_values((array) ($selectedResources['_groups_id_assign'] ?? []));
    $currentObserverGroups = array_values((array) ($selectedResources['_groups_id_observer'] ?? []));
    $currentRequesterGroups = array_values((array) ($selectedResources['_groups_id_requester'] ?? []));
    $currentAssignableSuppliers = array_values((array) ($selectedResources['_suppliers_id_assign'] ?? []));
}
if ($resourceSelectorEnabled) {
    $assignableUsers = $currentAssignableUsers;
    $observerUsers = $currentObserverUsers;
    $requesterUsers = $currentRequesterUsers;
    $assignableGroups = $currentAssignableGroups;
    $taskGroups = $assignableGroups;
    $observerGroups = $currentObserverGroups;
    $requesterGroups = $currentRequesterGroups;
    $assignableSuppliers = $currentAssignableSuppliers;
} elseif ($routingFormReady) {
    $assignableUsers = $mergeRoutingOptions($currentAssignableUsers, $assignableUsers);
    $observerUsers = $mergeRoutingOptions($currentObserverUsers, $observerUsers);
    $requesterUsers = $mergeRoutingOptions($currentRequesterUsers, $requesterUsers);
    $assignableGroups = $mergeRoutingOptions($currentAssignableGroups, $assignableGroups);
    $observerGroups = $mergeRoutingOptions($currentObserverGroups, $observerGroups);
    $requesterGroups = $mergeRoutingOptions($currentRequesterGroups, $requesterGroups);
    $assignableSuppliers = $mergeRoutingOptions($currentAssignableSuppliers, $assignableSuppliers);
}
$resourceSelectorAssetPath = 'public/assets/js/remote-resource-selector.js';
$resourceSelectorAssetVersion = function_exists('plugin_glpiacessivel_asset_version')
    ? plugin_glpiacessivel_asset_version($resourceSelectorAssetPath)
    : (string) (@filemtime(__DIR__ . '/../../' . $resourceSelectorAssetPath) ?: '1');
$resourceSelectorAssetUrl = \GlpiPlugin\Glpiacessivel\Support\Url::asset(
    $resourceSelectorAssetPath . '?v=' . rawurlencode($resourceSelectorAssetVersion)
);
$ticketStatus = (int) ($ticket['status'] ?? 0);
$allowedStatusTransitions = array_values(array_unique(array_filter(
    array_map('intval', (array) ($ticket['allowed_transitions'] ?? [])),
    static fn(int $status): bool => $status > 0 && $status !== $ticketStatus
)));
$solvedStatus = defined('\CommonITILObject::SOLVED') ? (int) \CommonITILObject::SOLVED : 5;
$closedStatus = defined('\CommonITILObject::CLOSED') ? (int) \CommonITILObject::CLOSED : 6;
$isSolved = $ticketStatus === $solvedStatus;
$isClosed = $ticketStatus === $closedStatus;
$isTerminal = $isSolved || $isClosed;
$canAddFollowup = !$isTerminal && !empty($itilActions['can_add_followup']);
$canAddTask = !$isTerminal && !empty($itilActions['can_add_task']);
$canAddPrivateFollowup = $canAddFollowup && !empty($itilActions['can_add_private_followup']);
$canAddPrivateTask = $canAddTask && !empty($itilActions['can_add_private_task']);
$canAddSolution = !$isTerminal
    && $solutionOperationState === 'ready'
    && !empty($itilActions['can_add_solution']);
$canChangeStatus = !$isTerminal && !empty($itilActions['can_change_status']);
$canAssignActors = !$isTerminal && !empty($itilActions['can_assign_actors']);
$canObserveActors = !$isTerminal && !empty($itilActions['can_observe_actors']);
$canAdminRequesters = !$isTerminal && !empty($itilActions['can_admin_actors']);
$canRoute = $canAssignActors || $canObserveActors || $canAdminRequesters;
$canDecideSolution = $isSolved
    && !empty($solutionDecision['can_decide'])
    && $solutionDecisionState === 'ready'
    && preg_match('/\A[a-f0-9]{64}\z/D', $solutionDecisionRevision) === 1;
$itilTabs = [];
if ($canAddFollowup) {
    $itilTabs[] = ['key' => 'followup', 'label' => $t('Responder'), 'hint' => $t('Acompanhamento')];
}
if ($canAddTask) {
    $itilTabs[] = ['key' => 'task', 'label' => $t('Criar tarefa'), 'hint' => $t('Atividade técnica')];
}
if ($canAddSolution) {
    $itilTabs[] = ['key' => 'solution', 'label' => $t('Adicionar solução'), 'hint' => $t('Encaminhar encerramento')];
}
$activeItilTab = (string) ($itilTabs[0]['key'] ?? '');
$nativeTodoTaskState = defined('\Planning::TODO') ? (int) \Planning::TODO : 1;
$defaultTaskState = (int) ($taskStateOptions[0]['id'] ?? $nativeTodoTaskState);
foreach ($taskStateOptions as $taskStateOption) {
    $taskStateId = (int) ($taskStateOption['id'] ?? 0);
    if ($taskStateId === $nativeTodoTaskState) {
        $defaultTaskState = $taskStateId;
        break;
    }
}
$defaultFollowupIsPrivate = $canAddPrivateFollowup && !empty($itilActions['default_followup_is_private']);
$defaultTaskIsPrivate = $canAddPrivateTask && !empty($itilActions['default_task_is_private']);
$requesterName = trim((string) (($ticket['requester_firstname'] ?? '') . ' ' . ($ticket['requester_realname'] ?? '')));
if ($requesterName === '') {
    $requesterName = $t('Não informado');
}
$openingDate = trim((string) ($ticket['date'] ?? ''));
$updatedDate = trim((string) ($ticket['date_mod'] ?? ''));
$htmlDateTime = static function (string $value): string {
    if (preg_match('/^\d{4}-\d{2}-\d{2}(?:[ T]\d{2}:\d{2}(?::\d{2})?)?$/', $value) !== 1) {
        return '';
    }

    return str_replace(' ', 'T', $value);
};
$openingDateTime = $htmlDateTime($openingDate);
$updatedDateTime = $htmlDateTime($updatedDate);
$piiMaskingEnabled = !empty($ticket['pii_masking_enabled']);
$revealedPiiFields = array_fill_keys((array) ($ticket['revealed_pii_fields'] ?? []), true);
$canRevealPii = $piiMaskingEnabled && !empty($ticket['can_reveal_pii']);
$attachmentHelp = __('Opcional. O GLPI validará extensão, tamanho e permissão conforme a configuração do servidor.', 'glpiacessivel');
$fileSelectionMessages = [
    'empty' => __('Nenhum anexo selecionado.', 'glpiacessivel'),
    'cleared' => __('Seleção de anexos limpa.', 'glpiacessivel'),
    'selected_one' => __('1 anexo selecionado.', 'glpiacessivel'),
    'selected_many' => __('%d anexos selecionados.', 'glpiacessivel'),
];
$followupTemplateMessages = [
    'replace_confirmation' => $t('Substituir o texto atual pelo modelo selecionado?'),
    'cancelled' => $t('Aplicação do modelo cancelada. Nenhum conteúdo foi alterado.'),
    'applied' => $t('Modelo de acompanhamento aplicado.'),
    'followup_metadata_applied' => $t('Modelo de acompanhamento aplicado à visibilidade. O campo de descrição foi preservado.'),
    'followup_no_changes' => $t('O modelo de acompanhamento não contém descrição e a visibilidade já corresponde ao modelo. Nenhum conteúdo foi alterado.'),
    'followup_empty' => $t('O modelo de acompanhamento não contém descrição nem campos aplicáveis. O campo de descrição foi preservado.'),
    'task_applied' => $t('Modelo de tarefa aplicado.'),
    'task_metadata_applied' => $t('Modelo de tarefa aplicado aos campos complementares. O campo de descrição foi preservado.'),
    'task_no_changes' => $t('O modelo de tarefa não contém descrição e os campos complementares já possuem os valores do modelo. Nenhum conteúdo foi alterado.'),
    'task_empty' => $t('O modelo de tarefa não contém descrição nem campos aplicáveis. O campo de descrição foi preservado.'),
    'solution_applied' => $t('Modelo de solução aplicado.'),
    'solution_metadata_applied' => $t('Modelo de solução aplicado ao tipo de solução. O campo de descrição foi preservado.'),
    'solution_no_changes' => $t('O modelo de solução não contém descrição e o tipo de solução já corresponde ao modelo. Nenhum conteúdo foi alterado.'),
    'solution_empty' => $t('O modelo de solução não contém descrição nem campos aplicáveis. O campo de descrição foi preservado.'),
    'lossy' => $t('A formatação ou as imagens do modelo foram convertidas para texto legível.'),
    'loading' => $t('Carregando modelo.'),
    'error' => $t('Não foi possível carregar o modelo. Recarregue a página e tente novamente.'),
    'error_session_expired' => $t('Sua sessão expirou. Entre novamente no GLPI antes de aplicar o modelo.'),
    'error_context_stale' => $t('O perfil ou a entidade mudou. Recarregue a página antes de aplicar o modelo.'),
    'error_invalid_security_token' => $t('A validação de segurança expirou. Recarregue a página antes de tentar novamente.'),
    'error_forbidden' => $t('Seu perfil não permite aplicar este modelo neste chamado.'),
    'error_template_not_available' => $t('Este modelo não está mais disponível para o perfil, a entidade ou os campos atuais. Escolha outro modelo.'),
    'error_temporarily_unavailable' => $t('O serviço de modelos está temporariamente indisponível. Tente novamente em alguns instantes.'),
    'error_invalid_response' => $t('O servidor devolveu uma resposta inválida. Abra o chamado no GLPI ou contate o suporte.'),
    'error_timeout' => $t('O carregamento do modelo excedeu o tempo esperado. Tente novamente.'),
    'error_reference' => $t('Referência de atendimento: {request_id}.'),
    'model_value' => $t('Valor definido pelo modelo'),
];
$templatePreviewUrl = glpiacessivel_url('front/ticket.template.php');
$formatDocumentSize = static function (int $bytes): string {
    if ($bytes <= 0) {
        return __('Tamanho não informado', 'glpiacessivel');
    }
    if ($bytes >= 1024 * 1024) {
        return number_format($bytes / (1024 * 1024), 1, ',', '.') . ' MB';
    }
    if ($bytes >= 1024) {
        return number_format($bytes / 1024, 1, ',', '.') . ' KB';
    }

    return $bytes . ' B';
};
$documentTypeLabel = static function (array $document): string {
    $displayName = (string) ($document['display_name'] ?? $document['filename'] ?? '');
    $extension = strtoupper((string) pathinfo($displayName, PATHINFO_EXTENSION));
    if ($extension !== '') {
        return $extension;
    }
    $mime = trim((string) ($document['mime'] ?? ''));

    return $mime !== '' ? $mime : __('Tipo não informado', 'glpiacessivel');
};
$renderDocuments = static function (
    array $documents,
    string $originLabel
) use ($formatDocumentSize, $documentTypeLabel): void {
    if ($documents === []) {
        return;
    }
    ?>
    <ul class="glpiacessivel-list glpiacessivel-document-list">
      <?php foreach ($documents as $document): ?>
        <?php
          $displayName = trim((string) ($document['display_name'] ?? $document['filename'] ?? $document['name'] ?? ''));
          $documentType = $documentTypeLabel($document);
          $documentSize = $formatDocumentSize((int) ($document['size'] ?? 0));
          $downloadLabel = sprintf(
              __('Baixar %1$s, documento %2$s, %3$s', 'glpiacessivel'),
              $displayName,
              $documentType,
              $documentSize
          );
        ?>
        <li>
          <a
            class="glpiacessivel-document-link"
            href="<?= glpiacessivel_e((string) ($document['download_url'] ?? '')) ?>"
            aria-label="<?= glpiacessivel_e($downloadLabel) ?>"
          ><?= glpiacessivel_e($displayName) ?></a>
          <dl class="glpiacessivel-document-meta">
            <div><dt><?= glpiacessivel_e(__('Formato', 'glpiacessivel')) ?></dt><dd><?= glpiacessivel_e($documentType) ?></dd></div>
            <div><dt><?= glpiacessivel_e(__('Tamanho', 'glpiacessivel')) ?></dt><dd><?= glpiacessivel_e($documentSize) ?></dd></div>
            <div><dt><?= glpiacessivel_e(__('Origem', 'glpiacessivel')) ?></dt><dd><?= glpiacessivel_e($originLabel) ?></dd></div>
            <?php if (!empty($document['date_mod'])): ?>
              <div><dt><?= glpiacessivel_e(__('Atualizado em', 'glpiacessivel')) ?></dt><dd><?= glpiacessivel_e((string) $document['date_mod']) ?></dd></div>
            <?php endif; ?>
            <?php if (array_key_exists('is_private', $document)): ?>
              <div><dt><?= glpiacessivel_e(__('Visibilidade', 'glpiacessivel')) ?></dt><dd><?= glpiacessivel_e(!empty($document['is_private']) ? __('Privado', 'glpiacessivel') : __('Público', 'glpiacessivel')) ?></dd></div>
            <?php endif; ?>
          </dl>
        </li>
      <?php endforeach; ?>
    </ul>
    <?php
};
?>
<section class="glpiacessivel-card" aria-labelledby="detalhe-ticket">
  <h2 id="detalhe-ticket" tabindex="-1"><?= glpiacessivel_e($t('Chamado')) ?> #<?= (int) $ticket['id'] ?> - <?= glpiacessivel_e($ticket['name']) ?></h2>
  <dl class="glpiacessivel-ticket-summary">
    <div>
      <dt><?= glpiacessivel_e($t('Status')) ?></dt>
      <dd><span class="glpiacessivel-badge glpiacessivel-badge-status-<?= glpiacessivel_e(glpiacessivel_status_class($ticket['status'])) ?>">
        <?= glpiacessivel_e(glpiacessivel_ticket_status($ticket['status'])) ?>
      </span></dd>
    </div>
    <div>
      <dt><?= glpiacessivel_e($t('Prioridade')) ?></dt>
      <dd><span class="glpiacessivel-badge glpiacessivel-badge-priority-<?= glpiacessivel_e(glpiacessivel_priority_class($ticket['priority'])) ?>">
        <?= glpiacessivel_e(glpiacessivel_ticket_priority($ticket['priority'])) ?>
      </span></dd>
    </div>
    <div><dt><?= glpiacessivel_e($t('Entidade')) ?></dt><dd><?= glpiacessivel_e((string) ($ticket['entity_name'] ?? $ticket['entities_id'])) ?></dd></div>
    <div><dt><?= glpiacessivel_e($t('Categoria')) ?></dt><dd><?= glpiacessivel_e((string) ($ticket['category_name'] ?? $t('Não informado'))) ?></dd></div>
    <div><dt><?= glpiacessivel_e($t('Localização')) ?></dt><dd><?= glpiacessivel_e((string) ($ticket['location_name'] ?? $t('Não informado'))) ?></dd></div>
    <div>
      <dt><?= glpiacessivel_e($t('Data de abertura')) ?></dt>
      <dd><?php if ($openingDate !== ''): ?><time<?= $openingDateTime !== '' ? ' datetime="' . glpiacessivel_e($openingDateTime) . '"' : '' ?>><?= glpiacessivel_e($openingDate) ?></time><?php else: ?><?= glpiacessivel_e($t('Não informado')) ?><?php endif; ?></dd>
    </div>
    <div>
      <dt><?= glpiacessivel_e($t('Última atualização')) ?></dt>
      <dd><?php if ($updatedDate !== ''): ?><time<?= $updatedDateTime !== '' ? ' datetime="' . glpiacessivel_e($updatedDateTime) . '"' : '' ?>><?= glpiacessivel_e($updatedDate) ?></time><?php else: ?><?= glpiacessivel_e($t('Não informado')) ?><?php endif; ?></dd>
    </div>
  </dl>

  <?php require __DIR__ . '/self_assign.php'; ?>

  <?php if (!empty($generalEdit['can_update'])): ?>
    <section class="glpiacessivel-routing-panel" aria-labelledby="editar-dados-chamado">
      <h3 id="editar-dados-chamado" tabindex="-1"><?= glpiacessivel_e($t('Editar dados do chamado')) ?></h3>
      <p id="general-edit-help" class="glpiacessivel-muted">
        <?= glpiacessivel_e($t('Altere somente os campos autorizados pelo perfil e pela entidade atuais. O GLPI validará novamente permissões, regras e campos protegidos antes de salvar.')) ?>
      </p>
      <?php if (!$generalFormReady): ?>
        <div class="glpiacessivel-alert glpiacessivel-alert-warning" role="alert">
          <strong><?= glpiacessivel_e($t('Os dados editáveis não puderam ser conferidos.')) ?></strong>
          <p><?= glpiacessivel_e($t('Nenhuma alteração será enviada para evitar a substituição de informações atualizadas por outra pessoa.')) ?></p>
          <a class="glpiacessivel-button glpiacessivel-button-secondary" href="<?= glpiacessivel_e(glpiacessivel_url('front/tickets.php?id=' . (int) $ticket['id'] . '#editar-dados-chamado')) ?>"><?= glpiacessivel_e($t('Recarregar dados do chamado')) ?></a>
        </div>
      <?php else: ?>
        <?php $generalTypeDependencyId = $generalCanEdit('type') ? 'general_type' : 'general_type_context'; ?>
        <form
          method="post"
          action="<?= glpiacessivel_e(glpiacessivel_url('front/ticket.action.php')) ?>"
          class="glpiacessivel-form"
          aria-describedby="general-edit-help"
          data-glpiacessivel-general-edit
          data-glpiacessivel-critical-form
          data-critical-title="<?= glpiacessivel_e($t('Confirmar atualização dos dados do chamado')) ?>"
          data-critical-message="<?= glpiacessivel_e(sprintf($t('Revise os campos alterados do chamado #%d antes de salvar.'), (int) $ticket['id'])) ?>"
          data-critical-consequence="<?= glpiacessivel_e($t('Esta ação altera os dados gerais do chamado no GLPI.')) ?>"
          data-general-changes-prefix="<?= glpiacessivel_e($t('Campos alterados')) ?>"
          data-general-change-template="<?= glpiacessivel_e($t('{field}: de {from} para {to}.')) ?>"
          data-general-sensitive-change-template="<?= glpiacessivel_e($t('{field}: o conteúdo será alterado sem ser exibido nesta confirmação.')) ?>"
          data-general-empty-label="<?= glpiacessivel_e($t('Não informado')) ?>"
          data-general-no-changes="<?= glpiacessivel_e($t('Nenhuma alteração foi selecionada.')) ?>"
          <?php if ($generalResourceSelectorEnabled): ?>
            data-resource-selector-url="<?= glpiacessivel_e(glpiacessivel_url('front/ticket.resource-selector.php')) ?>"
            data-resource-selector-csrf="<?= glpiacessivel_e($csrf_tokens['general_update'] ?? $csrf_token) ?>"
            data-resource-selector-context-revision="<?= glpiacessivel_e((string) ($generalResourceSelectorConfig['context_revision'] ?? '')) ?>"
            data-resource-selector-version="1"
            data-resource-selector-timeout="<?= max(500, min(5000, (int) ($generalResourceSelectorConfig['timeout_ms'] ?? 5000))) ?>"
            data-resource-selector-limit="<?= max(1, min(20, (int) ($generalResourceSelectorConfig['page_size'] ?? 20))) ?>"
            data-resource-selector-error-summary="#general-selector-errors"
          <?php endif; ?>
        >
          <input type="hidden" name="_glpi_csrf_token" value="<?= glpiacessivel_e($csrf_tokens['general_update'] ?? $csrf_token) ?>" />
          <input id="general_ticket_id" type="hidden" name="ticket_id" value="<?= (int) $ticket['id'] ?>" />
          <input type="hidden" name="action" value="general_update" />
          <input type="hidden" name="expected_revision" value="<?= glpiacessivel_e($generalRevision) ?>" />
          <input type="hidden" name="critical_confirmed" value="0" />
          <input type="hidden" name="critical_confirmation_token" value="<?= glpiacessivel_e((string) ($criticalConfirmations['general_update'] ?? '')) ?>" />
          <?php if (!$generalCanEdit('type')): ?>
            <input id="general_type_context" type="hidden" value="<?= (int) ($generalValues['type'] ?? 0) ?>" />
          <?php endif; ?>

          <div id="general-edit-status" role="status" aria-live="polite" aria-atomic="true" class="glpiacessivel-sr-only"></div>
          <?php if ($generalResourceSelectorEnabled): ?>
            <div id="general-selector-errors" class="glpiacessivel-alert glpiacessivel-alert-error" role="alert" tabindex="-1" hidden>
              <strong><?= glpiacessivel_e($t('Revise os valores selecionados.')) ?></strong>
              <ul class="glpiacessivel-error-list"></ul>
            </div>
          <?php endif; ?>

          <?php if ($generalCanEdit('name') || $generalCanEdit('content')): ?>
            <fieldset class="glpiacessivel-form-fieldset">
              <legend><?= glpiacessivel_e($t('Identificação do chamado')) ?></legend>
              <div class="glpiacessivel-form-grid">
                <?php if ($generalCanEdit('name')): ?>
                  <div class="glpiacessivel-field-block">
                    <label for="general_name"><?= glpiacessivel_e($t('Título')) ?> <span aria-hidden="true">*</span></label>
                    <input id="general_name" name="name" type="text" maxlength="255" required value="<?= glpiacessivel_e((string) ($generalValues['name'] ?? '')) ?>" aria-describedby="general-name-help" data-general-edit-field data-general-field-label="<?= glpiacessivel_e($t('Título')) ?>" />
                    <small id="general-name-help" class="glpiacessivel-help-text"><?= glpiacessivel_e($t('Descreva o assunto principal do chamado de forma objetiva. Campo obrigatório.')) ?></small>
                  </div>
                <?php endif; ?>
                <?php if ($generalCanEdit('content')): ?>
                  <div class="glpiacessivel-field-block">
                    <label for="general_content"><?= glpiacessivel_e($t('Descrição')) ?> <span aria-hidden="true">*</span></label>
                    <textarea id="general_content" name="content" maxlength="16000" rows="8" required aria-describedby="general-content-help" data-general-edit-field data-general-field-label="<?= glpiacessivel_e($t('Descrição')) ?>" data-general-sensitive-field><?= glpiacessivel_e($generalContent) ?></textarea>
                    <small id="general-content-help" class="glpiacessivel-help-text"><?= glpiacessivel_e($t('Revise a descrição completa. Formatação rica é apresentada como texto legível neste campo. Campo obrigatório.')) ?></small>
                  </div>
                <?php endif; ?>
              </div>
            </fieldset>
          <?php endif; ?>

          <?php if (array_intersect($generalEditableFields, ['type', 'itilcategories_id', 'locations_id', 'requesttypes_id']) !== []): ?>
            <fieldset class="glpiacessivel-form-fieldset">
              <legend><?= glpiacessivel_e($t('Classificação e origem')) ?></legend>
              <div class="glpiacessivel-form-grid">
                <?php if ($generalCanEdit('type')): ?>
                  <div class="glpiacessivel-field-block">
                    <label for="general_type"><?= glpiacessivel_e($t('Tipo')) ?></label>
                    <select id="general_type" name="type" required aria-describedby="general-type-help" data-general-edit-field data-general-field-label="<?= glpiacessivel_e($t('Tipo')) ?>">
                      <?php foreach ($generalTypeOptions as $option): ?>
                        <option value="<?= (int) ($option['id'] ?? 0) ?>"<?= (int) ($generalValues['type'] ?? 0) === (int) ($option['id'] ?? 0) ? ' selected' : '' ?>><?= glpiacessivel_e((string) ($option['label'] ?? '')) ?></option>
                      <?php endforeach; ?>
                    </select>
                    <small id="general-type-help" class="glpiacessivel-help-text"><?= glpiacessivel_e($t('A alteração do tipo pode modificar as categorias elegíveis conforme as regras do GLPI.')) ?></small>
                  </div>
                <?php endif; ?>

                <?php if ($generalCanEdit('itilcategories_id')): ?>
                  <?php $generalCategoryRequired = $generalIsRequired('itilcategories_id'); ?>
                  <div class="glpiacessivel-field-block">
                    <label for="general_category"><?= glpiacessivel_e($t('Categoria')) ?><?= $generalCategoryRequired ? ' (' . glpiacessivel_e($t('Obrigatória')) . ')' : '' ?></label>
                    <select
                      id="general_category"
                      name="itilcategories_id"
                      aria-describedby="general-category-help"
                      data-general-edit-field
                      data-general-field-label="<?= glpiacessivel_e($t('Categoria')) ?>"
                      <?= $generalCategoryRequired ? 'required aria-required="true"' : '' ?>
                      <?php if ($generalResourceSelectorEnabled): ?>
                        data-glpiacessivel-resource-select
                        data-resource-provider="category"
                        data-resource-min-chars="0"
                        data-resource-browse-empty="1"
                        data-resource-empty-value="<?= $generalCategoryRequired ? '' : '0' ?>"
                        data-resource-clear-on-dependency="1"
                        data-resource-dependencies="ticket_id:#general_ticket_id,ticket_type:#<?= glpiacessivel_e($generalTypeDependencyId) ?>"
                      <?php endif; ?>
                    >
                      <option value="<?= $generalCategoryRequired ? '' : '0' ?>"<?= (int) ($generalValues['itilcategories_id'] ?? 0) === 0 ? ' selected' : '' ?>><?= glpiacessivel_e($generalCategoryRequired ? $t('Selecione') : $t('Sem categoria')) ?></option>
                      <?php foreach ($generalCategories as $category): ?>
                        <?php $categoryId = (int) ($category['id'] ?? 0); ?>
                        <option value="<?= $categoryId ?>"<?= (int) ($generalValues['itilcategories_id'] ?? 0) === $categoryId ? ' selected' : '' ?>><?= glpiacessivel_e((string) ($category['label'] ?? '')) ?></option>
                      <?php endforeach; ?>
                    </select>
                    <small id="general-category-help" class="glpiacessivel-help-text"><?= glpiacessivel_e($t('São exibidas apenas categorias elegíveis para a entidade e o tipo do chamado.')) ?></small>
                  </div>
                <?php endif; ?>

                <?php if ($generalCanEdit('locations_id')): ?>
                  <?php $generalLocationRequired = $generalIsRequired('locations_id'); ?>
                  <div class="glpiacessivel-field-block">
                    <label for="general_location"><?= glpiacessivel_e($t('Localização')) ?><?= $generalLocationRequired ? ' (' . glpiacessivel_e($t('Obrigatória')) . ')' : '' ?></label>
                    <select
                      id="general_location"
                      name="locations_id"
                      aria-describedby="general-location-help"
                      data-general-edit-field
                      data-general-field-label="<?= glpiacessivel_e($t('Localização')) ?>"
                      <?= $generalLocationRequired ? 'required aria-required="true"' : '' ?>
                      <?php if ($generalResourceSelectorEnabled): ?>
                        data-glpiacessivel-resource-select
                        data-resource-provider="location"
                        data-resource-min-chars="0"
                        data-resource-browse-empty="1"
                        data-resource-empty-value="<?= $generalLocationRequired ? '' : '0' ?>"
                        data-resource-dependencies="ticket_id:#general_ticket_id"
                      <?php endif; ?>
                    >
                      <option value="<?= $generalLocationRequired ? '' : '0' ?>"<?= (int) ($generalValues['locations_id'] ?? 0) === 0 ? ' selected' : '' ?>><?= glpiacessivel_e($generalLocationRequired ? $t('Selecione') : $t('Sem localização')) ?></option>
                      <?php foreach ($generalLocations as $location): ?>
                        <?php $locationId = (int) ($location['id'] ?? 0); ?>
                        <option value="<?= $locationId ?>"<?= (int) ($generalValues['locations_id'] ?? 0) === $locationId ? ' selected' : '' ?>><?= glpiacessivel_e((string) ($location['label'] ?? '')) ?></option>
                      <?php endforeach; ?>
                    </select>
                    <small id="general-location-help" class="glpiacessivel-help-text"><?= glpiacessivel_e($t('São exibidas apenas localizações permitidas para a entidade do chamado. Algumas regras exigem localização antes da solução ou do fechamento.')) ?></small>
                  </div>
                <?php endif; ?>

                <?php if ($generalCanEdit('requesttypes_id')): ?>
                  <div class="glpiacessivel-field-block">
                    <label for="general_request_source"><?= glpiacessivel_e($t('Origem da solicitação')) ?></label>
                    <select id="general_request_source" name="requesttypes_id" required aria-describedby="general-request-source-help" data-general-edit-field data-general-field-label="<?= glpiacessivel_e($t('Origem da solicitação')) ?>">
                      <?php foreach ($generalRequestSourceOptions as $option): ?>
                        <option value="<?= (int) ($option['id'] ?? 0) ?>"<?= (int) ($generalValues['requesttypes_id'] ?? 0) === (int) ($option['id'] ?? 0) ? ' selected' : '' ?>><?= glpiacessivel_e((string) ($option['label'] ?? '')) ?></option>
                      <?php endforeach; ?>
                    </select>
                    <small id="general-request-source-help" class="glpiacessivel-help-text"><?= glpiacessivel_e($t('Mantida conforme as origens autorizadas pelo GLPI.')) ?></small>
                  </div>
                <?php endif; ?>
              </div>
            </fieldset>
          <?php endif; ?>

          <?php if (array_intersect($generalEditableFields, ['urgency', 'impact', 'priority']) !== []): ?>
            <fieldset class="glpiacessivel-form-fieldset">
              <legend><?= glpiacessivel_e($t('Priorização')) ?></legend>
              <p class="glpiacessivel-help-text"><?= glpiacessivel_e($t('Urgência e impacto podem recalcular a prioridade pelas regras nativas. Somente campos permitidos pelo GLPI são apresentados.')) ?></p>
              <div class="glpiacessivel-form-grid">
                <?php foreach ([
                    'urgency' => [$t('Urgência'), $generalUrgencyOptions],
                    'impact' => [$t('Impacto'), $generalImpactOptions],
                    'priority' => [$t('Prioridade'), $generalPriorityOptions],
                ] as $priorityField => [$priorityLabel, $priorityOptions]): ?>
                  <?php if (!$generalCanEdit($priorityField)) { continue; } ?>
                  <div class="glpiacessivel-field-block">
                    <label for="general_<?= glpiacessivel_e($priorityField) ?>"><?= glpiacessivel_e($priorityLabel) ?></label>
                    <select id="general_<?= glpiacessivel_e($priorityField) ?>" name="<?= glpiacessivel_e($priorityField) ?>" required data-general-edit-field data-general-field-label="<?= glpiacessivel_e($priorityLabel) ?>">
                      <?php foreach ($priorityOptions as $option): ?>
                        <option value="<?= (int) ($option['id'] ?? 0) ?>"<?= (int) ($generalValues[$priorityField] ?? 0) === (int) ($option['id'] ?? 0) ? ' selected' : '' ?>><?= glpiacessivel_e((string) ($option['label'] ?? '')) ?></option>
                      <?php endforeach; ?>
                    </select>
                  </div>
                <?php endforeach; ?>
              </div>
            </fieldset>
          <?php endif; ?>

          <div class="glpiacessivel-field-block">
            <label for="general_update_reason"><?= glpiacessivel_e($t('Motivo da alteração')) ?> <span class="glpiacessivel-muted">(<?= glpiacessivel_e($t('opcional')) ?>)</span></label>
            <input id="general_update_reason" name="update_reason" type="text" maxlength="255" aria-describedby="general-update-reason-help" />
            <small id="general-update-reason-help" class="glpiacessivel-help-text"><?= glpiacessivel_e($t('Use este campo para contextualizar a alteração na auditoria do plugin.')) ?></small>
          </div>

          <div class="glpiacessivel-actions">
            <button type="submit" class="glpiacessivel-button glpiacessivel-button-primary"><?= glpiacessivel_e($t('Salvar dados do chamado')) ?></button>
          </div>
        </form>
        <script>
          (function () {
            var form = document.querySelector('[data-glpiacessivel-general-edit]');
            var status = document.getElementById('general-edit-status');
            if (form && status) {
              form.addEventListener('submit', function () {
                var confirmed = form.querySelector('input[name="critical_confirmed"]');
                if (confirmed && confirmed.value === '1') {
                  status.textContent = <?= json_encode($t('Enviando alterações para validação do GLPI.'), JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) ?>;
                }
              });
            }
            if (window.location.hash === '#editar-dados-chamado' && !document.querySelector('[data-glpiacessivel-focus-alert]')) {
              var heading = document.getElementById('editar-dados-chamado');
              if (heading) {
                window.setTimeout(function () { heading.focus(); }, 0);
              }
            }
          })();
        </script>
      <?php endif; ?>
    </section>
  <?php endif; ?>

  <section aria-labelledby="bloco-atores">
    <h3 id="bloco-atores"><?= glpiacessivel_e($t('Atores do chamado')) ?></h3>
    <div class="glpiacessivel-grid-3">
      <article class="glpiacessivel-note">
        <h4><?= glpiacessivel_e($t('Requerentes')) ?></h4>
        <ul class="glpiacessivel-list">
          <?php foreach (($ticket['actors']['requesters'] ?? []) as $actor): ?>
            <li><?= glpiacessivel_e((string) ($actor['name'] ?? '')) ?></li>
          <?php endforeach; ?>
          <?php if (empty($ticket['actors']['requesters'])): ?><li><?= glpiacessivel_e($t('Não informado')) ?></li><?php endif; ?>
        </ul>
      </article>
      <article class="glpiacessivel-note">
        <h4><?= glpiacessivel_e($t('Atribuídos')) ?></h4>
        <ul class="glpiacessivel-list">
          <?php foreach (($ticket['actors']['assignees'] ?? []) as $actor): ?>
            <li><?= glpiacessivel_e((string) ($actor['name'] ?? '')) ?></li>
          <?php endforeach; ?>
          <?php if (empty($ticket['actors']['assignees'])): ?><li><?= glpiacessivel_e($t('Não informado')) ?></li><?php endif; ?>
        </ul>
      </article>
      <article class="glpiacessivel-note">
        <h4><?= glpiacessivel_e($t('Observadores')) ?></h4>
        <ul class="glpiacessivel-list">
          <?php foreach (($ticket['actors']['watchers'] ?? []) as $actor): ?>
            <li><?= glpiacessivel_e((string) ($actor['name'] ?? '')) ?></li>
          <?php endforeach; ?>
          <?php if (empty($ticket['actors']['watchers'])): ?><li><?= glpiacessivel_e($t('Não informado')) ?></li><?php endif; ?>
        </ul>
      </article>
    </div>
  </section>

  <section aria-labelledby="bloco-requisitante">
    <h3 id="bloco-requisitante"><?= glpiacessivel_e($t('Requisitante')) ?></h3>
    <?php if ($piiMaskingEnabled): ?>
      <p class="glpiacessivel-muted"><?= glpiacessivel_e($t('Os contatos pessoais estão mascarados conforme a configuração do plugin.')) ?></p>
    <?php else: ?>
      <p class="glpiacessivel-muted"><?= glpiacessivel_e($t('Os contatos pessoais são exibidos conforme as permissões definidas no GLPI.')) ?></p>
    <?php endif; ?>
    <div class="glpiacessivel-definition-grid">
      <p><strong><?= glpiacessivel_e($t('Nome')) ?></strong><span><?= glpiacessivel_e($requesterName) ?></span></p>
      <?php foreach ([
        'requester_email' => $t('E-mail'),
        'requester_phone' => $t('Telefone'),
        'requester_mobile' => $t('Celular'),
      ] as $piiField => $piiLabel): ?>
        <?php
          $piiValue = trim((string) ($ticket[$piiField] ?? ''));
          $piiRevealed = isset($revealedPiiFields[$piiField]);
        ?>
        <p>
          <strong><?= glpiacessivel_e($piiLabel) ?></strong>
          <span>
            <?= glpiacessivel_e($piiValue !== '' ? $piiValue : $t('Não informado')) ?>
            <?php if ($piiMaskingEnabled && $piiValue !== ''): ?>
              <small>(<?= glpiacessivel_e($piiRevealed ? $t('revelado temporariamente') : $t('mascarado')) ?>)</small>
            <?php endif; ?>
          </span>
        </p>
      <?php endforeach; ?>
    </div>

    <?php if ($canRevealPii): ?>
      <form method="post" action="<?= glpiacessivel_e(glpiacessivel_url('front/ticket.action.php')) ?>" class="glpiacessivel-form glpiacessivel-pii-reveal-form">
        <input type="hidden" name="_glpi_csrf_token" value="<?= glpiacessivel_e($csrf_tokens['pii_reveal'] ?? $csrf_token) ?>" />
        <input type="hidden" name="ticket_id" value="<?= (int) $ticket['id'] ?>" />
        <input type="hidden" name="action" value="pii_reveal" />
        <fieldset>
          <legend><?= glpiacessivel_e($t('Revelar contato por 5 minutos')) ?></legend>
          <p id="pii-reveal-help" class="glpiacessivel-help-text"><?= glpiacessivel_e($t('A revelação exige permissão de atualização no chamado e fica registrada na auditoria.')) ?></p>
          <label for="pii_field"><?= glpiacessivel_e($t('Dado')) ?></label>
          <select id="pii_field" name="pii_field" required aria-describedby="pii-reveal-help">
            <option value=""><?= glpiacessivel_e($t('Selecione')) ?></option>
            <option value="requester_email"><?= glpiacessivel_e($t('E-mail')) ?></option>
            <option value="requester_phone"><?= glpiacessivel_e($t('Telefone')) ?></option>
            <option value="requester_mobile"><?= glpiacessivel_e($t('Celular')) ?></option>
          </select>
          <label for="pii_reason"><?= glpiacessivel_e($t('Motivo da consulta')) ?></label>
          <input id="pii_reason" name="pii_reason" type="text" maxlength="255" required aria-describedby="pii-reveal-help" />
          <button type="submit"><?= glpiacessivel_e($t('Revelar dado selecionado')) ?></button>
        </fieldset>
      </form>
    <?php endif; ?>
  </section>

  <?php if ($canRoute): ?>
    <section aria-labelledby="roteamento-ticket" class="glpiacessivel-routing-panel">
      <h3 id="roteamento-ticket" tabindex="-1"><?= glpiacessivel_e($t('Atores, atribuição e escalonamento')) ?></h3>
      <p class="glpiacessivel-muted"><?= glpiacessivel_e($t('Atualize requerentes, responsáveis e observadores autorizados pelo GLPI. Fornecedores aparecem somente como atribuídos ao atendimento.')) ?></p>
      <?php if (!$routingFormReady): ?>
        <div class="glpiacessivel-alert glpiacessivel-alert-warning" role="alert">
          <strong><?= glpiacessivel_e($t('A atribuição atual não pôde ser conferida.')) ?></strong>
          <p><?= glpiacessivel_e($t('Nenhuma alteração será enviada para evitar a remoção involuntária de responsáveis ou observadores.')) ?></p>
          <div class="glpiacessivel-actions">
            <a class="glpiacessivel-button glpiacessivel-button-secondary" href="<?= glpiacessivel_e(glpiacessivel_url('front/tickets.php?id=' . (int) $ticket['id'])) ?>"><?= glpiacessivel_e($t('Tentar novamente')) ?></a>
          </div>
        </div>
      <?php else: ?>
      <form
        method="post"
        action="<?= glpiacessivel_e(glpiacessivel_url('front/ticket.action.php')) ?>"
        class="glpiacessivel-routing-form"
        data-glpiacessivel-critical-form
        data-critical-title="<?= glpiacessivel_e($t('Confirmar atualização da atribuição')) ?>"
        data-critical-message="<?= glpiacessivel_e(sprintf($t('Revise requerentes, responsáveis e observadores do chamado #%d antes de continuar.'), (int) $ticket['id'])) ?>"
        data-critical-consequence="<?= glpiacessivel_e($t('Esta ação altera quem solicita, atende e acompanha o chamado no GLPI.')) ?>"
        data-routing-changes-prefix="<?= glpiacessivel_e($t('Alterações selecionadas')) ?>"
        data-routing-add-label="<?= glpiacessivel_e($t('adicionar')) ?>"
        data-routing-remove-label="<?= glpiacessivel_e($t('remover')) ?>"
        data-routing-no-changes="<?= glpiacessivel_e($t('Nenhuma alteração de atores foi selecionada.')) ?>"
        <?php if ($resourceSelectorEnabled): ?>
          data-resource-selector-url="<?= glpiacessivel_e(glpiacessivel_url('front/ticket.resource-selector.php')) ?>"
          data-resource-selector-csrf="<?= glpiacessivel_e($csrf_tokens['routing'] ?? $csrf_token) ?>"
          data-resource-selector-context-revision="<?= glpiacessivel_e((string) ($resourceSelectorConfig['context_revision'] ?? '')) ?>"
          data-resource-selector-version="1"
          data-resource-selector-timeout="<?= max(500, min(5000, (int) ($resourceSelectorConfig['timeout_ms'] ?? 5000))) ?>"
          data-resource-selector-limit="<?= max(1, min(20, (int) ($resourceSelectorConfig['page_size'] ?? 20))) ?>"
          data-resource-selector-fallback-url="<?= glpiacessivel_e(glpiacessivel_url('front/tickets.php?id=' . (int) $ticket['id'] . '#roteamento-ticket')) ?>"
          data-resource-selector-error-summary="#routing-selector-errors"
        <?php endif; ?>
      >
        <input type="hidden" name="_glpi_csrf_token" value="<?= glpiacessivel_e($csrf_tokens['routing'] ?? $csrf_token) ?>" />
        <input id="routing_ticket_id" type="hidden" name="ticket_id" value="<?= (int) $ticket['id'] ?>" />
        <input type="hidden" name="action" value="routing" />
        <input type="hidden" name="routing_revision" value="<?= glpiacessivel_e($routingRevision) ?>" />
        <input type="hidden" name="critical_confirmed" value="0" />
        <input type="hidden" name="critical_confirmation_token" value="<?= glpiacessivel_e((string) ($criticalConfirmations['routing'] ?? '')) ?>" />
        <?php if ($resourceSelectorEnabled): ?>
          <div id="routing-selector-errors" class="glpiacessivel-alert glpiacessivel-alert-error" role="alert" tabindex="-1" hidden>
            <strong><?= glpiacessivel_e($t('Revise os atores selecionados.')) ?></strong>
            <ul class="glpiacessivel-error-list"></ul>
          </div>
        <?php endif; ?>
        <div class="glpiacessivel-routing-grid">
          <?php if ($canAdminRequesters): ?>
          <div class="glpiacessivel-field-block">
            <label for="routing_requesters"><?= glpiacessivel_e($t('Pessoas requerentes')) ?></label>
            <input type="hidden" name="_users_id_requester[]" value="0" />
            <select id="routing_requesters" name="_users_id_requester[]" multiple size="6" aria-describedby="routing_requesters_help" data-routing-role-label="<?= glpiacessivel_e($t('Pessoas requerentes')) ?>"<?= $resourceSelectorEnabled ? ' data-glpiacessivel-resource-select data-resource-provider="requester_user" data-resource-min-chars="2" data-resource-dependencies="ticket_id:#routing_ticket_id"' : '' ?>>
              <?php foreach ($requesterUsers as $user): ?>
                <?php $id = (int) ($user['id'] ?? 0); ?>
                <option value="<?= $id ?>" <?= in_array($id, $requesterUserIds, true) ? 'selected' : '' ?>><?= glpiacessivel_e((string) ($user['label'] ?? '')) ?></option>
              <?php endforeach; ?>
            </select>
            <small id="routing_requesters_help" class="glpiacessivel-help-text"><?= glpiacessivel_e($t('Selecione as pessoas em nome das quais o atendimento foi solicitado. Os requerentes por e-mail sem usuário cadastrado são preservados pelo servidor.')) ?></small>
          </div>
          <div class="glpiacessivel-field-block">
            <label for="routing_requester_groups"><?= glpiacessivel_e($t('Grupos requerentes')) ?></label>
            <input type="hidden" name="_groups_id_requester[]" value="0" />
            <select id="routing_requester_groups" name="_groups_id_requester[]" multiple size="6" aria-describedby="routing_requester_groups_help" data-routing-role-label="<?= glpiacessivel_e($t('Grupos requerentes')) ?>"<?= $resourceSelectorEnabled ? ' data-glpiacessivel-resource-select data-resource-provider="requester_group" data-resource-min-chars="2" data-resource-dependencies="ticket_id:#routing_ticket_id"' : '' ?>>
              <?php foreach ($requesterGroups as $group): ?>
                <?php $id = (int) ($group['id'] ?? 0); ?>
                <option value="<?= $id ?>" <?= in_array($id, $requesterGroupIds, true) ? 'selected' : '' ?>><?= glpiacessivel_e((string) ($group['label'] ?? '')) ?></option>
              <?php endforeach; ?>
            </select>
            <small id="routing_requester_groups_help" class="glpiacessivel-help-text"><?= glpiacessivel_e($t('Selecione os grupos que representam os requerentes deste chamado.')) ?></small>
          </div>
          <?php endif; ?>
          <?php if ($canAssignActors): ?>
          <div class="glpiacessivel-field-block">
            <label for="routing_groups"><?= glpiacessivel_e($t('Grupos técnicos responsáveis')) ?></label>
            <input type="hidden" name="_groups_id_assign[]" value="0" />
            <select id="routing_groups" name="_groups_id_assign[]" multiple size="6" aria-describedby="routing_groups_help" data-routing-role-label="<?= glpiacessivel_e($t('Grupos técnicos responsáveis')) ?>"<?= $resourceSelectorEnabled ? ' data-glpiacessivel-resource-select data-resource-provider="assigned_group" data-resource-min-chars="2" data-resource-dependencies="ticket_id:#routing_ticket_id"' : '' ?>>
              <?php foreach ($assignableGroups as $group): ?>
                <?php $id = (int) ($group['id'] ?? 0); ?>
                <option value="<?= $id ?>" <?= in_array($id, $assignedGroupIds, true) ? 'selected' : '' ?>><?= glpiacessivel_e((string) ($group['label'] ?? '')) ?></option>
              <?php endforeach; ?>
            </select>
            <small id="routing_groups_help" class="glpiacessivel-help-text"><?= glpiacessivel_e($t('Selecione um ou mais grupos responsáveis. Em listas múltiplas, use Ctrl (ou Command no macOS) para manter mais de uma seleção.')) ?></small>
          </div>
          <div class="glpiacessivel-field-block">
            <label for="routing_users"><?= glpiacessivel_e($t('Técnicos atribuídos')) ?></label>
            <input type="hidden" name="_users_id_assign[]" value="0" />
            <select id="routing_users" name="_users_id_assign[]" multiple size="6" aria-describedby="routing_users_help" data-routing-role-label="<?= glpiacessivel_e($t('Técnicos atribuídos')) ?>"<?= $resourceSelectorEnabled ? ' data-glpiacessivel-resource-select data-resource-provider="assigned_user" data-resource-min-chars="2" data-resource-dependencies="ticket_id:#routing_ticket_id"' : '' ?>>
              <?php foreach ($assignableUsers as $user): ?>
                <?php $id = (int) ($user['id'] ?? 0); ?>
                <option value="<?= $id ?>" <?= in_array($id, $assignedUserIds, true) ? 'selected' : '' ?>><?= glpiacessivel_e((string) ($user['label'] ?? '')) ?></option>
              <?php endforeach; ?>
            </select>
            <small id="routing_users_help" class="glpiacessivel-help-text"><?= glpiacessivel_e($t('Selecione uma ou mais pessoas responsáveis pelo atendimento.')) ?></small>
          </div>
          <div class="glpiacessivel-field-block">
            <label for="routing_suppliers"><?= glpiacessivel_e($t('Fornecedores atribuídos')) ?></label>
            <input type="hidden" name="_suppliers_id_assign[]" value="0" />
            <select id="routing_suppliers" name="_suppliers_id_assign[]" multiple size="6" aria-describedby="routing_suppliers_help" data-routing-role-label="<?= glpiacessivel_e($t('Fornecedores atribuídos')) ?>"<?= $resourceSelectorEnabled ? ' data-glpiacessivel-resource-select data-resource-provider="assigned_supplier" data-resource-min-chars="2" data-resource-dependencies="ticket_id:#routing_ticket_id"' : '' ?>>
              <?php foreach ($assignableSuppliers as $supplier): ?>
                <?php $id = (int) ($supplier['id'] ?? 0); ?>
                <option value="<?= $id ?>" <?= in_array($id, $assignedSupplierIds, true) ? 'selected' : '' ?>><?= glpiacessivel_e((string) ($supplier['label'] ?? '')) ?></option>
              <?php endforeach; ?>
            </select>
            <small id="routing_suppliers_help" class="glpiacessivel-help-text"><?= glpiacessivel_e($t('Selecione fornecedores responsáveis pelo atendimento. Fornecedores não podem ser requerentes nem observadores.')) ?></small>
          </div>
          <?php endif; ?>
          <?php if ($canObserveActors): ?>
          <div class="glpiacessivel-field-block">
            <label for="routing_watchers"><?= glpiacessivel_e($t('Pessoas observadoras')) ?></label>
            <input type="hidden" name="_users_id_observer[]" value="0" />
            <select id="routing_watchers" name="_users_id_observer[]" multiple size="6" aria-describedby="routing_watchers_help" data-routing-role-label="<?= glpiacessivel_e($t('Pessoas observadoras')) ?>"<?= $resourceSelectorEnabled ? ' data-glpiacessivel-resource-select data-resource-provider="observer_user" data-resource-min-chars="2" data-resource-dependencies="ticket_id:#routing_ticket_id"' : '' ?>>
              <?php foreach ($observerUsers as $user): ?>
                <?php $id = (int) ($user['id'] ?? 0); ?>
                <option value="<?= $id ?>" <?= in_array($id, $observerUserIds, true) ? 'selected' : '' ?>><?= glpiacessivel_e((string) ($user['label'] ?? '')) ?></option>
              <?php endforeach; ?>
            </select>
            <small id="routing_watchers_help" class="glpiacessivel-help-text"><?= glpiacessivel_e($t('Selecione as pessoas que devem acompanhar o chamado sem assumir o atendimento.')) ?></small>
          </div>
          <div class="glpiacessivel-field-block">
            <label for="routing_observer_groups"><?= glpiacessivel_e($t('Grupos observadores')) ?></label>
            <input type="hidden" name="_groups_id_observer[]" value="0" />
            <select id="routing_observer_groups" name="_groups_id_observer[]" multiple size="6" aria-describedby="routing_observer_groups_help" data-routing-role-label="<?= glpiacessivel_e($t('Grupos observadores')) ?>"<?= $resourceSelectorEnabled ? ' data-glpiacessivel-resource-select data-resource-provider="observer_group" data-resource-min-chars="2" data-resource-dependencies="ticket_id:#routing_ticket_id"' : '' ?>>
              <?php foreach ($observerGroups as $group): ?>
                <?php $id = (int) ($group['id'] ?? 0); ?>
                <option value="<?= $id ?>" <?= in_array($id, $observerGroupIds, true) ? 'selected' : '' ?>><?= glpiacessivel_e((string) ($group['label'] ?? '')) ?></option>
              <?php endforeach; ?>
            </select>
            <small id="routing_observer_groups_help" class="glpiacessivel-help-text"><?= glpiacessivel_e($t('Selecione os grupos cujos integrantes devem acompanhar o chamado sem assumir o atendimento. É possível escolher mais de um grupo.')) ?></small>
          </div>
          <?php endif; ?>
        </div>
        <label for="routing_reason"><?= glpiacessivel_e($t('Motivo da atualização dos atores')) ?></label>
        <input id="routing_reason" type="text" name="routing_reason" maxlength="255" placeholder="<?= glpiacessivel_e($t('Ex.: correção do requerente ou direcionamento para a equipe responsável')) ?>" />
        <button type="submit" class="glpiacessivel-button glpiacessivel-button-secondary"><?= glpiacessivel_e($t('Atualizar atores do chamado')) ?></button>
      </form>
      <script>
        (function () {
          var form = document.querySelector('.glpiacessivel-routing-form');
          if (!form) {
            return;
          }
          var baseMessage = String(form.dataset.criticalMessage || '').trim();
          var controls = Array.prototype.slice.call(form.querySelectorAll('[data-routing-role-label]'));
          var initial = controls.map(function (control) {
            var items = {};
            Array.prototype.slice.call(control.selectedOptions || []).forEach(function (option) {
              items[String(option.value)] = String(option.textContent || '').trim();
            });
            return items;
          });

          function selectedItems(control) {
            var items = {};
            Array.prototype.slice.call(control.selectedOptions || []).forEach(function (option) {
              items[String(option.value)] = String(option.textContent || '').trim();
            });
            return items;
          }

          function difference(source, target) {
            return Object.keys(source).filter(function (id) {
              return !Object.prototype.hasOwnProperty.call(target, id);
            }).map(function (id) {
              return source[id] || ('#' + id);
            });
          }

          function updateCriticalMessage() {
            var changes = [];
            controls.forEach(function (control, index) {
              var current = selectedItems(control);
              var added = difference(current, initial[index]);
              var removed = difference(initial[index], current);
              var actions = [];
              if (added.length > 0) {
                actions.push(String(form.dataset.routingAddLabel || '') + ' ' + added.join(', '));
              }
              if (removed.length > 0) {
                actions.push(String(form.dataset.routingRemoveLabel || '') + ' ' + removed.join(', '));
              }
              if (actions.length > 0) {
                changes.push(String(control.dataset.routingRoleLabel || '') + ': ' + actions.join('; '));
              }
            });
            form.dataset.criticalMessage = changes.length > 0
              ? baseMessage + ' ' + String(form.dataset.routingChangesPrefix || '') + ': ' + changes.join('. ') + '.'
              : baseMessage + ' ' + String(form.dataset.routingNoChanges || '');
          }

          controls.forEach(function (control) {
            control.addEventListener('change', updateCriticalMessage);
          });
          form.addEventListener('submit', updateCriticalMessage);
          updateCriticalMessage();
          if (window.location.hash === '#roteamento-ticket' && !document.querySelector('[data-glpiacessivel-focus-alert]')) {
            var routingHeading = document.getElementById('roteamento-ticket');
            if (routingHeading) {
              window.setTimeout(function () { routingHeading.focus(); }, 0);
            }
          }
        })();
      </script>
      <?php endif; ?>
    </section>
  <?php endif; ?>

  <?php if ($resourceSelectorEnabled || $generalResourceSelectorEnabled): ?>
    <script src="<?= glpiacessivel_e($resourceSelectorAssetUrl) ?>"></script>
  <?php endif; ?>

  <section aria-labelledby="descricao-ticket">
    <h3 id="descricao-ticket"><?= glpiacessivel_e($t('Descrição')) ?></h3>
    <article class="glpiacessivel-content"><?= \GlpiPlugin\Glpiacessivel\Support\RichTextFormatter::toHtml((string) $ticket['content']) ?></article>
  </section>

  <section aria-labelledby="documentos-ticket">
    <h3 id="documentos-ticket"><?= glpiacessivel_e($t('Documentos e anexos')) ?></h3>
    <?php if (empty($ticket['documents'])): ?>
      <p class="glpiacessivel-empty"><?= glpiacessivel_e($t('Nenhum documento vinculado.')) ?></p>
    <?php else: ?>
      <?php $renderDocuments((array) $ticket['documents'], $t('Chamado')); ?>
    <?php endif; ?>
  </section>
</section>

<section class="glpiacessivel-card glpiacessivel-itil-actions" aria-labelledby="acoes-ticket">
  <div class="glpiacessivel-itil-actions-head">
    <div>
      <p class="glpiacessivel-eyebrow"><?= glpiacessivel_e($t('Processamento do chamado')) ?></p>
      <h2 id="acoes-ticket"><?= glpiacessivel_e($t('Interações e ações do chamado')) ?></h2>
      <p class="glpiacessivel-muted"><?= glpiacessivel_e($t('Use as etapas do chamado: acompanhamento, tarefa, solução e status. As permissões e transições continuam validadas pelo GLPI.')) ?></p>
    </div>
    <span class="glpiacessivel-meta-chip"><?= glpiacessivel_e($t('Chamado')) ?> #<?= (int) $ticket['id'] ?></span>
  </div>

  <?php if ($isSolved): ?>
    <article class="glpiacessivel-itil-secondary-form" aria-labelledby="decisao-solucao">
      <div>
        <h3 id="decisao-solucao" tabindex="-1"><?= glpiacessivel_e($t('Decisão sobre a solução')) ?></h3>
        <p class="glpiacessivel-help-text"><?= glpiacessivel_e($t('O chamado está solucionado. Você pode aprovar a solução e fechar o chamado ou recusá-la e reabrir o atendimento.')) ?></p>
      </div>
      <?php if ($canDecideSolution): ?>
        <form method="post" action="<?= glpiacessivel_e(glpiacessivel_url('front/ticket.action.php')) ?>" enctype="multipart/form-data" class="glpiacessivel-itil-action-form" data-glpiacessivel-critical-form data-glpiacessivel-solution-decision-form data-critical-kind="solution-decision" data-critical-suppress-open-announcement>
          <input type="hidden" name="_glpi_csrf_token" value="<?= glpiacessivel_e($csrf_tokens['solution_decision'] ?? $csrf_token) ?>" />
          <input type="hidden" name="ticket_id" value="<?= (int) $ticket['id'] ?>" />
          <input type="hidden" name="solution_decision_revision" value="<?= glpiacessivel_e($solutionDecisionRevision) ?>" />
          <input type="hidden" name="solution_decision_operation_id" value="<?= glpiacessivel_e($solutionDecisionOperationId) ?>" />
          <input type="hidden" name="critical_confirmed" value="0" />
          <input type="hidden" name="critical_confirmation_token" value="" />
          <label for="solution_decision_comment"><?= glpiacessivel_e($t('Comentário sobre a decisão')) ?></label>
          <textarea id="solution_decision_comment" name="content" maxlength="16000" aria-describedby="solution-decision-help solution-decision-comment-error" data-critical-summary-label="<?= glpiacessivel_e($t('Comentário sobre a decisão')) ?>"></textarea>
          <small id="solution-decision-help" class="glpiacessivel-help-text"><?= glpiacessivel_e($t('Opcional ao aprovar. Obrigatório ao recusar a solução.')) ?></small>
          <p id="solution-decision-comment-error" class="glpiacessivel-form-error" role="alert" hidden><?= glpiacessivel_e($t('Informe o motivo da recusa da solução.')) ?></p>
          <div class="glpiacessivel-field glpiacessivel-file-picker" data-glpiacessivel-file-picker>
            <label for="solution_decision_filename"><?= glpiacessivel_e($t('Anexos à decisão (opcional)')) ?></label>
            <input
              id="solution_decision_filename"
              type="file"
              name="solution_decision_filename[]"
              multiple
              aria-describedby="solution-decision-files-help solution-decision-files-status"
              data-glpiacessivel-file-input
              data-critical-summary-label="<?= glpiacessivel_e($t('Anexos à decisão')) ?>"
            />
            <small id="solution-decision-files-help" class="glpiacessivel-help-text"><?= glpiacessivel_e($t('Os arquivos serão vinculados ao acompanhamento da decisão. O GLPI validará tipo, tamanho e permissão.')) ?></small>
            <div class="glpiacessivel-file-actions">
              <button type="button" class="glpiacessivel-button glpiacessivel-button-secondary" aria-controls="solution-decision-files-list" data-glpiacessivel-file-clear hidden><?= glpiacessivel_e($t('Limpar anexos')) ?></button>
            </div>
            <p id="solution-decision-files-status" class="glpiacessivel-sr-only" aria-live="polite" aria-atomic="true"></p>
            <ul id="solution-decision-files-list" class="glpiacessivel-file-list" data-glpiacessivel-file-list></ul>
          </div>
          <div class="glpiacessivel-itil-form-footer">
            <button type="submit" name="action" value="solution_refuse" class="glpiacessivel-button glpiacessivel-button-secondary" data-solution-decision="refuse" data-critical-confirmation-token="<?= glpiacessivel_e((string) ($criticalConfirmations['solution_refuse'] ?? '')) ?>" data-critical-title="<?= glpiacessivel_e($t('Confirmar recusa da solução')) ?>" data-critical-message="<?= glpiacessivel_e($t('Revise o motivo e os anexos antes de recusar a solução.')) ?>" data-critical-consequence="<?= glpiacessivel_e($t('O GLPI reabrirá o atendimento e registrará o motivo informado.')) ?>" data-critical-confirm-label="<?= glpiacessivel_e($t('Recusar e reabrir')) ?>"><?= glpiacessivel_e($t('Recusar solução')) ?></button>
            <button type="submit" name="action" value="solution_approve" class="glpiacessivel-button glpiacessivel-button-primary" data-solution-decision="approve" data-critical-confirmation-token="<?= glpiacessivel_e((string) ($criticalConfirmations['solution_approve'] ?? '')) ?>" data-critical-title="<?= glpiacessivel_e($t('Confirmar aprovação da solução')) ?>" data-critical-message="<?= glpiacessivel_e($t('Revise o comentário e os anexos antes de aprovar a solução.')) ?>" data-critical-consequence="<?= glpiacessivel_e($t('O GLPI fechará o chamado e registrará a solução como aceita.')) ?>" data-critical-confirm-label="<?= glpiacessivel_e($t('Aprovar solução')) ?>"><?= glpiacessivel_e($t('Aprovar solução')) ?></button>
          </div>
        </form>
      <?php else: ?>
        <?php
          $solutionDecisionMessage = match ($solutionDecisionState) {
              'not_approver' => $t('Seu perfil e sua relação com este chamado não permitem aprovar ou recusar esta solução no GLPI.'),
              'followup_denied' => $t('Seu perfil não permite registrar o acompanhamento exigido pelo GLPI para esta decisão.'),
              'transition_denied' => $t('O GLPI não permite fechar este chamado a partir do estado atual.'),
              'in_progress' => $t('Outra decisão sobre esta solução está em andamento. Atualize o chamado para consultar o resultado.'),
              default => $t('A decisão sobre esta solução não está disponível no estado atual do GLPI.'),
          };
        ?>
        <p class="glpiacessivel-empty"><?= glpiacessivel_e($solutionDecisionMessage) ?></p>
      <?php endif; ?>
    </article>
  <?php elseif ($isClosed): ?>
    <article class="glpiacessivel-itil-secondary-form" aria-labelledby="chamado-fechado">
      <h3 id="chamado-fechado" tabindex="-1"><?= glpiacessivel_e($t('Chamado fechado')) ?></h3>
      <p class="glpiacessivel-help-text"><?= glpiacessivel_e($t('O chamado está fechado. O GLPI não permite novas ações nesta etapa.')) ?></p>
    </article>
  <?php else: ?>
  <?php if ($solutionOperationState === 'partial'): ?>
    <?php
      $solutionObservedStatus = glpiacessivel_ticket_status(
          (int) ($solutionOperation['ticket_status'] ?? $ticketStatus)
      );
      $solutionOperationId = max(0, (int) ($solutionOperation['solution_id'] ?? 0));
    ?>
    <article
      id="solution-operation-state"
      class="glpiacessivel-itil-secondary-form"
      role="region"
      aria-labelledby="solution-operation-state-title"
      tabindex="-1"
    >
      <div>
        <h3 id="solution-operation-state-title"><?= glpiacessivel_e(sprintf($t('Solução registrada; chamado continua %s'), $solutionObservedStatus)) ?></h3>
        <p class="glpiacessivel-help-text"><?= glpiacessivel_e(sprintf(
            $t('O GLPI possui uma solução para este chamado, mas o estado atual ainda é %s. Não envie outra solução, pois isso criaria duplicidade.'),
            $solutionObservedStatus
        )) ?></p>
        <?php if ($solutionOperationId > 0): ?>
          <p class="glpiacessivel-help-text"><?= glpiacessivel_e(sprintf($t('Solução registrada: #%d.'), $solutionOperationId)) ?></p>
        <?php endif; ?>
      </div>
      <a class="glpiacessivel-button glpiacessivel-button-secondary" href="<?= glpiacessivel_e(glpiacessivel_url('front/tickets.php?id=' . (int) $ticket['id'])) ?>#solution-operation-state"><?= glpiacessivel_e($t('Atualizar e verificar estado')) ?></a>
    </article>
    <script>
      (function () {
        if (window.location.hash !== '#solution-operation-state' || document.querySelector('[data-glpiacessivel-focus-alert]')) {
          return;
        }
        var state = document.getElementById('solution-operation-state');
        if (state) {
          window.requestAnimationFrame(function () { state.focus(); });
        }
      })();
    </script>
  <?php endif; ?>
  <?php if ($itilTabs !== []): ?>
  <div class="glpiacessivel-itil-action-switcher" role="tablist" aria-label="<?= glpiacessivel_e($t('Escolha a ação do chamado')) ?>">
    <?php foreach ($itilTabs as $index => $tab): ?>
      <?php
        $tabKey = (string) ($tab['key'] ?? '');
        $isActiveTab = $index === 0;
      ?>
      <button
        type="button"
        id="itil-tab-<?= glpiacessivel_e($tabKey) ?>"
        class="glpiacessivel-itil-action-tab <?= $isActiveTab ? 'is-active' : '' ?>"
        role="tab"
        aria-selected="<?= $isActiveTab ? 'true' : 'false' ?>"
        aria-controls="itil-panel-<?= glpiacessivel_e($tabKey) ?>"
        tabindex="<?= $isActiveTab ? '0' : '-1' ?>"
        data-glpiacessivel-itil-tab="<?= glpiacessivel_e($tabKey) ?>"
      >
        <span aria-hidden="true"><?= $tabKey === 'followup' ? '+' : ($tabKey === 'task' ? 'OK' : '!') ?></span>
        <strong><?= glpiacessivel_e((string) ($tab['label'] ?? '')) ?></strong>
        <small><?= glpiacessivel_e((string) ($tab['hint'] ?? '')) ?></small>
      </button>
    <?php endforeach; ?>
  </div>

  <div class="glpiacessivel-itil-panel-stack">
    <?php if ($canAddFollowup): ?>
    <section id="itil-panel-followup" class="glpiacessivel-itil-panel" role="tabpanel" tabindex="0" aria-labelledby="itil-tab-followup" <?= $activeItilTab === 'followup' ? '' : 'hidden' ?>>
      <form method="post" action="<?= glpiacessivel_e(glpiacessivel_url('front/ticket.action.php')) ?>" enctype="multipart/form-data" class="glpiacessivel-itil-action-form">
        <input type="hidden" name="_glpi_csrf_token" value="<?= glpiacessivel_e($csrf_tokens['followup'] ?? $csrf_token) ?>" />
        <input type="hidden" name="ticket_id" value="<?= (int) $ticket['id'] ?>" />
        <input type="hidden" name="action" value="followup" />
        <input id="applied_followup_template_id" type="hidden" name="itilfollowuptemplates_id" value="0" />
        <div class="glpiacessivel-itil-panel-head">
          <div>
            <h3><?= glpiacessivel_e($t('Acompanhamento')) ?></h3>
            <p><?= glpiacessivel_e($t('Registre uma resposta ou atualização na linha do tempo do chamado, como no botão Responder do GLPI.')) ?></p>
          </div>
        </div>
        <div class="glpiacessivel-followup-template-box">
          <div class="glpiacessivel-followup-template-grid">
            <div>
              <label for="itilfollowuptemplates_id"><?= glpiacessivel_e($t('Modelo de acompanhamento')) ?></label>
              <select id="itilfollowuptemplates_id" aria-describedby="followup-template-help followup-template-status">
                <option value="0"><?= glpiacessivel_e($t('Sem modelo')) ?></option>
                <?php foreach ($followupTemplates as $template): ?>
                  <option value="<?= (int) ($template['id'] ?? 0) ?>"><?= glpiacessivel_e((string) ($template['name'] ?? '')) ?></option>
                <?php endforeach; ?>
                <?php if (empty($followupTemplates)): ?>
                  <option value="0" disabled><?= glpiacessivel_e($t('Nenhum modelo disponível para este perfil e entidade')) ?></option>
                <?php endif; ?>
              </select>
            </div>
            <button type="button" class="glpiacessivel-button glpiacessivel-button-secondary" data-glpiacessivel-apply-itil-template="followup" aria-describedby="followup-template-status" disabled><?= glpiacessivel_e($t('Aplicar modelo')) ?></button>
          </div>
          <small id="followup-template-help" class="glpiacessivel-help-text"><?= glpiacessivel_e($t('Opcional. O GLPI preenche o conteúdo do modelo conforme o chamado atual.')) ?></small>
          <p id="followup-template-status" class="glpiacessivel-resource-selector-status" role="status" aria-live="polite" aria-atomic="true"></p>
        </div>
        <?php if ($canAddPrivateFollowup): ?>
        <fieldset
          class="glpiacessivel-visibility-fieldset"
          data-glpiacessivel-visibility
          data-public-label="<?= glpiacessivel_e(__('Adicionar resposta pública', 'glpiacessivel')) ?>"
          data-private-label="<?= glpiacessivel_e(__('Adicionar nota interna', 'glpiacessivel')) ?>"
          aria-describedby="followup-visibility-help"
        >
          <legend><?= glpiacessivel_e(__('Visibilidade do acompanhamento', 'glpiacessivel')) ?></legend>
          <div class="glpiacessivel-visibility-options">
            <label class="glpiacessivel-visibility-option" for="followup-visibility-public">
              <input id="followup-visibility-public" type="radio" name="followup_is_private" value="0" required <?= !$defaultFollowupIsPrivate ? 'checked' : '' ?> aria-describedby="followup-visibility-public-help" />
              <span>
                <strong><?= glpiacessivel_e(__('Resposta pública', 'glpiacessivel')) ?></strong>
                <small id="followup-visibility-public-help"><?= glpiacessivel_e(__('Visível ao solicitante e aos participantes autorizados no chamado.', 'glpiacessivel')) ?></small>
              </span>
            </label>
            <label class="glpiacessivel-visibility-option" for="followup-visibility-private">
              <input id="followup-visibility-private" type="radio" name="followup_is_private" value="1" required <?= $defaultFollowupIsPrivate ? 'checked' : '' ?> aria-describedby="followup-visibility-private-help" />
              <span>
                <strong><?= glpiacessivel_e(__('Nota interna privada', 'glpiacessivel')) ?></strong>
                <small id="followup-visibility-private-help"><?= glpiacessivel_e(__('Visível somente aos usuários autorizados a consultar itens privados.', 'glpiacessivel')) ?></small>
              </span>
            </label>
          </div>
          <small id="followup-visibility-help" class="glpiacessivel-help-text"><?= glpiacessivel_e(__('A opção inicial acompanha sua preferência atual no GLPI. Os documentos anexados terão a mesma visibilidade.', 'glpiacessivel')) ?></small>
        </fieldset>
        <?php else: ?>
          <input type="hidden" name="followup_is_private" value="0" />
          <p class="glpiacessivel-help-text"><?= glpiacessivel_e(__('Este acompanhamento será público para os participantes autorizados no chamado.', 'glpiacessivel')) ?></p>
        <?php endif; ?>
        <label for="followup"><?= glpiacessivel_e($t('Descrição do acompanhamento')) ?> *</label>
        <textarea id="followup" name="content" required aria-describedby="followup-help"></textarea>
        <small id="followup-help" class="glpiacessivel-help-text"><?= glpiacessivel_e($t('Exemplo: contato realizado, retorno do usuário, diagnóstico parcial ou nova informação.')) ?></small>
        <div class="glpiacessivel-field glpiacessivel-file-picker" data-glpiacessivel-file-picker>
          <label for="followup_filename"><?= glpiacessivel_e(__('Documentos', 'glpiacessivel')) ?></label>
          <input
            id="followup_filename"
            type="file"
            name="followup_filename[]"
            multiple
            aria-describedby="followup-filename-help followup-filename-status"
            data-glpiacessivel-file-input
          />
          <small id="followup-filename-help" class="glpiacessivel-help-text"><?= glpiacessivel_e($attachmentHelp) ?></small>
          <div class="glpiacessivel-file-actions">
            <button
              type="button"
              class="glpiacessivel-button glpiacessivel-button-secondary"
              aria-controls="followup-filename-list"
              data-glpiacessivel-file-clear
              hidden
            ><?= glpiacessivel_e(__('Limpar anexos', 'glpiacessivel')) ?></button>
          </div>
          <p id="followup-filename-status" class="glpiacessivel-sr-only" aria-live="polite" aria-atomic="true"></p>
          <ul id="followup-filename-list" class="glpiacessivel-file-list" data-glpiacessivel-file-list></ul>
        </div>
        <div class="glpiacessivel-itil-form-footer">
          <button type="submit" class="glpiacessivel-button glpiacessivel-button-primary" data-glpiacessivel-visibility-submit><?= glpiacessivel_e(__('Adicionar resposta pública', 'glpiacessivel')) ?></button>
        </div>
      </form>
    </section>
    <?php endif; ?>

    <?php if ($canAddTask): ?>
    <section id="itil-panel-task" class="glpiacessivel-itil-panel" role="tabpanel" tabindex="0" aria-labelledby="itil-tab-task" <?= $activeItilTab === 'task' ? '' : 'hidden' ?>>
      <form
        method="post"
        action="<?= glpiacessivel_e(glpiacessivel_url('front/ticket.action.php')) ?>"
        enctype="multipart/form-data"
        class="glpiacessivel-itil-action-form"
        <?php if ($resourceSelectorEnabled): ?>
          data-resource-selector-url="<?= glpiacessivel_e(glpiacessivel_url('front/ticket.resource-selector.php')) ?>"
          data-resource-selector-csrf="<?= glpiacessivel_e($csrf_tokens['task'] ?? $csrf_token) ?>"
          data-resource-selector-context-revision="<?= glpiacessivel_e((string) ($resourceSelectorConfig['context_revision'] ?? '')) ?>"
          data-resource-selector-version="1"
          data-resource-selector-timeout="<?= max(500, min(5000, (int) ($resourceSelectorConfig['timeout_ms'] ?? 5000))) ?>"
          data-resource-selector-limit="<?= max(1, min(20, (int) ($resourceSelectorConfig['page_size'] ?? 20))) ?>"
          data-resource-selector-fallback-url="<?= glpiacessivel_e(glpiacessivel_url('front/tickets.php?id=' . (int) $ticket['id'])) ?>"
          data-resource-selector-error-summary="#task-selector-errors"
        <?php endif; ?>
      >
        <input type="hidden" name="_glpi_csrf_token" value="<?= glpiacessivel_e($csrf_tokens['task'] ?? $csrf_token) ?>" />
        <input id="task_ticket_id" type="hidden" name="ticket_id" value="<?= (int) $ticket['id'] ?>" />
        <input type="hidden" name="action" value="task" />
        <input id="applied_task_template_id" type="hidden" name="tasktemplates_id" value="0" />
        <div class="glpiacessivel-itil-panel-head">
          <div>
            <h3><?= glpiacessivel_e($t('Criar tarefa')) ?></h3>
            <p><?= glpiacessivel_e($t('Registre uma atividade técnica executada ou planejada. O GLPI também grava os campos opcionais disponíveis.')) ?></p>
          </div>
        </div>
        <div class="glpiacessivel-followup-template-box">
          <div class="glpiacessivel-followup-template-grid">
            <div>
              <label for="tasktemplates_id"><?= glpiacessivel_e($t('Modelo de tarefa')) ?></label>
              <select id="tasktemplates_id" aria-describedby="task-template-help task-template-status">
                <option value="0"><?= glpiacessivel_e($t('Sem modelo')) ?></option>
                <?php foreach ($taskTemplates as $template): ?>
                  <option value="<?= (int) ($template['id'] ?? 0) ?>"><?= glpiacessivel_e((string) ($template['name'] ?? '')) ?></option>
                <?php endforeach; ?>
                <?php if (empty($taskTemplates)): ?>
                  <option value="0" disabled><?= glpiacessivel_e($t('Nenhum modelo disponível para este perfil e entidade')) ?></option>
                <?php endif; ?>
              </select>
            </div>
            <button type="button" class="glpiacessivel-button glpiacessivel-button-secondary" data-glpiacessivel-apply-itil-template="task" aria-describedby="task-template-status" disabled><?= glpiacessivel_e($t('Aplicar modelo')) ?></button>
          </div>
          <small id="task-template-help" class="glpiacessivel-help-text"><?= glpiacessivel_e($t('Opcional. O conteúdo e os campos permitidos do modelo são carregados somente quando você o aplica.')) ?></small>
          <p id="task-template-status" class="glpiacessivel-resource-selector-status" role="status" aria-live="polite" aria-atomic="true"></p>
        </div>
        <?php if ($resourceSelectorEnabled): ?>
          <div id="task-selector-errors" class="glpiacessivel-form-error" role="alert" tabindex="-1" hidden></div>
        <?php endif; ?>
        <div class="glpiacessivel-itil-editor-layout">
          <div class="glpiacessivel-itil-editor-main">
            <?php if ($canAddPrivateTask): ?>
            <fieldset
              class="glpiacessivel-visibility-fieldset"
              data-glpiacessivel-visibility
              data-public-label="<?= glpiacessivel_e(__('Adicionar tarefa pública', 'glpiacessivel')) ?>"
              data-private-label="<?= glpiacessivel_e(__('Adicionar tarefa interna', 'glpiacessivel')) ?>"
              aria-describedby="task-visibility-help"
            >
              <legend><?= glpiacessivel_e(__('Visibilidade da tarefa', 'glpiacessivel')) ?></legend>
              <div class="glpiacessivel-visibility-options">
                <label class="glpiacessivel-visibility-option" for="task-visibility-public">
                  <input id="task-visibility-public" type="radio" name="task_is_private" value="0" required <?= !$defaultTaskIsPrivate ? 'checked' : '' ?> aria-describedby="task-visibility-public-help" />
                  <span>
                    <strong><?= glpiacessivel_e(__('Tarefa pública', 'glpiacessivel')) ?></strong>
                    <small id="task-visibility-public-help"><?= glpiacessivel_e(__('Visível na linha do tempo para os participantes autorizados pelo GLPI.', 'glpiacessivel')) ?></small>
                  </span>
                </label>
                <label class="glpiacessivel-visibility-option" for="task-visibility-private">
                  <input id="task-visibility-private" type="radio" name="task_is_private" value="1" required <?= $defaultTaskIsPrivate ? 'checked' : '' ?> aria-describedby="task-visibility-private-help" />
                  <span>
                    <strong><?= glpiacessivel_e(__('Tarefa interna privada', 'glpiacessivel')) ?></strong>
                    <small id="task-visibility-private-help"><?= glpiacessivel_e(__('Visível somente aos usuários autorizados a consultar tarefas privadas.', 'glpiacessivel')) ?></small>
                  </span>
                </label>
              </div>
              <small id="task-visibility-help" class="glpiacessivel-help-text"><?= glpiacessivel_e(__('A opção inicial acompanha sua preferência atual no GLPI. Os documentos anexados terão a mesma visibilidade.', 'glpiacessivel')) ?></small>
            </fieldset>
            <?php else: ?>
              <input type="hidden" name="task_is_private" value="0" />
              <p class="glpiacessivel-help-text"><?= glpiacessivel_e(__('Esta tarefa será pública para os participantes autorizados no chamado.', 'glpiacessivel')) ?></p>
            <?php endif; ?>
            <label for="task"><?= glpiacessivel_e($t('Descrição da tarefa')) ?> *</label>
            <textarea id="task" name="content" required aria-describedby="task-help"></textarea>
            <small id="task-help" class="glpiacessivel-help-text"><?= glpiacessivel_e($t('Use para registrar atividade operacional, execução técnica ou ação futura.')) ?></small>
            <div class="glpiacessivel-field glpiacessivel-file-picker" data-glpiacessivel-file-picker>
              <label for="task_filename"><?= glpiacessivel_e(__('Documentos', 'glpiacessivel')) ?></label>
              <input
                id="task_filename"
                type="file"
                name="task_filename[]"
                multiple
                aria-describedby="task-filename-help task-filename-status"
                data-glpiacessivel-file-input
              />
              <small id="task-filename-help" class="glpiacessivel-help-text"><?= glpiacessivel_e($attachmentHelp) ?></small>
              <div class="glpiacessivel-file-actions">
                <button
                  type="button"
                  class="glpiacessivel-button glpiacessivel-button-secondary"
                  aria-controls="task-filename-list"
                  data-glpiacessivel-file-clear
                  hidden
                ><?= glpiacessivel_e(__('Limpar anexos', 'glpiacessivel')) ?></button>
              </div>
              <p id="task-filename-status" class="glpiacessivel-sr-only" aria-live="polite" aria-atomic="true"></p>
              <ul id="task-filename-list" class="glpiacessivel-file-list" data-glpiacessivel-file-list></ul>
            </div>
          </div>
          <aside class="glpiacessivel-itil-editor-side" aria-label="<?= glpiacessivel_e($t('Campos complementares da tarefa')) ?>">
            <label for="taskcategories_id"><?= glpiacessivel_e($t('Categoria da tarefa')) ?></label>
            <select id="taskcategories_id" name="taskcategories_id">
              <option value="0"><?= glpiacessivel_e($t('Não informar')) ?></option>
              <?php foreach ($taskCategories as $category): ?>
                <option value="<?= (int) ($category['id'] ?? 0) ?>"><?= glpiacessivel_e((string) ($category['label'] ?? '')) ?></option>
              <?php endforeach; ?>
            </select>

            <div class="glpiacessivel-itil-mini-grid">
              <div>
                <label for="task_begin"><?= glpiacessivel_e($t('Início planejado')) ?></label>
                <input id="task_begin" type="datetime-local" name="task_begin" />
              </div>
              <div>
                <label for="task_end"><?= glpiacessivel_e($t('Fim planejado')) ?></label>
                <input id="task_end" type="datetime-local" name="task_end" />
              </div>
            </div>

            <label for="task_state"><?= glpiacessivel_e($t('Estado')) ?></label>
            <select id="task_state" name="task_state">
              <?php foreach ($taskStateOptions as $state): ?>
                <?php $stateId = (int) ($state['id'] ?? 0); ?>
                <option value="<?= $stateId ?>" <?= $stateId === $defaultTaskState ? 'selected' : '' ?>><?= glpiacessivel_e((string) ($state['label'] ?? '')) ?></option>
              <?php endforeach; ?>
            </select>


            <label for="task_actiontime"><?= glpiacessivel_e($t('Duração')) ?></label>
            <select id="task_actiontime" name="task_actiontime">
              <?php foreach ($taskDurationOptions as $duration): ?>
                <option value="<?= (int) ($duration['id'] ?? 0) ?>"><?= glpiacessivel_e((string) ($duration['label'] ?? '')) ?></option>
              <?php endforeach; ?>
            </select>

            <label for="task_users_id_tech"><?= glpiacessivel_e($t('Técnico responsável')) ?></label>
            <select id="task_users_id_tech" name="task_users_id_tech"<?= $resourceSelectorEnabled ? ' data-glpiacessivel-resource-select data-resource-provider="task_technician" data-resource-min-chars="2" data-resource-empty-value="0" data-resource-dependencies="ticket_id:#task_ticket_id"' : '' ?>>
              <option value="0"><?= glpiacessivel_e($t('Usuário atual / não alterar')) ?></option>
              <?php foreach ($assignableUsers as $user): ?>
                <option value="<?= (int) ($user['id'] ?? 0) ?>"><?= glpiacessivel_e((string) ($user['label'] ?? '')) ?></option>
              <?php endforeach; ?>
            </select>

            <label for="task_groups_id_tech"><?= glpiacessivel_e($t('Grupo técnico')) ?></label>
            <select id="task_groups_id_tech" name="task_groups_id_tech"<?= $resourceSelectorEnabled ? ' data-glpiacessivel-resource-select data-resource-provider="task_group" data-resource-min-chars="2" data-resource-empty-value="0" data-resource-dependencies="ticket_id:#task_ticket_id"' : '' ?>>
              <option value="0"><?= glpiacessivel_e($t('Não informar')) ?></option>
              <?php foreach ($taskGroups as $group): ?>
                <option value="<?= (int) ($group['id'] ?? 0) ?>"><?= glpiacessivel_e((string) ($group['label'] ?? '')) ?></option>
              <?php endforeach; ?>
            </select>
          </aside>
        </div>
        <div class="glpiacessivel-itil-form-footer">
          <button type="submit" class="glpiacessivel-button glpiacessivel-button-primary" data-glpiacessivel-visibility-submit><?= glpiacessivel_e(__('Adicionar tarefa pública', 'glpiacessivel')) ?></button>
        </div>
      </form>
    </section>
    <?php endif; ?>

    <?php if ($canAddSolution): ?>
    <section id="itil-panel-solution" class="glpiacessivel-itil-panel" role="tabpanel" tabindex="0" aria-labelledby="itil-tab-solution" <?= $activeItilTab === 'solution' ? '' : 'hidden' ?>>
      <form method="post" action="<?= glpiacessivel_e(glpiacessivel_url('front/ticket.action.php')) ?>" class="glpiacessivel-itil-action-form" data-glpiacessivel-critical-form data-critical-kind="solution" data-critical-title="<?= glpiacessivel_e($t('Confirmar adição de solução')) ?>" data-critical-message="<?= glpiacessivel_e(sprintf($t('Revise a solução do chamado #%d antes de enviá-la ao GLPI.'), (int) $ticket['id'])) ?>" data-critical-consequence="<?= glpiacessivel_e($t('O GLPI registrará a solução e tentará alterar o status para Solucionado; o portal confirmará o resultado após a gravação.')) ?>" data-critical-progress="<?= glpiacessivel_e($t('Registrando a solução e verificando o status no GLPI.')) ?>" data-critical-confirm-label="<?= glpiacessivel_e($t('Confirmar solução')) ?>" data-critical-full-text-label="<?= glpiacessivel_e($t('Revisar descrição completa')) ?>">
        <input type="hidden" name="_glpi_csrf_token" value="<?= glpiacessivel_e($csrf_tokens['solution'] ?? $csrf_token) ?>" />
        <input type="hidden" name="ticket_id" value="<?= (int) $ticket['id'] ?>" />
        <input type="hidden" name="action" value="solution" />
        <input id="applied_solution_template_id" type="hidden" name="solutiontemplates_id" value="0" data-critical-summary-label="<?= glpiacessivel_e($t('Modelo de solução')) ?>" data-critical-summary-value="<?= glpiacessivel_e($t('Sem modelo aplicado')) ?>" data-critical-summary-empty-value="<?= glpiacessivel_e($t('Sem modelo aplicado')) ?>" />
        <input type="hidden" name="critical_confirmed" value="0" />
        <input type="hidden" name="critical_confirmation_token" value="<?= glpiacessivel_e((string) ($criticalConfirmations['solution'] ?? '')) ?>" />
        <div class="glpiacessivel-itil-panel-head">
          <div>
            <h3><?= glpiacessivel_e($t('Adicionar solução')) ?></h3>
            <p><?= glpiacessivel_e($t('Informe a solução aplicada para encaminhar o chamado ao encerramento.')) ?></p>
          </div>
        </div>
        <div class="glpiacessivel-followup-template-box">
          <div class="glpiacessivel-followup-template-grid">
            <div>
              <label for="solutiontemplates_id"><?= glpiacessivel_e($t('Modelo de solução')) ?></label>
              <select id="solutiontemplates_id" aria-describedby="solution-template-help solution-template-status">
                <option value="0"><?= glpiacessivel_e($t('Sem modelo')) ?></option>
                <?php foreach ($solutionTemplates as $template): ?>
                  <option value="<?= (int) ($template['id'] ?? 0) ?>"><?= glpiacessivel_e((string) ($template['name'] ?? '')) ?></option>
                <?php endforeach; ?>
                <?php if (empty($solutionTemplates)): ?>
                  <option value="0" disabled><?= glpiacessivel_e($t('Nenhum modelo disponível para este perfil e entidade')) ?></option>
                <?php endif; ?>
              </select>
            </div>
            <button type="button" class="glpiacessivel-button glpiacessivel-button-secondary" data-glpiacessivel-apply-itil-template="solution" aria-describedby="solution-template-status" disabled><?= glpiacessivel_e($t('Aplicar modelo')) ?></button>
          </div>
          <small id="solution-template-help" class="glpiacessivel-help-text"><?= glpiacessivel_e($t('Opcional. O conteúdo e o tipo da solução são carregados somente após sua confirmação.')) ?></small>
          <p id="solution-template-status" class="glpiacessivel-resource-selector-status" role="status" aria-live="polite" aria-atomic="true"></p>
        </div>
        <label for="solution"><?= glpiacessivel_e($t('Descrição da solução')) ?> *</label>
        <textarea id="solution" name="content" required aria-describedby="solution-help" data-critical-summary-label="<?= glpiacessivel_e($t('Descrição da solução')) ?>"></textarea>
        <small id="solution-help" class="glpiacessivel-help-text"><?= glpiacessivel_e($t('Descreva causa, ação executada e validação. Depois do envio, o portal verificará o status definido pelo GLPI.')) ?></small>
        <label for="solutiontypes_id"><?= glpiacessivel_e($t('Tipo da solução')) ?></label>
        <select
          id="solutiontypes_id"
          name="solutiontypes_id"
          data-critical-summary-label="<?= glpiacessivel_e($t('Tipo da solução')) ?>"
          <?php if (empty($solutionTypes)): ?>aria-describedby="solutiontype-help"<?php endif; ?>
        >
          <option value="0"><?= glpiacessivel_e($t('Não informar')) ?></option>
          <?php foreach ($solutionTypes as $solutionType): ?>
            <option value="<?= (int) ($solutionType['id'] ?? 0) ?>"><?= glpiacessivel_e((string) ($solutionType['label'] ?? '')) ?></option>
          <?php endforeach; ?>
        </select>
        <?php if (empty($solutionTypes)): ?>
          <small id="solutiontype-help" class="glpiacessivel-help-text"><?= glpiacessivel_e($t('Nenhum tipo de solução está configurado ou elegível para este chamado na entidade atual. Você pode registrar a solução sem informar um tipo.')) ?></small>
        <?php endif; ?>
        <div class="glpiacessivel-itil-form-footer">
          <button type="submit" class="glpiacessivel-button glpiacessivel-button-primary"><?= glpiacessivel_e($t('Revisar e confirmar solução')) ?></button>
        </div>
      </form>
    </section>
    <?php endif; ?>
  </div>
  <?php elseif ($solutionOperationState !== 'partial'): ?>
    <p class="glpiacessivel-empty" role="status"><?= glpiacessivel_e($t('Nenhuma ação está disponível para este chamado com seu perfil e entidade atuais.')) ?></p>
  <?php endif; ?>

  <script>
    (function () {
      var followupTemplateMessages = <?= json_encode(
          $followupTemplateMessages,
          JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT
      ) ?: '{}' ?>;
      var templatePreviewUrl = <?= json_encode(
          $templatePreviewUrl,
          JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT
      ) ?: '""' ?>;
      var live = document.getElementById('glpiacessivel-live') || document.getElementById('glpiacessivel-live-region');
      var templateControls = {
        followup: {
          selectId: 'itilfollowuptemplates_id',
          appliedId: 'applied_followup_template_id',
          textareaId: 'followup',
          statusId: 'followup-template-status',
          appliedMessage: 'applied',
          metadataMessage: 'followup_metadata_applied',
          noChangesMessage: 'followup_no_changes',
          emptyMessage: 'followup_empty'
        },
        task: {
          selectId: 'tasktemplates_id',
          appliedId: 'applied_task_template_id',
          textareaId: 'task',
          statusId: 'task-template-status',
          appliedMessage: 'task_applied',
          metadataMessage: 'task_metadata_applied',
          noChangesMessage: 'task_no_changes',
          emptyMessage: 'task_empty'
        },
        solution: {
          selectId: 'solutiontemplates_id',
          appliedId: 'applied_solution_template_id',
          textareaId: 'solution',
          statusId: 'solution-template-status',
          appliedMessage: 'solution_applied',
          metadataMessage: 'solution_metadata_applied',
          noChangesMessage: 'solution_no_changes',
          emptyMessage: 'solution_empty'
        }
      };

      function announce(message, target, isError) {
        var region = target || live;
        if (region) {
          region.setAttribute('role', isError ? 'alert' : 'status');
          region.setAttribute('aria-live', isError ? 'assertive' : 'polite');
          region.textContent = String(message || '');
        }
      }

      function templateFailureMessage(error) {
        var code = error && typeof error.code === 'string' ? error.code : '';
        var status = Number(error && error.status) || 0;
        var key = 'error';
        if (error && (error.name === 'AbortError' || error.name === 'TimeoutError')) {
          key = 'error_timeout';
        } else if (code === 'session_expired' || status === 401) {
          key = 'error_session_expired';
        } else if (code === 'context_stale' || status === 409) {
          key = 'error_context_stale';
        } else if (code === 'invalid_security_token') {
          key = 'error_invalid_security_token';
        } else if (code === 'forbidden' || code === 'origin_not_allowed' || status === 403) {
          key = 'error_forbidden';
        } else if (code === 'template_not_available' || status === 404) {
          key = 'error_template_not_available';
        } else if (code === 'temporarily_unavailable' || status === 503) {
          key = 'error_temporarily_unavailable';
        } else if (code === 'invalid_response' || code === 'invalid_request' || status === 422) {
          key = 'error_invalid_response';
        }
        var message = String(followupTemplateMessages[key] || followupTemplateMessages.error || '');
        var requestId = error && typeof error.requestId === 'string' ? error.requestId : '';
        if (requestId) {
          message += ' ' + String(followupTemplateMessages.error_reference || '')
            .split('{request_id}').join(requestId);
        }
        return message.trim();
      }

      function selectModelValue(id, value, allowZero) {
        var field = document.getElementById(id);
        var numericValue = Number(value);
        if (!field || !Number.isFinite(numericValue)) {
          return false;
        }
        value = String(numericValue);
        // A zero from the native template means that the optional field was
        // not configured, except for Planning::INFO where zero is a real state.
        if (value === '0' && allowZero !== true) {
          return false;
        }
        var previousValue = String(field.value || '');
        var option = Array.prototype.slice.call(field.options || []).find(function (candidate) {
          return candidate.value === value;
        });
        if (!option) {
          option = document.createElement('option');
          option.value = value;
          option.textContent = String(followupTemplateMessages.model_value || '') + ' (#' + value + ')';
          field.appendChild(option);
        }
        field.value = value;
        if (previousValue !== value) {
          field.dispatchEvent(new Event('change', { bubbles: true }));
        }
        return previousValue !== value;
      }

      function applyTemplateResult(kind, form, result, statusRegion) {
        var control = templateControls[kind];
        var textarea = control ? document.getElementById(control.textareaId) : null;
        var effects = result && typeof result.effects === 'object' ? result.effects : {};
        if (!textarea) {
          throw new Error('template_target_missing');
        }
        var templateText = typeof result.text === 'string' ? result.text : '';
        var hasTemplateText = templateText.trim() !== '';
        var applicableEffects = 0;
        var changedEffects = 0;
        if (hasTemplateText) {
          textarea.value = templateText;
        }

        if (
          (kind === 'followup' || kind === 'task')
          && Object.prototype.hasOwnProperty.call(effects, 'is_private')
        ) {
          var privacyName = kind === 'task' ? 'task_is_private' : 'followup_is_private';
          var privacy = String(Number(effects.is_private) === 1 ? 1 : 0);
          var privacyOption = form.querySelector('input[name="' + privacyName + '"][value="' + privacy + '"]');
          if (privacyOption && privacyOption.type === 'radio') {
            applicableEffects += 1;
            if (!privacyOption.checked) {
              changedEffects += 1;
            }
            privacyOption.checked = true;
            if (changedEffects > 0) {
              privacyOption.dispatchEvent(new Event('change', { bubbles: true }));
            }
          }
        }
        if (kind === 'task') {
          [
            ['taskcategories_id', 'taskcategories_id', false],
            ['task_state', 'state', true],
            ['task_actiontime', 'actiontime', false],
            ['task_users_id_tech', 'users_id_tech', false],
            ['task_groups_id_tech', 'groups_id_tech', false]
          ].forEach(function (mapping) {
            if (!Object.prototype.hasOwnProperty.call(effects, mapping[1])) {
              return;
            }
            var effectValue = Number(effects[mapping[1]]);
            if (!Number.isFinite(effectValue) || (mapping[2] ? effectValue < 0 : effectValue <= 0)) {
              return;
            }
            if (!document.getElementById(mapping[0])) {
              return;
            }
            applicableEffects += 1;
            if (selectModelValue(mapping[0], effectValue, mapping[2])) {
              changedEffects += 1;
            }
          });
        } else if (kind === 'solution') {
          if (Number(effects.solutiontypes_id || 0) > 0 && document.getElementById('solutiontypes_id')) {
            applicableEffects += 1;
            if (selectModelValue('solutiontypes_id', effects.solutiontypes_id)) {
              changedEffects += 1;
            }
          }
        }
        var message = control ? String(followupTemplateMessages[control.appliedMessage] || '') : '';
        if (!hasTemplateText && control) {
          if (applicableEffects === 0) {
            message = String(followupTemplateMessages[control.emptyMessage] || '');
          } else if (changedEffects === 0) {
            message = String(followupTemplateMessages[control.noChangesMessage] || '');
          } else {
            message = String(followupTemplateMessages[control.metadataMessage] || '');
          }
        }
        if (result && result.lossy && hasTemplateText) {
          message += (message ? ' ' : '') + String(followupTemplateMessages.lossy || '');
        }
        if (hasTemplateText) {
          textarea.focus();
        }
        announce(message, statusRegion, false);
        return {
          applied: hasTemplateText || changedEffects > 0,
          focusTextarea: hasTemplateText
        };
      }

      Array.prototype.slice.call(document.querySelectorAll('[data-glpiacessivel-apply-itil-template]')).forEach(function (button) {
        var kind = button.getAttribute('data-glpiacessivel-apply-itil-template') || '';
        var control = templateControls[kind];
        var select = control ? document.getElementById(control.selectId) : null;
        var appliedField = control ? document.getElementById(control.appliedId) : null;
        var templateRequestRevision = 0;
        var activeController = null;
        button.addEventListener('click', function () {
          if (button.getAttribute('aria-busy') === 'true') {
            return;
          }
          var form = button.closest('form');
          var textarea = control ? document.getElementById(control.textareaId) : null;
          var statusRegion = control ? document.getElementById(control.statusId) : null;
          var ticketField = form ? form.querySelector('input[name="ticket_id"]') : null;
          var csrfField = form ? form.querySelector('input[name="_glpi_csrf_token"]') : null;
          var templateId = select ? Number(select.value || 0) : 0;
          var restoreButtonFocus = false;
          if (!form || !textarea || !ticketField || !csrfField || !appliedField || templateId <= 0) {
            return;
          }
          var requestRevision = ++templateRequestRevision;
          button.setAttribute('aria-busy', 'true');
          button.setAttribute('aria-disabled', 'true');
          appliedField.value = '0';
          if (appliedField.hasAttribute('data-critical-summary-value')) {
            appliedField.dataset.criticalSummaryValue = String(appliedField.dataset.criticalSummaryEmptyValue || '');
          }
          announce(followupTemplateMessages.loading, statusRegion, false);
          var controller = typeof AbortController === 'function' ? new AbortController() : null;
          activeController = controller;
          var timeoutId = window.setTimeout(function () {
            if (controller) {
              controller.abort();
            }
          }, 5000);
          window.fetch(templatePreviewUrl, {
            method: 'POST',
            credentials: 'same-origin',
            headers: {
              'Content-Type': 'application/json; charset=UTF-8',
              'X-Requested-With': 'XMLHttpRequest',
              'X-GLPI-CSRF-TOKEN': csrfField.value
            },
            body: JSON.stringify({
              contract: 'itil_template',
              version: 1,
              ticket_id: Number(ticketField.value || 0),
              kind: kind,
              template_id: templateId
            }),
            signal: controller ? controller.signal : undefined
          }).then(function (response) {
            return response.json().catch(function () {
              var invalid = new Error('invalid_response');
              invalid.code = 'invalid_response';
              invalid.status = response.status;
              throw invalid;
            }).then(function (payload) {
              if (!response.ok || !payload || payload.contract !== 'itil_template' || payload.version !== 1 || payload.success !== true) {
                var failure = new Error('template_request_failed');
                failure.status = response.status;
                failure.code = payload && payload.error && typeof payload.error.code === 'string'
                  ? payload.error.code
                  : 'invalid_response';
                failure.requestId = payload && payload.error && typeof payload.error.request_id === 'string'
                  ? payload.error.request_id
                  : (payload && typeof payload.request_id === 'string' ? payload.request_id : '');
                throw failure;
              }
              return payload.result || {};
            });
          }).then(function (result) {
            if (requestRevision !== templateRequestRevision || Number(select.value || 0) !== templateId) {
              var stale = new Error('stale_template_response');
              stale.code = 'stale_template_response';
              throw stale;
            }
            if (result.kind !== kind || Number(result.template_id || 0) !== templateId) {
              throw new Error('template_response_mismatch');
            }
            var returnedText = typeof result.text === 'string' ? result.text.trim() : '';
            if (
              returnedText !== ''
              && textarea.value.trim() !== ''
              && !window.confirm(String(followupTemplateMessages.replace_confirmation || ''))
            ) {
              restoreButtonFocus = true;
              announce(followupTemplateMessages.cancelled, statusRegion, false);
              return;
            }
            var outcome = applyTemplateResult(kind, form, result, statusRegion);
            appliedField.value = outcome.applied ? String(templateId) : '0';
            if (appliedField.hasAttribute('data-critical-summary-value')) {
              var selectedTemplate = select.options && select.selectedIndex >= 0
                ? select.options[select.selectedIndex]
                : null;
              appliedField.dataset.criticalSummaryValue = outcome.applied && selectedTemplate
                ? String(selectedTemplate.textContent || '').trim()
                : String(appliedField.dataset.criticalSummaryEmptyValue || '');
            }
            restoreButtonFocus = !outcome.focusTextarea;
          }).catch(function (error) {
            if (requestRevision !== templateRequestRevision || (error && error.code === 'stale_template_response')) {
              return;
            }
            restoreButtonFocus = true;
            announce(templateFailureMessage(error), statusRegion, true);
          }).finally(function () {
            window.clearTimeout(timeoutId);
            if (activeController === controller) {
              activeController = null;
            }
            button.removeAttribute('aria-busy');
            button.removeAttribute('aria-disabled');
            if (requestRevision === templateRequestRevision && restoreButtonFocus && document.contains(button)) {
              button.focus();
            }
          });
        });
        if (select && appliedField) {
          var synchronizeTemplateButton = function () {
            button.disabled = Number(select.value || 0) <= 0;
          };
          select.addEventListener('change', function () {
            if (activeController) {
              templateRequestRevision += 1;
              activeController.abort();
              announce(followupTemplateMessages.cancelled, document.getElementById(control.statusId), false);
            }
            appliedField.value = '0';
            if (appliedField.hasAttribute('data-critical-summary-value')) {
              appliedField.dataset.criticalSummaryValue = String(appliedField.dataset.criticalSummaryEmptyValue || '');
            }
            synchronizeTemplateButton();
          });
          synchronizeTemplateButton();
        }
      });

      Array.prototype.slice.call(document.querySelectorAll('[data-glpiacessivel-visibility]')).forEach(function (fieldset) {
        var form = fieldset.closest('form');
        var submit = form ? form.querySelector('[data-glpiacessivel-visibility-submit]') : null;
        var radios = Array.prototype.slice.call(fieldset.querySelectorAll('input[type="radio"]'));
        if (!submit || radios.length === 0) {
          return;
        }

        function updateSubmitLabel() {
          var selected = radios.find(function (radio) { return radio.checked; });
          var isPrivate = selected && selected.value === '1';
          submit.textContent = isPrivate
            ? fieldset.getAttribute('data-private-label')
            : fieldset.getAttribute('data-public-label');
        }

        radios.forEach(function (radio) {
          radio.addEventListener('change', updateSubmitLabel);
        });
        updateSubmitLabel();
      });

      var fileSelectionMessages = <?= json_encode($fileSelectionMessages, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) ?: '{}' ?>;
      Array.prototype.slice.call(document.querySelectorAll('[data-glpiacessivel-file-picker]')).forEach(function (picker) {
        var input = picker.querySelector('[data-glpiacessivel-file-input]');
        var list = picker.querySelector('[data-glpiacessivel-file-list]');
        var clearButton = picker.querySelector('[data-glpiacessivel-file-clear]');
        var statusId = input ? (input.getAttribute('aria-describedby') || '').split(/\s+/).filter(function (id) {
          return id.indexOf('-status') !== -1;
        })[0] : '';
        var status = statusId ? document.getElementById(statusId) : null;
        if (!input || !list || !clearButton || !status) {
          return;
        }

        function renderSelectedFiles(announcement) {
          list.innerHTML = '';
          var files = Array.prototype.slice.call(input.files || []);
          files.forEach(function (file) {
            var item = document.createElement('li');
            var sizeKb = Math.max(1, Math.ceil((file.size || 0) / 1024));
            item.textContent = file.name + ' (' + sizeKb + ' KB)';
            list.appendChild(item);
          });
          clearButton.hidden = files.length === 0;
          if (announcement) {
            status.textContent = files.length === 0
              ? fileSelectionMessages.empty
              : String(
                files.length === 1
                  ? fileSelectionMessages.selected_one
                  : fileSelectionMessages.selected_many
              ).replace('%d', String(files.length));
          }
        }

        input.addEventListener('change', function () {
          renderSelectedFiles(true);
        });
        clearButton.addEventListener('click', function () {
          input.value = '';
          renderSelectedFiles(false);
          status.textContent = fileSelectionMessages.cleared;
          input.focus();
        });
        renderSelectedFiles(false);
      });

      var tabs = Array.prototype.slice.call(document.querySelectorAll('[data-glpiacessivel-itil-tab]'));
      if (tabs.length === 0) {
        return;
      }

      function activateTab(tab) {
        tabs.forEach(function (item) {
          var panel = document.getElementById(item.getAttribute('aria-controls') || '');
          var active = item === tab;
          item.classList.toggle('is-active', active);
          item.setAttribute('aria-selected', active ? 'true' : 'false');
          item.setAttribute('tabindex', active ? '0' : '-1');
          if (panel) {
            panel.hidden = !active;
          }
        });
        tab.focus();
      }

      tabs.forEach(function (tab, index) {
        tab.setAttribute('tabindex', index === 0 ? '0' : '-1');
        tab.addEventListener('click', function () {
          activateTab(tab);
        });
        tab.addEventListener('keydown', function (event) {
          var next = index;
          if (event.key === 'ArrowRight') {
            next = (index + 1) % tabs.length;
          } else if (event.key === 'ArrowLeft') {
            next = (index - 1 + tabs.length) % tabs.length;
          } else if (event.key === 'Home') {
            next = 0;
          } else if (event.key === 'End') {
            next = tabs.length - 1;
          } else {
            return;
          }
          event.preventDefault();
          activateTab(tabs[next]);
        });
      });
    })();
  </script>

  <div class="glpiacessivel-itil-secondary-grid">
    <?php if ($canChangeStatus && $allowedStatusTransitions !== []): ?>
    <form method="post" action="<?= glpiacessivel_e(glpiacessivel_url('front/ticket.action.php')) ?>" class="glpiacessivel-itil-secondary-form" data-glpiacessivel-critical-form data-glpiacessivel-status-form data-critical-title="<?= glpiacessivel_e($t('Confirmar alteração de status')) ?>" data-critical-message="<?= glpiacessivel_e(sprintf($t('Revise a transição de status do chamado #%d.'), (int) $ticket['id'])) ?>" data-status-confirmation-template="<?= glpiacessivel_e($t('Confirme a alteração de {from} para {to}.')) ?>" data-critical-consequence="<?= glpiacessivel_e($t('A alteração fica registrada no histórico do GLPI.')) ?>">
      <input type="hidden" name="_glpi_csrf_token" value="<?= glpiacessivel_e($csrf_tokens['status'] ?? $csrf_token) ?>" />
      <input type="hidden" name="ticket_id" value="<?= (int) $ticket['id'] ?>" />
      <input type="hidden" name="action" value="status" />
      <input type="hidden" name="critical_confirmed" value="0" />
      <input type="hidden" name="critical_confirmation_token" value="<?= glpiacessivel_e((string) ($criticalConfirmations['status'] ?? '')) ?>" />
      <div>
        <h3><?= glpiacessivel_e($t('Status do chamado')) ?></h3>
        <p id="status-current" class="glpiacessivel-help-text"><?= glpiacessivel_e(sprintf($t('Status atual: %s.'), glpiacessivel_ticket_status($ticketStatus))) ?></p>
        <p id="status-help" class="glpiacessivel-help-text"><?= glpiacessivel_e($t('Selecione uma transição permitida pelo perfil e pelo estado atual. Nenhuma alteração ocorre antes da confirmação.')) ?></p>
      </div>
      <label for="status"><?= glpiacessivel_e($t('Novo status')) ?></label>
      <select id="status" name="status" required aria-describedby="status-current status-help">
        <option value="" selected disabled><?= glpiacessivel_e($t('Selecione o novo status')) ?></option>
        <?php foreach ($allowedStatusTransitions as $allowed): ?>
          <option value="<?= (int) $allowed ?>"><?= glpiacessivel_e(glpiacessivel_ticket_status($allowed)) ?></option>
        <?php endforeach; ?>
      </select>
      <button type="submit" class="glpiacessivel-button glpiacessivel-button-secondary" data-glpiacessivel-status-submit><?= glpiacessivel_e($t('Atualizar status')) ?></button>
    </form>
    <script>
      (function () {
        var form = document.querySelector('[data-glpiacessivel-status-form]');
        var select = form ? form.querySelector('select[name="status"]') : null;
        var button = form ? form.querySelector('[data-glpiacessivel-status-submit]') : null;
        if (!form || !select || !button) {
          return;
        }
        var current = <?= json_encode(glpiacessivel_ticket_status($ticketStatus), JSON_UNESCAPED_UNICODE | JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT) ?: '""' ?>;
        function synchronize() {
          var option = select.options[select.selectedIndex] || null;
          var chosen = String(select.value || '');
          button.disabled = chosen === '';
          if (chosen !== '' && option) {
            form.dataset.criticalMessage = String(form.dataset.statusConfirmationTemplate || '')
              .split('{from}').join(current)
              .split('{to}').join(String(option.textContent || '').trim());
          }
        }
        select.addEventListener('change', synchronize);
        synchronize();
      })();
    </script>
    <?php elseif ($canChangeStatus): ?>
      <article class="glpiacessivel-itil-secondary-form">
        <h3><?= glpiacessivel_e($t('Status do chamado')) ?></h3>
        <p class="glpiacessivel-help-text" role="status"><?= glpiacessivel_e($t('Nenhuma transição de status está disponível para este chamado.')) ?></p>
      </article>
    <?php endif; ?>

    <?php if (!empty($satisfaction['available'])): ?>
      <article class="glpiacessivel-itil-secondary-form" aria-labelledby="satisfacao-ticket">
        <div>
          <h3 id="satisfacao-ticket"><?= glpiacessivel_e($t('Satisfação do requisitante')) ?></h3>
          <p class="glpiacessivel-help-text"><?= glpiacessivel_e($t('Disponível porque o GLPI gerou uma pesquisa de satisfação para este chamado fechado.')) ?></p>
        </div>
        <?php if (!empty($satisfaction['can_answer'])): ?>
          <form method="post" action="<?= glpiacessivel_e(glpiacessivel_url('front/ticket.action.php')) ?>" class="glpiacessivel-itil-action-form" data-glpiacessivel-critical-form data-critical-title="<?= glpiacessivel_e($t('Confirmar resposta da satisfação')) ?>" data-critical-message="<?= glpiacessivel_e(sprintf($t('Revise a nota de satisfação do chamado #%d antes de enviar.'), (int) $ticket['id'])) ?>" data-critical-consequence="<?= glpiacessivel_e($t('A resposta fica registrada na pesquisa de satisfação do GLPI.')) ?>">
            <input type="hidden" name="_glpi_csrf_token" value="<?= glpiacessivel_e($csrf_tokens['requester_decision'] ?? $csrf_token) ?>" />
            <input type="hidden" name="ticket_id" value="<?= (int) $ticket['id'] ?>" />
            <input type="hidden" name="action" value="requester_decision" />
            <input type="hidden" name="critical_confirmed" value="0" />
            <input type="hidden" name="critical_confirmation_token" value="<?= glpiacessivel_e((string) ($criticalConfirmations['requester_decision'] ?? '')) ?>" />
            <label for="decision"><?= glpiacessivel_e($t('Nota de satisfação')) ?></label>
            <select id="decision" name="decision">
              <option value="5" <?= (int) ($satisfaction['score'] ?? 0) === 5 ? 'selected' : '' ?>><?= glpiacessivel_e($t('Muito satisfeito')) ?></option>
              <option value="4" <?= (int) ($satisfaction['score'] ?? 0) === 4 ? 'selected' : '' ?>><?= glpiacessivel_e($t('Satisfeito')) ?></option>
              <option value="3" <?= (int) ($satisfaction['score'] ?? 0) === 3 ? 'selected' : '' ?>><?= glpiacessivel_e($t('Neutro')) ?></option>
              <option value="2" <?= (int) ($satisfaction['score'] ?? 0) === 2 ? 'selected' : '' ?>><?= glpiacessivel_e($t('Insatisfeito')) ?></option>
              <option value="1" <?= (int) ($satisfaction['score'] ?? 0) === 1 ? 'selected' : '' ?>><?= glpiacessivel_e($t('Muito insatisfeito')) ?></option>
            </select>
            <label for="decision_comment"><?= glpiacessivel_e($t('Comentário')) ?></label>
            <input id="decision_comment" type="text" name="content" maxlength="255" value="<?= glpiacessivel_e((string) ($satisfaction['comment'] ?? '')) ?>" />
            <button type="submit" class="glpiacessivel-button glpiacessivel-button-secondary"><?= glpiacessivel_e($t('Responder pesquisa')) ?></button>
          </form>
        <?php else: ?>
          <p class="glpiacessivel-empty"><?= glpiacessivel_e($t('Pesquisa disponível apenas para o requisitante autorizado ou já bloqueada pelo GLPI.')) ?></p>
        <?php endif; ?>
      </article>
    <?php endif; ?>
  </div>
  <?php endif; ?>
</section>

<section class="glpiacessivel-card" aria-labelledby="timeline-ticket">
  <h2 id="timeline-ticket"><?= glpiacessivel_e($t('Linha do tempo operacional')) ?></h2>
  <p class="glpiacessivel-muted"><?= glpiacessivel_e(__('A linha do tempo mostra as interações do chamado que seu perfil pode consultar. Itens privados são identificados em texto.', 'glpiacessivel')) ?></p>
  <?php if (count($ticket['timeline']) === 0): ?>
    <p class="glpiacessivel-empty" role="status"><?= glpiacessivel_e(__('Nenhum evento disponível para este chamado com as permissões atuais.', 'glpiacessivel')) ?></p>
  <?php else: ?>
    <ol class="glpiacessivel-timeline">
      <?php foreach ($ticket['timeline'] as $event): ?>
        <li>
          <div class="glpiacessivel-timeline-marker" aria-hidden="true"></div>
          <article class="glpiacessivel-timeline-body">
            <header>
              <span class="glpiacessivel-meta-chip"><?= glpiacessivel_e(glpiacessivel_timeline_label($event['type'])) ?></span>
              <?php if (array_key_exists('is_private', $event)): ?>
                <span class="glpiacessivel-meta-chip"><?= glpiacessivel_e(!empty($event['is_private']) ? __('Privado', 'glpiacessivel') : __('Público', 'glpiacessivel')) ?></span>
              <?php endif; ?>
              <time datetime="<?= glpiacessivel_e((string) $event['date']) ?>"><?= glpiacessivel_e((string) $event['date']) ?></time>
            </header>
            <?php if (!empty($event['author_name'])): ?>
              <p class="glpiacessivel-muted"><?= glpiacessivel_e(sprintf(__('Autor: %s', 'glpiacessivel'), (string) $event['author_name'])) ?></p>
            <?php endif; ?>
            <div class="glpiacessivel-content"><?= \GlpiPlugin\Glpiacessivel\Support\RichTextFormatter::toHtml((string) $event['content']) ?></div>
            <?php if (!empty($event['documents'])): ?>
              <?php
                $eventDocumentTitleId = 'documentos-' . (string) $event['type'] . '-' . (int) $event['id'];
                $eventDocumentOrigin = $event['type'] === 'task'
                    ? __('Tarefa do chamado', 'glpiacessivel')
                    : __('Acompanhamento do chamado', 'glpiacessivel');
              ?>
              <section class="glpiacessivel-timeline-documents" aria-labelledby="<?= glpiacessivel_e($eventDocumentTitleId) ?>">
                <h3 id="<?= glpiacessivel_e($eventDocumentTitleId) ?>"><?= glpiacessivel_e(__('Anexos deste evento', 'glpiacessivel')) ?></h3>
                <?php $renderDocuments((array) $event['documents'], $eventDocumentOrigin); ?>
              </section>
            <?php endif; ?>
          </article>
        </li>
      <?php endforeach; ?>
    </ol>
  <?php endif; ?>
</section>


<?php if (!empty($historyContext['can_view'])): ?>
<section class="glpiacessivel-card" aria-labelledby="historico-ticket" aria-describedby="historico-ticket-desc">
  <h2 id="historico-ticket"><?= glpiacessivel_e($t('Histórico detalhado do chamado')) ?></h2>
  <p id="historico-ticket-desc" class="glpiacessivel-muted"><?= glpiacessivel_e($t('Alterações registradas no histórico do GLPI, limitadas ao que seu perfil pode consultar.')) ?></p>
  <?php if (empty($historyContext['available'])): ?>
    <p class="glpiacessivel-empty" role="status"><?= glpiacessivel_e($t('Histórico indisponível no momento. Tente novamente mais tarde.')) ?></p>
  <?php elseif (count($historyItems) === 0): ?>
    <p class="glpiacessivel-empty" role="status"><?= glpiacessivel_e($t('Nenhuma alteração detalhada disponível para este chamado.')) ?></p>
  <?php else: ?>
    <ol class="glpiacessivel-timeline">
      <?php foreach ($historyItems as $index => $event): ?>
        <?php
          $eventId = 'historico-evento-' . (int) ($event['id'] ?? ($index + 1));
          $eventDate = (string) ($event['date'] ?? '');
          $eventField = (string) ($event['field'] ?? '');
          $eventUser = (string) ($event['user'] ?? '');
          $eventAction = (string) ($event['action'] ?? '');
          $eventSummary = (string) ($event['summary'] ?? '');
        ?>
        <li>
          <div class="glpiacessivel-timeline-marker" aria-hidden="true"></div>
          <article class="glpiacessivel-timeline-body" aria-labelledby="<?= glpiacessivel_e($eventId) ?>">
            <header>
              <h3 id="<?= glpiacessivel_e($eventId) ?>" class="glpiacessivel-sr-only">
                <?= glpiacessivel_e(sprintf($t('Alteração do chamado em %s'), $eventDate !== '' ? $eventDate : $t('data não informada'))) ?>
              </h3>
              <span class="glpiacessivel-meta-chip"><?= glpiacessivel_e($eventField !== '' ? $eventField : $t('Histórico')) ?></span>
              <?php if ($eventDate !== ''): ?><time datetime="<?= glpiacessivel_e($eventDate) ?>"><?= glpiacessivel_e($eventDate) ?></time><?php endif; ?>
            </header>
            <p><?= glpiacessivel_e($eventSummary) ?></p>
            <?php if ($eventUser !== '' || $eventAction !== ''): ?>
              <p class="glpiacessivel-muted">
                <?php if ($eventUser !== ''): ?><?= glpiacessivel_e($t('Usuário')) ?>: <?= glpiacessivel_e($eventUser) ?><?php endif; ?>
                <?php if ($eventAction !== ''): ?><?= $eventUser !== '' ? ' | ' : '' ?><?= glpiacessivel_e($t('Ação')) ?>: <?= glpiacessivel_e($eventAction) ?><?php endif; ?>
              </p>
            <?php endif; ?>
          </article>
        </li>
      <?php endforeach; ?>
    </ol>
    <?php $historyLimit = (int) ($historyContext['limit'] ?? 50); ?>
    <p class="glpiacessivel-help-text"><?= glpiacessivel_e(sprintf(
        $t($historyLimit === 1 ? 'Exibindo até 1 registro recente do histórico.' : 'Exibindo até %d registros recentes do histórico.'),
        $historyLimit
    )) ?></p>
  <?php endif; ?>
</section>
<?php endif; ?>
<?php if (!empty($satisfaction['exists'])): ?>
  <section class="glpiacessivel-card" aria-labelledby="decisao-requisitante">
    <h2 id="decisao-requisitante"><?= glpiacessivel_e($t('Satisfação registrada')) ?></h2>
    <div class="glpiacessivel-definition-grid">
      <p><strong><?= glpiacessivel_e($t('Nota')) ?></strong><span><?= glpiacessivel_e((string) ($satisfaction['score'] ?? $t('N/D'))) ?></span></p>
      <p><strong><?= glpiacessivel_e($t('Respondida em')) ?></strong><span><?= glpiacessivel_e((string) ($satisfaction['date_answered'] ?? '')) ?></span></p>
      <p><strong><?= glpiacessivel_e($t('Comentário')) ?></strong><span><?= glpiacessivel_e((string) ($satisfaction['comment'] ?? '')) ?></span></p>
    </div>
  </section>
<?php endif; ?>
