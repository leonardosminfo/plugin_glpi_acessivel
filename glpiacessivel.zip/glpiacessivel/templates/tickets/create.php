<?php
$values = is_array($values ?? null) ? $values : [];
$t = static fn(string $text): string => glpiacessivel_t($text);
$context = is_array($context ?? null) ? $context : [];
$errors = is_array($errors ?? null) ? $errors : [];
$submissionMetadata = is_array($submission_metadata ?? null) ? $submission_metadata : [];
$partialCreatedTicketId = (int) ($submissionMetadata['created_ticket_id'] ?? 0);
$categories = is_array($context['categories'] ?? null) ? $context['categories'] : [];
$locations = is_array($context['locations'] ?? null) ? $context['locations'] : [];
$assignedUsers = is_array($context['assignable_users'] ?? null) ? $context['assignable_users'] : [];
$observerUsers = is_array($context['observer_users'] ?? null) ? $context['observer_users'] : [];
$groups = is_array($context['assignable_groups'] ?? null) ? $context['assignable_groups'] : [];
$observerGroups = is_array($context['observer_groups'] ?? null) ? $context['observer_groups'] : [];
$typeOptions = is_array($context['type_options'] ?? null) ? $context['type_options'] : [];
$urgencyOptions = is_array($context['urgency_options'] ?? null) ? $context['urgency_options'] : [];
$impactOptions = is_array($context['impact_options'] ?? null) ? $context['impact_options'] : [];
$requestSourceOptions = is_array($context['request_source_options'] ?? null) ? $context['request_source_options'] : [];
$defaultRequestSourceId = (int) ($context['default_request_source_id'] ?? 1);
$requestSourceSupported = !empty($context['request_source_supported']);
$externalIdSupported = !empty($context['external_id_supported']);
$groupAssignmentSupported = !empty($context['group_assignment_supported']);
$fieldRequirements = is_array($context['field_requirements'] ?? null) ? $context['field_requirements'] : [];
$ticketTemplates = is_array($context['ticket_templates'] ?? null) ? $context['ticket_templates'] : [];
$serviceCatalog = is_array($context['service_catalog'] ?? null) ? $context['service_catalog'] : [];
$dynamicFormSchema = is_array($context['dynamic_form_schema'] ?? null) ? $context['dynamic_form_schema'] : [];
$dynamicFormFallback = is_array($dynamicFormSchema['fallback'] ?? null) ? $dynamicFormSchema['fallback'] : [];
$requiresNativeFallback = !empty($dynamicFormFallback['required']);
$nativeFallbackReasons = array_values(array_unique(array_filter(array_map(
    static fn(mixed $reason): string => trim((string) $reason),
    (array) ($dynamicFormFallback['reasons'] ?? [])
))));
if ($requiresNativeFallback && $nativeFallbackReasons === []) {
    $nativeFallbackReasons[] = $t('Este formulário exige recursos ainda não disponíveis nesta página. Abra-o em página completa.');
}
$resourceSelectorConfig = is_array($context['resource_selector'] ?? null) ? $context['resource_selector'] : [];
$resourceSelectorEnabled = !empty($resourceSelectorConfig['enabled']);
$requesterEditable = $resourceSelectorEnabled && !empty($context['requester_editable']);
$currentRequesterId = (int) ($context['requester_id'] ?? 0);
$selectedRequesterId = (int) ($values['requester_user_id'] ?? $currentRequesterId);
if ($selectedRequesterId <= 0) {
    $selectedRequesterId = $currentRequesterId;
}
$selectedResources = is_array($context['selected_resources'] ?? null) ? $context['selected_resources'] : [];
$requesterUsers = (array) ($selectedResources['requester_user_id'] ?? []);
$requesterUsersById = [];
if ($currentRequesterId > 0) {
    $requesterUsersById[$currentRequesterId] = [
        'id' => $currentRequesterId,
        'label' => (string) ($context['requester_name'] ?? $t('Usuário atual')),
    ];
}
foreach ($requesterUsers as $requesterUser) {
    if (!is_array($requesterUser) || (int) ($requesterUser['id'] ?? 0) <= 0) {
        continue;
    }
    $requesterUsersById[(int) $requesterUser['id']] = $requesterUser;
}
$requesterUsers = array_values($requesterUsersById);
$effectiveRequesterName = (string) ($context['requester_name'] ?? '');
if (isset($requesterUsersById[$selectedRequesterId])) {
    $effectiveRequesterName = (string) ($requesterUsersById[$selectedRequesterId]['label'] ?? $effectiveRequesterName);
} else {
    $selectedRequesterId = $currentRequesterId;
}
if ($resourceSelectorEnabled) {
    // The server hydrates only confirmed values. Candidate catalogs remain remote.
    $categories = (array) ($selectedResources['itilcategories_id'] ?? []);
    $locations = (array) ($selectedResources['locations_id'] ?? []);
    $assignedUsers = (array) ($selectedResources['_users_id_assign'] ?? []);
    $observerUsers = (array) ($selectedResources['_users_id_observer'] ?? []);
    $groups = (array) ($selectedResources['_groups_id_assign'] ?? []);
    $observerGroups = (array) ($selectedResources['_groups_id_observer'] ?? []);
}
$resourceSelectorUrl = glpiacessivel_url('front/ticket.resource-selector.php');
$resourceSelectorAssetPath = 'public/assets/js/remote-resource-selector.js';
$resourceSelectorAssetVersion = function_exists('plugin_glpiacessivel_asset_version')
    ? plugin_glpiacessivel_asset_version($resourceSelectorAssetPath)
    : (string) (@filemtime(__DIR__ . '/../../' . $resourceSelectorAssetPath) ?: '1');
$resourceSelectorAssetUrl = \GlpiPlugin\Glpiacessivel\Support\Url::asset(
    $resourceSelectorAssetPath . '?v=' . rawurlencode($resourceSelectorAssetVersion)
);
$schemaFieldsByName = [];
foreach ((array) ($dynamicFormSchema['fields'] ?? []) as $schemaField) {
    if (!is_array($schemaField)) {
        continue;
    }
    foreach ([(string) ($schemaField['name'] ?? ''), (string) ($schemaField['native_field'] ?? ''), (string) ($schemaField['id'] ?? '')] as $schemaFieldKey) {
        if ($schemaFieldKey !== '') {
            $schemaFieldsByName[$schemaFieldKey] = $schemaField;
        }
    }
}
$fieldSchema = static fn(string $field): array => is_array($schemaFieldsByName[$field] ?? null) ? $schemaFieldsByName[$field] : [];
$fieldRequired = static function (string $field, bool $default = false) use ($fieldSchema): bool {
    $schemaField = $fieldSchema($field);
    return $schemaField === [] ? $default : !empty($schemaField['required']);
};
$fieldVisible = static function (string $field, bool $default = true) use ($fieldSchema): bool {
    $schemaField = $fieldSchema($field);
    return $schemaField === [] || !array_key_exists('visible', $schemaField) ? $default : !empty($schemaField['visible']);
};
$fieldReadonly = static function (string $field, bool $default = false) use ($fieldSchema): bool {
    $schemaField = $fieldSchema($field);
    return $schemaField === [] ? $default : !empty($schemaField['readonly']);
};
$fieldDisabled = static function (string $field, bool $default = false) use ($fieldSchema): bool {
    $schemaField = $fieldSchema($field);
    return $schemaField === [] ? $default : !empty($schemaField['disabled']);
};
$fieldLabel = static function (string $field, string $default) use ($fieldSchema): string {
    $schemaField = $fieldSchema($field);
    return (string) (($schemaField['label'] ?? '') !== '' ? $schemaField['label'] : $default);
};
$requiredAttrs = static function (string $field, bool $default = false) use ($fieldRequired): string {
    return $fieldRequired($field, $default) ? ' required aria-required="true"' : '';
};
$stateAttrs = static function (string $field, bool $disabledDefault = false) use ($fieldReadonly, $fieldDisabled): string {
    $attrs = [];
    if ($fieldReadonly($field)) {
        $attrs[] = 'readonly';
    }
    if ($fieldDisabled($field, $disabledDefault)) {
        $attrs[] = 'disabled';
    }
    return $attrs === [] ? '' : ' ' . implode(' ', $attrs);
};
$selectStateAttrs = static function (string $field, bool $disabledDefault = false) use ($fieldReadonly, $fieldDisabled): string {
    $readonly = $fieldReadonly($field);
    $disabled = $fieldDisabled($field, $disabledDefault);
    if (!$readonly && !$disabled) {
        return '';
    }

    return ' disabled' . ($readonly ? ' aria-readonly="true" data-glpiacessivel-template-locked="1"' : '');
};
$lockedSelectHidden = static function (string $field, string $name, mixed $value) use ($fieldReadonly, $fieldDisabled): string {
    if (!$fieldReadonly($field) || $fieldDisabled($field)) {
        return '';
    }
    $values = is_array($value) ? $value : [$value];
    $html = [];
    foreach ($values as $item) {
        if (!is_scalar($item)) {
            continue;
        }
        $html[] = '<input type="hidden" name="' . glpiacessivel_e($name) . '" value="'
            . glpiacessivel_e((string) $item) . '" data-glpiacessivel-template-locked-value="1" />';
    }
    return implode('', $html);
};
$requiredMark = static function (string $field, bool $default = false) use ($fieldRequired): string {
    return $fieldRequired($field, $default) ? ' *' : '';
};
$selectedTemplateId = (int) ($values['tickettemplates_id'] ?? 0);
$nativeCreateTicketUrl = (string) ($native_create_ticket_url ?? glpiacessivel_url('front/tickets.php'));
$templateById = [];
$templateMetadataPayload = [];
$templateProjectionKinds = [
    'type' => 'integer',
    'itilcategories_id' => 'integer',
    'locations_id' => 'integer',
    'requesttypes_id' => 'integer',
    'externalid' => 'text',
    'urgency' => 'integer',
    'impact' => 'integer',
    '_groups_id_assign' => 'integer_list',
    '_users_id_assign' => 'integer_list',
    '_users_id_observer' => 'integer_list',
    '_groups_id_observer' => 'integer_list',
];
$normalizeTemplateProjectionValue = static function (string $kind, mixed $value): mixed {
    if ($kind === 'integer_list') {
        $ids = [];
        foreach ((array) $value as $item) {
            if (!is_scalar($item)) {
                continue;
            }
            $id = (int) $item;
            if ($id > 0) {
                $ids[$id] = $id;
            }
        }
        return array_values($ids);
    }
    if ($kind === 'integer') {
        $candidate = is_array($value) ? reset($value) : $value;
        return is_scalar($candidate) ? (int) $candidate : null;
    }
    if ($kind === 'text') {
        $candidate = is_array($value) ? reset($value) : $value;
        return is_scalar($candidate) ? mb_substr(trim((string) $candidate), 0, 255, 'UTF-8') : null;
    }

    return null;
};
$selectedTemplate = null;
foreach ($ticketTemplates as $template) {
    $templateId = (int) ($template['id'] ?? 0);
    if ($templateId <= 0) {
        continue;
    }
    $templateById[$templateId] = $template;
    if ($templateId === $selectedTemplateId) {
        $selectedTemplate = $template;
    }
    $requiredLabels = [];
    foreach ((array) ($template['mandatory_fields'] ?? []) as $requiredField) {
        $requiredLabels[] = (string) (($fieldRequirements[$requiredField]['label'] ?? null) ?: ($template['field_requirements'][$requiredField]['label'] ?? $requiredField));
    }
    $unsupportedLabels = [];
    foreach ((array) ($template['unsupported_required'] ?? []) as $requiredField) {
        $unsupportedLabels[] = (string) (($template['field_requirements'][$requiredField]['label'] ?? null) ?: $requiredField);
    }
    $projectedPredefined = [];
    $projectionUnsupported = [];
    foreach ((array) ($template['predefined'] ?? []) as $predefinedField => $predefinedValue) {
        $predefinedField = (string) $predefinedField;
        if (!isset($templateProjectionKinds[$predefinedField])) {
            if (in_array($predefinedField, ['name', 'content', '_filename'], true)) {
                $projectionUnsupported[] = \GlpiPlugin\Glpiacessivel\Domain\Ticket\TicketCreationPolicy::fieldLabel($predefinedField);
            }
            continue;
        }
        $normalizedValue = $normalizeTemplateProjectionValue(
            $templateProjectionKinds[$predefinedField],
            $predefinedValue
        );
        if ($normalizedValue !== null) {
            $projectedPredefined[$predefinedField] = $normalizedValue;
        }
    }
    $projectedProtectedFields = array_values(array_intersect(
        array_keys($templateProjectionKinds),
        array_values(array_unique(array_merge(
            array_map('strval', (array) ($template['readonly_fields'] ?? [])),
            array_map('strval', (array) ($template['hidden_fields'] ?? [])),
            array_keys($projectedPredefined)
        )))
    ));
    $projectionRequiresNativeFallback = !empty($template['requires_native_fallback'])
        || $projectionUnsupported !== [];
    $templateMetadataPayload[(string) $templateId] = [
        'label' => (string) ($template['label'] ?? sprintf($t('Modelo #%d'), $templateId)),
        'required' => $requiredLabels,
        'requiredFields' => array_values(array_map('strval', (array) ($template['mandatory_fields'] ?? []))),
        'unsupported' => array_values(array_unique(array_merge($unsupportedLabels, $projectionUnsupported))),
        'requiresNativeFallback' => $projectionRequiresNativeFallback,
        'predefined' => $projectedPredefined,
        'protectedFields' => $projectedProtectedFields,
    ];
}

$computePriorityPreview = static function (int $urgency, int $impact) use ($t): string {
    $score = max(1, min(5, $urgency)) + max(1, min(5, $impact));
    return match (true) {
        $score <= 3 => $t('Muito baixa'),
        $score <= 5 => $t('Baixa'),
        $score <= 7 => $t('Média'),
        $score <= 9 => $t('Alta'),
        default => $t('Muito alta'),
    };
};

$fieldIdMap = [
    'name' => 'name',
    'content' => 'content',
    'type' => 'type',
    'itilcategories_id' => 'itilcategories_id',
    'locations_id' => 'locations_id',
    'requester_user_id' => 'requester_user_id',
    'requesttypes_id' => 'requesttypes_id',
    'externalid' => 'externalid',
    '_groups_id_assign' => 'groups_assign',
    '_users_id_assign' => 'users_assign',
    '_users_id_observer' => 'users_observer',
    '_groups_id_observer' => 'groups_observer',
    '_filename' => 'filename',
    'filename' => 'filename',
    'tickettemplates_id' => 'tickettemplates_id',
    'urgency' => 'urgency',
    'impact' => 'impact',
];

$errorFieldMap = [
    'titulo' => 'name',
    'descricao' => 'content',
    'tipo' => 'type',
    'categoria' => 'itilcategories_id',
    'localizacao' => 'locations_id',
    'requerente' => 'requester_user_id',
    'origem' => 'requesttypes_id',
    'externo' => 'externalid',
    'grupo' => 'groups_assign',
    'tecnico' => 'users_assign',
    'observador' => 'users_observer',
    'grupo observador' => 'groups_observer',
    'ator' => 'users_assign',
    'anexo' => 'filename',
    'upload' => 'filename',
    'arquivo' => 'filename',
    'modelo' => 'tickettemplates_id',
    'urgencia' => 'urgency',
    'impacto' => 'impact',
];

$errorMap = array_fill_keys(array_keys($fieldIdMap), false);
$errorMap['filename'] = false;
$errorMap['tickettemplates_id'] = false;
$normalizedErrors = [];
foreach ($errors as $error) {
    if (is_array($error)) {
        $message = (string) ($error['message'] ?? $t('Revise este campo.'));
        $field = (string) ($error['field'] ?? '');
        $code = (string) ($error['code'] ?? 'invalid');
    } else {
        $message = (string) $error;
        $field = '';
        $code = 'legacy';
        $normalized = mb_strtolower($message, 'UTF-8');
        foreach ($errorFieldMap as $needle => $fieldId) {
            if (str_contains($normalized, $needle)) {
                $field = (string) array_search($fieldId, $fieldIdMap, true);
                if ($field === '') {
                    $field = $fieldId;
                }
                break;
            }
        }
    }

    $target = $fieldIdMap[$field] ?? $field;
    if ($target !== '' && isset($errorMap[$field])) {
        $errorMap[$field] = true;
    }
    if ($target !== '' && isset($errorMap[$target])) {
        $errorMap[$target] = true;
    }
    $normalizedErrors[] = [
        'field' => $field,
        'target' => $target,
        'code' => $code,
        'message' => $message,
    ];
}

$selectedUrgency = (int) ($values['urgency'] ?? 3);
$selectedImpact = (int) ($values['impact'] ?? 3);
$priorityPreview = $computePriorityPreview($selectedUrgency, $selectedImpact);
$selectedRequestSourceId = (int) ($values['requesttypes_id'] ?? $defaultRequestSourceId);

$errorFieldMap = [
    'titulo' => 'name',
    'descricao' => 'content',
    'tipo' => 'type',
    'categoria' => 'itilcategories_id',
    'localizacao' => 'locations_id',
    'origem' => 'requesttypes_id',
    'externo' => 'externalid',
    'grupo' => 'groups_assign',
    'anexo' => 'filename',
    'upload' => 'filename',
    'arquivo' => 'filename',
    'modelo' => 'tickettemplates_id',
];
?>
<section class="glpiacessivel-section-head" aria-labelledby="novo-chamado-titulo">
  <p class="glpiacessivel-eyebrow"><?= glpiacessivel_e($t('Abertura assistida')) ?></p>
  <h2 id="novo-chamado-titulo"><?= glpiacessivel_e($t('Abrir chamado')) ?></h2>
  <p><?= glpiacessivel_e($t('Formulário organizado em etapas: dados principais, propriedades do chamado, participantes e encaminhamento técnico.')) ?></p>
</section>

<?php if (!empty($submissionMetadata['partial_success']) && $partialCreatedTicketId > 0): ?>
  <div class="glpiacessivel-alert glpiacessivel-alert-warning" role="alert" aria-labelledby="partial-create-title">
    <strong id="partial-create-title"><?= glpiacessivel_e($t('Chamado criado; anexo pendente de confirmação')) ?></strong>
    <p><?= glpiacessivel_e($t('O chamado foi criado, mas o vínculo final do anexo ainda não foi confirmado pelo GLPI. Não envie novamente o formulário.')) ?></p>
    <a class="glpiacessivel-button glpiacessivel-button-secondary" href="<?= glpiacessivel_e(glpiacessivel_url('front/tickets.php?id=' . $partialCreatedTicketId)) ?>"><?= glpiacessivel_e($t('Abrir chamado criado')) ?></a>
  </div>
<?php endif; ?>

<?php if (!empty($serviceCatalog['available'])): ?>
  <div class="glpiacessivel-alert glpiacessivel-alert-warning glpiacessivel-ticket-create-fallback" role="status" aria-labelledby="service-catalog-fallback-title">
    <strong id="service-catalog-fallback-title"><?= glpiacessivel_e($t('Formulário de serviço')) ?></strong>
    <p><?= glpiacessivel_e((string) ($serviceCatalog['message'] ?? $t('Abra o formulário em página completa quando a solicitação exigir campos adicionais.'))) ?></p>
    <?php if (!empty($serviceCatalog['enabled']) && !empty($serviceCatalog['url'])): ?>
      <a class="glpiacessivel-button glpiacessivel-button-secondary" href="<?= glpiacessivel_e((string) $serviceCatalog['url']) ?>"><?= glpiacessivel_e($t('Abrir formulário em página completa')) ?></a>
    <?php endif; ?>
  </div>
<?php endif; ?>

<?php if ($requiresNativeFallback): ?>
  <div class="glpiacessivel-alert glpiacessivel-alert-warning glpiacessivel-ticket-create-fallback" role="status" aria-labelledby="portal-limitations-title">
    <strong id="portal-limitations-title"><?= glpiacessivel_e($t('Este formulário deve ser concluído em página completa nesta etapa.')) ?></strong>
    <ul>
      <?php foreach ($nativeFallbackReasons as $reason): ?>
        <li><?= glpiacessivel_e((string) $reason) ?></li>
      <?php endforeach; ?>
    </ul>
    <a class="glpiacessivel-button glpiacessivel-button-secondary" href="<?= glpiacessivel_e($nativeCreateTicketUrl) ?>"><?= glpiacessivel_e($t('Abrir formulário em página completa')) ?></a>
  </div>
<?php endif; ?>

<?php if (!empty($context['requester_selection_fallback'])): ?>
  <div class="glpiacessivel-alert glpiacessivel-alert-warning glpiacessivel-ticket-create-fallback" role="status" aria-labelledby="requester-selection-fallback-title">
    <strong id="requester-selection-fallback-title"><?= glpiacessivel_e($t('Abertura em nome de outra pessoa')) ?></strong>
    <p><?= glpiacessivel_e((string) ($context['requester_selection_message'] ?? $t('Use o formulário nativo em página completa para alterar o requerente.'))) ?></p>
    <a class="glpiacessivel-button glpiacessivel-button-secondary" href="<?= glpiacessivel_e($nativeCreateTicketUrl) ?>"><?= glpiacessivel_e($t('Abrir formulário nativo')) ?></a>
  </div>
<?php endif; ?>

<?php if ($errors !== []): ?>
  <div class="glpiacessivel-alert glpiacessivel-alert-error" role="alert" aria-live="assertive" id="form-errors" tabindex="-1">
    <strong><?= glpiacessivel_e($t('Revise os dados informados.')) ?></strong>
    <ul class="glpiacessivel-error-list">
      <?php foreach ($normalizedErrors as $error): ?>
        <?php $target = (string) ($error['target'] ?? ''); ?>
        <li>
          <?php if ($target !== ''): ?>
            <a href="#<?= glpiacessivel_e($target) ?>"><?= glpiacessivel_e((string) ($error['message'] ?? $t('Revise este campo.'))) ?></a>
          <?php else: ?>
            <?= glpiacessivel_e((string) ($error['message'] ?? $t('Revise este campo.'))) ?>
          <?php endif; ?>
        </li>
      <?php endforeach; ?>
    </ul>
  </div>
<?php endif; ?>

<section class="glpiacessivel-card glpiacessivel-open-ticket-card" aria-labelledby="novo-chamado-formulario">
  <div class="glpiacessivel-open-ticket-header">
    <div>
      <p class="glpiacessivel-eyebrow"><?= glpiacessivel_e($t('Novo chamado')) ?></p>
      <h3 id="novo-chamado-formulario"><?= glpiacessivel_e($t('Registro inicial do chamado')) ?></h3>
      <p class="glpiacessivel-help-text"><?= glpiacessivel_e($t('O GLPI registra o chamado com seu perfil, sua entidade ativa e suas permissões. A tela mantém leitura simplificada e navegação por teclado.')) ?></p>
    </div>
    <section class="glpiacessivel-ticket-create-meta" aria-labelledby="ticket-create-context-title" role="region">
      <h3 id="ticket-create-context-title" class="glpiacessivel-sr-only"><?= glpiacessivel_e($t('Contexto do chamado')) ?></h3>
      <div class="glpiacessivel-ticket-create-chip">
        <span><?= glpiacessivel_e($t('Entidade ativa')) ?></span>
        <strong><?= glpiacessivel_e($context['entity_name'] ?? $t('Entidade atual')) ?></strong>
      </div>
      <div class="glpiacessivel-ticket-create-chip">
        <span><?= glpiacessivel_e($t('Requerente')) ?></span>
        <strong id="ticket-create-requester-name"><?= glpiacessivel_e($effectiveRequesterName) ?></strong>
      </div>
    </section>
  </div>

  <form
    method="post"
    action="<?= glpiacessivel_e(glpiacessivel_url('front/ticket.create.php')) ?>"
    class="glpiacessivel-open-ticket-form"
    id="glpiacessivel-open-ticket-form"
    enctype="multipart/form-data"
    novalidate
    <?php if ($resourceSelectorEnabled): ?>
      data-resource-selector-url="<?= glpiacessivel_e($resourceSelectorUrl) ?>"
      data-resource-selector-csrf="<?= glpiacessivel_e($csrf_token) ?>"
      data-resource-selector-context-revision="<?= glpiacessivel_e((string) ($resourceSelectorConfig['context_revision'] ?? '')) ?>"
      data-resource-selector-version="1"
      data-resource-selector-timeout="<?= max(500, min(5000, (int) ($resourceSelectorConfig['timeout_ms'] ?? $resourceSelectorConfig['request_timeout_ms'] ?? 5000))) ?>"
      data-resource-selector-limit="<?= max(1, min(20, (int) ($resourceSelectorConfig['page_size'] ?? 20))) ?>"
      data-resource-selector-fallback-url="<?= glpiacessivel_e($nativeCreateTicketUrl) ?>"
      data-resource-selector-error-summary="#create-selector-errors"
    <?php endif; ?>
  >
    <input type="hidden" name="_glpi_csrf_token" value="<?= glpiacessivel_e($csrf_token) ?>" />
    <?php if ($dynamicFormSchema !== []): ?>
      <input type="hidden" name="dynamic_form_schema_id" value="<?= glpiacessivel_e((string) ($dynamicFormSchema['id'] ?? '')) ?>" />
      <input type="hidden" name="dynamic_form_source" value="<?= glpiacessivel_e((string) ($dynamicFormSchema['source'] ?? 'native_ticket')) ?>" />
    <?php endif; ?>
    <div id="create-live-region" class="glpiacessivel-sr-only" aria-live="polite" aria-atomic="true"></div>
    <?php if ($resourceSelectorEnabled): ?>
      <div id="create-selector-errors" class="glpiacessivel-alert glpiacessivel-alert-error" role="alert" tabindex="-1" hidden>
        <strong><?= glpiacessivel_e($t('Revise os seletores pesquisáveis.')) ?></strong>
        <ul class="glpiacessivel-error-list"></ul>
      </div>
    <?php endif; ?>

    <div class="glpiacessivel-ticket-create-shell">
      <div class="glpiacessivel-ticket-create-main" id="conteudo-principal-chamado">
        <div class="glpiacessivel-ticket-create-entity" role="status" aria-live="polite">
          <span class="glpiacessivel-ticket-create-avatar" aria-hidden="true"><?= glpiacessivel_e(mb_strtoupper(mb_substr($effectiveRequesterName !== '' ? $effectiveRequesterName : 'GL', 0, 2, 'UTF-8'), 'UTF-8')) ?></span>
          <div>
            <strong><?= glpiacessivel_e($t('Chamado será adicionado na entidade')) ?></strong>
            <span><?= glpiacessivel_e($context['entity_name'] ?? $t('Entidade atual')) ?></span>
          </div>
        </div>

        <fieldset class="glpiacessivel-form-fieldset glpiacessivel-ticket-create-panel glpiacessivel-ticket-create-panel-primary">
          <legend><?= glpiacessivel_e($t('Chamado')) ?></legend>
          <div class="glpiacessivel-open-ticket-grid">
            <div class="glpiacessivel-field glpiacessivel-open-ticket-title">
              <label for="name"><?= glpiacessivel_e($fieldLabel('name', $t('Título'))) ?><?= $requiredMark('name', true) ?></label>
              <input
                id="name"
                type="text"
                name="name"
                maxlength="255"<?= $requiredAttrs('name', true) ?><?= $stateAttrs('name') ?>
                aria-describedby="name-help<?= $errorMap['name'] ? ' form-errors' : '' ?>"
                aria-invalid="<?= $errorMap['name'] ? 'true' : 'false' ?>"
                value="<?= glpiacessivel_e($values['name'] ?? '') ?>"
              />
              <small id="name-help" class="glpiacessivel-help-text"><?= glpiacessivel_e($t('Informe o assunto do chamado de forma objetiva, como aparece para a central de serviços.')) ?></small>
            </div>

            <div class="glpiacessivel-field glpiacessivel-open-ticket-description">
              <label for="content"><?= glpiacessivel_e($fieldLabel('content', $t('Descrição'))) ?><?= $requiredMark('content', true) ?></label>
              <textarea
                id="content"
                name="content"<?= $requiredAttrs('content', true) ?><?= $stateAttrs('content') ?>
                aria-describedby="content-help<?= $errorMap['content'] ? ' form-errors' : '' ?>"
                aria-invalid="<?= $errorMap['content'] ? 'true' : 'false' ?>"
              ><?= glpiacessivel_e($values['content'] ?? '') ?></textarea>
              <small id="content-help" class="glpiacessivel-help-text"><?= glpiacessivel_e($t('Explique o problema, informe contexto, evidências e impacto. Se houver urgência operacional, descreva o efeito no serviço.')) ?></small>
            </div>
          </div>

          <div class="glpiacessivel-field glpiacessivel-ticket-create-upload-note">
            <label for="filename"><?= glpiacessivel_e($fieldLabel('_filename', $t('Anexos'))) ?><?= $requiredMark('_filename') ?></label>
            <input
              id="filename"
              type="file"
              name="filename[]"
              multiple<?= $requiredAttrs('_filename') ?>
              aria-describedby="filename-help<?= $errorMap['filename'] ? ' form-errors' : '' ?>"
              aria-invalid="<?= $errorMap['filename'] ? 'true' : 'false' ?>"
              data-glpiacessivel-file-input
            />
            <small id="filename-help" class="glpiacessivel-help-text"><?= glpiacessivel_e($t('Opcional. O GLPI anexa os arquivos respeitando os tipos e limites configurados pela central.')) ?></small>
            <div class="glpiacessivel-file-actions">
              <button type="button" class="glpiacessivel-button glpiacessivel-button-secondary" data-glpiacessivel-file-clear><?= glpiacessivel_e($t('Limpar anexos')) ?></button>
            </div>
            <ul class="glpiacessivel-file-list" data-glpiacessivel-file-list aria-live="polite"></ul>
          </div>
        </fieldset>
      </div>

      <aside class="glpiacessivel-ticket-create-aside" aria-label="<?= glpiacessivel_e($t('Propriedades e atores do chamado')) ?>">
        <fieldset class="glpiacessivel-form-fieldset glpiacessivel-ticket-create-panel glpiacessivel-ticket-create-panel-side">
          <legend><?= glpiacessivel_e($t('Propriedades do chamado')) ?></legend>
          <div class="glpiacessivel-ticket-create-side-grid">
            <div class="glpiacessivel-field glpiacessivel-ticket-create-readonly">
              <span class="glpiacessivel-label-like"><?= glpiacessivel_e($t('Data de abertura')) ?></span>
              <output><?= glpiacessivel_e($context['opening_date_preview'] ?? date('d/m/Y H:i')) ?></output>
            </div>

            <div class="glpiacessivel-field">
              <label for="type"><?= glpiacessivel_e($fieldLabel('type', $t('Tipo'))) ?><?= $requiredMark('type', true) ?></label>
              <select id="type" name="type"<?= $requiredAttrs('type', true) ?><?= $selectStateAttrs('type') ?> aria-describedby="<?= $errorMap['type'] ? 'form-errors' : 'type-help' ?>" aria-invalid="<?= $errorMap['type'] ? 'true' : 'false' ?>">
                <?php foreach ($typeOptions as $option): ?>
                  <option value="<?= (int) $option['id'] ?>"<?= ((int) ($values['type'] ?? 0) === (int) $option['id']) ? ' selected' : '' ?>>
                    <?= glpiacessivel_e($option['label']) ?>
                  </option>
                <?php endforeach; ?>
              </select>
              <?= $lockedSelectHidden('type', 'type', (int) ($values['type'] ?? ($typeOptions[0]['id'] ?? 1))) ?>
              <small id="type-help" class="glpiacessivel-help-text"><?= glpiacessivel_e($t('A categoria se ajusta automaticamente ao tipo.')) ?><?= $fieldReadonly('type') ? ' ' . glpiacessivel_e($t('Valor definido pelo modelo de chamado; use a página completa para alterá-lo.')) : '' ?></small>
            </div>

            <div class="glpiacessivel-field">
              <label for="itilcategories_id"><?= glpiacessivel_e($fieldLabel('itilcategories_id', $t('Categoria'))) ?><?= $requiredMark('itilcategories_id') ?></label>
              <select
                id="itilcategories_id"
                name="itilcategories_id"<?= $requiredAttrs('itilcategories_id') ?><?= $selectStateAttrs('itilcategories_id') ?>
                aria-describedby="category-help<?= $errorMap['itilcategories_id'] ? ' form-errors' : '' ?>"
                aria-invalid="<?= $errorMap['itilcategories_id'] ? 'true' : 'false' ?>"
                <?php if ($resourceSelectorEnabled): ?>
                  data-glpiacessivel-resource-select
                  data-resource-provider="category"
                  data-resource-min-chars="0"
                  data-resource-browse-empty="1"
                  data-resource-empty-value="0"
                  data-resource-dependencies="ticket_type:#type"
                  data-resource-clear-on-dependency="1"
                <?php endif; ?>
              >
                <option value="0"><?= glpiacessivel_e($t('Selecione se souber')) ?></option>
                <?php foreach ($categories as $category): ?>
                  <?php if ($resourceSelectorEnabled && (int) ($values['itilcategories_id'] ?? 0) !== (int) $category['id']) { continue; } ?>
                  <option
                    value="<?= (int) $category['id'] ?>"
                    data-incident="<?= !empty($category['is_incident']) ? '1' : '0' ?>"
                    data-request="<?= !empty($category['is_request']) ? '1' : '0' ?>"
                    <?= ((int) ($values['itilcategories_id'] ?? 0) === (int) $category['id']) ? ' selected' : '' ?>
                  >
                    <?= glpiacessivel_e($category['label']) ?>
                  </option>
                <?php endforeach; ?>
              </select>
              <?= $lockedSelectHidden('itilcategories_id', 'itilcategories_id', (int) ($values['itilcategories_id'] ?? 0)) ?>
              <small id="category-help" class="glpiacessivel-help-text"><?= glpiacessivel_e($t('Carregada do GLPI conforme entidade, perfil e tipo do chamado.')) ?><?= $fieldReadonly('itilcategories_id') ? ' ' . glpiacessivel_e($t('Valor definido pelo modelo de chamado; use a página completa para alterá-lo.')) : '' ?></small>
            </div>

            <?php if ($ticketTemplates !== []): ?>
              <div class="glpiacessivel-field glpiacessivel-ticket-template-field">
                <label for="tickettemplates_id"><?= glpiacessivel_e($fieldLabel('tickettemplates_id', $t('Modelo de chamado'))) ?><?= $requiredMark('tickettemplates_id') ?></label>
                <select
                  id="tickettemplates_id"
                  name="tickettemplates_id"
                  data-glpiacessivel-ticket-template
                  aria-describedby="tickettemplates-help tickettemplates-status<?= $errorMap['tickettemplates_id'] ? ' form-errors' : '' ?>"
                  aria-invalid="<?= $errorMap['tickettemplates_id'] ? 'true' : 'false' ?>"
                >
                  <option value="0"><?= glpiacessivel_e($t('Sem modelo')) ?></option>
                  <?php foreach ($ticketTemplates as $template): ?>
                    <?php $templateId = (int) ($template['id'] ?? 0); ?>
                    <?php $templateRequiresNativeFallback = !empty($templateMetadataPayload[(string) $templateId]['requiresNativeFallback']); ?>
                    <option
                      value="<?= $templateId ?>"
                      data-requires-native-fallback="<?= $templateRequiresNativeFallback ? '1' : '0' ?>"
                      <?= $selectedTemplateId === $templateId ? ' selected' : '' ?>
                    >
                      <?= glpiacessivel_e((string) ($template['label'] ?? (sprintf($t('Modelo #%d'), $templateId)))) ?><?= $templateRequiresNativeFallback ? glpiacessivel_e($t(' — requer página completa')) : '' ?>
                    </option>
                  <?php endforeach; ?>
                </select>
                <small id="tickettemplates-help" class="glpiacessivel-help-text"><?= glpiacessivel_e($t('Aplica valores padrão e campos obrigatórios do modelo quando o subconjunto é suportado pelo portal.')) ?></small>
                <p id="tickettemplates-status" class="glpiacessivel-template-status" role="status" aria-live="polite">
                  <?php if ($selectedTemplate !== null && !empty($templateMetadataPayload[(string) $selectedTemplateId]['requiresNativeFallback'])): ?>
                    <?= glpiacessivel_e($t('O modelo selecionado exige campos adicionais. Abra o formulário em página completa.')) ?>
                  <?php elseif ($selectedTemplate !== null): ?>
                    <?= glpiacessivel_e($t('Modelo selecionado será validado antes da criação. Campos de título e descrição não são sobrescritos.')) ?>
                  <?php else: ?>
                    <?= glpiacessivel_e($t('Nenhum modelo de chamado selecionado.')) ?>
                  <?php endif; ?>
                </p>
              </div>
            <?php endif; ?>

            <div class="glpiacessivel-field glpiacessivel-ticket-create-readonly">
              <span class="glpiacessivel-label-like"><?= glpiacessivel_e($t('Status')) ?></span>
              <output><span class="glpiacessivel-status-dot" aria-hidden="true"></span><?= glpiacessivel_e($t('Novo')) ?></output>
            </div>

            <div class="glpiacessivel-field">
              <label for="requesttypes_id"><?= glpiacessivel_e($fieldLabel('requesttypes_id', $t('Origem da requisição'))) ?><?= $requiredMark('requesttypes_id') ?></label>
              <select id="requesttypes_id" name="requesttypes_id"<?= $requestSourceSupported ? '' : ' disabled' ?> aria-describedby="<?= $errorMap['requesttypes_id'] ? 'form-errors' : 'requesttypes-help' ?>" aria-invalid="<?= $errorMap['requesttypes_id'] ? 'true' : 'false' ?>">
                <?php foreach ($requestSourceOptions as $option): ?>
                  <option value="<?= (int) $option['id'] ?>"<?= $selectedRequestSourceId === (int) $option['id'] ? ' selected' : '' ?>>
                    <?= glpiacessivel_e((string) $option['label']) ?>
                  </option>
                <?php endforeach; ?>
              </select>
              <?php if (!$requestSourceSupported): ?>
                <input type="hidden" name="requesttypes_id" value="<?= $selectedRequestSourceId ?>" />
              <?php endif; ?>
              <small id="requesttypes-help" class="glpiacessivel-help-text"><?= glpiacessivel_e($requestSourceSupported ? $t('Mantida no chamado criado conforme configuração do GLPI.') : $t('Esta instalação não permite alterar a origem; o chamado será criado com a origem padrão.')) ?></small>
            </div>

            <div class="glpiacessivel-field">
              <label for="urgency"><?= glpiacessivel_e($fieldLabel('urgency', $t('Urgência'))) ?><?= $requiredMark('urgency', true) ?></label>
              <select id="urgency" name="urgency"<?= $requiredAttrs('urgency', true) ?><?= $selectStateAttrs('urgency') ?> aria-describedby="<?= $errorMap['urgency'] ? 'form-errors' : 'urgency-help' ?>" aria-invalid="<?= $errorMap['urgency'] ? 'true' : 'false' ?>">
                <?php foreach ($urgencyOptions as $option): ?>
                  <option value="<?= (int) $option['id'] ?>"<?= $selectedUrgency === (int) $option['id'] ? ' selected' : '' ?>>
                    <?= glpiacessivel_e($option['label']) ?>
                  </option>
                <?php endforeach; ?>
              </select>
              <?= $lockedSelectHidden('urgency', 'urgency', $selectedUrgency) ?>
              <small id="urgency-help" class="glpiacessivel-help-text"><?= glpiacessivel_e($t('Informe a urgência percebida para apoiar o cálculo de prioridade.')) ?><?= $fieldReadonly('urgency') ? ' ' . glpiacessivel_e($t('Valor definido pelo modelo de chamado; use a página completa para alterá-lo.')) : '' ?></small>
            </div>

            <div class="glpiacessivel-field">
              <label for="impact"><?= glpiacessivel_e($fieldLabel('impact', $t('Impacto'))) ?><?= $requiredMark('impact', true) ?></label>
              <select id="impact" name="impact"<?= $requiredAttrs('impact', true) ?><?= $selectStateAttrs('impact') ?> aria-describedby="<?= $errorMap['impact'] ? 'form-errors' : 'impact-help' ?>" aria-invalid="<?= $errorMap['impact'] ? 'true' : 'false' ?>">
                <?php foreach ($impactOptions as $option): ?>
                  <option value="<?= (int) $option['id'] ?>"<?= $selectedImpact === (int) $option['id'] ? ' selected' : '' ?>>
                    <?= glpiacessivel_e($option['label']) ?>
                  </option>
                <?php endforeach; ?>
              </select>
              <?= $lockedSelectHidden('impact', 'impact', $selectedImpact) ?>
              <small id="impact-help" class="glpiacessivel-help-text"><?= glpiacessivel_e($t('Informe o impacto no serviço ou atividade afetada.')) ?><?= $fieldReadonly('impact') ? ' ' . glpiacessivel_e($t('Valor definido pelo modelo de chamado; use a página completa para alterá-lo.')) : '' ?></small>
            </div>

            <div class="glpiacessivel-field glpiacessivel-ticket-create-readonly">
              <span class="glpiacessivel-label-like"><?= glpiacessivel_e($t('Prioridade')) ?></span>
              <output id="priority-preview" class="glpiacessivel-badge glpiacessivel-badge-priority-medium"><?= glpiacessivel_e($priorityPreview) ?></output>
            </div>

            <div class="glpiacessivel-field">
              <label for="locations_id"><?= glpiacessivel_e($fieldLabel('locations_id', $t('Localização'))) ?><?= $requiredMark('locations_id') ?></label>
              <select
                id="locations_id"
                name="locations_id"<?= $requiredAttrs('locations_id') ?><?= $selectStateAttrs('locations_id') ?>
                aria-describedby="<?= $errorMap['locations_id'] ? 'form-errors' : 'locations-help' ?>"
                aria-invalid="<?= $errorMap['locations_id'] ? 'true' : 'false' ?>"
                <?php if ($resourceSelectorEnabled): ?>
                  data-glpiacessivel-resource-select
                  data-resource-provider="location"
                  data-resource-min-chars="0"
                  data-resource-browse-empty="1"
                  data-resource-empty-value="0"
                <?php endif; ?>
              >
                <option value="0"><?= glpiacessivel_e($t('Não informar agora')) ?></option>
                <?php foreach ($locations as $location): ?>
                  <?php if ($resourceSelectorEnabled && (int) ($values['locations_id'] ?? 0) !== (int) $location['id']) { continue; } ?>
                  <option value="<?= (int) $location['id'] ?>"<?= ((int) ($values['locations_id'] ?? 0) === (int) $location['id']) ? ' selected' : '' ?>>
                    <?= glpiacessivel_e((string) $location['label']) ?>
                  </option>
                <?php endforeach; ?>
              </select>
              <?= $lockedSelectHidden('locations_id', 'locations_id', (int) ($values['locations_id'] ?? 0)) ?>
              <small id="locations-help" class="glpiacessivel-help-text"><?= glpiacessivel_e($t('Carregada do GLPI conforme a entidade ativa.')) ?><?= $fieldReadonly('locations_id') ? ' ' . glpiacessivel_e($t('Valor definido pelo modelo de chamado; use a página completa para alterá-lo.')) : '' ?></small>
            </div>

            <div class="glpiacessivel-field glpiacessivel-ticket-create-readonly">
              <span class="glpiacessivel-label-like"><?= glpiacessivel_e($t('Duração total')) ?></span>
              <output><?= glpiacessivel_e($context['duration_total_help'] ?? $t('Acompanhada após a abertura.')) ?></output>
            </div>

            <div class="glpiacessivel-field">
              <label for="externalid"><?= glpiacessivel_e($fieldLabel('externalid', $t('ID externo'))) ?><?= $requiredMark('externalid') ?></label>
              <input
                id="externalid"
                type="text"
                name="externalid"
                maxlength="255"
                value="<?= glpiacessivel_e((string) ($values['externalid'] ?? '')) ?>"
                <?= $externalIdSupported ? '' : 'disabled' ?>
                aria-describedby="<?= $errorMap['externalid'] ? 'form-errors' : 'externalid-help' ?>"
                aria-invalid="<?= $errorMap['externalid'] ? 'true' : 'false' ?>"
              />
              <?php if (!$externalIdSupported): ?>
                <input type="hidden" name="externalid" value="" />
              <?php endif; ?>
              <small id="externalid-help" class="glpiacessivel-help-text"><?= glpiacessivel_e($externalIdSupported ? $t('Use quando o chamado estiver vinculado a outro sistema.') : $t('Campo não suportado nesta instalação do GLPI.')) ?></small>
            </div>
          </div>
        </fieldset>

        <fieldset class="glpiacessivel-form-fieldset glpiacessivel-ticket-create-panel glpiacessivel-ticket-create-panel-side glpiacessivel-ticket-create-actors">
          <legend><?= glpiacessivel_e($t('Atores')) ?></legend>
          <?php if ($requesterEditable): ?>
            <div class="glpiacessivel-field">
              <label for="requester_user_id"><?= glpiacessivel_e($t('Abrir chamado em nome de')) ?></label>
              <select
                id="requester_user_id"
                name="requester_user_id"
                required
                aria-required="true"
                aria-describedby="requester-user-help<?= $errorMap['requester_user_id'] ? ' form-errors' : '' ?>"
                aria-invalid="<?= $errorMap['requester_user_id'] ? 'true' : 'false' ?>"
                data-glpiacessivel-resource-select
                data-resource-provider="requester_user"
                data-resource-min-chars="2"
              >
                <?php foreach ($requesterUsers as $requesterUser): ?>
                  <?php $requesterOptionId = (int) ($requesterUser['id'] ?? 0); ?>
                  <option value="<?= $requesterOptionId ?>"<?= $requesterOptionId === $selectedRequesterId ? ' selected' : '' ?>>
                    <?= glpiacessivel_e((string) ($requesterUser['label'] ?? ('#' . $requesterOptionId))) ?>
                  </option>
                <?php endforeach; ?>
              </select>
              <small id="requester-user-help" class="glpiacessivel-help-text"><?= glpiacessivel_e($t('Digite o nome ou o usuário, com pelo menos dois caracteres. Os resultados respeitam a entidade ativa e a capacidade nativa de delegação; mantenha seu nome para abrir para você.')) ?></small>
            </div>
          <?php else: ?>
            <input type="hidden" name="requester_user_id" value="<?= $currentRequesterId ?>" />
            <div class="glpiacessivel-field glpiacessivel-ticket-create-readonly">
              <span class="glpiacessivel-label-like"><?= glpiacessivel_e($t('Requerente')) ?></span>
              <output><?= glpiacessivel_e((string) ($context['requester_name'] ?? '')) ?></output>
              <small class="glpiacessivel-help-text"><?= glpiacessivel_e((string) ($context['requester_selection_message'] ?? $t('O requerente permanece no usuário autenticado.'))) ?></small>
            </div>
          <?php endif; ?>

          <details class="glpiacessivel-open-ticket-advanced">
            <summary>
              <span><?= glpiacessivel_e($t('Encaminhamento técnico')) ?></span>
              <small><?= glpiacessivel_e($t('Opcional. Direcione grupo, técnico ou observadores quando necessário.')) ?></small>
            </summary>
            <p class="glpiacessivel-help-text glpiacessivel-ticket-create-routing-intro">
              <?= glpiacessivel_e($t('Marque ou adicione atores do chamado como no GLPI. Com JavaScript ativo, use busca, adicionar e remover; sem JavaScript, os campos abaixo continuam como listas de seleção múltipla.')) ?>
            </p>
            <div class="glpiacessivel-ticket-create-routing-grid">
              <?php if ($groupAssignmentSupported): ?>
                <div class="glpiacessivel-field glpiacessivel-actor-field">
                  <label for="groups_assign"><?= glpiacessivel_e($fieldLabel('_groups_id_assign', $t('Grupo técnico'))) ?><?= $requiredMark('_groups_id_assign') ?></label>
                  <select
                    id="groups_assign"
                    class="glpiacessivel-actor-native-select"
                    name="_groups_id_assign[]"
                    multiple
                    size="4"
                    data-glpiacessivel-actor-select
                    data-actor-kind="<?= glpiacessivel_e($t('grupo técnico')) ?>"
                    data-actor-add-label="<?= glpiacessivel_e($t('Adicionar grupo técnico')) ?>"
                    data-actor-search-label="<?= glpiacessivel_e($t('Filtrar grupos técnicos')) ?>"
                    data-actor-empty-label="<?= glpiacessivel_e($t('Nenhum grupo técnico selecionado.')) ?>"
                    <?php if ($resourceSelectorEnabled): ?>
                      data-glpiacessivel-resource-select
                      data-resource-provider="assigned_group"
                      data-resource-min-chars="2"
                    <?php endif; ?>
                    <?= $requiredAttrs('_groups_id_assign') ?><?= $selectStateAttrs('_groups_id_assign') ?> aria-describedby="<?= $errorMap['_groups_id_assign'] ? 'form-errors' : 'groups-help' ?>"
                    aria-invalid="<?= $errorMap['_groups_id_assign'] ? 'true' : 'false' ?>"
                  >
                    <?php foreach ($groups as $group): ?>
                      <?php $selected = in_array((int) $group['id'], array_map('intval', (array) ($values['_groups_id_assign'] ?? [])), true); ?>
                      <?php if ($resourceSelectorEnabled && !$selected) { continue; } ?>
                      <option value="<?= (int) $group['id'] ?>"<?= $selected ? ' selected' : '' ?>>
                        <?= glpiacessivel_e((string) $group['label']) ?>
                      </option>
                    <?php endforeach; ?>
                  </select>
                  <?= $lockedSelectHidden('_groups_id_assign', '_groups_id_assign[]', (array) ($values['_groups_id_assign'] ?? [])) ?>
                  <small id="groups-help" class="glpiacessivel-help-text"><?= glpiacessivel_e($t('Seleção opcional para direcionar o atendimento ao grupo técnico correspondente. Para selecionar vários itens, use Ctrl no computador.')) ?><?= $fieldReadonly('_groups_id_assign') ? ' ' . glpiacessivel_e($t('Valor definido pelo modelo de chamado; use a página completa para alterá-lo.')) : '' ?></small>
                </div>
              <?php endif; ?>

              <div class="glpiacessivel-field glpiacessivel-actor-field">
                <label for="users_assign"><?= glpiacessivel_e($fieldLabel('_users_id_assign', $t('Atribuir para'))) ?><?= $requiredMark('_users_id_assign') ?></label>
                <select
                  id="users_assign"
                  class="glpiacessivel-actor-native-select"
                  name="_users_id_assign[]"
                  multiple
                  size="4"
                  data-glpiacessivel-actor-select
                  data-actor-kind="<?= glpiacessivel_e($t('técnico atribuído')) ?>"
                  data-actor-add-label="<?= glpiacessivel_e($t('Adicionar técnico')) ?>"
                  data-actor-search-label="<?= glpiacessivel_e($t('Filtrar técnicos')) ?>"
                  data-actor-empty-label="<?= glpiacessivel_e($t('Nenhum técnico selecionado.')) ?>"
                  <?php if ($resourceSelectorEnabled): ?>
                    data-glpiacessivel-resource-select
                    data-resource-provider="assigned_user"
                    data-resource-min-chars="2"
                  <?php endif; ?>
                  <?= $requiredAttrs('_users_id_assign') ?><?= $selectStateAttrs('_users_id_assign') ?> aria-describedby="users-assign-help"
                >
                  <?php foreach ($assignedUsers as $user): ?>
                    <?php $selected = in_array((int) $user['id'], array_map('intval', (array) ($values['_users_id_assign'] ?? [])), true); ?>
                    <?php if ($resourceSelectorEnabled && !$selected) { continue; } ?>
                    <option value="<?= (int) $user['id'] ?>"<?= $selected ? ' selected' : '' ?>>
                      <?= glpiacessivel_e((string) $user['label']) ?>
                    </option>
                  <?php endforeach; ?>
                </select>
                <?= $lockedSelectHidden('_users_id_assign', '_users_id_assign[]', (array) ($values['_users_id_assign'] ?? [])) ?>
                <small id="users-assign-help" class="glpiacessivel-help-text"><?= glpiacessivel_e($t('Opcional. Use quando quiser atribuir o chamado a um técnico específico. Para selecionar vários itens, use Ctrl no computador.')) ?><?= $fieldReadonly('_users_id_assign') ? ' ' . glpiacessivel_e($t('Valor definido pelo modelo de chamado; use a página completa para alterá-lo.')) : '' ?></small>
              </div>

              <div class="glpiacessivel-field glpiacessivel-actor-field">
                <label for="users_observer"><?= glpiacessivel_e($fieldLabel('_users_id_observer', $t('Adicionar observador'))) ?><?= $requiredMark('_users_id_observer') ?></label>
                <select
                  id="users_observer"
                  class="glpiacessivel-actor-native-select"
                  name="_users_id_observer[]"
                  multiple
                  size="4"
                  data-glpiacessivel-actor-select
                  data-actor-kind="<?= glpiacessivel_e($t('observador')) ?>"
                  data-actor-add-label="<?= glpiacessivel_e($t('Adicionar observador')) ?>"
                  data-actor-search-label="<?= glpiacessivel_e($t('Filtrar observadores')) ?>"
                  data-actor-empty-label="<?= glpiacessivel_e($t('Nenhum observador selecionado.')) ?>"
                  <?php if ($resourceSelectorEnabled): ?>
                    data-glpiacessivel-resource-select
                    data-resource-provider="observer_user"
                    data-resource-min-chars="2"
                  <?php endif; ?>
                  <?= $requiredAttrs('_users_id_observer') ?><?= $selectStateAttrs('_users_id_observer') ?> aria-describedby="users-observer-help"
                >
                  <?php foreach ($observerUsers as $user): ?>
                    <?php $selected = in_array((int) $user['id'], array_map('intval', (array) ($values['_users_id_observer'] ?? [])), true); ?>
                    <?php if ($resourceSelectorEnabled && !$selected) { continue; } ?>
                    <option value="<?= (int) $user['id'] ?>"<?= $selected ? ' selected' : '' ?>>
                      <?= glpiacessivel_e((string) $user['label']) ?>
                    </option>
                  <?php endforeach; ?>
                </select>
                <?= $lockedSelectHidden('_users_id_observer', '_users_id_observer[]', (array) ($values['_users_id_observer'] ?? [])) ?>
                <small id="users-observer-help" class="glpiacessivel-help-text"><?= glpiacessivel_e($t('Inclui pessoas que devem acompanhar o andamento do chamado.')) ?><?= $fieldReadonly('_users_id_observer') ? ' ' . glpiacessivel_e($t('Valor definido pelo modelo de chamado; use a página completa para alterá-lo.')) : '' ?></small>
              </div>
              <div class="glpiacessivel-field glpiacessivel-actor-field">
                <label for="groups_observer"><?= glpiacessivel_e($fieldLabel('_groups_id_observer', $t('Adicionar grupos observadores'))) ?><?= $requiredMark('_groups_id_observer') ?></label>
                <select
                  id="groups_observer"
                  class="glpiacessivel-actor-native-select"
                  name="_groups_id_observer[]"
                  multiple
                  size="4"
                  data-glpiacessivel-actor-select
                  data-actor-kind="<?= glpiacessivel_e($t('grupo observador')) ?>"
                  data-actor-add-label="<?= glpiacessivel_e($t('Adicionar grupo observador')) ?>"
                  data-actor-search-label="<?= glpiacessivel_e($t('Filtrar grupos observadores')) ?>"
                  data-actor-empty-label="<?= glpiacessivel_e($t('Nenhum grupo observador selecionado.')) ?>"
                  <?php if ($resourceSelectorEnabled): ?>
                    data-glpiacessivel-resource-select
                    data-resource-provider="observer_group"
                    data-resource-min-chars="2"
                  <?php endif; ?>
                  <?= $requiredAttrs('_groups_id_observer') ?><?= $selectStateAttrs('_groups_id_observer') ?> aria-describedby="groups-observer-help"
                >
                  <?php foreach ($observerGroups as $group): ?>
                    <?php $selected = in_array((int) $group['id'], array_map('intval', (array) ($values['_groups_id_observer'] ?? [])), true); ?>
                    <?php if ($resourceSelectorEnabled && !$selected) { continue; } ?>
                    <option value="<?= (int) $group['id'] ?>"<?= $selected ? ' selected' : '' ?>>
                      <?= glpiacessivel_e((string) $group['label']) ?>
                    </option>
                  <?php endforeach; ?>
                </select>
                <?= $lockedSelectHidden('_groups_id_observer', '_groups_id_observer[]', (array) ($values['_groups_id_observer'] ?? [])) ?>
                <small id="groups-observer-help" class="glpiacessivel-help-text"><?= glpiacessivel_e($t('Inclui grupos cujos integrantes devem acompanhar o chamado sem assumir o atendimento.')) ?><?= $fieldReadonly('_groups_id_observer') ? ' ' . glpiacessivel_e($t('Valor definido pelo modelo de chamado; use a página completa para alterá-lo.')) : '' ?></small>
              </div>
            </div>
          </details>
        </fieldset>
      </aside>
    </div>

    <div class="glpiacessivel-ticket-create-actions">
      <button type="submit" class="glpiacessivel-button glpiacessivel-button-primary"><?= glpiacessivel_e($t('Registrar chamado')) ?></button>
      <button type="reset" class="glpiacessivel-button glpiacessivel-button-secondary"><?= glpiacessivel_e($t('Limpar formulário')) ?></button>
      <a class="glpiacessivel-button glpiacessivel-button-secondary" href="<?= glpiacessivel_e($nativeCreateTicketUrl) ?>">
        <?= glpiacessivel_e($t('Abrir formulário em página completa')) ?>
      </a>
    </div>
  </form>
</section>

<?php if ($resourceSelectorEnabled): ?>
  <script src="<?= glpiacessivel_e($resourceSelectorAssetUrl) ?>"></script>
<?php endif; ?>
<script>
  (function () {
    var typeField = document.getElementById('type');
    var categoryField = document.getElementById('itilcategories_id');
    var urgencyField = document.getElementById('urgency');
    var impactField = document.getElementById('impact');
    var requestSourceField = document.getElementById('requesttypes_id');
    var requestSourcePreview = document.getElementById('request-source-preview');
    var priorityPreview = document.getElementById('priority-preview');
    var requesterField = document.getElementById('requester_user_id');
    var requesterPreview = document.getElementById('ticket-create-requester-name');
    var form = document.getElementById('glpiacessivel-open-ticket-form');
    var liveRegion = document.getElementById('create-live-region');
    var errorSummary = document.getElementById('form-errors');

    function message(key, replacements, fallback) {
      var catalog = window.__glpiacessivelI18n && window.__glpiacessivelI18n.messages
        ? window.__glpiacessivelI18n.messages
        : null;
      var value = catalog && typeof catalog[key] === 'string' && catalog[key] !== ''
        ? catalog[key]
        : String(fallback || '');
      Object.keys(replacements || {}).forEach(function (name) {
        value = value.split('{' + name + '}').join(String(replacements[name]));
      });
      return value;
    }

    if (!typeField || !categoryField || !urgencyField || !impactField || !priorityPreview) {
      return;
    }

    function announce(message) {
      if (liveRegion) {
        liveRegion.textContent = message;
      }
    }

    var actorPickers = [];

    function enhanceFileInputs() {
      Array.prototype.slice.call(document.querySelectorAll('[data-glpiacessivel-file-input]')).forEach(function (input) {
        var list = input.parentNode ? input.parentNode.querySelector('[data-glpiacessivel-file-list]') : null;
        if (!list) {
          return;
        }

        var clearButton = input.parentNode ? input.parentNode.querySelector('[data-glpiacessivel-file-clear]') : null;
        function clearFiles() {
          input.value = '';
          list.innerHTML = '';
          announce(message('create.file.selection_cleared', null, 'Seleção de anexos limpa.'));
        }
        if (clearButton) {
          clearButton.addEventListener('click', clearFiles);
        }

        input.addEventListener('change', function () {
          list.innerHTML = '';
          var files = Array.prototype.slice.call(input.files || []);
          if (files.length === 0) {
            announce(message('create.file.none_selected', null, 'Nenhum anexo selecionado.'));
            return;
          }

          files.forEach(function (file) {
            var item = document.createElement('li');
            item.textContent = file.name + ' (' + Math.ceil((file.size || 0) / 1024) + ' KB)';
            list.appendChild(item);
          });
          announce(message(
            files.length === 1 ? 'create.file.one_selected' : 'create.file.many_selected',
            { count: files.length },
            files.length === 1 ? '1 anexo selecionado.' : '{count} anexos selecionados.'
          ));
        });
      });
    }

    var templateField = document.querySelector('[data-glpiacessivel-ticket-template]');
    var templateStatus = document.getElementById('tickettemplates-status');
    var templateMetadata = <?= json_encode($templateMetadataPayload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) ?: '{}' ?>;
    var templateProjectionMessages = <?= json_encode([
        'projected_value' => $t('Valor definido pelo modelo (#{value})'),
        'predefined_applied' => $t('Os valores predefinidos compatíveis foram aplicados e bloqueados para esta abertura.'),
    ], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) ?: '{}' ?>;
    var templateFieldTargets = {
      name: 'name',
      content: 'content',
      type: 'type',
      itilcategories_id: 'itilcategories_id',
      locations_id: 'locations_id',
      requesttypes_id: 'requesttypes_id',
      externalid: 'externalid',
      urgency: 'urgency',
      impact: 'impact',
      _groups_id_assign: 'groups_assign',
      _users_id_assign: 'users_assign',
      _users_id_observer: 'users_observer',
      _groups_id_observer: 'groups_observer',
      _filename: 'filename',
      filename: 'filename'
    };
    var templateProjectionState = {};
    var templateSubmit = form ? form.querySelector('button[type="submit"]') : null;
    var templateSubmitInitiallyDisabled = templateSubmit ? templateSubmit.disabled : false;

    function projectionControl(field) {
      var id = templateFieldTargets[field] || '';
      return id ? document.getElementById(id) : null;
    }

    function orderedProjectionFields(fields) {
      var pending = fields.filter(function (field, index, all) {
        return all.indexOf(field) === index;
      });
      var ordered = [];
      while (pending.length > 0) {
        var progressed = false;
        pending.slice(0).forEach(function (field) {
          var control = projectionControl(field);
          var dependencies = control && control.dataset
            ? String(control.dataset.resourceDependencies || '').split(',')
            : [];
          var waitsForPendingDependency = dependencies.some(function (entry) {
            var selector = entry.split(':').slice(1).join(':').trim();
            if (!selector) {
              return false;
            }
            var dependency = null;
            try {
              dependency = document.querySelector(selector);
            } catch (error) {
              return false;
            }
            return pending.some(function (candidate) {
              return candidate !== field && projectionControl(candidate) === dependency;
            });
          });
          if (waitsForPendingDependency) {
            return;
          }
          ordered.push(field);
          pending.splice(pending.indexOf(field), 1);
          progressed = true;
        });
        if (!progressed) {
          return ordered.concat(pending);
        }
      }
      return ordered;
    }

    function selectedProjectionValues(control) {
      if (!(control instanceof HTMLSelectElement)) {
        return [{ value: String(control && control.value != null ? control.value : ''), label: '' }];
      }
      return Array.prototype.slice.call(control.options).filter(function (option) {
        return option.selected;
      }).map(function (option) {
        return { value: String(option.value), label: String(option.textContent || '').trim() };
      });
    }

    function rememberProjectionState(field, control) {
      if (!control || templateProjectionState[field]) {
        return;
      }
      templateProjectionState[field] = {
        values: selectedProjectionValues(control),
        disabled: control.disabled && !control.hasAttribute('data-glpiacessivel-template-locked'),
        ariaReadonly: control.getAttribute('aria-readonly')
      };
    }

    function resourceSelectorInstance(control) {
      var api = window.GlpiAccessibleResourceSelector;
      return api && typeof api.get === 'function' ? api.get(control) : null;
    }

    function synchronizeProjectedDisabled(control, disabled) {
      var instance = resourceSelectorInstance(control);
      if (instance) {
        if (disabled) {
          if (typeof instance.cancelRequest === 'function') {
            instance.cancelRequest();
          }
          if (typeof instance.close === 'function') {
            instance.close();
          }
        }
        if (instance.input) {
          instance.input.disabled = disabled;
          if (disabled) {
            instance.input.setAttribute('aria-readonly', 'true');
          } else {
            instance.input.removeAttribute('aria-readonly');
          }
        }
        if (instance.clearButton) {
          instance.clearButton.disabled = disabled;
        }
        if (instance.moreButton) {
          instance.moreButton.disabled = disabled || instance.requestInFlight || !instance.hasMore;
        }
        if (instance.retryButton) {
          instance.retryButton.disabled = disabled || instance.requestInFlight;
        }
      }

      var actorField = control.closest ? control.closest('.glpiacessivel-actor-field') : null;
      var actorPicker = actorField ? actorField.querySelector('.glpiacessivel-actor-picker') : null;
      if (actorPicker) {
        if (disabled) {
          Array.prototype.slice.call(actorPicker.querySelectorAll('input, select, button')).forEach(function (item) {
            item.disabled = true;
          });
          actorPicker.setAttribute('aria-disabled', 'true');
        } else {
          actorPicker.removeAttribute('aria-disabled');
          var search = actorPicker.querySelector('.glpiacessivel-actor-search');
          if (search) {
            search.disabled = false;
          }
          control.dispatchEvent(new Event('change', { bubbles: true }));
        }
      }
    }

    function restoreProjectionValue(control, snapshot) {
      if (control instanceof HTMLSelectElement) {
        Array.prototype.slice.call(control.options).forEach(function (option) {
          option.selected = false;
          if (option.hasAttribute('data-glpiacessivel-template-projected-option')) {
            option.remove();
          }
        });
        snapshot.values.forEach(function (item) {
          var option = Array.prototype.slice.call(control.options).find(function (candidate) {
            return String(candidate.value) === item.value;
          });
          if (!option) {
            option = document.createElement('option');
            option.value = item.value;
            option.textContent = item.label || item.value;
            control.appendChild(option);
          }
          option.selected = true;
        });
      } else {
        control.value = snapshot.values[0] ? snapshot.values[0].value : '';
      }
      control.dispatchEvent(new Event('change', { bubbles: true }));
    }

    function clearTemplateProjection() {
      if (form) {
        Array.prototype.slice.call(form.querySelectorAll(
          '[data-glpiacessivel-template-locked-value], [data-glpiacessivel-template-projected-value]'
        )).forEach(function (hidden) {
          hidden.remove();
        });
      }
      orderedProjectionFields(Object.keys(templateProjectionState)).forEach(function (field) {
        var control = projectionControl(field);
        var snapshot = templateProjectionState[field];
        if (!control || !snapshot) {
          return;
        }
        control.disabled = snapshot.disabled;
        control.removeAttribute('data-glpiacessivel-template-projection-lock');
        control.removeAttribute('data-glpiacessivel-template-locked');
        if (snapshot.ariaReadonly == null) {
          control.removeAttribute('aria-readonly');
        } else {
          control.setAttribute('aria-readonly', snapshot.ariaReadonly);
        }
        restoreProjectionValue(control, snapshot);
        synchronizeProjectedDisabled(control, snapshot.disabled);
      });
      var selectorApi = window.GlpiAccessibleResourceSelector;
      if (selectorApi && typeof selectorApi.enhance === 'function' && form) {
        selectorApi.enhance(form);
      }
      if (templateSubmit) {
        templateSubmit.disabled = templateSubmitInitiallyDisabled;
        templateSubmit.removeAttribute('aria-describedby');
      }
    }

    function projectionValues(value, multiple) {
      var values = Array.isArray(value) ? value : [value];
      values = values.filter(function (item) {
        return ['string', 'number'].indexOf(typeof item) !== -1;
      }).map(function (item) {
        return String(item);
      });
      return multiple ? values : values.slice(0, 1);
    }

    function projectControlValue(field, value) {
      var control = projectionControl(field);
      if (!control) {
        return false;
      }
      rememberProjectionState(field, control);
      var values = projectionValues(value, control instanceof HTMLSelectElement && control.multiple);
      if (control instanceof HTMLSelectElement) {
        Array.prototype.slice.call(control.options).forEach(function (option) {
          option.selected = false;
        });
        values.forEach(function (projectedValue) {
          var option = Array.prototype.slice.call(control.options).find(function (candidate) {
            return String(candidate.value) === projectedValue;
          });
          if (!option) {
            option = document.createElement('option');
            option.value = projectedValue;
            option.textContent = String(templateProjectionMessages.projected_value || '')
              .split('{value}').join(projectedValue);
            option.setAttribute('data-glpiacessivel-template-projected-option', '1');
            control.appendChild(option);
          }
          option.selected = true;
        });
      } else {
        control.value = values[0] || '';
      }
      control.dispatchEvent(new Event('change', { bubbles: true }));
      var instance = resourceSelectorInstance(control);
      if (instance && typeof instance.setStatus === 'function') {
        var projectedLabels = selectedProjectionValues(control).map(function (item) {
          return item.label || item.value;
        }).filter(Boolean);
        var projectedDescription = [instance.labelText, projectedLabels.join(', ')].filter(Boolean).join(': ');
        instance.setStatus(message(
          'selector.status.selected',
          { value: projectedDescription },
          projectedDescription + ' selecionado.'
        ));
      }
      return true;
    }

    function lockProjectedControl(field, hasProjectedValue, value) {
      var control = projectionControl(field);
      if (!control || !form) {
        return false;
      }
      rememberProjectionState(field, control);
      control.disabled = true;
      control.setAttribute('aria-readonly', 'true');
      control.setAttribute('data-glpiacessivel-template-projection-lock', '1');
      synchronizeProjectedDisabled(control, true);
      if (hasProjectedValue) {
        projectionValues(value, control instanceof HTMLSelectElement && control.multiple).forEach(function (item) {
          var hidden = document.createElement('input');
          hidden.type = 'hidden';
          hidden.name = control.name;
          hidden.value = item;
          hidden.setAttribute('data-glpiacessivel-template-projected-value', '1');
          form.appendChild(hidden);
        });
      }
      return true;
    }

    function applyTicketTemplateProjection(metadata) {
      var predefined = metadata && metadata.predefined && typeof metadata.predefined === 'object'
        ? metadata.predefined
        : {};
      var protectedFields = metadata && Array.isArray(metadata.protectedFields)
        ? metadata.protectedFields
        : [];
      var projectedFields = orderedProjectionFields(Object.keys(predefined));
      var fields = orderedProjectionFields(protectedFields.concat(projectedFields));
      var unavailable = fields.filter(function (field) {
        return !projectionControl(field);
      });
      if (unavailable.length > 0) {
        return unavailable;
      }
      projectedFields.forEach(function (field) {
        projectControlValue(field, predefined[field]);
      });
      fields.forEach(function (field) {
        lockProjectedControl(
          field,
          Object.prototype.hasOwnProperty.call(predefined, field),
          predefined[field]
        );
      });
      return [];
    }

    function blockTemplateFallback(blocked) {
      if (!templateSubmit) {
        return;
      }
      templateSubmit.disabled = templateSubmitInitiallyDisabled || blocked;
      if (blocked) {
        templateSubmit.setAttribute('aria-describedby', 'tickettemplates-status');
      } else {
        templateSubmit.removeAttribute('aria-describedby');
      }
    }
    var dynamicRequiredFields = [];

    function setFieldRequired(field, required) {
      var id = templateFieldTargets[field] || field;
      var control = document.getElementById(id);
      var label = control ? document.querySelector('label[for="' + id + '"]') : null;
      if (!control || control.disabled || control.getAttribute('aria-hidden') === 'true') {
        return;
      }
      if (required) {
        control.setAttribute('required', 'required');
        control.setAttribute('aria-required', 'true');
        if (label && label.textContent.indexOf('*') === -1) {
          label.setAttribute('data-template-required-added', '1');
          label.textContent = label.textContent + ' *';
        }
      } else {
        var nativeRequired = ['name', 'content', 'type', 'urgency', 'impact'].indexOf(field) !== -1;
        if (!nativeRequired) {
          control.removeAttribute('required');
          control.removeAttribute('aria-required');
        }
        if (label && label.getAttribute('data-template-required-added') === '1') {
          label.textContent = label.textContent.replace(/\s\*$/, '');
          label.removeAttribute('data-template-required-added');
        }
      }
    }

    function resetDynamicRequiredFields() {
      dynamicRequiredFields.forEach(function (field) {
        setFieldRequired(field, false);
      });
      dynamicRequiredFields = [];
    }

    function updateTicketTemplateStatus() {
      if (!templateField || !templateStatus) {
        return;
      }
      var selected = templateField.options[templateField.selectedIndex];
      var metadata = templateMetadata[String(templateField.value)] || null;
      clearTemplateProjection();
      resetDynamicRequiredFields();
      if (!metadata || templateField.value === '0') {
        blockTemplateFallback(false);
        templateStatus.textContent = message(
          'create.template.none', null, 'Nenhum modelo de chamado selecionado.'
        );
        announce(templateStatus.textContent);
        return;
      }
      if (
        (selected && selected.getAttribute('data-requires-native-fallback') === '1')
        || metadata.requiresNativeFallback === true
      ) {
        blockTemplateFallback(true);
        var unsupported = metadata.unsupported && metadata.unsupported.length
          ? metadata.unsupported.join(', ')
          : message(
            'create.template.unsupported_fields',
            null,
            'campos obrigatórios não suportados'
          );
        templateStatus.textContent = message(
          'create.template.requires_native',
          { label: metadata.label, unsupported: unsupported },
          'O modelo {label} exige {unsupported}. Abra o formulário em página completa para concluir.'
        );
        announce(templateStatus.textContent);
        return;
      }
      var unavailableProjection = applyTicketTemplateProjection(metadata);
      if (unavailableProjection.length > 0) {
        blockTemplateFallback(true);
        templateStatus.textContent = message(
          'create.template.requires_native',
          { label: metadata.label, unsupported: unavailableProjection.join(', ') },
          'O modelo {label} exige {unsupported}. Abra o formulário em página completa para concluir.'
        );
        announce(templateStatus.textContent);
        return;
      }
      blockTemplateFallback(false);
      dynamicRequiredFields = Array.isArray(metadata.requiredFields) ? metadata.requiredFields.slice(0) : [];
      dynamicRequiredFields.forEach(function (field) {
        setFieldRequired(field, true);
      });
      var required = metadata.required && metadata.required.length
        ? message(
          'create.template.required_fields',
          { fields: metadata.required.join(', ') },
          ' Campos obrigatórios: {fields}.'
        )
        : '';
      templateStatus.textContent = message(
        'create.template.selected',
        { label: metadata.label, required: required },
        'Modelo {label} selecionado.{required} Título e descrição não serão sobrescritos.'
      );
      if (metadata.predefined && Object.keys(metadata.predefined).length > 0) {
        templateStatus.textContent += ' ' + String(templateProjectionMessages.predefined_applied || '');
      }
      announce(templateStatus.textContent);
    }

    Object.keys(templateFieldTargets).forEach(function (field) {
      var control = projectionControl(field);
      if (control && control.hasAttribute('data-glpiacessivel-template-locked')) {
        rememberProjectionState(field, control);
      }
    });

    if (templateField) {
      templateField.addEventListener('change', updateTicketTemplateStatus);
      updateTicketTemplateStatus();
    }

    function actorText(value) {
      return String(value || '').replace(/\s+/g, ' ').trim();
    }

    function selectedActorOptions(select) {
      return Array.prototype.slice.call(select.options).filter(function (option) {
        return option.selected && option.value !== '';
      });
    }

    function enhanceActorSelect(select) {
      if (!select || select.dataset.glpiacessivelActorEnhanced === '1') {
        return;
      }

      var field = select.closest('.glpiacessivel-actor-field');
      var label = field ? field.querySelector('label') : null;
      var labelText = actorText(label ? label.textContent : select.getAttribute('data-actor-kind'));
      var kind = actorText(select.getAttribute('data-actor-kind') || labelText || message(
        'create.actor.default_kind', null, 'ator'
      ));
      var addLabel = actorText(select.getAttribute('data-actor-add-label') || message(
        'create.actor.add', { kind: kind }, 'Adicionar {kind}'
      ));
      var searchLabel = actorText(select.getAttribute('data-actor-search-label') || message(
        'create.actor.filter', { kind: kind }, 'Filtrar {kind}'
      ));
      var emptyLabel = actorText(select.getAttribute('data-actor-empty-label') || message(
        'create.actor.none_selected', { kind: kind }, 'Nenhum {kind} selecionado.'
      ));
      var baseId = select.id || ('actor-' + actorPickers.length);
      var options = Array.prototype.slice.call(select.options).map(function (option) {
        return {
          option: option,
          value: option.value,
          label: actorText(option.textContent)
        };
      }).filter(function (item) {
        return item.value !== '';
      });

      var picker = document.createElement('div');
      picker.className = 'glpiacessivel-actor-picker';
      picker.setAttribute('data-actor-kind', kind);

      var controls = document.createElement('div');
      controls.className = 'glpiacessivel-actor-picker-controls';

      var searchWrap = document.createElement('div');
      searchWrap.className = 'glpiacessivel-field glpiacessivel-actor-search-field';

      var searchId = baseId + '_search';
      var searchLabelNode = document.createElement('label');
      searchLabelNode.setAttribute('for', searchId);
      searchLabelNode.textContent = searchLabel;

      var searchInput = document.createElement('input');
      searchInput.id = searchId;
      searchInput.type = 'search';
      searchInput.className = 'glpiacessivel-actor-search';
      searchInput.setAttribute('autocomplete', 'off');
      searchInput.setAttribute('aria-controls', baseId + '_candidate');

      searchWrap.appendChild(searchLabelNode);
      searchWrap.appendChild(searchInput);

      var candidateWrap = document.createElement('div');
      candidateWrap.className = 'glpiacessivel-field glpiacessivel-actor-candidate-field';

      var candidateId = baseId + '_candidate';
      var candidateLabel = document.createElement('label');
      candidateLabel.setAttribute('for', candidateId);
      candidateLabel.className = 'glpiacessivel-sr-only';
      candidateLabel.textContent = message(
        'create.actor.option_to_add',
        { kind: kind },
        'Opção para adicionar em {kind}'
      );

      var candidateSelect = document.createElement('select');
      candidateSelect.id = candidateId;
      candidateSelect.className = 'glpiacessivel-actor-candidate';

      candidateWrap.appendChild(candidateLabel);
      candidateWrap.appendChild(candidateSelect);

      var buttonWrap = document.createElement('div');
      buttonWrap.className = 'glpiacessivel-actor-add-wrap';

      var addButton = document.createElement('button');
      addButton.type = 'button';
      addButton.className = 'glpiacessivel-button glpiacessivel-button-secondary glpiacessivel-actor-add';
      addButton.textContent = '+';
      addButton.setAttribute('aria-label', message(
        'create.actor.add_selected',
        { action: addLabel },
        '{action} selecionado'
      ));

      buttonWrap.appendChild(addButton);
      controls.appendChild(searchWrap);
      controls.appendChild(candidateWrap);
      controls.appendChild(buttonWrap);

      var summary = document.createElement('p');
      summary.id = baseId + '_summary';
      summary.className = 'glpiacessivel-actor-summary';
      summary.setAttribute('aria-live', 'polite');

      var selectedList = document.createElement('ul');
      selectedList.id = baseId + '_selected';
      selectedList.className = 'glpiacessivel-actor-selected-list';
      selectedList.setAttribute('aria-describedby', summary.id);

      var clearButton = document.createElement('button');
      clearButton.type = 'button';
      clearButton.className = 'glpiacessivel-button glpiacessivel-button-secondary glpiacessivel-actor-clear';
      clearButton.textContent = message('button.clear', null, 'Limpar');
      clearButton.setAttribute('aria-label', message(
        'create.actor.clear',
        { kind: kind },
        'Limpar seleção de {kind}'
      ));

      picker.appendChild(controls);
      picker.appendChild(summary);
      picker.appendChild(selectedList);
      picker.appendChild(clearButton);

      if (field) {
        field.insertBefore(picker, select);
        field.setAttribute('data-actor-enhanced', 'true');
      } else {
        select.parentNode.insertBefore(picker, select);
      }

      select.dataset.glpiacessivelActorEnhanced = '1';
      select.setAttribute('aria-hidden', 'true');
      select.tabIndex = -1;

      function filteredCandidates() {
        var term = actorText(searchInput.value).toLocaleLowerCase();
        return options.filter(function (item) {
          return !item.option.selected && (term === '' || item.label.toLocaleLowerCase().indexOf(term) !== -1);
        });
      }

      function renderCandidates() {
        var previous = candidateSelect.value;
        var candidates = filteredCandidates();
        candidateSelect.innerHTML = '';

        if (candidates.length === 0) {
          var emptyOption = document.createElement('option');
          emptyOption.value = '';
          emptyOption.textContent = options.length === 0
            ? message('create.actor.none_available', null, 'Nenhuma opção disponível')
            : message('create.actor.no_results', null, 'Nenhum resultado disponível');
          candidateSelect.appendChild(emptyOption);
          candidateSelect.disabled = true;
          addButton.disabled = true;
          return;
        }

        candidates.forEach(function (item) {
          var option = document.createElement('option');
          option.value = item.value;
          option.textContent = item.label;
          candidateSelect.appendChild(option);
        });

        candidateSelect.disabled = false;
        addButton.disabled = false;
        if (previous && candidates.some(function (item) { return item.value === previous; })) {
          candidateSelect.value = previous;
        }
      }

      function restoreActorFocus(preferredIndex) {
        if (typeof preferredIndex === 'number') {
          var removeButtons = Array.prototype.slice.call(selectedList.querySelectorAll('.glpiacessivel-actor-remove'));
          if (removeButtons.length > 0) {
            removeButtons[Math.min(Math.max(0, preferredIndex), removeButtons.length - 1)].focus();
            return;
          }
        }
        searchInput.focus();
      }

      function renderSelected(preferredFocusIndex) {
        var selected = selectedActorOptions(select);
        selectedList.innerHTML = '';

        if (selected.length === 0) {
          summary.textContent = emptyLabel;
          selectedList.classList.add('glpiacessivel-actor-selected-list-empty');
          clearButton.disabled = true;
          renderCandidates();
          if (typeof preferredFocusIndex === 'number') {
            restoreActorFocus(preferredFocusIndex);
          }
          return;
        }

        summary.textContent = message(
          selected.length === 1 ? 'create.actor.one_selected' : 'create.actor.many_selected',
          { count: selected.length, kind: kind },
          selected.length === 1 ? '1 item selecionado em {kind}.' : '{count} itens selecionados em {kind}.'
        );
        selectedList.classList.remove('glpiacessivel-actor-selected-list-empty');
        clearButton.disabled = false;

        selected.forEach(function (option, selectedIndex) {
          var item = document.createElement('li');
          item.className = 'glpiacessivel-actor-chip';

          var text = document.createElement('span');
          text.textContent = actorText(option.textContent);

          var remove = document.createElement('button');
          remove.type = 'button';
          remove.className = 'glpiacessivel-actor-remove';
          remove.textContent = message('button.remove', null, 'Remover');
          remove.setAttribute('aria-label', message(
            'create.actor.remove_from',
            { actor: actorText(option.textContent), kind: kind },
            'Remover {actor} de {kind}'
          ));
          remove.addEventListener('click', function () {
            option.selected = false;
            renderSelected(selectedIndex);
            announce(message(
              'create.actor.removed_from',
              { actor: actorText(option.textContent), kind: kind },
              '{actor} removido de {kind}.'
            ));
          });

          item.appendChild(text);
          item.appendChild(remove);
          selectedList.appendChild(item);
        });

        renderCandidates();
        if (typeof preferredFocusIndex === 'number') {
          restoreActorFocus(preferredFocusIndex);
        }
      }

      function addSelectedCandidate() {
        var value = candidateSelect.value;
        if (!value) {
          announce(message(
            'create.actor.none_to_add',
            { kind: kind },
            'Nenhuma opção disponível para adicionar em {kind}.'
          ));
          return;
        }

        var selectedItem = options.find(function (item) {
          return item.value === value;
        });
        if (!selectedItem) {
          return;
        }

        var moveFocusToSearch = document.activeElement === candidateSelect
          || document.activeElement === addButton;
        selectedItem.option.selected = true;
        searchInput.value = '';
        renderSelected();
        if (moveFocusToSearch && (candidateSelect.disabled || addButton.disabled)) {
          searchInput.focus();
        }
        announce(message(
          'create.actor.added_to',
          { actor: selectedItem.label, kind: kind },
          '{actor} adicionado em {kind}.'
        ));
      }

      searchInput.addEventListener('input', renderCandidates);
      searchInput.addEventListener('keydown', function (event) {
        if (event.key === 'Enter') {
          event.preventDefault();
          addSelectedCandidate();
        }
      });
      candidateSelect.addEventListener('keydown', function (event) {
        if (event.key === 'Enter') {
          event.preventDefault();
          addSelectedCandidate();
        }
      });
      addButton.addEventListener('click', addSelectedCandidate);
      clearButton.addEventListener('click', function () {
        var selected = selectedActorOptions(select);
        selected.forEach(function (option) {
          option.selected = false;
        });
        renderSelected(0);
        announce(message(
          'create.actor.selection_cleared',
          { kind: kind },
          'Seleção de {kind} limpa.'
        ));
      });
      select.addEventListener('change', renderSelected);

      renderSelected();
      actorPickers.push({
        render: renderSelected
      });
    }

    function enhanceActorPickers() {
      Array.prototype.slice.call(document.querySelectorAll('[data-glpiacessivel-actor-select]'))
        .filter(function (select) {
          return !select.disabled && !select.hasAttribute('data-glpiacessivel-resource-select');
        })
        .forEach(enhanceActorSelect);
    }

    function updateRequesterPreview() {
      if (!requesterField || !requesterPreview || !requesterField.selectedOptions.length) {
        return;
      }
      requesterPreview.textContent = requesterField.selectedOptions[0].textContent.trim();
    }

    if (requesterField) {
      requesterField.addEventListener('change', updateRequesterPreview);
    }

    function computePriorityLabel(urgency, impact) {
      var score = Number(urgency) + Number(impact);
      if (score <= 3) {
        return message('create.priority.very_low', null, 'Muito baixa');
      }
      if (score <= 5) {
        return message('create.priority.low', null, 'Baixa');
      }
      if (score <= 7) {
        return message('create.priority.medium', null, 'Média');
      }
      if (score <= 9) {
        return message('create.priority.high', null, 'Alta');
      }

      return message('create.priority.very_high', null, 'Muito alta');
    }

    function updatePriorityPreview() {
      var label = computePriorityLabel(urgencyField.value || 3, impactField.value || 3);
      priorityPreview.textContent = label;
      priorityPreview.className = 'glpiacessivel-badge ' + (
        label === message('create.priority.very_high', null, 'Muito alta')
          || label === message('create.priority.high', null, 'Alta')
          ? 'glpiacessivel-badge-priority-high'
          : (label === message('create.priority.medium', null, 'Média')
            ? 'glpiacessivel-badge-priority-medium'
            : 'glpiacessivel-badge-priority-low')
      );
      announce(message(
        'create.priority.updated',
        { priority: label },
        'Prioridade prevista atualizada para {priority}.'
      ));
    }

    function updateRequestSourcePreview() {
      if (!requestSourceField || !requestSourcePreview) {
        return;
      }

      var selected = requestSourceField.options[requestSourceField.selectedIndex];
      requestSourcePreview.textContent = selected
        ? selected.textContent
        : message('create.request_source.default', null, 'Central de atendimento');
    }

    function syncCategories() {
      if (categoryField.hasAttribute('data-glpiacessivel-resource-select')) {
        announce(message(
          'create.category.remote_context',
          null,
          'A pesquisa de categorias usará o tipo de chamado selecionado.'
        ));
        return;
      }
      var selectedType = String(typeField.value);
      var hasVisibleSelected = false;
      var visibleCount = 0;

      Array.prototype.slice.call(categoryField.options).forEach(function (option, index) {
        if (index === 0) {
          option.hidden = false;
          option.disabled = false;
          return;
        }

        var allowed = selectedType === '2'
          ? option.getAttribute('data-request') === '1'
          : option.getAttribute('data-incident') === '1';

        option.hidden = !allowed;
        option.disabled = !allowed;
        if (allowed) {
          visibleCount += 1;
        }
        if (allowed && option.selected) {
          hasVisibleSelected = true;
        }
      });

      if (!hasVisibleSelected) {
        categoryField.value = '0';
      }

      announce(message(
        'create.category.updated',
        { count: visibleCount },
        'Categorias atualizadas para o tipo selecionado. {count} opção(ões) disponível(is).'
      ));
    }

    typeField.addEventListener('change', syncCategories);
    urgencyField.addEventListener('change', updatePriorityPreview);
    impactField.addEventListener('change', updatePriorityPreview);
    if (requestSourceField) {
      requestSourceField.addEventListener('change', function () {
        updateRequestSourcePreview();
        announce(message(
          'create.request_source.updated',
          null,
          'Origem da requisição atualizada.'
        ));
      });
    }

    syncCategories();
    updatePriorityPreview();
    updateRequestSourcePreview();
    updateRequesterPreview();
    enhanceActorPickers();
    enhanceFileInputs();

    if (form) {
      form.addEventListener('reset', function () {
        window.setTimeout(function () {
          updateTicketTemplateStatus();
          syncCategories();
          updatePriorityPreview();
          updateRequestSourcePreview();
          actorPickers.forEach(function (picker) {
            picker.render();
          });
          announce(message('create.form.cleared', null, 'Formulário limpo.'));
        }, 0);
      });
    }

    if (errorSummary && typeof errorSummary.focus === 'function') {
      errorSummary.focus();
    } else {
      var firstInvalid = form ? form.querySelector('[aria-invalid="true"]') : null;
      if (firstInvalid && typeof firstInvalid.focus === 'function') {
        firstInvalid.focus();
      }
    }
  })();
</script>

