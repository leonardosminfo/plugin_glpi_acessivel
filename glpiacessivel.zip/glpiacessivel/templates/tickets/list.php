<?php

$resultContractVersion = 2;
$declaredResultContractVersion = array_key_exists('contract_version', $result)
  ? (is_int($result['contract_version']) ? $result['contract_version'] : 0)
  : $resultContractVersion;
$resultContractCompatible = $declaredResultContractVersion === $resultContractVersion;
$items = $resultContractCompatible ? (array) ($result['items'] ?? []) : [];
$page = max(1, (int) ($result['page'] ?? 1));
$pageSize = max(1, (int) ($result['page_size'] ?? ($filters['page_size'] ?? 20)));
$allowedTotalStates = ['deferred', 'pending', 'exact', 'unavailable', 'lower_bound'];
$totalState = $resultContractCompatible && in_array((string) ($result['total_state'] ?? ''), $allowedTotalStates, true)
  ? (string) $result['total_state']
  : 'unavailable';
$total = $resultContractCompatible && is_int($result['total'] ?? null) && (int) $result['total'] >= 0
  ? (int) $result['total']
  : null;
$totalKnown = in_array($totalState, ['exact', 'lower_bound'], true) && $total !== null;
$hasPrevious = $resultContractCompatible && !empty($result['has_previous']);
$hasMore = $resultContractCompatible && !empty($result['has_more']);
$backend = $resultContractCompatible
  ? (string) ($result['backend'] ?? 'native_saved_search_blocked')
  : 'native_saved_search_blocked';
$showOperationalDiagnostics = !empty($showOperationalDiagnostics);
$canCreateTicketFromList = !empty($can_create_ticket);
$backendReason = $resultContractCompatible
  ? (string) ($result['backend_reason'] ?? '')
  : 'contract_upgrade_required';
if (
  in_array($backendReason, ['saved_search_unavailable', 'native_saved_search_unavailable'], true)
  && ($filters['saved_search_failure_code'] ?? '') === 'native_resolved_semantics_changed'
) {
  $backendReason = 'native_resolved_semantics_changed';
}
$savedSearchSemanticsChanged = $backendReason === 'native_resolved_semantics_changed';
$savedSearchUnavailable = in_array($backendReason, [
  'saved_search_unavailable',
  'native_saved_search_unavailable',
  'native_resolved_semantics_changed',
], true);
$savedSearchUnavailableMessage = $savedSearchSemanticsChanged
  ? glpiacessivel_t('Não foi possível aplicar todos os filtros desta pesquisa no perfil atual. Para evitar resultados diferentes, a lista não foi carregada. Escolha outra pesquisa ou solicite a revisão dos filtros.')
  : glpiacessivel_t(
  'Ela pode ter sido excluída ou deixado de estar disponível para seu perfil e entidade. Nenhum chamado foi exibido para evitar uma lista diferente da esperada.'
);
$savedSearchRevalidationUnavailable = $backendReason === 'saved_search_revalidation_unavailable';
$savedSearchRevalidationFailure = $savedSearchRevalidationUnavailable
  || $backendReason === 'saved_search_revalidation_failed';
$savedSearchRevalidationMessage = $savedSearchRevalidationUnavailable
  ? glpiacessivel_t('Não foi possível validar a pesquisa salva agora. Nenhum chamado foi exibido. A pesquisa e seus filtros foram preservados. Aguarde antes de tentar novamente.')
  : glpiacessivel_t('Não foi possível validar a pesquisa salva. Nenhum chamado foi exibido. A pesquisa e seus filtros foram preservados. Atualize a página para tentar novamente.');
$pageUnavailableHeading = $savedSearchUnavailable
  ? glpiacessivel_t('Pesquisa salva indisponível.')
  : ($savedSearchRevalidationFailure ? glpiacessivel_t('Pesquisa salva não carregada') : glpiacessivel_t('Página não carregada'));
$savedSearchResetUrl = glpiacessivel_url(
  'front/tickets.php?saved_search=&manage_saved_search=1#ticket-search-tool-saved-searches'
);
$contractUpgradeRequired = $backendReason === 'contract_upgrade_required';
$capacityUnavailable = in_array($backendReason, [
  'capacity_backend_unavailable',
  'capacity_backend_error',
  'capacity_limit_reached',
  'user_context_in_flight',
  'circuit_open',
  'circuit_half_open',
], true);
$rateLimited = $backendReason === 'rate_limited';
$userContextInFlight = $backendReason === 'user_context_in_flight';
$capacityLimited = $backendReason === 'capacity_limit_reached';
$retryAfterSeconds = max(0, (int) ($result['retry_after'] ?? 0));
$boundedStatementTimeout = $backendReason === 'bounded_search_statement_timeout';
$temporaryRetryDelayed = $rateLimited || $boundedStatementTimeout || $savedSearchRevalidationUnavailable
  || $userContextInFlight || $capacityLimited;
$boundedOffsetExceeded = $backendReason === 'bounded_search_offset_limit_exceeded';
$boundedExecutionUnavailable = in_array($backendReason, [
  'bounded_search_execution_unavailable',
  'bounded_search_execution_failed',
  'bounded_search_plan_failed',
], true);
$groupScopeWithoutCurrentGroups = $backendReason === 'group_scope_without_current_groups';
$groupScopeWithoutCurrentGroupsMessage = glpiacessivel_t(
  'Você não pertence a nenhum grupo no perfil e na entidade atuais. Por isso, não há chamados de grupos responsáveis para exibir.'
);
$ticketResultsAsync = is_array($ticket_results_async ?? null)
  ? $ticket_results_async
  : ['enabled' => false];
$ticketResultsAsyncEnabled = !empty($ticketResultsAsync['enabled']);
$pageUnavailable = !$resultContractCompatible
  || $savedSearchRevalidationFailure
  || $contractUpgradeRequired
  || $capacityUnavailable
  || $rateLimited
  || $boundedStatementTimeout
  || $boundedOffsetExceeded
  || $boundedExecutionUnavailable
  || $backend === 'native_saved_search_blocked';
$totalStateMessage = '';
if (!$ticketResultsAsyncEnabled && !$groupScopeWithoutCurrentGroups && !$pageUnavailable) {
  if ($totalState === 'pending') {
    $totalStateMessage = glpiacessivel_t('Calculando o total de chamados.');
  } elseif ($totalState === 'deferred') {
    $totalStateMessage = glpiacessivel_t('O total não foi calculado para acelerar esta página.');
  } elseif ($totalState === 'unavailable') {
    $totalStateMessage = glpiacessivel_t('O total não pôde ser calculado agora. Os chamados desta página continuam disponíveis.');
  }
}
$ticketResultsAssetPath = 'public/assets/js/ticket-results.js';
$ticketResultsAssetVersion = function_exists('plugin_glpiacessivel_asset_version')
  ? plugin_glpiacessivel_asset_version($ticketResultsAssetPath)
  : (string) (@filemtime(__DIR__ . '/../../' . $ticketResultsAssetPath) ?: '1');
$ticketResultsAssetUrl = \GlpiPlugin\Glpiacessivel\Support\Url::asset(
  $ticketResultsAssetPath . '?v=' . rawurlencode($ticketResultsAssetVersion)
);
$ticketCopyAssetPath = 'public/assets/js/ticket-id-copy.js';
$ticketCopyAssetVersion = function_exists('plugin_glpiacessivel_asset_version')
  ? plugin_glpiacessivel_asset_version($ticketCopyAssetPath)
  : (string) (@filemtime(__DIR__ . '/../../' . $ticketCopyAssetPath) ?: '1');
$ticketCopyAssetUrl = \GlpiPlugin\Glpiacessivel\Support\Url::asset(
  $ticketCopyAssetPath . '?v=' . rawurlencode($ticketCopyAssetVersion)
);
$backendLabel = $backend === 'search_api'
  ? glpiacessivel_t('Lista atualizada.')
  : glpiacessivel_t('Não foi possível carregar todos os resultados desta consulta.');
$firstItem = count($items) > 0 ? (($page - 1) * $pageSize) + 1 : 0;
$lastItem = count($items) > 0 ? $firstItem + count($items) - 1 : 0;
if ($totalKnown && $total !== null && $lastItem > $total) {
  $lastItem = $total;
}
$nativeTicketUrl = trim((string) ($native_ticket_list_url ?? ''));
$savedSearchCatalog = is_array($saved_search_catalog ?? null) ? $saved_search_catalog : [];
$nativeSavedSearches = array_values(array_filter(
  (array) ($savedSearchCatalog['native'] ?? []),
  'is_array'
));

/**
 * Contrato progressivo da interface nativa:
 * - saved_search_catalog.native (ou native_catalog.items): itens do GLPI;
 * - query, previous_cursor/prev_cursor, next_cursor, total e page_size: catalogo;
 * - capabilities.can_create_private e editor: formulario de criacao/edicao;
 * - capabilities.can_edit/can_set_default/can_delete, edit_url e
 *   expected_fingerprint: operacoes permitidas por item.
 *
 * Sem capacidades explicitas, a interface permanece somente leitura. Nenhuma
 * pesquisa e copiada, importada ou persistida pelo plugin.
 */
$nativeCatalog = is_array($savedSearchCatalog['native_catalog'] ?? null)
  ? $savedSearchCatalog['native_catalog']
  : $savedSearchCatalog;
$nativeCatalogPagination = is_array($nativeCatalog['pagination'] ?? null)
  ? $nativeCatalog['pagination']
  : [];
$nativeCatalogCapabilities = is_array($nativeCatalog['capabilities'] ?? null)
  ? $nativeCatalog['capabilities']
  : [];
$nativeCatalogEditor = is_array($nativeCatalog['editor'] ?? null)
  ? $nativeCatalog['editor']
  : [];
$nativeCatalogUsesBackendPagination = array_key_exists('items', $nativeCatalog)
  || array_key_exists('next_cursor', $nativeCatalog)
  || array_key_exists('next_cursor', $nativeCatalogPagination);
$nativeCatalogItems = array_key_exists('items', $nativeCatalog)
  ? array_values(array_filter((array) $nativeCatalog['items'], 'is_array'))
  : $nativeSavedSearches;
$nativeCatalogPageSize = 25;
$nativeCatalogQuery = trim((string) ($_GET['saved_search_q'] ?? ($nativeCatalog['query'] ?? '')));
$nativeCatalogQuery = substr($nativeCatalogQuery, 0, 120);
$nativeCatalogCursor = (string) ($_GET['saved_search_cursor'] ?? '');
$nativeCatalogOffset = ctype_digit($nativeCatalogCursor) ? (int) $nativeCatalogCursor : 0;

if (!$nativeCatalogUsesBackendPagination && $nativeCatalogQuery !== '') {
  $nativeCatalogItems = array_values(array_filter(
    $nativeCatalogItems,
    static function (array $saved) use ($nativeCatalogQuery): bool {
      $searchableText = implode(' ', [
        (string) ($saved['name'] ?? ''),
        (string) ($saved['visibility'] ?? ''),
        (string) ($saved['entity_name'] ?? ''),
        (string) ($saved['criteria_summary'] ?? ''),
      ]);

      return stripos($searchableText, $nativeCatalogQuery) !== false;
    }
  ));
}

if ($nativeCatalogUsesBackendPagination) {
  $nativeCatalogTotal = max(0, (int) (
    $nativeCatalog['total'] ?? $nativeCatalogPagination['total'] ?? count($nativeCatalogItems)
  ));
  $nativeCatalogPreviousCursor = (string) (
    $nativeCatalog['previous_cursor']
    ?? $nativeCatalog['prev_cursor']
    ?? $nativeCatalogPagination['previous_cursor']
    ?? $nativeCatalogPagination['prev_cursor']
    ?? ''
  );
  $nativeCatalogHasPrevious = $nativeCatalogPreviousCursor !== '';
  $nativeCatalogCanReturnToFirst = !$nativeCatalogHasPrevious && $nativeCatalogCursor !== '';
  $nativeCatalogNextCursor = (string) (
    $nativeCatalog['next_cursor'] ?? $nativeCatalogPagination['next_cursor'] ?? ''
  );
} else {
  $nativeCatalogTotal = count($nativeCatalogItems);
  $nativeCatalogOffset = min(
    $nativeCatalogOffset,
    max(0, ((int) ceil(max(1, $nativeCatalogTotal) / $nativeCatalogPageSize) - 1) * $nativeCatalogPageSize)
  );
  $nativeCatalogItems = array_slice($nativeCatalogItems, $nativeCatalogOffset, $nativeCatalogPageSize);
  $nativeCatalogPreviousCursor = $nativeCatalogOffset > 0
    ? (string) max(0, $nativeCatalogOffset - $nativeCatalogPageSize)
    : '';
  $nativeCatalogHasPrevious = $nativeCatalogPreviousCursor !== '';
  $nativeCatalogCanReturnToFirst = false;
  $nativeCatalogNextCursor = ($nativeCatalogOffset + count($nativeCatalogItems)) < $nativeCatalogTotal
    ? (string) ($nativeCatalogOffset + $nativeCatalogPageSize)
    : '';
}

$nativeCatalogDefaultItem = is_array($nativeCatalog['default_item'] ?? null)
  ? $nativeCatalog['default_item']
  : null;
if ($nativeCatalogDefaultItem === null) {
  foreach ($nativeCatalogItems as $nativeCatalogCandidate) {
    if (!empty($nativeCatalogCandidate['is_default'])) {
      $nativeCatalogDefaultItem = $nativeCatalogCandidate;
      break;
    }
  }
}
$canCreateNativeSearch = !empty($nativeCatalogCapabilities['can_create_private']);
$canEditNativeSearch = !empty($nativeCatalogEditor['can_edit'])
  || count(array_filter(
    $nativeCatalogItems,
    static fn(array $saved): bool => !empty($saved['can_edit'])
      || !empty($saved['capabilities']['can_edit'])
  )) > 0;
$nativeCatalogFocusResults = array_key_exists('saved_search_q', $_GET)
  || array_key_exists('saved_search_cursor', $_GET);
$selectedSavedSearch = (string) ($selected_saved_search ?? '');
$activeSavedSearch = is_array($active_saved_search ?? null) ? $active_saved_search : null;
$savedSearchExecutionBlocked = $activeSavedSearch !== null
  && (
    !empty($activeSavedSearch['execution_blocked'])
    || (string) ($activeSavedSearch['capability'] ?? $activeSavedSearch['compatibility'] ?? '') === 'native_only'
  );
$advancedSearchCatalog = is_array($advanced_search_catalog ?? null) ? $advanced_search_catalog : [];
$advancedSearchState = is_array($advanced_search_state ?? null) ? $advanced_search_state : [];
$advancedSearchToken = trim((string) ($advanced_search_token ?? ''));
$draftFrequentFilters = is_array($draft_frequent_filters ?? null)
  ? $draft_frequent_filters
  : [];
$draftStatus = is_string($draftFrequentFilters['status'] ?? null)
  ? (string) $draftFrequentFilters['status']
  : (string) ($filters['status'] ?? '');
$draftGroupId = is_int($draftFrequentFilters['group_id'] ?? null)
  ? (int) $draftFrequentFilters['group_id']
  : (int) ($filters['group_id'] ?? 0);
$frequentFilterPresentation = is_array($frequent_filter_presentation ?? null)
  ? $frequent_filter_presentation
  : [];
$draftStatusMode = (string) ($frequentFilterPresentation['status_mode'] ?? 'normal');
$advancedSearchCriteria = array_values(array_filter(
  (array) ($advancedSearchState['criteria'] ?? []),
  'is_array'
));
$advancedSearchMetaCriteria = array_values(array_filter(
  (array) ($advancedSearchState['metacriteria'] ?? []),
  'is_array'
));
$advancedSearchSort = array_values((array) ($advancedSearchState['sort'] ?? []));
$advancedSearchOrder = array_values((array) ($advancedSearchState['order'] ?? []));
$advancedSearchErrors = array_values(array_filter(
  (array) ($advancedSearchState['errors'] ?? []),
  'is_string'
));
$advancedSearchFocusResults = !empty($advancedSearchState['focus_results'])
  || (string) ($_GET['focus'] ?? '') === 'results';
$advancedSearchEditable = !array_key_exists('editable', $advancedSearchState)
  || !empty($advancedSearchState['editable']);
$savedSearchDefinitionActive = $activeSavedSearch !== null
  && !$savedSearchExecutionBlocked
  && in_array(
    (string) ($activeSavedSearch['capability'] ?? $activeSavedSearch['compatibility'] ?? ''),
    ['editable', 'executable_read_only'],
    true
  );
$advancedSearchActive = $advancedSearchToken !== ''
  || $advancedSearchErrors !== []
  || $advancedSearchCriteria !== []
  || $advancedSearchMetaCriteria !== []
  || $savedSearchDefinitionActive;
$advancedVisibleCriteriaCount = max(
  0,
  (int) ($advancedSearchState['criteria_count']
    ?? (count($advancedSearchCriteria) + count($advancedSearchMetaCriteria)))
);
$advancedSearchConfig = [
  'catalog' => $advancedSearchCatalog,
  'criteria' => $advancedSearchCriteria,
  'metacriteria' => $advancedSearchMetaCriteria,
  'sort' => $advancedSearchSort,
  'order' => $advancedSearchOrder,
  'default_columns' => ['id', 'name', 'status', 'priority', 'group', 'date_mod'],
  'is_deleted' => (int) ($advancedSearchState['is_deleted'] ?? 0),
  'editable' => $advancedSearchEditable,
  'native_search_url' => $nativeTicketUrl,
  'remote_value_url' => glpiacessivel_url('front/ticket.search-values.php'),
  'csrf_token' => (string) ($csrf_token ?? ''),
  'limits' => [
    'criteria' => 25,
    'metacriteria' => 25,
    'sorts' => 5,
    'depth' => 4,
  ],
];
$advancedSearchConfigJson = json_encode(
  $advancedSearchConfig,
  JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT
);
if (!is_string($advancedSearchConfigJson)) {
  $advancedSearchConfigJson = '{"catalog":{},"criteria":[],"metacriteria":[],"sort":[],"order":[]}';
}
$ticketResultsAsyncConfig = $ticketResultsAsync + [
  'enabled' => false,
  'contract_version' => 2,
  'csrf_token' => (string) ($csrf_token ?? ''),
  'columns' => (array) ($filters['columns'] ?? []),
  'group_by' => (string) ($filters['group_by'] ?? 'none'),
  'scope' => (string) ($filters['scope'] ?? 'all'),
  'saved_search_reset_url' => $savedSearchResetUrl,
];
$ticketResultsAsyncConfigJson = json_encode(
  $ticketResultsAsyncConfig,
  JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT
);
if (!is_string($ticketResultsAsyncConfigJson)) {
  $ticketResultsAsyncConfigJson = '{"enabled":false}';
}
$ticketColumnOptions = [
  'id' => 'ID',
  'name' => glpiacessivel_t('Título'),
  'status' => glpiacessivel_t('Status'),
  'priority' => glpiacessivel_t('Prioridade'),
  'group' => glpiacessivel_t('Grupo responsável'),
  'requester' => glpiacessivel_t('Requisitante'),
  'assignee' => glpiacessivel_t('Técnico'),
  'category' => glpiacessivel_t('Categoria'),
  'entity' => glpiacessivel_t('Entidade'),
  'location' => glpiacessivel_t('Localização'),
  'date' => glpiacessivel_t('Data de abertura'),
  'date_mod' => glpiacessivel_t('Última atualização'),
  'time_to_resolve' => glpiacessivel_t('Prazo para solução'),
];
$ticketColumnCatalog = array_values(array_filter(
  (array) ($advancedSearchCatalog['columns'] ?? []),
  'is_array'
));
$requiredTicketColumns = ['id', 'name'];
foreach ($ticketColumnCatalog as $columnDefinition) {
  $columnIdentifier = trim((string) (
    $columnDefinition['identifier']
    ?? $columnDefinition['key']
    ?? $columnDefinition['option_id']
    ?? ''
  ));
  if ($columnIdentifier === '' || !array_key_exists($columnIdentifier, $ticketColumnOptions)) {
    continue;
  }
  $columnLabel = trim((string) ($columnDefinition['label'] ?? ''));
  if ($columnLabel !== '') {
    $ticketColumnOptions[$columnIdentifier] = $columnLabel;
  }
  if (!empty($columnDefinition['required'])) {
    $requiredTicketColumns[] = $columnIdentifier;
  }
}
$requiredTicketColumns = array_values(array_unique($requiredTicketColumns));
$columns = array_values((array) ($filters['columns'] ?? ['id', 'name', 'status', 'priority', 'group', 'date_mod']));

$savedSearchActionUrl = glpiacessivel_url('front/ticket.saved-search.php');
$savedSearchIdempotencyKey = static fn(): string => bin2hex(random_bytes(24));

$statusLabels = ['' => glpiacessivel_t('Sem filtro adicional de status')];
foreach (\GlpiPlugin\Glpiacessivel\Support\TicketStatusLabels::all() as $statusId => $statusLabel) {
  $statusLabels[(string) $statusId] = $statusLabel;
}

$scopeLabels = [
  'all' => glpiacessivel_t('Todos os chamados permitidos'),
  'mine' => glpiacessivel_t('Meus chamados'),
  'group' => glpiacessivel_t('Chamados do grupo'),
];

$groupByLabels = [
  'none' => glpiacessivel_t('Lista única'),
  'group' => glpiacessivel_t('Agrupar por grupo'),
];

$queryUrl = static function (array $changes = []) use ($filters, $columns, $advancedSearchToken): string {
  $params = array_merge((array) $filters, $changes);
  if ($advancedSearchToken !== '') {
    $params['advanced_search_token'] = $advancedSearchToken;
  }
  foreach (['native_criteria', 'native_metacriteria', 'native_sort', 'native_order', 'native_is_deleted', 'native_saved_search_id', 'native_parameters', 'native_execution_fingerprint', 'columns', 'native_saved_search_execution_ready'] as $internalKey) {
    unset($params[$internalKey]);
  }
  foreach ($columns as $column) {
    $params['columns'][] = $column;
  }
  foreach ($params as $key => $value) {
    if ($value === '' || $value === null) {
      unset($params[$key]);
    }
  }

  return '?' . http_build_query($params);
};

$sortUrl = static function (string $column) use ($filters, $queryUrl): string {
  $currentSort = (string) ($filters['sort'] ?? 'date_mod');
  $currentDirection = strtoupper((string) ($filters['direction'] ?? 'DESC'));
  $nextDirection = ($currentSort === $column && $currentDirection === 'ASC') ? 'DESC' : 'ASC';

  return $queryUrl([
    'sort' => $column,
    'direction' => $nextDirection,
    'native_default_search' => 0,
    'page' => 1,
  ]);
};

$ariaSort = static function (string $column) use ($filters): string {
  if ((string) ($filters['sort'] ?? 'date_mod') !== $column) {
    return 'none';
  }

  return strtoupper((string) ($filters['direction'] ?? 'DESC')) === 'ASC' ? 'ascending' : 'descending';
};

$sortMarker = static function (string $column) use ($filters): string {
  if ((string) ($filters['sort'] ?? 'date_mod') !== $column) {
    return '';
  }

  return strtoupper((string) ($filters['direction'] ?? 'DESC')) === 'ASC' ? ' crescente' : ' decrescente';
};

$groupLabel = glpiacessivel_t('Todos os grupos');
foreach ((array) ($group_options ?? []) as $groupOption) {
  if ((int) ($groupOption['id'] ?? 0) === (int) ($filters['group_id'] ?? 0)) {
    $groupLabel = (string) ($groupOption['label'] ?? $groupLabel);
    break;
  }
}

$activeFilters = [];
$activeFilters[glpiacessivel_t('Escopo')] = $scopeLabels[(string) ($filters['scope'] ?? 'all')]
  ?? glpiacessivel_t('Todos os chamados permitidos');
if (trim((string) ($filters['q'] ?? '')) !== '') {
  $activeFilters[glpiacessivel_t('Busca')] = (string) $filters['q'];
}
if ((string) ($filters['status'] ?? '') !== '') {
  $activeFilters[glpiacessivel_t('Status')] = $statusLabels[(string) $filters['status']] ?? (string) $filters['status'];
}
if ((int) ($filters['group_id'] ?? 0) > 0) {
  $activeFilters[glpiacessivel_t('Grupo responsável')] = $groupLabel;
}
if ((string) ($filters['group_by'] ?? 'none') !== 'none') {
  $activeFilters[glpiacessivel_t('Classificação')] = $groupByLabels[(string) $filters['group_by']]
    ?? glpiacessivel_t('Agrupar por grupo');
}

$appliedSearchSummary = is_array($applied_search_summary ?? null)
  ? $applied_search_summary
  : [];
$appliedSummarySections = [];
foreach ((array) ($appliedSearchSummary['sections'] ?? []) as $section) {
  if (!is_array($section)) {
    continue;
  }
  $sectionLabel = trim((string) ($section['label'] ?? ''));
  $sectionItems = array_values(array_filter(array_map(
    static fn($item): string => trim((string) $item),
    (array) ($section['items'] ?? [])
  ), static fn(string $item): bool => $item !== ''));
  if ($sectionLabel !== '' && $sectionItems !== []) {
    $appliedSummarySections[] = [
      'key' => trim((string) ($section['key'] ?? '')),
      'label' => $sectionLabel,
      'items' => $sectionItems,
    ];
  }
}
$appliedSummaryWarnings = array_values(array_filter(array_map(
  static fn($warning): string => trim((string) $warning),
  (array) ($appliedSearchSummary['warnings'] ?? [])
), static fn(string $warning): bool => $warning !== ''));
$appliedSummaryHeading = trim((string) ($appliedSearchSummary['heading'] ?? ''));
$appliedSummarySavedSearchName = trim((string) (
  $appliedSearchSummary['saved_search_name'] ?? ''
));
$appliedSummaryPlainText = trim((string) ($appliedSearchSummary['plain_text'] ?? ''));
$appliedSummaryNote = trim((string) ($appliedSearchSummary['note'] ?? ''));
$appliedSummaryActive = !empty($appliedSearchSummary['active']);

if ($appliedSearchSummary === []) {
  $fallbackItems = [];
  if ($advancedSearchActive) {
    $advancedSummary = trim((string) ($advancedSearchState['summary'] ?? ''));
    $fallbackItems[] = $advancedSummary !== ''
      ? $advancedSummary
      : sprintf(glpiacessivel_t('%d critérios avançados aplicados'), $advancedVisibleCriteriaCount);
  } else {
    foreach ($activeFilters as $filterName => $filterValue) {
      $fallbackItems[] = (string) $filterName . ': ' . (string) $filterValue;
    }
  }
  if ($fallbackItems !== []) {
    $appliedSummarySections[] = [
      'key' => 'fallback',
      'label' => $advancedSearchActive
        ? glpiacessivel_t('Pesquisa avançada')
        : glpiacessivel_t('Filtros'),
      'items' => $fallbackItems,
    ];
  }
  $appliedSummaryHeading = glpiacessivel_t('Resumo da consulta atual');
  $appliedSummarySavedSearchName = trim((string) ($activeSavedSearch['name'] ?? ''));
  $appliedSummaryPlainText = implode('. ', $fallbackItems);
  $appliedSummaryActive = $fallbackItems !== [];
}

if ($appliedSummaryHeading === '') {
  $appliedSummaryHeading = glpiacessivel_t('Resumo da consulta atual');
}
$appliedSummaryHeading = glpiacessivel_t('Resumo da consulta atual');
$frequentFilterConfiguredCount = 0;
if ((string) ($filters['scope'] ?? 'all') !== 'all') {
  $frequentFilterConfiguredCount++;
}
if ((string) ($filters['status'] ?? '') !== '') {
  $frequentFilterConfiguredCount++;
}
if ((int) ($filters['group_id'] ?? 0) > 0) {
  $frequentFilterConfiguredCount++;
}
$filterLayerConfiguredCount = $frequentFilterConfiguredCount + $advancedVisibleCriteriaCount;
$displayLayerConfiguredCount = count($advancedSearchSort);
if ((int) ($filters['page_size'] ?? 20) !== 20) {
  $displayLayerConfiguredCount++;
}
if ((string) ($filters['group_by'] ?? 'none') !== 'none') {
  $displayLayerConfiguredCount++;
}
if ((int) ($advancedSearchState['is_deleted'] ?? 0) === 1) {
  $displayLayerConfiguredCount++;
}
if ($columns !== $advancedSearchConfig['default_columns']) {
  $displayLayerConfiguredCount++;
}
$renderSortHeader = static function (
  string $column,
  string $label
) use ($sortUrl, $ariaSort, $sortMarker, $advancedSearchActive): void {
  if ($advancedSearchActive) {
    ?>
    <th scope="col" aria-sort="none">
      <?= glpiacessivel_e($label) ?>
      <span class="glpiacessivel-sr-only"><?= glpiacessivel_e(glpiacessivel_t('Use a seção Ordenação da busca avançada para alterar a ordem.')) ?></span>
    </th>
    <?php
    return;
  }
  ?>
  <th scope="col" aria-sort="<?= glpiacessivel_e($ariaSort($column)) ?>">
    <a class="glpiacessivel-sort-link" href="<?= glpiacessivel_e($sortUrl($column)) ?>">
      <?= glpiacessivel_e($label) ?><span class="glpiacessivel-sr-only"><?= glpiacessivel_e($sortMarker($column)) ?></span>
    </a>
  </th>
  <?php
};

$renderTicketHeaders = static function (bool $showGroup = true) use (
  $columns,
  $ticketColumnOptions,
  $renderSortHeader
): void {
  $sortableColumns = ['id', 'name', 'status', 'date', 'priority', 'date_mod'];
  foreach ($columns as $column) {
    if (!$showGroup && $column === 'group') {
      continue;
    }

    $label = (string) ($ticketColumnOptions[$column] ?? $column);
    if (in_array($column, $sortableColumns, true)) {
      $renderSortHeader($column, $label);
      continue;
    }
    ?>
    <th scope="col"><?= glpiacessivel_e($label) ?></th>
    <?php
  }
};

$renderTicketRow = static function (array $item, bool $showGroup = true) use ($columns): void {
  $ticketId = (int) ($item['id'] ?? 0);
  $ticketName = (string) ($item['name'] ?? '');
  $ticketUrl = glpiacessivel_url('front/tickets.php?id=' . $ticketId);
  ?>
  <tr>
    <td>
      <input
        type="checkbox"
        class="glpiacessivel-ticket-select"
        value="<?= $ticketId ?>"
        aria-label="<?= glpiacessivel_e(sprintf(glpiacessivel_t('Selecionar chamado %d'), $ticketId)) ?>"
      />
    </td>
    <?php foreach ($columns as $column): ?>
      <?php if (!$showGroup && $column === 'group') {
        continue;
      } ?>
      <?php switch ($column):
        case 'id': ?>
          <td><?= $ticketId ?></td>
          <?php break;
        case 'name': ?>
          <td>
            <a href="<?= glpiacessivel_e($ticketUrl) ?>" class="glpiacessivel-ticket-title-link">
              <?= glpiacessivel_e($ticketName) ?>
            </a>
          </td>
          <?php break;
        case 'status': ?>
          <td>
            <span class="glpiacessivel-badge glpiacessivel-badge-status-<?= glpiacessivel_e(glpiacessivel_status_class((int) ($item['status'] ?? 0))) ?>">
              <?= glpiacessivel_e(glpiacessivel_ticket_status((int) ($item['status'] ?? 0))) ?>
            </span>
          </td>
          <?php break;
        case 'priority': ?>
          <td>
            <span class="glpiacessivel-badge glpiacessivel-badge-priority-<?= glpiacessivel_e(glpiacessivel_priority_class((int) ($item['priority'] ?? 0))) ?>">
              <?= glpiacessivel_e(glpiacessivel_ticket_priority((int) ($item['priority'] ?? 0))) ?>
            </span>
          </td>
          <?php break;
        case 'group': ?>
          <td><?= glpiacessivel_e((string) ($item['primary_group_name'] ?? 'Sem grupo')) ?></td>
          <?php break;
        case 'requester': ?>
          <td><?= glpiacessivel_e(trim((string) ($item['requester_name'] ?? ''))) ?></td>
          <?php break;
        case 'assignee': ?>
          <td><?= glpiacessivel_e(trim((string) ($item['assignee_name'] ?? ''))) ?></td>
          <?php break;
        case 'category': ?>
          <td><?= glpiacessivel_e((string) ($item['category_name'] ?? '')) ?></td>
          <?php break;
        case 'entity': ?>
          <td><?= glpiacessivel_e((string) ($item['entity_name'] ?? '')) ?></td>
          <?php break;
        case 'location': ?>
          <td><?= glpiacessivel_e((string) ($item['location_name'] ?? '')) ?></td>
          <?php break;
        case 'date': ?>
          <td><?= glpiacessivel_e((string) ($item['date'] ?? '')) ?></td>
          <?php break;
        case 'date_mod': ?>
          <td><?= glpiacessivel_e((string) ($item['date_mod'] ?? '')) ?></td>
          <?php break;
        case 'time_to_resolve': ?>
          <td><?= glpiacessivel_e((string) ($item['time_to_resolve'] ?? '')) ?></td>
          <?php break;
      endswitch; ?>
    <?php endforeach; ?>
    <td>
      <a
        class="glpiacessivel-button glpiacessivel-button-secondary"
        href="<?= glpiacessivel_e($ticketUrl) ?>"
        aria-label="<?= glpiacessivel_e(sprintf(glpiacessivel_t('Abrir chamado %d: %s'), $ticketId, $ticketName)) ?>"
      ><?= glpiacessivel_e(glpiacessivel_t('Abrir')) ?></a>
    </td>
  </tr>
  <?php
};?>

<section class="glpiacessivel-section-head" aria-labelledby="tickets-intro">
  <p class="glpiacessivel-eyebrow"><?= glpiacessivel_e(glpiacessivel_t('Gestão de chamados')) ?></p>
  <h2 id="tickets-intro"><?= glpiacessivel_e(glpiacessivel_t('Chamados')) ?></h2>
  <p><?= glpiacessivel_e(glpiacessivel_t('Pesquise usando os mesmos campos autorizados para seu perfil e entidade no GLPI.')) ?></p>
</section>

<nav class="glpiacessivel-ticket-toolbar" aria-label="<?= glpiacessivel_e(glpiacessivel_t('Ações da listagem de chamados')) ?>">
  <?php if ($canCreateTicketFromList): ?>
  <a class="glpiacessivel-button" href="<?= glpiacessivel_e(glpiacessivel_url('front/ticket.create.php')) ?>"><?= glpiacessivel_e(glpiacessivel_t('Novo chamado')) ?></a>
  <?php endif; ?>
  <a class="glpiacessivel-button glpiacessivel-button-secondary" href="<?= glpiacessivel_e($queryUrl()) ?>"><?= glpiacessivel_e(glpiacessivel_t('Atualizar lista')) ?></a>
  <?php if ($nativeTicketUrl !== ''): ?>
  <a class="glpiacessivel-button glpiacessivel-button-secondary" href="<?= glpiacessivel_e($nativeTicketUrl) ?>"><?= glpiacessivel_e(glpiacessivel_t('Abrir a lista no GLPI')) ?></a>
  <?php endif; ?>
</nav>

<nav class="glpiacessivel-ticket-page-nav" aria-label="<?= glpiacessivel_e(glpiacessivel_t('Nesta página')) ?>">
  <strong><?= glpiacessivel_e(glpiacessivel_t('Nesta página')) ?></strong>
  <a href="#ticket-search-layer-quick"><?= glpiacessivel_e(glpiacessivel_t('Busca rápida')) ?></a>
  <a href="#tickets-filter-summary"><?= glpiacessivel_e(glpiacessivel_t('Resumo aplicado')) ?></a>
  <a href="#tickets-lista"><?= glpiacessivel_e(glpiacessivel_t('Resultados dos chamados')) ?></a>
  <a href="#tickets-pesquisas-salvas"><?= glpiacessivel_e(glpiacessivel_t('Pesquisas salvas')) ?></a>
</nav>

<section aria-labelledby="tickets-filtros" class="glpiacessivel-card glpiacessivel-ticket-search-workspace">
  <div class="glpiacessivel-card-heading">
    <div>
      <p class="glpiacessivel-eyebrow"><?= glpiacessivel_e(glpiacessivel_t('Pesquisa de chamados')) ?></p>
      <h2 id="tickets-filtros"><?= glpiacessivel_e(glpiacessivel_t('Pesquisar chamados')) ?></h2>
    </div>
    <p class="glpiacessivel-card-note"><?= glpiacessivel_e(glpiacessivel_t('A consulta respeita os campos, operadores, permissões e entidades autorizados pelo GLPI.')) ?></p>
  </div>

  <noscript>
    <div class="glpiacessivel-alert glpiacessivel-alert-info" role="status">
      <?= glpiacessivel_e(glpiacessivel_t('O construtor acessível requer JavaScript.')) ?>
      <?php if ($nativeTicketUrl !== ''): ?>
      <a href="<?= glpiacessivel_e($nativeTicketUrl) ?>"><?= glpiacessivel_e(glpiacessivel_t('Pesquisar no GLPI')) ?></a>.
      <?php endif; ?>
    </div>
  </noscript>

  <form
    id="ticket-advanced-search-form"
    method="post"
    action="<?= glpiacessivel_e(glpiacessivel_url('front/tickets.php')) ?>"
    class="glpiacessivel-advanced-search-form glpiacessivel-ticket-unified-search"
    role="search"
    aria-label="<?= glpiacessivel_e(glpiacessivel_t('Pesquisar chamados')) ?>"
    data-glpiacessivel-advanced-search-form
    data-editable="<?= $advancedSearchEditable ? '1' : '0' ?>"
    novalidate
  >
    <input type="hidden" name="_glpi_csrf_token" value="<?= glpiacessivel_e($csrf_token) ?>" />
    <input type="hidden" name="search_mode" value="advanced" />
    <input type="hidden" name="advanced[action]" value="search" />
    <input type="hidden" name="advanced[focus]" value="results" />
    <input
      type="hidden"
      name="advanced[context_revision]"
      value="<?= glpiacessivel_e((string) ($advancedSearchCatalog['context_revision'] ?? '')) ?>"
    />

    <section
      id="ticket-search-layer-quick"
      class="glpiacessivel-ticket-search-layer glpiacessivel-ticket-search-layer-quick"
      aria-labelledby="ticket-search-layer-quick-heading"
    >
      <div class="glpiacessivel-ticket-search-layer-heading">
        <p class="glpiacessivel-eyebrow"><?= glpiacessivel_e(glpiacessivel_t('Etapa 1')) ?></p>
        <h3 id="ticket-search-layer-quick-heading"><?= glpiacessivel_e(glpiacessivel_t('Busca rápida')) ?></h3>
        <p><?= glpiacessivel_e(glpiacessivel_t('Pesquise por ID, título ou descrição. Os filtros e as opções de exibição permanecem disponíveis nas etapas seguintes.')) ?></p>
      </div>
      <div class="glpiacessivel-ticket-search-basics">
        <div class="glpiacessivel-field glpiacessivel-ticket-search-text">
          <label for="q"><?= glpiacessivel_e(glpiacessivel_t('ID, título ou descrição')) ?></label>
          <input
            id="q"
            type="search"
            name="q"
            maxlength="120"
            value="<?= glpiacessivel_e((string) ($filters['q'] ?? '')) ?>"
            autocomplete="off"
            aria-describedby="ticket-search-text-help"
          />
          <p id="ticket-search-text-help" class="glpiacessivel-help-text"><?= glpiacessivel_e(glpiacessivel_t('A busca rápida será combinada com os filtros configurados, mas os resultados só mudarão depois de Pesquisar.')) ?></p>
        </div>
        <div class="glpiacessivel-ticket-search-primary-actions">
          <button type="submit" class="glpiacessivel-search-tool-primary" <?= !$advancedSearchEditable ? 'disabled' : '' ?>>
            <svg class="glpiacessivel-search-tool-icon" viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path d="m21 21-4.35-4.35m2.35-5.15A7.5 7.5 0 1 1 4 11.5a7.5 7.5 0 0 1 15 0Z" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" /></svg>
            <span><?= glpiacessivel_e(glpiacessivel_t('Pesquisar')) ?></span>
          </button>
          <a class="glpiacessivel-button glpiacessivel-button-secondary" href="<?= glpiacessivel_e(glpiacessivel_url('front/tickets.php?saved_search=')) ?>">
            <?= glpiacessivel_e(glpiacessivel_t('Limpar consulta')) ?>
          </a>
        </div>
      </div>
    </section>

    <?php if ($advancedSearchErrors !== []): ?>
      <div
        class="glpiacessivel-alert glpiacessivel-alert-error"
        id="ticket-advanced-search-errors"
        role="alert"
        tabindex="-1"
        data-glpiacessivel-advanced-errors
      >
        <h3><?= glpiacessivel_e(glpiacessivel_t('Revise a busca avançada')) ?></h3>
        <ul>
          <?php foreach ($advancedSearchErrors as $advancedSearchError): ?>
            <li><?= glpiacessivel_e($advancedSearchError) ?></li>
          <?php endforeach; ?>
        </ul>
      </div>
    <?php else: ?>
      <div
        class="glpiacessivel-alert glpiacessivel-alert-error"
        id="ticket-advanced-search-errors"
        role="alert"
        tabindex="-1"
        data-glpiacessivel-advanced-errors
        hidden
      >
        <h3><?= glpiacessivel_e(glpiacessivel_t('Revise a busca avançada')) ?></h3>
        <ul></ul>
      </div>
    <?php endif; ?>

    <?php if (!$advancedSearchEditable): ?>
      <div class="glpiacessivel-alert glpiacessivel-alert-info" role="status">
        <?= glpiacessivel_e(glpiacessivel_t('Esta pesquisa pode ser aplicada, mas contém recursos que não podem ser editados fielmente neste portal. Nenhum critério foi simplificado.')) ?>
      </div>
    <?php endif; ?>

    <nav
      class="glpiacessivel-ticket-search-actions glpiacessivel-ticket-search-tools glpiacessivel-ticket-search-layer-nav"
      aria-label="<?= glpiacessivel_e(glpiacessivel_t('Etapas adicionais da pesquisa')) ?>"
      data-glpiacessivel-search-tools
    >
      <button
        type="button"
        class="glpiacessivel-button glpiacessivel-button-secondary"
        aria-expanded="true"
        aria-controls="ticket-search-tool-saved-searches"
        data-glpiacessivel-search-tool-trigger="saved-searches"
      >
        <svg class="glpiacessivel-search-tool-icon" viewBox="0 0 24 24" aria-hidden="true" focusable="false"><circle cx="10.5" cy="10.5" r="6.5" fill="none" stroke="currentColor" stroke-width="2" /><path d="m15.5 15.5 5 5" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" /></svg>
        <span><?= glpiacessivel_e(glpiacessivel_t('Acesso recorrente')) ?></span>
        <span class="glpiacessivel-filter-count" data-glpiacessivel-layer-state="saved-searches">
          <?= $appliedSummarySavedSearchName !== ''
            ? glpiacessivel_e(glpiacessivel_t('Pesquisa aplicada'))
            : glpiacessivel_e(sprintf(glpiacessivel_t('%d disponíveis'), $nativeCatalogTotal)) ?>
        </span>
      </button>
      <button
        type="button"
        class="glpiacessivel-button glpiacessivel-button-secondary"
        aria-expanded="true"
        aria-controls="ticket-search-tool-filters"
        data-glpiacessivel-search-tool-trigger="filters"
      >
        <svg class="glpiacessivel-search-tool-icon" viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path d="M4 5h16M7 12h10m-7 7h4" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" /></svg>
        <span><?= glpiacessivel_e(glpiacessivel_t('2. Filtros')) ?></span>
        <span class="glpiacessivel-filter-count" data-glpiacessivel-layer-state="filters"><?= glpiacessivel_e(sprintf(glpiacessivel_t('%d configurados'), $filterLayerConfiguredCount)) ?></span>
      </button>
      <button
        type="button"
        class="glpiacessivel-button glpiacessivel-button-secondary"
        aria-expanded="true"
        aria-controls="ticket-search-tool-result-options"
        data-glpiacessivel-search-tool-trigger="result-options"
      >
        <svg class="glpiacessivel-search-tool-icon" viewBox="0 0 24 24" aria-hidden="true" focusable="false"><circle cx="12" cy="12" r="3" fill="none" stroke="currentColor" stroke-width="2" /><path d="M19.4 15a1.7 1.7 0 0 0 .34 1.88l.06.06-2.12 2.12-.06-.06a1.7 1.7 0 0 0-1.88-.34 1.7 1.7 0 0 0-1.03 1.56V20.3h-3v-.08a1.7 1.7 0 0 0-1.03-1.56A1.7 1.7 0 0 0 8.8 19l-.06.06-2.12-2.12.06-.06A1.7 1.7 0 0 0 7.02 15a1.7 1.7 0 0 0-1.56-1.03h-.08v-3h.08A1.7 1.7 0 0 0 7.02 9.9a1.7 1.7 0 0 0-.34-1.88l-.06-.06 2.12-2.12.06.06a1.7 1.7 0 0 0 1.88.34A1.7 1.7 0 0 0 11.71 4.7v-.08h3v.08a1.7 1.7 0 0 0 1.03 1.56 1.7 1.7 0 0 0 1.88-.34l.06-.06 2.12 2.12-.06.06a1.7 1.7 0 0 0-.34 1.88 1.7 1.7 0 0 0 1.56 1.03h.08v3h-.08A1.7 1.7 0 0 0 19.4 15Z" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linejoin="round" /></svg>
        <span><?= glpiacessivel_e(glpiacessivel_t('3. Exibição dos resultados')) ?></span>
        <span class="glpiacessivel-filter-count" data-glpiacessivel-layer-state="display"><?= glpiacessivel_e(sprintf(glpiacessivel_t('%d opções'), $displayLayerConfiguredCount)) ?></span>
      </button>
    </nav>

    <section
      id="ticket-search-tool-filters"
      class="glpiacessivel-search-tool-panel glpiacessivel-ticket-filter-layer"
      aria-labelledby="ticket-search-tool-filters-heading"
      tabindex="-1"
      data-glpiacessivel-search-tool-panel="filters"
      data-glpiacessivel-search-tool-initial-open="<?= $advancedSearchErrors !== [] ? '1' : '0' ?>"
    >
      <div class="glpiacessivel-search-tool-panel-heading">
        <div>
          <p class="glpiacessivel-eyebrow"><?= glpiacessivel_e(glpiacessivel_t('Etapa 2')) ?></p>
          <h3 id="ticket-search-tool-filters-heading"><?= glpiacessivel_e(glpiacessivel_t('Filtros')) ?></h3>
          <p><?= glpiacessivel_e(glpiacessivel_t('Comece pelos filtros frequentes. Abra os filtros avançados somente quando precisar combinar regras do GLPI.')) ?></p>
        </div>
        <button type="button" class="glpiacessivel-button glpiacessivel-button-secondary" data-glpiacessivel-search-tool-close="filters"><?= glpiacessivel_e(glpiacessivel_t('Fechar filtros')) ?></button>
      </div>

      <section class="glpiacessivel-ticket-frequent-filters" aria-labelledby="ticket-frequent-filters-heading">
        <h4 id="ticket-frequent-filters-heading"><?= glpiacessivel_e(glpiacessivel_t('Filtros frequentes')) ?></h4>
        <div class="glpiacessivel-ticket-frequent-filter-grid">
          <div class="glpiacessivel-field">
            <label for="scope"><?= glpiacessivel_e(glpiacessivel_t('Escopo')) ?></label>
            <select id="scope" name="scope">
              <?php foreach ($scopeLabels as $scopeValue => $scopeLabel): ?>
                <option value="<?= glpiacessivel_e($scopeValue) ?>" <?= ($filters['scope'] ?? 'all') === $scopeValue ? 'selected' : '' ?>><?= glpiacessivel_e($scopeLabel) ?></option>
              <?php endforeach; ?>
            </select>
          </div>
          <div class="glpiacessivel-field">
            <label for="ticket-filter-status"><?= glpiacessivel_e(glpiacessivel_t('Status')) ?></label>
            <select id="ticket-filter-status" name="status" aria-describedby="ticket-filter-status-state"<?= in_array($draftStatusMode, ['saved_advanced', 'saved_native_only'], true) ? ' disabled' : '' ?>>
              <?php if (in_array($draftStatusMode, ['saved_advanced', 'saved_native_only'], true)): ?>
                <option value="" selected disabled><?= glpiacessivel_e(
                    $draftStatusMode === 'saved_native_only'
                      ? glpiacessivel_t('Definido na pesquisa nativa do GLPI')
                      : glpiacessivel_t('Definido nos filtros avançados')
                ) ?></option>
              <?php endif; ?>
              <?php foreach ($statusLabels as $statusValue => $statusLabel): ?>
                <option value="<?= glpiacessivel_e($statusValue) ?>" <?= !in_array($draftStatusMode, ['saved_advanced', 'saved_native_only'], true) && $draftStatus === (string) $statusValue ? 'selected' : '' ?>><?= glpiacessivel_e($statusLabel) ?></option>
              <?php endforeach; ?>
            </select>
            <p id="ticket-filter-status-state" class="glpiacessivel-help-text">
              <?php if ($draftStatusMode === 'saved_simple'): ?>
                <?= glpiacessivel_e(sprintf(
                    glpiacessivel_t('Aplicado pela pesquisa salva %s. Alterar este campo modifica somente a execução atual.'),
                    trim((string) ($activeSavedSearch['name'] ?? ''))
                )) ?>
              <?php elseif ($draftStatusMode === 'saved_advanced'): ?>
                <?= glpiacessivel_e(glpiacessivel_t('O status faz parte de uma expressão avançada e não pode ser representado como um único valor. Edite essa regra nos filtros avançados para preservar sua lógica.')) ?>
              <?php elseif ($draftStatusMode === 'saved_native_only'): ?>
                <?= glpiacessivel_e(glpiacessivel_t('Os critérios desta pesquisa são executados pelo GLPI e não podem ser representados com segurança neste seletor. Use o link da pesquisa completa para consultá-los.')) ?>
              <?php else: ?>
                <?= glpiacessivel_e(glpiacessivel_t('Escolha um status ou mantenha Sem filtro adicional de status para não aplicar este filtro.')) ?>
              <?php endif; ?>
            </p>
          </div>
          <?php if (!empty($group_options)): ?>
            <div class="glpiacessivel-field">
              <label for="ticket-filter-group"><?= glpiacessivel_e(glpiacessivel_t('Grupo responsável')) ?></label>
              <select id="ticket-filter-group" name="group_id">
                <option value="0"><?= glpiacessivel_e(glpiacessivel_t('Todos os grupos permitidos')) ?></option>
                <?php foreach ((array) $group_options as $groupOption): ?>
                  <?php $groupOptionId = (int) ($groupOption['id'] ?? 0); ?>
                  <option value="<?= $groupOptionId ?>" <?= $draftGroupId === $groupOptionId ? 'selected' : '' ?>><?= glpiacessivel_e((string) ($groupOption['label'] ?? '')) ?></option>
                <?php endforeach; ?>
              </select>
            </div>
          <?php endif; ?>
        </div>
      </section>

      <details class="glpiacessivel-ticket-advanced-filters" <?= $advancedSearchActive ? 'open' : '' ?>>
        <summary>
          <span><?= glpiacessivel_e(glpiacessivel_t('Filtros avançados')) ?></span>
          <span class="glpiacessivel-filter-count" data-glpiacessivel-advanced-rule-count><?= glpiacessivel_e(sprintf(glpiacessivel_t('%d regras'), $advancedVisibleCriteriaCount)) ?></span>
        </summary>
        <div class="glpiacessivel-ticket-advanced-filters-content">
          <section class="glpiacessivel-advanced-search-section" aria-labelledby="advanced-criteria-heading">
            <div class="glpiacessivel-advanced-section-heading">
              <div>
                <h4 id="advanced-criteria-heading"><?= glpiacessivel_e(glpiacessivel_t('Regras da pesquisa')) ?></h4>
                <p class="glpiacessivel-help-text"><?= glpiacessivel_e(glpiacessivel_t('Combine campo, condição e valor. A partir da segunda regra, escolha o conector adequado.')) ?></p>
              </div>
            </div>
            <ol class="glpiacessivel-advanced-search-list" data-glpiacessivel-criteria-list aria-label="<?= glpiacessivel_e(glpiacessivel_t('Critérios da busca avançada')) ?>"></ol>
            <div class="glpiacessivel-advanced-search-add-actions" role="group" aria-label="<?= glpiacessivel_e(glpiacessivel_t('Adicionar regras à pesquisa')) ?>">
              <button type="button" class="glpiacessivel-button glpiacessivel-button-secondary" data-glpiacessivel-add-criterion><?= glpiacessivel_e(glpiacessivel_t('Adicionar regra')) ?></button>
              <button type="button" class="glpiacessivel-button glpiacessivel-button-secondary" data-glpiacessivel-add-global-rule><?= glpiacessivel_e(glpiacessivel_t('Adicionar regra global')) ?></button>
              <button type="button" class="glpiacessivel-button glpiacessivel-button-secondary" data-glpiacessivel-add-group><?= glpiacessivel_e(glpiacessivel_t('Adicionar grupo')) ?></button>
            </div>
          </section>

          <section class="glpiacessivel-advanced-search-section glpiacessivel-advanced-global-section" aria-labelledby="advanced-global-rules-heading">
            <h4 id="advanced-global-rules-heading"><?= glpiacessivel_e(glpiacessivel_t('Regras globais adicionadas')) ?></h4>
            <p class="glpiacessivel-help-text"><?= glpiacessivel_e(glpiacessivel_t('As regras globais consultam campos relacionados autorizados pelo GLPI.')) ?></p>
            <ol class="glpiacessivel-advanced-search-list" data-glpiacessivel-global-rules-list aria-label="<?= glpiacessivel_e(glpiacessivel_t('Regras globais da busca avançada')) ?>"></ol>
          </section>
        </div>
      </details>

      <div class="glpiacessivel-ticket-search-primary-actions">
        <button
          type="submit"
          class="glpiacessivel-button glpiacessivel-button-primary"
          data-glpiacessivel-apply-ticket-filters
        ><?= glpiacessivel_e(glpiacessivel_t('Aplicar filtros e pesquisar')) ?></button>
      </div>
    </section>

    <section
      id="ticket-search-tool-result-options"
      class="glpiacessivel-search-tool-panel glpiacessivel-advanced-result-options glpiacessivel-ticket-display-layer"
      aria-labelledby="ticket-search-tool-result-options-heading"
      tabindex="-1"
      data-glpiacessivel-search-tool-panel="result-options"
    >
      <div class="glpiacessivel-search-tool-panel-heading">
        <div>
          <p class="glpiacessivel-eyebrow"><?= glpiacessivel_e(glpiacessivel_t('Etapa 3')) ?></p>
          <h3 id="ticket-search-tool-result-options-heading"><?= glpiacessivel_e(glpiacessivel_t('Exibição dos resultados')) ?></h3>
          <p class="glpiacessivel-help-text" data-glpiacessivel-result-options-summary><?= glpiacessivel_e(sprintf(glpiacessivel_t('Ordenação e exibição: %d ordenações; %d itens por página; %d colunas.'), count($advancedSearchSort), (int) ($filters['page_size'] ?? 20), count($columns))) ?></p>
        </div>
        <button type="button" class="glpiacessivel-button glpiacessivel-button-secondary" data-glpiacessivel-search-tool-close="result-options">
          <svg class="glpiacessivel-search-tool-icon" viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path d="m6 6 12 12M18 6 6 18" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" /></svg>
          <span><?= glpiacessivel_e(glpiacessivel_t('Fechar exibição')) ?></span>
        </button>
      </div>
      <div class="glpiacessivel-advanced-result-options-content">
        <section class="glpiacessivel-advanced-search-section" aria-labelledby="advanced-sorts-heading">
          <h4 id="advanced-sorts-heading"><?= glpiacessivel_e(glpiacessivel_t('Ordenação')) ?></h4>
          <p class="glpiacessivel-help-text"><?= glpiacessivel_e(glpiacessivel_t('Defina até cinco campos. A primeira ordenação tem maior prioridade.')) ?></p>
          <ol
            class="glpiacessivel-advanced-sort-list"
            data-glpiacessivel-sorts-list
            aria-label="<?= glpiacessivel_e(glpiacessivel_t('Ordenações dos resultados')) ?>"
          ></ol>
          <button type="button" class="glpiacessivel-button glpiacessivel-button-secondary" data-glpiacessivel-add-sort>
            <?= glpiacessivel_e(glpiacessivel_t('Adicionar ordenação')) ?>
          </button>
        </section>

        <div class="glpiacessivel-ticket-result-settings">
          <div class="glpiacessivel-field glpiacessivel-ticket-filter-pagesize">
            <label for="advanced_page_size"><?= glpiacessivel_e(glpiacessivel_t('Itens por página')) ?></label>
            <select id="advanced_page_size" name="advanced[page_size]">
              <?php foreach ([10, 20, 50, 100] as $option): ?>
                <option value="<?= $option ?>" <?= (int) ($filters['page_size'] ?? 20) === $option ? 'selected' : '' ?>><?= $option ?></option>
              <?php endforeach; ?>
            </select>
          </div>
          <div class="glpiacessivel-field glpiacessivel-ticket-filter-grouping">
            <label for="ticket-group-by"><?= glpiacessivel_e(glpiacessivel_t('Agrupamento')) ?></label>
            <select id="ticket-group-by" name="group_by">
              <?php foreach ($groupByLabels as $groupByValue => $groupByLabel): ?>
                <option value="<?= glpiacessivel_e($groupByValue) ?>" <?= (string) ($filters['group_by'] ?? 'none') === $groupByValue ? 'selected' : '' ?>><?= glpiacessivel_e($groupByLabel) ?></option>
              <?php endforeach; ?>
            </select>
          </div>
          <div class="glpiacessivel-field glpiacessivel-ticket-column-summary">
            <span class="glpiacessivel-field-label"><?= glpiacessivel_e(glpiacessivel_t('Colunas dos resultados')) ?></span>
            <button
              type="button"
              class="glpiacessivel-button glpiacessivel-button-secondary"
              data-glpiacessivel-open-columns
              aria-haspopup="dialog"
              aria-controls="ticket-column-dialog"
            ><span
              data-glpiacessivel-column-opener-label
              data-glpiacessivel-column-count="<?= count($columns) ?>"
            ><?= glpiacessivel_e(sprintf(glpiacessivel_t('Escolher colunas (%d selecionadas)'), count($columns))) ?></span></button>
            <p class="glpiacessivel-help-text"><?= glpiacessivel_e(glpiacessivel_t('ID e título permanecem disponíveis para identificar e abrir o chamado.')) ?></p>
          </div>
        </div>

        <?php if (!empty($advancedSearchCatalog['capabilities']['allow_deleted'])): ?>
          <fieldset class="glpiacessivel-advanced-deleted-scope">
            <legend><?= glpiacessivel_e(glpiacessivel_t('Registros incluídos na próxima pesquisa')) ?></legend>
            <label>
              <input type="radio" name="advanced[deleted_scope]" value="active" <?= (int) ($advancedSearchState['is_deleted'] ?? 0) !== 1 ? 'checked' : '' ?> />
              <?= glpiacessivel_e(glpiacessivel_t('Somente chamados ativos')) ?>
            </label>
            <label>
              <input type="radio" name="advanced[deleted_scope]" value="deleted" <?= (int) ($advancedSearchState['is_deleted'] ?? 0) === 1 ? 'checked' : '' ?> />
              <?= glpiacessivel_e(glpiacessivel_t('Somente chamados excluídos')) ?>
            </label>
            <p class="glpiacessivel-help-text"><?= glpiacessivel_e(glpiacessivel_t('A alteração será aplicada somente quando você ativar Pesquisar.')) ?></p>
          </fieldset>
        <?php endif; ?>

        <dialog
          id="ticket-column-dialog"
          class="glpiacessivel-column-dialog"
          aria-labelledby="ticket-column-dialog-heading"
          data-glpiacessivel-column-dialog
        >
          <div class="glpiacessivel-column-dialog-head">
            <div>
              <p class="glpiacessivel-eyebrow"><?= glpiacessivel_e(glpiacessivel_t('Resultados dos chamados')) ?></p>
              <h3 id="ticket-column-dialog-heading"><?= glpiacessivel_e(glpiacessivel_t('Escolher e ordenar colunas')) ?></h3>
            </div>
            <button type="button" class="glpiacessivel-button glpiacessivel-button-secondary" data-glpiacessivel-close-columns><?= glpiacessivel_e(glpiacessivel_t('Fechar')) ?></button>
          </div>
          <p class="glpiacessivel-help-text"><?= glpiacessivel_e(glpiacessivel_t('Adicione, remova ou reordene as informações. Ao aplicar, toda a consulta em edição será pesquisada e a tabela usará esta ordem de colunas.')) ?></p>
          <div class="glpiacessivel-column-dialog-add">
            <div class="glpiacessivel-field">
              <label for="ticket-column-add"><?= glpiacessivel_e(glpiacessivel_t('Coluna disponível')) ?></label>
              <select id="ticket-column-add" data-glpiacessivel-column-add>
                <option value=""><?= glpiacessivel_e(glpiacessivel_t('Selecione uma coluna')) ?></option>
                <?php foreach ($ticketColumnOptions as $columnIdentifier => $columnLabel): ?>
                  <option value="<?= glpiacessivel_e($columnIdentifier) ?>"><?= glpiacessivel_e($columnLabel) ?></option>
                <?php endforeach; ?>
              </select>
            </div>
            <button type="button" class="glpiacessivel-button glpiacessivel-button-secondary" data-glpiacessivel-add-column><?= glpiacessivel_e(glpiacessivel_t('Adicionar coluna')) ?></button>
          </div>
          <ol class="glpiacessivel-column-list" data-glpiacessivel-column-list aria-label="<?= glpiacessivel_e(glpiacessivel_t('Colunas selecionadas, na ordem de exibição')) ?>">
            <?php foreach (array_values(array_unique($columns)) as $selectedColumn): ?>
              <?php
                if (!array_key_exists($selectedColumn, $ticketColumnOptions)) {
                  continue;
                }
                $selectedColumnLocked = in_array($selectedColumn, $requiredTicketColumns, true);
              ?>
              <li
                data-column-id="<?= glpiacessivel_e($selectedColumn) ?>"
                data-column-label="<?= glpiacessivel_e($ticketColumnOptions[$selectedColumn]) ?>"
                data-column-locked="<?= $selectedColumnLocked ? '1' : '0' ?>"
              >
                <span><?= glpiacessivel_e($ticketColumnOptions[$selectedColumn]) ?></span>
                <?php if ($selectedColumnLocked): ?>
                  <span class="glpiacessivel-badge"><?= glpiacessivel_e(glpiacessivel_t('Obrigatória')) ?></span>
                <?php else: ?>
                  <button type="button" class="glpiacessivel-button glpiacessivel-button-secondary" data-glpiacessivel-column-remove>
                    <?= glpiacessivel_e(sprintf(glpiacessivel_t('Remover %s'), $ticketColumnOptions[$selectedColumn])) ?>
                  </button>
                <?php endif; ?>
              </li>
            <?php endforeach; ?>
          </ol>
          <div class="glpiacessivel-column-dialog-actions glpiacessivel-column-dialog-footer">
            <button type="button" class="glpiacessivel-button glpiacessivel-button-primary" data-glpiacessivel-apply-columns><?= glpiacessivel_e(glpiacessivel_t('Aplicar colunas e pesquisar')) ?></button>
            <button type="button" class="glpiacessivel-button glpiacessivel-button-secondary" data-glpiacessivel-reset-columns><?= glpiacessivel_e(glpiacessivel_t('Restaurar colunas padrão')) ?></button>
            <button type="button" class="glpiacessivel-button glpiacessivel-button-secondary" data-glpiacessivel-close-columns><?= glpiacessivel_e(glpiacessivel_t('Cancelar')) ?></button>
          </div>
        </dialog>
      </div>
    </section>

    <input type="hidden" name="advanced_schema_version" value="3" />
    <input type="hidden" name="advanced_request_complete" value="1" />

    <section class="glpiacessivel-query-draft-summary" aria-labelledby="ticket-query-draft-heading">
      <h3 id="ticket-query-draft-heading"><?= glpiacessivel_e(glpiacessivel_t('Consulta em edição')) ?></h3>
      <p class="glpiacessivel-help-text"><?= glpiacessivel_e(glpiacessivel_t('Estas escolhas ainda não alteraram os resultados. Use Pesquisar para aplicá-las.')) ?></p>
      <p data-glpiacessivel-advanced-summary><?= glpiacessivel_e(glpiacessivel_t('Nenhum filtro configurado na consulta em edição.')) ?></p>
    </section>
  </form>

<section
  id="ticket-search-tool-saved-searches"
  class="glpiacessivel-card glpiacessivel-saved-searches glpiacessivel-search-tool-panel glpiacessivel-saved-search-tool-panel"
  aria-labelledby="tickets-pesquisas-salvas"
  tabindex="-1"
  data-glpiacessivel-search-tool-panel="saved-searches"
  data-glpiacessivel-search-tool-initial-open="<?= (isset($_GET['manage_saved_search']) || !empty($saved_search_invalid) || $nativeCatalogFocusResults) ? '1' : '0' ?>"
>
  <div class="glpiacessivel-card-heading glpiacessivel-search-tool-panel-heading">
    <div>
      <p class="glpiacessivel-eyebrow"><?= glpiacessivel_e(glpiacessivel_t('Acesso recorrente')) ?></p>
      <h2 id="tickets-pesquisas-salvas"><?= glpiacessivel_e(glpiacessivel_t('Pesquisas salvas do GLPI')) ?></h2>
      <p class="glpiacessivel-card-note">
        <?= glpiacessivel_e(glpiacessivel_t('Consulte e gerencie as pesquisas mantidas no próprio GLPI. Nenhuma cópia é criada pelo plugin.')) ?>
      </p>
    </div>
    <button type="button" class="glpiacessivel-button glpiacessivel-button-secondary" data-glpiacessivel-search-tool-close="saved-searches">
      <svg class="glpiacessivel-search-tool-icon" viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path d="m6 6 12 12M18 6 6 18" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" /></svg>
      <span><?= glpiacessivel_e(glpiacessivel_t('Fechar')) ?></span>
    </button>
  </div>

  <div class="glpiacessivel-saved-search-manager-content">
  <?php if (!empty($saved_search_invalid)): ?>
    <div class="glpiacessivel-alert glpiacessivel-alert-error" role="alert" tabindex="-1" id="saved-search-unavailable">
      <strong><?= __('Pesquisa salva indisponível.', 'glpiacessivel') ?></strong>
      <p><?= __('Ela pode ter sido excluída ou deixado de estar disponível para seu perfil e entidade. Nenhum chamado foi exibido para evitar uma lista diferente da esperada.', 'glpiacessivel') ?></p>
      <a class="glpiacessivel-button glpiacessivel-button-secondary" href="<?= glpiacessivel_e(glpiacessivel_url('front/tickets.php?saved_search=')) ?>">
        <?= __('Limpar pesquisa indisponível', 'glpiacessivel') ?>
      </a>
    </div>
  <?php endif; ?>

  <?php if ($activeSavedSearch !== null && ($activeSavedSearch['origin'] ?? '') === 'glpi'): ?>
    <div class="glpiacessivel-active-saved-search">
      <p role="status" aria-live="polite" aria-atomic="true">
        <strong><?= $savedSearchExecutionBlocked
          ? __('Pesquisa salva indisponível.', 'glpiacessivel')
          : __('Pesquisa aplicada:', 'glpiacessivel') ?></strong>
        <?= glpiacessivel_e((string) ($activeSavedSearch['name'] ?? '')) ?>.
      </p>
      <?php if (
        ($activeSavedSearch['capability'] ?? $activeSavedSearch['compatibility'] ?? '') === 'native_only'
        || !empty($activeSavedSearch['execution_blocked'])
      ): ?>
        <?php if ($savedSearchSemanticsChanged || ($filters['saved_search_failure_code'] ?? '') === 'native_resolved_semantics_changed'): ?>
        <p><?= glpiacessivel_e(glpiacessivel_t('Esta pesquisa requer revisão dos filtros no perfil atual. Abrir a pesquisa no GLPI também pode aplicar apenas parte dos filtros.')) ?></p>
        <?php else: ?>
        <p><?= __('Os critérios completos desta pesquisa devem ser consultados no GLPI.', 'glpiacessivel') ?></p>
        <?php if ($nativeTicketUrl !== ''): ?>
        <a href="<?= glpiacessivel_e((string) ($activeSavedSearch['native_url'] ?? $nativeTicketUrl)) ?>">
          <?= __('Abrir pesquisa completa no GLPI', 'glpiacessivel') ?>
        </a>
        <?php endif; ?>
        <?php endif; ?>
      <?php endif; ?>
    </div>
  <?php endif; ?>

  <?php if ($nativeCatalogDefaultItem !== null): ?>
    <aside class="glpiacessivel-native-search-default" aria-labelledby="native-search-default-heading">
      <h3 id="native-search-default-heading"><?= __('Pesquisa padrão atual', 'glpiacessivel') ?></h3>
      <p><?= glpiacessivel_e((string) ($nativeCatalogDefaultItem['name'] ?? __('Sem nome', 'glpiacessivel'))) ?></p>
    </aside>
  <?php endif; ?>

  <form
    method="get"
    action="<?= glpiacessivel_e(glpiacessivel_url('front/tickets.php')) ?>"
    class="glpiacessivel-native-search-catalog-form"
    role="search"
    aria-label="<?= glpiacessivel_e(__('Pesquisar no catálogo de pesquisas salvas do GLPI', 'glpiacessivel')) ?>"
  >
    <?php foreach (['scope', 'status', 'q', 'group_id', 'group_by', 'page', 'page_size', 'sort', 'direction', 'saved_search'] as $filterKey): ?>
      <?php if ((string) ($filters[$filterKey] ?? '') !== ''): ?>
        <input type="hidden" name="<?= glpiacessivel_e($filterKey) ?>" value="<?= glpiacessivel_e((string) $filters[$filterKey]) ?>" />
      <?php endif; ?>
    <?php endforeach; ?>
    <?php foreach ($columns as $column): ?>
      <input type="hidden" name="columns[]" value="<?= glpiacessivel_e((string) $column) ?>" />
    <?php endforeach; ?>
    <?php if ($advancedSearchToken !== ''): ?>
      <input type="hidden" name="advanced_search_token" value="<?= glpiacessivel_e($advancedSearchToken) ?>" />
    <?php endif; ?>
    <div class="glpiacessivel-field">
      <label for="saved_search_q"><?= __('Buscar pesquisa salva por nome', 'glpiacessivel') ?></label>
      <input
        id="saved_search_q"
        type="search"
        name="saved_search_q"
        maxlength="120"
        value="<?= glpiacessivel_e($nativeCatalogQuery) ?>"
        autocomplete="off"
        aria-describedby="saved-search-catalog-help"
      />
      <p id="saved-search-catalog-help" class="glpiacessivel-help-text">
        <?= __('A busca só será executada depois que você ativar o botão Buscar pesquisas.', 'glpiacessivel') ?>
      </p>
    </div>
    <button type="submit"><?= __('Buscar pesquisas', 'glpiacessivel') ?></button>
    <?php if ($nativeCatalogQuery !== ''): ?>
      <a class="glpiacessivel-button glpiacessivel-button-secondary" href="<?= glpiacessivel_e($queryUrl([
        'saved_search_q' => null,
        'saved_search_cursor' => null,
      ])) ?>">
        <?= __('Limpar busca de pesquisas', 'glpiacessivel') ?>
      </a>
    <?php endif; ?>
  </form>

  <div class="glpiacessivel-native-search-results-head">
    <h3
      id="saved-search-catalog-results"
      tabindex="-1"
      <?= $nativeCatalogFocusResults ? 'data-glpiacessivel-catalog-results-focus' : '' ?>
    >
      <?= glpiacessivel_e(sprintf(
        _n('%d pesquisa nesta página', '%d pesquisas nesta página', count($nativeCatalogItems), 'glpiacessivel'),
        count($nativeCatalogItems)
      )) ?>
    </h3>
    <p><?= glpiacessivel_e(sprintf(__('São exibidas no máximo %d pesquisas por página.', 'glpiacessivel'), $nativeCatalogPageSize)) ?></p>
  </div>

  <?php if (!$canCreateNativeSearch && !$canEditNativeSearch): ?>
    <div class="glpiacessivel-alert glpiacessivel-alert-info" role="status">
      <p><?= __('As pesquisas são lidas diretamente do GLPI. As opções de alteração aparecem somente quando o GLPI autoriza a operação para seu perfil e para aquela pesquisa.', 'glpiacessivel') ?></p>
    </div>
  <?php endif; ?>

  <?php if ($canCreateNativeSearch): ?>
    <details id="create-native-saved-search" class="glpiacessivel-native-search-editor" <?= isset($_GET['manage_saved_search']) ? 'open' : '' ?>>
      <summary><?= __('Criar pesquisa salva no GLPI com os filtros atuais', 'glpiacessivel') ?></summary>
      <form method="post" action="<?= glpiacessivel_e($savedSearchActionUrl) ?>">
        <input type="hidden" name="_glpi_csrf_token" value="<?= glpiacessivel_e($csrf_token) ?>" />
        <input type="hidden" name="idempotency_key" value="<?= glpiacessivel_e($savedSearchIdempotencyKey()) ?>" />
        <input type="hidden" name="saved_search_action" value="create" />
        <?php if ($advancedSearchToken !== ''): ?>
          <input type="hidden" name="search_mode" value="advanced" />
          <input type="hidden" name="advanced_search_token" value="<?= glpiacessivel_e($advancedSearchToken) ?>" />
          <p class="glpiacessivel-help-text"><?= glpiacessivel_e(glpiacessivel_t('A pesquisa avançada aplicada será salva diretamente no GLPI.')) ?></p>
        <?php endif; ?>
        <?php foreach (['scope', 'status', 'q', 'group_id', 'group_by', 'page_size', 'sort', 'direction'] as $filterKey): ?>
          <input type="hidden" name="<?= glpiacessivel_e($filterKey) ?>" value="<?= glpiacessivel_e((string) ($filters[$filterKey] ?? '')) ?>" />
        <?php endforeach; ?>
        <?php foreach ($columns as $column): ?>
          <input type="hidden" name="columns[]" value="<?= glpiacessivel_e((string) $column) ?>" />
        <?php endforeach; ?>
        <div class="glpiacessivel-field">
          <label for="native_saved_search_name_create"><?= __('Nome da nova pesquisa no GLPI', 'glpiacessivel') ?></label>
          <input id="native_saved_search_name_create" name="saved_search_name" maxlength="180" required />
        </div>
        <label class="glpiacessivel-checkbox-row">
          <input type="checkbox" name="saved_search_default" value="1" />
          <?= __('Definir como minha pesquisa padrão', 'glpiacessivel') ?>
        </label>
        <button type="submit"><?= __('Criar pesquisa no GLPI', 'glpiacessivel') ?></button>
      </form>
    </details>
  <?php endif; ?>

  <?php if ($nativeCatalogItems === []): ?>
    <p class="glpiacessivel-empty-state" role="status">
      <?= $nativeCatalogQuery === ''
        ? __('Nenhuma pesquisa salva do GLPI está disponível para seu perfil e entidade.', 'glpiacessivel')
        : __('Nenhuma pesquisa salva corresponde à busca informada.', 'glpiacessivel') ?>
    </p>
  <?php else: ?>
    <ol class="glpiacessivel-native-search-catalog" aria-labelledby="saved-search-catalog-results">
      <?php foreach ($nativeCatalogItems as $savedIndex => $saved): ?>
        <?php
          $savedId = max(0, (int) ($saved['id'] ?? 0));
          $savedName = trim((string) ($saved['name'] ?? ''));
          $savedName = $savedName !== '' ? $savedName : __('Pesquisa sem nome', 'glpiacessivel');
          $savedKey = 'native:' . $savedId;
          $savedHeadingId = 'native-saved-search-' . $savedId . '-' . (int) $savedIndex;
          $savedCapabilities = is_array($saved['capabilities'] ?? null) ? $saved['capabilities'] : [];
          $savedCanEdit = !empty($savedCapabilities['can_edit']) || !empty($saved['can_edit']);
          $savedCanSetDefault = !empty($savedCapabilities['can_set_default']) || !empty($saved['can_set_default']);
          $savedCanUnsetDefault = !empty($savedCapabilities['can_unset_default']) || !empty($saved['can_unset_default']);
          $savedCanDelete = !empty($savedCapabilities['can_delete']) || !empty($saved['can_delete']);
          $savedIsDefault = !empty($saved['is_default']);
          $savedFingerprint = (string) ($saved['expected_fingerprint'] ?? $saved['fingerprint'] ?? '');
          $savedNativeUrl = $nativeTicketUrl !== ''
            ? trim((string) ($saved['native_url'] ?? $nativeTicketUrl))
            : '';
          $savedCapability = (string) ($saved['capability'] ?? $saved['compatibility'] ?? 'native_only');
          $savedVisibilityLabel = (string) ($saved['visibility'] ?? 'private') === 'private'
            ? __('Privada', 'glpiacessivel')
            : __('Compartilhada', 'glpiacessivel');
          $savedCriteriaCount = max(0, (int) ($saved['criteria_count'] ?? 0));
          $savedDeletePanelId = 'native-saved-search-delete-' . $savedId . '-' . (int) $savedIndex;
        ?>
        <li>
          <article class="glpiacessivel-native-search-card" aria-labelledby="<?= glpiacessivel_e($savedHeadingId) ?>">
            <div class="glpiacessivel-native-search-card-head">
              <h4 id="<?= glpiacessivel_e($savedHeadingId) ?>"><?= glpiacessivel_e($savedName) ?></h4>
              <?php if ($savedIsDefault): ?>
                <span class="glpiacessivel-badge"><?= __('Pesquisa padrão', 'glpiacessivel') ?></span>
              <?php endif; ?>
            </div>
            <dl class="glpiacessivel-native-search-meta">
              <div><dt><?= __('Visibilidade', 'glpiacessivel') ?></dt><dd><?= glpiacessivel_e($savedVisibilityLabel) ?></dd></div>
              <div><dt><?= __('Critérios', 'glpiacessivel') ?></dt><dd><?= $savedCriteriaCount ?></dd></div>
              <div>
                <dt><?= __('Disponibilidade', 'glpiacessivel') ?></dt>
                <dd><?= $savedCapability === 'native_only'
                  ? ($savedNativeUrl !== ''
                    ? __('Consultar no GLPI', 'glpiacessivel')
                    : __('Não disponível nesta interface', 'glpiacessivel'))
                  : __('Aplicável nesta lista acessível', 'glpiacessivel') ?></dd>
              </div>
            </dl>

            <div class="glpiacessivel-native-search-actions" role="group" aria-label="<?= glpiacessivel_e(sprintf(__('Ações para a pesquisa %s', 'glpiacessivel'), $savedName)) ?>">
              <?php if ($savedId > 0 && $savedCapability !== 'native_only'): ?>
                <a class="glpiacessivel-button" href="<?= glpiacessivel_e(glpiacessivel_url(
                  'front/tickets.php?saved_search=' . rawurlencode($savedKey)
                )) ?>"><?= glpiacessivel_e(sprintf(__('Aplicar: %s', 'glpiacessivel'), $savedName)) ?></a>
              <?php endif; ?>
              <?php if ($savedNativeUrl !== ''): ?>
              <a class="glpiacessivel-button glpiacessivel-button-secondary" href="<?= glpiacessivel_e($savedNativeUrl) ?>">
                <?= glpiacessivel_e(sprintf(__('Abrir no GLPI: %s', 'glpiacessivel'), $savedName)) ?>
              </a>
              <?php endif; ?>

              <?php if (!$savedIsDefault && $savedCanSetDefault && $savedId > 0): ?>
                <form method="post" action="<?= glpiacessivel_e($savedSearchActionUrl) ?>">
                  <input type="hidden" name="_glpi_csrf_token" value="<?= glpiacessivel_e($csrf_token) ?>" />
                  <input type="hidden" name="idempotency_key" value="<?= glpiacessivel_e($savedSearchIdempotencyKey()) ?>" />
                  <input type="hidden" name="saved_search_action" value="default" />
                  <input type="hidden" name="native_saved_search_id" value="<?= $savedId ?>" />
                  <input type="hidden" name="expected_fingerprint" value="<?= glpiacessivel_e($savedFingerprint) ?>" />
                  <button type="submit" class="glpiacessivel-button glpiacessivel-button-secondary">
                    <?= glpiacessivel_e(sprintf(__('Definir como padrão: %s', 'glpiacessivel'), $savedName)) ?>
                  </button>
                </form>
              <?php elseif ($savedIsDefault && $savedCanUnsetDefault && $savedId > 0): ?>
                <form method="post" action="<?= glpiacessivel_e($savedSearchActionUrl) ?>">
                  <input type="hidden" name="_glpi_csrf_token" value="<?= glpiacessivel_e($csrf_token) ?>" />
                  <input type="hidden" name="idempotency_key" value="<?= glpiacessivel_e($savedSearchIdempotencyKey()) ?>" />
                  <input type="hidden" name="saved_search_action" value="unset_default" />
                  <input type="hidden" name="native_saved_search_id" value="<?= $savedId ?>" />
                  <input type="hidden" name="expected_fingerprint" value="<?= glpiacessivel_e($savedFingerprint) ?>" />
                  <button type="submit" class="glpiacessivel-button glpiacessivel-button-secondary">
                    <?= glpiacessivel_e(sprintf(__('Remover como padrão: %s', 'glpiacessivel'), $savedName)) ?>
                  </button>
                </form>
              <?php endif; ?>

              <?php if ($savedCanDelete && $savedId > 0): ?>
                <button
                  type="button"
                  class="glpiacessivel-button glpiacessivel-button-secondary"
                  aria-expanded="false"
                  aria-controls="<?= glpiacessivel_e($savedDeletePanelId) ?>"
                  data-glpiacessivel-native-delete-open
                  data-open-announcement="<?= glpiacessivel_e(sprintf(__('Confirmação de exclusão aberta para %s.', 'glpiacessivel'), $savedName)) ?>"
                ><?= glpiacessivel_e(sprintf(__('Excluir: %s', 'glpiacessivel'), $savedName)) ?></button>
              <?php endif; ?>
            </div>

            <?php if ($savedCanEdit && $savedId > 0): ?>
              <details class="glpiacessivel-native-search-editor">
                <summary><?= glpiacessivel_e(sprintf(__('Renomear e ajustar padrão: %s', 'glpiacessivel'), $savedName)) ?></summary>
                <form method="post" action="<?= glpiacessivel_e($savedSearchActionUrl) ?>">
                  <input type="hidden" name="_glpi_csrf_token" value="<?= glpiacessivel_e($csrf_token) ?>" />
                  <input type="hidden" name="idempotency_key" value="<?= glpiacessivel_e($savedSearchIdempotencyKey()) ?>" />
                  <input type="hidden" name="saved_search_action" value="update" />
                  <input type="hidden" name="native_saved_search_id" value="<?= $savedId ?>" />
                  <input type="hidden" name="expected_fingerprint" value="<?= glpiacessivel_e($savedFingerprint) ?>" />
                  <p class="glpiacessivel-help-text"><?= __('Os critérios da pesquisa serão preservados exatamente como estão no GLPI.', 'glpiacessivel') ?></p>
                  <div class="glpiacessivel-field">
                    <label for="native_saved_search_name_<?= $savedId ?>_<?= (int) $savedIndex ?>">
                      <?= glpiacessivel_e(sprintf(__('Nome da pesquisa %s', 'glpiacessivel'), $savedName)) ?>
                    </label>
                    <input
                      id="native_saved_search_name_<?= $savedId ?>_<?= (int) $savedIndex ?>"
                      name="saved_search_name"
                      maxlength="180"
                      value="<?= glpiacessivel_e($savedName) ?>"
                      required
                    />
                  </div>
                  <label class="glpiacessivel-checkbox-row">
                    <input type="checkbox" name="saved_search_default" value="1" <?= $savedIsDefault ? 'checked' : '' ?> />
                    <?= __('Definir como minha pesquisa padrão', 'glpiacessivel') ?>
                  </label>
                  <button type="submit"><?= glpiacessivel_e(sprintf(__('Salvar nome e padrão no GLPI: %s', 'glpiacessivel'), $savedName)) ?></button>
                </form>
              </details>
            <?php endif; ?>

            <?php if ($savedCanDelete && $savedId > 0): ?>
              <section
                id="<?= glpiacessivel_e($savedDeletePanelId) ?>"
                class="glpiacessivel-native-search-delete-confirmation"
                role="region"
                aria-labelledby="<?= glpiacessivel_e($savedDeletePanelId) ?>-heading"
                aria-describedby="<?= glpiacessivel_e($savedDeletePanelId) ?>-description"
                data-glpiacessivel-native-delete-panel
                data-cancel-announcement="<?= glpiacessivel_e(sprintf(__('Exclusão cancelada para %s.', 'glpiacessivel'), $savedName)) ?>"
                hidden
              >
                <h5 id="<?= glpiacessivel_e($savedDeletePanelId) ?>-heading" tabindex="-1">
                  <?= glpiacessivel_e(sprintf(__('Confirmar exclusão de %s', 'glpiacessivel'), $savedName)) ?>
                </h5>
                <p id="<?= glpiacessivel_e($savedDeletePanelId) ?>-description">
                  <?= glpiacessivel_e(sprintf(
                    __('Esta ação exclui definitivamente a pesquisa %s no GLPI%s. Os chamados não serão excluídos.', 'glpiacessivel'),
                    $savedName,
                    $savedIsDefault ? __(', que atualmente é sua pesquisa padrão', 'glpiacessivel') : ''
                  )) ?>
                </p>
                <form method="post" action="<?= glpiacessivel_e($savedSearchActionUrl) ?>">
                  <input type="hidden" name="_glpi_csrf_token" value="<?= glpiacessivel_e($csrf_token) ?>" />
                  <input type="hidden" name="idempotency_key" value="<?= glpiacessivel_e($savedSearchIdempotencyKey()) ?>" />
                  <input type="hidden" name="saved_search_action" value="delete" />
                  <input type="hidden" name="native_saved_search_id" value="<?= $savedId ?>" />
                  <input type="hidden" name="expected_fingerprint" value="<?= glpiacessivel_e($savedFingerprint) ?>" />
                  <label class="glpiacessivel-checkbox-row">
                    <input type="checkbox" name="confirm_delete" value="1" required />
                    <?= glpiacessivel_e(sprintf(__('Confirmo a exclusão definitiva da pesquisa %s no GLPI', 'glpiacessivel'), $savedName)) ?>
                  </label>
                  <div class="glpiacessivel-native-search-confirmation-actions">
                    <button type="submit"><?= glpiacessivel_e(sprintf(__('Excluir definitivamente: %s', 'glpiacessivel'), $savedName)) ?></button>
                    <button type="button" class="glpiacessivel-button glpiacessivel-button-secondary" data-glpiacessivel-native-delete-cancel>
                      <?= __('Cancelar', 'glpiacessivel') ?>
                    </button>
                  </div>
                </form>
              </section>
            <?php endif; ?>
          </article>
        </li>
      <?php endforeach; ?>
    </ol>
  <?php endif; ?>

  <?php if ($nativeCatalogHasPrevious || $nativeCatalogCanReturnToFirst || $nativeCatalogNextCursor !== ''): ?>
    <nav class="glpiacessivel-native-search-pagination" aria-label="<?= glpiacessivel_e(__('Paginação das pesquisas salvas do GLPI', 'glpiacessivel')) ?>">
      <?php if ($nativeCatalogHasPrevious): ?>
        <a class="glpiacessivel-button glpiacessivel-button-secondary" href="<?= glpiacessivel_e($queryUrl([
          'saved_search_q' => $nativeCatalogQuery,
          'saved_search_cursor' => $nativeCatalogPreviousCursor,
        ])) ?>"><?= __('Página anterior de pesquisas', 'glpiacessivel') ?></a>
      <?php elseif ($nativeCatalogCanReturnToFirst): ?>
        <a class="glpiacessivel-button glpiacessivel-button-secondary" href="<?= glpiacessivel_e($queryUrl([
          'saved_search_q' => $nativeCatalogQuery,
          'saved_search_cursor' => null,
        ])) ?>"><?= __('Voltar à primeira página de pesquisas', 'glpiacessivel') ?></a>
      <?php endif; ?>
      <?php if ($nativeCatalogNextCursor !== ''): ?>
        <a class="glpiacessivel-button glpiacessivel-button-secondary" href="<?= glpiacessivel_e($queryUrl([
          'saved_search_q' => $nativeCatalogQuery,
          'saved_search_cursor' => $nativeCatalogNextCursor,
        ])) ?>"><?= __('Próxima página de pesquisas', 'glpiacessivel') ?></a>
      <?php endif; ?>
    </nav>
  <?php endif; ?>
  </div>
</section>

  <section
    id="tickets-filter-summary"
    class="glpiacessivel-applied-search-summary"
    role="region"
    aria-labelledby="tickets-filter-summary-heading"
    data-glpiacessivel-applied-search-summary
  >
    <div class="glpiacessivel-active-filters" role="group" aria-label="<?= glpiacessivel_e(glpiacessivel_t('Filtros ativos')) ?>">
    <p class="glpiacessivel-eyebrow"><?= glpiacessivel_e(glpiacessivel_t('Resultados atuais')) ?></p>
    <h3 id="tickets-filter-summary-heading"><?= glpiacessivel_e($appliedSummaryHeading) ?></h3>
    <div data-glpiacessivel-applied-search-summary-static>
    <?php if ($appliedSummarySavedSearchName !== ''): ?>
      <p><strong><?= glpiacessivel_e(glpiacessivel_t('Pesquisa salva:')) ?></strong> <?= glpiacessivel_e($appliedSummarySavedSearchName) ?></p>
    <?php endif; ?>
    <?php if (!$appliedSummaryActive): ?>
      <p><?= glpiacessivel_e(glpiacessivel_t('Nenhum filtro adicional foi aplicado aos resultados.')) ?></p>
    <?php endif; ?>
    <?php foreach ($appliedSummarySections as $appliedSection): ?>
      <section class="glpiacessivel-applied-search-summary-section">
        <h4><?= glpiacessivel_e((string) $appliedSection['label']) ?></h4>
        <ul>
          <?php foreach ($appliedSection['items'] as $appliedItem): ?>
            <li><?= glpiacessivel_e((string) $appliedItem) ?></li>
          <?php endforeach; ?>
        </ul>
      </section>
    <?php endforeach; ?>
    <?php if ($appliedSummaryWarnings !== []): ?>
      <div class="glpiacessivel-alert glpiacessivel-alert-info" role="status">
        <strong><?= glpiacessivel_e(glpiacessivel_t('Informações sobre esta consulta')) ?></strong>
        <ul>
          <?php foreach ($appliedSummaryWarnings as $appliedWarning): ?>
            <li><?= glpiacessivel_e($appliedWarning) ?></li>
          <?php endforeach; ?>
        </ul>
      </div>
    <?php endif; ?>
    <?php if ($appliedSummarySections === [] && $appliedSummaryPlainText !== ''): ?>
      <p><?= glpiacessivel_e($appliedSummaryPlainText) ?></p>
    <?php endif; ?>
    <?php if ($appliedSummaryNote !== ''): ?>
      <p class="glpiacessivel-help-text"><?= glpiacessivel_e($appliedSummaryNote) ?></p>
    <?php endif; ?>
    </div>
    <?php if ($ticketResultsAsyncEnabled): ?>
      <section class="glpiacessivel-applied-search-summary-section" data-glpiacessivel-effective-search-summary hidden>
        <h4 data-glpiacessivel-effective-search-label></h4>
        <p data-glpiacessivel-effective-search-items></p>
        <p class="glpiacessivel-help-text" data-glpiacessivel-effective-search-note></p>
      </section>
    <?php endif; ?>
    </div>
  </section>

  <script type="application/json" id="ticket-advanced-search-config"><?= $advancedSearchConfigJson ?></script>
</section>
<?php if ($showOperationalDiagnostics && $backend !== 'search_api' && !$ticketResultsAsyncEnabled && !$groupScopeWithoutCurrentGroups && !$savedSearchUnavailable && !$savedSearchRevalidationFailure): ?>
  <?php
    $backendReasonLabels = [
      'native_saved_search_unavailable' => 'A pesquisa salva não pôde ser executada pela Search API do GLPI.',
      'search_api_unavailable' => 'A Search API nativa não está disponível para esta consulta.',
      'saved_search_unavailable' => 'A pesquisa salva deixou de estar disponível para o perfil e a entidade atuais.',
    ];
    $backendReasonText = $backendReasonLabels[$backendReason]
      ?? 'A consulta não pôde ser executada fielmente pela Search API do GLPI.';
  ?>
  <div class="glpiacessivel-alert glpiacessivel-alert-warning" id="tickets-native-search-warning">
    <strong><?= glpiacessivel_e(glpiacessivel_t('Lista de chamados não carregada.')) ?></strong>
    <p><?= glpiacessivel_e($backendReasonText) ?></p>
    <p><?= glpiacessivel_e(glpiacessivel_t('Para evitar resultados diferentes ou mais amplos que a pesquisa solicitada, o portal exibiu uma lista vazia.')) ?></p>
    <?php if ($nativeTicketUrl !== ''): ?>
    <a class="glpiacessivel-button glpiacessivel-button-secondary" href="<?= glpiacessivel_e($nativeTicketUrl) ?>"><?= glpiacessivel_e(glpiacessivel_t('Abrir a lista no GLPI')) ?></a>
    <?php endif; ?>
  </div>
<?php endif; ?>
<section
  aria-labelledby="tickets-lista"
  class="glpiacessivel-card"
  data-glpiacessivel-ticket-results
  data-glpiacessivel-ticket-results-contract-version="<?= $resultContractVersion ?>"
  data-native-fallback-url="<?= glpiacessivel_e($nativeTicketUrl) ?>"
>
  <div class="glpiacessivel-list-header">
    <div>
      <p class="glpiacessivel-eyebrow"><?= glpiacessivel_e(glpiacessivel_t('Resultado operacional')) ?></p>
      <h2
        id="tickets-lista"
        tabindex="-1"
        <?= $advancedSearchFocusResults ? 'data-glpiacessivel-advanced-results-focus' : '' ?>
      ><?= glpiacessivel_e(glpiacessivel_t('Lista de chamados')) ?></h2>
      <p id="tickets-results-status" data-glpiacessivel-ticket-results-summary role="status" aria-live="polite" aria-atomic="true">
        <?php if ($ticketResultsAsyncEnabled): ?>
          <?= glpiacessivel_e(glpiacessivel_t('Resultados ainda não carregados nesta página. A lista no GLPI permanece disponível.')) ?>
        <?php elseif ($savedSearchRevalidationFailure): ?>
          <?= glpiacessivel_e($savedSearchRevalidationMessage) ?>
        <?php elseif ($savedSearchUnavailable): ?>
          <?= glpiacessivel_e($savedSearchUnavailableMessage) ?>
        <?php elseif ($groupScopeWithoutCurrentGroups): ?>
          <?= glpiacessivel_e($groupScopeWithoutCurrentGroupsMessage) ?>
        <?php elseif ($contractUpgradeRequired): ?>
          <?= glpiacessivel_e(glpiacessivel_t('A versão da lista mudou. Atualize a página para continuar.')) ?>
        <?php elseif ($userContextInFlight): ?>
          <?= glpiacessivel_e(glpiacessivel_t('Já há uma consulta em andamento para seu acesso. Aguarde alguns segundos e tente novamente. Seus filtros foram preservados.')) ?>
        <?php elseif ($capacityLimited): ?>
          <?= glpiacessivel_e(glpiacessivel_t('A lista está atendendo muitas consultas agora. Aguarde e tente novamente.')) ?>
        <?php elseif ($capacityUnavailable): ?>
          <?= glpiacessivel_e(glpiacessivel_t('A capacidade segura da lista está temporariamente indisponível.')) ?>
        <?php elseif ($rateLimited): ?>
          <?= glpiacessivel_e(sprintf(glpiacessivel_t('Não foi possível carregar a página %d porque a lista atingiu um limite temporário. Seus filtros foram preservados.'), $page)) ?>
        <?php elseif ($boundedStatementTimeout): ?>
          <?= glpiacessivel_e(glpiacessivel_t('A consulta ultrapassou o tempo permitido. Esta página não foi carregada e seus filtros foram preservados. Aguarde antes de tentar novamente ou ajuste os filtros.')) ?>
        <?php elseif ($boundedOffsetExceeded): ?>
          <?= glpiacessivel_e(glpiacessivel_t('Esta página está além do limite seguro de navegação. Volte à primeira página.')) ?>
        <?php elseif ($boundedExecutionUnavailable): ?>
          <?= glpiacessivel_e(glpiacessivel_t('A lista de chamados está temporariamente indisponível.')) ?>
        <?php elseif (count($items) === 0 && $page > 1): ?>
          <?= glpiacessivel_e(sprintf(glpiacessivel_t('A página %d não tem mais resultados. Volte à página anterior.'), $page)) ?>
        <?php elseif (count($items) === 0): ?>
          <?= glpiacessivel_e(glpiacessivel_t('Nenhum chamado visível para a consulta atual.')) ?>
        <?php elseif ($totalKnown && $totalState === 'lower_bound'): ?>
          <?= glpiacessivel_e(sprintf(glpiacessivel_t('Exibindo %1$d-%2$d de pelo menos %3$d chamados.'), $firstItem, $lastItem, $total)) ?>
        <?php elseif ($totalKnown): ?>
          <?= glpiacessivel_e(sprintf(glpiacessivel_t('Exibindo %1$d-%2$d de %3$d chamados.'), $firstItem, $lastItem, $total)) ?>
        <?php elseif ($hasMore): ?>
          <?= glpiacessivel_e(sprintf(glpiacessivel_t('Exibindo chamados %1$d-%2$d. Há mais resultados.'), $firstItem, $lastItem)) ?>
        <?php else: ?>
          <?= glpiacessivel_e(sprintf(glpiacessivel_t('Exibindo chamados %1$d-%2$d. Não há mais resultados.'), $firstItem, $lastItem)) ?>
        <?php endif; ?>
        <?php if ($totalStateMessage !== ''): ?>
          <span class="glpiacessivel-sr-only"><?= glpiacessivel_e($totalStateMessage) ?></span>
        <?php endif; ?>
      </p>
      <p data-glpiacessivel-ticket-results-total aria-hidden="true">
        <?= glpiacessivel_e($totalStateMessage) ?>
      </p>
      <?php if ($showOperationalDiagnostics && !$ticketResultsAsyncEnabled && !$groupScopeWithoutCurrentGroups): ?>
        <p class="glpiacessivel-card-note">
          <?= glpiacessivel_e($backendLabel) ?>
        </p>
      <?php endif; ?>
    </div>
    <div
      class="glpiacessivel-selection-summary"
      data-glpiacessivel-selection-summary
      <?= ($ticketResultsAsyncEnabled || $pageUnavailable || count($items) === 0) ? 'hidden' : '' ?>
    >
      <?= glpiacessivel_e(glpiacessivel_t('Selecionados:')) ?> <strong data-glpiacessivel-selected-count>0</strong>
      <button type="button" class="glpiacessivel-button glpiacessivel-button-secondary" data-glpiacessivel-copy-selected disabled><?= glpiacessivel_e(glpiacessivel_t('Copiar IDs')) ?></button>
      <span class="glpiacessivel-sr-only" data-glpiacessivel-selection-status role="status" aria-live="polite" aria-atomic="true"></span>
      <p data-glpiacessivel-copy-status role="status" aria-live="polite" aria-atomic="true"></p>
      <p data-glpiacessivel-copy-error role="alert" aria-atomic="true"></p>
      <div data-glpiacessivel-copy-manual hidden>
        <label for="tickets-copy-manual-ids"><?= glpiacessivel_e(glpiacessivel_t('IDs selecionados nesta página para cópia manual')) ?></label>
        <textarea id="tickets-copy-manual-ids" data-glpiacessivel-copy-manual-field readonly rows="2" aria-describedby="tickets-copy-manual-help"></textarea>
        <p id="tickets-copy-manual-help" class="glpiacessivel-help-text"><?= glpiacessivel_e(glpiacessivel_t('Neste campo, use Ctrl+A e Ctrl+C (Command+A e Command+C no Mac), ou selecione os IDs e use o comando Copiar do seu dispositivo.')) ?></p>
      </div>
    </div>
  </div>

  <div data-glpiacessivel-ticket-results-content>
  <?php if ($ticketResultsAsyncEnabled): ?>
    <div class="glpiacessivel-alert glpiacessivel-alert-info" data-glpiacessivel-ticket-results-initial>
      <?php if ($nativeTicketUrl !== ''): ?>
      <p><?= glpiacessivel_e(glpiacessivel_t('Use a lista no GLPI se o carregamento desta página não iniciar.')) ?></p>
      <a class="glpiacessivel-button glpiacessivel-button-secondary" href="<?= glpiacessivel_e($nativeTicketUrl) ?>"><?= glpiacessivel_e(glpiacessivel_t('Abrir a lista no GLPI')) ?></a>
      <?php else: ?>
      <p><?= glpiacessivel_e(glpiacessivel_t('A lista será exibida aqui quando o carregamento terminar.')) ?></p>
      <?php endif; ?>
    </div>
  <?php elseif ($groupScopeWithoutCurrentGroups): ?>
    <?php // The live summary above is the single accessible announcement for this empty scope. ?>
  <?php elseif ($pageUnavailable): ?>
    <section
      class="glpiacessivel-alert glpiacessivel-alert-error"
      role="region"
      aria-labelledby="tickets-page-error-heading"
      aria-describedby="<?= $savedSearchUnavailable ? 'tickets-saved-search-error-description' : 'tickets-results-status' ?>"
    >
      <h3 id="tickets-page-error-heading"><?= glpiacessivel_e($pageUnavailableHeading) ?></h3>
      <?php if ($savedSearchUnavailable): ?>
        <p id="tickets-saved-search-error-description"><?= glpiacessivel_e($savedSearchUnavailableMessage) ?></p>
        <p>
          <a class="glpiacessivel-button" href="<?= glpiacessivel_e($savedSearchResetUrl) ?>">
            <?= glpiacessivel_e(glpiacessivel_t('Limpar pesquisa indisponível')) ?>
          </a>
        </p>
      <?php elseif ($temporaryRetryDelayed && $retryAfterSeconds > 0): ?>
        <p id="tickets-sync-retry-countdown" aria-live="off"><?= glpiacessivel_e(sprintf(
          glpiacessivel_n('Aguarde %d segundo antes de tentar novamente.', 'Aguarde %d segundos antes de tentar novamente.', $retryAfterSeconds),
          $retryAfterSeconds
        )) ?></p>
        <span id="tickets-sync-retry-ready" class="glpiacessivel-sr-only" role="status" aria-live="polite" aria-atomic="true"></span>
      <?php endif; ?>
      <?php if (!$savedSearchUnavailable): ?>
      <p>
        <?php if ($boundedOffsetExceeded): ?>
          <a class="glpiacessivel-button" href="<?= glpiacessivel_e($queryUrl(['page' => 1, 'focus' => 'results'])) ?>"><?= glpiacessivel_e(glpiacessivel_t('Voltar à primeira página')) ?></a>
        <?php elseif ($savedSearchRevalidationFailure && !$savedSearchRevalidationUnavailable): ?>
          <a class="glpiacessivel-button" href="<?= glpiacessivel_e($queryUrl(['page' => $page, 'focus' => 'results'])) ?>"><?= glpiacessivel_e(glpiacessivel_t('Atualizar página')) ?></a>
        <?php elseif ($temporaryRetryDelayed && $retryAfterSeconds > 0): ?>
          <button
            type="button"
            class="glpiacessivel-button"
            data-glpiacessivel-sync-retry
            data-retry-url="<?= glpiacessivel_e($queryUrl(['page' => $page, 'focus' => 'results'])) ?>"
            data-retry-after="<?= $retryAfterSeconds ?>"
            data-wait-singular="<?= glpiacessivel_e(glpiacessivel_t('Aguarde %d segundo antes de tentar novamente.')) ?>"
            data-wait-plural="<?= glpiacessivel_e(glpiacessivel_t('Aguarde %d segundos antes de tentar novamente.')) ?>"
            data-ready-message="<?= glpiacessivel_e(glpiacessivel_t('A espera terminou. Você já pode tentar novamente.')) ?>"
            aria-describedby="tickets-sync-retry-countdown tickets-sync-retry-ready"
            disabled
          ><?= glpiacessivel_e(glpiacessivel_t('Tentar novamente')) ?></button>
        <?php else: ?>
          <a class="glpiacessivel-button" href="<?= glpiacessivel_e($queryUrl(['page' => $page, 'focus' => 'results'])) ?>"><?= glpiacessivel_e(glpiacessivel_t('Tentar novamente')) ?></a>
        <?php endif; ?>
      </p>
      <?php if ($boundedStatementTimeout): ?>
        <p><a class="glpiacessivel-button glpiacessivel-button-secondary" href="#ticket-advanced-search-form"><?= glpiacessivel_e(glpiacessivel_t('Ajustar filtros')) ?></a></p>
      <?php endif; ?>
      <?php if ($nativeTicketUrl !== '' && !$savedSearchRevalidationFailure): ?>
      <p><?= glpiacessivel_e(glpiacessivel_t('Ao abrir a lista geral no GLPI, revise os filtros, pois essa contingência pode não preservar a consulta atual.')) ?></p>
      <p><a class="glpiacessivel-button glpiacessivel-button-secondary" href="<?= glpiacessivel_e($nativeTicketUrl) ?>"><?= glpiacessivel_e(glpiacessivel_t('Abrir a lista geral no GLPI')) ?></a></p>
      <?php endif; ?>
      <?php endif; ?>
    </section>
  <?php elseif (count($items) === 0): ?>
    <div class="glpiacessivel-empty">
      <p><?= glpiacessivel_e(glpiacessivel_t('Nenhum chamado encontrado para os filtros informados.')) ?></p>
      <p>
        <a class="glpiacessivel-button glpiacessivel-button-secondary" href="<?= glpiacessivel_e(glpiacessivel_url('front/tickets.php?saved_search=')) ?>"><?= glpiacessivel_e(glpiacessivel_t('Limpar filtros')) ?></a>
        <?php if ($canCreateTicketFromList): ?>
        <a class="glpiacessivel-button" href="<?= glpiacessivel_e(glpiacessivel_url('front/ticket.create.php')) ?>"><?= glpiacessivel_e(glpiacessivel_t('Abrir novo chamado')) ?></a>
        <?php endif; ?>
      </p>
    </div>
  <?php else: ?>
    <?php if (($filters['group_by'] ?? 'none') === 'group' && !empty($grouped_items)): ?>
      <div class="glpiacessivel-ticket-grouped">
        <?php foreach ((array) ($grouped_items ?? []) as $groupIndex => $groupTickets): ?>
          <?php $groupHeadingId = 'tickets-grupo-' . md5((string) $groupIndex); ?>
          <section class="glpiacessivel-ticket-group" aria-labelledby="<?= glpiacessivel_e($groupHeadingId) ?>">
            <h3 id="<?= glpiacessivel_e($groupHeadingId) ?>"><?= glpiacessivel_e((string) $groupIndex) ?> (<?= glpiacessivel_e(sprintf(glpiacessivel_t('%d nesta página'), count((array) $groupTickets))) ?>)</h3>
            <div class="glpiacessivel-table-wrap" role="region" aria-labelledby="<?= glpiacessivel_e($groupHeadingId) ?>" tabindex="0">
              <table class="tab_cadre_fixehov glpiacessivel-ticket-table">
                <caption class="glpiacessivel-sr-only"><?= glpiacessivel_e(sprintf(glpiacessivel_t('Chamados do grupo %s para os filtros atuais'), (string) $groupIndex)) ?></caption>
                <thead>
                  <tr>
                    <th scope="col"><span class="glpiacessivel-sr-only"><?= glpiacessivel_e(glpiacessivel_t('Selecionar')) ?></span></th>
                    <?php $renderTicketHeaders(false); ?>

                    <th scope="col"><?= glpiacessivel_e(glpiacessivel_t('Ação')) ?></th>
                  </tr>
                </thead>
                <tbody>
                <?php foreach ((array) $groupTickets as $item): ?>
                  <?php $renderTicketRow((array) $item, false); ?>
                <?php endforeach; ?>
                </tbody>
              </table>
            </div>
          </section>
        <?php endforeach; ?>
      </div>
    <?php else: ?>
      <div class="glpiacessivel-table-wrap" role="region" aria-label="<?= glpiacessivel_e(glpiacessivel_t('Tabela de chamados')) ?>" tabindex="0">
        <table class="tab_cadre_fixehov glpiacessivel-ticket-table" aria-describedby="tickets-lista">
          <caption class="glpiacessivel-sr-only"><?= glpiacessivel_e(glpiacessivel_t('Chamados encontrados para os filtros atuais')) ?></caption>
          <thead>
            <tr>
              <th scope="col"><span class="glpiacessivel-sr-only"><?= glpiacessivel_e(glpiacessivel_t('Selecionar')) ?></span></th>
              <?php $renderTicketHeaders(true); ?>

              <th scope="col"><?= glpiacessivel_e(glpiacessivel_t('Ação')) ?></th>
            </tr>
          </thead>
          <tbody>
          <?php foreach ($items as $item): ?>
            <?php $renderTicketRow((array) $item, true); ?>
          <?php endforeach; ?>
          </tbody>
        </table>
      </div>
    <?php endif; ?>
  <?php endif; ?>
  </div>
  <?php if ($ticketResultsAsyncEnabled): ?>
    <script type="application/json" data-glpiacessivel-ticket-results-config><?= $ticketResultsAsyncConfigJson ?></script>
  <?php endif; ?>
  <script src="<?= glpiacessivel_e($ticketCopyAssetUrl) ?>" defer data-glpiacessivel-ticket-copy-script></script>
  <?php if ($ticketResultsAsyncEnabled || ($temporaryRetryDelayed && $retryAfterSeconds > 0)): ?>
    <script src="<?= glpiacessivel_e($ticketResultsAssetUrl) ?>" defer data-glpiacessivel-ticket-results-script></script>
  <?php endif; ?>
</section>

<nav
  class="glpiacessivel-pagination glpiacessivel-ticket-pagination"
  aria-label="<?= glpiacessivel_e(glpiacessivel_t('Paginação')) ?>"
  data-glpiacessivel-ticket-results-pagination
  <?= ($ticketResultsAsyncEnabled || $pageUnavailable) ? 'hidden' : '' ?>
>
  <?php if (!$ticketResultsAsyncEnabled && !$pageUnavailable): ?>
    <span><?= glpiacessivel_e(sprintf(glpiacessivel_t('Página %d'), $page)) ?></span>
    <?php if ($hasPrevious): ?>
      <a href="<?= glpiacessivel_e($queryUrl(['page' => 1, 'focus' => 'results'])) ?>"><?= glpiacessivel_e(glpiacessivel_t('Primeira')) ?></a>
      <a href="<?= glpiacessivel_e($queryUrl(['page' => $page - 1, 'focus' => 'results'])) ?>"><?= glpiacessivel_e(glpiacessivel_t('Anterior')) ?></a>
    <?php else: ?>
      <span aria-disabled="true"><?= glpiacessivel_e(glpiacessivel_t('Primeira')) ?></span>
      <span aria-disabled="true"><?= glpiacessivel_e(glpiacessivel_t('Anterior')) ?></span>
    <?php endif; ?>
    <span aria-current="page"><?= glpiacessivel_e(sprintf(glpiacessivel_t('Atual: %d'), $page)) ?></span>
    <?php if ($hasMore): ?>
      <a href="<?= glpiacessivel_e($queryUrl(['page' => $page + 1, 'focus' => 'results'])) ?>"><?= glpiacessivel_e(glpiacessivel_t('Próxima')) ?></a>
    <?php else: ?>
      <span aria-disabled="true"><?= glpiacessivel_e(glpiacessivel_t('Próxima')) ?></span>
    <?php endif; ?>
  <?php endif; ?>
</nav>
