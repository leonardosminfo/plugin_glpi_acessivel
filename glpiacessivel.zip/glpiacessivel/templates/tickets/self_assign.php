<?php
// This action intentionally does not depend on permission to route other actors.
$canSelfAssign = !empty($itilActions['can_self_assign']);
$selfAssignRevision = (string) ($itilActions['self_assign_revision'] ?? '');
?>
<?php if ($canSelfAssign && preg_match('/\A[a-f0-9]{64}\z/D', $selfAssignRevision) === 1) : ?>
  <section class="glpiacessivel-routing-panel" aria-labelledby="atribuir-a-mim">
    <h3 id="atribuir-a-mim" tabindex="-1"><?= glpiacessivel_e($t('Atribuir chamado a mim')) ?></h3>
    <p id="self-assign-help" class="glpiacessivel-help-text"><?= glpiacessivel_e($t('Inclua seu usuário como técnico responsável pelo atendimento. O GLPI aplicará as permissões e regras do chamado.')) ?></p>
    <form
      method="post"
      action="<?= glpiacessivel_e(glpiacessivel_url('front/ticket.action.php')) ?>"
      class="glpiacessivel-form"
      aria-describedby="self-assign-help"
      data-glpiacessivel-self-assign
      data-glpiacessivel-critical-form
      data-critical-title="<?= glpiacessivel_e($t('Confirmar atribuição a mim')) ?>"
      data-critical-message="<?= glpiacessivel_e(sprintf($t('Deseja incluir seu usuário como técnico responsável pelo chamado #%d?'), (int) $ticket['id'])) ?>"
      data-critical-consequence="<?= glpiacessivel_e($t('O GLPI processará sua inclusão como técnico responsável e aplicará as regras de atendimento.')) ?>"
      data-critical-confirm-label="<?= glpiacessivel_e($t('Confirmar atribuição a mim')) ?>"
    >
      <input type="hidden" name="_glpi_csrf_token" value="<?= glpiacessivel_e($csrf_tokens['self_assign'] ?? $csrf_token) ?>" />
      <input type="hidden" name="ticket_id" value="<?= (int) $ticket['id'] ?>" />
      <input type="hidden" name="action" value="self_assign" />
      <input type="hidden" name="self_assign_revision" value="<?= glpiacessivel_e($selfAssignRevision) ?>" />
      <input type="hidden" name="critical_confirmed" value="0" />
      <input type="hidden" name="critical_confirmation_token" value="<?= glpiacessivel_e((string) ($criticalConfirmations['self_assign'] ?? '')) ?>" />
      <div class="glpiacessivel-actions">
        <button type="submit" class="glpiacessivel-button glpiacessivel-button-primary"><?= glpiacessivel_e($t('Atribuir a mim')) ?></button>
      </div>
      <noscript><p><?= glpiacessivel_e($t('Ative o JavaScript para revisar e confirmar esta atribuição antes do envio.')) ?></p></noscript>
    </form>
  </section>
<?php endif; ?>
