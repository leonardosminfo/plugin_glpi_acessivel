# GLPI Acessível 0.4.16-beta.2 — desinstalação segura e resiliência da lista

## Objetivo

Esta revisão corrige duas falhas operacionais observadas em homologação sem
substituir direitos, critérios ou consultas funcionais do GLPI:

1. erro SQL `1146` durante a desinstalação, quando o runtime ainda tentava ler
   a tabela de configuração já removida;
2. erro MySQL `3024` na lista de chamados, causado pelo orçamento fixo de três
   segundos aplicado a uma pesquisa nativa mais onerosa.

Compatibilidade declarada: GLPI 10/PHP 8.1 e GLPI 11/PHP 8.3.

## Alterações entregues

### Ciclo de vida

- o marcador de desinstalação é ativado antes da remoção de direitos, hooks e
  tabelas;
- bootstrap, configuração, idioma e hooks verificam o esquema sem executar
  `SELECT` em tabela ausente;
- callbacks já registrados tornam-se inertes durante a desmontagem;
- a tabela de configuração é removida por último;
- leituras sem esquema retornam padrões seguros e gravações falham de forma
  controlada;
- tabelas nunca são recriadas por navegação, hook ou leitura; a reconciliação
  permanece exclusiva da instalação/atualização explícita.

### Lista de chamados

- novo orçamento administrativo `ticket_list_statement_timeout_ms`, entre
  `1000` e `9000 ms`, com padrão `3000 ms`;
- aplicação somente ao `SELECT` limitado da lista, preservando a SQL e a
  autorização construídas pelo Search nativo do GLPI;
- MySQL utiliza `MAX_EXECUTION_TIME` e MariaDB utiliza
  `SET STATEMENT max_statement_time`;
- um limite de sessão mais restritivo definido pelo DBA sempre prevalece;
- erros MySQL `3024` e MariaDB `1969` são normalizados como
  `bounded_search_statement_timeout`;
- timeout retorna `HTTP 503`, `Retry-After`, contrato `ticket_results` V2 e
  mensagem sanitizada; nunca é apresentado como lista vazia ou total zero;
- o prazo do navegador, a reserva de capacidade e o tempo de nova tentativa
  são derivados no servidor;
- valores acima de `5000 ms` exigem confirmação administrativa, lista
  assíncrona, proteção de capacidade e simultaneidade efetiva de uma consulta;
- nenhuma repetição automática é executada após timeout.

### Acessibilidade e privacidade

- a falha é anunciada uma única vez e mantém os filtros aplicados;
- a contagem regressiva permanece fora da região viva e a nova tentativa é
  liberada de modo previsível;
- tentativa iniciada pelo usuário devolve foco ao título do erro quando o
  conteúdo é substituído;
- a interface administrativa associa rótulo, ajuda, alerta e confirmação;
- auditoria e resposta não incluem SQL, valores pesquisados, nomes, IDs,
  conteúdo do chamado ou mensagem original do driver.

## Configuração operacional

O padrão permanece `3000 ms`. O teto de `9000 ms` é uma contingência
excepcional. Para usá-lo, o ambiente deve manter timeout de PHP-FPM, proxy,
balanceador e WAF em pelo menos 20 segundos, com 30 segundos recomendado.

Com `9000 ms`, o cliente usa até `13000 ms` e a reserva mínima efetiva é de
`15 s`. O plugin não modifica configurações globais do banco nem serviços da
infraestrutura.

## Limitações

O orçamento interrompe uma consulta demorada e protege a disponibilidade, mas
não corrige índices ou um plano de execução inadequado. Consultas que dependam
permanentemente de sete a nove segundos precisam de análise estrutural do banco
e da forma da pesquisa.

## Evidência automatizada

- PHPUnit PHP 8.1: 868 testes e 5.311 asserções;
- PHPUnit PHP 8.3: 868 testes e 5.311 asserções;
- navegador: 84 cenários aprovados;
- PHPCS: 300 arquivos aprovados;
- PHPStan: sem erros;
- i18n: 2.670 mensagens auditadas e catálogos compilados.

A homologação autenticada em GLPI 10 e 11 continua obrigatória antes da
implantação em produção.
