# Plano de testes — 0.4.16-beta.5

## Comparação justa

Executar o mesmo usuário, perfil, entidade, recursividade, critérios, colunas, ordem e página no plugin e no motor nativo. Registrar IDs e ordem, inclusive resultado vazio válido. Não comparar root isolada com árvore. Não confundir resposta CLI com teste HTTP autenticado.

## Casos obrigatórios

- Pesquisa salva com `search=Pesquisar`, rótulo em outro idioma e ordenação ausente.
- Ordenação serializada como `"15"`; direção e sequência preservadas; zero, negativo, decimal e string malformada recusados.
- Estado salvo previamente bloqueado: resposta de pesquisa indisponível, nunca falsa mudança de perfil. Mudança real do contexto continua recusada.
- Pesquisa privada, pública, sem permissão, alterada ou excluída; nenhum fallback silencioso para universo mais amplo.
- Perfis sintéticos: self-service, leitura, técnico e administração; usuário em múltiplos grupos, conta com vários perfis, entidade externa não autorizada.
- Status abertos, pendentes, solucionados e fechados; requester, observador, técnico e grupo; paginação e consulta sem resultado.
- Carregamento tardio do iframe, timeout, retry, origem/identidade/login inválidos. Verificar display real, hidden, ARIA, botão Começar e ausência de recarga de dados preenchidos.
- Regressão PHP 8.1/8.3, JS/navegador, análise estática, i18n e verificação do ZIP.

## Limites

Base pequena reproduz comportamento/ACL; não reproduz volume ou infraestrutura de homologação. Medição de carga representativa e avaliação manual com leitor de tela continuam independentes.
