# Execução — 0.4.16-beta.5

Data: 04/09/2026.

Alvos: GLPI 11.0.7 em localhost:8080 e GLPI 10.0.10 em localhost:8089. Dados sintéticos, sem cópia de dados de homologação e sem alteração em chamadosh/GLPIT.

## Correção e regressão automatizada

- PHP 8.1.31 e 8.3.14: 1.063 testes, 6.953 asserções aprovados em cada runtime.
- Subconjunto das correções de pesquisas: 69 testes / 529 asserções nos dois runtimes.
- Navegador headless: 91 cenários aprovados; 4 testes do harness de carga aprovados. Os 16 cenários de iframe estão incluídos nos 91.
- Harness HTTP: 6 testes adicionais de contrato/segurança do próprio gerador de testes aprovados.
- PHPStan completo: sem erros. PHPCS: 315 arquivos sem erros.
- i18n: 2.697 mensagens auditadas; catálogos compilados; assets fonte/público sincronizados.
- Primeira execução PHP detectou 9 divergências dos espelhos de assets antes do build. Após sincronização, ambas as suítes completas passaram. Não foram ignoradas falhas.

## Instalação

Backup dos dois plugins e dos bancos locais `glpi` e `glpi10` em `.deployment-backups/beta5-20260904/`, antes da atualização. Instalação e ativação pelo console GLPI, sem reinício do PHP-FPM e sem desinstalação. Avisos legados DATETIME no GLPI 10, sem falha de instalação.

Versão 0.4.16-beta.5 servida em JS/CSS nas seis sessões de cada ambiente. Hashes do gateway, controlador assíncrono e JS instalado coincidem com o código empacotado nos dois contêineres. O pacote possui raiz única, 372 entradas, não inclui tools/tests/credenciais e passa `verify-release.ps1`. O SHA-256 final está ao lado do ZIP, em `SHA256SUMS`.

## Base criada, por ambiente

- 6 usuários ativos locais, 4 perfis próprios, 4 entidades, 3 grupos, 1 categoria e 36 chamados.
- 8 pesquisas salvas: botão nativo com e sem ordenação; ordenação string privada; pública aninhada; privada externa; grupo responsável; contagem/HAVING; resultado vazio.
- 8 associações perfil/usuário, 6 associações grupo/usuário e 8 observadores sintéticos.
- Os status efetivos dos 36 chamados coincidiram com os esperados nas duas versões.
- Reexecução preservou identidades e credenciais e acrescentou apenas as duas novas pesquisas solicitadas para a regressão; não apagou dados existentes.
- A fixture de metacritério Computer não foi criada: o gerador não a habilitou pelo catálogo detectado. Não se conclui daí que o GLPI não suporte metacritérios. A pesquisa de contagem resultou vazia válida, portanto não representa cobertura positiva de todos os agregados.

## Comparação com o motor nativo

Por ambiente, 80 casos aprovados: 48 casos nas seis contas, 24 casos dos três perfis da conta múltipla e 8 casos do perfil de leitura sem recursividade. Total: 160 comparações.

A referência usa `SavedSearch::getParameters(id)` e `Search::getDatas()` com sessão/entidade/direitos nativos. As listas de IDs e ordem coincidiram com a execução paginada do plugin. Pesquisas privadas não autorizadas foram recusadas. A busca sem ordenação deixou de falhar. Resultado vazio continuou válido, sem falso erro de contexto.

Esta comparação usa CLI: a referência coleta até 1.000 itens e o plugin pagina em 10. Total explícito e limite de paginação impedem aprovar referência truncada. Não se usa a diferença de duração entre esses dois modos como benchmark de desempenho.

## HTTP autenticado real

Seis logins independentes por instância, via HTTP nas portas publicadas pelo Docker. 48 pesquisas e 36 verificações de detalhe em cada ambiente; total de 96 pesquisas e 72 verificações de detalhe, todas aprovadas.

Validado login, perfil/entidade, versão servida, shell HTML, contrato `ticket_results`, CSRF, estado/revisão, IDs ordenados esperados, paginação e recusa sem vazamento de conteúdo. A pesquisa recusada não foi apresentada como mudança de perfil.

Referência de acesso nativa, no perfil inicial de cada conta: leitura 32/36, solicitante 20/36, técnico 32/36, admin QA 32/36, múltipla (self-service) 12/36 e externa 4/36. A conta externa não alcança a árvore principal e as contas principais não alcançam seus quatro chamados.

Em amostras locais sequenciais, o maior tempo observado no endpoint de resultados foi 99 ms no GLPI 10 e 95 ms no GLPI 11. Inclui respostas de recusa; não é percentil, ensaio de carga ou evidência sobre o banco de homologação. Não se alterou limite de consulta.

## Evidências e limites

Relatórios locais em `.test-results/beta5/`: manifests, `*-native-compare.json`, `*-multi.json`, `*-root.json` e `*-http.json`. Senhas em arquivos `*-credentials.json` separados, ignorados pelo Git e excluídos do ZIP. Backups também ignorados.

Não foi retestada a beta.5 em chamadosh. Volume de produção, banco lento, configuração real de perfis/plugins, acessibilidade com leitor de tela e operações de alteração de chamado permanecem fora desta rodada. O carregamento tardio do formulário foi reproduzido em fixtures de navegador com CSS/DOM realistas, não por degradação do servidor de homologação.
