# Desinstalação segura e resiliência da lista — revisão 0.4.16-v2

## Status

Planejado para uma próxima versão. Nenhuma alteração descrita neste documento
está implementada apenas pela existência deste roadmap.

- nome funcional da revisão: `0.4.16-v2`;
- versão técnica recomendada: `0.4.16-beta.2`;
- runtime epoch previsto: `20260902-01`;
- compatibilidade obrigatória: GLPI 10 e GLPI 11.

Não usar `0.4.16-v2` nos metadados internos do plugin. O
`version_compare()` do PHP considera essa identificação anterior a
`0.4.16-beta`, o que pode impedir o GLPI de reconhecer a atualização. O nome
`0.4.16-v2` pode permanecer como identificação funcional da revisão.

## Contexto do problema

O SQL 1146 observado ocorre durante a desinstalação:

```text
Table 'glpi_plugin_glpiacessivel_configs' doesn't exist
```

O fluxo atual é:

1. o GLPI carrega `setup.php` e inicializa o plugin;
2. o GLPI chama `plugin_glpiacessivel_uninstall()`;
3. `SchemaManager::uninstall()` remove as tabelas próprias, inclusive
   `glpi_plugin_glpiacessivel_configs`;
4. somente depois o GLPI conclui a mudança do plugin para `NOTINSTALLED` e o
   descarrega;
5. nessa janela, um hook já registrado, uma inicialização posterior ou uma
   requisição concorrente pode tentar ler a tabela removida.

O `try/catch` atualmente existente é tardio: o mecanismo de banco do GLPI pode
registrar ou apresentar o SQL 1146 antes de a exceção ser capturada.

### Timeout da pesquisa nativa

Em homologação, a lista de chamados também apresentou o erro MySQL `3024`:

```text
Query execution was interrupted, maximum statement execution time exceeded
```

A consulta continua sendo construída pelo Search nativo do GLPI, mas o plugin
aplica hoje um orçamento fixo de `3000 ms`. O GLPI 10 e o GLPI 11 não possuem
uma configuração administrativa nativa equivalente a
`MAX_EXECUTION_TIME`/`max_statement_time` para a duração de cada pesquisa. O
limite de itens por página reduz o resultado exibido, mas não evita que o banco
processe `JOIN`, agregações, `GROUP BY`, ordenação e regras de visibilidade antes
do `LIMIT`.

A revisão deve, portanto, preservar integralmente a semântica nativa e tornar
configurável apenas o envelope operacional da consulta. O teto de `9000 ms` é
uma contingência excepcional; o padrão permanece `3000 ms`.

## Objetivos

1. Desinstalar sem erro SQL na resposta ou nos logs.
2. Tornar o plugin inerte assim que a desmontagem começar.
3. Impedir consultas às tabelas próprias ausentes.
4. Não recriar tabelas durante desinstalação, navegação ou leitura de
   configuração.
5. Manter a desinstalação repetível e tolerante a tabelas já ausentes.
6. Permitir reinstalação posterior pela rotina explícita do GLPI.
7. Não ocultar falhas reais de banco quando o esquema existir.
8. Permitir ajuste administrativo do orçamento SQL entre `1000` e `9000 ms`.
9. Manter `3000 ms` como padrão e tratar valores acima de `5000 ms` como modo
   excepcional.
10. Encerrar consultas demoradas antes dos limites do cliente, proxy e PHP-FPM.
11. Converter timeouts MySQL `3024` e MariaDB `1969` em indisponibilidade
    controlada, sem expor SQL e sem apresentar lista vazia.
12. Preservar ACL, perfis, entidades, critérios, Search Options, IDs e ordem do
    Search nativo do GLPI 10 e 11.

## Decisões de arquitetura

### Estado transitório de desmontagem

Criar um marcador de processo, por exemplo
`$GLOBALS['plugin_glpiacessivel_uninstalling']`, antes de remover direitos ou
tabelas. O marcador permanece ativo até o fim da requisição, inclusive quando
a desinstalação falhar parcialmente.

O marcador protege a requisição corrente, mas não substitui a verificação do
esquema, pois não sobrevive ao redirecionamento nem alcança outro worker.

### Porta central de disponibilidade

Criar uma função central de disponibilidade do runtime que:

1. retorne `false` quando o marcador de desinstalação estiver ativo;
2. valide a presença do banco e de `tableExists()`;
3. verifique as tabelas próprias indispensáveis sem executar `SELECT`;
4. retorne `false` quando o esquema estiver ausente ou incompleto;
5. nunca crie, altere ou repare tabelas.

Ausência do esquema em execução normal significa plugin indisponível e
comportamento `fail-closed`.

### Separação entre runtime e instalação

Nenhum destes caminhos pode criar tabelas:

- `plugin_init_glpiacessivel()`;
- carregamento de configuração;
- tradução e seleção de idioma;
- hook de login ou central;
- navegação em página nativa do GLPI;
- acesso direto a URL antiga do plugin.

Criação ou reconciliação do esquema fica restrita a instalação, reinstalação ou
atualização explicitamente iniciada pelo administrador.

### Pesquisa nativa com contenção própria

O plugin não deve substituir o Search do GLPI nem criar SQL alternativo para
resolver o timeout. Critérios, ACL, entidades, recursividade, pesquisa salva,
metacritérios, `GROUP BY`, `HAVING`, ordenação e paginação continuam sendo
produzidos pelo mecanismo nativo.

O plugin acrescenta somente um orçamento por instrução:

- MySQL: `MAX_EXECUTION_TIME` no `SELECT`;
- MariaDB: `SET STATEMENT max_statement_time=... FOR`;
- nenhuma alteração de variável global do servidor;
- nenhuma aplicação a inclusão, edição, solução ou outra operação
  transacional.

Quando existir um limite de sessão não zero definido pelo DBA, o orçamento
efetivo será o menor entre o valor solicitado pelo plugin, `9000 ms` e o limite
herdado do SGBD. Valor zero do SGBD significa ausência de limite nessa camada.
O plugin nunca poderá ampliar uma política mais restritiva do ambiente.

### Faixas de operação

Criar a chave `ticket_list_statement_timeout_ms` com as seguintes regras:

- mínimo: `1000 ms`;
- máximo: `9000 ms`;
- padrão: `3000 ms`;
- passo da interface: `500 ms`;
- `1000–5000 ms`: faixa normal administrável;
- qualquer valor acima de `5000 ms`, até `9000 ms`: contingência excepcional
  e temporária;
- valor ausente, inválido ou legado: normalizar para `3000 ms`;
- nenhuma origem em URL, sessão de usuário ou perfil;
- alteração somente por administrador, via `POST`, com CSRF e validação no
  serviço.

Valores acima de `5000 ms` exigem confirmação explícita e devem forçar no
servidor:

1. lista assíncrona ativada;
2. proteção de capacidade ativada;
3. simultaneidade efetiva de uma consulta pesada por servidor;
4. circuit breaker abrindo após três timeouts em 60 segundos;
5. circuito aberto por 30 segundos;
6. somente uma tentativa em estado meio aberto;
7. repetição apenas manual, nunca automática.

Em ambiente com mais de um nó, capacidade e circuito precisam de backend
compartilhado. APCu ou arquivo local coordenam somente processos do mesmo
servidor.

### Hierarquia obrigatória de prazos

Considere `S` como o orçamento SQL efetivo, em milissegundos. O servidor deve
derivar e enviar ao cliente:

```text
request_timeout_ms = S + 4000

effective_lease_seconds = max(
    lease_configurado,
    ceil(request_timeout_ms / 1000) + 2
)

retry_after_seconds = min(
    30,
    max(retry_configurado, ceil(S / 1000))
)
```

Tabela de referência:

| SQL efetivo | Cliente | Lease mínima efetiva |
|---:|---:|---:|
| `1000 ms` | `5000 ms` | `8 s` |
| `3000 ms` | `7000 ms` | `9 s` |
| `5000 ms` | `9000 ms` | `11 s` |
| `7000 ms` | `11000 ms` | `13 s` |
| `9000 ms` | `13000 ms` | `15 s` |

O cliente não pode fornecer nem ampliar esses valores. Para homologar
`9000 ms`, o menor timeout de PHP-FPM, proxy, balanceador ou WAF deve ser de no
mínimo `20 s`, com `30 s` recomendado. O plugin apenas verifica/documenta essa
pré-condição; não edita serviços da infraestrutura.

## Alterações técnicas planejadas

### 1. `setup.php`

1. Marcar `uninstalling` no início de
   `plugin_glpiacessivel_uninstall()` e não limpar o marcador na mesma
   requisição.
2. Criar a porta central de disponibilidade do runtime.
3. Em `plugin_init_glpiacessivel()`, registrar somente compatibilidade CSRF e
   idioma antes da verificação.
4. Retornar antes de firewall, classes funcionais, menus, configuração,
   widgets, CSS, JavaScript, login, chatbot e integrações quando o runtime não
   estiver disponível.
5. Fazer `plugin_glpiacessivel_get_cached_config_map()` testar a tabela antes
   de chamar `request()`.
6. Quando o esquema estiver ausente, retornar padrões seguros com formulários,
   chatbot, botão flutuante e integrações desativados.
7. Não transformar falhas genéricas de banco em valores padrão quando a tabela
   existir.

### 2. Hooks já registrados

Adicionar a mesma porta de disponibilidade no início dos callbacks públicos,
especialmente:

- `plugin_glpiacessivel_display_login()`;
- `plugin_glpiacessivel_display_login_accessibility_notice()`;
- `plugin_glpiacessivel_display_central()`.

Durante a desmontagem eles devem virar operações nulas, sem montar container,
consultar configuração, carregar templates ou emitir assets.

Quando seguro, remover também as entradas funcionais do plugin em
`$PLUGIN_HOOKS` antes dos `DROP TABLE`. Essa remoção é uma defesa complementar,
não substitui os guardas dentro dos callbacks.

### 3. `ConfigService`

1. Leitura com tabela ausente retorna o padrão solicitado sem SQL.
2. Gravação com tabela ausente lança erro controlado de instalação ou
   atualização indisponível.
3. Nenhuma leitura ou gravação tenta reparar o esquema.
4. Falhas reais de consulta continuam visíveis quando a tabela existe.

### 4. `I18n`

`configuredFallbackLocale()` deve verificar a tabela antes da consulta. Na
ausência dela, retorna vazio e permite o fallback estático do plugin, sem SQL.

### 5. `SchemaManager::uninstall()`

1. Manter `DROP TABLE IF EXISTS` para idempotência.
2. Validar as pré-condições possíveis antes do primeiro `DROP`.
3. Remover a tabela de migrações antes da tabela de configurações.
4. Remover `glpi_plugin_glpiacessivel_configs` por último.
5. Retornar `false` de forma controlada quando uma operação falhar.
6. Não tentar recriar tabelas dentro de `uninstall()`.

A ordenação reduz a janela de erro, mas não substitui o marcador nem as
verificações de existência.

### 6. Instalação e reinstalação explícitas

O fluxo explícito pode reconciliar um esquema parcialmente removido. Essa
reconciliação deve:

1. ocorrer somente dentro de `install()` ou atualização administrativa;
2. usar criação idempotente;
3. preservar configurações e dados ainda existentes;
4. inserir somente padrões ausentes;
5. falhar de forma controlada se o esquema não puder ser concluído;
6. nunca ser acionada por leitura, hook ou navegação.

### 7. Configuração do orçamento SQL

1. Persistir `ticket_list_statement_timeout_ms` sem sobrescrever valor válido
   durante atualização.
2. Validar `1000–9000 ms` no `ConfigService`, controlador e construtor do
   orçamento.
3. Restringir a alteração ao direito nativo de administração já usado pela
   configuração do plugin.
4. Mostrar valor solicitado, limite de sessão do DBA quando disponível e valor
   efetivo.
5. Oferecer ação para restaurar imediatamente o padrão de `3000 ms`.
6. Acima de `5000 ms`, exigir confirmação administrativa e aplicar os
   guardrails no servidor, mesmo com formulário manipulado.
7. Registrar a alteração somente conforme a política de auditoria e proteção
   de dados já configurada.

Texto principal da interface:

> Tempo máximo da consulta SQL da lista de chamados. Limita somente a pesquisa
> da lista e não altera o banco globalmente. Padrão recomendado: 3000 ms.

Alerta para valores acima de `5000 ms`:

> Uso excepcional e temporário. Consultas longas aumentam a ocupação do banco
> e dos processos PHP. A lista assíncrona e a proteção de capacidade serão
> obrigatórias, com somente uma consulta pesada simultânea. Confirme os prazos
> do PHP-FPM, proxy e balanceador antes de salvar.

O campo deve possuir `label` explícito e ajuda/alerta associados por
`aria-describedby`. O resumo calculado deve ser atualizado em `change` ou
`blur`, com `role="status"`, `aria-live="polite"` e `aria-atomic="true"`, sem
anúncio a cada tecla.

### 8. Execução e classificação do timeout

1. Substituir a constante rígida de
   `MySqlMariaDbQueryBudget::STATEMENT_TIMEOUT_MILLISECONDS` por valor imutável
   recebido no construtor.
2. Injetar o valor pelo container até o executor, sem leitura global tardia de
   configuração.
3. Ler o limite de sessão do SGBD e calcular o menor limite não zero antes de
   montar a instrução.
4. Capturar imediatamente o código do banco antes de qualquer restauração de
   sessão.
5. Classificar MySQL `3024` e MariaDB `1969` como
   `bounded_search_statement_timeout`.
6. Propagar o motivo tipado pelo executor, gateway, repositório e controlador.
7. Restaurar toda variável de sessão em `finally` e liberar a reserva de
   capacidade em sucesso, timeout ou exceção.
8. Se o dialeto ou o limite não puder ser identificado com segurança, não
   assumir `9000 ms`; usar no máximo `3000 ms` ou falhar de forma controlada.
9. Nunca registrar ou devolver SQL, valores de filtros, IDs, conteúdo de
   chamado ou mensagem original do driver.

### 9. Contrato HTTP e experiência de indisponibilidade

Timeout do banco deve resultar em:

```http
HTTP/1.1 503 Service Unavailable
Retry-After: <valor derivado>
Content-Type: application/json; charset=UTF-8
Cache-Control: private, no-store
X-Content-Type-Options: nosniff
```

```json
{
  "contract": "ticket_results",
  "version": 2,
  "success": false,
  "error": "bounded_search_statement_timeout",
  "request_id": "..."
}
```

Mensagem da interface:

> A consulta ultrapassou o limite seguro configurado. Esta página não foi
> carregada e seus filtros foram preservados. Aguarde antes de tentar novamente
> ou ajuste os filtros.

Não apresentar zero chamados, lista vazia ou `200`. A falha deve ser anunciada
uma única vez, sem deslocar o foco na carga inicial. Após tentativa iniciada
pelo usuário, se o controle focalizado for substituído, o foco deve ir para o
título "Página não carregada". A contagem do `Retry-After` permanece com
`aria-live="off"`; anunciar somente quando a tentativa manual ficar disponível.

### 10. Circuito, capacidade e observabilidade

1. Manter rate limit, capacidade e circuito antes do acesso ao banco.
2. Para `S <= 5000 ms`, preservar a simultaneidade homologada e calcular a
   lease pela fórmula definida.
3. Para `S > 5000 ms`, impor simultaneidade efetiva `1` e circuito mais
   sensível, independentemente do valor salvo nas demais opções.
4. Recusar pedidos excedentes em até um segundo, sem executar a consulta.
5. Não contabilizar como falha do circuito `403`, `404`, validação, `429` ou
   cancelamento explícito do usuário.
6. Registrar somente telemetria sanitizada: `request_id`, motivo, família e
   código permitido do banco, orçamentos efetivos, duração, adaptador GLPI,
   página/tamanho, contagens estruturais, estado do circuito/capacidade e HMAC
   da forma da consulta.
7. Não registrar SQL, login, nomes, IDs, títulos, conteúdo ou valores de
   critérios.

## Arquivos inicialmente afetados

- `setup.php`;
- `hook.php`;
- `src/Support/Bootstrap.php`;
- `src/Infrastructure/Compliance/SchemaManager.php`;
- `src/Application/ConfigService.php`;
- `src/Infrastructure/Search/MySqlMariaDbQueryBudget.php`;
- executor/gateway/repositório da lista nativa de chamados;
- controlador do contrato `ticket_results`;
- JavaScript da lista assíncrona;
- tela administrativa e estilos dos avisos;
- `src/Support/I18n.php`;
- `tests/unit/SchemaManagerTest.php`;
- testes novos de bootstrap, configuração, idioma e ciclo de desinstalação;
- `VERSION`, `glpiacessivel.xml`, `CITATION.cff` e `CHANGELOG.md` somente na
  etapa de criação do pacote.

## Matriz mínima de testes

Executar a mesma matriz no GLPI 10/PHP 8.1 e GLPI 11/PHP 8.3.

| Cenário | Meio | Resultado obrigatório |
|---|---|---|
| Desinstalação normal | Interface | Sucesso, redirecionamento válido e nenhuma ocorrência nova de SQL 1146. |
| Desinstalação normal | CLI nativa | Saída controlada, tabelas e direitos removidos, sem SQL 1146. |
| Tabela `configs` já ausente | Interface e CLI | Nenhuma tentativa de `SELECT`; remoção das demais tabelas. |
| Algumas tabelas já ausentes | Unidade e CLI | `DROP TABLE IF EXISTS` conclui as restantes. |
| Todas as tabelas ausentes | Unidade | Operação idempotente e sem leitura de configuração. |
| Falha em direitos | Unidade | Interrompe antes do primeiro `DROP`. |
| Falha no meio da remoção | Unidade/integração | Falha controlada; nova tentativa ou reinstalação explícita recupera o estado. |
| Hook já registrado | Unidade/HTTP | Callback vira operação nula depois do início da desmontagem. |
| Requisição concorrente | HTTP autenticado | GLPI permanece disponível e o plugin não consulta tabela removida. |
| Página nativa após remover | Navegador | Página inicial e gerenciador de plugins abrem sem faixa de erro. |
| URL antiga do plugin | Navegador | Bloqueio ou resposta controlada, sem SQL e sem recriação de tabela. |
| Segunda desinstalação | Unidade/CLI | Comportamento idempotente. |
| Reinstalação | Interface e CLI | Esquema e padrões recriados uma vez; portal volta a abrir. |
| Reinstalação sem reiniciar FPM | Interface | Nova versão e runtime reconhecidos sem estado residual de OPcache. |

### Matriz da lista de chamados

| Cenário | Valores/meio | Resultado obrigatório |
|---|---|---|
| Validação da configuração | `999`, `1000`, `3000`, `5000`, `5001`, `5500`, `7000`, `9000`, `9001`, texto, negativo e ausente | Limites e fallback aplicados no servidor; nenhum valor do cliente altera o orçamento. |
| Direito e integridade | administrador, usuário comum e CSRF inválido | Somente administrador altera; falhas não modificam a configuração. |
| Limite herdado do DBA | zero, menor e maior que o solicitado | Zero não limita; em qualquer outro caso prevalece o menor valor. |
| Derivação dos prazos | todos os patamares válidos | Cliente, lease e `Retry-After` correspondem às fórmulas do plano. |
| Guardrails excepcionais | `S > 5000 ms` com recursos ligados/desligados | Servidor força lista assíncrona, capacidade, simultaneidade `1` e circuito de três falhas. |
| MySQL | sucesso e erro `3024` | Timeout tipado, `503`, reserva liberada e nenhuma exposição de SQL. |
| MariaDB | sucesso e erro `1969` | Timeout tipado, `503`, restauração da sessão e nenhuma exposição de SQL. |
| Pesquisa simples | GLPI 10 e 11 | IDs, ordem, ACL e entidade iguais ao GLPI nativo. |
| Pesquisa representativa da falha | participantes requerente/técnico/observador, entidades `1,2,3`, ordenação por atualização | Conclusão dentro do orçamento ou `503` controlado; nunca `504` ou falso zero. |
| Pesquisas avançadas | salva/recorrente, metacritério, `GROUP BY`, `HAVING`, `AND`, `OR`, `AND NOT`, `OR NOT` e Search Option de terceiro | Paridade com o resultado nativo ou indisponibilidade tipada. |
| Paginação | páginas 1 e 2 | Estado preservado, sem repetição automática e sem divergência de ordem. |
| Circuit breaker | três timeouts em 60 s | Abre por 30 s, recusa antes do banco, uma tentativa meio aberta e recuperação após sucesso. |
| Concorrência | `1`, `2`, `5` e `10` sessões | Acima de 5 s só uma consulta chega ao banco; excedentes recebem resposta controlada em até 1 s. |
| Infraestrutura | FPM/proxy/balanceador em no mínimo 20 s | Resposta do plugin sempre ocorre antes da contenção externa. |
| Acessibilidade | teclado, Axe e NVDA | Anúncio único, foco previsível, filtros preservados e nenhuma mensagem técnica. |

## Testes automatizados obrigatórios

1. `tableExists() === false` implica zero chamadas a `request()`.
2. Bootstrap sem esquema não registra hooks funcionais.
3. Hooks registrados não executam trabalho durante `uninstalling`.
4. Configuração ausente retorna padrão seguro sem SQL.
5. Gravação sem esquema falha de forma controlada.
6. Idioma usa fallback estático sem SQL.
7. `uninstall()` pode ser executado duas vezes.
8. Falha parcial seguida de nova tentativa não recria tabelas no runtime.
9. Reinstalação explícita recria configuração e histórico sem duplicidade.
10. Erro de banco com tabela existente não é silenciosamente mascarado.
11. Configuração aceita somente `1000–9000 ms` e volta a `3000 ms` quando
    ausente ou inválida.
12. Orçamento efetivo nunca supera limite não zero herdado do DBA.
13. SQL MySQL/MariaDB recebe o valor efetivo correto por instrução.
14. Erros `3024`/`1969` são diferenciados de conexão, sintaxe e falhas
    genéricas.
15. O prazo do cliente e a lease são derivados do orçamento e a lease nunca
    expira durante uma consulta admitida.
16. Valores acima de `5000 ms` não funcionam sem os guardrails obrigatórios.
17. A resposta tipada usa `503`, `Retry-After`, `no-store` e `nosniff`, sem
    nenhum byte ou aviso antes do JSON.
18. Timeout nunca é convertido em lista vazia, contagem zero ou sucesso HTTP.
19. Critérios, ACL, entidades, IDs e ordem permanecem iguais ao Search nativo.
20. Nenhuma repetição automática ocorre após esgotar o orçamento.

## Homologação de desempenho

Executar, em ambiente com banco e volume equivalentes à produção, ao menos os
patamares de `3000`, `5000`, `7000` e `9000 ms`, sempre em GLPI 10 e GLPI 11.
Para liberar um patamar, exigir:

- `p95` abaixo de 70% do orçamento SQL;
- `p99` abaixo de 85% do orçamento SQL;
- menos de 1% de timeout na lista simples;
- 100% dos timeouts convertidos em `503` controlado;
- zero `502`, `504`, fatal, OOM, deadlock ou término forçado de worker;
- nenhuma lease expirada ou não liberada;
- circuito abrindo e recuperando conforme projetado;
- CPU, IOPS, conexões e filas retornando ao patamar basal;
- nenhuma degradação relevante nas operações nativas do GLPI.

Para `9000 ms`, executar no mínimo 100 repetições representativas com
concorrência `1` e ensaios de recusa com concorrência `2`, `5` e `10`. A maioria
das consultas não pode depender dos últimos 15% do orçamento para concluir.

## Implantação e rollback do orçamento

Introduzir a flag interna `ticket_list_configurable_timeout_enabled`. A
implantação começa com a flag ativa e `3000 ms`, sem alterar automaticamente a
configuração existente. Subir para `5000`, `7000` ou `9000 ms` somente depois
de cada patamar anterior cumprir os gates de homologação.

Rollback imediato:

1. desativar a flag configurável;
2. restaurar o orçamento fixo de `3000 ms`;
3. restaurar o limiar normal do circuito e a simultaneidade anteriormente
   homologada;
4. manter lista assíncrona, capacidade e circuito ativados;
5. nunca retornar ao carregamento síncrono como forma de rollback;
6. manter a chave nova no banco para compatibilidade, ignorada enquanto a flag
   estiver desativada.

Acionar rollback diante de qualquer `502`/`504`, SQL exposto, JSON inválido,
divergência de ACL/IDs/ordem, lease expirada, circuito sem recuperação, mais de
2% de timeouts durante 15 minutos de carga normal, ocupação sustentada superior
a 80% dos workers PHP-FPM ou fila do banco sem retorno ao basal.

## Evidências e logs

Antes de cada ensaio real, registrar tamanho ou timestamp dos arquivos e
comparar somente as linhas novas em:

- `files/_log/sql-errors.log`;
- `files/_log/php-errors.log`;
- log do PHP-FPM;
- log do servidor web.

Não pode surgir ocorrência nova contendo simultaneamente referências como:

- `1146`;
- `glpi_plugin_glpiacessivel_configs`;
- `doesn't exist`;
- `Base table or view not found`.

## Critérios de liberação

A revisão só pode ser empacotada quando:

1. nenhum SQL 1146 for emitido na desinstalação, resposta ou logs;
2. nenhuma consulta atingir tabela própria ausente;
3. nenhuma tabela for recriada por navegação ou bootstrap;
4. o GLPI permanecer operacional depois da remoção;
5. menus, assets, widgets e integrações do plugin desaparecerem;
6. a desinstalação remover todas as tabelas quando não houver falha externa;
7. a reinstalação explícita funcionar sem duplicidade;
8. toda a matriz passar em GLPI 10 e 11;
9. lint, testes unitários, análise estática, auditoria i18n, montagem e
   verificação do pacote passarem integralmente.
10. padrão de `3000 ms` permanecer sem regressão de throughput, tempo ou
    memória;
11. cliente, lease, circuito e capacidade acompanharem o valor configurado;
12. nenhum SQL ou dado pessoal aparecer em HTML, JSON, auditoria ou log
    funcional;
13. configuração de `9000 ms` somente ser liberada após validação dos prazos
    externos e teste de carga.

### Critérios de NO-GO específicos para 9000 ms

Não liberar o teto excepcional quando ocorrer qualquer destes casos:

1. `p95` acima de `6300 ms` ou `p99` acima de `7650 ms`;
2. consultas funcionando apenas próximas de `9000 ms`;
3. qualquer `502`/`504`, fila persistente de PHP-FPM ou conexão presa;
4. lease menor que o prazo efetivo ou cliente expirando antes do SQL;
5. ausência de circuito/capacidade compartilhados em ambiente multinó;
6. possibilidade de superar limite menor definido pelo DBA;
7. consulta continuando a falhar com `9000 ms`;
8. divergência de ACL, IDs, ordenação ou entidade em relação ao GLPI;
9. prejuízo à criação, edição, solução ou visualização nativa de chamados;
10. plano de execução indicando expansão extrema sem ação registrada para a
    causa estrutural.

## Entregáveis da futura versão

1. Implementação dos guardas de ciclo de vida.
2. Orçamento SQL administrável, prazos derivados e tratamento HTTP tipado.
3. Circuito, capacidade, telemetria sanitizada e UX acessível da falha.
4. Testes automatizados, de integração e carga.
5. `docs/test_plan_0.4.16-beta.2.md`.
6. `docs/test_execution_0.4.16-beta.2_<data>.md`.
7. `docs/release_0.4.16-beta.2_safe_uninstall_query_resilience.md`.
8. Atualização dos metadados e do runtime epoch.
9. Pacote esperado:
   `output/release_0.4.16-beta.2_safe_uninstall_query_resilience_<data>_r1/glpiacessivel.zip`.

## Fora do escopo desta revisão

- mudanças funcionais em chamados, perfis, formulários ou auditoria;
- alteração automática de configurações existentes;
- autorreparo de esquema durante navegação;
- recriação de tabelas como efeito colateral de leitura;
- SQL alternativo para substituir o Search nativo;
- alteração global de `max_execution_time` ou `max_statement_time` no banco;
- alteração automática de PHP-FPM, proxy, balanceador ou WAF;
- orçamento acima de `9000 ms`;
- aumento automático do orçamento depois de timeout;
- tratar `9000 ms` como padrão ou como correção definitiva do plano SQL;
- homologação funcional completa de módulos não afetados, além dos testes de
  fumaça necessários para detectar regressão.
