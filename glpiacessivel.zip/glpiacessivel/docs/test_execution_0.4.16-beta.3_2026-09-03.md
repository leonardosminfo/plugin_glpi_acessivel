# Execução de testes — GLPI Acessível 0.4.16-beta.3 — 03/09/2026

## Escopo

Registro da validação das mensagens contextuais de criação, indisponibilidade segura de pesquisas salvas, links nativos por interface e regressões gerais da versão.

## Resultado automatizado

- PHP 8.1.31: `1.031` testes PHPUnit e `6.750` asserções aprovados.
- PHP 8.3.14: `1.031` testes PHPUnit e `6.750` asserções aprovados.
- Navegador: `84` cenários aprovados, incluindo o novo caso sem rota nativa para Self-Service.
- Ensaio de carga: `4` testes de contrato, partição de sessões e classificação de respostas aprovados.
- PHPStan: `313/313` arquivos analisados sem erro.
- PHPCS: `314/314` arquivos aprovados sem erro.
- i18n: `2.693` mensagens auditadas; catálogos POT/PO/MO válidos e compilados com `msgfmt`.
- pacote Marketplace: raiz única `glpiacessivel/`, versão `0.4.16-beta.3`, `365` entradas, perfil público sem ativos de voz offline e contratos de release aprovados pelo verificador.

A execução PHP foi feita com Xdebug desativado para impedir que uma configuração local de log sem permissão contaminasse a saída dos processos filhos. Nenhuma supressão de teste ou erro de aplicação foi utilizada.

## Evidência de homologação anterior à geração do pacote

- No GLPIT, a pesquisa privada `Teste Cosme` não foi exposta ao perfil Leitura.
- Impersonando o proprietário Cosme em Self-Service, a pesquisa apareceu e foi executada pelo plugin sem erro, confirmando a aplicação da ACL nativa.
- A consulta complexa equivalente foi executada pelo Search nativo sem erro; executar critérios não foi confundido com possuir acesso ao objeto `SavedSearch`.
- A paginação acessível apresentou os registros 1–20 e 21–22 sem timeout ou erro de capacidade.

## Validação local ao vivo após a geração do pacote

O pacote `0.4.16-beta.3` foi instalado e ativado nos ambientes locais GLPI 10 (`localhost:8089`) e GLPI 11 (`localhost:8080`). A validação foi executada no navegador integrado do Codex, preservando as sessões autenticadas existentes.

- GLPI 10 / Self-Service: a lista carregou os chamados 1–20 e a página seguinte carregou 21–23, sem erro SQL, timeout, limitação de capacidade ou repetição automática.
- GLPI 11 / Super-Admin: a lista carregou os chamados 1–20 e a página seguinte carregou 21–40, também sem erro operacional.
- Nos dois ambientes, `Novo chamado` manteve o formulário acessível e deixou de exibir o aviso técnico permanente “Limites beta do formulário acessível”. As duas frases técnicas associadas ao aviso também não foram encontradas.
- O link para a lista padrão foi conferido no GLPI 10 com Self-Service e abriu a lista nativa permitida pelo próprio GLPI, sem desvio para formulário ou erro.
- As pesquisas salvas indisponíveis receberam a apresentação segura prevista: título específico, mensagem neutra e ação para limpar a pesquisa, sem botão de repetição nem erro genérico de página.
- Os logs PHP não receberam fatal ou erro novo durante a navegação. Permaneceram apenas os avisos de instalação já conhecidos sobre o uso de campos `DATETIME` nas tabelas do plugin.

## Divergência encontrada na homologação local

As pesquisas fixture simples, aninhada e de agregação aparecem no catálogo acessível, mas a requisição assíncrona as classifica como indisponíveis. No GLPI 11, a mesma consulta simples, aberta pelo URL nativo completo fornecido pelo catálogo, executa e apresenta resultados. A falha ocorre, portanto, na revalidação assíncrona do objeto `SavedSearch` pelo plugin, não no Search nativo nem na consulta ao banco.

Até que a revalidação entre a emissão do estado e `TicketResultController` seja corrigida e repetida nas duas versões, o pacote está aprovado para instalação, listagem, paginação e criação sem envio, mas não deve ser considerado integralmente homologado para reabertura de pesquisas salvas.
