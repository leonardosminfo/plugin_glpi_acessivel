# Plano de testes — GLPI Acessível 0.4.16-beta.4

Data: 03/09/2026.

## Matriz

- GLPI 10 com PHP 8.1.
- GLPI 11 com PHP 8.3.
- Pesquisa simples, busca avançada e pesquisa salva autorizada.
- Teclado e ponteiro.

## Seleção e aplicação de colunas

1. Abrir “Escolher e ordenar colunas”.
2. Adicionar uma coluna, remover outra e alterar a ordem.
3. Acionar “Aplicar colunas e pesquisar” uma única vez.
4. Confirmar uma única submissão e uma única navegação.
5. Confirmar no `FormData` que `advanced[columns][]` contém exatamente a ordem escolhida.
6. Confirmar que os cabeçalhos do resultado mudam já na resposta dessa submissão.
7. Repetir depois de restaurar as colunas padrão.

## Preservação da consulta

1. Combinar colunas com critério avançado, ordenação, agrupamento, tamanho de página e escopo de registros.
2. Aplicar as colunas e comparar o estado submetido com o estado exibido.
3. Repetir com pesquisa salva autorizada, confirmando que o identificador e os critérios permanecem preservados.
4. Confirmar paridade de IDs e ordem com a mesma consulta executada antes da alteração das colunas.

## Cancelamento, validação e acessibilidade

1. Alterar o rascunho e usar Cancelar; confirmar ausência de submissão e preservação das colunas confirmadas.
2. Repetir com Escape.
3. Criar critério inválido e aplicar colunas; confirmar que a validação impede a navegação.
4. Confirmar foco no resumo de erros, link para o controle inválido e `aria-invalid`.
5. Confirmar atualização do rótulo e da contagem acessível após aplicação.
6. Confirmar anúncio do processamento, `aria-busy` após validação válida e proteção contra envio duplo.
7. Verificar teclado, foco visível, zoom e reflow.

## Regressão e pacote

- PHPUnit em PHP 8.1 e 8.3.
- Suíte de navegador.
- PHPStan, PHPCS, auditoria i18n e catálogos compilados.
- Assets fonte e público idênticos.
- Pacote Marketplace verificado para versão, runtime epoch, raiz, arquivos exigidos e arquivos proibidos.

