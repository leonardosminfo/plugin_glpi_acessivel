# Plano de testes — GLPI Acessível 0.4.16-beta.2

## Ambientes

- GLPI 10 com PHP 8.1;
- GLPI 11 com PHP 8.3;
- MySQL e MariaDB suportados pelo respectivo GLPI;
- proxy/PHP-FPM com prazo mínimo de 20 segundos para ensaio de `9000 ms`;
- perfis administrador, técnico e usuário com direitos restritos;
- entidades única e recursiva.

## 1. Atualização e ciclo de vida

1. Atualizar da `0.4.16-beta` sem reiniciar PHP-FPM e confirmar versão/runtime.
2. Desativar, ativar e desinstalar pela interface e CLI.
3. Repetir a desinstalação com `configs`, migrações e tabelas funcionais já
   ausentes, uma de cada vez.
4. Acessar página nativa e URL antiga do plugin durante/depois da remoção.
5. Confirmar ausência de SQL `1146`, fatal, recriação de tabela, menu, assets ou
   hook funcional após a desmontagem.
6. Reinstalar e confirmar criação idempotente dos padrões.

## 2. Configuração do orçamento

Testar `999`, `1000`, `3000`, `5000`, `5001`, `5500`, `7000`, `9000`, `9001`,
negativo, texto e campo ausente.

Confirmar:

- somente administrador com CSRF válido altera a opção;
- inválido mantém valor anterior ou padrão seguro;
- acima de `5000 ms` exige confirmação explícita;
- lista assíncrona e capacidade são forçadas e simultaneidade efetiva vira `1`;
- cliente = SQL + `4000 ms`;
- lease = maior valor entre configuração e cliente em segundos + `2`;
- `Retry-After` nunca é menor que o orçamento SQL arredondado em segundos;
- um limite não zero inferior do DBA prevalece.

## 3. Pesquisa e timeout

Em GLPI 10 e 11, comparar com a lista nativa:

- pesquisa simples;
- entidades única e recursiva;
- requerente, técnico e observador;
- páginas 1 e 2;
- pesquisa salva/recorrente;
- metacritério;
- `GROUP BY` e `HAVING`;
- critérios `AND`, `OR`, `AND NOT` e `OR NOT`;
- Search Option de plugin de terceiro.

Para cada caso, validar IDs, ordem, ACL, perfil, entidade e estado dos filtros.
Uma consulta que exceda o orçamento deve produzir `503` e nunca sucesso vazio.

## 4. Contrato HTTP

- `Content-Type: application/json; charset=UTF-8`;
- `Cache-Control: private, no-store`;
- `X-Content-Type-Options: nosniff`;
- `Retry-After` calculado;
- contrato `ticket_results` versão 2;
- razão `bounded_search_statement_timeout`;
- nenhum byte, aviso, HTML ou SQL antes/depois do JSON;
- reserva liberada em sucesso, timeout e exceção;
- nenhum retry automático.

## 5. Capacidade e carga

Executar `3000`, `5000`, `7000` e `9000 ms`, com concorrência `1`, `2`, `5` e
`10`. Acima de `5000 ms`, somente uma consulta pesada pode chegar ao banco.

Critérios:

- recusa excedente em até um segundo;
- zero `502`, `504`, fatal, OOM e deadlock;
- circuito abre após três timeouts em 60 segundos e recupera após 30 segundos;
- `p95 < 70%` e `p99 < 85%` do orçamento liberado;
- conexões, filas, memória, CPU e IOPS retornam ao basal;
- operações nativas do GLPI não apresentam degradação relevante.

## 6. Acessibilidade

- teclado completo na configuração e na recuperação da lista;
- Axe sem violação nova;
- NVDA com Chrome e Firefox;
- anúncio único da falha;
- contagem regressiva sem repetição sonora;
- foco inicial preservado e retorno previsível após tentativa manual;
- filtros mantidos e mensagem sem termos internos de banco.

## 7. Regressão funcional

Repetir criação e detalhe de chamado, atores, atribuição, acompanhamento,
tarefa, solução, aprovação/recusa, filtros, formulários incorporados,
FormCreator, auditoria, proteção de dados, autenticação e VLibras.

## Critérios de bloqueio

Não liberar com SQL exposto, `1146`, `502/504`, lease expirada, JSON inválido,
timeout convertido em zero, divergência nativa, regressão de direitos ou falha
de teclado/leitor de tela. O patamar de `9000 ms` também é bloqueado se
`p95 > 6300 ms`, `p99 > 7650 ms` ou se a consulta ainda falhar nesse teto.
