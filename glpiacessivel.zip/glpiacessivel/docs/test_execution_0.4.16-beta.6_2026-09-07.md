# Execução — 0.4.16-beta.6

Data: 7 de setembro de 2026.

## Estado

**Aprovado para homologação controlada.** O pacote `0.4.16-beta.6` foi instalado
e ativado no GLPI 10.0.10 e no GLPI 11.0.7 locais. A pesquisa N1 foi comparada
com o motor nativo nas três páginas e os controles de contexto e capacidade
permaneceram íntegros.

## Evidência funcional reutilizada

- GLPI 10.0.10 e GLPI 11.0.7: quatro pesquisas sintéticas em três páginas,
  comparadas com o carregamento nativo, aprovadas após a correção.
- PHP 8.1.31 e 8.3.14: 1.148 testes e 7.611 asserções em cada runtime.
- Vinte cenários assíncronos/acessíveis da lista aprovados.
- PHPCS (323 arquivos), PHPStan e auditoria de 2.709 mensagens aprovados.
- Capacidade/contexto aprovados nos modos já configurados de cada ambiente.

Detalhes, falha anterior e relatórios locais em
`test_execution_N1_correction_2026-09-07.md`.

## Gate do pacote beta.6

### Artefato e instalação

- Perfil de build: `marketplace`, com raiz única `glpiacessivel/`.
- Versão: `0.4.16-beta.6`.
- Runtime epoch: `20260907-01`, igual em `setup.php`, `Bootstrap` e
  `SchemaManager`.
- Build de verificação instalado: SHA-256
  `0f7cbec3b248bba62f3ca34d935729518f72c3e3e4773fb1f2ab44abaddf0198`.
- Backup anterior à instalação:
  `deployment_backups/beta6-preinstall-20260907-195940`.
- O mesmo conteúdo do pacote foi copiado para os dois ambientes. Os hashes de
  `VERSION`, `setup.php`, `Bootstrap.php`, `SchemaManager.php`,
  `NativeSavedSearchGateway.php` e `ticket-results.js` coincidiram entre o
  staging do pacote e as duas instalações.
- Após a cópia, o GLPI marcou corretamente o plugin como **Para atualizar**.
  A atualização e a ativação foram concluídas pelos comandos nativos do GLPI.
  O GLPI 10 emitiu apenas avisos nativos não fatais sobre campos `DATETIME`.
- Nenhum contêiner, PHP-FPM ou servidor web foi reiniciado durante a troca.

O ZIP definitivo é reconstruído depois do fechamento deste relatório. Por isso,
seu hash final deve ser obtido de `RELEASE_MANIFEST.json` ou `SHA256SUMS`, ao
lado do artefato, e não do hash de verificação acima. A reconstrução altera
somente a documentação de execução; os arquivos de runtime testados permanecem
com os mesmos hashes.

### Runtime observado pela web

Antes da instalação, requisições aquecidas nas duas versões publicavam assets
com cache-buster `0.4.16-beta.5-*`. Depois da atualização e ativação, sem
reinício, as duas passaram a publicar:

- `glpiacessivel.css?v=0.4.16-beta.6-1788560835`;
- `glpiacessivel.js?v=0.4.16-beta.6-1788569090`.

Relatórios:

- `.test-results/n1-order-20260907/glpi10-post-beta6-activated-1788822162750.json`;
- `.test-results/n1-order-20260907/glpi11-post-beta6-activated-1788822166477.json`.

O perfil sintético não possui o direito global de configuração e recebeu `403`
ao tentar abrir o diagnóstico administrativo. Isso é a restrição nativa
esperada. A versão carregada pela SAPI web foi comprovada pelo cache-buster dos
assets. Como o estado interno do OPcache não ficou acessível a esse perfil, o
teste comprova a atualização sem reinício, mas não afirma que uma API específica
do OPcache foi exercitada.

### Matriz N1 do pacote instalado

Em cada GLPI foram executadas quatro pesquisas sintéticas: sem ordenação salva,
ordenação textual explícita, ordenação em array e a variante sem ordenação com
perfil requerente. Cada pesquisa foi comparada com a reabertura nativa nas
páginas 1, 2 e 3, com 20 itens por página.

Resultado nas duas versões: **12 de 12 páginas aprovadas**, IDs e ordem idênticos
ao nativo, critérios preservados, sem perda nem duplicação. Os assets observados
durante a própria matriz eram da beta.6.

Relatórios:

- `.test-results/n1-order-20260907/glpi10-beta6-package-1788822285397.json`;
- `.test-results/n1-order-20260907/glpi11-beta6-package-1788822287420.json`.

### Contexto, permissões e capacidade

- GLPI 10: limites adicionais mantidos **ativados**. Quando o GLPI nativo
  removeu um critério indisponível no contexto, o plugin recusou a ampliação com
  `422/native_resolved_semantics_changed`. Consultas simultâneas do mesmo
  contexto foram recusadas com `429/user_context_in_flight`; usuários distintos
  continuaram independentes.
- GLPI 11: limites adicionais mantidos **desativados**. As mesmas comparações de
  pesquisa, perfis e usuários foram aprovadas sem introduzir bloqueio adicional.

Relatórios:

- `.test-results/volume-20260907/glpi10-context-mode-1.json`;
- `.test-results/volume-20260907/glpi11-context-mode-0.json`.

## Limites desta aprovação

- A definição remota exata da pesquisa salva chamada **N1** não foi lida nem
  copiada. O teste reproduz o defeito confirmado: pesquisa nativa válida sem
  `sort`/`order` persistidos, incluindo perfis e paginação.
- O histórico `SQL 3024` por tempo máximo de consulta é um problema de carga e
  plano de execução separado. Esta correção evita divergência do plugin na
  resolução da ordenação; ela não transforma uma consulta nativa lenta em uma
  consulta diferente nem promete eliminar todo timeout do banco.
- A aprovação é para homologação controlada. A validação final deve repetir a
  pesquisa N1 real sem expor conteúdo dos chamados e observar tempo, status HTTP
  e igualdade com o resultado nativo.
