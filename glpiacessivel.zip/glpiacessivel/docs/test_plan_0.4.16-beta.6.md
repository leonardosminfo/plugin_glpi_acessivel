# Plano de testes — 0.4.16-beta.6

## Objetivo

Validar o pacote versionado da correção de ordenação das pesquisas salvas e a
atualização `0.4.16-beta.5` para `0.4.16-beta.6` sem reiniciar o PHP, mantendo
regras, configurações e semântica do GLPI 10 e 11.

## Gate de código e artefato

1. Conferir `VERSION`, `setup.php`, XML, CFF e cabeçalhos gettext como beta.6.
2. Conferir epoch `20260907-01` em `setup.php`, `Bootstrap` e `SchemaManager`,
   tanto no workspace quanto dentro do ZIP.
3. Compilar PO/MO, verificar espelhos de assets, executar PHPCS, PHPStan,
   PHPUnit no PHP 8.1/8.3 e os cenários assíncronos afetados.
4. Gerar o perfil Marketplace em diretório novo, verificar raiz única, arquivos
   obrigatórios, caminhos proibidos, metadados, epoch, manifesto e SHA-256.

## Gate instalado

1. Aquecer a beta.5, instalar o conteúdo exato do pacote nas portas 8089 e 8080
   sem reiniciar contêiner ou PHP e confirmar pela SAPI web:
   `loaded_version = disk_version = 0.4.16-beta.6`, epoch consistente e runtime
   não obsoleto.
2. Confirmar que as configurações existentes permanecem inalteradas.
3. Comparar `SavedSearch::load` nativo e plugin nas páginas 1, 2 e 3 das quatro
   pesquisas discriminantes: sem ordem nos dois perfis e com ordem explícita em
   texto/array. Exigir mesmos 45 IDs, mesma ordem, 20/20/5 itens, filtros
   preservados e nenhuma duplicação.
4. Confirmar ausência parcial de ordem, vazio explícito, ASC/DESC/múltipla e
   desempate estável por ID nos contratos automatizados.
5. Confirmar recusa 422 quando o core descarta filtros e resposta 429 com
   `Retry-After` para consulta concorrente do mesmo acesso; usuários distintos
   não podem se bloquear.
6. Abrir lista/paginação em sessão nova e verificar que os assets usam o
   cache-buster beta.6. Uma página aberta antes da atualização deve ser
   recarregada se seu estado/schema estiver antigo.

## Limites da conclusão

Não acessar conteúdo de chamados de homologação. A pesquisa N1 real só estará
confirmada quando nome, proprietário, perfil, entidade, recursividade, filtros,
ordem e Search Options instalados forem exercitados no mesmo contexto. O timeout
SQL 3024 deve permanecer em uma trilha de desempenho separada.
