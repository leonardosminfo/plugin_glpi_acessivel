# Execução da correção — pesquisa salva N1

Data: 7 de setembro de 2026.

## Escopo e conclusão

A correção local foi implementada e aprovada no GLPI 10.0.10 (porta 8089) e
no GLPI 11.0.7 (porta 8080). O plugin agora preserva a ordenação padrão que o
motor nativo resolve quando uma pesquisa salva não contém `sort`/`order`, sem
criar SQL própria e sem alterar critérios, direitos, entidade ou recursividade.

Esta execução reproduz a classe de defeito da pesquisa informada como “N1”. A
definição e o perfil exatos da pesquisa de homologação não foram consultados;
portanto, a validação definitiva daquele registro ainda deve ser feita em
homologação sem acessar o conteúdo dos chamados.

## Implementação

- A perda de critérios entre a definição armazenada e a resolução nativa é
  verificada antes do preenchimento dos padrões, mantendo a recusa segura.
- Somente `sort` e `order` ausentes são obtidos por `Search::manageParams()`.
- O estado de sessão é restaurado mesmo se o core lançar uma exceção.
- O formato escalar legítimo do GLPI 10 e o formato em listas do GLPI 11 são
  normalizados; booleanos, `null`, números fracionários, IDs e direções
  inválidos continuam recusados.
- Ordenação explícita, inclusive vazio explícito, não é substituída.
- A resposta para filtros removidos pelo core usa mensagem específica e não
  oferece um destino nativo potencialmente enganoso.
- Consulta concorrente do mesmo acesso mantém HTTP 429 e `Retry-After`, mas
  agora é explicada separadamente de sobrecarga global.

Arquivos centrais: `src/Infrastructure/Repository/NativeSavedSearchGateway.php`,
`src/Application/SavedTicketSearchService.php`, controladores de lista e
resultado, `templates/tickets/list.php`, `assets/js/ticket-results.js` e
catálogos de tradução.

## Evidência discriminante antes e depois

Foram criados, pelos modelos nativos, 45 chamados sintéticos isolados por
versão, com datas de atualização únicas e deliberadamente diferentes da ordem
dos IDs. Quatro pesquisas privadas foram comparadas em sessões autenticadas
independentes, nas páginas 1, 2 e 3 (20/20/5 itens): administrador sem ordem,
administrador com ordem textual, administrador com ordem em lista e solicitante
sem ordem.

Antes da correção, os casos sem ordem falharam nas duas versões e os casos com
ordem explícita passaram. Evidências:

- `.test-results/n1-order-20260907/glpi10-pre-fix-1788819549123.json`
- `.test-results/n1-order-20260907/glpi11-pre-fix-1788819549713.json`

Após o primeiro ajuste, o GLPI 11 passou e o ensaio real revelou que o GLPI 10
entrega os padrões como escalares. A compatibilidade foi corrigida e a matriz
final passou integralmente nas duas versões: mesmos 45 IDs, mesma ordem do
nativo, filtros preservados e nenhuma perda ou duplicação entre páginas.

- `.test-results/n1-order-20260907/glpi10-post-fix-compat-1788820445516.json`
- `.test-results/n1-order-20260907/glpi11-post-fix-compat-1788820448151.json`

Não foi necessário reiniciar os contêineres nem o PHP para o código corrigido
ser observado.

## Regressões e qualidade

- PHP 8.1.31: 1.148 testes e 7.611 asserções aprovados.
- PHP 8.3.14: 1.148 testes e 7.611 asserções aprovados.
- Navegador assíncrono/acessível: 20 cenários aprovados.
- PHPCS: 323 arquivos aprovados.
- PHPStan: nenhum erro.
- Traduções: 2.709 mensagens e espelhos aprovados.
- Capacidade/contexto: GLPI 10 com limites adicionais ativos e GLPI 11 com
  limites adicionais desativados aprovados; usuários distintos não se bloqueiam
  e a duplicidade do mesmo acesso recebe a recusa controlada esperada.

## Salvaguardas e pendências

Antes das fixtures foi criado o backup privado
`.test-results/n1-order-20260907/before-n1-order-fixture.sql`. Antes da instalação
local, as duas árvores do plugin foram preservadas em
`deployment_backups/n1-fix-preinstall-20260907-192807`.

O erro histórico SQL 3024/3.000 ms é um incidente de orçamento/desempenho
separado e não apareceu nesta matriz. Esta correção não deve ser apresentada
como solução desse timeout. Também permanecem fora da afirmação de equivalência
exata os filtros, plugins de Search Options e o perfil desconhecidos da N1 de
homologação.

A evidência funcional acima foi produzida antes do bump, quando o código ainda
se identificava como `0.4.16-beta.5`. A entrega oficial correspondente foi
versionada posteriormente como `0.4.16-beta.6`, com epoch `20260907-01`; os
resultados do pacote versionado são registrados na execução própria da beta.6.
