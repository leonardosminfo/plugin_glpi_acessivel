# Execução de testes — GLPI Acessível 0.4.16-beta.2 — 02/09/2026

## Escopo executado

Validação local da implementação de desinstalação segura, orçamento SQL
configurável, timeout tipado, contrato assíncrono, capacidade, interface
administrativa, acessibilidade automatizada e catálogos.

Esta execução não substitui a homologação autenticada nos servidores GLPI 10 e
11 com banco e volume equivalentes à produção.

## Resultados

| Verificação | Ambiente | Resultado |
|---|---|---|
| PHPUnit completo | PHP 8.1.31 | 868 testes, 5.311 asserções, aprovado |
| PHPUnit completo | PHP 8.3.14 | 868 testes, 5.311 asserções, aprovado |
| PHPCS | PHP 8.1.31 | 300 arquivos, aprovado |
| PHPStan | PHP 8.1.31 | sem erros |
| Navegador automatizado | Node/Puppeteer | 84 cenários, aprovados |
| Auditoria i18n | POT/pt_BR/en_GB/MO | 2.670 mensagens, aprovada |
| Assets duplicados | `assets`/`public/assets` | JavaScript da lista idêntico |

## Cenários novos confirmados

- bootstrap sem esquema não executa consulta funcional;
- hooks tornam-se inertes durante desinstalação;
- configuração e idioma não acessam tabela removida;
- remoção é idempotente e mantém `configs` até o final;
- padrões de timeout são inseridos sem sobrescrever personalização;
- timeout aceita a faixa de 1 a 9 segundos e deriva cliente/lease/espera;
- limite inferior do DBA prevalece em MySQL e MariaDB;
- códigos `3024` e `1969` propagam a razão tipada até a lista;
- endpoint responde `503` com `Retry-After` e sem SQL;
- timeout não produz lista vazia ou total zero;
- nova tentativa é manual, respeita espera e mantém foco/filtros;
- acima de cinco segundos a simultaneidade efetiva é uma consulta.

## Pendências de homologação

1. Instalar o mesmo ZIP em GLPI 10/PHP 8.1 e GLPI 11/PHP 8.3.
2. Executar desinstalação/reinstalação pela interface e CLI, inspecionando os
   logs incrementais.
3. Reproduzir a pesquisa de participantes e entidades que gerou o erro `3024`.
4. Medir os patamares de 3, 5, 7 e 9 segundos sob carga autenticada.
5. Confirmar paridade com o Search nativo e ausência de `502/504`.
6. Executar NVDA/Chrome e NVDA/Firefox na configuração e recuperação da lista.

## Conclusão local

A implementação está aprovada na linha de base automatizada. A liberação do
teto excepcional de `9000 ms` para produção permanece condicionada aos testes
de infraestrutura, carga e tecnologia assistiva descritos no plano.
