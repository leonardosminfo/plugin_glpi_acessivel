# GLPI Acessível 0.4.16-beta.4 — aplicação imediata das colunas

Data: 03/09/2026.

## Objetivo

Corrigir a divergência em que “Aplicar colunas” apenas confirmava o rascunho visual e fechava o diálogo, mas a lista só mudava depois de um segundo acionamento de “Aplicar filtros e pesquisar”.

## Alterações

- A ação passa a se chamar “Aplicar colunas e pesquisar” e executa imediatamente a consulta completa.
- O envio usa `requestSubmit()` com o botão canônico da pesquisa, preservando validação, token e o caminho normal do navegador; não usa `form.submit()`.
- Critérios, ordenação, agrupamento, tamanho de página, escopo de exclusão, pesquisa salva e demais parâmetros ativos permanecem no mesmo formulário.
- A ordem escolhida é gravada em `advanced[columns][]` antes do envio.
- Cancelar e Escape descartam somente o rascunho e não executam consulta.
- O formulário bloqueia envio duplicado e recebe `aria-busy` somente após validação válida.
- A contagem de colunas é atualizada visual e programaticamente; o início da consulta é anunciado e erros mantêm o foco no resumo de validação.

## Compatibilidade

- GLPI: `>= 10.0` e `< 12.0`.
- PHP: `>= 8.1`.
- Sem migração de banco de dados.
- A construção e execução da consulta continuam delegadas ao Search nativo do GLPI.

## Limites

Esta correção trata a aplicação da configuração de colunas. Ela não altera a compatibilidade de critérios de pesquisas salvas, o plano SQL nativo ou o orçamento de tempo da consulta.

