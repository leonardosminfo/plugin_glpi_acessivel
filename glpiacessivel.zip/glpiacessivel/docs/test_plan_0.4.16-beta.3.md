# Plano de testes — GLPI Acessível 0.4.16-beta.3

Data: 03/09/2026.

## Matriz

- GLPI 10 com PHP 8.1.
- GLPI 11 com PHP 8.3.
- Perfis Self-Service, Leitura, Técnico e Super-Admin.
- Entidade corrente, entidade filha recursiva e entidade não autorizada.

## Criação de chamado

1. Abrir o formulário sem modelo e confirmar ausência do antigo aviso "Limites beta".
2. Selecionar modelo compatível e confirmar que o envio permanece disponível.
3. Selecionar modelo com campo obrigatório não representável e confirmar aviso contextual, razão concreta, bloqueio da submissão parcial e link autorizado para o formulário completo.
4. Confirmar preservação da seleção e foco após validação.
5. Verificar que referências a GLPI 11 não aparecem em uma instalação GLPI 10.

## Pesquisas salvas

1. Proprietário visualiza e executa sua pesquisa privada.
2. Outro usuário não enumera nem executa a pesquisa privada.
3. Super-Admin autorizado visualiza e executa a pesquisa.
4. Pesquisa pública respeita direito nativo, entidade e recursividade.
5. Pesquisa removida, permissão revogada e troca de contexto produzem a mesma mensagem neutra.
6. Timeout e capacidade continuam com mensagem operacional e retentativa própria.
7. Comparar IDs, ordem e paginação entre plugin e GLPI nativo somente sob o mesmo usuário, perfil, entidade e critérios.

## Navegação nativa

1. Interface Central com direito de leitura recebe URL nativa válida da lista.
2. Self-Service, sessão anônima ou ausência de direito não recebem link para a lista central.
3. O fluxo de criação continua usando a rota fornecida pelo core, inclusive redirecionamento configurado ao FormCreator ou Catálogo de Serviços.
4. Nenhum link vazio, `403`, loop ou promessa indevida de preservar filtros é apresentado.

## Acessibilidade

- Teclado completo, ordem e visibilidade do foco.
- Anúncio único em região viva para mudança dinâmica.
- Título e mensagem associados semanticamente.
- Linguagem simples, sem "beta", "fallback" ou "fluxo nativo" na interface comum.
- Zoom em 200% e 400%, reflow em 320 CSS px, contraste e análise Axe/WAVE.

## Automação e empacotamento

- PHPUnit em PHP 8.1 e 8.3.
- PHPStan e PHPCS.
- Suíte de navegador e auditoria i18n.
- Compilação dos catálogos `pt_BR` e `en_GB`.
- Geração do pacote Marketplace e verificação de versão, raiz, arquivos proibidos, runtime epoch e SHA-256.
