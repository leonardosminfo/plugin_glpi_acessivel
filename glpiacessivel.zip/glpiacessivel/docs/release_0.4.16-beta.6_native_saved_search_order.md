# GLPI Acessível 0.4.16-beta.6

Esta versão corrige a divergência de ordenação observada ao reabrir pesquisas
salvas sem `sort`/`order`. O plugin passa a pedir os padrões ao mesmo estágio
`Search::manageParams()` usado pelo GLPI, preservando a diferença legítima entre
o formato escalar do GLPI 10 e o formato em arrays do GLPI 11.

Não foi criada SQL própria, não há migração de banco e nenhuma definição de
pesquisa é regravada. Critérios, metacritérios, entidade, recursividade, perfil,
ACL e ordenações explícitas continuam sob as regras nativas. Se o core remover
um filtro durante a resolução contextual, a lista permanece bloqueada e a
interface explica que nem todos os filtros puderam ser aplicados.

A recusa de uma segunda consulta pesada no mesmo acesso também passa a ser
diferenciada de sobrecarga global, mantendo HTTP 429, `Retry-After`, filtros e
recuperação acessível sem repetição automática.

O runtime epoch `20260907-01` identifica o conjunto atualizado e aciona a
invalidação restrita dos arquivos PHP do plugin. Não é utilizado
`opcache_reset()`. A instalação deve ser feita com backup e pelo fluxo de
atualização do GLPI.

A fixture local com 45 chamados demonstrou a falha antes da correção e a
equivalência posterior com o nativo nas páginas 1, 2 e 3, em GLPI 10 e 11. A
definição exata da pesquisa “N1” de homologação não foi consultada e ainda deve
ser validada no próprio contexto, sem acessar o conteúdo dos chamados.

Consulte o [plano de testes](test_plan_0.4.16-beta.6.md), a
[execução da beta.6](test_execution_0.4.16-beta.6_2026-09-07.md) e a
[evidência discriminante da N1](test_execution_N1_correction_2026-09-07.md).
O erro histórico SQL 3024/3.000 ms é um incidente de desempenho separado e não
é apresentado como corrigido por esta entrega.
