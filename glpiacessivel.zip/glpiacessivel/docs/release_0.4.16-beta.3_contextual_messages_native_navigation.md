# GLPI Acessível 0.4.16-beta.3 — mensagens contextuais e navegação nativa segura

Data: 03/09/2026.

## Objetivo

Esta versão reduz ruído técnico na jornada de abertura de chamados e torna explícita a diferença entre indisponibilidade de uma pesquisa salva e falhas operacionais da lista. A autorização, a visibilidade das pesquisas e a execução permanecem delegadas ao GLPI 10 e 11.

## Alterações

- O aviso permanente "Limites beta" foi removido. Um aviso acessível passa a ser exibido somente quando o modelo selecionado realmente exige campos que não podem ser representados na página.
- Pesquisas salvas removidas ou indisponíveis para o perfil e a entidade atuais recebem mensagem neutra, sem revelar ID, proprietário ou existência do registro.
- Timeout, capacidade, contrato e falhas temporárias continuam distintos e preservam suas ações de recuperação.
- A lista nativa só é oferecida quando a sessão está autenticada, a interface ativa é Central e o GLPI concede leitura de chamados.
- Na interface Self-Service, links de lista central não são apresentados. O fluxo nativo de criação continua respeitando os redirecionamentos configurados pelo GLPI, FormCreator ou Catálogo de Serviços.
- O catálogo e a execução de pesquisas salvas continuam sujeitos a `SavedSearch::getVisibilityCriteria()` e `SavedSearch::can(READ)`.
- O identificador de runtime foi renovado para permitir a atualização a partir da beta.2 sem reinício obrigatório do PHP-FPM quando a invalidação restrita do OPcache estiver disponível.

## Compatibilidade

- GLPI: `>= 10.0` e `< 12.0`.
- PHP: `>= 8.1`.
- Não há migração de esquema ou alteração de dados nesta versão.

## Limites da homologação

Os testes automatizados e a homologação funcional reduzem risco, mas não constituem certificação integral WCAG, eMAG ou RGAA. A validação final deve incluir teclado, leitor de tela e os perfis reais da implantação.
