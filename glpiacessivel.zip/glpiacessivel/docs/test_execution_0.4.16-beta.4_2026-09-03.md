# Execução de testes — GLPI Acessível 0.4.16-beta.4

Data: 03/09/2026.

## Escopo da correção

Aplicação imediata e acessível da seleção ordenada de colunas pelo envio canônico da consulta.

## Evidências automatizadas focadas

- Navegador: adicionar, remover, reordenar, restaurar, cancelar, Escape, envio único, ordem no `FormData`, contagem acessível, validação e foco.
- Contrato PHP: uso de `requestSubmit()`, ausência de `form.submit()`, hidden inputs antes do envio e paridade entre assets fonte/público.
- Resultado focado: 4 cenários de navegador aprovados; 4 testes e 63 asserções aprovados em PHP 8.1 e PHP 8.3.

## Evidências de integração e regressão

- PHP 8.1.31: `1.031` testes PHPUnit e `6.755` asserções aprovados.
- PHP 8.3.14: `1.031` testes PHPUnit e `6.755` asserções aprovados.
- Navegador: `87` cenários aprovados.
- Ensaio de carga: `4` testes aprovados.
- PHPStan: análise aprovada sem erro.
- PHPCS: `314/314` arquivos aprovados sem erro.
- i18n: `2.697` mensagens auditadas e `2.698` entradas compiladas em cada catálogo MO.
- Assets JavaScript fonte/público: conteúdo byte a byte idêntico.

## Pacote e validação funcional local

- O pacote Marketplace foi verificado com raiz única `glpiacessivel/`, versão `0.4.16-beta.4`, runtime epoch `20260903-03`, `368` entradas e perfil público aprovado.
- O mesmo candidato foi instalado e ativado no GLPI 10 (`localhost:8089`) e no GLPI 11 (`localhost:8080`) sem reinício do PHP-FPM; a beta.3 foi preservada como backup em cada contêiner.
- Os dois ambientes serviram `glpiacessivel.js` com a chave de versão `0.4.16-beta.4`.
- No GLPI 10, a coluna Requisitante foi acrescentada e “Aplicar colunas e pesquisar” atualizou imediatamente os cabeçalhos para `ID`, `Título`, `Status`, `Prioridade`, `Última atualização` e `Requisitante`, com novo token de pesquisa e sem segundo acionamento.
- No GLPI 11, o mesmo fluxo acrescentou Requisitante e preservou Grupo responsável, também com atualização imediata e novo token.
- A contagem passou para 6 colunas no GLPI 10 e 7 no GLPI 11.
- Cancelar manteve o URL e a contagem confirmada sem executar nova pesquisa.
- Não houve mensagem de falha da lista nem erro no console do navegador. Os logs PHP mostraram somente os avisos conhecidos de instalação sobre campos `DATETIME` e as entradas de teste do logger, sem fatal novo.

Após registrar estas evidências, apenas a documentação de execução foi incorporada novamente ao pacote final; o código, os catálogos e os assets validados ao vivo permaneceram inalterados.

## Validação no GLPIT

- O ambiente de homologação serviu o asset `glpiacessivel.js` identificado como `0.4.16-beta.4` e apresentou a ação “Aplicar colunas e pesquisar”.
- A consulta inicial carregou sem falha com `ID`, `Título`, `Status`, `Prioridade`, `Grupo responsável` e `Última atualização`.
- Requisitante foi acrescentado ao rascunho e apareceu nos cabeçalhos após um único acionamento; o token de pesquisa mudou uma vez e a contagem passou de 6 para 7.
- Categoria foi acrescentada em outro rascunho e Cancelar preservou o mesmo URL, os mesmos cabeçalhos e a contagem 7, sem executar consulta.
- Depois de aplicar `Status: Novo`, Categoria foi acrescentada e aplicada. O seletor continuou em Novo, o resumo exibiu `Status: Novo. Colunas selecionadas: 8.`, e a lista não apresentou falha.
- Não foram observados erro de capacidade, mensagem de excesso de consultas, falha segura da lista ou erro no console do navegador.

Somente este registro documental foi alterado depois da validação; a implementação executada no GLPIT permaneceu a mesma.

## Matriz funcional ampliada no GLPIT

A validação complementar foi executada no ambiente de homologação sem criar, editar ou excluir chamados e sem alterar usuários. Para o ensaio de paginação, a entidade ativa foi temporariamente ampliada para “Todas as entidades permitidas”; ao final, o contexto original foi restaurado para `Super-Admin`, entidade `JF2R`, no chamado 19.

- **Adicionar, remover e ordenar colunas:** aprovado. O rascunho `ID`, `Título`, `Status`, `Requisitante`, `Grupo responsável` e `Última atualização` foi aplicado na ordem escolhida e recebeu um novo token de pesquisa.
- **Restaurar colunas padrão:** aprovado. A ação restaurou `ID`, `Título`, `Status`, `Prioridade`, `Grupo responsável` e `Última atualização`; a aplicação preservou exatamente essa ordem.
- **Cancelar com Escape:** aprovado. O diálogo foi fechado sem consulta, o URL e os cabeçalhos foram preservados e o foco retornou ao botão “Escolher colunas”.
- **Validação antes da aplicação:** aprovado. Um critério Título sem valor bloqueou a consulta, marcou o campo com `aria-invalid="true"`, exibiu “Critério 1: informe o valor” e levou o foco ao resumo de erro.
- **Pesquisa salva complexa:** aprovado com “Teste Cosme”. O grupo com dois critérios (`Título contém cosme` OU `Descrição contém cosme`) foi preservado ao acrescentar Requisitante; somente a quantidade de colunas mudou de 5 para 6.
- **Paginação após personalização:** aprovado. Com sete colunas, a página 2 exibiu os chamados 21–30 e preservou o mesmo token, a ordem e os cabeçalhos, sem falha de capacidade.
- **Proteção contra acionamento duplo:** aprovado. Um clique duplo em “Aplicar colunas e pesquisar” produziu um único estado final de consulta e incluiu Categoria uma única vez. A garantia de um único `requestSubmit()` também está coberta pela suíte automatizada.
- **Perfis e direitos do GLPI:** aprovado. O perfil de leitura consultou e personalizou colunas, mas não ofereceu criação; `Self-Service` exibiu somente o universo autorizado e manteve “Novo chamado”; `Helpdesk` apresentou “Chamados indisponíveis para este perfil” porque o próprio perfil ativo não possui permissão de consulta. Não existe perfil denominado “Técnico” neste GLPIT, portanto não foi inventada equivalência de permissões.
- **Teclado e anúncios:** aprovado. Enter abriu as opções e o diálogo, o foco inicial foi colocado no seletor de nova coluna, Escape fechou e devolveu o foco ao acionador. As regiões `aria-live` anunciaram “Escolha de colunas aberta com 6 colunas selecionadas” e “Colunas restauradas. Permanecem 6 colunas padrão”.

Nenhum desses cenários apresentou falha segura da lista, excesso de consultas ou divergência dos direitos nativos do perfil. O resultado do perfil `Helpdesk` é uma restrição configurada no GLPI, não um defeito do plugin.

## Limites

Os testes automatizados não substituem avaliação manual com leitor de tela nem certificação WCAG, eMAG ou RGAA.
