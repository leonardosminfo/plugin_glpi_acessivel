# GLPI Acessível 0.4.16-beta.5

Data: 04/09/2026. Candidato de homologação, não certificação de acessibilidade.

## Correções

1. `search=Pesquisar` (e outros rótulos traduzidos) é um acionador de apresentação da pesquisa nativa, não um critério. O gateway o reconhece sem aceitar parâmetros semânticos desconhecidos.
2. IDs de ordenação serializados como texto decimal positivo são normalizados antes do fingerprint e chegam como inteiros ao repositório. Valores inválidos continuam rejeitados.
3. Pesquisa indisponível não é anunciada como mudança de perfil/entidade. A verificação de contexto e a revalidação de autorização continuam obrigatórias.
4. O formulário incorporado oculto não permanece visível por efeito do CSS. Carregamento tardio pode recuperar a tentativa após validar origem, rota e identidade; falhas permanentes não são liberadas. Não há recarga automática de formulário preenchido.

Sem alteração de SQL manual, critérios, regras de perfil, direitos de entidades, limite de 1.000–9.000 ms ou proteção de capacidade. O timeout observado em uma consulta ampla de homologação exige comparação equivalente e medição no ambiente; esta versão não promete eliminá-lo por configuração arbitrária.

## Instalação e validação

Backup do plugin e banco antes de atualização. Instalar pelo fluxo GLPI, preservando configurações. Runtime epoch `20260904-01` identifica o conjunto atualizado. O pacote não contém usuários, credenciais ou scripts de fixtures.

Ver [plano](test_plan_0.4.16-beta.5.md), [execução](test_execution_0.4.16-beta.5_2026-09-04.md) e [base sintética local](local_beta5_test_base.md). Não houve alteração no servidor de homologação durante a preparação desta versão.
