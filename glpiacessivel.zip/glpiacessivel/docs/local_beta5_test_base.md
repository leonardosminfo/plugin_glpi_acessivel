# Base sintética local — beta.5

Alvos exclusivos: GLPI 11 em localhost:8080 e GLPI 10 em localhost:8089.

Namespace `QA_BETA5`. Usuários, perfis, entidades, grupos, chamados e pesquisas são criados pelas classes nativas do GLPI. A base existente não é apagada. Reexecução deve reutilizar os registros identificados pelo namespace e não alterar perfis reais.

Base criada e verificada em 04/09/2026. Cada ambiente tem 6 usuários, 4 perfis, 4 entidades, 3 grupos, 1 categoria, 36 chamados e 8 pesquisas salvas. O GLPI local da porta 8089 é 10.0.10; o da 8080 é 11.0.7.

## Como acessar

Abra `http://localhost:8080` ou `http://localhost:8089` em uma sessão separada para não perder o contexto da conta atual. Use autenticação local e um login abaixo. Depois acesse `/plugins/glpiacessivel/front/tickets.php` e abra Pesquisas salvas.

| Login | Uso | Acesso inicial aos 36 chamados |
| --- | --- | --- |
| `qa_beta5_reader` | Leitura; sem criar/editar chamados | 32 |
| `qa_beta5_requester` | Solicitante, interface self-service | 20 |
| `qa_beta5_technician` | Técnico participante dos grupos N1 e N2 | 32 |
| `qa_beta5_admin` | Administração de chamados apenas na árvore QA | 32 |
| `qa_beta5_multi` | Alternar self-service, técnico e leitura; dois grupos | 12 no perfil inicial |
| `qa_beta5_outside` | Testar isolamento da entidade externa | 4 |

Os nomes de perfil são `[QA_BETA5] read`, `self_service`, `technician` e `admin`. As permissões são nativas, não condicionadas ao nome do perfil. Admin QA não é Super-Admin da instância e não tem configuração global.

As senhas são diferentes entre ambientes, aleatórias e não constam neste documento. Na pasta de desenvolvimento, consulte os arquivos privados:

- `.test-results/beta5/glpi10-credentials.json` para 8089;
- `.test-results/beta5/glpi11-credentials.json` para 8080.

Esses arquivos são de uso local, ignorados pelo Git e não fazem parte do ZIP. Os originais no contêiner estão em `/tmp/qa_beta5_credentials.json`, modo 0600. Não transportar senhas nem executar scripts contra homologação ou produção. Se a senha de uma conta QA for trocada manualmente, o gerador não a redefine ao reexecutar.

## Roteiro rápido

1. Com leitura, abrir `public_search_button` e `public_search_button_unsorted`: ambos devem carregar. Conferir IDs, ordem e paginação no nativo com o mesmo contexto.
2. Abrir `public_empty`: lista vazia válida, sem erro de contexto.
3. Com `qa_beta5_multi`, abrir `private_string_sort`; com outra conta sem acesso à pesquisa, a mesma pesquisa deve ser recusada, nunca substituída por todos os chamados.
4. Na conta múltipla, alternar os três perfis e conferir criação/edição somente quando os direitos nativos permitirem. N1/N2 são grupos sintéticos.
5. Alternar entidade pai com e sem recursividade: somente a árvore inclui chamados das filhas; a entidade pai isolada está vazia.
6. Com `qa_beta5_outside`, conferir apenas seus quatro chamados. Tentar o ID de um chamado da árvore principal deve negar o detalhe sem exibir seu conteúdo.

Os IDs exatos gerados em cada ambiente constam em `.test-results/beta5/glpi10-manifest.json` e `glpi11-manifest.json`. Os relatórios `*-native-compare.json`, `*-multi.json`, `*-root.json` e `*-http.json` registram as verificações automatizadas sem senhas.

## Reproduzir a criação/teste

Scripts de desenvolvimento, não distribuídos no pacote: `tools/homologation/seed-beta5-local.php`, `compare-beta5-local.php` e `test-beta5-http.cjs`. Instruções completas em `tools/homologation/QA_BETA5.md`. Seeder exige CLI, contêiner local, confirmação explícita, banco com URL de loopback e usa transação/modelos nativos. O modo padrão é simulação, sem bootstrap de banco.

Backup anterior à instalação/criação está em `.deployment-backups/beta5-20260904/`. Não restaurar um banco inteiro após novos testes sem avaliar os dados adicionados depois do backup.

Esta base serve para reproduzir pesquisas antigas serializadas, alternância de perfis, recursividade e usuários multigrupo. Não pretende clonar a configuração ou o volume de chamadosh. O caso Computer/metacritério permanece não criado pelo gerador e o agregado/HAVING tem somente resultado vazio nesta fixture; não considerar esses casos como cobertura completa das consultas complexas.
