<div align="center">
  <p><a href="README.md" lang="pt-BR">Português</a> | <strong lang="en">English</strong></p>

  <img src="glpiacessivel.png" width="180" alt="GLPI Accessible logo">

  # GLPI Accessible

  **An alternative, GLPI-integrated service desk journey designed primarily for blind users, people with low vision, and keyboard users.**

  [![Status: beta](https://img.shields.io/badge/status-0.4--beta-f59e0b)](https://github.com/leonardosminfo/plugin_glpi_acessivel/releases)
  [![GLPI 10 and 11](https://img.shields.io/badge/GLPI-10%20%7C%2011-0b5cad)](https://glpi-project.org/)
  [![PHP 8.1+](https://img.shields.io/badge/PHP-%3E%3D%208.1-777bb4)](https://www.php.net/)
  [![GPL-2.0-or-later](https://img.shields.io/badge/license-GPL--2.0--or--later-2f855a)](LICENSE)
  ![Automated tests: 1148](https://img.shields.io/badge/tests-1148%20passing-2f855a)
</div>

> [!IMPORTANT]
> Version `0.4.16-beta.6` preserves GLPI's resolved default ordering when saved searches are reopened, including the different GLPI 10 and 11 formats, and clarifies failures caused by removed filters or a concurrent query. Native Search semantics, ACLs and query budgets remain unchanged, with no custom SQL or database migration. This beta is not a final accessibility certification or GLPI Marketplace approval.

## About the project

GLPI Accessible provides a more direct and assistive service desk experience without creating a parallel authorization layer. The plugin preserves the GLPI session, active entity, profile, groups, and permissions.

It **does not grant additional rights**. Queries and changes remain subject to GLPI core ACLs, business rules, and validations.

The project targets environments where the standard portal still creates barriers for screen reader users, magnification users, high-contrast users, or people who navigate exclusively with a keyboard.

## See it in action

The screens below use fictitious validation data and show workflows that remain subject to the active GLPI profile, entity, and ACLs. They illustrate the product experience, but are not, by themselves, evidence of WCAG or eMAG conformance.

### 1. Start from the accessible service desk

The entry page brings together the modules enabled by the administrator and keeps the GLPI context, entity, and profile visible.

<p align="center">
  <img src="assets/images/readme/01-portal-acessivel.png" width="1100" alt="Accessible portal home page with module navigation, active context, and shortcuts to the main workflows">
</p>

### 2. Submit a request with clear guidance

The assisted ticket flow arranges fields in a predictable sequence without replacing GLPI templates, validations, or permissions.

<p align="center">
  <img src="assets/images/readme/02-abertura-assistida.png" width="1100" alt="Assisted ticket creation page with organized fields, guidance, and access to the Service Catalog">
</p>

### 3. Track tickets allowed by your profile

The ticket list combines text search, compound filters, and results authorized by GLPI. Values such as Status use lists, while catalogs such as Category open paginated choices for selection operators. It also retrieves native saved searches, lets users choose and order columns, and leads to the details, history, and ITIL actions available for each item.

<p align="center">
  <img src="assets/images/readme/03-chamados.png" width="1100" alt="Ticket search page with accessible filters and results restricted by the current user permissions">
</p>

### 4. Search for guidance before opening a ticket

The knowledge base supports subject search and access to articles visible in the active entity and profile.

<p align="center">
  <img src="assets/images/readme/04-base-conhecimento.png" width="1100" alt="Knowledge base page with a search field, categories, and an accessible article reading area">
</p>

### 5. Reuse forms already registered in GLPI

The catalog displays forms available from GLPI 11 Service Catalog or GLPI 10 Formcreator while preserving the native engine whenever required.

<p align="center">
  <img src="assets/images/readme/05-formularios.png" width="1100" alt="Accessible forms catalog with options to report a problem and request a service">
</p>

### 6. Ask the Assistant in the same operational context

The Assistant uses the current profile, entity, and permissions. Write actions remain protected by ACL, CSRF, and structured confirmation.

<p align="center">
  <img src="assets/images/readme/06-assistente.png" width="1100" alt="Assistant page with GLPI context, introductory message, and suggested operational questions">
</p>

### 7. Roll out capabilities gradually

Administrators can customize the Assistant name, visible modules, and integrations without treating presentation settings as authorization.

<p align="center">
  <img src="assets/images/readme/07-configuracoes.png" width="1100" alt="Plugin administration page with the public Assistant name and feature availability settings">
</p>

## User journey

The diagram summarizes the functional flow. Equivalent text follows the diagram so the information does not depend on its visual representation.

```mermaid
flowchart LR
    U["User"] --> P["Accessible portal"]
    P --> C["GLPI context"]
    C --> S["Session, profile, and entity"]
    S --> A{"Allowed by ACL?"}
    A -->|Yes| T["Tickets and ITIL actions"]
    A -->|Yes| K["Knowledge base"]
    A -->|Yes| B["Operational chatbot"]
    A -->|Yes| F["Forms and catalog"]
    A -->|No| N["Neutral and safe response"]
    F --> G["Native engine validation or completion when required"]
```

In text: the user enters through the portal, the plugin loads the GLPI session context, and only displays or executes features allowed by the profile, entity, and object-level ACL. Complex forms may finish in the native engine to preserve conditions, targets, and validations that have not yet reached proven equivalence.

## Main features

| Area | Available capabilities |
| --- | --- |
| Accessible portal | Dedicated entry point, consistent navigation, gradual module rollout, and continuity with the standard GLPI interface. |
| Tickets | Creation, listing, an accessible catalog and CRUD for searches saved directly in GLPI, column customization, detail, history, and ITIL actions according to the actual user and item permissions. On GLPI 11, search, saved searches, and creation use post-POST redirects compatible with the core exception. |
| Knowledge base | Search and access to articles visible in the active context. |
| Operational chatbot | Ticket and knowledge queries, ticket creation assistance, ACL enforcement, and structured confirmations. Its public name is configurable. |
| Forms | Accessible catalog and three opening modes. Integrates with GLPI 11 Service Catalog and GLPI 10 Formcreator when installed. |
| Configuration | Accessibility modes, fallback language, VLibras, voice, optional contact masking, chatbot scope, and per-module availability. |
| Governance | Audit trail for sensitive operations, operational metrics without free-text storage, and administrator diagnostics. |

## Assistive experience

The interface is developed with **WCAG 2.2 Level AA** and the Brazilian **eMAG** as references. It still requires manual validation with assistive technologies.

- heading structure, landmarks, labels, and status regions;
- predictable focus order and visible focus indicators;
- keyboard operation and shortcuts documented in the page help;
- reflow at 320 CSS pixels and magnification without document-level horizontal scrolling in the main workflows; wide tables keep scrolling inside their identified region;
- high-contrast theme and `forced-colors` support;
- field-related error messages;
- dynamic updates announced without excessive screen reader verbosity;
- independent controls to start and stop voice capture or playback;
- respect for reduced-motion preferences.

Automated axe-core and Pa11y checks complement but do not replace testing with NVDA, JAWS, VoiceOver, magnifiers, and real users.

## Compatibility

| Component | Declared range | Notes |
| --- | --- | --- |
| GLPI | `>= 10.0` and `< 12.0` | GLPI 10 and 11. Validation must consider the exact version, installed plugins, profiles, entities, and data. |
| PHP | `>= 8.1` | As declared by `setup.php` and `composer.json`. |
| Database | MySQL `>= 5.7.8` or MariaDB `>= 10.2` | Checked during installation so the ticket-list server-side budget is available. |
| GLPI 11 | Native Service Catalog | Complex flows may be embedded or opened in the native engine. |
| GLPI 10 | Optional Formcreator | Integration requires a compatible, installed, and enabled Formcreator version. |
| Languages | `pt_BR` and `en_GB` | Portuguese is the primary catalog. English is still partial and may use fallback strings. |

This range is a technical compatibility declaration, not evidence that every intermediate release has been tested.

## Installation

### Install from a release package

1. Back up the GLPI database and the current plugin directory.
2. Download `glpiacessivel.zip` from the [Releases page](https://github.com/leonardosminfo/plugin_glpi_acessivel/releases).
3. Extract the package into the GLPI plugins directory.
4. Confirm that the final path is exactly `plugins/glpiacessivel`.
5. In GLPI, open `Setup > Plugins`.
6. Install and enable **GLPI Accessible**.
7. Open `/plugins/glpiacessivel/front/acessivel.php`.

> [!WARNING]
> The technical directory name must be exactly `glpiacessivel`. Do not deploy the development workspace directly to a server.

### Upgrade

1. Record the current settings and back up the database and plugin directory.
2. Replace the directory with the contents of the new `glpiacessivel.zip`.
3. Run the plugin update from GLPI.
4. Clear GLPI and browser caches.
5. Revalidate Self-Service, technician/hotliner, and Super-Admin profiles before expanding the pilot.

## Initial configuration

After enabling the plugin, review `Setup > Plugins > GLPI Accessible`:

1. **Accessibility mode:** `portal`, `embedded`, or `hybrid`. New installations default to `hybrid`; upgrades preserve existing settings.
2. **Portal modules:** each feature can be available, hidden, or disabled. These states never override GLPI ACLs.
3. **Forms:** embed the native form, open it in GLPI, or use the plugin representation with a callback to the native flow.
4. **Chatbot:** customize its public name and define where the floating button appears.
5. **Language:** the primary language comes from the GLPI session; the plugin can define a fallback for missing translations.
6. **Privacy:** email and phone masking is optional and disabled by default. When enabled, temporary disclosure requires permission, a reason, and an audit record.
7. **Voice and VLibras:** validate scope, asset origin policy, CSP, licenses, and privacy before production use.

## Forms: safe integration

The plugin provides three configurable strategies:

- **embedded native:** displays the official form inside the portal journey;
- **open in GLPI:** redirects to the native page;
- **converted with native callback:** presents an accessible plugin layer and delegates compatibility-sensitive operations to the official engine.

This separation avoids claiming full transposition where equivalence has not been proven. Nested conditions, native reference fields, attachments, multiple targets, approvals, or routing may require GLPI 11 Service Catalog or GLPI 10 Formcreator.

On GLPI 11, embedded mode confirms a Service Catalog form only when the origin, render route, identifier, method, and submit endpoint match the expected contract. The plugin neither rebuilds nor triggers the `POST`: fields, conditions, CSRF, validation, and submission stay in the native engine. If the contract cannot be proven, the iframe remains visible with a failure state, a load-only retry, and the full-page alternative.

## Security and privacy

- the GLPI session is the authentication authority;
- the recommended mode delegates login, SSO, and MFA exclusively to GLPI; an optional static notice can identify the Accessible Portal without creating a button, form, or alternate route;
- after authentication, the header combines the login and first name already present in the GLPI session;
- profile, entity, and ACL checks run on the server and at object level;
- write requests use CSRF protection;
- sensitive actions use accessible confirmation, with stronger confirmation for critical actions;
- permission-denied responses avoid revealing out-of-scope objects;
- logs and metrics should not store complete prompts or free-text descriptions;
- personal contact masking and temporary disclosure are configurable and auditable.

Report security issues privately according to [SECURITY.md](SECURITY.md). Do not publish real ticket data, users, entities, tokens, or infrastructure details in issues.

## Voice and external resources

The code supports a `local-first` strategy for speech recognition and synthesis. The public `marketplace` package **does not distribute** offline models or runtimes whose redistribution evidence is still incomplete.

Internal environments may validate local assets or external URLs according to their CSP, licensing, and privacy policies. The installation package includes a detailed voice asset inventory under `docs/`.

## Known beta limitations

- the GLPI 10/11 matrix must still be repeated with representative profiles, entities, versions, and data volumes for each installation;
- complex forms may finish in the native engine;
- the `en_GB` translation still requires community review;
- offline voice assets are not included in the public ZIP;
- automated checks do not replace manual assistive technology testing;
- final Marketplace readiness depends on review of the published package and community validation.

## Quality baseline

Current evidence is in [beta.6 test execution](docs/test_execution_0.4.16-beta.6_2026-09-07.md). This release gate confirmed:

- PHPUnit on PHP 8.1 and PHP 8.3: 1,148 tests and 7,611 assertions passing on each runtime;
- PHPStan and PHPCS passing without errors;
- 20 focused browser scenarios passing for asynchronous results, messages, focus, controlled retries, timeouts, and pagination;
- authenticated native/plugin comparison of 45 tickets, four searches, and three pages on GLPI 10 and 11, without missing, duplicate, or differently ordered results;
- capacity and context checks passing in the configured modes, with independent users and controlled duplicate-query rejection;
- 2,709 i18n messages audited, POT/PO/MO catalogues compiled, and source/public assets synchronised.

Public release still requires:

- the functional and load matrix repeated on GLPI 10 and GLPI 11 with the same ZIP and SHA-256;
- manual assistive-technology validation of critical journeys;
- i18n: a global gate covering PHP, templates, JavaScript, accents, static msgids, plurals, placeholders, mojibake, POT/PO/MO catalogues, and source/public asset parity, with mandatory `msgfmt` validation;
- automated validation of the single ZIP root, version metadata, forbidden paths, and SHA-256;
- online PHP and JavaScript dependency audits must run in CI with registry access before publication.

For local development:

```powershell
composer install
composer qa
pnpm install --frozen-lockfile
pnpm run test:browser
pnpm run a11y:pa11y
```

Authenticated accessibility tests require a valid GLPI session. Detailed test and operation guides are included in the release package under `docs/`.

For local trials with synthetic data, see [`docs/synthetic_accessibility_test_base.md`](docs/synthetic_accessibility_test_base.md).

## Package verification

A public release should contain:

- `glpiacessivel.zip`;
- `SHA256SUMS`;
- pre-release notes;
- the `v0.4.16-beta.6` tag.

Verify the checksum in PowerShell:

```powershell
Get-FileHash .\glpiacessivel.zip -Algorithm SHA256
Get-Content .\SHA256SUMS
```

Maintainers can build and verify the public package with:

```powershell
.\tools\build-release.ps1 -Output .release\0.4.16-beta.6 -Profile marketplace -RequireMsgfmt
.\tools\verify-release.ps1 -Package .release\0.4.16-beta.6\glpiacessivel.zip -ExpectedVersion 0.4.16-beta.6 -ExpectedRuntimeEpoch 20260907-01 -PublicProfile
```

## Documentation

Public files maintained at the project root:

- [Authorship and ownership](AUTHORS.md)
- [Citation metadata](CITATION.cff)
- [0.4.16-beta.6 release notes](docs/release_0.4.16-beta.6_native_saved_search_order.md)
- [0.4.16-beta.6 test plan](docs/test_plan_0.4.16-beta.6.md)
- [0.4.16-beta.6 test execution](docs/test_execution_0.4.16-beta.6_2026-09-07.md)
- [N1 saved-search discriminating evidence](docs/test_execution_N1_correction_2026-09-07.md)
- [Developer Certificate of Origin](DCO.md)
- [0.4.16-beta.4 release notes](docs/release_0.4.16-beta.4_apply_columns_search.md)
- [0.4.16-beta.4 test plan](docs/test_plan_0.4.16-beta.4.md)
- [0.4.16-beta.4 test execution](docs/test_execution_0.4.16-beta.4_2026-09-03.md)
- [0.4.16-beta release notes](docs/release_0.4.16-beta_glpit_accessibility_refinements.md)
- [0.4.16-beta test plan](docs/test_plan_0.4.16-beta.md)
- [0.4.16-beta test execution](docs/test_execution_0.4.16-beta_2026-09-01.md)
- [0.4.15-beta release notes](docs/release_0.4.15-beta_native_solution_decision.md)
- [0.4.15-beta test plan](docs/test_plan_0.4.15-beta.md)
- [0.4.13-beta release notes](docs/release_0.4.13-beta_native_solution_guard.md)
- [Audit governance and retention](docs/roadmap_future_audit_modes_privacy_retention.md)
- [Licensing policy](LICENSE_POLICY.md)
- [Intellectual property checklist](docs/intellectual_property_checklist.md)
- [Changelog](CHANGELOG.md)
- [Contributing guide](CONTRIBUTING.md)
- [Security policy](SECURITY.md)
- [Third-party notices](THIRD_PARTY_NOTICES.md)
- [GPL-2.0-or-later license](LICENSE)

The installation package also contains a `docs/` directory with detailed installation, operation, accessibility, security, testing, and voice inventory guides.

## Authorship and ownership

The original project was conceived, developed, and is maintained by **Leonardo da Silva Moreira**, author and owner of the original code.

The software is distributed under GPL-2.0-or-later. Third parties may create customizations and redistributions under the license without removing authorship of the original project. This is an independent community project and is not an official product sponsored or certified by the GLPI Project or Teclib.

See [authorship and ownership](AUTHORS.md) and the [citation metadata](CITATION.cff).
## Contributing

Accessibility barrier reports are especially valuable. When opening an issue:

- include the GLPI, PHP, plugin, and browser versions;
- describe the test profile and entity without exposing personal data;
- name the assistive technology and workflow used;
- provide reproducible steps, expected result, and observed result;
- include screenshots only when they use fictional or properly anonymized data.

Pull requests must preserve GLPI 10/11 compatibility, server-side ACL checks, internationalization, and keyboard operation.

## License

Distributed under [GPL-2.0-or-later](LICENSE). Third-party dependencies and notices are listed in [THIRD_PARTY_NOTICES.md](THIRD_PARTY_NOTICES.md).

---

The licensing policy is detailed in
[LICENSE_POLICY.md](LICENSE_POLICY.md). GLPI is a trademark of its respective
owner and is mentioned solely to identify compatibility; this project is not
affiliated with, sponsored by, or certified by the GLPI Project or Teclib.

<div align="center">
  An open project working to make service desk workflows more usable for everyone.
</div>
