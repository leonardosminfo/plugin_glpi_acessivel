(function () {
  'use strict';

  function start() {
    const section = document.querySelector('[data-glpiacessivel-ticket-results]');
    if (!(section instanceof HTMLElement)) {
      return;
    }
    const button = section.querySelector('[data-glpiacessivel-copy-selected]');
    const content = section.querySelector('[data-glpiacessivel-ticket-results-content]');
    const status = section.querySelector('[data-glpiacessivel-copy-status]');
    const error = section.querySelector('[data-glpiacessivel-copy-error]');
    const manual = section.querySelector('[data-glpiacessivel-copy-manual]');
    const field = section.querySelector('[data-glpiacessivel-copy-manual-field]');
    const catalog = window.__glpiacessivelI18n && window.__glpiacessivelI18n.messages;
    if (!(button instanceof HTMLButtonElement) || !(content instanceof HTMLElement)
      || !(status instanceof HTMLElement) || !(error instanceof HTMLElement)
      || !(manual instanceof HTMLElement) || !(field instanceof HTMLTextAreaElement)
      || !catalog || button.dataset.glpiacessivelCopyBound === '1') {
      return;
    }
    button.dataset.glpiacessivelCopyBound = '1';

    let revision = 0;
    let pending = false;
    let announcementTimer = 0;
    function selectedText() {
      return Array.from(content.querySelectorAll('.glpiacessivel-ticket-select:checked'))
        .map(function (checkbox) { return String(checkbox.value || '').trim(); })
        .filter(Boolean).join(', ');
    }
    function clearFeedback() {
      window.clearTimeout(announcementTimer);
      status.textContent = '';
      error.textContent = '';
      if (manual.contains(document.activeElement)) {
        const heading = document.getElementById('tickets-lista');
        if (heading instanceof HTMLElement) {
          heading.focus();
        }
      }
      field.value = '';
      manual.hidden = true;
    }
    function reset() {
      revision += 1;
      clearFeedback();
    }
    content.addEventListener('change', function (event) {
      if (event.target instanceof HTMLInputElement
        && event.target.classList.contains('glpiacessivel-ticket-select')) {
        reset();
      }
    });
    section.addEventListener('glpiacessivel:ticket-selection-reset', reset);

    button.addEventListener('click', function () {
      if (pending) {
        return;
      }
      const text = selectedText();
      reset();
      const attempt = revision;
      function current() {
        return attempt === revision && section.isConnected && selectedText() === text;
      }
      function announce(node, key) {
        // A separate task also makes an explicitly repeated action announceable.
        announcementTimer = window.setTimeout(function () {
          if (current()) {
            node.textContent = String(catalog[key] || '');
          }
        }, 0);
      }
      function failed() {
        if (!current()) {
          return;
        }
        field.value = text;
        manual.hidden = false;
        announce(error, 'ticket.copy.failed');
      }
      if (!text) {
        announce(status, 'status.no_ticket_selected');
        return;
      }
      pending = true;
      button.setAttribute('aria-disabled', 'true');
      let operation;
      try {
        if (!navigator.clipboard || typeof navigator.clipboard.writeText !== 'function') {
          throw new Error('clipboard_unavailable');
        }
        // Keep the browser user activation: no permission probe or await first.
        operation = navigator.clipboard.writeText(text);
        if (!operation || typeof operation.then !== 'function') {
          throw new Error('clipboard_result_unconfirmed');
        }
      } catch (ignored) {
        failed();
        pending = false;
        button.removeAttribute('aria-disabled');
        return;
      }
      Promise.resolve(operation).then(function () {
        if (current()) {
          announce(status, 'status.ticket_ids_copied');
        }
      }, failed).finally(function () {
        pending = false;
        button.removeAttribute('aria-disabled');
      });
    });
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', start, { once: true });
  } else {
    start();
  }
})();
