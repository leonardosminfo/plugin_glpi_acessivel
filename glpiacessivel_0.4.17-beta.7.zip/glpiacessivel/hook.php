<?php

// SPDX-License-Identifier: GPL-2.0-or-later

declare(strict_types=1);

spl_autoload_register(static function (string $class): void {

    $prefixes = [
        'GlpiPlugin\\Glpiacessivel\\' => __DIR__ . '/src/',
    ];
    foreach ($prefixes as $prefix => $baseDir) {
        if (strncmp($class, $prefix, strlen($prefix)) !== 0) {
            continue;
        }

        $relative = substr($class, strlen($prefix));
        $path = $baseDir . str_replace('\\', '/', $relative) . '.php';
        if (is_file($path)) {
            require_once $path;
        }
        return;
    }
});
if (is_file(__DIR__ . '/vendor/autoload.php')) {
    require_once __DIR__ . '/vendor/autoload.php';
}


function glpiacessivel_t(string $text): string
{
    return \GlpiPlugin\Glpiacessivel\Support\I18n::translate($text);
}

function glpiacessivel_n(string $single, string $plural, int $count): string
{
    return \GlpiPlugin\Glpiacessivel\Support\I18n::plural($single, $plural, $count);
}

function glpiacessivel_x(string $context, string $text): string
{
    return \GlpiPlugin\Glpiacessivel\Support\I18n::context($context, $text);
}

function glpiacessivel_html_lang(?string $locale = null): string
{
    return \GlpiPlugin\Glpiacessivel\Support\I18n::htmlLang($locale);
}

function glpiacessivel_i18n_catalog(): array
{
    return \GlpiPlugin\Glpiacessivel\Support\I18n::javascriptCatalog();
}

function glpiacessivel_json_for_script($value): string
{
    $json = json_encode($value, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE | JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT);
    return is_string($json) ? $json : 'null';
}

function plugin_glpiacessivel_portal_icon_markup(int $size = 62): string
{
    $size = min(96, max(16, $size));
    $safeSize = (string) $size;

    return '<svg class="glpiacessivel-portal-icon" viewBox="0 0 100 100" width="' . $safeSize . '" height="' . $safeSize . '" aria-hidden="true" focusable="false">'
        . '<path d="M20 34 A38 38 0 0 1 80 34" fill="none" stroke="#000000" stroke-width="4.5" stroke-linecap="round"></path>'
        . '<path d="M20 43 Q50 57 80 43" fill="none" stroke="#000000" stroke-width="4.5" stroke-linecap="round"></path>'
        . '<path d="M18 52 A38 38 0 0 0 33 81" fill="none" stroke="#000000" stroke-width="4.5" stroke-linecap="round"></path>'
        . '<path d="M82 52 A38 38 0 0 1 67 81" fill="none" stroke="#000000" stroke-width="4.5" stroke-linecap="round"></path>'
        . '<path d="M42 87 A20 20 0 0 0 58 87" fill="none" stroke="#000000" stroke-width="4.5" stroke-linecap="round"></path>'
        . '<path d="M50 57 L35 82" fill="none" stroke="#000000" stroke-width="4.5" stroke-linecap="round"></path>'
        . '<path d="M50 57 L65 82" fill="none" stroke="#000000" stroke-width="4.5" stroke-linecap="round"></path>'
        . '<circle cx="50" cy="33" r="10.5" fill="#49b9e5" stroke="#000000" stroke-width="4.5"></circle>'
        . '<circle cx="20" cy="43" r="5.5" fill="#49b9e5" stroke="#000000" stroke-width="4.5"></circle>'
        . '<circle cx="80" cy="43" r="5.5" fill="#49b9e5" stroke="#000000" stroke-width="4.5"></circle>'
        . '<circle cx="35" cy="82" r="5.5" fill="#49b9e5" stroke="#000000" stroke-width="4.5"></circle>'
        . '<circle cx="65" cy="82" r="5.5" fill="#49b9e5" stroke="#000000" stroke-width="4.5"></circle>'
        . '</svg>';
}

function plugin_glpiacessivel_hook_runtime_is_available(): bool
{
    if (\GlpiPlugin\Glpiacessivel\Support\Bootstrap::isUninstalling()) {
        return false;
    }

    if (!function_exists('plugin_glpiacessivel_runtime_is_available')) {
        return true;
    }

    // GLPI always provides the database before invoking these hooks. Keeping
    // the callback usable without it preserves isolated rendering/tests while
    // the uninstall marker above still makes the teardown path fail closed.
    if (!isset($GLOBALS['DB']) || !is_object($GLOBALS['DB'])) {
        return true;
    }

    return plugin_glpiacessivel_runtime_is_available();
}

function plugin_glpiacessivel_display_login(): void
{
    if (!plugin_glpiacessivel_hook_runtime_is_available()) {
        return;
    }

    if (
        function_exists('plugin_glpiacessivel_is_accessible_login_bridge_enabled')
        && plugin_glpiacessivel_is_accessible_login_bridge_enabled()
    ) {
        plugin_glpiacessivel_display_accessible_login_bridge();
        return;
    }

    if (
        function_exists('plugin_glpiacessivel_should_display_login_accessibility_notice')
        && plugin_glpiacessivel_should_display_login_accessibility_notice()
    ) {
        plugin_glpiacessivel_display_login_accessibility_notice();
    }
}

function plugin_glpiacessivel_display_login_accessibility_notice(): void
{
    if (!plugin_glpiacessivel_hook_runtime_is_available()) {
        return;
    }

    $message = glpiacessivel_t(
        'Após entrar, procure Portal Acessível no início da página ou no menu principal.'
    );
    $label = glpiacessivel_t('Informacao de acessibilidade');

    echo '<div id="glpiacessivel-login-accessibility-notice" role="note" aria-label="' . htmlspecialchars($label, ENT_QUOTES, 'UTF-8') . '" class="glpiacessivel-login-accessibility-notice alert alert-info d-flex align-items-start gap-2 mt-2 mb-0 text-start">';
    echo '<span class="glpiacessivel-login-accessibility-notice-icon d-inline-flex flex-shrink-0" aria-hidden="true">';
    echo plugin_glpiacessivel_portal_icon_markup(32);
    echo '</span>';
    echo '<p class="mb-0 small">' . htmlspecialchars($message, ENT_QUOTES, 'UTF-8') . '</p>';
    echo '</div>';
}

/**
 * Whether the current native GLPI page may expose an entry to the portal.
 *
 * @param array<string, mixed>|null $sessionStatus
 */
function plugin_glpiacessivel_portal_is_available(?array $sessionStatus = null): bool
{
    if (!plugin_glpiacessivel_hook_runtime_is_available()) {
        return false;
    }

    try {
        $sessionStatus ??= (new \GlpiPlugin\Glpiacessivel\Security\SessionContextGuard())->status();
        if (
            empty($sessionStatus['is_authenticated'])
            || empty($sessionStatus['session_ready'])
            || empty($sessionStatus['context_valid'])
        ) {
            return false;
        }

        return \GlpiPlugin\Glpiacessivel\Support\Container::get()
            ->authorization()
            ->canViewPortal();
    } catch (\Throwable $e) {
        // Discovery must fail closed; portal controllers remain the canonical ACL boundary.
        return false;
    }
}

/** @return array<string, bool> */
function plugin_glpiacessivel_runtime_portal_capabilities(): array
{
    $capabilities = ['ticket_create' => false];

    try {
        $sessionStatus = (new \GlpiPlugin\Glpiacessivel\Security\SessionContextGuard())->status();
        if (empty($sessionStatus['is_authenticated']) || empty($sessionStatus['context_valid'])) {
            return $capabilities;
        }

        $capabilities['ticket_create'] = \GlpiPlugin\Glpiacessivel\Support\Container::get()
            ->authorization()
            ->canCreateTickets();
    } catch (\Throwable $e) {
        // Capabilities fail closed; the canonical controller still enforces ACL.
    }

    return $capabilities;
}

function plugin_glpiacessivel_display_accessible_login_bridge(): void
{
    if (!plugin_glpiacessivel_hook_runtime_is_available()) {
        return;
    }

    if (
        !function_exists('plugin_glpiacessivel_is_accessible_login_bridge_enabled')
        || !plugin_glpiacessivel_is_accessible_login_bridge_enabled()
    ) {
        return;
    }

    $url = \GlpiPlugin\Glpiacessivel\Support\Url::plugin('front/acessivel.php');
    $safeUrl = htmlspecialchars($url, ENT_QUOTES, 'UTF-8');
    $chatbotFloating = plugin_glpiacessivel_is_chatbot_floating_button_enabled() ? 'true' : 'false';
    $mode = plugin_glpiacessivel_get_accessibility_mode();
    $sessionStatus = (new \GlpiPlugin\Glpiacessivel\Security\SessionContextGuard())->status();
    $runtimeConfig = [
        'accessibilityMode' => $mode,
        'chatbotEnabled' => plugin_glpiacessivel_is_chatbot_enabled(),
        'portalModules' => plugin_glpiacessivel_get_portal_module_states(),
        'portalCapabilities' => plugin_glpiacessivel_runtime_portal_capabilities(),
        'portalAvailable' => plugin_glpiacessivel_portal_is_available($sessionStatus),
        'chatbotFloatingScope' => plugin_glpiacessivel_get_chatbot_floating_scope(),
        'isLogged' => !empty($sessionStatus['is_authenticated']),
        'sessionReady' => !empty($sessionStatus['session_ready']),
        'contextValid' => !empty($sessionStatus['context_valid']),
        'sessionIssueCode' => (string) ($sessionStatus['issue_code'] ?? 'unknown'),
        'activeProfileId' => (int) ($sessionStatus['profile_id'] ?? 0),
        'activeEntityId' => (int) ($sessionStatus['entity_id'] ?? 0),
        'locale' => \GlpiPlugin\Glpiacessivel\Support\I18n::locale(),
        'htmlLang' => \GlpiPlugin\Glpiacessivel\Support\I18n::htmlLang(),
        'fallbackLocale' => \GlpiPlugin\Glpiacessivel\Support\I18n::fallbackLocale(),
        'vlibrasScope' => function_exists('plugin_glpiacessivel_get_vlibras_scope') ? plugin_glpiacessivel_get_vlibras_scope() : 'plugin_pages',
        'vlibrasEnabled' => function_exists('plugin_glpiacessivel_is_vlibras_enabled_for_context') ? plugin_glpiacessivel_is_vlibras_enabled_for_context(false, true) : false,
    ];
    $entryLabel = $mode === 'embedded'
        ? glpiacessivel_t('Entrar com apoio acessível')
        : glpiacessivel_t('Entrar pelo portal acessível');
    echo '<script>document.documentElement.setAttribute("data-glpiacessivel-chatbot-floating",' . ($chatbotFloating === 'true' ? '"1"' : '"0"') . ');'
        . 'window.__glpiacessivelChatbotFloatingEnabled=' . $chatbotFloating . ';'
        . 'window.__glpiacessivelRuntimeConfig=' . glpiacessivel_json_for_script($runtimeConfig) . ';'
        . 'window.__glpiacessivelRuntimeConfigLoaded=true;'
        . 'window.__glpiacessivelI18n=' . glpiacessivel_json_for_script(glpiacessivel_i18n_catalog()) . ';'
        . 'window.__glpiacessivelI18nLoaded=true;</script>';
    echo '<div id="glpiacessivel-login-entry" class="glpiacessivel-login-entry glpiacessivel-login-entry-inline" role="region" aria-label="' . htmlspecialchars(glpiacessivel_t('Acesso acessível'), ENT_QUOTES, 'UTF-8') . '">';
    echo '<a class="glpiacessivel-login-entry-link" href="' . $safeUrl . '" aria-label="' . htmlspecialchars($entryLabel . ' ' . glpiacessivel_t('do GLPI'), ENT_QUOTES, 'UTF-8') . '">';
    echo plugin_glpiacessivel_portal_icon_markup();
    echo '<span>' . htmlspecialchars($entryLabel, ENT_QUOTES, 'UTF-8') . '</span>';
    echo '</a>';
    echo '</div>';
    echo '<script>(function(){'
        . 'function placePortalEntry(){'
        . 'var entry=document.getElementById("glpiacessivel-login-entry");'
        . 'if(!entry){return;}'
        . 'var loginButton=document.querySelector("button[type=\'submit\'], input[type=\'submit\']");'
        . 'if(!loginButton){return;}'
        . 'var anchor=loginButton.closest(".form-group, .mb-3, .mb-4, .input-group, p, div") || loginButton;'
        . 'if(anchor && anchor.parentNode && entry.previousElementSibling !== anchor){'
        . 'anchor.insertAdjacentElement("afterend", entry);'
        . '}'
        . '}'
        . 'function retryPlace(attempt){'
        . 'placePortalEntry();'
        . 'if(document.getElementById("glpiacessivel-login-entry") && document.querySelector("button[type=\'submit\'], input[type=\'submit\']")){return;}'
        . 'if(attempt>=12){return;}'
        . 'window.setTimeout(function(){retryPlace(attempt+1);},250);'
        . '}'
        . 'if(document.readyState==="loading"){document.addEventListener("DOMContentLoaded",function(){retryPlace(0);});}else{retryPlace(0);}'
        . '})();</script>';
}

function plugin_glpiacessivel_display_central(): void
{
    static $rendered = false;
    if ($rendered || !plugin_glpiacessivel_hook_runtime_is_available()) {
        return;
    }

    try {
        $sessionStatus = (new \GlpiPlugin\Glpiacessivel\Security\SessionContextGuard())->status();
    } catch (\Throwable $e) {
        return;
    }
    if (!plugin_glpiacessivel_portal_is_available($sessionStatus)) {
        return;
    }

    $rendered = true;
    $url = \GlpiPlugin\Glpiacessivel\Support\Url::plugin('front/acessivel.php');
    $safeUrl = htmlspecialchars($url, ENT_QUOTES, 'UTF-8');
    $chatbotFloating = plugin_glpiacessivel_is_chatbot_floating_button_enabled() ? 'true' : 'false';
    $mode = plugin_glpiacessivel_get_accessibility_mode();
    $runtimeConfig = [
        'accessibilityMode' => $mode,
        'chatbotEnabled' => plugin_glpiacessivel_is_chatbot_enabled(),
        'portalModules' => plugin_glpiacessivel_get_portal_module_states(),
        'portalCapabilities' => plugin_glpiacessivel_runtime_portal_capabilities(),
        'portalAvailable' => true,
        'chatbotFloatingScope' => plugin_glpiacessivel_get_chatbot_floating_scope(),
        'isLogged' => !empty($sessionStatus['is_authenticated']),
        'sessionReady' => !empty($sessionStatus['session_ready']),
        'contextValid' => !empty($sessionStatus['context_valid']),
        'sessionIssueCode' => (string) ($sessionStatus['issue_code'] ?? 'unknown'),
        'activeProfileId' => (int) ($sessionStatus['profile_id'] ?? 0),
        'activeEntityId' => (int) ($sessionStatus['entity_id'] ?? 0),
        'locale' => \GlpiPlugin\Glpiacessivel\Support\I18n::locale(),
        'htmlLang' => \GlpiPlugin\Glpiacessivel\Support\I18n::htmlLang(),
        'fallbackLocale' => \GlpiPlugin\Glpiacessivel\Support\I18n::fallbackLocale(),
        'vlibrasScope' => function_exists('plugin_glpiacessivel_get_vlibras_scope') ? plugin_glpiacessivel_get_vlibras_scope() : 'plugin_pages',
        'vlibrasEnabled' => function_exists('plugin_glpiacessivel_is_vlibras_enabled_for_context') ? plugin_glpiacessivel_is_vlibras_enabled_for_context(false, false) : false,
    ];
    $portalLabel = $mode === 'embedded'
        ? glpiacessivel_t('Ir para modo acessível do GLPI')
        : glpiacessivel_t('Abrir portal acessível do GLPI');
    $entryTitle = glpiacessivel_t('Interface acessível do GLPI');
    $entryDescription = glpiacessivel_t('Use o GLPI com navegação simplificada e recursos de acessibilidade. Seu perfil, entidade e permissões serão mantidos.');
    $entryAction = glpiacessivel_t('Abrir Portal Acessível');
    $entryShortcut = glpiacessivel_t('Acesso principal: use o link visível Abrir Portal Acessível. Atalho opcional: Ctrl+Alt+Shift+A.');
    echo '<script>document.documentElement.setAttribute("data-glpiacessivel-chatbot-floating",' . ($chatbotFloating === 'true' ? '"1"' : '"0"') . ');'
        . 'window.__glpiacessivelChatbotFloatingEnabled=' . $chatbotFloating . ';'
        . 'window.__glpiacessivelRuntimeConfig=' . glpiacessivel_json_for_script($runtimeConfig) . ';'
        . 'window.__glpiacessivelRuntimeConfigLoaded=true;'
        . 'window.__glpiacessivelI18n=' . glpiacessivel_json_for_script(glpiacessivel_i18n_catalog()) . ';'
        . 'window.__glpiacessivelI18nLoaded=true;</script>';
    echo '<tr id="glpiacessivel-postlogin-entry-row" class="glpiacessivel-postlogin-entry-row">';
    echo '<td colspan="99" class="glpiacessivel-postlogin-entry-cell">';
    echo '<section id="glpiacessivel-postlogin-entry" class="glpiacessivel-postlogin-entry" aria-labelledby="glpiacessivel-postlogin-entry-title">';
    echo '<span class="glpiacessivel-postlogin-entry-icon" aria-hidden="true">' . plugin_glpiacessivel_portal_icon_markup(40) . '</span>';
    echo '<div class="glpiacessivel-postlogin-entry-content">';
    echo '<h2 id="glpiacessivel-postlogin-entry-title" class="glpiacessivel-postlogin-entry-title">' . htmlspecialchars($entryTitle, ENT_QUOTES, 'UTF-8') . '</h2>';
    echo '<p class="glpiacessivel-postlogin-entry-description">' . htmlspecialchars($entryDescription, ENT_QUOTES, 'UTF-8') . '</p>';
    echo '<div class="glpiacessivel-postlogin-entry-actions">';
    echo '<a id="glpiacessivel-postlogin-entry-link" class="glpiacessivel-postlogin-entry-link" href="' . $safeUrl . '" aria-keyshortcuts="Control+Alt+Shift+A" aria-describedby="glpiacessivel-postlogin-entry-shortcut">' . htmlspecialchars($entryAction, ENT_QUOTES, 'UTF-8') . '</a>';
    echo '<p id="glpiacessivel-postlogin-entry-shortcut" class="glpiacessivel-postlogin-entry-shortcut">' . htmlspecialchars($entryShortcut, ENT_QUOTES, 'UTF-8') . '</p>';
    echo '</div>';
    echo '</div>';
    echo '</section>';
    echo '<a id="glpiacessivel-portal-button" class="glpiacessivel-portal-button" href="' . $safeUrl . '" aria-label="' . htmlspecialchars($portalLabel, ENT_QUOTES, 'UTF-8') . '">';
    echo plugin_glpiacessivel_portal_icon_markup();
    echo '<span class="glpiacessivel-sr-only">' . htmlspecialchars($portalLabel, ENT_QUOTES, 'UTF-8') . '</span>';
    echo '</a>';
    echo '</td>';
    echo '</tr>';
}
