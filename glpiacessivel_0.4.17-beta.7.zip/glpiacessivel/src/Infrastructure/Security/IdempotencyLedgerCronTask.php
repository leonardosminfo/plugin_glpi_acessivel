<?php

declare(strict_types=1);

namespace GlpiPlugin\Glpiacessivel\Infrastructure\Security;

final class IdempotencyLedgerCronTask
{
    private const NAME = 'PurgeIdempotencyLedger';
    private const BATCH_SIZE = 200;
    private const MAX_BATCHES = 5;
    private const MAX_SECONDS = 2.0;

    /** @return array{description?:string} */
    public static function cronInfo(string $name): array
    {
        if ($name !== self::NAME) {
            return [];
        }

        return [
            'description' => __(
                'Remove reservas de reenvio expiradas em lotes limitados.',
                'glpiacessivel'
            ),
        ];
    }

    public static function cronPurgeIdempotencyLedger(\CronTask $task): int
    {
        global $DB;

        $deleted = 0;
        $startedAt = microtime(true);
        try {
            $ledger = new IdempotencyLedger($DB);
            for ($batch = 0; $batch < self::MAX_BATCHES; $batch++) {
                $batchDeleted = $ledger->purgeExpiredBatch(self::BATCH_SIZE);
                $deleted += $batchDeleted;
                if (
                    $batchDeleted < self::BATCH_SIZE
                    || (microtime(true) - $startedAt) >= self::MAX_SECONDS
                ) {
                    break;
                }
            }
        } catch (\Throwable) {
            return 0;
        }

        if ($deleted > 0 && method_exists($task, 'addVolume')) {
            $task->addVolume($deleted);
        }

        return $deleted > 0 ? 1 : 0;
    }
}
