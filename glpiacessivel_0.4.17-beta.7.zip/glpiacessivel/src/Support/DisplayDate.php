<?php

declare(strict_types=1);

namespace GlpiPlugin\Glpiacessivel\Support;

/** Formats display text only; never use for persisted values or form inputs. */
final class DisplayDate
{
    public static function format(?string $value): string
    {
        $raw = $value ?? '';
        if (preg_match('/^(\d{4})-(\d{2})-(\d{2})(?:[ T](\d{2}):(\d{2})(?::(\d{2}))?)?$/D', $raw, $parts) !== 1) {
            return $raw;
        }
        if (
            !checkdate((int) $parts[2], (int) $parts[3], (int) $parts[1])
            || (isset($parts[4]) && ((int) $parts[4] > 23 || (int) $parts[5] > 59 || (int) ($parts[6] ?? 0) > 59))
        ) {
            return $raw;
        }
        $method = isset($parts[4]) ? 'convDateTime' : 'convDate';
        if (!is_callable(['\\Html', $method])) {
            return $raw;
        }

        return isset($parts[4])
            ? (string) \Html::convDateTime(str_replace('T', ' ', $raw), null, isset($parts[6]))
            : (string) \Html::convDate($raw);
    }
}
