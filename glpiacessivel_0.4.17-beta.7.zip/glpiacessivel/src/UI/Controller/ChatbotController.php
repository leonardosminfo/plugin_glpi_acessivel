<?php

declare(strict_types=1);

namespace GlpiPlugin\Glpiacessivel\UI\Controller;

use GlpiPlugin\Glpiacessivel\Application\ConfigService;
use GlpiPlugin\Glpiacessivel\Security\InputSanitizer;
use GlpiPlugin\Glpiacessivel\Support\I18n;
use GlpiPlugin\Glpiacessivel\UI\View\View;

final class ChatbotController extends BaseController
{
    public static function index(): void
    {
        self::requireLogin();
        if (!self::requireModuleEnabled(ConfigService::MODULE_CHATBOT)) {
            return;
        }
        $authorization = self::container()->authorization();
        if (!$authorization->canUseChatbot()) {
            self::denyAccess(
                __('Chatbot indisponível para este perfil', 'glpiacessivel'),
                __('O perfil ativo não possui nenhuma das capacidades atendidas pelo chatbot.', 'glpiacessivel'),
                'chatbot.access_denied'
            );
            return;
        }
        $canViewTickets = $authorization->canViewTickets();
        $canViewKnowledgeBase = $authorization->canViewKnowledgeBase();
        $canCreateTicket = $authorization->canCreateTickets();
        $enabled = self::container()->configService()->isChatbotEnabled();
        $context = self::container()->contextService()->getContext();
        $contextValid = !empty($context['is_valid']);

        $sanitizer = new InputSanitizer();
        $method = strtoupper((string) ($_SERVER['REQUEST_METHOD'] ?? 'GET'));
        $prompt = $sanitizer->text($_POST['prompt'] ?? '', 1000);
        $result = null;

        if ($method === 'POST' && $enabled) {
            self::csrf()->validateRequest(true);
            if (!$contextValid) {
                self::container()->auditLogger()->log('chatbot.context.required', [
                    'prompt_len' => strlen($prompt),
                    'profile_id' => (int) ($context['current_profile_id'] ?? 0),
                    'entity_id' => (int) ($context['current_entity_id'] ?? 0),
                ]);
                $result = self::contextRequiredResult($context);
            } else {
                try {
                    $result = self::container()->chatbotService()->handlePrompt($prompt);
                } catch (\Throwable $e) {
                    self::logFailure($e, $prompt);
                    $result = self::fallbackResult(
                        $e,
                        self::shouldShowTechnicalDebug(),
                        $canCreateTicket
                    );
                }
            }
        }

        $config = self::container()->configService();
        $config->migrateLegacyVoiceDefaults();
        $config->migrateLegacyVoiceAssetPaths();
        $resolvedVoiceAssets = $config->getResolvedVoiceAssets();
        $voiceConfig = [
            'enabled' => $enabled && $config->isChatbotVoiceEnabled(),
            'locale' => $config->getChatbotVoiceLocale(),
            'assetMode' => $resolvedVoiceAssets['mode'],
            'sttEngine' => $config->getChatbotSttEngine(),
            'ttsEngine' => $config->getChatbotTtsEngine(),
            'sttScriptUrl' => $resolvedVoiceAssets['sttScriptUrl'],
            'sttScriptSource' => $resolvedVoiceAssets['sttScriptSource'],
            'sttModelUrl' => $resolvedVoiceAssets['sttModelUrl'],
            'sttModelSource' => $resolvedVoiceAssets['sttModelSource'],
            'sttModelLabel' => $config->getChatbotSttModelLabel(),
            'sttModelCacheId' => $config->getChatbotSttModelCacheId(),
            'ttsScriptUrl' => $resolvedVoiceAssets['ttsScriptUrl'],
            'ttsScriptSource' => $resolvedVoiceAssets['ttsScriptSource'],
            'ttsVoiceId' => $config->getChatbotTtsVoiceId(),
            'ttsOnnxRuntimeUrl' => $resolvedVoiceAssets['ttsOnnxRuntimeUrl'],
            'ttsOnnxRuntimeSource' => $resolvedVoiceAssets['ttsOnnxRuntimeSource'],
            'ttsOnnxWasmBaseUrl' => $resolvedVoiceAssets['ttsOnnxWasmBaseUrl'],
            'ttsOnnxWasmBaseSource' => $resolvedVoiceAssets['ttsOnnxWasmBaseSource'],
            'ttsPiperWasmUrl' => $resolvedVoiceAssets['ttsPiperWasmUrl'],
            'ttsPiperWasmSource' => $resolvedVoiceAssets['ttsPiperWasmSource'],
            'ttsPiperDataUrl' => $resolvedVoiceAssets['ttsPiperDataUrl'],
            'ttsPiperDataSource' => $resolvedVoiceAssets['ttsPiperDataSource'],
            'ttsVoiceModelUrl' => $resolvedVoiceAssets['ttsVoiceModelUrl'],
            'ttsVoiceModelSource' => $resolvedVoiceAssets['ttsVoiceModelSource'],
            'ttsVoiceConfigUrl' => $resolvedVoiceAssets['ttsVoiceConfigUrl'],
            'ttsVoiceConfigSource' => $resolvedVoiceAssets['ttsVoiceConfigSource'],
        ];

        View::render('chatbot/index', [
            'title' => __('Chatbot operacional', 'glpiacessivel'),
            'chatbot_name' => $config->getChatbotDisplayName(),
            'prompt' => $prompt,
            'result' => $result,
            'enabled' => $enabled,
            'csrf_token' => self::csrf()->token(true),
            'voice_config' => $voiceConfig,
            'show_debug' => self::shouldShowTechnicalDebug(),
            'context' => $context,
            'context_valid' => $contextValid,
            'portal_module_states' => self::container()->portalModulePolicy()->getEffectiveStates(),
            'can_view_tickets' => $canViewTickets,
            'can_view_knowledge_base' => $canViewKnowledgeBase,
            'can_create_ticket' => $canCreateTicket,
        ]);
    }

    /**
     * @param array<string, mixed> $context
     * @return array<string, mixed>
     */
    private static function contextRequiredResult(array $context): array
    {
        $answer = I18n::translate('Antes de consultar ou abrir chamados, confirme o perfil e a entidade ativa do GLPI.');

        return [
            'intent_version' => 'controller-context-required',
            'intent' => 'context_required',
            'confidence' => 1.0,
            'requires_handoff' => false,
            'answer' => $answer,
            'speech_text' => $answer,
            'next_steps' => [
                I18n::translate('Revise o seletor de perfil e entidade no topo da página'),
                I18n::translate('Escolha a entidade correta antes de enviar nova mensagem'),
                I18n::translate('Se o problema persistir, acione a central para revisar suas permissões'),
            ],
            'data' => [
                'context_summary' => (string) ($context['summary'] ?? ''),
                'profile_id' => (int) ($context['current_profile_id'] ?? 0),
                'entity_id' => (int) ($context['current_entity_id'] ?? 0),
            ],
            'debug' => [],
        ];
    }

    private static function shouldShowTechnicalDebug(): bool
    {
        if (!defined('UPDATE') || !class_exists('\Session') || !method_exists('\Session', 'haveRight')) {
            return false;
        }

        try {
            return \Session::haveRight('config', (int) constant('UPDATE'));
        } catch (\Throwable $e) {
            return false;
        }
    }

    /**
     * @return array<string, mixed>
     */
    private static function fallbackResult(
        \Throwable $e,
        bool $showDebug,
        bool $canCreateTicket
    ): array {
        $answer = I18n::translate('Não consegui concluir essa etapa automaticamente. Você pode reformular a pergunta ou seguir com atendimento individualizado.');
        $data = [];

        if ($showDebug) {
            $data = [
                'error_class' => get_class($e),
                'error_message' => $e->getMessage(),
            ];
        }

        $nextSteps = [
            I18n::translate('Tente reenviar com mais detalhes sobre o problema'),
            I18n::translate('Confira se entidade e perfil ativos estão corretos'),
        ];
        if ($canCreateTicket) {
            $nextSteps[] = I18n::translate('Se quiser abrir atendimento, diga "abrir chamado"');
        }
        $nextSteps[] = I18n::translate('Se a falha persistir, recarregue a página ou contate a central telefônica');

        return [
            'intent_version' => 'controller-fallback',
            'intent' => 'processing_error',
            'confidence' => 0.0,
            'requires_handoff' => true,
            'answer' => $answer,
            'speech_text' => $answer,
            'next_steps' => $nextSteps,
            'data' => $data,
            'debug' => [],
        ];
    }

    private static function logFailure(\Throwable $e, string $prompt): void
    {
        $line = sprintf(
            "[%s] user=%d entity=%d method=%s prompt_len=%d error=%s\n",
            date('c'),
            (int) ($_SESSION['glpiID'] ?? 0),
            (int) ($_SESSION['glpiactive_entity'] ?? 0),
            (string) ($_SERVER['REQUEST_METHOD'] ?? ''),
            strlen($prompt),
            $e->getMessage()
        );

        if (class_exists('\Toolbox') && method_exists('\Toolbox', 'logInFile')) {
            \Toolbox::logInFile('glpiacessivel-chatbot', $line);
            return;
        }

        error_log('[glpiacessivel-chatbot] ' . trim($line));
    }
}
