<?php

declare(strict_types=1);

namespace GlpiPlugin\Glpiacessivel\Application;

/** Search-only status groups. Never expose these as writable ticket statuses. */
final class TicketStatusFilter
{
    public static function label(): string
    {
        return \GlpiPlugin\Glpiacessivel\Support\I18n::translate('Não solucionados');
    }

    public static function isValid(string $status): bool
    {
        return $status === '' || $status === 'open'
            || in_array($status, ['1', '2', '3', '4', '5', '6'], true);
    }

    /** @return int[] */
    public static function openStatuses(): array
    {
        $statuses = [];
        foreach (['INCOMING', 'ASSIGNED', 'PLANNED', 'WAITING'] as $name) {
            $constant = '\\CommonITILObject::' . $name;
            if (!defined($constant)) {
                throw new \RuntimeException('native_ticket_status_unavailable');
            }
            $statuses[] = (int) constant($constant);
        }
        return $statuses;
    }

    /** @return array<int,array<string,mixed>> */
    public static function criteria(int $option, string $status): array
    {
        if (!self::isValid($status) || ($status !== '' && $option <= 0)) {
            throw new \InvalidArgumentException('native_search_status_unsupported');
        }
        if ($status === '') {
            return [];
        }
        if ($status !== 'open') {
            return [['link' => 'AND', 'field' => $option, 'searchtype' => 'equals', 'value' => $status]];
        }
        $criteria = [];
        foreach (self::openStatuses() as $index => $value) {
            $criteria[] = ['link' => $index === 0 ? 'AND' : 'OR', 'field' => $option,
                'searchtype' => 'equals', 'value' => (string) $value];
        }
        return [['link' => 'AND', 'criteria' => $criteria]];
    }
}
