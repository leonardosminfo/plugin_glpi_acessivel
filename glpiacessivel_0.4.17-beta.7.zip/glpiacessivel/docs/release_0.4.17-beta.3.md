# 0.4.17-beta.3

Runtime epoch: `20260917-03`. Data: `2026-09-17`.

Correção cumulativa da beta-2 para identificação de versão durante a atualização do plugin.

- Os leitores do arquivo `VERSION` passam a aceitar o formato legado com ponto antes de beta, como `0.4.17.beta-2`, e o formato canônico com hífen, como `0.4.17-beta.3`.
- A nova versão utiliza o formato canônico, reconhecido também pelo leitor antigo quando o código anterior ainda estiver em cache. A correção não depende apenas da substituição imediata desse leitor.
- A detecção nativa de atualização do GLPI é preservada. Não há alteração de esquema de banco, regras de chamados ou comportamento funcional entregue na beta-2.
- O verificador do pacote exige que `VERSION` esteja no formato canônico, além de conferir a igualdade com a versão esperada, impedindo novos pacotes com a grafia legada de beta.

## Validação

Suíte PHP aprovada: 1209 testes e 8036 asserções. Os testes executam o leitor com o marcador real da release, validam formatos legados e inválidos e simulam código antigo com marcador novo, confirmando a detecção de runtime divergente. A versão canônica também é ordenada depois da beta-2 por version_compare. Lint e PHPCS sem erros nos arquivos de produção alterados. Esses testes não comprovam a invalidação efetiva de OPcache no servidor web; a atualização pela interface deve ainda ser conferida nos ambientes GLPI 10 e 11. O aceite assistivo das alterações anteriores permanece necessário.

## Distribuição

O pacote é gerado localmente, sem publicação externa ou instalação automática. A documentação e os pacotes beta-1 e beta-2 são preservados. A integridade deve ser conferida com o manifesto e o verificador de release. Após substituir os arquivos, acessar a página de plugins para a detecção e executar a atualização nativa. Caso o servidor restrinja opcache_invalidate, utilize preload ou múltiplos processos/pools com cache persistente, poderá ser necessária uma recarga controlada do PHP pela infraestrutura; não é executado opcache_reset global pelo plugin.
