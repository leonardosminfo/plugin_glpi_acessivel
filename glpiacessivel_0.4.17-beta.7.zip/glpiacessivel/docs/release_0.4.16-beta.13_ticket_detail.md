# 0.4.16-beta.13 — detalhe do chamado orientado ao atendimento

Data: 16/09/2026. Runtime epoch: `20260916-01`. Candidato para validação, sem publicação externa automática.

## O que muda

A tela começa pelo resumo, com status, técnicos e grupos atuais. Links internos levam às interações, resposta, responsáveis, status, edição e histórico disponíveis para o perfil. Descrição e anexos iniciais precedem as interações do atendimento.

Responsáveis e encaminhamento ficam destacados na área operacional: grupos e técnicos primeiro; fornecedores, requerentes e observadores em expansores com seus resumos. Edição geral e histórico de alterações ficam recolhidos. Os eventos da conversa têm títulos próprios, sem alteração da ordenação ou dos limites.

## Guia curto da jornada

1. Leia o resumo e escolha um link de navegação no chamado para ir à tarefa desejada.
2. Use **Responder** para acessar a aba existente de acompanhamento; tarefa e solução continuam disponíveis conforme o GLPI permitir.
3. Em **Responsáveis e encaminhamento**, revise grupos e técnicos. Abra fornecedores, requerentes ou observadores somente quando precisar editar esses participantes. **Salvar responsáveis e participantes** confirma todas as alterações deste formulário, inclusive as de blocos recolhidos.
4. Status mantém formulário e confirmação separados. Escolher uma opção não salva automaticamente. Registrar uma solução continua sendo operação própria, não um atalho de status.
5. Para alterar os demais campos, abra **Editar dados do chamado** com Enter, Espaço ou clique. Recolher o bloco não apaga o que foi preenchido nesta página.
6. Abra **Histórico de alterações** para consultar auditoria; **Interações do atendimento** contém a conversa operacional.

Expansores não fecham uns aos outros. Erros em campos recolhidos abrem o bloco necessário; links de destino abrem o contexto antes de orientar o foco. Não há promessa de preservar rascunhos após recarregar a página.

## O que permanece

Mesmos endpoints, nomes de campos, tokens CSRF, revisão de concorrência, sentinelas de seleção vazia e confirmação crítica. Atribuir a mim mantém autorização independente. Permissões, transições, soluções, privacidade, documentos, buscas, entidades e SQL não foram redesenhados. Nenhuma migração de banco ou nova consulta para compor a tela.

## Limitações e aceite

Achado posterior à reorganização: fornecedores são suportados pelo seletor nativo de atribuição, mas o plugin os expõe em bloco próprio, inclusive vazio. A oferta desse bloco usa a capacidade de atribuição, sem considerar a ocultação de `_suppliers_id_assign` pelo modelo; a pesquisa direta também não percorre o mesmo filtro `FILTER_ACTORS` do seletor nativo. Avaliar paridade de modelo/hook e reduzir destaque vazio antes de homologar esse fluxo. Nenhuma alteração de autorização ou remoção de fornecedor foi feita nesta avaliação. O contexto específico do chamado da captura ainda não foi inspecionado.

Os relatos específicos de salto do status e anúncio de anexo como coluna não foram reproduzidos com os usuários. Automação não os encerra nem certifica WCAG/eMAG/RGAA. O aceite exige Valéria/Renato usando seus leitores e navegadores, seguido de reteste no GLPIT 10.0.18. O manual e o roteiro completos devem ser revisados após esse aceite; este guia é provisório do candidato.

Ver `test_execution_0.4.16-beta.13_ticket_detail.md` para evidências e pendências. O pacote beta.12 anterior permanece preservado.
