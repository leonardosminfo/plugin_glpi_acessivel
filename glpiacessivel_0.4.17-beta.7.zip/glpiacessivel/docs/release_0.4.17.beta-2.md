# 0.4.17.beta-2

Runtime epoch: `20260917-02`. Data: `2026-09-17`.

Pacote cumulativo da beta-1 com níveis de serviço somente leitura e ajustes de navegação no detalhe do chamado.

- A seção recolhível de níveis de serviço apresenta os quatro prazos SLA/OLA e os nomes dos acordos vinculados, respeitando os campos ocultos pelo modelo nativo. Distingue ausência de valores de falha de consulta, sem cálculo próprio de prazos nem alteração das regras nativas.
- As interações do atendimento começam recolhidas. A navegação por fragmento direto e o retorno após envio de acompanhamento ou tarefa abrem a seção, preservando o anúncio do resultado da operação. As ações continuam disponíveis fora das interações.
- A navegação interna passa a se chamar “Atalhos do chamado”, com quatro links “Voltar aos atalhos do chamado”. Os novos textos constam dos catálogos português e inglês.
- A apresentação de datas conforme a preferência nativa, entregue na beta-1, é preservada. Não há alteração de esquema de banco nem consultas adicionais de SLA/OLA na listagem.

## Validação

Validação da implementação: 1197 testes PHP (8002 asserções) e 22 testes de interface aprovados. A suíte de interface renderiza o template PHP real com dados sintéticos, CSS e JavaScript de produção; verifica teclado, fragmentos, prioridade do alerta, quatro retornos aos atalhos, preservação dos formulários e reflow em 320 px. Não equivale a teste de envio real nos ambientes GLPI. Os vínculos SLA/OLA foram comparados anteriormente com os modelos nativos nos ambientes locais GLPI 10 e 11. O aceite com leitor de tela e usuários permanece necessário, assim como a validação final em homologação. A análise estática possui pendências anteriores e não é declarada aprovada por esta entrega.

## Distribuição

A geração do ZIP local não implica envio ao GitHub, marketplace, homologação ou produção, nem instalação nos ambientes locais. A documentação e os pacotes da beta-1 são preservados. A integridade do pacote deve ser conferida com o manifesto e o verificador de release.
