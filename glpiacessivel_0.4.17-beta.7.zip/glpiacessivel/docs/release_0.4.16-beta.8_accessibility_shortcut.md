# GLPI Acessível 0.4.16-beta.8

## Objetivo

Eliminar a colisão observada entre o antigo `Alt+A` do plugin e o atalho nativo
do GLPI, mantendo uma única regra nos ambientes GLPI 10 e GLPI 11.

## Alterações

- o atalho opcional global passa a ser `Ctrl+Alt+Shift+A` e abre sempre a
  entrada geral do portal acessível;
- o plugin deixa de declarar e capturar `Alt+A`, preservando o comportamento
  nativo do GLPI;
- a tabela da **Ajuda de acessibilidade**, inclusive no login acessível, informa
  o novo atalho e o descreve como alternativa ao link visível;
- o link pós-login declara `aria-keyshortcuts="Control+Alt+Shift+A"` e associa a
  explicação visível por `aria-describedby`;
- o botão flutuante continua contextual, sem receber o atalho global;
- o atalho não é acionado em campos editáveis, durante composição de texto,
  repetição da tecla ou quando há diálogo visível;
- uma proteção de transição neutraliza o listener anônimo de `Alt+A` deixado por
  uma beta anterior em uma aba que recebeu o novo asset sem recarregamento total;
- versão e epoch de runtime foram renovados para que o GLPI 10 publique uma URL
  de asset diferente e não reutilize JavaScript da beta anterior.

## Compatibilidade e risco

A mudança é restrita à entrada acessível, ao JavaScript transversal e à ajuda.
Não altera o motor Search do GLPI, SQL, ACL, perfis, entidades, critérios,
ordenação, colunas, paginação ou o ciclo de vida dos chamados. O link visível
permanece o meio principal de acesso; o atalho é apenas complementar.

Consulte o [plano de testes](test_plan_0.4.16-beta.8.md) e a
[execução registrada](test_execution_0.4.16-beta.8_2026-09-14.md).
