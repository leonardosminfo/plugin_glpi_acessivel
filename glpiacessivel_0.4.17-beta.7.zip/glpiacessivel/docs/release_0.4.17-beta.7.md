# GLPI Acessível 0.4.17-beta.7

## Reorganização do detalhe do chamado

A descrição agora aparece antes da navegação interna do chamado, seguindo uma sequência mais próxima da tarefa de compreender a solicitação antes de atuar. Um link rápido anterior à descrição permite ir diretamente para a navegação quando o usuário já conhece o conteúdo ou deseja executar uma ação.

A estrutura de primeiro nível passa a seguir esta ordem:

1. resumo do chamado;
2. acesso rápido à navegação;
3. descrição do chamado;
4. navegação do chamado;
5. documentos e anexos;
6. requisitante;
7. interações e áreas operacionais.

Descrição, documentos e requisitante são seções independentes. A navegação mantém o identificador técnico `#atalhos-chamado` e todos os fragmentos já existentes, evitando quebrar links salvos e redirecionamentos internos. O nome visível foi alterado para “Navegação do chamado”, que descreve melhor a função do componente.

## Acessibilidade e compatibilidade

- o `nav` usa o título visível como nome acessível;
- links internos preservam foco, fragmento, formulários, rascunhos e estado dos expansores;
- Níveis de serviço passa a oferecer retorno à navegação, como as demais regiões endereçadas;
- catálogos pt-BR e en-GB foram recompilados;
- nenhuma permissão, regra ITIL, rota nativa, consulta ou esquema de banco foi alterado;
- a mesma estrutura é usada no GLPI 10 e no GLPI 11.

## Validação

- suíte PHP completa;
- suíte completa de navegador;
- Axe WCAG 2.2 A/AA no detalhe sintético;
- reflow sem rolagem horizontal a 320 CSS px;
- teclado, fragmentos, foco, retornos e preservação de estado;
- instalação e verificação local em GLPI 11/8080 e GLPI 10/8089.
