# GLPI Acessível 0.4.16-beta.9

Data: 14/09/2026

## Objetivo

Esta versão elimina o ruído de chave duplicada produzido no log SQL quando duas requisições usam a mesma chave de idempotência. O comportamento funcional já impedia uma segunda mutação; a beta.9 passa a coordenar a disputa sem provocar deliberadamente um erro do banco.

## Alteração

- a inclusão no ledger usa a SQL montada por `DBmysql::buildInsert()` e a execução compatível de `GlpiDatabaseQuery`;
- a cláusula `ON DUPLICATE KEY UPDATE id=id` conserva a linha vencedora sem ocultar outros erros;
- a linha é relida com `SELECT ... FOR UPDATE`, de modo que uma transação iniciada antes da vencedora veja o estado corrente também sob `REPEATABLE READ`;
- o token aleatório relido da linha identifica qual tentativa adquiriu a reserva;
- uma reserva expirada é substituída somente depois de bloquear a linha e removê-la pelo seu `id`, sem varrer o índice de expiração durante a mutação;
- a mesma regra protege reservas comuns, marcadores de resultado incerto e guardas persistentes;
- a limpeza de expirados saiu do caminho transacional crítico e passou a uma ação automática horária do GLPI, em até cinco lotes de 200 linhas ou dois segundos;
- a migração idempotente `V0006_idempotency_ledger_cron` registra essa ação tanto em instalações novas quanto em atualizações da beta.8;
- erro real de SQL, ausência da linha ou estado inválido continuam interrompendo a operação de forma segura.

O pacote não usa `INSERT IGNORE`, não remove a restrição única e não tenta transformar uma consulta prévia em trava. A chave única `(scope_hash, idempotency_key_hash)` permanece como autoridade de concorrência.

## Compatibilidade e alcance

A sintaxe e as abstrações utilizadas são compatíveis com GLPI 10/PHP 8.1 e GLPI 11/PHP 8.3, em MySQL e MariaDB suportados pelo plugin. Não há alteração de esquema; a atualização acrescenta apenas o registro idempotente da migração e da ação automática.

Esta correção não modifica a lista de chamados, o motor `Search`, pesquisas salvas, critérios, paginação, colunas, ACLs, perfis, entidades, atores, formulários ou regras de ciclo de vida ITIL.

O runtime epoch `20260914-04` identifica o novo código e permite a renovação restrita do OPcache durante a atualização.

## Validação necessária

O aceite exige a suíte completa nos dois PHPs, atualização real da beta.8, inspeção do índice e do cron, disputa em duas conexões, transação com snapshot anterior ao vencedor, renovação expirada, repetição concluída, conflito por hash diferente e delta zero de `uniq_scope_key` e deadlock no log SQL. Consulte o [plano de testes](test_plan_0.4.16-beta.9.md) e a [execução registrada](test_execution_0.4.16-beta.9_2026-09-14.md).
