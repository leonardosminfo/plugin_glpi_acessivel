# GLPI Acessível 0.4.16-beta.10 — paridade do seletor de entidades

Data: 15/09/2026

## Correção

Em homologação, o GLPI nativo apresentava `JF2R` e suas subentidades para o
mesmo usuário e perfil, enquanto a interface acessível mostrava apenas a raiz.
A beta.10 passa a consumir as estruturas de árvore do próprio GLPI:

- GLPI 10: `getTreeForItem()`;
- GLPI 11: `Entity::getEntityTree()`.

A escolha ocorre pela capacidade disponível no runtime, sem bifurcar a regra
de negócio por número de versão. O plugin apenas normaliza o retorno nativo em
texto e caminho hierárquico para um `<select>` acessível. Não há SQL direto nem
uma tabela, cache persistente ou ACL paralela.

O estado de “todas as entidades” também segue a representação de cada geração.
No GLPI 11, o marcador nativo é autoritativo inclusive quando vale `false`. No
GLPI 10, que não grava esse marcador, o plugin exige catálogo completo,
contexto não recursivo e igualdade exata entre as entidades efetivas e o
catálogo autorizado. Assim, uma raiz recursiva que alcance toda a árvore não é
confundida visualmente com “todas as entidades”.

## Autoridade e segurança

As raízes continuam vindo de `glpiactiveprofile.entities`. Somente concessões
recursivas são expandidas. Exibição, pré-validação e recursividade usam o mesmo
catálogo, e `Session::changeActiveEntities()` continua sendo a autoridade final
para alterar o contexto.

Se a árvore não puder ser construída, a interface mantém somente o contexto
já ativo, informa a falha e não oferece ampliação para todas as entidades. IDs
adulterados, grupos e dados do usuário que iniciou uma impersonação não
acrescentam entidades.

## Acessibilidade

- caminhos hierárquicos tornam entidades homônimas distinguíveis;
- “inclui subentidades” substitui o jargão visual “árvore”;
- ajuda associada ao seletor explica recursividade e perfil;
- uma única opção é informada sem botão de aplicação sem efeito;
- falha de carregamento é anunciada e oferece nova tentativa segura;
- reflow em 320 CSS px, alto contraste, cores forçadas, teclado e Axe fazem
  parte da regressão automatizada.

## Compatibilidade e impacto

Não há migração de banco. A correção não altera busca/listagem de chamados,
pesquisas salvas, atribuição, solução, formulários, idempotência ou regras ITIL.
O rollback operacional é reinstalar o pacote beta.9, sem reversão de esquema.

Os resultados e limites da validação estão registrados em
`test_plan_execution_0.4.16-beta.10_entity_context.md`.
