# GLPI Acessível 0.4.16-beta.12 — paridade do seletor nativo de entidades

## Problema corrigido

Na homologação com GLPI 10.0.18, o seletor do plugin podia apresentar entidades diferentes das exibidas pelo seletor padrão do GLPI. A beta.11 evitava a chamada a um método privado, mas ainda podia reconstruir a lista pelo gerador genérico de árvores. Esse gerador não é a fonte final usada pela interface nativa e, em uma instalação real, produziu um conjunto mais amplo que o seletor padrão.

## Contrato adotado

A beta.12 usa `Entity::getEntitySelectorTree()` como fonte prioritária quando o método existe. Esse é o catálogo estruturado usado pelo próprio seletor do GLPI 10.0.18 e do GLPI 11. O plugin:

1. consome somente `key`, `folder` e `children`;
2. ignora o campo `title`, porque ele contém HTML de apresentação;
3. resolve cada rótulo completo por `Dropdown::getDropdownName()`;
4. oferece `direct:<id>` para a entidade concreta e `tree:<id>` apenas quando o GLPI indica uma pasta com descendentes;
5. envia o ID e a recursividade resultantes para `Session::changeActiveEntities()`, que continua sendo a autoridade final;
6. mantém apenas o contexto atual se o seletor existir, mas estiver inacessível, lançar erro ou devolver estrutura inconsistente.

Em versões antigas sem `getEntitySelectorTree()`, como o GLPI 10.0.10 local, permanece o adaptador público `getTreeForItem()`/`DbUtils::getTreeForItem()`. Esse fallback só é usado quando o seletor realmente não existe.

## Segurança, desempenho e acessibilidade

- não há SQL de entidades nem ACL paralela no plugin;
- o cliente nunca informa uma recursividade livre: o servidor reconstrói os escopos autorizados pelo catálogo corrente;
- valores numéricos antigos são aceitos apenas para formulários já abertos e são resolvidos contra os mesmos escopos autorizados;
- o catálogo e os nomes são memoizados durante a requisição; a prioridade desta correção é a paridade funcional com o GLPI;
- o `<select>` nativo foi preservado, com caminhos completos e textos “somente esta entidade” e “inclui subentidades”;
- mudanças entre os dois escopos passam a registrar `recursive` na auditoria.

## Escopo preservado

Não foram alterados lista ou busca de chamados, pesquisas salvas, SQL de chamados, atores, formulários, soluções, regras ITIL ou esquema de banco.
