# GLPI Acessível 0.4.16-beta.7

Esta versão reúne correções focalizadas derivadas da avaliação assistiva de
11/09/2026 e da investigação posterior das pesquisas salvas. A entrega mantém o
GLPI como fonte de verdade para pesquisa, autorização, apresentação de usuários,
entidades e atualização de chamados.

Depois do login, a central passa a oferecer uma entrada textual visível para a
interface acessível no início do conteúdo. Esse link visível é o acesso
principal; menu e botão flutuante permanecem como caminhos complementares, e
`Ctrl+Alt+Shift+A` é um atalho opcional. O plugin não declara `Alt+A`,
preservando o acelerador nativo do GLPI 11. As ajudas de acessibilidade da
interface principal e do login apresentam o mesmo contrato. A entrada é
renderizada no hook nativo com marcação válida e só aparece quando a sessão, o contexto e
`Authorization::canViewPortal()` permitem o acesso. Não há redirecionamento,
movimentação automática de foco, nova tabela, consulta ou configuração.

Uma pesquisa salva autorizada agora é identificada no resumo permanente e, após
a resposta válida, seus critérios são narrados a partir do snapshot que o
`Search` do GLPI efetivamente executou. O estado inicial do carregamento
progressivo não afirma que não existem filtros nem apresenta um rascunho como
resultado confirmado. O nome autorizado e um catálogo mínimo de apresentação
permanecem no estado opaco do servidor; SQL, IDs técnicos e definição bruta não
são enviados ao DOM. A alteração não modifica critérios, metacritérios,
`GROUP BY`, `HAVING`, ordenação, colunas, paginação ou ACL.

Na linha do tempo operacional, nomes de usuários passam pelo formatador público
do próprio GLPI, respeitando a ordem configurada nas versões 10 e 11. Textos
históricos já devolvidos por `Log::getHistoryData()` são preservados como
snapshots e não são invertidos por heurística.

O seletor remoto de localização durante a edição passa a conservar a mesma
elegibilidade recursiva do formulário nativo: localização da entidade do chamado
ou de ancestral publicado recursivamente. Irmãos e ancestrais não recursivos
continuam recusados, e o ID é revalidado no contexto do chamado antes da
atualização pelo `Ticket` nativo.

O runtime epoch `20260914-02` identifica o novo conjunto e aciona somente a
invalidação dos arquivos PHP do plugin; não é usado `opcache_reset()`. Não há
migração de banco. A atualização deve ser feita pelo fluxo do GLPI, com backup do
pacote anterior.

Consulte o [plano de testes](test_plan_0.4.16-beta.7.md), a
[execução da beta.7](test_execution_0.4.16-beta.7_2026-09-14.md) e o
[plano consolidado da avaliação assistiva](plan_melhoria_avaliacao_usuario_2026-09-11.md).

Esta beta é candidata a homologação controlada. Testes automatizados não
substituem a repetição das jornadas críticas com leitor de tela e usuário real.
