# 0.4.17-beta.4 — Não solucionados

Filtro de pesquisa `status=open`: novos, atribuídos, planejados e pendentes, usando constantes nativas. Não é um status gravável. `scope=mine` sozinho permanece sem filtro de status; o acesso do cartão envia ambos explicitamente, sem mudar o visual do botão. Entrada geral e pesquisas salvas conservam suas definições.

O indicador e a pesquisa usam o mesmo compilador. Nova pesquisa salva persiste critérios nativos. Mensagem de timeout deixa de indicar falsa incompatibilidade com a Search API. Nenhum timeout, índice, autorização ou esquema de banco foi alterado.

## Verificação local antes do pacote

- GLPI 11.0.7 na porta 8080 e GLPI 10.0.10 na porta 8089.
- Comparação CLI somente leitura: mesmas identidades e ordem nas páginas 1/2 de mine+open e página 1 de mine; exclusão de status 5/6; sem sobreposição; paridade de definição com pesquisa salva e cockpit.
- HTTP autenticado com conta administrativa de QA: seleção open, resultados assíncronos, página 2 e remoção explícita do filtro aprovados em ambas as portas.
- PHPUnit: 1215 testes, 8073 asserções aprovados (incluindo seis novos testes).
- Backups locais antes da implantação: /tmp/glpiacessivel-before-open-20260921 em cada contêiner.

Limitações: comparação em dados locais existentes; não é teste de carga nem homologação de todos os perfis. Não demonstra resolução do timeout do ambiente institucional. Não houve alterações em chamados ou pesquisas salvas para executar os testes nativos.
