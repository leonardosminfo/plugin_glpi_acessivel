# GLPI Acessível 0.4.17-beta.6

## Correção

O detalhe do chamado agora converte para texto os separadores hierárquicos que podem ser devolvidos pelo GLPI 10 como entidades HTML, por exemplo `&#62;`. A conversão ocorre apenas na projeção apresentada ao usuário; o valor armazenado pelo GLPI não é regravado.

O formulário de edição geral usa a mesma projeção e reconhece como inalterado o título exibido já decodificado. O snapshot bruto continua sendo usado para revisão otimista e detecção de concorrência. Quando o título é realmente alterado, a verificação aceita a codificação nativa aplicada pelo GLPI 10 após a gravação.

## Segurança e compatibilidade

- o template continua escapando o título no ponto de saída;
- nenhuma entidade HTML é tratada como marcação confiável;
- não há alteração de esquema nem acesso direto de escrita ao banco;
- a correção usa a mesma rota para GLPI 10 e GLPI 11.

## Validação prevista

- títulos com `&#62;` e `&amp;#62;`;
- salvamento de outro campo sem alteração espúria do título;
- alteração real do título e releitura nativa;
- conteúdo semelhante a HTML sem criação de elemento executável;
- suíte PHP, testes de interface e atualização nativa nos ambientes locais 8080 e 8089.
