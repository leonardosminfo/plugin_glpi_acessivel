# 0.4.16-beta.14 — participantes e fornecedores

Data: 16/09/2026. Runtime epoch `20260916-02`. Candidato local; não publicado automaticamente em homologação ou produção.

## Apresentação

- Requerentes e observadores editáveis ficam resumidos no próprio expansor, sem outra cópia imediatamente acima.
- Quando a edição está indisponível, os resumos de leitura continuam presentes.
- Fornecedor vazio deixa de ocupar uma célula no resumo inicial. Fornecedores já atribuídos continuam identificáveis.
- A oferta de edição depende das condições nativas. Campo indisponível fica ausente do POST, nunca representado como seleção vazia que apagaria vínculos.
- Status, técnicos e grupos continuam no resumo e perto da alteração: repetição intencional para conferir o contexto.

## Integração

A pesquisa de fornecedores deve usar o seletor nativo de atores, respeitando modelo aplicado, entidade, tipo Supplier e filtros dos plugins. O backend revalida a disponibilidade da operação. Seleções atuais são preservadas separadamente do catálogo de novas opções.

Não há alteração em SQL da listagem, pesquisas salvas, status/solução, catálogo de entidades ou esquema de banco. A correção de quebra de linha do status da beta.13 permanece.

## Validação

Execução e resultados finais serão registrados ao concluir o gate local. Testes automatizados não substituem a avaliação de Valéria/Renato com seus leitores de tela nem o reteste no GLPIT 10.0.18.

O ZIP beta.13 anterior permanece preservado. Esta versão trata o achado de fornecedores registrado após a reorganização daquela versão.
