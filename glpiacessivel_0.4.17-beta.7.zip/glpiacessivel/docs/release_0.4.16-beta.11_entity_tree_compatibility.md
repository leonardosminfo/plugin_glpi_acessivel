# GLPI Acessível 0.4.16-beta.11 — compatibilidade da árvore de entidades

## Correção

A beta.10 detectava `Entity::getEntityTree()` somente com `method_exists()`. No GLPI 10.0.18 esse método existe, mas é privado. A tentativa de chamada externa gerava uma exceção, capturada pelo mecanismo de segurança, e o portal preservava apenas a entidade atual com a mensagem “Não foi possível carregar a lista de entidades”.

A beta.11 seleciona o construtor pela capacidade real de invocação:

1. usa `Entity::getEntityTree()` somente quando o método é público e invocável;
2. caso contrário, usa o adaptador público nativo `getTreeForItem()`;
3. se o alias global não estiver disponível, usa `DbUtils::getTreeForItem()` quando público;
4. se nenhum contrato nativo público estiver disponível, mantém a falha fechada já existente.

Não há SQL de entidades no plugin. A seleção continua sendo aplicada por `Session::changeActiveEntities()`, que permanece como autoridade de sessão e autorização.

## Escopo preservado

- nenhuma mudança na lista ou busca de chamados;
- nenhuma mudança em pesquisas salvas;
- nenhuma mudança em perfis, ACLs ou regras ITIL;
- nenhuma mudança em atores, soluções ou formulários;
- nenhuma migração de banco.

## Segurança e acessibilidade

O fallback nunca infere entidades por grupos nem acrescenta IDs fora das concessões do perfil ativo. Em erro, somente o contexto atual é mantido. Os caminhos hierárquicos e a indicação “inclui subentidades” continuam disponíveis quando o catálogo nativo é construído.
