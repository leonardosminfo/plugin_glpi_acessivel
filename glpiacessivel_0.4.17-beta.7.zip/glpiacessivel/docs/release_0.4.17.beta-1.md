# 0.4.17.beta-1

Runtime epoch: `20260917-01`. Identificador solicitado: `0.4.17.beta-1`.

Pacote cumulativo da beta.14 com interações recolhíveis e datas apresentadas conforme a preferência nativa do GLPI. A seção começa aberta; ações permanecem fora dela. Datas já formatadas não são reinterpretadas. Valores usados em banco, filtros, formulários e ordenação permanecem intactos. Nenhuma preferência ou conversão de fuso foi imposta.

Validação das alterações antes do pacote: 1196 testes PHP (7970 asserções), 19 testes de interface e comparação dos formatos 0/1/2 nas funções reais de GLPI 10.0.10 e 11.0.7. A beta.14 teve ainda 16 cenários de navegação por ambiente. Esses cenários não substituem novo aceite da versão em homologação, nem testes assistivos com os usuários.

Publicação aqui significa geração do ZIP local. Não implica envio ao GitHub, marketplace, homologação ou produção. Pacotes anteriores preservados.
