# 0.4.17-beta.5 — Solução de chamados e navegação acessível

Esta versão corrige o fluxo de solução sem substituir as regras do núcleo do GLPI. Campos obrigatórios de atores passam a considerar os vínculos nativos armazenados em `Ticket_User`, `Group_Ticket` e `Supplier_Ticket`, conforme o campo exigido pelo modelo. Requerentes anônimos continuam reconhecidos quando representados pelo e-mail alternativo nativo.

A descrição da solução é validada no servidor com mensagem associada ao campo. As transições para Solucionado e Fechado deixam o seletor genérico de status e são encaminhadas ao formulário Adicionar solução. Permissões, regras de transição, validação do modelo e gravação continuam delegadas às APIs nativas do GLPI 10 e 11.

O detalhe do chamado acrescenta o atalho Descrição do chamado e um retorno imediato aos Atalhos do chamado. Os destinos recebem foco programático sem interferir no alerta de resultado retornado pelo servidor.

## Verificação local antes do pacote

- GLPI 11.0.7 na porta 8080 e GLPI 10.0.10 na porta 8089.
- Relações nativas existentes de requerente e técnico verificadas em modo somente leitura nas duas versões.
- HTTP autenticado confirmou o atalho da descrição, o retorno, o destino focável e a ausência de Solucionado/Fechado no seletor genérico.
- PHPUnit: 1.221 testes e 8.107 asserções aprovados.
- Interface: 22 testes aprovados; auditoria i18n: 2.763 mensagens aprovadas.

Não há migração de esquema. A versão e o runtime epoch foram renovados para tornar a atualização identificável pelo GLPI e invalidar código ou ativos antigos ainda mantidos em cache. A homologação institucional e o aceite com leitor de tela permanecem necessários.
