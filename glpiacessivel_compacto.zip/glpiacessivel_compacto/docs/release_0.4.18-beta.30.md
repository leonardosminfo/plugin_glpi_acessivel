# GLPI Acessível 0.4.18-beta.30

Esta versão corrige o destino do foco ao paginar chamados depois de localizar uma pesquisa salva pelo nome. O pedido explícito de voltar aos resultados passa a prevalecer sobre a busca ou o cursor preservado do catálogo. A busca deliberada de pesquisas salvas continua levando ao resultado do catálogo.

## Escopo da correção

O ajuste é restrito à apresentação da lista. Não muda critérios, ordenação, paginação de dados, pesquisas padrão, APIs de consulta, permissões ou regras nativas. Não há SQL novo. A reprodução ocorreu no GLPI 10 durante os retestes de Técnico vazio; a mesma condição de apresentação é compartilhada com o GLPI 11.

As comparações autenticadas da beta.29 confirmaram os mesmos 26 chamados sem técnico em páginas 20 + 6 no 8089. No 8080, confirmaram Tag positiva, preservação ao salvar e reaplicar, combinações vazias e controle delimitado sem Tag. O problema identificado foi de foco, não de filtragem.

## Versão e limites

Marcadores: `0.4.18-beta.30`, epoch `20261027-08`. A atualização usa o fluxo nativo do GLPI, sem desinstalar ou mudar direitos. A beta.29 é preservada. O manual HTML 1.8 mantém os procedimentos e as figuras; a referência de cobertura acompanha esta versão, sem alteração das instruções.

Consulte os [testes e limites de validação](test_execution_0.4.18-beta.30.md) e o [quadro de estabilização](status_estabilizacao_2026-10-27.md). Os recortes aprovados não encerram toda a F4 nem substituem leitor de tela ou validação institucional.
