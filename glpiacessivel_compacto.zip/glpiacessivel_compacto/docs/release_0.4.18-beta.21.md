# Orientações didáticas do manual do GLPI Acessível

A versão 0.4.18-beta.21 acompanha o manual HTML 1.5, com instruções mais diretas para consultar a Ajuda, interpretar pesquisas e realizar as etapas de atendimento autorizadas no GLPI.

O percurso da Ajuda explica como fechar o diálogo antes de usar os controles visuais da página e como retomar a aba original. Os exemplos de pesquisa distinguem filtros em preparação, critérios aplicados, pesquisa salva e agrupamento lógico de estados, sem confundir esse agrupamento com uma equipe de atendimento.

O atendimento é organizado em procedimentos independentes. A figura de tarefa acompanha a criação de tarefa, antes do procedimento de solução. A visibilidade pública ou privada, o alcance dos participantes autorizados e a visibilidade dos documentos são explicados em texto, não apenas nas capturas.

A orientação de ação em massa identifica a confirmação, a execução, a revisão dos parâmetros e o cancelamento pelos nomes dos controles. O status Novo continua sendo apenas o valor do exemplo. Exercícios de treinamento orientam a revisão e o cancelamento seguro, sem pressupor autorização para gravar.

O manual contextual diferencia orientação para o contexto de autorização para operar em um chamado. O completo continua disponível para consulta sem habilitar funcionalidades. As sete imagens, as treze jornadas, os destinos dos capítulos e o crédito de elaboração são preservados; as legendas mantêm a versão real capturada.

A edição contextual, a completa e o HTML autônomo compartilham a mesma fonte. Não há SQL novo, alteração de permissões, novas regras de atendimento ou mudança no núcleo do GLPI. As configurações existentes de liberação permanecem independentes da leitura do manual.
