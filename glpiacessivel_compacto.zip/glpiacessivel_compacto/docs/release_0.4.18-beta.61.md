# 0.4.18-beta.61 — apresentação simples opcional

O detalhe do chamado pode oferecer os botões Simples e Completa. Completa continua sendo a apresentação inicial. A liberação administrativa usa o catálogo existente: desativado por padrão, perfis selecionados ou todos. A escolha individual não muda as funções autorizadas.

Simples recolhe somente dados complementares do resumo, contatos do requisitante e os formulários de alteração de responsáveis/status. Mantém descrição, observadores, navegação, documentos, etiquetas, interações e a ação em uso. Reutiliza as abas e os recolhimentos existentes, sem criar outro formulário ou importar o formulário convencional.

A preferência da conta usa as APIs nativas de configuração do GLPI em namespace separado. O endpoint deriva a conta da sessão, valida origem, CSRF e contrato limitado ao enum. Não recebe texto, anexos ou identificadores de conta do navegador. A confirmação da gravação exige leitura posterior pela API nativa.

Alternar a apresentação não recarrega a página, não envia o chamado, não recria editor/iframe e não limpa arquivos. Regiões com foco, rascunho, erro ou destino de âncora não ficam inacessíveis. Sem JavaScript, recurso desativado ou preferência indisponível, o conteúdo completo permanece utilizável.

Manual 3.9 contextual, completo e HTML autônomo: 48 assuntos e sete figuras, com instruções por tarefa sem pressupor experiência no GLPI. O modo simples desta entrega limita-se ao detalhe; lista e outras telas permanecem como antes.

Compatibilidade GLPI 10/11; sem SQL novo, esquema novo ou mudanças nas regras nativas. Epoch `20261106-06`. Ensaios assistivos com NVDA/JAWS e aceite institucional não são substituídos pelos testes automatizados.
