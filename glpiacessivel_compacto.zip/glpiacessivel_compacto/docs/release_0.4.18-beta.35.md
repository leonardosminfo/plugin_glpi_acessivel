# GLPI Acessível 0.4.18-beta.35

Esta versão corrige a sobreposição das ações de pesquisa avançada sobre o campo Valor, comprovada por Tab nos GLPI 11.0.7 e 10.0.10 locais a 1280 CSS pixels. Os mínimos dos campos e a coluna de ações não cabiam no espaço disponível dentro de grupos aninhados.

O ajuste CSS permite a reorganização dos campos e mantém os botões em linha própria, com quebra quando necessária. Não altera critérios, conectores, valores, regras globais, expressões de ordenação, DOM, JavaScript de produção ou processamento nativo. Não há SQL novo, mudança de permissão ou de regra do GLPI.

Versão 0.4.18-beta.35, epoch 20261028-05. Manual 1.8 com cobertura atualizada; procedimentos e figuras permanecem preservados. Pacotes anteriores não são reconstruídos.

Os resultados e limites da rodada estão em [Testes de teclado temas e manual](test_execution_0.4.18-beta.35.md). A correção passou no recorte autenticado dos dois ambientes; o plano completo de estabilização continua aberto.
