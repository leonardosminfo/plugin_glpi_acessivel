# GLPI Acessível 0.4.18-beta.38

Versão 0.4.18-beta.38, epoch `20261029-01`, manual 1.9. Ambientes de referência: GLPI 11.0.7 no 8080 e GLPI 10.0.10 no 8089. As adaptações passaram na validação local dos cenários registrados; o resultado não constitui certificação de acessibilidade ou aceite institucional.

## Escopo de apresentação

O Resumo do chamado ganha um único campo **Observadores**, distinguindo **Pessoa** e **Grupo** dentro do mesmo valor. Usa somente os atores já carregados e autorizados, sem expandir membros dos grupos ou buscar novos dados. Os nomes, seletores e resumos da edição de responsáveis e participantes permanecem inalterados.

Somente **Descrição do acompanhamento** recebe uma área inicial maior e os controles **Ampliar campo** e **Restaurar altura padrão**. O ajuste não altera texto, fonte, largura, privacidade, arquivos, modelos, tokens ou envio. Restaurar muda somente a altura: não limpa o acompanhamento. O mesmo textarea permanece editável, com rolagem e redimensionamento vertical nativo quando suportado. Sem JavaScript, os controles próprios ficam ocultos e o campo conserva sua altura inicial e edição.

Não se amplia esse tratamento para tarefa, solução, abertura, edição geral, edição de interação salva ou TinyMCE/iframe convencional. Não há novo editor rico, autogrow, autosave, preferência persistida, SQL, consulta de negócio ou mudança de permissão/regra nativa.

## Manual 1.9

J-07 orienta a leitura de pessoas e grupos no campo Observadores; J-08 explica a ampliação e a restauração da área de acompanhamento, inclusive por teclado e sem confundir altura com conteúdo ou envio. As edições contextual e completa partem da mesma fonte editorial. As sete figuras mantêm imagens, alternativas e versões reais de captura; não há recaptura fictícia. O HTML autônomo é exportado pelo procedimento oficial, mas exportar não equivale, por si só, a um novo aceite offline ou autenticado sem JavaScript.

## Testes e limites

O [plano delimitado](plano_observadores_resumo_altura_acompanhamento_2026-10-29.md) foi implementado e confrontado nos dois núcleos. O [relatório desta entrega](test_execution_0.4.18-beta.38.md) registra os recortes e seus limites:

- Resumo com pessoa e grupo nos chamados sintéticos autorizados, sem renomear os controles de edição.
- Área inicial próxima de 192 CSS px, crescimento por Enter/Espaço até o limite, restauração e retorno à edição, preservando o texto e o foco.
- Doze combinações de 320/1280 CSS px e temas claro, noturno e alto contraste, além de janela baixa. O arrasto nativo elevou a altura para aproximadamente 390 px nos dois ambientes; Ampliar não reduziu essa escolha acima do teto e Restaurar retornou a aproximadamente 192 px.
- Manual 1.9 nas quatro apresentações autenticadas: contextual/completo em GLPI 10/11. As orientações novas permaneceram disponíveis de acordo com o contexto; exportação autônoma não é operação offline de chamados.
- 96 testes proporcionais de navegador, incluindo 19 novos, e 2.472 testes/18.151 asserções em cada runtime de teste PHP 8.1.31 e 8.3.14. Subconjuntos não se somam novamente.

Os contextos autenticados usados estavam sem arquivos selecionados ou modelos elegíveis. Preservação de anexos pendentes, modelos e confirmações recebeu regressão isolada, não novo aceite autenticado integral desses percursos. Sem JavaScript, a alternativa de campo editável e controles ocultos foi verificada em fixture; não se afirma novo ensaio autenticado sem JavaScript. A saída real de leitor de tela e os anúncios assistivos permanecem pendentes.

Os ZIPs publicados anteriores permanecem preservados. As pendências gerais F1–F8, leitor real, texto a 200%, zoom real a 400% e validação institucional conservam suas classificações próprias; esta versão não as encerra por associação.
