# GLPI Acessível 0.4.18-beta.8

Correção do posicionamento dos botões flutuantes em páginas nativas com menu lateral do GLPI 10 e 11. As disposições e o tamanho escolhidos pelo administrador são preservados.

## Menu lateral e foco

Os acessos à esquerda passam a considerar a borda visível do menu, em vez de usar apenas a borda da janela. O cálculo acompanha abertura, recolhimento e mudanças de largura. Uma barra horizontal no topo não é tratada como menu lateral.

Na beta.6, a sobreposição com o controle do menu podia acionar o modo de segurança em fluxo. Isso explicava o portal aparecendo como link grande no conteúdo e o chatbot junto à borda inferior do documento. A beta.8 corrige a causa geométrica, inclusive durante a animação, quando o rótulo do controle pode ultrapassar a borda momentânea do menu. O modo em fluxo continua disponível quando realmente falta espaço ou há colisão persistente com o foco.

Não é necessário mudar a configuração do menu nativo. O ajuste não move os elementos do GLPI, não altera controles de terceiros e não muda a ordem relativa dos acessos.

## Atualização

Versão **0.4.18-beta.8**, runtime **20261018-03**. Atualize pelo ciclo nativo de plugins, sem desinstalar. Não há nova migração de esquema. O pacote beta.6 permanece preservado e não deve ser substituído silenciosamente por arquivos desta versão. A beta.7 foi usada somente como candidata de teste local; a nova numeração renova também a referência dos assets pelo mecanismo nativo do GLPI 10.

As verificações e os limites da validação estão no [relatório de testes da beta.8](test_execution_0.4.18-beta.8.md). Testes automatizados não substituem a avaliação manual com leitores de tela, zoom real e os widgets do ambiente de destino.
