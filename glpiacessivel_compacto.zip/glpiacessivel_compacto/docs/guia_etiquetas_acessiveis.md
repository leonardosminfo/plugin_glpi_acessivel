# Etiquetas nos chamados

## Alcance da integração

O GLPI Acessível pode apresentar, no detalhe e na listagem de chamados, as etiquetas mantidas pelo plugin oficial **Tag**, de `pluginsGLPI/tag`, e pesquisar uma etiqueta exata quando houver contrato compatível. Não cria outro cadastro, não copia vínculos e não substitui as permissões ou regras do GLPI.

A edição permanece na interface convencional, quando autorizada. Adicionar ou remover etiquetas dentro do portal acessível, ordenar pela coluna de etiquetas e alterar etiquetas em massa não fazem parte desta entrega.

## Ativar

1. Confirme com a administração que o Tag está ativo, atualizado e compatível com o GLPI instalado. O pacote do GLPI Acessível não inclui nem instala o Tag.
2. Abra **Liberação de funcionalidades** na configuração do GLPI Acessível.
3. Libere **Visualizar etiquetas nos chamados** para os perfis do piloto ou para todos os usuários já autorizados.
4. Se desejar a continuação convencional, libere também **Acesso à edição nativa de etiquetas**.
5. Para a listagem, libere separadamente **Etiquetas na listagem de chamados** e/ou **Filtrar chamados por etiqueta**. Uma não exige a outra, nem a leitura no detalhe.
6. Revise e confirme. As opções novas começam desativadas; as escolhas anteriores são preservadas.

A liberação usa o perfil ativo e nunca concede direitos nativos. O link de edição exige também acesso de atualização ao chamado e direito de atualização das etiquetas. Sua disponibilidade não garante que toda etiqueta possa ser associada: a interface convencional continua aplicando suas próprias validações.

## Consultar

Abra um chamado autorizado e use o atalho **Etiquetas do chamado**, quando disponível. A seção apresenta uma lista textual de vínculos diretos. Etiquetas da entidade não são confundidas com etiquetas do chamado. Nomes iguais são diferenciados pelo identificador.

A cor de fundo válida é preservada exatamente em termos de valor RGB. O texto é preto ou branco, escolhendo o maior contraste calculado. Assim, a cor continua sendo uma referência visual, mas não é a única forma de identificar a etiqueta. Nomes longos quebram linha, sem serem cortados. Em cores forçadas, prevalecem as cores do sistema. Cor ausente ou inválida usa apresentação neutra e aviso textual, sem inventar uma cor de categoria.

Se houver um link para gerenciar etiquetas, ele abre o chamado convencional na mesma aba. Use os controles nativos e o retorno do navegador. O portal não automatiza nem replica essa gravação.

## Usar a coluna e o filtro

Na listagem, abra a seleção de colunas, marque **Etiquetas** e aplique. A coluna não vem selecionada por padrão e não oferece ordenação. Cada célula distingue **Sem etiquetas**, quando a ausência foi comprovada, de **Etiquetas indisponíveis**, quando a leitura não pôde ser concluída. Uma falha somente na coluna preserva os chamados, a ordem e a paginação. A leitura usa até dois lotes públicos para a página autorizada, sem consulta adicional por chamado.

Nos filtros, use **Etiqueta** para procurar e selecionar um valor pelo nome. A seleção identifica a etiqueta pelo ID nativo; digitar não aplica o filtro. Acione **Pesquisar** para consultar os chamados vinculados à etiqueta escolhida. Use o controle de limpeza e depois **Pesquisar** para retirar esse critério. O filtro funciona mesmo com a coluna desligada.

O resumo da pesquisa informa a etiqueta aplicada. A escolha acompanha paginação, ordenação e estado da pesquisa. Quando uma pesquisa salva ou avançada contiver uma expressão que não possa ser representada por uma única seleção, a interface indica que o filtro está definido na pesquisa avançada ou nativa; não reduz grupos complexos a um único valor.

Nesta etapa, somente a igualdade por uma etiqueta possui contrato liberado. Não há filtro simplificado de várias etiquetas, desigualdade ou ordenação por etiqueta. Se a dependência ou a liberação ficar indisponível em uma pesquisa que depende de etiqueta, a execução afetada é bloqueada: o critério não é descartado para mostrar resultados mais amplos. Retire ou ajuste o critério explicitamente para realizar outra consulta.

## Ausência e falhas

- Integração desativada, Tag ausente/inativo ou falta de acesso: a seção não é oferecida.
- Combinação não suportada ou falha da consulta: a seção informa indisponibilidade. Isso não significa ausência de etiquetas.
- Consulta concluída sem vínculos: a seção informa que não há etiquetas vinculadas.

Os demais blocos do chamado permanecem disponíveis quando a falha está na fronteira da integração. O plugin não consegue recuperar um erro fatal de terceiros ocorrido antes de o portal iniciar.

Consultas com mais de cem etiquetas por chamado não são apresentadas parcialmente. A listagem aceita até cinquenta chamados por lote, mil associações e 256 KiB de textos de etiquetas na página. Acima desses limites, a coluna informa indisponibilidade. Esses limites são conferidos no retorno; não limitam o trabalho interno da Search API nem alteram o cadastro nativo.

## Compatibilidade e segurança

O adaptador reconhece os contratos de Tag 2.14.8 com GLPI 11.0.1–11.0.98 e Tag 2.12.6 com GLPI 10.0.11–10.0.98. Reconhecimento técnico não é recomendação de instalação nem certificação: os requisitos nativos, os avisos de segurança e a homologação do pacote real continuam obrigatórios. Outras versões ficam indisponíveis até validação.

A coluna em lote está habilitada somente para o contrato Tag 2.14.8. O formatador do Tag 2.12.6 realiza leituras individuais internamente; por isso, a coluna permanece indisponível nessa combinação para preservar o requisito de não consultar por linha. O contrato de filtro dessa versão é reconhecido separadamente, mas não possui homologação integrada ativa no ambiente local GLPI 10.

A homologação integrada da leitura e do filtro usa GLPI 11.0.7 com Tag 2.14.8. O ambiente local GLPI 10.0.10 não atende ao mínimo do Tag 2.12.6. Posteriormente, o Tag 2.12.2 foi instalado nesse ambiente apenas para testes autorizados; a abertura do gerenciamento convencional não homologa seu contrato com o portal, que ainda não reconhece essa versão. O [aviso oficial GHSA-6rpj-89c7-x2mh](https://github.com/pluginsGLPI/tag/security/advisories/GHSA-6rpj-89c7-x2mh) abrange versões antigas e indica correção na linha GLPI 11. A integração ativa no GLPI 10 permanece pendente de combinação segura e homologação específica; a instalação local não é recomendação de uso em produção.

Antes de ampliar o piloto, confirme o contraste, a navegação por teclado, o leitor de tela e as restrições de entidades/perfis da instalação. Testes automatizados não certificam conformidade integral com WCAG, eMAG ou RGAA.
