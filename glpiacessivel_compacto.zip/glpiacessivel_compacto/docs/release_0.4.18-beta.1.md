# GLPI Acessível 0.4.18-beta.1

Data: 09/10/2026. Entrega de correções de compatibilidade da etapa A e prova do executor nativo da etapa B do plano aprovado. Não representa a conclusão de todo o plano.

## Correções entregues

O nome salvo do chatbot passa a ser preservado, inclusive “TiAjuda”. O padrão é utilizado somente quando o campo estiver ausente ou vazio. Permanecem a sanitização, o limite de caracteres e o escape da apresentação.

Os três endpoints de consulta — resultados de chamados, seletores remotos e modelos — utilizam a mesma política de origem. Protocolo, hostname e porta efetiva são comparados de forma consistente, inclusive portas padrão e IPv6. Origem indevida ou malformada continua bloqueada. Sessão, CSRF, perfil, contexto e permissões continuam obrigatórios em seus fluxos existentes.

A política não confia automaticamente em `Forwarded` ou `X-Forwarded-*` e não altera a configuração global do GLPI/Symfony. Atrás de proxy, o servidor deve apresentar host e HTTPS normalizados por uma cadeia confiável. HTTPS externo com HTTP interno não normalizado continua sendo rejeitado. Hostnames não convencionais com underscore deixam de ser aceitos pela política. Nenhuma promessa de correção do ambiente TRF/OpenShift decorre dos testes locais.

O catálogo de entidades mantém o contexto recursivo já ativo de uma entidade folha quando aceito pelo núcleo. Isso não oferece recursividade para outras folhas nem cria uma lista alternativa de entidades. As falhas do catálogo são classificadas por motivos internos conhecidos; exceções nativas desconhecidas recebem uma mensagem genérica.

## Compatibilidade e atualização

- Validado localmente com GLPI 10.0.10 em 8089 e GLPI 11.0.7 em 8080; os requisitos próprios de PHP de cada GLPI continuam aplicáveis.
- Versão: `0.4.18-beta.1`. Runtime epoch: `20261009-01`, sincronizado em setup, bootstrap e controle de esquema.
- Nenhuma alteração em arquivos do núcleo, regra ITIL, ACL, semântica de status ou esquema de banco.
- Atualizar os arquivos do plugin e executar o fluxo nativo de atualização do GLPI; preservar configurações e dados. Não desinstalar o plugin como procedimento de atualização.
- O pacote não contém credenciais, certificados de teste, ferramentas de QA ou dependências de desenvolvimento.

## Ações em massa e pendências

A prova executou uma mudança de status em chamados exclusivamente sintéticos usando `MassiveAction::process` nas duas versões. A interface de ações em massa do portal não foi adicionada: os contratos de formulários diferem e os gates HTTP/CSRF, teclado, foco, leitor de tela, resultados parciais e recuperação segura ainda não foram concluídos. Detalhes em `acoes_massa_prova_0.4.18-beta.1.md`.

Também permanecem pendentes a homologação real no OpenShift, o diagnóstico operacional restrito dos motivos de origem e a avaliação manual assistiva. A regressão do detalhe confirmou sobreposições parciais preexistentes do botão flutuante, registradas no relatório de execução para revisão posterior. A mensagem de origem é orientativa e não divulga cabeçalhos, cookies ou tokens. Não há certificação de conformidade integral WCAG, eMAG ou RGAA nesta entrega.

## Evidências e reversão

O relatório `test_execution_0.4.18-beta.1.md` distingue testes concluídos e pendências. Antes da implantação local foram preservadas cópias da versão anterior em `deployment_backups/0.4.18-beta.1-20261009`. Como não há migração de esquema neste ciclo, a reversão consiste em restaurar o pacote anterior e conferir sua versão/estado pelo fluxo nativo; não exige exclusão de dados.
