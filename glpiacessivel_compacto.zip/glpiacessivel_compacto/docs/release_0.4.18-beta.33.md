# GLPI Acessível 0.4.18-beta.33

Esta versão completa a correção de apresentação do seletor de anexos da beta.32. O CSS genérico dos botões sobrepunha o atributo hidden do controle Limpar anexos: mesmo com o seletor e as listas vazios, o botão permanecia visível. A divergência foi comprovada no GLPI local pela apresentação e pelo estilo efetivo.

Uma regra restrita a esse controle faz o atributo hidden voltar a determinar sua ocultação. Selecionar arquivos torna o botão disponível; limpar oculta o controle e mantém o foco no seletor. Não foi criada regra global para todos os elementos hidden.

A sincronização das listas da beta.32 permanece. Não há novo SQL, mudança de processamento de upload, formulários de negócio, limites, permissões ou regras nativas. Os pacotes beta.31 e beta.32 são preservados.

Versão 0.4.18-beta.33, epoch 20261028-03. Manual contextual/completo/autônomo 1.8 com cobertura atualizada, procedimentos e figuras preservados. Os [testes F7/F8](test_execution_0.4.18-beta.33.md) delimitam o aceite local e os [ensaios ainda pendentes](status_estabilizacao_pos_beta33_2026-10-28.md).
