# GLPI Acessível 0.4.18-beta.14

## Novidades

- Consulta acessível de quatro contagens calculadas pelas APIs públicas nativas do GLPI, por técnico atribuído e período, com entrada no Cockpit.
- Controle independente `reports.cockpit_statistics`, inicialmente desativado, com liberação para perfis selecionados ou todos os usuários já autorizados. As dez escolhas anteriores são preservadas.
- Mensagens específicas para recusas de varredura e revisão editorial em lote, sem transformar indisponibilidade de política em falha técnica ou perder resultados de operações anteriores.

Os cinco indicadores atuais do Cockpit continuam preservados. Abrir o Cockpit e o formulário não executa estatísticas. A consulta ocorre após envio explícito e usa o contexto e o direito nativos, sem modificar preferências ou pesquisas salvas.

## Limites

A apresentação adaptada não reproduz o relatório completo: não inclui médias, tempos, satisfação, gráficos, exportação própria ou totais recalculados. Tarefas permanecem na interface convencional por diferença semântica entre núcleos. Os links convencionais continuam sujeitos ao controle independente e às permissões nativas; a localização anterior na lista é mantida durante esta etapa de homologação.

Não há SQL novo, acesso direto ao banco nessa integração ou alteração de fórmula, esquema ou núcleo. O adaptador usa `Stat::getItems()` e `Stat::getData()` no mesmo processo PHP. Retornos incompatíveis não viram zeros ou resultados parciais. O limite nativo de listagem é respeitado entre 1 e 100; valores especiais ou maiores são recusados sem alterar a preferência.

Uma configuração desativada impede novas requisições, mas não cancela uma consulta síncrona já iniciada. Avaliação assistiva com usuários, critérios locais de desempenho e homologação institucional continuam necessários antes de ampliar a liberação.

## Atualização e operação

Atualize pelos procedimentos nativos sem desinstalar. A nova opção começa desativada mesmo que as dez anteriores estejam liberadas. A administração poderá revisar e escolher o público depois da homologação. As melhorias das mensagens são permanentes e não possuem botão para desligamento.

Consulte o [guia de liberação](guia_liberacao_funcionalidades.md), o [guia de uso das estatísticas](guia_estatisticas_acessiveis.md) e o [registro dos testes](test_execution_0.4.18-beta.14.md).
