# Versão 0.4.18-beta.44

Entrega com manual 2.5 e epoch `20261029-07`. O encaminhamento continua pelo núcleo, com os hooks oficiais do Escalade. O manual contextual, o completo e o HTML autônomo usam a mesma fonte editorial.

## Atribuição nativa e compatibilidade

| Frente | Implementação |
| --- | --- |
| Resultado dos hooks | Reconhece o ajuste subtrativo delimitado de responsáveis nas combinações verificadas, sem rejeitar e repor atores retirados legitimamente. Exige o grupo novo persistido e recusa atores extras ou alterações indevidas nos demais papéis. |
| Histórico do GLPI 10 | Mantém inclusão e remoção do grupo no mesmo comando nativo para preservar a origem registrada pelo Escalade. |
| Destinos autorizados | Usa a API nativa de atores, com filtros, template e entidade, também na pesquisa e validação exata de novos grupos. Grupos atuais permanecem legíveis e removíveis. |
| Contrato IDOR | Replica o token oficial do seletor até GLPI 10.0.12 e a partir de 10.0.13/11, sem fallback para contornar validação. |
| Resultado acessível | Informa quando as regras nativas ajustaram os responsáveis e orienta conferir o estado final. Mantém seleção por teclado, confirmação e região de estado existentes. |

Os ensaios locais usaram GLPI 11.0.7 com Escalade 2.10.8 no 8080 e GLPI 10.0.10 com Escalade 2.9.4 no 8089. A versão histórica 2.9.4 serve ao teste local autorizado, não à recomendação de implantação institucional. Não houve atualização do núcleo, SQL novo no GLPI Acessível, cópia da matriz do Escalade ou redisparo manual de hooks.

## Orientação de encaminhamento

J-08 passa a explicar que incluir um grupo técnico como novo responsável pelo chamado pode acionar regras do Escalade quando a extensão estiver ativa e configurada para essa operação. O texto distingue esse grupo de um grupo observador ou do grupo de uma tarefa e recomenda conferir responsáveis, status e histórico antes de repetir uma operação incerta.

O item correspondente em Limites reconhece esses efeitos possíveis sem presumir que todo salvamento equivale ao botão Escalar. Em participantes em massa, a orientação deixa de negar genericamente regras automáticas de extensões e mantém a distinção entre adicionar participantes e executar um botão dedicado de outro plugin.

Os 45 assuntos, as sete figuras, os créditos e os destinos de navegação são preservados. Esta orientação não cria uma liberação adicional nem um executor direto do Escalade. Não promete suporte universal a versões, configurações ou fluxos institucionais.

## Validação e distribuição

Os resultados da instalação, das comparações por API, do fluxo real no navegador e dos testes negativos estão em [Execução da beta.44](test_execution_0.4.18-beta.44.md). O [plano atualizado](plano_integracao_escalade_glpi10_11_2026-10-29.md) separa o escopo verificado das combinações que exigem homologação própria. Os pacotes Escalade não são incorporados ao ZIP do GLPI Acessível.

O verificador de pacote exige manual 2.5, epoch `20261029-07`, documentos desta entrega e orientação condicional de Escalade, preservando os gates anteriores e o mapeamento 43→2.4. A beta.43 e seu HTML 2.4 permanecem preservados.

Leitor de tela real, piloto com usuários, impressão física e aceite institucional continuam separados da inspeção estrutural e das suítes automatizadas. Não há declaração de certificação WCAG, eMAG ou RGAA.
