# Versão 0.4.18-beta.41

O manual HTML 2.2 torna as orientações mais diretas para pessoas sem conhecimento prévio do GLPI. A revisão preserva o manual contextual, o completo e a referência autônoma, com os mesmos 45 assuntos, sete figuras e destinos de navegação.

## Alterações editoriais

- Distingue os controles da edição integrada das orientações da edição autônoma. O manual autônomo já está completo e não exige um botão para abrir outra apresentação.
- Explica os efeitos práticos de condições de uso em etiquetas, estatísticas, curadoria e administração, substituindo termos internos de engenharia sem remover as condições necessárias.
- Mantém as orientações de ajuda e suporte, evitando observações de homologação no percurso de uso.
- Informa onde acessar as estatísticas atualmente, sem descrever a posição de blocos de versões anteriores.
- Orienta a pessoa a conferir mensagens e resultados das ações, em vez de apresentar requisitos de implementação dos anúncios.
- Organiza a orientação comum de teclado, rascunho e anexos no acompanhamento, preservando o público/privado, o envio e o cancelamento de cada operação separadamente.

## Compatibilidade e limites

Esta entrega altera conteúdo editorial e metadados. Não muda o renderizador do manual, o catálogo contextual, o controlador integrado, JavaScript, CSS, consultas ou operações de atendimento. Não acrescenta SQL nem modifica permissões ou regras nativas. Mantém compatibilidade com GLPI 10 e 11.

As instruções não concedem acesso nem habilitam funcionalidades. Leitura com leitor de tela real, avaliação didática com usuários iniciantes, impressão física e aceite institucional continuam sendo validações próprias. Testes automatizados e mídia CSS de impressão não substituem esses ensaios. Os resultados da beta.40 não são apresentados como retestes da beta.41.

## Verificação e distribuição

Os resultados desta entrega estão em [Execução dos testes da beta.41](test_execution_0.4.18-beta.41.md). O verificador exige o manual 2.2, o epoch `20261029-04` e os documentos desta versão, mantendo os gates cumulativos e os mapeamentos históricos 39→2.0 e 40→2.1.

- A suíte PHP aprovou 2.498 testes e 18.620 asserções em cada runtime, PHP 8.1.31 e 8.3.14. Esses resultados não são somados entre runtimes nem duplicados com os subconjuntos proporcionais.
- Foram aprovados 47 testes distintos de navegador: 43 do manual e quatro da edição autônoma. Resultados de rodadas anteriores não entram nessa contagem.
- Quatro comparações autenticadas, contextual e completa nos dois GLPI locais, preservaram estados, avisos, presença dos procedimentos, sumário e contexto entre as versões 40 e 41. No GLPI 10, o perfil Self-Service na entidade raiz apresentou 25 assuntos no sumário contextual e 45 no completo, com um estado não confirmado. No GLPI 11, o perfil sintético de teste no escopo de todas as entidades apresentou 26/45 assuntos, com dois estados não confirmados. Não houve troca de perfil, entidade ou configuração para essas comparações.
- O novo texto de ajuda foi observado na apresentação integrada. Na leitura completa do GLPI 10, os jargões e históricos substituídos não foram encontrados.
- A comparação da fonte aprovou oito verificações, preservando 279 arquivos protegidos, 39 ativos de voz, a estrutura das 45 seções, as sete figuras byte a byte e os créditos. O conteúdo editorial de 12 seções foi revisado. A auditoria gettext aprovou 3.340 mensagens; somente os cabeçalhos de versão e os catálogos compilados foram atualizados.
- A edição autônoma 2.2 tem 531.602 bytes e SHA-256 `c601793b48b1b2d6de52edc122f7f9a76194c5b0a27bc4c12d404b363eef394a`.

A distribuição deve preservar o ZIP da beta.40 e seu HTML autônomo 2.1. A geração e a conferência do novo pacote são etapas separadas dos testes de fonte.
