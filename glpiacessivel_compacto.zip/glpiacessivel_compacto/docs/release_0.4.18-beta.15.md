# GLPI Acessível 0.4.18-beta.15

## Correção dos atalhos nas estatísticas

As âncoras do resultado estatístico e da entrada no Cockpit passam a direcionar o foco ao título, em vez do cartão inteiro. Isso evita que um resultado extenso acione indevidamente o modo em fluxo e expanda o botão do chatbot.

Os endereços existentes de consulta, paginação e retorno são preservados. A navegação por fragmento funciona também sem JavaScript. O foco continua visível no título e a região de rolagem da tabela permanece acessível por teclado.

## Comportamentos preservados

A proteção geral contra sobreposição de controles não foi desativada. Quando realmente faltar espaço, o modo em fluxo continua disponível. Permanecem os layouts independentes e empilhados dos botões, o afastamento dos menus nativos e os cálculos, permissões e opções de liberação das estatísticas.

Não há SQL novo, migração estrutural, mudança de regra nativa ou alteração das escolhas administrativas. Atualize sem desinstalar, pelos procedimentos nativos do GLPI. O marcador de runtime é `20261019-06`.

Consulte o [registro dos testes](test_execution_0.4.18-beta.15.md).
