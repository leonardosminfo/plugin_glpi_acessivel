# 0.4.18-beta.59 — editor nativo no formulário do portal

Entrega de 06/11/2026. Compatibilidade: GLPI 10 e 11. Manual 3.7; runtime epoch `20261106-04`.

## Correção

A inclusão e a edição formatadas de acompanhamentos e tarefas não importam mais o formulário completo do GLPI. O portal mantém seus formulários, navegação, modelos, visibilidade e botões. Somente o editor e o seletor de arquivos são fornecidos pelos helpers públicos do núcleo.

- Na edição, texto, imagens e visibilidade usam um formulário próprio, com retorno à interação no portal.
- Na inclusão no chamado, os campos complementares da tarefa e os modelos já oferecidos pelo portal permanecem disponíveis.
- O editor recebe o HTML autorizado sem a projeção textual que oculta formatação. O salvamento usa os objetos nativos, com verificação de contexto, permissões, concorrência, CSRF e liberação do recurso.
- O anexo continua opcional. Arquivos temporários do uploader nativo têm identidade capturada no servidor e confirmação do vínculo final por APIs existentes. A permanência de um temporário após deduplicação não é interpretada como falha.
- A aplicação de modelos sincroniza o editor visual e protege o rascunho existente. Rótulos próprios e ajuda são associados ao editor sem duplicação.
- Retirar uma imagem do texto não apaga o documento. As operações sobre vínculos continuam separadas e sujeitas ao núcleo.

As liberações de inclusão e edição formatadas continuam independentes. Nenhuma permissão nativa é ampliada. Não há SQL novo, migração estrutural ou mudança de regra operacional do núcleo.

## Documentação e limites

Manual contextual, completo e HTML autônomo atualizados para 3.7, mantendo 47 assuntos, sete figuras e os créditos existentes. A edição desta tela não promete alterar estado, duração, planejamento ou responsáveis da tarefa: seu escopo é texto, imagens e visibilidade autorizada.

Resultados e limites dos ensaios constam em `test_execution_0.4.18-beta.59.md`. Verificações automatizadas e navegação de QA não substituem o ensaio com NVDA/JAWS nem a homologação institucional.
