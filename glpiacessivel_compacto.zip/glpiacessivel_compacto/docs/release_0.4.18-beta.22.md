# Avaliação de solução e exercícios do manual do GLPI Acessível

A versão 0.4.18-beta.22 acompanha o manual HTML 1.6. A jornada J-09 apresenta aprovação e recusa como caminhos independentes, com listas de passos próprias. Na recusa, o preenchimento de Comentário sobre a decisão e a escolha de anexos opcionais antecedem Recusar solução. A revisão permite confirmar Recusar e reabrir ou cancelar sem executar a decisão.

O exercício de pesquisa não exige uma pesquisa salva chamada N1 nem uma segunda página de resultados. Essas etapas são condicionais à existência de dados de treinamento autorizados. Conferir filtros e resumo continua sendo possível sem essas opções.

A orientação contextual explica a diferença entre o sumário priorizado e a navegação pelos títulos, que também encontra avisos resumidos de outros assuntos. Os destinos permanecem estáveis e o manual completo continua acessível sem alterar direitos ou liberar funcionalidades.

As edições contextual, completa e autônoma usam a mesma fonte editorial. As sete figuras, suas alternativas textuais, as legendas com a versão realmente capturada e o crédito de elaboração são preservados. Não há SQL novo, alteração de permissões, novas regras de atendimento ou mudança no núcleo dos GLPI 10 e 11.

Atualize pelo ciclo nativo de plugins, sem desinstalação. Consulte o relatório de testes desta versão para o alcance da homologação local e os limites assistivos e institucionais.
