# GLPI Acessível 0.4.18-beta.32

Esta versão corrige a lista de anexos pendentes do acompanhamento e da tarefa. Com a colagem de imagens disponível, Limpar anexos esvaziava o seletor, mas os nomes e botões da lista adicional continuavam visíveis. O problema foi reproduzido na interface autenticada do GLPI 11 local.

## Correção

O inicializador dos seletores no detalhe do chamado emite o evento change após limpar o campo. As listas convencional e de colagem recebem o mesmo estado. A mensagem final continua Seleção de anexos limpa e o foco retorna ao seletor; texto, privacidade, modelo e outros formulários permanecem independentes.

O ajuste não envia arquivos, não acumula escolhas, não altera o formulário de criação e não muda upload multipart, banco, consultas, permissões, hooks, validações ou regras nativas. Não há SQL novo. A disponibilidade da colagem continua controlada pela liberação existente.

## Versão e manual

Versão 0.4.18-beta.32, epoch 20261028-02. A beta.31 publicada é preservada. O manual HTML 1.8 contextual, completo e autônomo mantém os procedimentos, imagens e suas versões reais de captura; a referência de cobertura acompanha esta entrega.

Consulte os [testes F7 e F8](test_execution_0.4.18-beta.32.md) para os resultados nos dois núcleos e as variantes ainda pendentes. O ajuste não encerra o diálogo real de arquivos do sistema, zoom nativo, leitor de tela ou a homologação institucional.
