# GLPI Acessível 0.4.18-beta.25

Esta versão corrige a recusa de criação de pesquisa privada a partir de uma busca aplicada. A causa estava no contrato interno de apresentação do plugin, antes da chamada de inclusão da pesquisa pelo GLPI, e não em uma regra nativa de privacidade.

## Correção

A listagem já produzia estados com `status`, `group_id` e `tag_id`, inclusive quando nenhuma etiqueta estava selecionada. O salvamento ainda aceitava apenas os dois primeiros campos e também rejeitava o valor de pesquisa `open`, usado por Não solucionados. Assim, uma pesquisa executável era recusada antes de chegar à API nativa de SavedSearch.

Os dois controladores agora usam o mesmo validador estrito. Ele mantém o formato antigo de dois campos, aceita o formato atual e valida tipos, campos conhecidos e limites de etiqueta. A definição de critérios já compilada não é reconstruída nem alterada por essa validação.

| Frente | Entrega |
| --- | --- |
| F4 Pesquisas privadas | Criação a partir de estado aplicado corrigida, com pesquisa privada persistida e reaberta no GLPI 10 e 11. |
| Compatibilidade | Contrato compartilhado para estado antigo e atual, Não solucionados e metadados de etiqueta, sem nova chamada nativa. |
| Regressão | Testes de ida e volta entre produtor, armazenamento do estado e leitor, incluindo contexto diferente e entradas inválidas. |
| Manual | Manual HTML 1.8 contextual, completo e autônomo com referência à beta.25; procedimentos e sete figuras preservados. |

## Atualização

Atualize pelos arquivos e pelo fluxo nativo do plugin, sem desinstalar. Confira código e cadastro `0.4.18-beta.25` e runtime epoch `20261027-03`. A beta.24 foi preservada com SHA-256 `48243a41ec60de66fdda9d0707933164d6be8aaa09f7f4144310b76ee64f03b1`.

Não há SQL novo, migração estrutural, alteração nas regras do núcleo, ampliação de permissões ou de funcionalidades liberadas. A inclusão continua usando SavedSearch e seus verificadores públicos nativos. A pesquisa padrão somente pode mudar quando essa opção for explicitamente solicitada.

## Limites

Esta entrega encerra a falha de criação identificada na F4, não toda a matriz de estabilização. Permanecem os demais casos de transporte/BFCache, concorrência ampliada, pesquisas e contextos institucionais, acessibilidade assistiva real, desempenho e reversão descritos no relatório anterior. Preservar o rascunho após outros erros de criação continua uma melhoria separada, sem reenvio automático.

Os resultados e o escopo dos testes estão em `test_execution_0.4.18-beta.25.md`.
