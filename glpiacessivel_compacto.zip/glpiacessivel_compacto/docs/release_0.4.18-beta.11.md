# GLPI Acessível 0.4.18-beta.11

Correção do menu superior responsivo e melhoria de acesso às estatísticas convencionais. Runtime 20261019-02. Atualize pelo ciclo nativo do GLPI, sem desinstalar.

## Atalhos flutuantes

- Menu superior expandido deixa de ser confundido com duas laterais, corrigindo a transformação indevida dos ícones em links no conteúdo.
- Menu lateral aberto, recolhido e em animação conserva seu afastamento.
- Configurações de lados, empilhamento e tamanhos permanecem preservadas.
- Proteções para falta de espaço, menu cobrindo os atalhos, foco encoberto e diálogos continuam ativas. O modo em fluxo legítimo não é reiniciado indiscriminadamente.

## Estatísticas

- O bloco passa a se chamar Estatísticas na interface convencional, com nomes de links que identificam o destino.
- Orientação informa abertura em tabela e na mesma aba, alcance dos dados e retorno pelo navegador.
- No retorno por histórico, o bloco reabre e o foco volta ao link de origem quando o navegador e o estado atual permitem, sem alterar a URL ou copiar filtros e tokens para armazenamento persistente.
- O acesso sem JavaScript continua sendo um link convencional. Permissões, contexto, parâmetros de cada versão e verificação nativa no destino permanecem inalterados.

Consulte o [relatório consolidado](relatorio_consolidado_menu_estatisticas_2026-10-19.md) e os [testes da revisão](test_execution_0.4.18-beta.11.md). A revisão não certifica a acessibilidade integral da interface nativa de estatísticas.
