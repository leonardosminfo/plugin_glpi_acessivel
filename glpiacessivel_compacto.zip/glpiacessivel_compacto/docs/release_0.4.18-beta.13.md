# GLPI Acessível 0.4.18-beta.13

Corrige a expansão indevida do atalho flutuante do chatbot ao abrir a revisão de liberação de funcionalidades.

O foco inicial passa ao título da revisão, em vez de abranger toda a seção. Revisões extensas deixam de ser interpretadas como um controle encoberto pelo atalho. O título permanece programaticamente focalizável, e os botões Confirmar liberação e Voltar para editar continuam no percurso normal do teclado.

A proteção geral contra sobreposição, o modo de segurança para janelas pequenas, os layouts laterais e empilhados e o nome configurado do chatbot não foram alterados. Não há mudança nas permissões, no salvamento, nas APIs de negócio ou no SQL.

Compatível com GLPI 10 e 11. Runtime: `20261019-04`. Atualize pelo ciclo nativo de plugins, sem desinstalar. As escolhas de liberação já gravadas são preservadas.
