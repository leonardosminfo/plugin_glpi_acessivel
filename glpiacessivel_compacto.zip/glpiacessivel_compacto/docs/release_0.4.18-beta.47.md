# Acesso aos controles nativos e lote enxuto de estabilização

Versão 0.4.18-beta.47, epoch `20261029-10`, de 29/10/2026. Corrige a sobreposição comprovada do ícone do portal sobre Salvar na interface convencional. Os [resultados desta rodada](test_execution_0.4.18-beta.47.md) distinguem testes isolados, percursos autenticados e pré-condições ainda pendentes.

## Posicionamento seguro dos acessos

O posicionamento verifica se um acesso flutuante encobre um controle visível antes de esse controle receber foco. Quando necessário, os acessos passam ao modo em fluxo da página já existente. Não se altera o botão Salvar do GLPI, não se redireciona o clique para outro alvo e não se reduzem camadas nativas para esconder o problema.

A verificação é limitada à área pintada dos acessos e agendada por quadro em eventos pertinentes, incluindo rolagem. Acesso em fluxo permanece estável, sem alternar repetidamente com o posicionamento fixo. URLs, elementos, rótulos e comportamento de teclado dos acessos são preservados; os controles do formulário não são recriados ou deslocados pelo plugin.

Layouts sem colisão mantêm a configuração escolhida. A correção não exige alterar permissões, modelos, a matriz Escalade ou regras de atribuição, status e anexos.

Regiões de tabela preparadas para rolagem por teclado também são áreas interativas. Se um acesso encobrir essa região, a apresentação em fluxo pode ser aplicada; não se promete manter um ícone fixo sobre uma tabela longa. O simples foco em um título não deve provocar essa mudança, e o foco no destino da navegação é preservado.

## Escopo da entrega

O lote abrange a obstrução do Salvar, a revisão de atribuição com rascunho/arquivo e as negativas de contexto disponíveis. A matriz de limpeza do Escalade já aprovada não é reaberta como lacuna. Somente a correção comprovada de apresentação motivou esta nova versão.

O manual continua na edição 2.7, com cobertura atualizada para a beta.47, 45 capítulos e sete figuras. Sua fonte editorial e instruções de negócio não mudam. As edições contextual, completa e autônoma continuam usando a mesma fonte.

Mantêm-se GLPI 10/11, sem SQL novo, migração estrutural ou mudanças nos códigos/regras nativos. A validação institucional e os ensaios assistivos não executados continuam separados. Os pacotes anteriores não são substituídos retroativamente.
