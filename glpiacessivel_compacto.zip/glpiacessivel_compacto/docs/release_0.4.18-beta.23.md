# GLPI Acessível 0.4.18-beta.23 — estabilização

Entrega restrita à estabilização aprovada, compatível com os contratos inspecionados do GLPI 10 e 11. Não acrescenta SQL, migração estrutural ou regra de negócio ao núcleo. As quinze liberações de funcionalidades existentes permanecem inalteradas.

| Frente e origem | Implementação nesta versão | Limite de aceite |
| --- | --- | --- |
| F0 — preparação | Baseline do pacote beta.22, versões locais, configurações e testes sintéticos isolados | Nenhuma gravação institucional |
| F1 — D01/D02, confirmação | Mensagens de recuperação distintas para confirmação ausente, expirada, indisponível e incompatível com o contexto; mantém prazo, confirmação explícita e uso único | A falha institucional não foi reproduzida com formulário novo; não se declara sua causa resolvida |
| F2 — C14, edição | Readback estrito da descrição bruta, preservando espaços e linhas; divergência ou exceção após tentativa permanece inconclusiva; uma única atualização nativa | Não oferece normalização irrestrita de entidades nem proteção transacional que a API não fornece |
| F2 — preservação editorial | Descrição rica não representável não é reenviada pelo editor textual; continuação no editor convencional; conteúdo literal que seria removido pela sanitização é bloqueado antes do envio | Demais campos autorizados continuam editáveis; não é um novo editor rico |
| F3 — C13/D03, imagens | Contenção local de mídias e ancestrais; rolagem local com acesso por teclado quando necessária | Não reescreve HTML armazenado, URLs ou alternativas textuais |
| F4 — D04, sem técnico | Contrato estrito de ausência do técnico atribuído; codec GLPI 10 para sentinela nativa e operador vazio com transporte `null` nativo no GLPI 11 | Não transforma usuário zero em pessoa válida nem remove silenciosamente filtros desconhecidos; pesquisa salva legada antes ignorada fica convencional, sem ativação silenciosa |
| F5 — C08, categorias | Visibilidade helpdesk aplicada somente à interface helpdesk obtida no servidor; mesma política para catálogo e hidratação | Mantém tipo, entidade e elegibilidade nativa; não libera categorias fixas |
| F6 — C01/C03/C11/C12 | Revisão dos caminhos existentes e testes de regressão de participantes, tarefa e campos obrigatórios | Sem nova regra universal de técnico, grupo ou categoria; plugins terceiros exigem homologação própria |
| F7 — C06/C10, anexos | Feedback de seleção inicializado independentemente dos campos de classificação; seleção múltipla na escolha atual; aviso e bloqueio de drop não suportado | Não implementa upload por arrastar nem acúmulo de escolhas sucessivas |
| F8 — C02, descrição | Maior altura inicial e redimensionamento acessível do campo de criação | Apenas apresentação |
| Manual | Versão 1.7, contextual, completa e autônoma, com orientações coerentes com a entrega | Figuras didáticas não são a única fonte de instrução |

## Fora desta entrega

Documentos ou validações autônomos, relações entre chamados, associação de itens, integração Escalar, acúmulo de arquivos, upload por drop e novos cartões de observadores continuam como adaptações futuras. A existência de um recurso no GLPI convencional não dispensa comprovar seu contrato público em ambas as versões.

## Instalação e diagnóstico

Atualizar os arquivos e executar a atualização nativa do plugin, sem desinstalar. Conferir código e cadastro em `0.4.18-beta.23`, runtime epoch `20261027-01`. Em ambiente com réplicas, a equipe de infraestrutura deve conferir uniformidade de arquivos e continuidade da sessão; o plugin não contorna essas proteções.

Para confirmação indisponível, conferir a primeira tentativa antes de repetir. Não registrar tokens, cookies, POST bruto ou conteúdo real de chamados no relatório de diagnóstico.

Os resultados efetivamente executados e suas limitações constam em `test_execution_0.4.18-beta.23.md`. A entrega não constitui certificação integral WCAG, eMAG ou RGAA.
