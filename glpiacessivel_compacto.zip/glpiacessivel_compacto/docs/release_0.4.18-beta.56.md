# Versão 0.4.18-beta.56

Preservação do layout existente nas páginas de inclusão e edição de acompanhamentos e tarefas. GLPI 10 e 11, epoch `20261105-04`, manual 3.4.

- Layout da beta.55 mantido: cabeçalho, identificação do contexto, navegação, ajuda e apresentação de anexos não são substituídos por uma estrutura compacta.
- Formulário simples e formulário nativo continuam sujeitos às mesmas liberações e autorizações anteriores. O editor rico não é ativado automaticamente.
- O mecanismo de inclusão e edição reutiliza os formulários completos do GLPI já existentes. Campos, modelos, planejamento, uploads, CSRF, endpoints e destino nativo após o envio não são recortados nem substituídos.
- A leitura textual de anexos e suas opções nativas continuam com os mesmos limites e verificações da beta.55. A gestão de documentos permanece separada do rascunho.
- O manual 3.4 conserva o conteúdo editorial da beta.55, seus 47 assuntos e sete figuras, com cobertura atualizada para beta.56. Contextual, completo e HTML autônomo continuam usando a mesma fonte.

Sem SQL novo, alteração de permissões ou de regras nativas. Esta entrega não introduz o cabeçalho compacto nem novos controles de navegação recolhida. A simplicidade do mecanismo significa continuar usando os recursos do GLPI, sem criar um segundo fluxo próprio de editor, upload ou salvamento. O layout existente e as demais páginas do portal são preservados.

Consulte o registro de testes para resultados executados e limites. Ensaios da proposta compacta não comprovam o estado final com o layout preservado. NVDA/JAWS e homologação institucional continuam exigindo evidência própria.
