# GLPI Acessível 0.4.18-beta.18

## Estatísticas centralizadas no Cockpit

O Cockpit reúne a consulta acessível e os links para as estatísticas convencionais por técnico atribuído e técnico de tarefas, conforme liberação e autorização. O bloco antigo de estatísticas convencionais não é mais apresentado na lista de Chamados, que também deixa de descobrir esses destinos durante sua renderização.

A consulta acessível e os links convencionais continuam independentes. A chave existente `reports.native_links` passa a depender do módulo Cockpit, sem mudar seu identificador, estado ou perfis selecionados. A dependência já existente entre Cockpit e Chamados permanece. Nenhuma opção é ativada por causa da mudança de localização, e o direito nativo de estatísticas continua obrigatório.

Os links abrem na mesma aba e explicam que a acessibilidade da interface convencional pode ser diferente da apresentação do portal. A melhoria de retorno de foco agora é carregada também no Cockpit: ao voltar pelo histórico, o foco retorna ao link utilizado quando possível, sem substituir outro controle ou aviso prioritário. Sem JavaScript, os links e o retorno normal continuam disponíveis.

## Atualização

Atualize pelo fluxo nativo sem desinstalar. Versão `0.4.18-beta.18`, runtime `20261019-09`. Esta correção não cria SQL, não altera o core, não muda fórmulas ou contratos GLPI 10/11 e não amplia o suporte a versões do Tag.

Consulte o [guia de estatísticas em HTML](guia_estatisticas_acessiveis.html), a [liberação de funcionalidades](guia_liberacao_funcionalidades.md) e o [registro de testes](test_execution_0.4.18-beta.18.md).
