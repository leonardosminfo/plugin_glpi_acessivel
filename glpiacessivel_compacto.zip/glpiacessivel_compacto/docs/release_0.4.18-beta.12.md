# GLPI Acessível 0.4.18-beta.12

Liberação gradual de dez novidades, por estado e perfil ativo. Runtime: 20261019-03. Nenhuma tabela, coluna, índice, SQL novo ou alteração do núcleo. A persistência reutiliza o armazenamento próprio já existente; o catálogo usa a API pública CommonDBTM de Profile, autorizada por `Profile::canView()`.

## Disponível

- Página própria em Configuração do plugin, com os estados Desativada, Liberada para perfis selecionados e Liberada para todos os usuários autorizados.
- Revisão Antes e Depois, confirmação CSRF, token de dez minutos vinculado à sessão e contexto, recusa de revisão obsoleta e leitura de confirmação da gravação.
- Controles independentes de status em massa, participantes em massa, edição de interações, colagem, prévia, cabeçalhos, atualização automática, varredura, decisões editoriais em lote e links de estatísticas convencionais.
- Revalidação de escrita no servidor, sem exceção automática para administradores nem ampliação das permissões nativas.
- Formulário sem dependência de JavaScript, controles nativos e textos em português e inglês.
- Recusa de formulário incompleto ou truncado pelos limites do PHP, antes de preparar a confirmação, e preservação do redirecionamento nativo após o salvamento.

## Atualização e limites

Atualize pelo ciclo nativo, sem desinstalar. Preserve a beta.11 e registre as funcionalidades em uso. Política já gravada é preservada; na ausência dela, o instalador cria estado conservador e solicita revisão, porque o núcleo pode já ter substituído os metadados da versão anterior. A ativação explícita dos recursos em uso é parte da revisão administrativa, não uma inferência a partir do novo VERSION.

Nenhum estado desliga correções, verificação das fontes do chatbot ou permissões do GLPI. Operações concluídas não são desfeitas e as continuações nativas em andamento são preservadas. Conveniências em abas já abertas podem exigir recarga.

Não foi implementada trava atômica entre administradores. Revisão e releitura detectam estados obsoletos conhecidos, mas não eliminam corrida simultânea: coordenar a configuração por um administrador por vez. Sem SQL ou arquivo de lock adicionado para simular exclusão mútua.

Não inclui as estatísticas adaptadas no Cockpit, presets administrativos, filtro textual dos perfis ou novas regras de autorização. O catálogo atual aceita até mil perfis; acima desse limite, fica indisponível, sem resultados incompletos apresentados como catálogo completo.

Consulte o [guia administrativo](guia_liberacao_funcionalidades.md), o [plano e seus limites](plano_liberacao_funcionalidades_por_perfil_2026-10-19.md) e a [execução de testes](test_execution_0.4.18-beta.12.md).
