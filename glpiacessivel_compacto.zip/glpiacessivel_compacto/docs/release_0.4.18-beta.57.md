# Versão 0.4.18-beta.57

Editor nativo integrado ao layout existente do portal. GLPI 10 e 11, epoch `20261105-05`, manual 3.5.

## O que muda

- As páginas de inclusão e edição autorizadas usam o formulário completo do GLPI dentro do layout já conhecido do plugin. Não acrescentam cabeçalho ou menu lateral convencionais, nem reorganizam o contexto, a navegação ou a Ajuda.
- Com a inclusão formatada liberada e autorizada, o formulário nativo de acompanhamento ou tarefa aparece diretamente no respectivo bloco do chamado. Cada operação apresenta um formulário por vez.
- Sem essa disponibilidade, o formulário simples permanece e o acesso separado ao formulário completo pode ser oferecido quando autorizado. Recuperar uma recusa de upload não migra o rascunho: conserva o caminho simples e exige conferir os arquivos novamente.
- A página carrega os recursos oficiais do GLPI por seus helpers públicos de cabeçalho e rodapé, preservando a fila nativa de bibliotecas. Os scripts do plugin não são carregados novamente por um segundo caminho na mesma página.
- Os controles nativos identificados somente por ícones recebem nomes acessíveis derivados dos próprios rótulos traduzidos do GLPI. O seletor de arquivos usa a indicação nativa de arquivos e limite de tamanho.
- Um ajuste de largura exclusivo dos formulários nativos permite que os blocos se acomodem a 320 pixels sem cortar controles. Não altera o layout das demais páginas.
- O manual 3.5 orienta começar pelo formulário apresentado no próprio bloco e mantém o caminho separado como alternativa. Contextual, completo e HTML autônomo continuam usando a mesma fonte, com 47 assuntos, sete figuras e os créditos preservados.

## O que permanece

Inclusão e edição têm liberações e autorizações independentes. Nenhuma opção é habilitada automaticamente. O formulário nativo conserva campos, modelos, arquivos, action, CSRF, endpoints e destino após salvar. O GLPI pode redirecionar à interface convencional; não há retorno forçado pelo plugin.

Uma falha ao abrir a edição formatada de uma interação salva não converte seu conteúdo para texto simples. Imagem no texto e documento anexado continuam distintos; a gestão de documentos mantém suas ações e autorizações próprias. A solução conserva o fluxo atual: esta entrega não acrescenta um editor rico de solução.

Sem SQL novo, mudanças de permissões, núcleo ou regras nativas. Não há cópia automática de rascunhos entre páginas, segundo upload próprio ou reaplicação automática de uma gravação incerta. Os recursos empacotados continuam locais; não se introduz dependência de CDN.

Consulte o [registro de testes da entrega](test_execution_0.4.18-beta.57.md) para resultados efetivamente executados e limites. Testes locais não substituem ensaios com leitor de tela nem validação institucional.
