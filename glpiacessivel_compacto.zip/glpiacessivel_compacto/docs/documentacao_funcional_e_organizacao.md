# Documentação funcional e organização do GLPI Acessível

Referência: GLPI Acessível **0.4.18-beta.63**, manual **3.11**. Revisão documental de 06/11/2026.

### Apresentação opcional do detalhe do chamado

O recurso `presentation_simple_mode` disponibiliza, quando liberado, os botões **Simples** e **Completa** no topo do detalhe do chamado. Completa é a apresentação inicial; Simples recolhe informações complementares do resumo, contatos do requisitante e formulários de alteração de responsáveis e status. Descrição, navegação, documentos, etiquetas e ação em andamento continuam disponíveis. A troca não recarrega, não envia o chamado e não recria o editor ou campos de arquivos. Regiões com rascunho, erro ou destino de link permanecem acessíveis.

A preferência é individual, armazenada pelas APIs nativas `Config` em contexto exclusivo do plugin; não modifica direitos, entidade, perfil ou tokens operacionais. A liberação pode ser desativada, restrita a perfis ou geral. A ausência de JavaScript ou de configuração disponível mantém Completa. A primeira entrega contempla somente o detalhe, não a lista nem a tela separada de edição. O manual contextual mostra o procedimento conforme disponibilidade; completo e autônomo conservam as condições e instruções. GLPI 10/11, sem SQL novo nem regras nativas alteradas.

Este documento apresenta os recursos, as condições de disponibilidade e os principais componentes para manutenção do plugin. Os procedimentos de uso estão no manual acessado pela Ajuda e pela entrada do portal. Os resultados de homologação e suas pendências pertencem aos relatórios de cada entrega; descrever um recurso não significa que ele esteja liberado para todos os perfis ou instalações.

## Visão funcional

O GLPI Acessível oferece uma interface alternativa e integrada ao GLPI. O usuário continua sujeito ao mesmo login, perfil, entidade, recursividade e permissões. A interface acessível organiza as tarefas mais frequentes sem copiar os dados operacionais para outro sistema.

## Funcionalidades

### Portal e contexto

A Ajuda de acessibilidade apresenta os atalhos em tabela de consulta, com legenda e cabeçalhos identificados; as linhas não são botões. A tabela acompanha a rolagem do diálogo, sem uma segunda rolagem vertical interna. A orientação diferencia Tab entre controles e leitura de texto/células pelo leitor de tela, e pede fechar a Ajuda antes de navegar na página. As alternativas já existentes Ctrl + Alt + Shift + T/K/H/V/A são informadas com suas condições, sem promessa de funcionamento universal: botões e links visíveis permanecem disponíveis em caso de conflito. O manual 3.11 mantém essa explicação nas apresentações contextual, completa e autônoma. A alteração não cria comandos, permissões ou regras de atendimento.

- entrada acessível com navegação consistente;
- configuração da entrada anônima entre login unificado do GLPI, recomendado, e formulário alternativo de compatibilidade;
- redirecionamento direto ao login oficial do GLPI quando o modo unificado está ativo, preservando SSO, MFA e retorno ao portal;
- nota estática e opcional imediatamente depois de `Entrar` no login nativo, identificada semanticamente, sem link, foco, anúncio intrusivo, formulário ou rota alternativa; uma melhoria progressiva restrita move a nota no DOM e conserva a área do hook como fallback;
- identificação autenticada por login e primeiro nome nativo do GLPI, com fallback para somente o login;
- troca autorizada de perfil e entidade, confirmada somente depois que a nova requisição comprova a persistência da sessão GLPI;
- indicação do contexto ativo;
- atalhos de teclado, tema noturno, alto contraste e ampliação;
- alternativa explícita para abrir a tela nativa do GLPI quando necessário.

O cartão “Interface acessível do GLPI” tem apresentação global Completo, Compacto ou Oculto. Compacto mantém título, os links de portal/manual e o texto visível “Atalho: Ctrl+Alt+Shift+A.”, retirando informação secundária e ajustando espaçamento, sem reduzir a fonte. Oculto omite somente o cartão, não o script de runtime nem o acesso independente ao portal. Antes e sem JavaScript, esse acesso mantém o fallback existente de link estático com rótulo visível. O manual continua disponível pela Ajuda do portal; o atalho não é a única alternativa de entrada.

Os acessos ao portal e ao chatbot ficam sobrepostos à página, sem faixa reservada ou scrollport novo. A rolagem nativa do GLPI é preservada. Mantêm-se os quatro layouts separados/invertidos/empilhados e os tamanhos configurados. Cada grupo recebe um controle explícito “Opções de posição...”, distinto dos links originais: permite arraste pela alça ou abertura de painel não modal com quatro direções em passos de 8 pixels, desfazer, restaurar configurado e fechar. A pilha se move como um conjunto. As posições são guardadas somente nesta aba em sessionStorage, com falha de armazenamento tratada sem impedir os acessos; não há preferência por usuário persistida no banco. A guarda de foco testa quatro cantos seguros e move temporariamente apenas o grupo obstrutor, sem rolar o formulário ou salvar a adaptação. Se nenhum canto comportar o grupo, ele é suspenso temporariamente enquanto o controle precisar de proteção, com acesso alternativo pela navegação. Essa exceção não representa promessa de visibilidade física em qualquer geometria. Modais preservam foco e suspensão dos acessos externos. Não se recriam campos, alteram destinos ou substituem APIs globais de rolagem. O reposicionamento depende de JavaScript; o acesso SSR existente conserva sua alternativa de navegação, sem promessa de dois ícones operáveis sem script.

### Disponibilidade e liberação por perfil

A configuração separa módulos do portal e liberação gradual de funcionalidades. As opções do catálogo podem ficar desativadas, liberadas somente para os perfis selecionados ou liberadas para todos os usuários já autorizados. A avaliação considera o perfil ativo, não a soma dos perfis da conta. A administração revisa e confirma a alteração antes de aplicá-la.

O catálogo abrange ações em massa, edição simples, inclusão e edição formatadas de interações, colagem de imagens, prévia de descrição, ordenação por cabeçalhos, atualização automática, quatro opções de etiquetas, varredura e revisão de roteiros, links convencionais e estatísticas acessíveis. A inclusão com editor formatado (`tickets.interaction_rich_add`) começa desativada e exige autorização de inclusão, sem depender da liberação de edição. A edição formatada (`tickets.interaction_rich_edit`), também desativada por padrão, depende da liberação base de edição e dos direitos de atualização. CREATE e UPDATE não são intercambiáveis. Uma liberação não concede direitos, não instala dependências e não torna compatível um contrato desconhecido. Desativar uma função impede novas operações específicas por esse caminho; não desfaz alterações já registradas no GLPI.

### Chamados

Os valores de data e data/hora dos filtros avançados oferecem digitação e, quando disponível, o calendário do GLPI integrado ao campo do portal. O adaptador carrega somente os recursos necessários, não o formulário convencional nem seu seletor de datas relativas. A confirmação de data/hora preenche Valor; fechar sem confirmar preserva o valor digitado. Selecionar uma data não executa a consulta. Formato, segundos e valores que precisem de revisão são preservados no contrato de pesquisa, sem conversão de fuso ou ampliação para um dia inteiro. Se os recursos do componente não estiverem disponíveis, há alternativa de entrada pelo navegador ou texto. O capítulo `filtros-data-hora` do manual explica os percursos e a conferência da Pesquisa aplicada; ensaio com leitor de tela permanece distinto da verificação automatizada.

Os formulários próprios de acompanhamento e tarefa integram o editor e os anexos nativos, com os demais campos abaixo e rótulos textuais visíveis. A apresentação preserva campos, valores, CSRF, permissões e o processamento nativo; não converte HTML em texto simples. A edição apresenta uma orientação curta e ajuda recolhida. Tema e ampliação acompanham a área editável por estilos de apresentação, sem reabrir o editor nem alterar seu conteúdo. As liberações de inclusão e edição permanecem independentes.

- criação assistida com campos autorizados, anexos e validação acessível;
- pesquisa organizada em três etapas progressivas sobre um único estado canônico: busca rápida, filtros e exibição dos resultados; o acesso recorrente a pesquisas salvas permanece separado do formulário principal e reutiliza o mesmo estado quando aplicado;
- uma única ação `Pesquisar`, sem aplicar a consulta em edição antes da confirmação e sem duplicar o estado da pesquisa;
- no GLPI 11, o POST da pesquisa calcula o destino antes da fronteira de redirecionamento e preserva `advanced_search_token` e `focus=results`, evitando que a exceção nativa de redirect seja classificada como falha;
- listagem com pesquisa textual, escopo, critérios, grupos e metacritérios;
- operadores e valores derivados das Search Options do GLPI;
- condições positivas e negativas de status somente quando autorizadas pelo catálogo de operadores do contexto atual;
- autocomplete remoto autorizado para usuários, grupos, categorias e demais dropdowns;
- múltiplas ordenações, quantidade por página e escolha/reordenação de colunas;
- diálogo de colunas com fechamento por teclado e retorno do foco ao acionador;
- exibição autorizada de chamados ativos ou excluídos;
- resumo separado da consulta em edição e da pesquisa aplicada;
- paginação, seleção e abertura do chamado;
- consulta limitada de IDs com adaptadores próprios para GLPI 10 e 11, linha sentinela apenas para detectar a próxima página e hidratação máxima do tamanho autorizado;
- total independente e anulável, sem bloquear a primeira página nem apresentar ausência de contagem como zero;
- limite global de capacidade, uma consulta em voo por usuário/contexto e circuito local para rejeitar sobrecarga antes da Search API;
- detalhe com acompanhamentos, tarefas, solução, documentos e ações permitidas;
- carregamento assíncrono opcional da página de resultados, com estado de carregamento, vazio, expiração e indisponibilidade, sem substituir a página ou perder o link nativo;
- escopo de grupos em três estados: grupos oficiais resolvidos seguem para consulta, ausência oficial comprovada produz lista vazia exata e contexto ausente, malformado ou cuja carga nativa falhou permanece indisponível;
- validação de `group_id` contra os grupos oficiais do perfil e da entidade atuais, com falha fechada e sem consulta quando o identificador não pertence ao conjunto; `group_by` organiza a apresentação sem alterar o escopo;
- fallback nativo sempre visível antes da inicialização assíncrona, limite de espera, nova tentativa por botão e encerramento garantido do estado ocupado quando o ativo ou o endpoint falhar;
- falha na preparação do estado assíncrono encerra em shell degradado e recuperável, sem executar a consulta síncrona pesada como emergência;
- hidratação em lote da página retornada pela Search API, evitando consulta individual por chamado;
- seletores pesquisáveis e paginados para categoria, localização, técnicos, grupos e observadores, com seleção simples ou múltipla e revalidação integral no envio;
- pesquisa vazia ou curta para categoria/localização e mínimo de dois caracteres para pessoas/grupos, com mensagens estruturadas e resumo de validação sincronizado sem deslocar o foco;
- seleção separada de grupos técnicos e grupos observadores, limitada aos grupos elegíveis para cada papel e para a entidade do chamado;
- recuperação dos participantes já vinculados e edição autorizada por papel, preservando no comando os dados não editados; os efeitos automáticos dos hooks nativos continuam aplicáveis;
- rota canônica `front/tickets.php` para lista e detalhe, evitando a substituição indevida pelo Formcreator em perfis Self-Service; a rota histórica `front/ticket.php` apenas encaminha favoritos antigos antes do bootstrap;
- condição `Status não é` preservada na interface, no resumo e na pesquisa salva, com compilação compatível com a polaridade nativa do GLPI 10 antes da execução;
- escopo `Meus chamados` formado pelos papéis nativos de requisitante, técnico e observador descobertos por metadados, sem identificadores numéricos ou rótulos dependentes do idioma;
- lista e seletores assíncronos traduzidos pelo catálogo compartilhado, mantendo o HTML do servidor como alternativa quando o JavaScript ou a tradução não estiver disponível;
- criação e detalhe com vocabulário canônico pelo contrato Gettext para textos visíveis, nomes acessíveis, confirmações e anúncios, incluindo o gate linguístico global da `0.2.37-beta`;
- contagens de chamados, seleções, erros, anexos, atores e resultados de auditoria com plurais naturais em pt-BR e en-GB, sem construções artificiais com `(s)`;
- mudanças de tema, contraste, alertas e carregamentos comunicadas uma única vez pelas regiões vivas, sem anúncio visual e modal duplicado;
- falhas de sessão ou CSRF apresentadas como orientação para atualizar, entrar novamente ou repetir a ação, sem expor tokens ou detalhes técnicos ao usuário comum;
- criação de chamado redireciona somente depois das fronteiras de exceção, sem alterar a ordem de ACL, CSRF, idempotência e validações;
- ações de criação no fluxo normal, depois dos campos do formulário: Registrar chamado, Limpar formulário e Abrir formulário em página completa, sem barra aderente sobre as instruções.

O atalho **Meus chamados abertos** combina a participação pessoal com o filtro de não solucionados nem fechados. O escopo pessoal e o status continuam conceitos separados. Pesquisas gerais e pesquisas salvas preservam suas definições próprias; o atalho não substitui a pesquisa padrão do usuário.

Filtros por técnico, grupo e ausência de atribuição dependem das Search Options e do contrato de cada geração do GLPI. Técnico vazio não é tratado como uma pessoa de identificador zero. Definições antigas ou combinações não representáveis conservam a continuação convencional, sem ampliar silenciosamente a consulta.

No resumo do chamado, **Observadores** reúne pessoas e grupos, identificados dentro do mesmo valor. Utiliza somente atores já carregados e autorizados, sem expandir integrantes dos grupos. Essa apresentação não renomeia nem combina os seletores da edição de participantes.

### Atendimento, edição e documentos

A inclusão e a edição de interações usam os formulários próprios do portal. Somente o editor de conteúdo e o uploader temporário são fornecidos pelo helper público `Html::textarea` do GLPI, com seus recursos de página. Não se chama `ITILFollowup::showForm` nem `TicketTask::showForm` nesses fluxos; não se extraem campos de formulários completos nem se importam seus campos adicionais, botões ou destinos de envio. Cabeçalho, contexto, navegação, Ajuda, campos e ações do plugin são preservados. Cada script é carregado uma vez pelo ciclo de página correspondente.

Acompanhamentos, tarefas, soluções e transições de status usam os modelos e as validações do GLPI. A atribuição do técnico, a descrição da solução, os campos obrigatórios e as transições permitidas dependem das regras nativas da instalação; o portal não cria uma política paralela para solucionar ou fechar chamados.

Modelos de acompanhamento preenchem o conteúdo conforme o contrato nativo. Somente **Descrição do acompanhamento** oferece os controles **Ampliar campo** e **Restaurar altura padrão**. A ampliação por botão é limitada pela janela e não reduz uma altura maior obtida pelo redimensionamento nativo. Os controles ajustam a altura do mesmo campo sem alterar texto, privacidade, arquivos ou envio; restaurar não apaga conteúdo. Não implementam autosave ou editor rico. Sem JavaScript, os controles próprios ficam ocultos e o campo permanece editável. Tarefa, solução e editor convencional não recebem esses controles.

A edição de acompanhamentos e tarefas salvos exige liberação e autorização nativa. O editor simples cobre texto simples e privacidade nos contratos reconhecidos e mantém seu POST restrito. Com a liberação adicional de edição formatada, o mesmo formulário próprio incorpora o editor e o uploader nativos. O POST continua no endpoint do plugin, com CSRF, token de edição e autorização revalidada; o modo rico autoriza apenas os campos previstos de conteúdo, privacidade e upload temporário. A atualização e o vínculo dos documentos usam as APIs nativas. Não se promete a edição de estado, duração, planejamento ou responsáveis da tarefa por essa tela. Após salvar, o usuário retorna à interação no chamado do portal. Uma falha ao abrir o editor não converte conteúdo salvo para texto simples; uma gravação incerta não é reaplicada automaticamente. Os documentos já vinculados permanecem acessíveis pela leitura autorizada de anexos.

A inclusão de acompanhamento ou tarefa tem liberação própria, com o chamado pai e os direitos de inclusão validados. Há um formulário próprio por operação: com a formatação liberada, editor e uploader nativos ocupam a área de conteúdo no respectivo bloco, sem substituir os demais campos do portal. Modelos, visibilidade, campos da tarefa e documentos continuam sendo revisados nos controles apresentados. Os acessos antigos à inclusão com formatação validam a autorização e conduzem ao bloco correspondente do detalhe, preservando o mesmo formulário, os campos e valores iniciais da tarefa. Não abrem um formulário alternativo reduzido. O envio passa pelo endpoint do plugin e pelas APIs nativas de inclusão, retornando ao chamado no portal. Uma recuperação de upload conserva o rascunho reapresentado; não se promete transferência entre páginas, recuperação automática de arquivos ou reaplicação de gravação incerta. A solução conserva seu fluxo atual; esta entrega não adiciona um novo editor de solução.

Os anexos da interação possuem uma página de leitura textual, independente das flags dos editores. Nome, origem, descrição autorizada e dados técnicos precedem a prévia opcional. Texto alternativo é obtido somente da ocorrência no contexto autorizado; comentário do documento é identificado como comentário, sem ser promovido a descrição da imagem. Na ausência, a indicação neutra é “Descrição do conteúdo não informada.”. Metadados técnicos não substituem significado, e não se cria descrição por OCR ou IA.

As ações nativas de documentos ficam somente na página de anexos, acessada por “Consultar anexos e opções disponíveis”, e exigem a liberação base de edição e os direitos nativos correspondentes. O formulário de edição aberto mantém leitura e prévias, mas não contém essas ações. A navegação separada não transfere rascunhos nem promete proteção integral contra perda; o usuário deve concluir ou preservar o que preparou. Editar dados do documento compartilhado, remover vínculos do chamado e configurar a lista de exclusão para importação são operações diferentes. O controle “Excluir permanentemente” da timeline não equivale ao purge global: pode remover referências do arquivo no chamado e interações abrangidas, limpar imagens da descrição e produzir histórico/notificações. A propriedade de lista de importação é compartilhada pelos vínculos do documento, não remove o arquivo nem muda o direito de leitura. Não se promete o mesmo controle rápido ou comportamento de importação no GLPI 10 e 11. Nenhuma operação é executada para produzir a leitura documental ou a prévia.

A descrição textual do chamado continua com entrada e releitura específicas por geração, sem decodificação heurística que transforme texto em HTML. Na leitura, o conteúdo rico é delegado ao renderizador público nativo.

Arquivos selecionados estão pendentes até a operação nativa confirmar seu registro. Extensão, tamanho, autorização e visibilidade continuam validados pelo GLPI. A seleção múltipla atual não promete acumular escolhas sucessivas; a colagem de imagens é uma opção independente e o seletor comum permanece disponível. Arrastar para áreas sem suporte não inicia upload.

Uma recusa anterior à operação pode reapresentar o texto na resposta atual, mas exige nova seleção dos arquivos. Uma falha posterior pode deixar resultado parcial ou incerto: não há repetição automática de gravações ou anexos. O acesso a documentos continua sujeito ao chamado e à privacidade da interação, não apenas à presença de um link.

### Responsáveis, participantes e Escalade

A atualização autorizada de responsáveis e participantes usa uma operação nativa de atores do GLPI, preservando a ordem enviada e os metadados dos atores não editados, inclusive requerentes anônimos e fornecedores quando presentes. Os hooks oficiais continuam responsáveis por seus próprios efeitos sobre atribuição, histórico, status e notificações.

Nos contratos reconhecidos, vários grupos novos podem ser preparados e enviados na mesma operação. O Escalade pode retirar grupos ou técnicos conforme sua configuração; terminar com um único grupo não significa que a entrada nativa esteja limitada a um grupo por vez. Uma restrição efetiva da operação nativa continua sendo respeitada. Sem Escalade, permanece a atribuição nativa, sem simular escalonamento.

A conferência anterior à revisão é somente de leitura e vincula contexto, capacidade e sequência da intenção à confirmação. O envio final revalida o contexto de forma independente. Cancelar mantém as escolhas e os demais rascunhos na mesma página; sair ou recarregar pode exigir preparar novamente texto e arquivos. Processamento aceito, resultado conferido e resultado incerto são estados distintos.

Se a versão ou configuração da integração não permitir comprovar o contrato, o portal oferece continuação no chamado convencional antes de gravar. As escolhas não são transferidas automaticamente. O plugin não reimplementa o motor do Escalade nem afirma equivalência irrestrita ao seu botão Escalar. As combinações reconhecidas e os recortes testados estão nas notas das versões; não são garantia para qualquer extensão instalada.

### Ações em massa

Com as funções liberadas e os direitos nativos correspondentes, o usuário seleciona chamados autorizados e prepara a ação disponível. O fluxo oferece revisão explícita, quantidade e resumo antes da confirmação, e distingue sucesso, recusa e resultado parcial ou incerto.

O catálogo adaptado desta versão cobre mudança de status e adição de participantes por ações nativas reconhecidas; não é uma cópia de todas as ações do GLPI. Adicionar participantes não equivale a substituir os responsáveis. As validações e os hooks das extensões continuam atuando, inclusive possíveis efeitos automáticos. A seleção de chamados e a cópia de IDs não concedem permissão para uma ação em massa; as ações disponíveis dependem do catálogo nativo e são novamente validadas no fluxo. Desativar as duas funções coletivas retira o acesso correspondente na listagem.

### Etiquetas do plugin Tag

A integração opcional pode apresentar etiquetas no detalhe, uma coluna na listagem e um filtro de igualdade por uma etiqueta exata. Leitura no detalhe, acesso à edição convencional, coluna e filtro têm quatro liberações distintas. A edição continua no GLPI convencional; não há edição local, alteração de etiquetas em massa, ordenação pela coluna ou filtro simplificado de várias etiquetas nesta entrega.

Os nomes identificam as etiquetas sem depender de cor. A cor válida é preservada, com texto preto ou branco conforme o maior contraste calculado; cores forçadas respeitam o sistema. Valores inválidos recebem apresentação neutra. Nomes longos quebram linha e etiquetas homônimas são diferenciadas pelo identificador.

Uma falha apenas na coluna preserva chamados, ordenação e paginação, distinguindo ausência comprovada de etiquetas de leitura indisponível. Já uma consulta que depende de etiqueta não executa sem esse contrato: o critério não é removido para produzir resultados mais amplos. Tag ausente ou incompatível não impede os demais recursos do portal dentro da fronteira dessa integração.

Os contratos reconhecidos são Tag 2.14.8 com GLPI 11.0.1–11.0.98 e Tag 2.12.6 com GLPI 10.0.11–10.0.98. A coluna em lote está habilitada somente no contrato 2.14.8. Reconhecimento técnico não dispensa requisitos, segurança e homologação da combinação real. O GLPI 10.0.10 local com Tag 2.12.2 não homologa a integração do portal. Consulte o [guia de etiquetas](guia_etiquetas_acessiveis.md) para condições e limites.

### Pesquisas salvas

- catálogo paginado das pesquisas autorizadas do GLPI;
- pesquisa por nome;
- aplicação direta da definição nativa;
- criação, renomeação, definição como padrão e exclusão no próprio GLPI;
- mutações selecionam o destino dentro do fluxo protegido e redirecionam somente depois dos `catch`, mantendo compatibilidade com `RedirectException` no GLPI 11;
- classificação conservadora de pesquisas que precisam ser abertas na interface nativa;
- nenhuma cópia ou sincronização local de `SavedSearch`.

Pesquisas privadas continuam limitadas aos usuários autorizados pelo GLPI. Aplicar uma pesquisa, guardá-la e defini-la como padrão são operações distintas. A definição aplicada e o estado salvo passam pela mesma validação estrita, incluindo critérios de status e etiqueta. Um estado legado não representável não é reinterpretado como outra pesquisa.

### Conhecimento, formulários e atendimento

- consulta acessível da base de conhecimento;
- descoberta e renderização delegada de formulários nativos, Service Catalog e Formcreator quando o contrato é comprovado;
- catálogo público com nome, descrição e uma ação principal, sem expor fonte, versão, motor, renderer, contrato ou razão técnica;
- abertura orientada por tarefa, com uma única região de estado, alternativa permanente em página completa, nova tentativa e foco preservado;
- abertura iniciada pelo catálogo sempre preserva o shell e o menu do portal; o modo de página completa permanece uma alternativa explícita;
- área incorporada com altura responsiva limitada e rolagem própria, evitando realimentação de tamanho entre o iframe e o documento Formcreator;
- incorporação do Service Catalog do GLPI 11 condicionada a mesma origem, rota, ID, método `POST` e endpoint `/Form/SubmitAnswers`; a nova tentativa repete somente o GET, e campos, CSRF, validações e submissão continuam no core;
- diagnósticos de formulários projetados e sanitizados no servidor, ausentes do modelo público e liberados somente a quem possui o direito nativo de atualizar configurações;
- resolução única da instalação Formcreator em `plugins` ou `marketplace`, reutilizada no catálogo, na abertura e no envio, sem caminho fornecido pelo cliente e com alternativa nativa conservadora quando a raiz não puder ser comprovada;
- incorporação mínima opcional do Formcreator 2.13 no GLPI 10, controlada por gate server-side e guardas de origem, rota, ID, versão e estrutura; qualquer divergência preserva a interface nativa completa;
- redução visual limitada à casca reconhecida do Formcreator, sem ocultar campos, ajuda, validações, anexos, mensagens, CSRF ou envio;
- fingerprint vertical institucional versionado, aplicado apenas quando o formulário Formcreator, o identificador, o CSRF e o único envio esperado forem comprovados; qualquer divergência mantém a interface completa;
- chatbot operacional com políticas de intenção, mascaramento de dados e encaminhamento seguro;
- FAQ, cockpit e playbooks para orientar atendimento e operação;
- cockpit com cinco indicadores textuais e acionáveis, calculados pela Search API no contexto autorizado, com período, escopo, horário de referência e detalhamento equivalente na lista de chamados;
- indicadores do cockpit diferenciados visualmente sem depender de cor, com os metadados completos recolhidos em `Detalhes do indicador`;
- estado explícito de resultado indisponível quando uma contagem exata não puder ser comprovada, sem converter falha em zero;
- indicador de chamados dos grupos responsáveis com zero exato somente quando o conjunto oficial de grupos estiver resolvido e vazio; os outros quatro indicadores continuam independentes;
- configuração administrativa e diagnóstico local de acessibilidade, com separação entre violações confirmadas e revisões manuais e detalhes técnicos limitados que não persistem nem transmitem conteúdo da página.
- textos administrativos e diagnósticos de formulários dinâmicos traduzidos pelo mesmo domínio Gettext, mantendo códigos internos apenas nas superfícies autorizadas;

### Estatísticas no Cockpit

O Cockpit centraliza a consulta acessível e os links para estatísticas convencionais, com liberações independentes. Esse acesso não permanece duplicado na lista de Chamados. O direito nativo de estatísticas é obrigatório, além da liberação do recurso e das dependências do módulo.

A consulta adaptada apresenta quatro contagens nativas por **técnico atribuído**, com período e paginação das linhas de técnicos. Não recalcula fórmulas e não transforma o número de linhas no total de chamados. Os indicadores operacionais do Cockpit e os filtros da lista não são a mesma consulta estatística. Indisponibilidade não é apresentada como zero.

As estatísticas por técnico de tarefas permanecem na interface convencional, assim como modalidades não reconhecidas pelo adaptador. Os links explicam a mudança de interface e usam a mesma aba. Consulte o [guia de estatísticas](guia_estatisticas_acessiveis.md).

### Roteiros e varredura da base de conhecimento

A varredura retomável prepara propostas a partir das fontes de conhecimento autorizadas; não publica nem inativa automaticamente intenções. Conteúdo retirado de publicação ou de uso pode fornecer evidência para uma proposta de inativação, conforme o estado nativo reconhecido. A revisão humana continua necessária.

Quando liberado, o usuário pode selecionar propostas e revisar uma decisão em lote de aprovação ou rejeição. A decisão individual permanece disponível. Estado da fonte, elegibilidade, autorização e revisão são novamente conferidos; uma proposta não substitui a regra de acesso ao artigo nem amplia o conteúdo que o chatbot pode apresentar.

### Manual e orientação contextual

O manual 3.11 reúne 49 assuntos e sete figuras, com apresentações contextual, completa integrada e HTML autônomo geradas pela mesma fonte editorial. `interacoes-inclusao-rica` mantém a regra `tickets.interaction_rich_add`, independente de edição, e orienta começar pelo formulário do portal no próprio bloco. `interacoes-edicao-rica` mantém a regra `tickets.interaction_rich_edit` e sua dependência da liberação base. Os procedimentos distinguem adicionar de editar, campo simples de editor formatado e arquivo selecionado, temporário ou vinculado. Explicam os mesmos controles do portal, o retorno ao chamado, a utilização do editor por teclado e a diferença entre retirar uma imagem do texto e excluir um documento. Não prometem alteração dos demais atributos da tarefa na edição. A leitura de anexos com texto primeiro está em J-07, sem depender da liberação rica. A Ajuda abre o manual em nova aba; o cartão convencional, quando exibido, oferece acesso na mesma aba. Os procedimentos não pressupõem experiência prévia com GLPI e podem ser compreendidos sem enxergar as figuras. A orientação de posição também integra o assunto geral de teclado e leitor, sem exigir acesso administrativo.

O manual contextual prioriza assuntos conforme módulos, liberações, direitos gerais e dependências confirmáveis na abertura. Os assuntos não priorizados mantêm título, orientação de disponibilidade e ligação para o completo, sem exibir integralmente os procedimentos nesse modo. Não existe uma matriz fixa de capítulos baseada apenas no nome do perfil.

O completo integrado reúne todos os procedimentos e conserva o contexto e os avisos. Consultá-lo não exige trocar perfil nem concede ações. **Contexto desta leitura** informa perfil, entidade, escopo e versão confirmados, sem login, e-mail ou tokens. Uma mudança em outra aba só aparece depois de reabrir ou recarregar o manual. Disponibilidade desconhecida não significa falta de direito nem ausência de dados.

O HTML autônomo é uma referência completa para leitura offline, com imagens e estilos incorporados, sem sessão ou operações de atendimento. Não repete estados dinâmicos da instalação em cada capítulo. O integrado e o autônomo compartilham procedimentos, alternativas textuais, sumário, links por tarefa e índices internos.

A consulta documental é somente de leitura: não lista chamados ou integrantes de grupos para decidir orientações, não inicializa o contexto operacional e não autoriza ações. As verificações por chamado ou recurso continuam na operação nativa. Consulte o [guia do manual](guia_manual_contextual.md).

### Acessibilidade da apresentação

A estrutura usa títulos, regiões, rótulos e tabelas semânticas, salto ao conteúdo, navegação do chamado e acesso/retorno à descrição. No manual, há acesso ao sumário e ao primeiro percurso, retorno ao sumário e miniíndices nos assuntos extensos. Os destinos por âncora recebem foco sem se tornarem novas paradas habituais de Tab.

Tab percorre controles; a leitura por títulos e regiões depende dos comandos do leitor de tela. Atalhos são alternativas opcionais, não o único caminho. Temas e ampliação preservam a estrutura semântica, e a informação não depende somente de cor ou posição. As tabelas que precisam de duas dimensões têm rolagem própria, sem prometer ausência universal de rolagem.

WCAG, eMAG e RGAA orientam a avaliação, sem declaração de certificação integral. Ensaios automatizados, recortes autenticados, leitor de tela real e aceite institucional têm alcances distintos. Leitura offline do manual não significa operação offline do GLPI. A verificação desta entrega e os limites assistivos/institucionais pertencem ao [relatório da beta.55](test_execution_0.4.18-beta.55.md); descrever a implementação aqui não constitui aprovação de ensaios ainda não documentados.

## Fluxo de uma requisição

1. Um arquivo em `front/` carrega o bootstrap do GLPI; na entrada anônima, a política decide entre redirecionamento nativo e ponte compatível antes de preparar o formulário.
2. O controlador confirma sessão, contexto, liberação e dependências quando aplicáveis, CSRF nas operações protegidas e permissão nativa.
3. Um serviço de aplicação coordena o caso de uso.
4. Regras de domínio validam a entrada e o contrato.
5. Um repositório ou adaptador executa o contrato reconhecido. Atribuições e ações nativas permanecem sujeitas aos hooks e validações do GLPI e das extensões; persistências próprias existentes mantêm seus limites.
6. Um presenter prepara informação sem metadados internos.
7. O template gera HTML semântico e os ativos adicionam interação progressiva.

## Organização das pastas

| Pasta | Responsabilidade |
|---|---|
| `front/` | Pontos de entrada HTTP do plugin |
| `src/Application/` | Casos de uso e orquestração |
| `src/Domain/` | Políticas, entidades e contratos de negócio |
| `src/Infrastructure/` | Repositórios, pesquisa, auditoria, segurança e persistência |
| `src/Model/` | Modelos de tabelas próprias do plugin |
| `src/Security/` | CSRF, sanitização e guarda de contexto |
| `src/Support/` | Bootstrap, contêiner, compatibilidade e utilitários |
| `src/UI/` | Controladores, presenters e mecanismo de views |
| `templates/` | Páginas e componentes HTML renderizados no servidor |
| `resources/` | Fonte editorial e figuras do manual, manifestos e outros recursos empacotados |
| `assets/` | Fontes de CSS, JavaScript, imagens e dependências inventariadas |
| `public/` | Ativos publicados para o navegador |
| `locales/` | Catálogos Gettext |
| `sql/` | Instalação e remoção das tabelas próprias |
| `tests/` | Testes unitários, de integração e navegador |
| `tools/` | Compilação, verificação, i18n, acessibilidade e homologação |
| `docs/` | Arquitetura, operação, segurança, testes, roadmaps e notas de versão |

## Inventário principal dos arquivos de execução

O inventário destaca os pontos de entrada e componentes de manutenção. Não é uma relação exaustiva de todas as classes, contratos e arquivos do pacote.

### Raiz

| Arquivo | Finalidade |
|---|---|
| `setup.php` | Metadados, versão, compatibilidade, inicialização, política cacheada da entrada pré-login e registro do ativo anônimo oficial |
| `hook.php` | Hooks e integração de menu/ativos com o GLPI, incluindo a ponte compatível e o HTML estático do aviso pré-login |
| `glpiacessivel.xml` | Metadados de publicação e compatibilidade |
| `glpiacessivel.png` | Identidade visual em alta resolução usada na documentação |
| `logo.png` | Ícone local otimizado, nativo no GLPI 11 e usado pelo fallback progressivo do cartão ativo no GLPI 10 |
| `composer.json` | Dependências, autoload PSR-4 e comandos de QA PHP |
| `glpiacessivel_chatbot_check.php` | Diagnóstico de requisitos do chatbot |

### Pontos de entrada `front/`

| Arquivo | Finalidade |
|---|---|
| `acessivel.php` | Entrada principal do portal |
| `manual.php` | Leitura autenticada do manual contextual ou completo |
| `features.php` | Administração e confirmação da liberação gradual |
| `statistics.php` | Consulta acessível das estatísticas nativas reconhecidas |
| `audit.php`, `audit.export.php` e `audit.profile.form.php` | Consulta/exportação autorizada de auditoria e gestão dos direitos específicos |
| `chatbot.php` | Jornada do chatbot |
| `cockpit.php` | Visão operacional |
| `config.php` | Configuração administrativa |
| `context.php` | Troca autorizada de perfil e entidade |
| `faq.php` | Perguntas frequentes |
| `form.open.php` | Resolução e abertura segura de formulário |
| `form.render.php` | Renderização ou delegação do formulário |
| `forms.php` | Catálogo de formulários |
| `knowledge.php` | Base de conhecimento |
| `playbooks.php` | Playbooks operacionais |
| `runtime-config.js.php` | Configuração JavaScript gerada no contexto da sessão |
| `ticket.action.php` | Ações mutáveis autorizadas sobre chamados |
| `ticket.massaction.php` | Preparação, revisão, execução e resultado das ações coletivas reconhecidas |
| `ticket.interaction.php` | Edição autorizada de acompanhamento ou tarefa salva |
| `ticket.routing-preflight.php` | Conferência somente de leitura da intenção de atribuição, antes da revisão |
| `ticket.template.php` | Aplicação autorizada de modelo de interação |
| `ticket.create.php` | Criação de chamado |
| `ticket.php` | Redirecionador de compatibilidade pré-bootstrap para favoritos e integrações anteriores |
| `tickets.php` | Rota canônica da lista e do detalhe de chamados |
| `ticket.results.php` | Endpoint JSON dos resultados assíncronos da lista |
| `ticket.resource-selector.php` | Endpoint JSON dos seletores remotos de recursos |
| `ticket.saved-search.php` | Mutações de pesquisas salvas nativas |
| `ticket.search-values.php` | Endpoint protegido do autocomplete de filtros |

### Aplicação `src/Application/`

| Arquivo | Finalidade |
|---|---|
| `AdvancedTicketSearchRequest.php` | Traduz a submissão da busca para AST canônica |
| `ChatbotIntentPolicy.php` | Política de intenções permitidas |
| `ChatbotPlaybookService.php` | Integra chatbot e playbooks |
| `ChatbotService.php` | Fluxo conversacional e respostas operacionais |
| `ConfigService.php` | Leitura, gravação e validação fechada dos modos e preferências de configuração |
| `FeatureReleaseCatalog.php` e `FeatureReleasePolicy.php` | Catálogo e disponibilidade das funcionalidades conforme o perfil ativo e a configuração, incluindo a dependência da edição formatada em relação à edição base |
| `ManualCatalog.php` | Carga e validação da fonte editorial fixa empacotada |
| `ManualAvailabilitySnapshot.php` | Contexto documental e disponibilidade geral, locais à requisição e sem conceder autorização |
| `NativeTicketStatisticsService.php`, `NativeTicketStatisticsGateway.php` e `NativeStatisticsRequest.php` | Validação, contrato e paginação das contagens nativas, sem recalcular estatísticas |
| `TicketTagsService.php` e `TicketTagsPageService.php` | Leitura condicionada de etiquetas no detalhe e na página de resultados |
| `TicketMassActionStateStore.php`, `TicketMassActionForm.php` e `TicketMassActionVerification.php` | Estado opaco, projeção validada do formulário nativo e conferência do resultado coletivo |
| `InteractionEditState.php` | Estado protegido da edição de interação salva |
| `KnowledgeScanService.php` e `PlaybookEligibilityPolicy.php` | Varredura retomável e elegibilidade das propostas de roteiros |
| `ContextService.php` | Usuário, perfil, entidade e contexto ativo a partir da sessão GLPI |
| `FormService.php` | Catálogo e acesso a formulários |
| `KnowledgeBaseService.php` | Pesquisa e apresentação da base de conhecimento |
| `PortalModulePolicy.php` | Disponibilidade dos módulos do portal |
| `RemoteSearchValueAuthorizer.php` | Reautoriza valores remotos de filtros |
| `SavedTicketSearchService.php` | Casos de uso de pesquisas salvas do GLPI |
| `TicketListStateStore.php` | Estado opaco e temporário da consulta assíncrona |
| `TicketSearchStateStore.php` | Tokens opacos e estado temporário da pesquisa |
| `TicketService.php` | Casos de uso de chamados |

### Formulários dinâmicos `src/Application/DynamicForm/`

| Arquivo | Finalidade |
|---|---|
| `DynamicFormFacade.php` | Seleciona o adaptador de formulário adequado |
| `FormcreatorSchemaAdapter.php` | Adapta Formcreator quando disponível |
| `FormSubmissionGate.php` | Autoriza e valida a submissão |
| `NativeTicketSchemaAdapter.php` | Adapta o formulário nativo de chamado |
| `ServiceCatalogSchemaAdapter.php` | Adapta o Service Catalog do GLPI 11 |
| `TicketTemplateSchemaAdapter.php` | Adapta modelos de chamado |

### Domínio `src/Domain/`

| Arquivo | Finalidade |
|---|---|
| `DynamicForm/DynamicFormAdapterInterface.php` | Contrato dos adaptadores de formulário |
| `DynamicForm/DynamicFormCondition.php` | Condição de exibição/validação |
| `DynamicForm/DynamicFormField.php` | Campo normalizado |
| `DynamicForm/DynamicFormSchema.php` | Esquema versionado do formulário |
| `DynamicForm/DynamicFormSection.php` | Seção normalizada |
| `DynamicForm/DynamicFormSubmissionResult.php` | Resultado da submissão |
| `DynamicForm/FormCapability.php` | Capacidades comprovadas do adaptador |
| `Pii/PiiMasker.php` | Mascaramento de informação pessoal |
| `Security/Authorization.php` | Regras comuns de autorização |
| `Ticket/NativeSearchDefinitionValidator.php` | Valida a AST e parâmetros nativos da busca |
| `Ticket/NativeSearchValidationException.php` | Erro controlado de definição de busca |
| `Ticket/SearchCriterionValueValidator.php` | Valida valores por campo e operador |
| `Ticket/SearchFieldContract.php` | Contrato autorizado de um campo |
| `Ticket/SearchOperatorValueContract.php` | Contrato de valor por operador |
| `Ticket/SearchValueKind.php` | Tipos suportados de valor |
| `Ticket/TicketCreationPolicy.php` | Política de criação de chamado |
| `Ticket/TicketPolicy.php` | Políticas de acesso e ação sobre chamado |

### Infraestrutura `src/Infrastructure/`

| Arquivo | Finalidade |
|---|---|
| `Audit/AuditLogger.php` | Registro de auditoria com minimização de dados, sem executar retenção no caminho da requisição |
| `Audit/AuditRetentionService.php` | Exclusão limitada e indexada de registros vencidos |
| `Audit/AuditRetentionCronTask.php` | Execução periódica em lotes da retenção de auditoria |
| `Search/GlpiBoundedTicketSearchGateway.php` | Orquestra a pesquisa limitada de IDs e falha fechada quando a capability não é reconhecida |
| `Search/Glpi10BoundedTicketSearchAdapter.php` | Adapta o contrato de busca limitada do GLPI 10 |
| `Search/Glpi11BoundedTicketSearchAdapter.php` | Adapta o contrato de busca limitada do GLPI 11 |
| `Search/TicketListCapacityGuard.php` | Controla capacidade, consulta única por usuário/contexto e circuito de falhas |
| `Compliance/SchemaManager.php` | Instalação e evolução do esquema próprio |
| `Http/NativeTicketRoutingInput.php` | Prepara somente a entrada nativa de atores, preservando ordem e metadados |
| `Http/EscaladeRoutingCapabilityResolver.php` | Reconhecimento somente de leitura dos contratos de atribuição com Escalade |
| `Http/NativeTicketDescriptionInput.php` | Entrada textual de descrição reconhecida por geração do GLPI |
| `Http/NativeTicketReportLinks.php` | Destinos locais autorizados das estatísticas convencionais |
| `Ticket/NativeInteractionEditor.php` | Edição pelos modelos públicos nativos nos contratos reconhecidos |
| `Ticket/NativeInteractionCreator.php` e `Ticket/NativeInteractionCreationForms.php` | Autorização da inclusão e fragmentos de editor/uploader nativos nos formulários próprios do portal |
| `MassiveAction/NativeMassiveActionGateway.php` e `MassiveAction/NativeFormControls.php` | Fronteira das ações em massa e projeção restrita dos controles nativos |
| `Tags/GlpiTicketTagsGateway.php`, `Tags/GlpiTicketTagsPageGateway.php` e `Tags/TagSearchCapability.php` | Contratos de leitura de etiquetas e capacidades da integração Tag |
| `Statistics/GlpiNativeStatisticsGateway.php` | Consulta do mecanismo nativo de estatísticas |
| `Session/GlpiSessionContextGateway.php` | Adaptação das APIs nativas de contexto de sessão |
| `Knowledge/NativeKnowledgeSourceReader.php` | Leitura de fontes de conhecimento pelo contrato nativo |
| `Audit/AuditRights.php`, `Audit/AuditQueryService.php` e `Audit/AuditPayloadSanitizer.php` | Autorização, consulta e minimização do conteúdo de auditoria |
| `Repository/FormRepository.php` | Acesso aos formulários disponíveis |
| `Repository/NativeSavedSearchGateway.php` | Integração com `SavedSearch` do GLPI |
| `Repository/PlaybookRepository.php` | Persistência de playbooks e sugestões |
| `Repository/SavedTicketSearchRepository.php` | Compatibilidade histórica de pesquisas |
| `Repository/TicketRepository.php` | Pesquisa, leitura e gravação de chamados via GLPI |
| `FormCatalog/FormCatalogGateway.php` | Contrato fechado das fontes de catálogo de formulários |
| `FormCatalog/FormCatalogRequest.php` | Requisição paginada vinculada ao contexto do catálogo |
| `FormCatalog/Formcreator213CatalogGateway.php` | Adaptador autorizado e paginado do Formcreator 2.13 |
| `FormCatalog/FormcreatorNativeUrlResolver.php` | Resolve e valida no servidor a raiz nativa do Formcreator para catálogo, abertura e envio |
| `Search/GlpiResourceSelectorCursor.php` | Emite e valida cursores opacos dos seletores |
| `Search/GlpiResourceSelectorProvider.php` | Consulta e reautoriza recursos dos chamados |
| `Search/GlpiResourceSelectorRegistry.php` | Allowlist de provedores, dependências e limites |
| `Search/GlpiSearchContractResolver.php` | Resolve o contrato campo/operador/valor |
| `Search/GlpiSearchOptionCatalog.php` | Catálogo contextual de Search Options |
| `Search/GlpiSearchValueProvider.php` | Consulta paginada de valores remotos |
| `Search/GlpiSearchValueRateLimiter.php` | Limites de requisição do autocomplete |
| `Search/GlpiTicketLocalValueCatalog.php` | Valores locais como status e prioridade |
| `Search/GlpiTicketStatusCriterionCodec.php` | Preserva a semântica acessível de Status e compila a polaridade exigida pela Search API nativa |
| `Search/GlpiTicketActorSearchOptionResolver.php` | Descoberta dos papéis nativos usados nos filtros de participantes |
| `Search/GlpiTicketUnassignedCriterionCodec.php` e `Search/GlpiTicketUnassignedSearchCapability.php` | Semântica de ausência de atribuição conforme o contrato de busca |
| `Search/TicketTagFilterCriteria.php` e `Search/TagSearchExecutionGuard.php` | Critério exato de etiqueta e guarda que impede executar uma consulta dependente sem sua integração |
| `Search/TicketListRateLimiter.php` | Limita chamadas ao endpoint de resultados |
| `Security/GlpiSessionContextSnapshot.php` | Captura a revisão opaca de usuário, perfil, entidade e direitos |
| `Security/IdempotencyClaim.php` | Representa uma reserva idempotente |
| `Security/IdempotencyLedger.php` | Evita repetição de mutações |

### Modelos, segurança e suporte

| Arquivo | Finalidade |
|---|---|
| `src/Model/AuditLog.php` | Modelo do registro de auditoria |
| `src/Model/AuditProfileRights.php` | Direitos específicos da auditoria por perfil |
| `src/Model/Config.php` | Modelo de configuração |
| `src/Model/PiiReveal.php` | Modelo de revelação controlada de PII |
| `src/Model/Playbook.php` | Modelo de playbook |
| `src/Model/PlaybookJob.php` | Modelo de execução de playbook |
| `src/Model/PlaybookSuggestion.php` | Modelo de sugestão operacional |
| `src/Security/CsrfGuard.php` | Compatibilidade e verificação CSRF |
| `src/Security/InputSanitizer.php` | Normalização de entrada |
| `src/Security/SessionContextGuard.php` | Confirma contexto da sessão |
| `src/Support/Bootstrap.php` | Carregamento do plugin |
| `src/Support/Container.php` | Resolução das dependências internas |
| `src/Support/FormValidationException.php` | Erros controlados de formulário |
| `src/Support/EditorialBatchState.php` | Estado protegido da revisão editorial em lote |
| `src/Support/GlpiCompatibility.php` | Diferenças suportadas entre GLPI 10 e 11 |
| `src/Support/I18n.php` | Tradução Gettext |
| `src/Support/LoginSourceDiscovery.php` | Descoberta das fontes de autenticação |
| `src/Support/RichTextFormatter.php` | Formatação segura de texto rico |
| `src/Support/TextNormalizer.php` | Normalização semântica de texto |
| `src/Support/TicketStatusLabels.php` | Rótulos consistentes de status |
| `src/Support/UploadedFileMapper.php` | Mapeamento seguro de anexos |
| `src/Support/Url.php` | Construção de URLs do plugin |
| `src/Support/ValidationErrorNormalizer.php` | Mensagens de validação apresentáveis |

### Interface `src/UI/`

| Arquivo | Finalidade |
|---|---|
| `Controller/BaseController.php` | Comportamentos comuns dos controladores |
| `Controller/ChatbotController.php` | Controla o chatbot |
| `Controller/CockpitController.php` | Controla o cockpit |
| `Controller/ManualController.php` | Leitura autenticada GET/HEAD, contextual/completa, sem inicialização operacional |
| `Controller/FeatureReleaseController.php` | Revisão e confirmação da liberação de funcionalidades |
| `Controller/NativeStatisticsController.php` | Consulta e apresentação autorizada das estatísticas adaptadas |
| `Controller/TicketMassActionController.php` | Coordena seleção, revisão, execução e resultado coletivo |
| `Controller/TicketInteractionController.php` e `Controller/TicketTemplateController.php` | Edição de interações e aplicação de modelos |
| `Controller/AuditController.php` e `Controller/AuditProfileController.php` | Consulta/exportação da auditoria e administração de seus direitos |
| `Controller/ConfigController.php` | Controla configurações, modos suportados e auditoria de alterações |
| `Controller/ContextController.php` | Controla perfil e entidade |
| `Controller/FormController.php` | Controla formulários, confirma a audiência no servidor e entrega somente a projeção correspondente |
| `Controller/KnowledgeController.php` | Controla conhecimento |
| `Controller/MenuController.php` | Monta a navegação permitida |
| `Controller/PlaybookController.php` | Controla playbooks |
| `Controller/PortalController.php` | Controla a entrada do portal e o redirecionamento anônimo ao login nativo |
| `Controller/SavedTicketSearchController.php` | Lista e gerencia pesquisas salvas |
| `Controller/TicketController.php` | Controla lista, detalhe, criação e ações de chamados |
| `Controller/TicketResultController.php` | Entrega páginas de resultados por contrato JSON autenticado, vinculado ao contexto e sem cache |
| `Controller/TicketResourceSelectorController.php` | Entrega opções paginadas dos provedores fechados de recursos de chamados |
| `Controller/TicketSearchValueController.php` | Controla valores remotos da pesquisa |
| `Presenter/FormExperiencePresenter.php` | Separa estados públicos de diagnósticos administrativos, limita metadados e valida ações locais |
| `Presenter/TicketSearchSummaryPresenter.php` | Produz o resumo acessível da consulta aplicada |
| `Presenter/TicketTagColorPresenter.php` | Preserva cor válida das etiquetas e escolhe texto com maior contraste calculado |
| `View/View.php` | Renderiza templates com dados controlados |
| `View/NativeInteractionAssets.php` | Carrega o cabeçalho de recursos do GLPI sem acrescentar a navegação convencional ao portal |

### Templates `templates/`

| Arquivo | Finalidade |
|---|---|
| `layout/header.php` e `layout/footer.php` | Estrutura, navegação, ativos e rodapé comuns |
| `portal/index.php`, `portal/login.php` e `portal/faq.php` | Entrada, autenticação e FAQ |
| `tickets/list.php` | Busca, pesquisas salvas, resumo e tabela de chamados |
| `tickets/create.php` | Criação assistida |
| `tickets/detail.php` | Detalhe e linha do tempo |
| `tickets/mass-action.php` | Etapas e resultado das ações em massa |
| `tickets/interaction-edit.php` | Edição de interação reconhecida |
| `tickets/tags.php` e `tickets/clipboard-attachment.php` | Etiquetas e controles opcionais de anexos colados |
| `manual/index.php` | Renderização comum das apresentações contextual, completa e autônoma |
| `statistics/index.php` e `cockpit/statistics-entry.php` | Consulta adaptada e acessos às estatísticas centralizados no Cockpit |
| `config/features.php` | Liberação gradual com revisão e confirmação |
| `playbooks/batch.php` | Revisão editorial de propostas em lote |
| `audit/index.php` | Consulta autorizada dos eventos de auditoria |
| `forms/index.php` e `forms/render.php` | Catálogo e preenchimento em linguagem funcional; diagnósticos administrativos aparecem recolhidos depois da tarefa |
| `knowledge/index.php` | Base de conhecimento |
| `chatbot/index.php` | Interface conversacional |
| `cockpit/index.php` | Indicadores operacionais |
| `playbooks/index.php` | Playbooks e sugestões |
| `config/index.php` | Configuração administrativa, inclusive a política de entrada e o aviso estático de acessibilidade no login |
| `errors/permission.php` e `errors/unavailable.php` | Erros seguros de permissão e indisponibilidade |

### Ativos, traduções e banco

| Arquivo/pasta | Finalidade |
|---|---|
| `assets/css/glpiacessivel.css` | Estilos compartilhados |
| `assets/css/portal.css` | Layout do portal |
| `assets/css/manual.css` | Apresentação documental, foco, escala de títulos, temas e impressão |
| `assets/css/ticket-tags.css` | Apresentação textual e visual das etiquetas |
| `assets/css/a11y-audit.css` | Interface da auditoria local |
| `assets/js/glpiacessivel.js` | Comportamentos acessíveis, busca e melhoria progressiva guardada do formulário nativo incorporado |
| `assets/js/login-accessibility-notice.js` | Reposiciona a nota depois do submit oficial, sem ler campos, com fallback na área do hook |
| `assets/js/ticket-results.js` | Carrega resultados assíncronos, descarta respostas antigas e preserva o fallback nativo |
| `assets/js/remote-resource-selector.js` | Combobox único, paginado e acessível para recursos de chamados |
| `assets/js/ticket-mass-actions.js` | Interação progressiva da seleção e das ações coletivas |
| `assets/js/ticket-clipboard-attachments.js` e `assets/js/ticket-input-safety.js` | Colagem opcional, seleção de anexos e proteção contra arraste inadequado, sem substituir validações nativas |
| `assets/js/ticket-id-copy.js` | Cópia dos IDs selecionados, com alternativa manual |
| `assets/js/feature-release.js` e `assets/js/editorial-batch.js` | Interação progressiva da liberação e da revisão editorial |
| `assets/js/a11y-audit.js` | Execução local do Axe, com timeout, separação de resultados e detalhes técnicos limitados sem persistência |
| `assets/images/readme/` | Capturas públicas da documentação |
| `resources/manual/pt-BR.json` | Fonte editorial única e metadados do manual |
| `resources/manual/images/` | Figuras e manifesto de integridade do manual |
| `public/assets/manual/images/` | Figuras publicadas para o manual integrado |
| `assets/vendor/axe-core/` | axe-core e licenças inventariadas |
| `public/assets/` | Cópias publicadas e ativos opcionais de voz |
| `locales/glpiacessivel.pot` | Catálogo mestre de mensagens |
| `locales/pt_BR.po` e `locales/pt_BR.mo` | Português do Brasil |
| `locales/en_GB.po` e `locales/en_GB.mo` | Inglês britânico |
| `sql/install.php` | Cria/atualiza estruturas próprias |
| `sql/uninstall.php` | Remove estruturas conforme política do plugin |

## Arquivos de desenvolvimento, qualidade e distribuição

| Arquivo/pasta | Finalidade |
|---|---|
| `tests/unit/` | Testes isolados de contratos, serviços e apresentação |
| `tests/integration/` | Testes de colaboração entre camadas |
| `tests/browser/` | Testes Puppeteer de teclado, foco e componentes |
| `phpunit.xml` | Configuração PHPUnit |
| `phpstan.neon` | Configuração PHPStan |
| `phpcs.xml` | Padrão PHP_CodeSniffer |
| `package.json` e `package-lock.json` | Ferramentas JavaScript de teste |
| `tools/build-release.ps1` | Gera o pacote de distribuição |
| `tools/verify-release.ps1` | Verifica o pacote gerado |
| `tools/compile-locales.ps1` | Compila catálogos Gettext |
| `tools/i18n-audit.ps1` | Verifica consistência das traduções |
| `tools/a11y/` | Captura autenticada e execução Pa11y |
| `tools/homologation/` | Preparação de massa sintética de homologação |
| `tools/homologation/build-manual-html.php` | Exporta o manual autônomo pela mesma fonte editorial e pelo mesmo template |
| `tools/homologation/compare-installed-release-files.ps1` | Confere os arquivos instalados contra o pacote aprovado, por hash |
| `tools/phpstan/` | Stubs de compatibilidade com GLPI |
| `README.md` e `README.en.md` | Apresentação e instalação |
| `CHANGELOG.md` | Histórico funcional das versões |
| `SECURITY.md` | Política de segurança e reporte |
| `CONTRIBUTING.md`, `DCO.md` e `AUTHORS.md` | Colaboração, declaração de origem da contribuição e autoria |
| `LICENSE`, `LICENSE_POLICY.md` e `THIRD_PARTY_NOTICES.md` | Licenças e conformidade de dependências |
| `CITATION.cff` | Citação acadêmica do software |

## Operação e manutenção

- Instalar sempre o ZIP completo e executar a atualização de plugins do GLPI.
- Limpar caches do GLPI e do navegador quando uma versão alterar CSS ou JavaScript.
- Não copiar apenas arquivos isolados entre versões.
- Manter backups do banco e do diretório de plugins antes da atualização.
- Repetir homologação com perfis, entidades, recursividade, GLPI 10/11, teclado e leitores de tela representativos.
- Conferir `VERSION`, versão registrada no GLPI, epoch dos ativos e checksum do pacote; o nome da pasta, sozinho, não comprova a atualização.
- Revisar módulos, liberação por perfil e dependências sem confundir configuração visual com autorização nativa.
- Consultar a [nota da beta.62](release_0.4.18-beta.63.md), o [relatório correspondente](test_execution_0.4.18-beta.63.md) e os guias funcionais para condições e limitações; registros históricos não substituem o estado mais recente.
- Distinguir uma revisão exclusivamente documental de uma mudança de runtime: ela exige novo checksum e rastreabilidade do pacote, mas não cria funcionalidade nem altera regras nativas.

## Referências de uso e validação

- [Manual contextual e completo](guia_manual_contextual.md).
- [Liberação de funcionalidades](guia_liberacao_funcionalidades.md).
- [Etiquetas acessíveis](guia_etiquetas_acessiveis.md).
- [Estatísticas acessíveis](guia_estatisticas_acessiveis.md).
- [Escopo da beta.62](release_0.4.18-beta.63.md) e [testes e pendências da entrega](test_execution_0.4.18-beta.63.md).

A revisão deste arquivo não modifica código de execução, consultas, SQL, esquema, permissões ou regras nativas. Recursos descritos de forma condicionada continuam exigindo sua liberação, dependências e autorização no contexto efetivo.

## Coerência da edição na beta.59

A linha do tempo e a tela de edição distinguem conteúdo formatado, texto simples e somente visibilidade. Os três caminhos preservam os formulários próprios e os campos apresentados pelo portal. A falha do editor formatado não aciona silenciosamente o editor simples. A lista de documentos reaproveita a leitura nativa autorizada já usada na linha do tempo, sem SQL novo. Na administração, a prévia mostra a interseção das opções por perfil e combinações incompletas, sem ativação automática. A edição cobre texto, imagens e visibilidade disponíveis, sem prometer outros atributos da tarefa. Uma imagem inserida pode ter propriedades alteradas no editor; um arquivo apenas anexado não entra automaticamente no texto nem tem seus pixels alterados. O manual 3.11 explica esses percursos e o retorno ao chamado do portal após salvar.
