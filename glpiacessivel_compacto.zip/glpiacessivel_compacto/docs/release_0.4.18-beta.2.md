# GLPI Acessível 0.4.18-beta.2

Esta versão disponibiliza a preparação e execução de ações em massa na lista acessível, completando a integração que na beta.1 estava limitada à prova do executor. É um candidato validado nos GLPI 10.0.10 e 11.0.7 locais; não representa aprovação no ambiente TRF nem certificação de acessibilidade.

## Como usar as ações em massa

1. Na lista de chamados, marque os chamados desejados. “Selecionar todos os chamados desta página” não seleciona outras páginas.
2. Acione “Ações em massa”. A preparação só aceita IDs presentes na página validada pelo servidor.
3. Escolha a ação. Nesta versão, são apresentadas alteração de status e adição de participante quando oferecidas pelo GLPI ao perfil atual.
4. Preencha os parâmetros. Para participantes, escolha o papel, o tipo e um usuário ou grupo permitido pelo seletor nativo. Use a pesquisa e a paginação quando necessário.
5. Revise a ação, a quantidade, os IDs e os parâmetros. Confirme explicitamente antes de executar. É possível revisar parâmetros ou cancelar antes da execução.
6. Confira os contadores devolvidos pelo núcleo. Se houver continuação nativa, prossiga somente com os itens restantes.

Adicionar um grupo ou técnico não significa substituir os responsáveis anteriores, remover participantes ou executar o escalonamento de outro plugin. Exclusão, expurgo e fusão não são disponibilizados nesta interface.

Mudar a página, a pesquisa, os filtros, o perfil ou a entidade invalida a seleção e sua preparação. Se o resultado não puder ser confirmado, consulte os chamados e o histórico no GLPI antes de qualquer nova operação. Não há repetição automática nem promessa de reversão.

## Integração e proteção

O GLPI continua responsável pelo catálogo, pelos parâmetros, pelas permissões por chamado e pelas alterações. O plugin apresenta controles HTML acessíveis a partir dos formulários nativos, sem executar seus scripts no navegador nem criar um processador paralelo.

As mensagens geradas pela operação são apresentadas como texto escapado, limitadas a 20 mensagens de até 2.000 caracteres. Não são expostas mensagens antigas da sessão como se fossem resultado da operação atual.

A preparação tem validade curta e é vinculada à sessão, ao contexto e à página. A confirmação revalida o contexto, a visibilidade e o catálogo; o estado de execução é persistido antes da mutação para impedir reenvio. A continuação utiliza o identificador nativo, não repete o POST inicial.

O diagnóstico de origem HTTP e catálogo de entidades utiliza a auditoria existente, respeitando seus direitos e modo de funcionamento. Registra códigos conhecidos e versões, com deduplicação e limite de volume, sem cabeçalhos crus, cookies, tokens, URLs de chamados ou árvore de entidades. Falhas no diagnóstico não alteram a decisão de segurança.

## Instalação e limites

Versão: `0.4.18-beta.2`. Runtime epoch: `20261009-02`. Não há migração nova de esquema. A atualização usa o ciclo nativo de instalação e ativação, preservando configurações e dados.

Backups locais da beta.1 estão em `deployment_backups/0.4.18-beta.2-20261009`. Restaurar código não desfaz alterações de chamados realizadas pelo núcleo.

Permanecem necessários a avaliação manual com NVDA/Chrome/Firefox e a homologação coordenada do servidor TRF. O plugin não passa a confiar automaticamente em cabeçalhos encaminhados nem modifica a rota OpenShift. Outros minors do GLPI requerem validação própria.
