# Acessos flutuantes com ajuste de posição

Versão 0.4.18-beta.50, epoch `20261104-03`, manual 3.0, de 04/11/2026. Verificações do runtime concluídas no [registro da rodada](test_execution_0.4.18-beta.50.md), conforme o [plano](plano_icones_flutuantes_arraste_beta50.md). A validação da distribuição e seu checksum ficam no recibo externo, sem hash autorreferente neste documento.

## Apresentação sem faixa reservada

Os acessos de portal e chatbot voltam a flutuar sobre a página. Não há faixa inferior reservada, mudança do scrollport nativo, limitação artificial de altura dos painéis ou conversão dos ícones em cartões. Mantêm-se `split_default`, `split_reverse`, `stack_left` e `stack_right`, com os tamanhos configurados para a pilha.

O ajuste local usa um controle de movimento separado dos links originais, com nome “Opções de posição do portal acessível”, “Opções de posição do chatbot” ou “Opções de posição dos acessos flutuantes”. Arrastar por esse controle move o grupo. Um clique abre o painel não modal “Posicionar acessos flutuantes”, com quatro botões direcionais em passos de 8 pixels, desfazer último movimento, restaurar configurado e fechar. Uma pilha se move inteira; o ícone principal continua abrindo o mesmo destino.

As posições ficam somente nesta aba, em `sessionStorage`, sem nova preferência de banco ou alteração da configuração institucional. Restaurar retoma a disposição configurada; não altera permissões, disponibilidade ou escopo dos acessos.

A posição inicial pode encobrir um controle, inclusive Salvar. Esta entrega permite mover os acessos para liberar esse controle; não promete ausência universal de sobreposição na posição padrão. Nos quatro casos locais de detalhe, Salvar foi conferido e atingido pelo ponteiro depois do reposicionamento.

## Proteção do foco e limites

Quando um acesso encobrir um controle que recebeu foco, a guarda testa quatro cantos e move temporariamente somente o grupo obstrutor para uma posição segura, sem rolar o formulário nem salvar essa adaptação. Se nenhum canto couber, o grupo é suspenso temporariamente enquanto o foco precisar de proteção, conservando os caminhos alternativos de navegação. Não se promete simultaneamente visibilidade física permanente e ausência de obstrução em uma janela sem espaço.

Modais preservam sua própria gestão de foco e a suspensão dos acessos externos. O arraste não substitui o teclado: as ações de direção também são clicáveis e operáveis por teclado. O menu contextual nativo dos links e a rolagem por toque da página não devem ser capturados pelo controle de posição.

O reposicionamento depende de JavaScript. O acesso SSR existente continua sendo a alternativa sem script; não há promessa de dois acessos flutuantes operáveis nessa condição. Não há novo SSR ou SQL. Regras de negócio, permissões e recursos de voz permanecem preservados; além dos metadados/epochs, a alteração PHP limita-se às novas mensagens do catálogo I18n.

## Manual e verificação

O manual 3.0 preserva 45 assuntos e sete figuras nas apresentações contextual, completa e autônoma. O tópico geral de teclado e leitor também ensina a mover os acessos sem direitos administrativos ou experiência prévia com GLPI. Os rótulos e avisos novos usam o catálogo de tradução do plugin.

A rodada final passou em 149 testes de navegador isolados: 26 de arraste/posição, cinco de foco, 65 de layout e 53 de rolagem nativa sem reserva. O manual passou em 50 testes e a regressão existente de VLibras em dois; esta última não valida arraste do widget externo. As suítes PHP passaram em 2.724 testes e 20.729 asserções por execução em PHP 8.1.31 e 8.3.14, sem somar os dois runtimes como testes distintos.

A matriz final autenticada headless concluiu 16 combinações: dois GLPI, quatro rotas e larguras de 1366 e 320 pixels. Conferiu arraste por ações de mouse, mover para cima, desfazer, restaurar e início/meio/fim da rolagem nativa, com hashes do runtime final. Nos quatro detalhes, Salvar ficou atingível após mover os acessos. Os três casos adicionais da revisão — limites vazios, colisão no resize e restauração após blur para BODY — foram retestados e aprovados no runtime congelado.

O menu superior real também foi conferido no navegador interativo. No GLPI 11/8080, chamado 152 com depurador, “Mover para cima” ajustou os acessos sem abrir o portal e Salvar permaneceu atingível. No GLPI 10/8089, Self-Service na central de ajuda, uma única alça moveu a pilha como conjunto em passos de 8 pixels. O manual contextual e o completo apresentaram 3.0/beta.50 nos dois ambientes, com orientação geral de posição disponível ao usuário comum e sete figuras no completo.

As preferências temporárias dos ensaios foram restauradas para a apresentação vertical original, com `page_layout = NULL`. No GLPI 10, quatro campos de dashboard alterados pelo formulário nativo foram restaurados pelo modelo `User`, com guarda, hashes de conferência e vínculos inalterados. Não foram alterados chamados para concluir a verificação.

Não se reutilizam os totais da beta.49 nem se somam repetições. Permanecem pendentes NVDA/JAWS, ampliação operacional integral de texto 200%/zoom real 400% e aceite institucional. Não há declaração de certificação WCAG/eMAG/RGAA. O checksum final pertence ao recibo externo do pacote, não a este documento.
