# Versão 0.4.18-beta.43

O manual HTML 2.4 ajusta a escala dos títulos e a identificação de duas tarefas no capítulo de pesquisas salvas. Mantém as apresentações contextual, completa e autônoma, com os mesmos destinos de navegação.

## Alterações

- Os títulos H1 a H4 passam a usar tamanhos relativos ao texto do manual, acompanhando a preferência de tamanho da edição integrada. H5 e H6 já usavam essa relação. A hierarquia semântica dos títulos permanece igual.
- O índice local e os subtítulos de Pesquisas salvas passam a identificar “Definir ou retirar a pesquisa padrão” e “Renomear ou excluir uma pesquisa salva”. Os identificadores dos destinos são preservados, assim como as orientações de cada operação.

As 45 seções, as sete figuras, os créditos e as condições de envio, cancelamento, privacidade e disponibilidade são preservados. Os links continuam funcionando sem JavaScript e não executam ações de atendimento.

## Compatibilidade e distribuição

Esta entrega altera estilos e dois rótulos do manual, além dos metadados de versão. Não acrescenta SQL nem modifica consultas, permissões ou regras nativas. Mantém compatibilidade com GLPI 10 e 11. O manual contextual continua adaptado ao contexto confirmado; o completo mantém a consulta às demais orientações.

Os resultados desta entrega são registrados em [Execução dos testes da beta.43](test_execution_0.4.18-beta.43.md), separados dos resultados anteriores. O verificador exige manual 2.4, epoch `20261029-06`, documentos desta versão, títulos relativos ao texto e rótulos explícitos de pesquisas salvas. Os gates cumulativos e os mapeamentos históricos, inclusive 42→2.3, permanecem ativos.

A suíte PHP aprovou 2.502 testes e 19.028 asserções em cada runtime, PHP 8.1.31 e 8.3.14. Esses resultados não são somados entre runtimes nem aos subconjuntos proporcionais. Foram aprovados 54 testes distintos de navegador: 50 do manual e quatro da edição autônoma.

Quatro apresentações autenticadas, contextual e completa nos GLPI 10/8089 e 11/8080 locais, preservaram contexto, sumário e estados. Os sumários mantiveram 25/45 assuntos no GLPI 10 e 26/45 no GLPI 11. Os dois links refinados foram acionados com Enter e receberam foco nos quatro percursos.

A preferência de texto de 120% foi aplicada pelos controles do portal nos dois ambientes. Com o texto em 19,2 pixels, os títulos passaram a 38,4 pixels no H1, 29,76 no H2, 24 no H3, 21,12 no H4 e 19,2 no H5. Não houve transbordamento horizontal a 320 ou 1.280 pixels nessa preferência. Ao final, as preferências foram restauradas e o texto voltou a 16 pixels nos dois ambientes. Esse ensaio de preferência do portal não equivale ao zoom real do navegador.

A edição autônoma passou nas quatro combinações de largura e mídia de tela/impressão CSS, sem JavaScript nem acesso à rede. O HTML 2.4 tem 536.009 bytes e SHA-256 `7107333c34153296b3d8ef07d6d7a62c21773e0290e37a58b0bf9494bb9149dc`. A auditoria gettext aprovou 3.340 mensagens após a atualização dos cabeçalhos de versão e catálogos compilados.

Os testes de código e navegador não substituem ensaios com NVDA ou JAWS, avaliação com usuários iniciantes, ampliação real do navegador, impressão física ou aceite institucional. A distribuição deve preservar o ZIP da beta.42 e seu HTML autônomo 2.3.
