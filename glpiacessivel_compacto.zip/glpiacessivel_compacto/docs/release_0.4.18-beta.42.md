# Versão 0.4.18-beta.42

O manual HTML 2.3 permite localizar uma tarefa sem percorrer todo o conteúdo. A abertura oferece acesso ao sumário e ao primeiro percurso, e os capítulos mais extensos passam a ter índices locais. O conteúdo continua disponível nas apresentações contextual, completa e autônoma.

## Navegação e leitura

- O acesso visível ao sumário complementa o salto inicial para o conteúdo e os retornos ao final de cada capítulo.
- Os links por tarefa ajudam a abrir chamados, encontrar uma pesquisa, acompanhar um atendimento e consultar orientações. As trilhas por público levam aos capítulos correspondentes.
- Os índices locais de J-06, J-08 e Pesquisas salvas levam aos subtítulos existentes. Os destinos aceitam foco de teclado e mantêm a hierarquia de títulos.
- Os subtítulos menores acompanham o tamanho do texto. A alteração visual não promove títulos a outro nível semântico.
- Os links funcionam sem JavaScript, sem novas combinações de teclado e sem executar ações de atendimento.

## Conteúdo e compatibilidade

As 45 seções, as sete figuras e os créditos são preservados. As condições de envio, cancelamento, anexos, visibilidade e disponibilidade permanecem junto às tarefas. O manual contextual continua adaptado ao perfil e às funcionalidades disponíveis; o completo mantém o acesso às demais orientações. A edição autônoma reúne o conteúdo para consulta fora do GLPI.

Esta entrega altera navegação, apresentação e conteúdo editorial do manual, além dos metadados de versão. Não acrescenta SQL nem modifica consultas, permissões ou regras nativas. Mantém compatibilidade com GLPI 10 e 11. Consultar uma orientação não habilita uma funcionalidade nem concede acesso.

## Verificação e distribuição

Os resultados desta entrega são registrados em [Execução dos testes da beta.42](test_execution_0.4.18-beta.42.md), separados dos resultados anteriores. O verificador exige manual 2.3, epoch `20261029-05`, documentos desta versão, navegação inicial e índices locais, preservando os gates cumulativos e os mapeamentos históricos 39→2.0, 40→2.1 e 41→2.2.

A suíte PHP aprovou 2.500 testes e 18.969 asserções em cada runtime, PHP 8.1.31 e 8.3.14. Esses resultados não são somados entre runtimes nem aos subconjuntos proporcionais. Foram aprovados 52 testes distintos de navegador: 48 do manual e quatro da edição autônoma.

Quatro comparações autenticadas, contextual e completa nos GLPI 10/8089 e 11/8080 locais, preservaram contexto, sumário, estados e presença dos procedimentos. A navegação inicial e os três índices locais foram conferidos, com 20 links internos válidos. Em cada ambiente, cinco destinos e o retorno ao sumário receberam foco visível pelo teclado. As apresentações a 320 e 1.280 pixels não apresentaram transbordamento horizontal.

A edição autônoma passou nas quatro combinações de largura e mídia de tela/impressão CSS, sem JavaScript nem acesso à rede. Os 20 destinos dos índices locais foram acionados por Enter nos casos de tela. O HTML 2.3 tem 535.957 bytes e SHA-256 `c20bed38b92d14dbe3ca5ad95aaeb21ba347de262ed4fdaadae092378fa18dbb`.

A auditoria da fonte aprovou oito verificações: 276 arquivos protegidos, incluindo consultas, JavaScript e código de negócio, permaneceram intactos em comparação com a beta.41. Também foram preservados os 39 ativos de voz, a estrutura das 45 seções, as sete figuras e os créditos. A auditoria gettext aprovou 3.340 mensagens após a atualização dos cabeçalhos de versão e catálogos compilados.

Os testes automatizados e de navegador não substituem ensaios com NVDA ou JAWS, avaliação com usuários iniciantes, impressão física ou aceite institucional. A distribuição deve preservar o ZIP da beta.41 e seu HTML autônomo 2.2. A geração e a conferência do novo pacote são etapas separadas dos testes de fonte.
