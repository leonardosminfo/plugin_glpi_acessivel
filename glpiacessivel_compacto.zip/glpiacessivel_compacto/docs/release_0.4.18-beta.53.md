# Editor nativo e cartão de entrada configurável

Versão 0.4.18-beta.53, epoch `20261105-01`, de 05/11/2026. Manual: 3.1.

## Escopo entregue

Integração da edição formatada de acompanhamentos e tarefas já salvos com os recursos nativos disponíveis no GLPI 10 e 11, respeitando liberação separada, direitos e capacidades verificadas. A criação de novas interações mantém seus formulários atuais. A configuração do cartão “Interface acessível do GLPI” passa a prever os modos completo, compacto e oculto, sem confundir a visibilidade do aviso com a disponibilidade do portal ou do manual.

A edição formatada reutiliza o formulário nativo completo de acompanhamento ou tarefa: editor, campos autorizados, envio, CSRF, imagens e anexos seguem os recursos do próprio GLPI. O POST customizado do editor simples não passa a receber HTML ou uploads. Salvar pode levar ao chamado convencional conforme o comportamento nativo. A liberação específica começa desativada nas políticas existentes e também exige a edição de interações e os direitos nativos.

O cartão compacto mantém o título, os dois links e o atalho visível “Atalho: Ctrl+Alt+Shift+A.”. O modo oculto retira somente o aviso, preservando o acesso independente ao portal; o atalho nunca é a única alternativa de entrada.

Os caminhos seguros de contingência devem preservar conteúdo e regras nativas quando um recurso não estiver disponível. Arquivo selecionado, envio temporário e documento vinculado são estados distintos. Não há promessa de remoção geral de documentos já vinculados nem de suporte universal a todas as funções do editor convencional.

## Manual e preservação

O manual 3.1 utiliza a mesma fonte para leitura contextual, completa e exportação autônoma, preservando os 45 assuntos anteriores e sete figuras e adicionando um assunto dedicado à edição formatada (total de 46). Na leitura contextual, esse novo assunto depende da capacidade específica. Ler uma função não a libera nem concede direitos. Não foi introduzido SQL novo nem alteração de regras de negócio nativas.

## Verificação

PHP 8.1 e 8.3: 2.742 testes e 21.014 verificações aprovados em cada versão. Navegador: 85 testes aprovados. Ensaios autenticados de acompanhamento e tarefa realizados no GLPI 11/8080 e GLPI 10/8089, exclusivamente em registros sintéticos. As configurações temporárias foram restauradas. Escopo e limites em [Verificação da beta.53](test_execution_0.4.18-beta.53.md). Leitor de tela real, zoom operacional e aceite institucional exigem evidência própria. O checksum final pertence ao recibo externo do pacote.
