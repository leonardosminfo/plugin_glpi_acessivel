# GLPI Acessível 0.4.18-beta.29

Esta versão corrige a recuperação do formulário quando um anexo é recusado antes da gravação de um acompanhamento ou tarefa. O erro conhecido de preparação passa a identificar o problema, manter o rascunho na resposta atual e abrir a aba correspondente. No GLPI 10, a descrição da abertura reapresentada após erro de upload usa a intenção textual conferida pelo contrato nativo, sem transformar novamente entidades escritas como texto.

## Escopo da correção

A recusa de extensão continua delegada a `Document::isValidDoc`; erros de upload do PHP continuam impedindo o processamento. Não foram alterados tamanhos permitidos, extensões, direitos, modelos, estados ou regras do núcleo. Não há SQL novo ou modificação em TicketService/TicketRepository para esta correção.

Somente exceções tipadas conhecidas da preparação do upload entram na recuperação anterior à operação. O detalhe, a autorização e os catálogos são relidos e novos tokens são emitidos. O rascunho permanece apenas na resposta atual, sem gravação em sessão, autosave ou envio automático. Arquivos não são repopulados: devem ser selecionados novamente. Escolhas remotas não confirmadas pelo catálogo precisam ser revistas; não há promessa de restauração integral de seletores remotos.

O resumo do erro é focalizável, identifica o campo de anexos e mantém a aba de acompanhamento ou tarefa ativa. Falhas posteriores à tentativa nativa continuam no tratamento conservador anterior: resultado parcial ou incerto exige conferência antes de qualquer novo envio.

## Instalação e limites

Marcadores: `0.4.18-beta.29`, epoch `20261027-07`. Atualize pelo fluxo nativo, sem desinstalar ou alterar permissões. A beta.28 foi preservada. O manual HTML 1.8 mantém os procedimentos e as sete figuras; sua referência de cobertura acompanha esta versão.

Os ensaios distinguem recusa PHP de limite GLPI, seleção múltipla do navegador de diálogo real do sistema, controles ausentes por permissão de POST recusado, e automação de teste de leitor de tela. Consulte os [resultados e pendências](test_execution_0.4.18-beta.29.md). A entrega não encerra toda a estabilização nem homologa todos os patches GLPI 10/11.
