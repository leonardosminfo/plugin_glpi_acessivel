# GLPI Acessível 0.4.18-beta.39

Versão 0.4.18-beta.39, epoch `20261029-02`, manual 2.0. A implementação passou nos recortes locais registrados de GLPI 11.0.7/8080 e GLPI 10.0.10/8089. Os resultados não constituem aceite institucional ou certificação de acessibilidade.

## Manual para começar sem experiência anterior

O manual introduz chamado, status, requerente, técnico, observador, grupo, perfil e entidade antes dos procedimentos. Um primeiro percurso seguro ensina a conferir o contexto, localizar uma tarefa e reconhecer a diferença entre preparar, revisar e gravar. As instruções usam rótulos reais, navegação por teclado, nomes e estados a conferir, cancelamento e recuperação, sem depender de figuras ou posição visual.

O contexto integrado da leitura informa o perfil, a entidade, o escopo e o GLPI quando esses metadados estão confirmados na sessão. Valores ausentes têm orientação conservadora; não provocam buscas operacionais ou atribuição de direitos. Mudar a sessão em outra aba não reorganiza silenciosamente a leitura: é necessário reabrir ou recarregar o manual.

## Contextual completo e autônomo

O contextual prioriza as orientações conforme as verificações gerais existentes. O completo permanece acessível e contém também funções que podem estar indisponíveis ou não autorizadas. Ler um procedimento não habilita sua execução. Massa, edição, formulários e Tag conservam seus limites de autorização por item ou contrato.

A edição autônoma usa a mesma fonte editorial, mas é referência geral e não recebe identificação dinâmica da sessão. As jornadas e âncoras anteriores são preservadas. As sete figuras existentes mantêm propósito, alternativas e versões reais de captura, sem simular recaptura por atualização de metadados.

## Cobertura funcional e limites

A revisão completa a orientação das funções existentes: pesquisas salvas e padrão, gestão de roteiros, auditoria com seus direitos específicos, voz e referência administrativa. A [matriz de cobertura](matriz_cobertura_manual_2_0.md) distingue presença estrutural de procedimento didático e identifica os destinos do manual.

Não cria funcionalidades para preencher uma lacuna editorial. Não acrescenta SQL, novas consultas de negócio, privilégios ou mudanças nas regras nativas do GLPI. O manual não inicializa cabeçalhos operacionais, lista chamados, lê eventos de auditoria ou inspeciona autorização por registro para selecionar instruções.

## Validação

O [plano aprovado](plano_manual_contextual_didatico_pos_beta38_2026-10-29.md) foi implementado com regressões proporcionais e ensaios nos dois núcleos. O [relatório da entrega](test_execution_0.4.18-beta.39.md) detalha os recortes e suas limitações:

- 2.490 testes e 18.367 asserções aprovados em cada runtime de teste PHP 8.1.31 e 8.3.14, sem somar os runtimes como casos novos.
- 58 testes distintos de navegador aprovados: 40 do manual, 14 da entrada/login e quatro da edição autônoma. Rodadas anteriores falhas e subconjuntos não são somados novamente.
- Na interface autenticada, manual contextual/completo conferido em três contextos legítimos: autoatendimento sintético no GLPI 11, Super-Admin e Self-Service no GLPI 10. Foram observados perfil, entidade e escopo, navegação, Ajuda e reflow a 320 CSS px; o completo manteve os 45 assuntos.
- A edição autônoma foi aberta por `fileURL` real, sem JavaScript, offline e com rede externa bloqueada, em 320/1280 px e mídias de tela/impressão. As 45 seções coincidiram com o texto da fonte editorial atual, os destinos locais foram válidos e as sete imagens incorporadas foram decodificadas, sem transbordamento horizontal. O percurso pelo sumário e seu retorno passou na mídia de tela.
- Os 3.340 textos dos catálogos gettext foram auditados; somente o cabeçalho de versão foi alterado nos POT/PO, preservando todas as mensagens e traduções anteriores. Os MO foram recompilados pelo procedimento oficial.

O ensaio de mídia de impressão verifica apresentação CSS, não paginação completa ou impressão física. O teste autenticado com JavaScript desativado não foi realizado por falta de controle suportado na sessão: fixtures e HTML autônomo não o substituem. Os demais perfis personalizados não foram presumidos a partir dos três contextos exercitados.

Leitor de tela real, aprendizagem com usuários iniciantes, ampliação real adiada pelo usuário, condições institucionais e demais frentes da estabilização permanecem separadas. Os ZIPs anteriores são preservados; a verificação do pacote e da cópia instalada é uma etapa própria da distribuição.
