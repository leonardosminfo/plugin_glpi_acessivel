# GLPI Acessível 0.4.18-beta.17

## Etiquetas na listagem e na pesquisa

A listagem pode apresentar a coluna opcional **Etiquetas** e pesquisar uma etiqueta exata. Os dois recursos possuem liberações independentes, inicialmente desativadas. As treze configurações anteriores são preservadas; liberar um recurso não concede direitos nativos nem habilita o outro.

A coluna recebe dados estruturados de até dois lotes públicos, limitados aos chamados autorizados da página e às etiquetas retornadas. Não executa leitura individual por chamado, não interpreta HTML e não altera a hidratação existente. Mantém os nomes completos, o fundo original válido, texto contrastante e cores forçadas. Ausência comprovada e indisponibilidade têm mensagens diferentes. Não oferece ordenação por etiqueta.

O filtro usa o identificador nativo e a igualdade do Search, com seleção remota acessível. Digitar ou selecionar não dispara a consulta: é necessário acionar **Pesquisar**. O critério integra o estado validado da pesquisa avançada, preservando o agrupamento lógico, a paginação e as pesquisas salvas. Expressões complexas não são reduzidas silenciosamente a uma seleção simples.

## Proteções e compatibilidade

Tag ausente, versão não reconhecida ou direito insuficiente não acrescenta seletor. Uma falha somente na coluna preserva os chamados. Uma pesquisa que depende de uma etiqueta indisponível é bloqueada sem descartar o critério ou ampliar os resultados. A capacidade é revalidada ao executar, inclusive em pesquisas nativas salvas e após mudanças de liberação ou contexto.

A chamada do seletor remoto usa os cabeçalhos AJAX nativos exigidos pelo CSRF do GLPI 11 e mantém o campo de token compatível com o GLPI 10. Não há desativação de proteção de origem, sessão, IDOR ou CSRF.

A integração ativa da coluna usa Tag 2.14.8 com GLPI 11. O contrato Tag 2.12.6 na faixa GLPI 10 compatível é reconhecido para o filtro, mas sua coluna em lote permanece indisponível: o formatador dessa versão faz leituras individuais internamente. O GLPI 10.0.10 local não atende ao mínimo dessa versão do Tag e permanece sem ele. Não foi instalado um pacote antigo vulnerável para contornar o requisito. Consulte o [guia de etiquetas](guia_etiquetas_acessiveis.md) antes de definir o piloto.

Continuam fora desta etapa: gravação de etiquetas no portal, ações em massa de etiquetas, ordenação por etiqueta e seleção múltipla simplificada. Testes automatizados não certificam conformidade integral com WCAG, eMAG ou RGAA.

Atualize pelo procedimento nativo, sem desinstalar. O pacote não inclui o Tag, não acrescenta SQL ou migração estrutural e não altera o core. O marcador de runtime é `20261019-08`. O [registro de testes](test_execution_0.4.18-beta.17.md) informa os cenários efetivamente executados.
