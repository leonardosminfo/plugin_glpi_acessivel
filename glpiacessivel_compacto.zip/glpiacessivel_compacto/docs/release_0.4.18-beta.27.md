# GLPI Acessível 0.4.18-beta.27

Esta candidata local adaptou a entrada textual da edição da descrição ao bootstrap do GLPI 10. O caso do ampersand passou, mas o caso com apóstrofo foi recusado pelo núcleo sem efeito persistido. A candidata não foi aprovada como entrega final e foi substituída pela beta.28, com ajuste restrito da representação das aspas no GLPI 10. Este registro preserva o resultado intermediário, não afirma que os dois defeitos estavam corrigidos na beta.27.

## Contrato de entrada e gravação

Somente no GLPI 10.0.x, a ação de edição confere a descrição original preservada pelo bootstrap contra o POST processado, usando a transformação pública nativa no sentido direto. Ausência ou divergência dessa origem, formato não suportado, HTML real e representações ambíguas são recusados antes da atualização. Não há decodificação genérica, stripslashes próprio, sentinela ou leitura de cookies.

O texto é serializado pelo formato existente — texto escapado e quebras — antes do escape público exigido pelo modelo legado. A releitura estrita compara o registro com a intenção textual, sem tentar inverter uma transformação que pode perder distinções. O GLPI 11 mantém seu caminho existente.

CSRF, confirmação, revisão, perfil, entidade, regras, modelos e hooks continuam sob os mesmos verificadores. O plugin não cria SQL nem altera o núcleo. Uma tentativa não é repetida automaticamente quando a persistência não pode ser confirmada.

## Atualização e limites

Marcadores: `0.4.18-beta.27`, epoch `20261027-05`. Atualize pelo fluxo nativo, sem desinstalar. A beta.26 permanece preservada. O manual HTML 1.8 mantém os mesmos procedimentos e figuras, com referência à nova versão.

A adaptação não promete representar qualquer cadeia possível por todos os patches do GLPI 10. Quando o helper nativo considera uma sequência de barras já escapada e a origem segura do payload não pode ser estabelecida, o portal oferece a continuação convencional sem gravar. Os demais testes de transporte e concorrência da estabilização continuam separados.

Os ensaios e a situação de aceite estão no [relatório da versão](test_execution_0.4.18-beta.27.md).
