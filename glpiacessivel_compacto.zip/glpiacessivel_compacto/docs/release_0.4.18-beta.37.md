# GLPI Acessível 0.4.18-beta.37

Versão 0.4.18-beta.37, epoch `20261028-07`; GLPI 11.0.7 no 8080 e GLPI 10.0.10 no 8089. Reteste local concluído nos cenários registrados; não representa encerramento da estabilização nem aceite institucional.

## Divergência comprovada e escopo

Na Etapa 3, Exibição dos resultados, o campo Agrupamento apresentava largura zero a 320 CSS pixels e seu centro ficava coberto pelo botão Escolher colunas, inclusive quando recebia foco por Tab. A divergência foi reproduzida nos dois ambientes locais. O campo Itens por página herdava uma área de grade nomeada ausente no contêiner atual, produzindo trilhas implícitas.

A correção é restrita ao CSS desse conjunto de controles. Não altera os nomes ou valores enviados, critérios, operadores, ordenações, agrupamento, seleção de colunas, ordem do DOM, JavaScript de produção, SQL, permissões ou regras nativas. O uso legítimo de áreas nomeadas nos outros layouts deve permanecer preservado.

## Reteste e limites

O reteste autenticado passou nas doze combinações de dois ambientes, larguras reais de 320/1280 CSS pixels e três temas: claro, noturno e alto contraste. Agrupamento conservou largura útil e seu centro recebeu o próprio controle, sem sobreposição com Colunas. Os valores de itens por página, agrupamento e seis colunas permaneceram iguais; preservou-se a ordenação existente de cada cenário, sem impor que ambos os ambientes partissem da mesma configuração. O diálogo de colunas abriu e seu cancelamento por Escape devolveu o foco ao acionador nos dois ambientes.

Os resultados e condições efetivamente conferidos estão no [relatório desta rodada](test_execution_0.4.18-beta.37.md), com a matriz `matrix-display-after37.json`. Esse recorte não encerra toda F4/F8, a validação institucional ou a semântica de todas as pesquisas nativas.

A triagem do VLibras é separada: a sobreposição interna da grade não foi atribuída ao widget. Antes da atualização, seu acionador real foi examinado nos dois ambientes; a cobertura parcial observada, de aproximadamente 14 pixels, era recuperável por rolagem e os controles examinados continuaram utilizáveis. Isso não aprova todos os textos ou estados possíveis nem transforma uma cobertura parcial em correção entregue.

Após o ajuste, o acionador do GLPI 11 manteve o percurso por Tab. A releitura do GLPI 10 apresentou o estado de espera `skipped-cooldown`, sem os hosts/scripts remotos do widget naquele momento; não foi limpa a memória local para forçar seu carregamento. Portanto, a ausência do widget nessa releitura não comprova correção da obstrução ou funcionamento da tradução. Nenhum JavaScript do VLibras foi alterado. Sua disponibilidade externa, tradução remota, comportamento integral com leitor e aceite institucional não foram homologados por esta rodada.

## Manual e preservação

O manual permanece na versão 1.8. Somente a cobertura passa à beta.37; procedimentos, figuras, alternativas e versões reais das capturas são preservados. As edições contextual e completa usam a mesma fonte editorial, com exportação autônoma pelo processo oficial. Exportar novamente não equivale a uma nova homologação offline ou autenticada sem JavaScript.

Pacotes publicados anteriores são preservados. Sem novas regras, SQL ou alteração de permissões para produzir aprovação. Leitor real, texto a 200%, zoom real a 400% e dependências institucionais mantêm suas classificações próprias.
