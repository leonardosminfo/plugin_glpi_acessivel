# Imagens de treinamento no manual do GLPI Acessível

A versão 0.4.18-beta.20 acompanha o manual HTML 1.4 com exemplos visuais da preparação dos filtros, da pesquisa aplicada, da descrição e navegação do chamado, dos campos de tarefa e da revisão de mudança de status em massa. Os exemplos usam somente informações sintéticas do ambiente local.

As imagens complementam os procedimentos. Cada figura possui alternativa textual, dimensões e legenda que identifica o contexto capturado; as instruções de teclado, confirmação e recuperação permanecem fora da imagem. As capturas feitas na beta.19 mantêm essa identificação, sem serem apresentadas como uma nova interface.

A fonte editorial é compartilhada pelo manual contextual, pelo completo e pela edição HTML autônoma. As figuras seguem a disponibilidade do procedimento no contexto verificado; no completo permanecem junto de suas condições de uso. A edição autônoma incorpora as imagens e continua funcionando sem conexão.

A figura da ação em massa ilustra somente a revisão, com a confirmação desmarcada. Não representa uma ação executada e não implica que a funcionalidade esteja liberada em todas as instalações.

Os acessos pela Ajuda e pelo cartão inicial permanecem. As treze jornadas, os identificadores dos capítulos, o crédito de elaboração e as quinze liberações são preservados. Não há SQL novo, alteração de regras de atendimento, ampliação de permissões ou mudança no núcleo do GLPI.

Os arquivos anteriores da beta.19 e do manual 1.3 permanecem disponíveis. O registro de testes desta versão descreve a conferência das figuras, da apresentação contextual e completa e da compatibilidade com GLPI 10 e 11.
