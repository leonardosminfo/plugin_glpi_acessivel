# Versão 0.4.18-beta.40

O manual HTML 2.1 distingue a leitura autônoma das edições integradas ao GLPI. Na edição autônoma, uma nota “Sobre este manual” explica que as funções disponíveis dependem de perfil, entidade, configuração e componentes da instalação. O texto continua sendo uma referência completa, sem confirmar permissões ou habilitar recursos.

## Alterações

- A exportação identifica explicitamente o modo autônomo. Ausência de URL, indisponibilidade de dados da sessão ou falha de contexto não ativam esse modo.
- A edição autônoma não repete os avisos de disponibilidade por assunto nem as instruções sobre troca de perfil ou entidade em outra aba.
- As leituras integradas contextual e completa conservam os avisos e o bloco “Contexto desta leitura”.
- Os 45 assuntos, as sete figuras, as descrições acessíveis e as orientações para quem não conhece o GLPI permanecem disponíveis.
- A orientação inicial diferencia o contexto da edição integrada da nota geral da edição autônoma.

## Compatibilidade e limites

A alteração é de apresentação documental e metadados. Não acrescenta SQL nem altera consultas operacionais, permissões, regras nativas ou contratos de negócio. Mantém compatibilidade com GLPI 10 e 11. O catálogo contextual e o controlador integrado não precisam mudar para identificar a exportação autônoma.

Leitura com leitor de tela real, impressão física e aceite institucional continuam sendo validações distintas. Testes de mídia de impressão não equivalem a homologação de paginação ou de uma impressora. Resultados históricos da beta.39 não substituem os retestes desta versão.

## Verificação

Os resultados desta entrega estão em [Execução dos testes da beta.40](test_execution_0.4.18-beta.40.md). O verificador exige o manual 2.1, o epoch `20261029-03`, os documentos desta versão e os contratos de apresentação autônoma, mantendo os gates cumulativos e os metadados históricos.

- A suíte PHP aprovou 2.494 testes e 18.546 asserções em cada runtime, PHP 8.1.31 e 8.3.14. Os resultados não são somados entre runtimes.
- Foram aprovados 46 testes distintos de navegador: 42 do manual e quatro da edição autônoma. Os 14 testes de entrada executados na beta.39 não foram reutilizados nesta contagem.
- Quatro comparações autenticadas, contextual e completa nos dois GLPI locais, preservaram assuntos, estados, avisos, procedimentos, sumário e contexto entre as versões 39 e 40, alterando somente os metadados previstos. No GLPI 10, o perfil Self-Service na entidade raiz apresentou 25 assuntos no sumário contextual e 45 no completo, com um estado não confirmado. No GLPI 11, o perfil sintético de teste no escopo de todas as entidades apresentou 26/45 assuntos, com dois estados não confirmados. Não houve troca de perfil ou configuração para essas comparações.
- A edição autônoma manteve os 45 assuntos e as sete imagens. Seu SHA-256 é `b55775566b519bbc30926bff01e80fea3e5c13088e8fcc609eb5090b8fc5591e`.
- A comparação da fonte com a beta.39 preservou 278 arquivos protegidos e 39 ativos de voz. A auditoria gettext aprovou 3.340 mensagens, com alteração apenas dos cabeçalhos de versão e recompilação dos catálogos.

A distribuição deve preservar o ZIP da beta.39 e seu HTML autônomo 2.0. A geração e a conferência do novo pacote são etapas separadas dos testes de fonte.
