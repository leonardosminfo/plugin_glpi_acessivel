# GLPI Acessível 0.4.18-beta.4

A curadoria do chatbot passa a examinar a base nativa em lotes finitos e gerar propostas para revisão humana. Artigos sem visibilidade nativa configurada são tratados como não publicados; falta de acesso, falha de leitura e expiração não são confundidas com retirada editorial.

## Como utilizar

Na administração de roteiros, escolha publicação, FAQ, tamanho do lote e limite total. Inicie a varredura e continue os lotes pela própria tela. Pausar ou cancelar não aprova nem exclui propostas. A fila possui filtros por ação e estado; confira fontes, texto, alvo e revisão antes de confirmar uma decisão. Propostas de revisão individual não são publicadas diretamente.

Uma retirada de publicação gera proposta de inativação somente dos roteiros vinculados. O chatbot revalida as fontes antes de recomendar e responder, mesmo sem nova varredura. Alterações de texto exigem revisão; reativação permanece uma decisão humana. Intenções gerais não são desligadas automaticamente.

## Segurança das decisões

Conteúdo, dependências e aprovação são persistidos atomicamente, com revisão e controle de concorrência. Confirmações antigas não aprovam propostas posteriormente editadas. Roteiros legados sem procedência verificada ficam bloqueados até revisão explícita; roteiros manuais independentes continuam disponíveis. Importações com fontes exigem mapeamento local e revisão.

Curadoria exige configuração administrativa e administração nativa da base. Leituras respeitam a autorização atual do GLPI e seus hooks. O inventário não concede acesso futuro ao usuário do chatbot.

## Instalação e limites

Versão 0.4.18-beta.4, runtime 20261010-04. A migração V0007 é aditiva e altera somente tabelas do plugin. Utilize o ciclo nativo de atualização; desinstalar pode remover dados do plugin. Restauração apenas do código não desfaz a migração nem decisões editoriais.

Esta entrega usa texto dos artigos, sem OCR, anexos, Tika, Docling, IA externa, execução agendada ou publicação automática. Alternativas com resumo misto permanecem bloqueadas quando qualquer fonte necessária não puder ser validada; não há recorte automático de trechos. A transição antiga de roteiro existente para pendente não está disponível, evitando exclusão ou duplicação de histórico.

O gerador produz rascunhos heurísticos, não respostas semanticamente certificadas. A busca mantém limites de candidatos e precisa de avaliação com perguntas reais. Os núcleos locais de referência são GLPI 10.0.10 e 11.0.7; homologação dos patches, regras de publicação e plugins institucionais, testes de carga e avaliação manual com leitores de tela continuam necessários.

Consulte [Testes locais](test_execution_0.4.18-beta.4.md).
