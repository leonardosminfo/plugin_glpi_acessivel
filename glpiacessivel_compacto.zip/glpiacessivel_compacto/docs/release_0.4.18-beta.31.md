# GLPI Acessível 0.4.18-beta.31

Esta versão remove uma normalização adicional da leitura da descrição e das interações do chamado. O conteúdo armazenado passa intacto ao renderizador público nativo do GLPI, como na interface convencional. Literais de entidades, marcação escrita como texto e espaços pré-formatados deixam de ser reinterpretados pelo normalizador de rótulos do portal.

## Escopo da correção

O ajuste é restrito a `RichTextFormatter`. Mantém `getEnhancedHtml` com a opção nativa de galeria, o caminho alternativo `getSafeHtml` e a saída textual escapada se a API estiver ausente ou falhar. Não substitui o sanitizador e não altera conteúdo armazenado, serialização de gravação, campos textuais do editor, normalização de títulos, consultas, permissões, hooks ou regras. Não há SQL novo.

A reprodução ocorreu em chamados sintéticos criados pelo editor convencional no GLPI 11.0.7/8080 e GLPI 10.0.10/8089. A descrição e um acompanhamento em cada núcleo demonstraram a interpretação adicional. Os casos A/B de gravação aprovados anteriormente não foram regravados para corrigir a apresentação.

## Versão e limites

Marcadores: `0.4.18-beta.31`, epoch `20261028-01`. A beta.30 publicada é preservada. O manual HTML 1.8 conserva procedimentos, imagens e suas versões reais de captura; somente a referência de cobertura acompanha a entrega.

O processamento de galeria continua nativo. Esta correção não resolve a limitação de alternativa textual da galeria vinculada observada no GLPI 10 nem encerra concorrência, transporte, zoom ou ensaio real com leitor de tela. Consulte os [testes e limites](test_execution_0.4.18-beta.31.md) e o [quadro de estabilização](status_estabilizacao_2026-10-27.md).
