# Liberação de funcionalidades

## Finalidade

As novidades podem ser disponibilizadas gradualmente sem alterar as permissões do GLPI. A configuração vale para a instalação. Cada recurso pode ficar desativado, liberado para perfis selecionados ou liberado para todos os usuários já autorizados.

Correções de segurança, integridade e acessibilidade continuam aplicadas. Desativar uma novidade não restaura uma versão antiga do plugin.

## Abrir a administração

Abra a configuração do GLPI Acessível e acione **Liberação de funcionalidades**. A página exige o direito administrativo de configuração do GLPI. Seu salvamento é independente dos ajustes de módulos, nome do chatbot e botões flutuantes.

O catálogo de perfis exige também autorização nativa para visualizar perfis. Se não puder ser carregado ou validado, a página explica a indisponibilidade e não converte a seleção para Todos. O limite do catálogo é de mil perfis; instalações acima dele exigem avaliação antes de usar a seleção por perfis.

O envio do formulário também depende dos limites do PHP, como `max_input_vars` e `post_max_size`. Mil perfis no catálogo não significam dez mil seleções simultâneas suportadas pelo servidor. Formulários incompletos são recusados antes da revisão; se uma seleção extensa não puder ser revisada, peça à administração do ambiente que confira esses limites. Não presuma que parte das escolhas foi salva.

## Escolher um estado

- **Desativada:** impede novas operações específicas do recurso no portal.
- **Liberada para perfis selecionados:** exige selecionar pelo menos um perfil válido. Vale o perfil ativo, não qualquer perfil que a pessoa possua.
- **Liberada para todos os usuários autorizados:** não restringe o público adicionalmente; as regras, os módulos e as permissões nativas continuam obrigatórios.

Não existe exceção automática para administradores. Uma pessoa poderá configurar o piloto sem poder utilizá-lo no seu perfil ativo. Renomear um perfil não altera sua seleção por ID; remover e recriar um perfil não transfere a liberação para o novo ID.

## Revisar e confirmar

1. Escolha o estado de cada funcionalidade.
2. No modo por perfis, marque os perfis desejados nas caixas de seleção. A lista não se aplica aos outros modos.
3. Acione **Revisar alterações**. Nada foi salvo nessa etapa.
4. Confira os estados Antes e Depois, os perfis e as consequências indicadas.
5. Acione **Confirmar liberação**, ou **Voltar para editar**.

A revisão vale por dez minutos e está vinculada ao usuário, perfil e entidade. Mudança de contexto, revisão expirada ou alteração da configuração vigente exigem nova conferência. Não reenvie automaticamente uma confirmação cuja gravação não pôde ser comprovada: recarregue e confira os valores atuais.

## Recursos controlados

São quinze opções independentes: status em massa, adição de participantes em massa, editor de acompanhamentos e tarefas, colagem de imagens, prévia da descrição, ordenação pelos cabeçalhos, atualização automática, varredura retomável, revisão editorial em lote, links de estatísticas convencionais, estatísticas nativas acessíveis no Cockpit, visualização de etiquetas, acesso à edição nativa de etiquetas, etiquetas na listagem e filtro por etiqueta.

Desligar colagem preserva a seleção comum de anexos. Desligar os atalhos dos cabeçalhos preserva a ordenação normal. Desligar atualização automática preserva a atualização manual. Desligar decisões em lote preserva a revisão individual autorizada. Os links estatísticos continuam sendo acessos ao GLPI convencional; não são um novo relatório calculado pelo plugin.

### Estatísticas no Cockpit

O Cockpit reúne a consulta acessível e as alternativas convencionais. O bloco antigo não é mais apresentado em Chamados. A opção **Acessos às estatísticas convencionais** depende agora do módulo Cockpit, assim como a consulta acessível; a dependência já existente entre Cockpit e Chamados permanece. A localização não altera estados Desativada, Perfis ou Todos já gravados.

A opção **Estatísticas nativas acessíveis no Cockpit** começa desativada, inclusive ao atualizar com todas as dez opções anteriores liberadas. Para utilizá-la, o perfil ativo precisa também de acesso ao Cockpit, permissão nativa de estatísticas e contrato suportado. O modo Todos não concede esses direitos.

A consulta adaptada e os links convencionais são independentes:

| Consulta acessível | Links convencionais | Resultado |
| --- | --- | --- |
| Desativada | Desativados | Nenhum acesso estatístico adicional é oferecido pelo portal |
| Desativada | Liberados | Acessos à interface convencional, conforme autorização |
| Liberada | Desativados | Consulta adaptada, sem os links adicionais convencionais |
| Liberada | Liberados | Consulta adaptada e alternativas convencionais |

O direito nativo e as dependências continuam valendo em todas as combinações. Desativar a consulta adaptada bloqueia novas requisições e paginação, mas não cancela uma consulta síncrona já iniciada nem apaga resultados recebidos pelo navegador. A primeira apresentação inclui quatro contagens por técnico atribuído; tarefas permanecem no relatório convencional. Consulte o [guia das estatísticas em HTML acessível](guia_estatisticas_acessiveis.html) ou o [texto em Markdown](guia_estatisticas_acessiveis.md).

### Etiquetas nos chamados

**Visualizar etiquetas nos chamados** habilita a leitura no detalhe, sujeita ao Tag ativo, à combinação suportada e às permissões nativas. **Acesso à edição nativa de etiquetas** acrescenta uma continuação para o chamado na interface convencional quando o usuário pode atualizá-lo e administrar etiquetas. Não é um editor de etiquetas dentro do portal; essa segunda opção depende também da primeira.

As duas opções do detalhe começaram desativadas na beta.16. Na beta.17, **Etiquetas na listagem de chamados** e **Filtrar chamados por etiqueta** também começam desativadas, preservando as treze escolhas anteriores. A coluna e o filtro são independentes entre si e das opções do detalhe.

Desativar a coluna não apaga a preferência salva nem os vínculos. Se ela já estiver selecionada, a lista básica permanece e a informação de etiquetas fica indisponível. Desativar o filtro bloqueia novas execuções que dependam dele; o critério não é removido silenciosamente de uma pesquisa salva. Pesquisas sem etiqueta continuam disponíveis. Tag ausente ou inativo não acrescenta controles. Uma falha de leitura informa indisponibilidade, em vez de declarar que o chamado não tem etiquetas. O [guia de etiquetas](guia_etiquetas_acessiveis.md) apresenta as combinações e os limites de cada recurso.

## Instalação e atualização

Escolhas já gravadas são preservadas. Recursos novos não são liberados por ausência de configuração. Na instalação sem política anterior, as novidades começam desativadas e a página solicita revisão administrativa. É possível confirmar a revisão mantendo todos os estados desativados.

O GLPI pode atualizar o registro de versão antes de executar o instalador do plugin. Por isso, quando não há política anterior, o pacote não infere automaticamente que deve conservar todas as novidades da beta.11. Antes da implantação, registre os recursos em uso; depois da atualização, revise e libere explicitamente os correspondentes. Não use o VERSION recém-copiado como prova da versão anterior.

Instalações que vêm da beta.7 podem receber as correções com as novidades desativadas e liberá-las depois. Atualizar não exige desinstalar e não desfaz migrações próprias já existentes.

## Efeito de mudanças e limites

A política é conferida no servidor para as operações específicas. Preparações ainda não executadas serão revalidadas. Operações já iniciadas pelo executor nativo podem precisar concluir sua continuação segura; a configuração não cancela transações nem desfaz alterações concluídas.

Na varredura, desativar impede novos trabalhos e lotes ainda não iniciados. Consulta, pausa e cancelamento seguro continuam disponíveis. A verificação de autorização das fontes do chatbot nunca é desligada por essa opção.

As mensagens distinguem desativação, perfil fora do público e indisponibilidade de verificação. Uma recusa de liberação não significa falha do banco ou do servidor. Resultados anteriores continuam preservados e uma confirmação consumida não deve ser reenviada. Essas melhorias de mensagem são permanentes e não possuem opção para desativação.

Abas antigas podem manter temporizadores ou controles visuais anteriores até recarregar. Isso não concede permissão de gravação: a liberação e a autorização nativas são verificadas antes de novas execuções protegidas. A configuração do plugin não bloqueia a interface convencional autorizada.

A revisão detecta formulários já desatualizados e a gravação é conferida por releitura. Isso não constitui bloqueio atômico entre dois administradores salvando simultaneamente. Nesta versão, coordene as alterações com **um administrador por vez**. Não há trava distribuída nem promessa de exclusão mútua. A auditoria segue a política de persistência já configurada no plugin.

## Acessibilidade e homologação

O formulário e a revisão funcionam sem JavaScript, com controles nativos e nomes visíveis. Não é preciso usar Ctrl ou Shift para marcar vários perfis. A revisão distingue estados por texto, não somente por cor.

Com JavaScript, a lista de perfis aparece somente no modo por perfis. Alternar os estados não salva nem desloca o foco; seleções do rascunho são preservadas enquanto a página estiver aberta. Sem JavaScript, a lista permanece visível com a indicação de quando se aplica. O texto de situação vigente descreve a política salva, não as escolhas ainda em edição.

Testes automatizados não substituem a avaliação com teclado, leitor de tela e usuários. Antes de ampliar o piloto, valide os recursos liberados nos perfis e plugins reais da instituição. A liberação por perfis não torna uma funcionalidade automaticamente compatível ou acessível.
