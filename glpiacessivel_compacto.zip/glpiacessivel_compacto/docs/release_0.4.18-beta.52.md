# Ações no final do formulário de criação

Versão 0.4.18-beta.52, epoch `20261104-05`, de 04/11/2026. Mantém GLPI 10 e 11 e o manual 3.0.

## Correção delimitada

Os botões Registrar chamado, Limpar formulário e Abrir formulário em página completa deixam de acompanhar a rolagem presos à parte inferior da janela. Permanecem no fluxo normal, ao final do formulário de criação do plugin. A alteração remove somente `position: sticky`, `bottom`, `z-index` e `backdrop-filter` dessa barra, no CSS fonte e no espelho publicado.

A apresentação flexível, a quebra de linha, os rótulos, a ordem do documento e os tipos submit/reset/link são preservados. Em formulários longos, o usuário rola ou navega por teclado até as ações. Não se cria uma faixa reservada, novo contêiner de rolagem ou tratamento por JavaScript.

## Preservação do funcionamento

Nenhuma mudança nos ícones flutuantes, formulários nativos GLPI/Formcreator, permissões, CSRF, validações, modelos, anexos, dados ou regras de negócio. Não há SQL novo, novo endpoint ou alteração do núcleo. Os metadados de versão e epoch são atualizados para distinguir o pacote e invalidar os ativos antigos.

O manual contextual e o completo permanecem disponíveis com o mesmo conteúdo da edição 3.0 e cobertura atualizada. As instruções existentes de preenchimento e registro continuam válidas.

## Verificação

Os resultados desta rodada e seus limites estão em [Verificação da beta.52](test_execution_0.4.18-beta.52.md). Leitor de tela real, ampliação operacional integral e aceite institucional não são certificados por testes automatizados de layout. O checksum final pertence ao recibo externo do pacote.
