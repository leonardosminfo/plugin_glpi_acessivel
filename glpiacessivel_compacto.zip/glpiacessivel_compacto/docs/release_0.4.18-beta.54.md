# Edição coerente de interações e orientação sobre imagens

Versão 0.4.18-beta.54, epoch `20261105-02`, manual 3.2, de 05/11/2026.

- A linha do tempo identifica a ação disponível: edição nativa completa, texto simples ou somente visibilidade. Conteúdo rico não é apresentado como editável por um textarea simples.
- O formulário nativo continua sendo o editor completo para texto simples ou formatado quando ambas as liberações e os direitos nativos permitem. Falha no carregamento não provoca redução silenciosa ao editor simples.
- A tela de edição reúne os arquivos já vinculados e explica a diferença entre imagem incorporada e anexo. Leitura reutiliza o caminho autorizado de documentos; não cria SQL, upload próprio ou exclusão de documentos.
- A configuração mostra a interseção dos perfis selecionados nas duas opções de edição e sinaliza combinações incompletas. Nenhuma política existente é ampliada automaticamente.
- O manual 3.2 mantém 46 assuntos e sete figuras nas apresentações contextual, completa e offline. Inclui seleção de imagem, descrição alternativa, dimensões, cancelamento e conferência depois de salvar.

CSRF, campos, arquivos, regras, autorização, proteção de rascunho e destino do formulário completo continuam nativos. O POST simples continua recusando HTML e campos de upload. A liberação controla a exposição no portal, não revoga o acesso convencional nem interrompe formulários nativos já abertos.

Verificações: 2.752 testes PHP e 21.044 verificações aprovados em cada versão PHP 8.1/8.3; 92 testes de navegador aprovados. Edição da imagem, novo anexo e visibilidade isolada ensaiados com registros sintéticos no GLPI 10/8089 e GLPI 11/8080. Políticas originais restauradas.

O reenvio de um arquivo já vinculado provocou erro de unicidade no pipeline nativo do GLPI 11.0.7. Não foi contornado por SQL ou alteração de regra; arquivo novo foi salvo normalmente. A investigação comparativa desse caso e os demais limites estão na [Verificação da beta.54](test_execution_0.4.18-beta.54.md). Não se declara certificação WCAG/eMAG/RGAA nem aprovação de ensaios ainda não documentados.
