# Manual contextual da versão 0.4.18-beta.19

O GLPI Acessível inclui o manual HTML 1.3, com leitura contextual por padrão e opção de consultar o manual completo. A Ajuda autenticada abre o manual em nova aba, com aviso. O cartão da página inicial convencional oferece o mesmo acesso na própria aba.

As orientações básicas e de recuperação permanecem disponíveis. A apresentação contextual considera módulos, liberações e direitos gerais confirmados; não autoriza operações sobre chamados. Falhas de verificação não são apresentadas como falta de permissão. Integrações cuja disponibilidade não possa ser confirmada sem pesquisa recebem orientação condicional.

O conteúdo completo e o HTML autônomo utilizam a mesma fonte editorial. As treze jornadas preservam seus identificadores; os quinze recursos de liberação gradual são documentados sem alterar a política salva. O crédito discreto de elaboração é preservado.

Figuras de apoio usam o caminho público de assets compatível com GLPI 10 e 11, inclusive em subdiretório, sem depender do acesso direto às fontes editoriais. Na edição autônoma, as figuras são incorporadas. As orientações recolhidas de recuperação continuam disponíveis na impressão.

Não há SQL novo, novas tabelas ou alteração do núcleo do GLPI. A leitura não executa pesquisas, cálculos ou gravações operacionais. O manual não amplia o suporte às versões do Tag e não apresenta funcionalidades apenas planejadas como entregues.

Consulte o guia de utilização do manual e o registro de testes desta versão para o alcance da homologação. A entrega não constitui certificação integral de acessibilidade.
