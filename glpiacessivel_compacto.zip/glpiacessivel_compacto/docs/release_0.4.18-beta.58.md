# Versão 0.4.18-beta.58

Adequação dos formulários de edição de tarefas e acompanhamentos ao padrão visual do portal. GLPI 10 e 11, epoch `20261106-03`.

## Escopo

- Apresentação restrita aos formulários nativos integrados: tipografia, espaçamento, temas, foco e acomodação à largura disponível.
- Rótulos textuais e associações acessíveis complementares para campos e seletores que antes dependiam principalmente de ícones.
- Texto e anexos relacionados no mesmo fluxo, com instruções iniciais curtas e ajuda detalhada recolhida.
- Adaptação de apresentação da área editável, sem substituir o editor nem modificar seu conteúdo.
- Atualização das orientações do manual contextual, completo e HTML autônomo a partir da mesma fonte editorial.

## Preservações

O GLPI continua responsável pelos formulários, campos, modelos, permissões, estado, action, CSRF, uploads, associação de documentos, validação e salvamento. Os diálogos de imagem permanecem nativos. Remover uma imagem do texto não significa excluir o documento anexado.

Não há SQL novo, mudança de esquema, alteração do núcleo, recriação de permissões ou regras de negócio próprias. A atualização de epoch sincroniza o runtime; não acrescenta migração estrutural. Inclusão e edição formatadas continuam com liberações independentes, sem habilitação automática. Ações de inclusão compartilhadas devem ser retestadas para prevenir regressão, sem uma reformulação geral do chamado.

## Verificação

Os resultados executados e as limitações constam do registro `test_execution_0.4.18-beta.58.md`. A publicação do pacote requer a conclusão desse registro e do verificador de distribuição. Testes automáticos e inspeção de navegador não substituem teste com leitor de tela real, validação institucional nem certificam conformidade integral com WCAG, eMAG ou RGAA.
