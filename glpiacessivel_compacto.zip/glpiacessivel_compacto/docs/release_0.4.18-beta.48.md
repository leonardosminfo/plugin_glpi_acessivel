# Ícones persistentes nos layouts conhecidos

Versão 0.4.18-beta.48, epoch `20261104-01`, de 04/11/2026. Manual 2.8. Plano e limites em [plano de implementação](plano_icones_reserva_janela_beta48.md) e [testes](test_execution_0.4.18-beta.48.md).

## Entrega

Uma faixa inferior da janela fica reservada aos acessos de portal e chatbot nos shells conhecidos do GLPI 10/11 e do portal autônomo. O conteúdo tem um scrollport limitado acima dessa faixa, em vez de receber apenas padding ao final. Os ícones continuam circulares e fixos desde a inicialização do componente até o final da rolagem.

São mantidos os layouts separados, invertidos e empilhados e os tamanhos configurados. A reserva considera apenas os acessos existentes. Os elementos, nomes, destinos, campos, eventos, rascunhos e ordem de teclado não são recriados. Não existe arraste ou nova preferência individual nesta entrega.

Em janelas de pouca altura, a apresentação usa alvos compactos de 64 pixels e, abaixo de 360 pixels de altura útil de viewport, separa temporariamente os acessos. Ao ampliar a janela, volta à disposição configurada. Nenhuma preferência salva é alterada. O controle nativo existente de voltar ao topo acompanha o novo scrollport, com ativação seletiva; não se executa simultaneamente a animação da janela nem se sobrescrevem APIs globais.

Painéis ITIL e listas com rolagem própria recebem um limite geométrico de altura. O cálculo ITIL reserva também a altura de seu rodapé. Quando esse rodapé é fixo, a faixa é somada ao afastamento nativo vigente, sem acumular descontos nem impor um valor único para todos os temas. A origem vertical da página é considerada, inclusive com banners anteriores ao conteúdo.

Modais preservam bloqueio de rolagem, suspensão dos acessos externos e devolução de foco. A faixa é removida quando não há acessos e na impressão. O iframe nativo excluído não recebe essa adaptação. Os assets de origem e públicos são idênticos, pois os GLPI locais usam caminhos diferentes.

## Limites de compatibilidade

Não é uma promessa de posicionamento fixo em qualquer tema, plugin de terceiros ou janela sem altura útil. A degradação segura anterior permanece para shells não reconhecidos e geometria impossível; nesse caso excepcional a apresentação em fluxo pode ocorrer. A regra prioritária continua sendo permitir acessar os controles, não cobri-los.

Em um shell conhecido, mesmo a exceção sem altura útil conserva links circulares, e não cartões. Nessa exceção eles entram no fluxo da página e deixam de ser fixos; não deve ser anunciada como cumprimento universal de “sempre flutuantes”.

A página conhecida passa a ter scrollport próprio. Não se sobrescrevem window.scrollTo, APIs globais ou arquivos do núcleo. Usos legados de rolagem da janela por extensões, comportamentos específicos de validação de interação, menus destacados e restauração de posição exigem conferência em seus respectivos percursos. O resultado local de geometria não equivale a paridade universal dessas integrações.

O manual contextual, completo e autônomo usa a mesma fonte 2.8, com os mesmos 45 capítulos e sete imagens; o texto administrativo explica a área reservada e a exceção de compatibilidade. Mantêm-se GLPI 10/11, PHP 8.1+, sem SQL novo, migrações, mudanças de permissões ou de regras de negócio.
