# GLPI Acessível 0.4.18-beta.28

Esta versão corrige a fronteira de entrada textual da descrição no GLPI 10, preservando o caminho existente do GLPI 11. Trata os dois casos da F2: ampersand codificado novamente e falso resultado incerto com barras, quebras de linha e apóstrofo.

## Correção restrita

A descrição original preservada pelo bootstrap 10.0.x é conferida por transformação pública nativa no sentido direto, depois de CSRF e confirmação. O plugin não tenta recuperar o texto por decodificações ou desescapes heurísticos. Ausência ou divergência da origem, HTML real, limites excedidos e formato não suportado são recusados antes da atualização.

No GLPI 10, o serializador preserva as aspas literais no nó textual, mantém o escape de ampersand e marcação e aplica o escape público exigido pelo modelo legado. Isso respeita a preparação nativa que normaliza entidades de aspas na cadeia de regras. No GLPI 11, as opções anteriores de serialização permanecem iguais. A descrição bruta é relida estritamente contra a intenção original; resultado não comprovado continua incerto, sem reenvio automático.

O plugin não cria SQL, altera regras, força campos obrigatórios, amplia direitos ou substitui os hooks nativos. O guard de conteúdo rico, a revisão de concorrência e as confirmações permanecem ativos. O procedimento do manual HTML 1.8 não mudou.

## Atualização e limites

Marcadores: `0.4.18-beta.28`, epoch `20261027-06`. Atualize pelo fluxo nativo, sem desinstalar. A beta.26 foi preservada. A beta.27 foi somente uma candidata local não aprovada, cujo caso B foi recusado sem efeito persistido.

Quando uma cadeia com barras é considerada já escapada pelo helper nativo e sua representação não pode ser estabelecida com segurança, a gravação é recusada e a interface convencional é oferecida. Não há promessa de suporte a qualquer cadeia ou a todo patch GLPI 10. Os demais ensaios de transporte, concorrência e renderização legada continuam separados.

Consulte os [testes e limites](test_execution_0.4.18-beta.28.md).
