# Atribuição nativa e manual 2.7

Versão 0.4.18-beta.46, epoch `20261029-09`, de 29/10/2026. A atribuição de responsáveis e participantes passa pelo contrato público de atores do GLPI, em uma atualização, preservando a ordem enviada e os efeitos dos hooks. A validação local está registrada na [execução desta versão](test_execution_0.4.18-beta.46.md). A implementação não encerra os recortes de paridade ainda não exercitados.

## Atribuição pelo núcleo

O portal envia os participantes pelo campo nativo `_actors` a `Ticket::update()`, com preparação pública de campos somente leitura no GLPI 11. Preserva participantes não editados, requerentes anônimos, fornecedores e preferências de notificação. A revisão inclui os metadados dos atores para detectar alterações concorrentes.

Com Escalade reconhecido e configuração efetiva consistente, vários grupos novos podem ser enviados na mesma operação. Os hooks decidem se os grupos permanecem ou se os anteriores são retirados. Terminar com um só responsável não cria uma restrição de entrada de um grupo. O portal não dispara hooks manualmente, não restaura grupos removidos legitimamente e não decompõe esse envio em vários escalonamentos próprios.

Retorno aceito, resultado verificado e resultado incerto são apresentados de forma distinta. Uma aceitação do núcleo não é anunciada como garantia de que todos os grupos selecionados permaneceram. As versões/configurações ainda não reconhecidas mantêm continuação convencional específica e temporária; isso não constitui paridade concluída.

## Revisão acessível antes do envio

Uma consulta prévia somente de leitura confere a capacidade e vincula a sequência da intenção à confirmação já existente. Mudança de contexto impede o envio. Edição das escolhas durante a consulta pede nova revisão sem recarregar a página ou deslocar o foco. Falhas mantêm os controles e os arquivos pendentes no documento; não há promessa de preservar arquivos depois de navegar.

A revisão apresenta os novos grupos na ordem efetiva de envio e informa os possíveis ajustes automáticos. O resultado orienta conferir os responsáveis atuais, sem confundir intenção com estado persistido. Permissões, entidades, modelos, CSRF, origem e elegibilidade continuam validados no servidor.

A consulta prévia e o envio final usam tokens CSRF independentes, emitidos pela API pública de sessão. O token da consulta é renovado sem substituir o do envio final. O domínio de status é obtido do contrato público da versão reconhecida do Escalade, sem remapear seus valores.

## Manual e limites

O manual 2.7 atualiza J-08 nas apresentações contextual, completa e autônoma. Mantém os 45 assuntos, as sete figuras, IDs, links e créditos. Explica múltiplas inclusões, limpeza automática e restrições nativas reais, sem repetir o limite geral da beta.45.

O produto não introduz SQL, alterações de esquema ou mudanças nas regras do núcleo/Escalade. Os ensaios locais usam GLPI 10.0.10/Escalade 2.9.4 histórica autorizada e GLPI 11.0.7/Escalade 2.10.8; não certificam todas as versões ou outras extensões. O formulário dedicado Escalar é uma operação distinta de salvar participantes.

As validações institucionais, as notificações externas e os ensaios com leitor de tela real permanecem identificados separadamente. A beta.45 e seus artefatos não são substituídos retroativamente.

## Resultados e próximos aceites

As suítes completas passaram em 2.710 testes/20.538 asserções em cada PHP 8.1 e 8.3. Nos GLPI 10/11 locais, duas ordens de múltiplas inclusões com limpeza ativa tiveram o mesmo grupo final, status, tarefas e históricos do convencional; o caso Hotliner do 8080 também foi comparado. Manual contextual/completo foi conferido nos dois ambientes e o autônomo em quatro combinações sem rede/JavaScript.

Permanecem pendentes a comparação real com limpeza desligada, matriz de destinos negados, cardinalidade por outra extensão e os demais recortes delimitados no relatório. Uma obstrução preexistente do Salvar convencional pelo ícone flutuante foi identificada e registrada como F8, sem correção nesta entrega. Não se declara paridade integral ou ausência geral de barreiras de acessibilidade.
