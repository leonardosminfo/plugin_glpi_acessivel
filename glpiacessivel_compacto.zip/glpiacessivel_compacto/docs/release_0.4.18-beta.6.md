# GLPI Acessível 0.4.18-beta.6

Os acessos flutuantes ao portal e ao chatbot podem ser posicionados nas configurações do plugin. A atualização conserva a apresentação anterior até que o administrador salve outra escolha.

## Como configurar

1. Com um perfil autorizado, abra a configuração do GLPI Acessível.
2. Na seção **Botões flutuantes**, escolha a disposição: separados como atualmente, separados com lados invertidos, empilhados à direita ou empilhados à esquerda.
3. Para os modos empilhados, escolha tamanho padrão responsivo ou compacto. O compacto utiliza alvos de 64 × 64 pixels CSS; não reduz os botões dos modos separados.
4. Selecione **Salvar**. A configuração vale para os usuários do ambiente; não é uma preferência individual.

**Restaurar padrão destes botões** preenche somente esses dois campos. É necessário salvar para aplicar. Os demais ajustes não são redefinidos. Sem JavaScript, o formulário também oferece a restauração como rascunho, sem persistência automática.

## Comportamento e proteção de foco

No empilhamento, o portal aparece acima do chatbot, com espaçamento entre os alvos. Um acesso indisponível não deixa uma posição vazia nem é habilitado por mudar a disposição. O nome configurado do chatbot compõe seu nome acessível.

O posicionamento não altera a ordem relativa dos links nem move controles de terceiros. Os botões reservam espaço no documento e verificam colisões com o foco. Em área insuficiente ou colisão persistente, passam para o fluxo da página com texto visível. Esse modo de segurança é mantido até a próxima navegação. O tratamento de diálogos preserva o retorno do foco; uma região com `role="dialog"` não é considerada bloqueante apenas por esse atributo.

Antes da inicialização segura, o link do portal gerado no servidor permanece no fluxo com texto. Sem JavaScript, ele continua disponível nessa forma. A criação do acesso flutuante ao chatbot continua dependendo de JavaScript. O fallback de estilos também oculta visualmente os textos exclusivos de leitores de tela quando os botões estão fixos, evitando que esses textos interceptem cliques fora dos alvos.

## Instalação e compatibilidade

Versão **0.4.18-beta.6**, runtime **20261018-01**. Não há nova migração de esquema nem alteração no núcleo ou nas permissões do GLPI. Atualize pelo ciclo nativo de plugins, sem desinstalar. A versão anterior e o banco dos ambientes locais foram preservados antes da instalação de teste.

Foram utilizados GLPI 10.0.10 em 8089 e GLPI 11.0.7 em 8080. O pacote foi gerado localmente; isso não representa publicação em repositório remoto ou implantação institucional. Para desfazer a mudança visual, escolha a disposição separada padrão e salve. Restaurar o banco inteiro não é necessário para essa reversão visual.

## Limites da validação

Os testes automatizados e o salvamento autenticado local estão registrados no [relatório de testes](test_execution_0.4.18-beta.6.md). Permanecem necessárias avaliação manual com leitor de tela, zoom real de 200% e 400%, dispositivo móvel e verificação das integrações do ambiente de destino. Ferramentas automatizadas não certificam conformidade WCAG, eMAG ou RGAA.
