# GLPI Acessível 0.4.18-beta.16

## Etiquetas opcionais no detalhe do chamado

A primeira etapa da integração com o plugin oficial Tag apresenta as etiquetas vinculadas diretamente ao chamado. A leitura usa a Search API e modelos públicos autorizados na sessão atual, sem SQL próprio, cópia de vínculos ou alteração das regras nativas.

A apresentação mantém o nome completo e a cor de fundo válida. O texto preto ou branco é escolhido pelo maior contraste calculado; nomes não dependem apenas da cor. Cores ausentes ou inválidas usam apresentação neutra com aviso, e cores forçadas respeitam o sistema. O atalho leva o foco ao título da seção, sem tornar cada etiqueta um controle desnecessário.

## Liberação e isolamento

O catálogo passa a treze opções. As duas novas começam desativadas, preservando as onze escolhas anteriores:

- **Visualizar etiquetas nos chamados:** leitura opcional no detalhe.
- **Acesso à edição nativa de etiquetas:** continuação autorizada para o chamado convencional, dependente também da leitura. Não habilita edição local no portal.

Tag ausente, inativo ou sem acesso não oferece controles. Versão desconhecida ou falha de leitura informa indisponibilidade, nunca uma lista falsamente vazia. Não há consulta de etiquetas para cada chamado na listagem. O detalhe admite até cem etiquetas; resultados maiores ou inconsistentes não são apresentados parcialmente.

## Compatibilidade e limites

O contrato do Tag 2.14.8 foi validado com GLPI 11.0.7 local, incluindo associação pela interface nativa e leitura no portal. O reconhecimento de contrato do Tag 2.12.6 na faixa GLPI 10 compatível foi testado por simulação, não homologado com instalação ativa.

O GLPI 10.0.10 em 8089 não atende ao requisito mínimo do Tag 2.12.6. Uma versão antiga não foi instalada para contornar isso, devido ao [aviso oficial de XSS](https://github.com/pluginsGLPI/tag/security/advisories/GHSA-6rpj-89c7-x2mh), cuja correção indicada é da linha GLPI 11. Esse ambiente continua sem Tag e teve sua contingência verificada.

Adicionar/remover etiquetas dentro do portal, filtros, coluna e ações em massa de etiquetas permanecem pendentes de contrato público seguro e homologação. Não há promessa de adaptação acessível de todos os controles convencionais de terceiros.

Atualize o GLPI Acessível sem desinstalar, pelo procedimento nativo. O pacote não instala o Tag. Esta entrega não acrescenta SQL, migração estrutural ou mudança no core. O marcador de runtime é `20261019-07`.

Consulte o [guia de etiquetas](guia_etiquetas_acessiveis.md), o [plano atualizado](plano_integracao_etiquetas_tag_2026-10-19.md) e o [registro de testes](test_execution_0.4.18-beta.16.md).
