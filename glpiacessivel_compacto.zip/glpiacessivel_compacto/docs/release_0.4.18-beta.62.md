# 0.4.18-beta.62 — Ajuda e atalhos acessíveis

A Ajuda mantém o diálogo, os controles existentes e a tabela como referência de consulta. Explica que as linhas não são botões, que Tab percorre controles e que a leitura das linhas usa os comandos do leitor. Orienta fechar a Ajuda antes de atalhos de navegação e usar botões/links quando uma combinação for reservada por navegador, sistema ou tecnologia assistiva.

A tabela passa a ter legenda e cabeçalhos de coluna explícitos, incluindo as alternativas existentes Ctrl+Alt+Shift para tema, contraste, Ajuda e chatbot. O diálogo concentra a rolagem vertical: a tabela deixa de encolher e de criar um segundo scroll vertical. As combinações podem quebrar linha em telas estreitas, sem diminuir fonte ou alvos.

Os atalhos não escapam de um diálogo aberto nem interrompem composição de texto, AltGraph ou repetição de tecla. O atalho de Ajuda pode fechar o próprio diálogo. A combinação que exige Shift para produzir o sinal de mais é reconhecida somente para aumentar a fonte, sem habilitar Shift nos atalhos de navegação.

Manual 3.10 contextual, completo e autônomo atualizado. Nenhuma alteração de permissão, consulta SQL, gravação de chamados ou regra de negócio. Compatível com GLPI 10 e 11. Epoch `20261106-07`.
