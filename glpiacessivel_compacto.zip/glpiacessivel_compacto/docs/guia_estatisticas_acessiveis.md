# Estatísticas nativas acessíveis no Cockpit

## Acesso e consulta

Os acessos estatísticos ficam centralizados no **Cockpit**, depois dos indicadores. A lista de **Chamados** não apresenta mais o bloco de links para estatísticas convencionais. Use **Cockpit** no menu do portal para encontrá-los.

Depois dos indicadores do Cockpit, procure **Estatísticas de chamados** e **Consultar estatísticas de chamados**. O acesso aparece quando a administração libera a funcionalidade e seu perfil ativo possui as permissões necessárias no GLPI. Os indicadores já existentes continuam independentes dessa consulta.

1. Confira perfil e entidade ativos.
2. Abra a consulta e confira a modalidade Por técnico atribuído.
3. Informe data inicial e final. A data final deve ser igual ou posterior à inicial; o preenchimento segue o controle de data do navegador.
4. Acione **Consultar estatísticas**. Alterar campos ou abrir o Cockpit não executa o relatório.
5. Leia o contexto aplicado, o período e os cabeçalhos da tabela antes de comparar os números.
6. Use a paginação, quando oferecida, ou **Voltar ao cockpit**.

O intervalo inicial segue o padrão de calendário do relatório convencional. A consulta usa a entidade, a recursividade e o perfil da sessão, sem substituir preferências ou pesquisas salvas. Depois de trocar o contexto, faça uma nova consulta.

## Interpretação das contagens

| Coluna | Como interpretar |
| --- | --- |
| Abertos no período | Contagem nativa de abertura no intervalo; não significa a fila que continua aberta agora |
| Solucionados no período | Contagem nativa de solução no intervalo |
| Solucionados fora do prazo | Critério nativo de atraso na solução |
| Fechados no período | Contagem nativa pelo critério de fechamento |

O GLPI calcula esses valores. O plugin apresenta somente esse subconjunto do relatório, sem refazer fórmulas, médias, tempos ou totais. Um chamado pode participar de mais de uma coluna ou de mais de um técnico: não some as colunas ou linhas para obter chamados distintos. A quantidade de linhas da paginação refere-se a técnicos, não ao total de chamados.

Zero é um resultado válido. Uma consulta incompleta ou incompatível gera orientação e não uma tabela de zeros. Ausência de linhas significa que o relatório não retornou técnicos nesse período e contexto; não comprova um total de zero chamados.

## Teclado e leitor de tela

Use os títulos para alcançar formulário, resultados e navegação. Os campos têm rótulos visíveis e os erros identificam o que precisa ser corrigido. Ao consultar, o destino dos resultados ou da orientação de erro pode ser alcançado diretamente, sem percorrer novamente todo o formulário.

A tabela identifica técnico em cada linha e contagem em cada coluna. Use a navegação de tabelas do seu leitor de tela para relacionar cada valor aos cabeçalhos. Em telas estreitas, a rolagem horizontal fica na região da tabela; alcance essa região com Tab e use as setas para os lados. O restante da página continua em fluxo vertical.

## Alternativa convencional e limites

Quando liberados separadamente, os links convencionais abrem o relatório na mesma aba. Para retornar, use Voltar no navegador. A interface convencional oferece outras colunas e sua acessibilidade pode diferir da apresentação do plugin.

No Cockpit, esses links aparecem em **Alternativas na interface convencional**. Com JavaScript disponível e sem outro destino de foco prioritário, o retorno pelo histórico restaura o foco ao link utilizado. Sem essa melhoria, os links e o retorno normal do navegador continuam funcionando.

A liberação **Acessos às estatísticas convencionais** e a liberação **Estatísticas nativas acessíveis no Cockpit** continuam independentes. Ambas dependem do módulo Cockpit disponível e dos direitos nativos; a centralização não liga recursos desligados nem modifica os perfis selecionados.

As estatísticas por técnico de tarefas permanecem no GLPI convencional, pois os critérios nativos diferem entre as versões. Não são apresentadas como equivalentes ao responsável pela tarefa nas duas versões.

O tamanho da página segue a preferência nativa de listagem. A adaptação aceita limites de 1 a 100 linhas; preferências especiais ou maiores são recusadas com orientação, sem serem alteradas. Períodos amplos podem demorar, mesmo com paginação. Não repita a consulta automaticamente após uma falha.

Se o recurso for desativado enquanto a página estiver aberta, uma nova consulta ou paginação poderá ser recusada. A configuração não cancela trabalho nativo já iniciado nem desfaz resultados anteriores. Se ocorrer falha técnica, preserve o contexto e as datas e informe a mensagem ao suporte.
