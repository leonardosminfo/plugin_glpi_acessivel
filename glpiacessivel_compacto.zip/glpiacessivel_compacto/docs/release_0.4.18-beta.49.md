# Recuperação dos ícones após falta de espaço

Versão 0.4.18-beta.49, epoch `20261104-02`, de 04/11/2026. Manual 2.9. Escopo e resultados em [plano de implementação](plano_icones_recuperacao_beta49.md) e [relatório desta rodada](test_execution_0.4.18-beta.49.md). O checksum e a verificação de integridade do pacote ficam no recibo externo da distribuição.

## Correção delimitada

A apresentação em fluxo seguro da beta.48 podia continuar ativa mesmo depois de ampliar a janela e voltar a existir espaço para os ícones. A beta.49 permite recuperar automaticamente a área reservada e o posicionamento fixo nos shells conhecidos, sem recarregar a página.

A recuperação exige geometria estável e uma nova verificação de segurança. Se a tentativa encontrar colisão ou espaço insuficiente, permanece o fluxo seguro. A rolagem comum, sem mudança relevante da geometria, não deve disparar tentativas repetidas nem alternância contínua da apresentação.

Os mesmos links e controles são conservados. A transição preserva o foco e usa uma referência visível de leitura para acomodar a mudança entre a rolagem da janela e a do conteúdo, sem recriar campos ou alterar seus dados. Modais continuam responsáveis por seu foco e pelo bloqueio de rolagem; a recuperação aguarda uma condição segura fora do modal.

Na inspeção do menu superior real do GLPI 11, foi identificada a barra nativa de depuração fixa no rodapé, com 59 pixels de altura no cenário observado. O afastamento dos ícones e a reserva passam a considerar a área realmente ocupada por `#debug-toolbar` quando a barra está visível. O cálculo acompanha mudanças de tamanho e atributos, sem deslocar a barra nem impor 59 pixels a outras instalações. A correção considera também o rodapé estático `#pluginfooter` fora de `.page`; as regressões incluem Salvar fixo e depurador de altura variável. Isso não representa suporte universal a barras de terceiros.

## O que não muda

Mantêm-se a faixa reservada da beta.48, os layouts configurados, a proteção dos controles nativos, GLPI 10/11 e a distribuição offline. Não há SQL novo, migração, alteração de permissões, regras de negócio ou mudança automática da configuração institucional. Não há arraste nem preferência individual nova.

O HTML inicial, a renderização no servidor e o comportamento sem JavaScript permanecem iguais. Esta entrega não promete dois ícones fixos desde o primeiro frame nem substitui a degradação de shells desconhecidos ou de geometria fisicamente inviável. Nesses casos a apresentação pode continuar em fluxo; alcançabilidade por teclado não equivale a visibilidade permanente.

## Manual e validação

O manual contextual, completo e autônomo passa a 2.9, mantendo os 45 assuntos e as sete figuras. A fonte editorial explica que os acessos em fluxo por falta de espaço voltam automaticamente à posição fixa quando houver espaço seguro, sem recarregar.

Nas sessões reais, o manual contextual e o completo informaram 2.9/beta.49 nos dois GLPI. O completo conservou as sete figuras e a frase de recuperação. No GLPI 10 Self-Service, a orientação administrativa não apareceu no procedimento contextual, como esperado para esse perfil; no GLPI 11 Super-Admin, a frase apareceu no contexto e o acesso ao completo permaneceu disponível.

As suítes PHP passaram em 2.724 testes e 20.733 asserções por execução, nos runtimes 8.1.31 e 8.3.14. A suíte final de reserva/recuperação passou em 65 casos; as regressões de layout e foco passaram, respectivamente, em 65 e quatro. A regressão de navegador do manual passou nos 50 casos com PHP 8.3.14; as apresentações contextual, completa e offline conservaram 45 assuntos, sete figuras e a frase de recuperação.

Os percursos autenticados headless concluíram 16 combinações de ambiente, rota e largura (1366 e 320), com 32 recuperações de 120 → 900, conferência de versão/hashes e Salvar atingível onde presente. No navegador interativo, o menu superior real foi conferido no GLPI 11/8080 como Super-Admin, no chamado 152 com depurador ativo, e no GLPI 10/8089 como Self-Service, na central de ajuda. Os acessos permaneceram fixos, circulares e atingíveis nos cenários verificados e recuperaram após a redução efetiva de 160 → 900, sem recarga. O navegador interativo limitou a altura a 160; esse ensaio não é apresentado como 120 pixels reais.

As preferências horizontais foram temporárias e o estado original `page_layout = NULL`, com apresentação vertical, foi restaurado nos dois ambientes. Os efeitos adicionais do formulário de preferências do GLPI 10 e a restauração dos quatro campos de dashboard são discriminados no relatório, com verificação por modelo nativo e hashes. Não foram alterados chamados ou vínculos de perfil/entidade para concluir o ensaio.

A integridade da distribuição é registrada pelo verificador e pelo recibo externo do pacote. Não se reutilizam os totais da beta.48 como resultado desta versão nem se somam repetições. Não há declaração de certificação WCAG/eMAG/RGAA, teste de leitor de tela real ou aceite institucional.
