# 0.4.18-beta.60 — altura acessível do editor

O editor formatado de acompanhamentos e tarefas começa com altura mínima de 20rem (aproximadamente 320px com a fonte padrão), mantendo a largura responsiva de 100% do espaço disponível.

Os botões **Ampliar campo** e **Restaurar altura padrão** permitem ajustar a área pelo teclado, sem arrastar. O foco permanece no botão acionado e o resultado é anunciado em uma região de status. Ampliar respeita um limite proporcional à janela; o botão continua focalizável ao atingir o limite. A tela cheia nativa não tem sua geometria modificada pelos botões do portal.

O ajuste altera apenas a apresentação do editor existente. Não recria o TinyMCE, não altera conteúdo, seleção de arquivos, documentos, regras, SQL, permissões ou o mecanismo de salvamento. Os controles aparecem somente após o editor estar disponível; sem JavaScript, não se exibem controles inoperantes.

Manual contextual, completo e autônomo 3.8 atualizados. Compatibilidade GLPI 10/11; epoch `20261106-05`.
