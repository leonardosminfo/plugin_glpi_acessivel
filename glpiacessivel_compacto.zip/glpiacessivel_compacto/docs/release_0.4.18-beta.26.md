# GLPI Acessível 0.4.18-beta.26

Esta versão corrige uma divergência de apresentação encontrada nos testes locais de integridade da edição de chamados. A descrição já convertida para texto era interpretada como HTML uma segunda vez ao preencher o editor. Com isso, uma entidade numérica escrita literalmente podia aparecer como outro caractere, embora o registro nativo estivesse preservado.

## Correção e aderência

O contexto de edição passa a identificar explicitamente a descrição já projetada como texto. A tela usa o caminho existente para esse valor, mantendo o escape na saída. Não há nova conversão, campo gravado, chamada nativa, SQL, migração, alteração de permissões ou de regras do GLPI.

A descrição bruta e a revisão de concorrência não mudam. Conteúdo rico continua seguindo para o editor convencional quando não pode ser editado com segurança no campo textual. O caminho legado da tela, quando recebe um contexto sem o marcador de texto, permanece disponível.

| Frente | Entrega |
| --- | --- |
| F1 Confirmação | Ampliação dos testes locais de expiração, purga por outro GET, cancelamento, troca de intenção e histórico. Sem mudança do prazo ou das proteções. |
| F2 Edição | Correção da segunda interpretação da descrição; regressões do contexto até a textarea real e controles de preservação do conteúdo bruto. |
| Compatibilidade | Testes locais no GLPI 11.0.7 e 10.0.10; PHP 8.1 e 8.3. As regras nativas permanecem responsáveis por autorizar e efetivar as operações. |
| Manual | Manual HTML 1.8 contextual, completo e autônomo com referência à beta.26. Procedimentos, rótulos e sete figuras preservados. |

## Atualização

Atualize pelo fluxo nativo do plugin, sem desinstalar. Os marcadores desta versão são `0.4.18-beta.26` e runtime epoch `20261027-04`. A beta.25 permanece preservada, com SHA-256 `46510d73a102bbdf0ce02b3854242abfb08ea6b8ba95ba21d2e311ed310f7e0b`.

## Limites desta entrega

A correção não modifica o transporte ou a sanitização de descrições no GLPI 10. Permanecem em análise local a representação de alguns caracteres nesse caminho e o falso resultado incerto com determinada combinação de barras literais e apóstrofo. A releitura independente confirmou a preservação do texto do segundo caso; não se deve reenviar uma operação apenas porque o resultado foi incerto.

Voltar e avançar no navegador foram exercitados, mas não comprovam, por si, restauração real por BFCache. Replay HTTP e resposta perdida após possível gravação também continuam distintos das simulações isoladas. F1 e F2 não estão integralmente encerradas. O escopo desta rodada exclui as dependências institucionais.

Consulte os [testes e pendências locais](test_execution_0.4.18-beta.26.md).
