# GLPI Acessível 0.4.18-beta.5

A fila editorial permite aprovar ou rejeitar propostas em lote, com revisão e confirmação explícitas. O recurso atua nos roteiros do chatbot; não modifica os artigos nativos nem substitui as ações em massa sobre chamados.

## Como utilizar

1. Abra a administração de roteiros e filtre a fila de propostas pendentes.
2. Marque as propostas desejadas ou selecione a página atual. O limite é 20 propostas; páginas anteriores não entram na seleção.
3. Escolha aprovar ou rejeitar as propostas selecionadas. Essa etapa abre uma revisão, sem executar decisões.
4. Confira conteúdo, fontes, alvos, impedimentos e consequências de cada proposta. Se necessário, volte para ajustar a seleção, renove a revisão ou cancele.
5. Confirme a decisão e consulte o resultado por proposta. Um resultado parcial não implica sucesso integral nem autoriza repetir automaticamente o lote.

Rejeitar remove a proposta da fila de pendentes, sem apagar artigos ou alterar o roteiro existente. Aprovar pode criar, atualizar, inativar ou reativar um roteiro conforme a proposta. Duas propostas para o mesmo alvo não são aprovadas juntas. Importações sem mapeamento e propostas que exigem revisão individual não são aprovadas silenciosamente.

## Proteções e acessibilidade

A confirmação está vinculada a usuário, perfil, entidade, inclusão de subentidades, ação e seleção exata mantida no servidor. Cada decisão reutiliza o serviço individual, revalida autorização e revisões e possui transação própria. Alterações de fontes ou do alvo impedem sobrescritas desatualizadas. O conjunto não forma uma única transação global.

Os controles usam checkboxes, etiquetas e formulários nativos sem aninhamento. Há instruções visíveis, seleção parcial, resultados textuais, navegação por teclado e revisão sem JavaScript. Alterar filtros ou página não carrega uma seleção oculta. Contadores e foco contextual complementam, sem substituir, as informações HTML.

## Instalação e limites

Versão 0.4.18-beta.5, runtime 20261010-05. Não há nova migração de esquema nesta entrega; a V0007 da beta.4 permanece. Atualize pelo ciclo nativo de plugins, sem desinstalar. O código anterior foi preservado localmente antes da atualização em 8080 e 8089; a restauração desses arquivos não desfaz decisões editoriais.

Os núcleos testados são GLPI 10.0.10 e GLPI 11.0.7. Essa evidência não certifica conformidade WCAG, eMAG ou RGAA nem comprova os patches e plugins do ambiente institucional. Seleção de todos os resultados, IA externa, OCR e aprovação automática não integram o recurso. Persistem as pendências de relevância, projeção de respostas por seção e avaliação manual assistiva.

Consulte [Testes locais](test_execution_0.4.18-beta.5.md) e [Planejamento atualizado](plano_varredura_conhecimento_chatbot_2026-10-10.md).
