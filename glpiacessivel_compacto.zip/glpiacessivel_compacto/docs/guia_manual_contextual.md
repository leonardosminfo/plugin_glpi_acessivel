# Consultar o manual do GLPI Acessível

O manual 3.11, correspondente ao GLPI Acessível 0.4.18-beta.63, ensina a utilizar os recursos disponíveis sem pressupor experiência com o GLPI. Seus 49 assuntos e sete figuras partem da mesma fonte editorial para leitura contextual, completa e exportação HTML autônoma. Ler as orientações não altera direitos, não habilita recursos e não executa operações. O assunto geral de teclado e leitor orienta todas as pessoas a abrir “Opções de posição...”, arrastar pela alça ou usar os quatro botões de direção, desfazer e restaurar. Os ícones ficam sobre a página, sem faixa reservada, e o ajuste vale apenas nesta aba. A seção administrativa continua explicando os quatro layouts e os tamanhos configuráveis, sem confundir mover localmente com salvar a configuração institucional.

## Começar sem conhecimento prévio

“Comece aqui” encaminha para Conceitos básicos e Seu primeiro percurso sem gravar dados. O leitor aprende o que são chamado, requerente, técnico, observador, grupo, status, perfil, entidade, filtro, rascunho e anexo pendente antes de preparar um atendimento.

O primeiro percurso ensina a reconhecer entrada, contexto, menu e Ajuda, abrir o manual, usar o sumário e retornar sem gravar. Não exige criar um chamado ou encontrar um registro de treinamento. A orientação diferencia navegar por títulos/texto com o leitor de tela e usar Tab entre controles.

Depois, cada pessoa escolhe a tarefa de que precisa: pedir ajuda, consultar um chamado, prestar atendimento ou administrar uma função. Os procedimentos são independentes e não precisam ser executados todos em sequência.

“Comece aqui” também oferece links para aprender a abrir, encontrar e acompanhar um chamado ou consultar orientações na Base de conhecimento. Esses links levam à leitura dos capítulos; não abrem formulários nem registram ações. Os caminhos por público em “Como usar este manual” permitem consultar diretamente os capítulos correspondentes, inclusive a orientação de disponibilidade no manual contextual.

## Consultar a Ajuda e usar atalhos

“Teclado e leitor de tela” diferencia a tabela de consulta dos controles interativos: as combinações escritas não são botões, Tab não percorre as células, e a leitura da tabela usa os comandos do leitor. J-02 orienta fechar a Ajuda antes de usar controles e atalhos de navegação da página, conservando os caminhos de retorno por botão identificado ou Esc.

O texto inclui as alternativas já existentes Ctrl + Alt + Shift + T, K, H, V e A, com o destino e as condições de cada uma. Não promete que funcionem com qualquer navegador, sistema ou leitor; os botões e links visíveis continuam sendo o caminho principal quando houver conflito. Consultar a tabela não executa ações, libera recursos nem altera permissões. A fonte compartilhada conserva as mesmas instruções no manual contextual, completo e autônomo.

## Abrir o manual

Na Ajuda das páginas autenticadas, use “Manual do GLPI Acessível”; o link informa a abertura em nova aba. A tela da tarefa permanece na aba anterior. Na página inicial convencional, use “Consultar manual do GLPI Acessível” no cartão da interface acessível; esse acesso abre na mesma aba.

## Entender o contexto da leitura

Na edição integrada ao portal, o bloco Contexto desta leitura apresenta o perfil ativo, a entidade, o escopo e a versão do GLPI confirmados nessa abertura. Informação não confirmada recebe indicação própria. O nome exibido orienta o leitor; ele não é uma regra de autorização.

Perfil, entidade e regras nativas podem limitar uma operação por chamado ou recurso. Por isso, “Orientação para este contexto” não promete que todas as ações de um capítulo estejam autorizadas. Massa, edição de interação, Tag e formulários conservam suas condições e incertezas.

Na edição integrada, trocar perfil ou entidade em outra aba altera a sessão compartilhada, mas não reorganiza automaticamente uma leitura aberta. Reabra ou recarregue o manual para conferir o contexto atualizado. Não é preciso trocar perfil para consultar o completo.

O manual não lista entidades, busca chamados, consulta integrantes de grupos ou carrega registros de auditoria para compor suas orientações. O contexto não contém login, e-mail ou tokens.

## Escolher contextual ou completo

O Manual para o contexto atual prioriza assuntos conforme módulos, liberações, direitos gerais e dependências confirmáveis na abertura. Assuntos não priorizados mantêm aviso e acesso ao conteúdo correspondente no manual completo.

Na edição integrada, Consultar manual completo apresenta todos os procedimentos, inclusive opções não liberadas, incompatíveis ou não autorizadas no contexto. Ele não concede ações. “Disponibilidade não verificada” é diferente de falta de direito, desativação ou ausência de dados.

O HTML autônomo já reúne todos os assuntos. Use o sumário e Voltar ao sumário para percorrê-los; não há um controle para trocar a modalidade de leitura. A abertura, “Sobre este manual”, explica as variações por perfil, entidade, configuração e componentes instalados. A edição não repete os estados dinâmicos de disponibilidade em cada capítulo nem recebe dados de sessão. As pré-condições específicas de cada procedimento permanecem no texto. O integrado continua exigindo autenticação e mantém seus avisos de disponibilidade; a apresentação editorial autônoma não os transforma em autorização.

## Aprender pelos nomes dos controles e pelas tarefas

### Escolher a apresentação do chamado

O assunto `modo-apresentacao` explica os botões “Simples” e “Completa” no grupo “Apresentação da tela”, no início do detalhe do chamado. Completa conserva a apresentação habitual e é o padrão inicial. Simples é uma escolha opcional da pessoa: recolhe detalhes complementares sem retirar ações autorizadas. A orientação não recomenda esse modo automaticamente para pessoas cegas nem promete que menos conteúdo aberto facilite todo leitor de tela.

O procedimento identifica os expansores “Mais informações do chamado”, “Contatos do requisitante”, “Alterar responsáveis e participantes” e “Alterar status do chamado”. Ensina Tab, Enter/Espaço, leitura por títulos e o retorno a Completa. Diferencia recolher uma região de apagar dados; a linha do tempo conserva sua expansão existente. A preferência é vinculada à conta, sem mudar regras ou permissões, e não se confunde com as modalidades contextual/completa do próprio manual. A primeira entrega limita o ajuste ao detalhe, não à lista nem à edição de interações.

No manual contextual, a seção só exibe o procedimento quando `presentation_simple_mode`, o módulo de chamados, o direito de leitura e a família GLPI 10/11 forem confirmados. A descoberta não lê nem grava a preferência pessoal. No completo e no autônomo, o texto permanece com suas condições de uso. Uma liberação por perfil não concede acesso a chamados.

A troca sem recarga conserva o que está preparado na mesma página, mas não cria armazenamento de rascunho. O texto orienta conferir erros, destino dos links e avisos de persistência da preferência, e explica o fallback completo sem JavaScript. O exercício limita-se a encontrar a mesma informação nos dois modos, sem registrar um atendimento. Ensaios com NVDA/JAWS e usuários iniciantes e experientes devem registrar descoberta, sucesso, expansões, erros e perdas de foco; cobertura editorial ou teste automático não os substitui.

A inclusão e a edição usam os formulários próprios do portal: cabeçalho, contexto, navegação, Ajuda e campos conhecidos continuam nos mesmos lugares. Quando a formatação está disponível, somente o editor e a seleção de arquivos do GLPI são incorporados ao campo de conteúdo. Não se acrescentam o formulário completo, o cabeçalho, o menu lateral nem campos adicionais da interface convencional. Salvar retorna ao chamado no portal; as regras e autorizações continuam sendo as do GLPI.

J-06 separa abrir a lista, buscar número/texto, preparar filtros, combinar regras avançadas, conferir o resumo, escolher colunas e navegar entre páginas. Pesquisas salvas tem procedimento próprio para aplicar, criar privada, definir/remover padrão, renomear e excluir quando autorizado. Aplicar uma consulta é diferente de guardar uma pesquisa ou alterar uma preferência.

J-08 mantém sete caminhos independentes de atendimento. J-09 trata aprovação ou recusa de solução. O texto identifica os botões que enviam diretamente e os percursos com revisão; não acrescenta uma confirmação a uma ação que não a oferece.

Ao incluir um grupo técnico como novo responsável pelo chamado, o GLPI pode acionar regras do Escalade quando a extensão estiver ativa e configurada para essa operação. Isso depende do caminho e das condições da instalação, não de todo salvamento. Grupo observador e grupo da tarefa têm outras funções. Depois de confirmar, confira responsáveis, status e histórico antes de repetir uma operação incerta. A orientação não promete equivalência ao botão Escalar nem homologa qualquer combinação de versões; os resultados de compatibilidade pertencem ao relatório de testes da entrega.

Nos contratos reconhecidos, a atualização de responsáveis usa uma operação nativa de atores, com a sequência enviada e os efeitos dos hooks. O GLPI pode aceitar vários grupos novos e terminar com apenas um grupo responsável por causa dessas regras; o resultado final não demonstra uma restrição de entrada a um grupo. Uma restrição real da operação nativa, quando existente, continua sendo respeitada. Manter vários grupos atuais também é diferente de incluir vários novos.

J-08 orienta conferir as inclusões e remoções solicitadas, a ordem de processamento indicada e os avisos de efeitos automáticos antes de confirmar. Depois, a referência são os responsáveis efetivos no chamado, não a promessa de que todos os selecionados permanecerão. A seleção não envia a atribuição, e cancelar uma revisão na mesma página não registra a operação.

A continuação convencional depende de um contrato indisponível ou não reconhecido, não apenas da quantidade de grupos novos. Quando for oferecida antes de gravar, o manual identifica “Continuar a atribuição deste chamado no GLPI convencional”, avisa sobre a mesma aba e a não transferência das escolhas, do texto e dos arquivos pendentes. Orienta preservar os rascunhos, preparar novamente os participantes autorizados e, se for continuar uma interação com anexos, selecionar os arquivos no formulário correspondente. Essa explicação usa a mesma fonte em todas as apresentações do manual, sem uma nova liberação específica para o texto nem avisos técnicos repetidos na edição autônoma.

J-06, J-08 e Pesquisas salvas têm índices internos para alcançar o procedimento desejado. Os destinos são títulos do próprio capítulo, preparados para receber foco sem entrar na sequência habitual de Tab. Esses índices aparecem com o conteúdo do procedimento, não nos avisos resumidos de indisponibilidade. Os links dos caminhos por público apontam para capítulos, cujos destinos permanecem presentes no manual contextual, completo e autônomo.

No índice de Pesquisas salvas, “Definir ou retirar a pesquisa padrão” e “Renomear ou excluir uma pesquisa salva” identificam o assunto mesmo numa lista de links do leitor de tela. Retirar o padrão remove essa preferência, sem excluir a pesquisa; a exclusão tem seu próprio controle e confirmação. Os títulos acompanham a escala do texto, preservando os níveis que organizam a leitura por leitor de tela.

As orientações usam nomes e estados a conferir em vez de prometer uma frase igual em todos os leitores. Procedimentos, exemplos, consequências, recuperação e exercícios podem ser entendidos sem enxergar uma figura ou identificar cor/posição.

## Informar datas nos filtros

O capítulo `filtros-data-hora`, vinculado a `tickets_read`, ensina a escolher um campo de data autorizado nos filtros avançados, considerar o operador e preencher Valor por calendário ou digitação. A preparação é diferente da execução; o procedimento termina conferindo Pesquisa aplicada e não exige guardar uma pesquisa. A regra documental acompanha o acesso geral à pesquisa, sem prometer a presença de um campo ou operador específico para todos os perfis.

O texto explica a diferença entre data e data/hora, a preservação de segundos ao retomar consultas, a variação de formato do navegador e a ausência de conversão automática para começo/fim do dia ou outro fuso. O exemplo de preenchimento inválido não é corrigido por adivinhação. Um erro de entrada é distinto de resultado vazio; valores antigos que precisem de revisão não devem desaparecer silenciosamente.

O calendário reutiliza o componente do GLPI quando disponível, dentro do campo do portal, sem importar o formulário convencional. A orientação contempla a alternativa de data do navegador ou digitação por compatibilidade, sem exigir o calendário nem prometer acessibilidade de uma biblioteca por sua origem. Hoje, Agora e demais relativos ficam fora desse procedimento. A fonte é a mesma para o contextual, o completo e o autônomo; o texto explica a operação sem depender de uma nova captura.

Os testes de estrutura e os exemplos didáticos não substituem ensaio real com leitor de tela. Devem ser verificadas associação do rótulo e erro ao campo visível, entrada e saída por teclado, anúncio do valor, preservação da consulta e uso com ampliação nos dois GLPIs.

## Conferir arquivos e altura antes de enviar

### Ler anexos sem depender da galeria

J-07 apresenta o acesso “Consultar anexos e opções disponíveis”, o nome e a origem do arquivo, informação textual disponível e dados técnicos; a prévia é opcional. A leitura dos anexos não depende da liberação da edição formatada. “Descrição da imagem nesta interação” vem de uma ocorrência autorizada da imagem nesse contexto. “Comentário cadastrado no documento” identifica um comentário, não uma descrição alternativa validada. “Descrição do conteúdo não informada.” é uma indicação neutra de ausência, não erro nem descrição fabricada. Nome, formato e tamanho não explicam o conteúdo visual.

As ações nativas continuam separadas: abrir/visualizar, editar os dados do documento, remover vínculos e alterar a propriedade de lista de exclusão para importação. “Excluir permanentemente” da timeline pode remover referências no chamado e em interações abrangidas, limpar imagens da descrição e produzir histórico/notificações; não é o mesmo que purga global do documento. A lista de importação é propriedade compartilhada do documento e não muda seus direitos de leitura. O manual não promete o mesmo controle rápido nem tratamento idêntico de importação no GLPI 10 e 11.

Os procedimentos orientam abrir “Consultar anexos e opções disponíveis” para gerenciar arquivos: as ações ficam nessa página, não no formulário de edição aberto. Antes de navegar, é necessário concluir ou preservar o rascunho, sem promessa de transferência ou proteção integral. O texto orienta ler o efeito e a confirmação nativos e conferir resultado incerto antes de repetir. Não há OCR, descrição automática ou recuperação automática de arquivos prometidos. A galeria não é pré-requisito para compreender as ações disponíveis.

### Adicionar não é editar

O assunto `interacoes-inclusao-rica` tem regra própria `tickets.interaction_rich_add`, independente da liberação de edição. A opção começa desativada e continua exigindo direito nativo de inclusão. `interacoes-edicao-rica` mantém sua regra de edição, dependente da liberação base e dos direitos de atualização. O contexto não usa o direito de editar para decidir que alguém pode adicionar, nem o contrário.

Na inclusão, o manual orienta começar no bloco de acompanhamento ou tarefa, conferir chamado e tipo, aplicar modelos quando disponíveis, revisar seus efeitos, editar por teclado, conferir arquivos e usar o botão de adicionar somente com autorização. Há um formulário próprio por operação, com o editor formatado ou o campo simples conforme a disponibilidade. Os campos e valores iniciais da tarefa permanecem nesse mesmo bloco; os acessos antigos de inclusão com formatação levam ao bloco correspondente no chamado, sem abrir outro formulário. Na edição, a referência é a interação existente: o procedimento cobre texto, imagens e visibilidade disponíveis, não a alteração de estado, duração, planejamento ou responsáveis da tarefa. Uma falha ao abrir o editor não converte conteúdo salvo para texto simples. Salvar retorna ao chamado do portal. A solução mantém seu procedimento próprio.

Os links de inclusão com formatação não são uma etapa obrigatória antes de escrever no editor incorporado: conduzem ao mesmo bloco de atendimento do chamado. Antes de navegar, o usuário deve preservar o que preparou e conferir os arquivos pendentes; o link não transfere o rascunho de outra página. Uma recuperação de arquivo recusado mantém o rascunho e as escolhas reapresentadas, sem prometer migração entre modos de edição. A orientação não promete proteção geral dos campos nem recuperação automática de arquivos.

O completo integrado e a edição offline incluem os dois procedimentos com suas condições. No contextual, cada assunto usa sua disponibilidade própria, sem consultar chamados ou anexos para produzir a orientação.

Um arquivo pendente está selecionado na página; não comprova upload nem vínculo registrado. Confira nome e quantidade antes de enviar. Abrir novamente o seletor pode substituir a seleção anterior; não há promessa de acumular escolhas sucessivas.

No formulário simples, somente a Descrição do acompanhamento oferece Ampliar campo e Restaurar altura padrão. Tab alcança os controles, Enter/Espaço os acionam e Shift+Tab a partir de Ampliar retorna ao campo. Restaurar não apaga nem envia o texto. Fonte, privacidade, arquivos e demais formulários não devem mudar por esse ajuste. O editor formatado usa os controles que o GLPI oferecer para sua área de edição; não se promete que os botões próprios do campo simples controlem esse editor.

O exercício prepara texto e arquivo fictícios, ajusta a altura, confere o estado pendente e termina pela limpeza dos dados de treinamento, sem enviar. O arquivo permanece apenas selecionado; o exercício não verifica seu envio ou registro. Recarregar, sair ou mudar contexto pode perder o rascunho e exigir nova seleção de arquivos.

Nos formulários protegidos, arrastar arquivo para área sem suporte é recusado com orientação para usar o seletor. A colagem é opcional e não controla a seleção comum. Selecionar grupo da tarefa também só prepara esse campo, sem encaminhar automaticamente o chamado.

## Roteiros e auditoria com direitos específicos

A gestão de roteiros explica cadastro manual, edição/inativação, exclusão e importação/exportação, além das propostas individuais e em lote. Aprovar uma proposta pode criar, atualizar, ativar ou inativar um roteiro conforme sua consequência; não publica artigos.

As seções de auditoria explicam consulta, filtros, paginação e exportação limitada de metadados autorizados. Direitos de leitura/exportação e de conteúdo sensível/global são distintos. A permissão de configurar o plugin não os substitui.

A referência administrativa orienta o alcance dos grupos de configuração e o ponto de salvamento. O usuário comum não precisa executar etapas administrativas para utilizar o portal ou compreender o manual.

## Usar figuras e exemplos

As figuras são complementares e mantêm as versões registradas nas capturas. Sua presença numa edição nova não significa recaptura nem interface idêntica em todo perfil ou versão de manutenção do GLPI. Alternativas textuais descrevem o propósito; legendas contextualizam o exemplo. O procedimento completo permanece em texto.

No contextual, a figura acompanha a disponibilidade do procedimento. No completo e no autônomo, ela continua sendo apenas orientação, sem liberar funções. A referência para a tarefa é o texto e o controle oferecido no ambiente atual.

## Cancelar e recuperar sem duplicar ações

Cancelar uma revisão na mesma página não executa a ação. Isso não promete armazenamento persistente do rascunho. Diferencie sessão expirada, confirmação expirada, mudança de contexto, resultado vazio, indisponibilidade e gravação incerta.

Em uma tentativa incerta, confira o chamado, histórico, catálogo ou fila antes de repetir. Não contorne revisão, substitua uma pesquisa por universo mais amplo silenciosamente ou amplie direitos para fazer uma operação funcionar. A instituição continua responsável pelas regras e pelos canais de suporte.

## Conferência e limites

A matriz de cobertura do manual 2.0 identifica telas, operações, regras documentais e seus testes. Cobertura editorial não equivale a homologação institucional ou certificação WCAG, eMAG ou RGAA.

As comparações locais desta entrega abrangem os GLPIs 10 e 11 com limpeza de grupos ativa e duas ordens de inclusão, além de um percurso permitido de Hotliner no GLPI 11. Limpeza desligada, matriz de destinos permitidos/negados, outras combinações de versões e configuração e entrega externa de notificações exigem seus próprios ensaios. Os resultados não equivalem a paridade universal do Escalade.

Leitor real, impressão e ensaios autenticados sem JavaScript devem ser registrados separadamente. Texto a 200% e zoom real a 400% continuam sujeitos ao adiamento solicitado pelo usuário; 320 pixels ou fixture não os substituem.
