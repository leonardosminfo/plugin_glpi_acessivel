# Versão 0.4.18-beta.55

Prioridade: leitura acessível de anexos e apresentação das ações nativas do GLPI 10 e 11. Manual 3.3, epoch `20261105-03`.

- Anexos de acompanhamento/tarefa têm acesso próprio de leitura, independente das liberações de edição. Nome, formato, tamanho, comentário cadastrado e descrição da ocorrência autorizada precedem a prévia opcional. Nome de arquivo não é descrição da imagem.
- Somente imagens confirmadas pelo helper nativo recebem prévia; os arquivos continuam entregues pelo endpoint autorizado `document.send.php`.
- A gestão usa controles produzidos pelo GLPI para o evento exato, intersectados com os documentos autorizados. Falha de contrato oculta a gestão, não a leitura. Nenhum novo POST de documento foi criado.
- Remover da timeline pode alcançar os vínculos do documento no chamado e em suas interações. Não é purga global. A lista de exclusão de importação é uma propriedade compartilhada do documento, não controle de privacidade; o controle rápido depende da versão nativa.
- Inclusão pelo formulário nativo tem liberação própria, inicialmente desativada, sem depender da liberação de edição. O formulário simples existente permanece disponível. CREATE, UPDATE e READ são verificados separadamente.
- Formulários nativos preservam campos, modelos, editor, anexos, CSRF, endpoint e retorno do GLPI. Não se promete conversão de rascunhos nem recuperação automática de arquivos temporários.
- Manual contextual, completo e HTML autônomo atualizados pela mesma fonte editorial.

Sem SQL novo, alteração do núcleo, direitos adicionais ou substituição de regras nativas. A liberação controla a abertura pelo portal, não cancela um POST nativo já iniciado. Leitor de tela real e homologação institucional continuam exigindo evidência própria; a entrega não é certificação integral WCAG/eMAG/RGAA.

Consulte o registro de testes desta versão para distinguir resultados executados e limitações.
