# Posição dos acessos preservada entre páginas da mesma aba

Versão 0.4.18-beta.51, epoch `20261104-04`, de 04/11/2026. Mantém o manual 3.0 sem alteração de conteúdo, atualizando somente a cobertura de versão. A [verificação direcionada](test_execution_0.4.18-beta.51.md) foi concluída.

## Correção mínima

Uma posição ajustada na beta.50 podia deixar de ser aplicada ao navegar entre páginas na mesma aba. A leitura preliminar antes da configuração pronta e a mudança da composição de acessos — por exemplo, uma página com dois ícones e outra com apenas um — podiam fazer um registro compatível ser tratado como pertencente a outra configuração.

A beta.51 vincula a leitura da posição à configuração estável de layout/tamanho e evita descartar o ajuste somente porque os IDs presentes na página mudaram. O formato anterior de assinatura que incluía a composição dos acessos recebe tratamento de compatibilidade, sem reinterpretar a origem ou o referencial das coordenadas.

## O que permanece igual

O armazenamento continua em `sessionStorage`, restrito à aba. A entrega não cria persistência entre abas, por conta, entre dispositivos ou em banco. Também não presume que o relato original tenha ocorrido em outra aba; esse não é o diagnóstico necessário para a correção delimitada.

Mantêm-se os ícones sobre a página sem faixa reservada, os quatro layouts e os tamanhos configurados. Arraste pela alça, quatro direções em passos de 8 pixels, desfazer, restaurar e fechar continuam com os mesmos rótulos e destinos. A guarda de foco, os modais e as exceções de geometria da beta.50 não ganham regras novas nesta correção. Não há SQL novo, mudança de regras nativas ou nova mensagem de tradução.

O manual permanece na edição 3.0, com seus 45 assuntos, sete figuras e instrução já disponível ao usuário comum. Seu conteúdo didático e as imagens não são reescritos; somente `covered_plugin_version` passa a beta.51.

## Validação e limites

Os três controles negativos falharam na beta.50 e passaram na beta.51: dois cenários de configuração atrasada, nos layouts separado e empilhado, e um de navegação com composição diferente de acessos. A migração da assinatura anterior de três partes também passou. A rodada final concluiu 152 testes de navegador: 29 de arraste/posição, cinco de foco, 65 de layout e 53 de rolagem nativa. PHP 8.1.31 e 8.3.14 passaram em 2.724 testes e 20.731 asserções por execução, sem multiplicar a quantidade de testes pelos runtimes.

Nos GLPI 11/8080 e GLPI 10/8089, dois percursos autenticados ajustaram a posição por arraste de mouse nos chamados sintéticos 182 e 167 e navegaram, na mesma aba, por computadores, lista de chamados, portal com um ícone e retorno ao chamado com dois. As oito navegações conservaram o registro e recuperaram as posições por ID, com diferença de até um pixel no retorno, sem gravar chamados ou preferências nativas.

No navegador interativo do GLPI 11, Super-Admin com menu lateral, o chamado 152 foi reposicionado pelo controle de direção e seguido pela navegação Ativos/Computadores até `computer.form.php?id=1`. O retorno ao chamado conservou as coordenadas com diferença de até 0,15 pixel por arredondamento. A captura e o registro são `device-position-glpi11.png` e `device-position-glpi11.json`.

Não houve mudança de CSS, referencial de coordenadas, SQL ou escopo de armazenamento. A fonte do manual permanece idêntica à beta.50, exceto pela cobertura de versão; isso não é anunciado como uma nova execução da regressão de navegador do manual. A verificação do pacote e seu checksum são consolidados no recibo externo.

NVDA/JAWS, ampliação operacional integral 200%/400% e aceite institucional mantêm sua validação própria pendente. Não há certificação WCAG/eMAG/RGAA. O checksum do pacote pertence ao recibo externo, sem hash autorreferente neste documento.
