# GLPI Acessível 0.4.18-beta.34

Esta versão corrige o corte de textos e campos no painel de pesquisas salvas em telas estreitas. A divergência foi reproduzida a 320 CSS pixels nos GLPI 11.0.7 e 10.0.10 locais: a página permanecia contida, mas o conteúdo interno do painel excedia sua largura.

O ajuste CSS limita o tamanho mínimo das colunas e do campo de busca à área disponível. Não oculta conteúdo, reduz a fonte ou muda a semântica do painel. Consultas, permissões, pesquisas salvas e regras nativas permanecem inalteradas, sem SQL novo.

Versão 0.4.18-beta.34, epoch 20261028-04. Manual contextual e completo 1.8 com cobertura atualizada, sem mudanças nos procedimentos ou nas figuras. Os pacotes publicados anteriores permanecem preservados.

Os resultados da conferência local e seus limites estão em [Testes F8 a 320 pixels](test_execution_0.4.18-beta.34.md). O recorte corrigido passou nos dois ambientes; o plano de estabilização completo permanece aberto.
