# GLPI Acessível 0.4.18-beta.24

Esta candidata corrige divergências demonstradas no fechamento local da estabilização. Mantém os modelos e APIs públicos do GLPI 10 e 11, sem SQL novo, migração estrutural ou alteração de regras nativas. Não representa o encerramento de toda a matriz de homologação.

| Frente | Implementação ou verificação desta entrega | Limite |
| --- | --- | --- |
| F5 Categorias | Separa o catálogo de abertura do catálogo autorizado de edição de chamado existente. A visibilidade helpdesk continua aplicada na criação; edição e reclassificação seguem entidade, tipo e autorização do chamado. O caminho alternativo sem seletor remoto usa o mesmo descritor de criação. | Não adiciona uma proibição universal de categoria na atualização. Modelos, permissões e validação final do Ticket permanecem nativos. |
| F7 Anexos | Correção da confirmação de vínculos quando o GLPI reutiliza documentos pelo conteúdo e altera o nome armazenado. A identidade é conferida com evidência calculada no servidor antes da gravação e com o vínculo ao objeto resultante. | Não corrige metadados no núcleo, não cria upload alternativo e não reenvia arquivos automaticamente. |
| F6 Feedback de tarefa | Confirmação textual neutra após adicionar tarefa, sem afirmar a visibilidade apenas com base na opção enviada. | A visibilidade efetiva continua determinada pelo modelo e pelo núcleo; deve ser conferida nas interações. |
| F6 C12 Modelos | Marca de obrigatório e ARIA sincronizadas ao selecionar/trocar modelo. Valores predefinidos são preenchimentos iniciais, não bloqueios extras; campos ocultos e somente leitura continuam protegidos. | Não cria somente leitura no GLPI 10 nem modifica as regras do modelo. Campos legitimamente omitidos não são confundidos com tentativa explícita de alteração. |
| F1 Confirmações | Regressões determinísticas aos 299, 300 e 301 segundos e testes reais de recusa de formulário expirado nos dois núcleos. | O prazo de 300 segundos não mudou. Perda de resposta e BFCache reais ainda exigem ensaio específico. |
| F2 Concorrência | Duas sessões independentes, Chrome e navegador integrado, confirmaram a recusa de revisão obsoleta nos dois GLPIs. | Não oferece compare-and-swap atômico nem resolve a arquitetura institucional por inferência. |
| F4 Pesquisa | Comparação nativo/portal de onze chamados sintéticos no GLPI 11, com título e Técnico vazio, em duas páginas 10 + 1, sem diferenças de conjunto. | Demais papéis, operadores e GLPI 10 ainda precisam de ampliação. A tentativa integrada de criar pesquisa privada no GLPI 11 falhou e permanece pendente de diagnóstico. |
| F6 Modelos e tarefas | Modelos sintéticos, recusa de categoria obrigatória vazia, registro após preenchimento e releitura dos grupos de tarefas. | Preparar modelos não equivale a testar todas as combinações. GLPI 10 não oferece os mesmos campos somente leitura do GLPI 11. |
| Manual | Manual HTML 1.8, nas edições contextual, completa e autônoma, explica as diferenças de categoria entre abertura e edição. | As sete figuras mantêm suas versões reais de captura. Os procedimentos permanecem completos em texto. |

Os testes de autorização usaram uma conta sintética existente: chamado e anexo recusados nos dois ambientes, enquanto a conta autorizada abriu o mesmo arquivo. Nenhuma permissão foi ampliada. A regressão definitiva passou com 2.153 testes PHP por runtime (8.1/8.3), 420 testes de navegador e 3.320 mensagens i18n. Esses resultados não encerram as pendências discriminadas no relatório.

## Atualização

Atualize os arquivos e execute a atualização nativa do plugin, sem desinstalar. Confira versão de código e cadastro `0.4.18-beta.24` e runtime epoch `20261027-02`. Em instalações com réplicas, a infraestrutura deve conferir os mesmos arquivos em todas elas.

As quinze liberações existentes não são ampliadas por esta entrega. A leitura do manual também não ativa funcionalidades nem altera direitos.

## Homologação restante

O relatório `test_execution_0.4.18-beta.24.md` separa os resultados locais das pendências. O leitor de tela real permanece pendente por decisão do usuário; o zoom nativo de 400% não foi substituído por emulação de viewport. A causa institucional de sessão, origem, confirmação ou timeout em OpenShift continua dependente de investigação no ambiente afetado.

Adaptações futuras permanecem fora desta entrega: documentos e validações autônomos, relações entre chamados, itens/ativos, Escalar, acúmulo de anexos, upload por arraste e novos cartões de observadores. A entrega não é uma certificação WCAG, eMAG ou RGAA.
