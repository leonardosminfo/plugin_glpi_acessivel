# Versão 0.4.18-beta.45

Entrega com manual 2.6 e epoch `20261029-08`. O portal mantém a atribuição pelo núcleo e contém, antes da gravação, a inclusão de mais de um novo grupo técnico numa mesma alteração com Escalade ativo.

## Continuação para alterações com vários grupos novos

A continuação explícita abre o mesmo chamado na interface convencional. O portal não executa parcialmente a alteração nem remove participantes para tentar torná-la compatível. Com JavaScript, o aviso aparece antes do envio e mantém as escolhas, os rascunhos e os arquivos pendentes na mesma página até o usuário decidir sair. O link abre na mesma aba e não transfere esses dados. Sem JavaScript ou em POST direto, a guarda independente do servidor impede a alteração, mas não se promete preservar arquivos pendentes após a navegação. Os direitos e os destinos autorizados continuam sendo os nativos.

Essa contenção não proíbe múltiplos grupos no GLPI. Manter grupos atuais é diferente de incluir vários grupos novos, e o tratamento de um grupo novo preserva seu contrato delimitado. Não há executor próprio do Escalade, cópia de suas regras, SQL novo ou alteração de permissões.

## Manual contextual completo e autônomo

J-08 explica quando continuar no GLPI convencional, qual link utilizar, a abertura na mesma aba e a necessidade de preparar novamente os participantes. A orientação não promete suporte ao fluxo de vários grupos novos dentro do portal. Preserva os 45 assuntos, as sete figuras, os destinos de navegação e os créditos.

O HTML 2.5 e a distribuição beta.44 ficam preservados. Os metadados atuais, o manifesto das figuras e os contratos de pacote passam a manual 2.6 e beta.45, mantendo os gates históricos e os mapeamentos anteriores.

## Validação

Os resultados desta entrega e as diferenças entre testes automatizados, ensaios autenticados e pendências institucionais estão em [Execução da beta.45](test_execution_0.4.18-beta.45.md). Nenhuma conclusão desta página substitui ensaio com NVDA/JAWS, piloto com usuários, impressão física ou aceite da configuração institucional.

A possível perda do identificador do modelo ao cancelar sua reaplicação permanece como investigação complementar. Não foi alterada sem efeito nativo persistido comprovado.
