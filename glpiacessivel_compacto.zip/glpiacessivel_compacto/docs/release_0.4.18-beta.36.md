# GLPI Acessível 0.4.18-beta.36

Versão 0.4.18-beta.36, epoch `20261028-06`; GLPI 11.0.7 no 8080 e GLPI 10.0.10 no 8089. Reteste local concluído nos cenários registrados; o plano completo de estabilização continua aberto.

## Divergência e escopo

Na leitura de conteúdo operacional com imagem larga e ancestral rígido, a 320 CSS pixels, foi comprovada no GLPI 11 uma barreira visual no foco do link que envolve a imagem. A presença de foco no elemento não tornou seu indicador suficientemente perceptível no recorte observado. Esse achado não significa falha de carregamento, perda de conteúdo ou ampliação de permissões.

O ajuste aplica foco visível na própria imagem vinculada, somente em `.glpiacessivel-content[data-glpiacessivel-scrollable-content] a:focus-visible img`. Combina indicador claro e borda escura e utiliza a cor de destaque do sistema em cores forçadas. Não muda o conteúdo armazenado, DOM, JavaScript de produção, destino do link, renderizador nativo, SQL ou regras de autorização. A rolagem permanece local quando o conteúdo realmente exige largura adicional.

## Validação local e limites

O reteste passou nas doze combinações de dois ambientes, larguras reais de 320/1280 CSS pixels e três temas: claro, noturno e alto contraste. Os conteúdos sintéticos de descrição, acompanhamento e tarefa permaneceram contidos; o recipiente rígido conservou rolagem local, alcance dos extremos e saída por Tab. No GLPI 11, o foco na imagem vinculada ficou perceptível nas extremidades esquerda e direita. O [relatório desta rodada](test_execution_0.4.18-beta.36.md) delimita as observações e evidências; essa aprovação não encerra integralmente a F3/F8 nem constitui certificação de acessibilidade.

A tarefa final do GLPI 10 usa imagem sem link envolvente para isolar contenção e não recebeu novo foco. A limitação observada na galeria vinculada nativa do GLPI 10, que não transporta a alternativa textual em ambas as interfaces, permanece separada: esta versão não a corrige nem aprova sua acessibilidade.

## Manual e preservação

O manual permanece na versão 1.8, com cobertura beta.36. Não há novo procedimento, alteração das figuras ou atualização artificial das versões em que foram capturadas. As edições contextual e completa continuam a partir da mesma fonte editorial. A exportação autônoma foi gerada pelo processo oficial, preservando as 37 seções e as figuras; sua atualização de cobertura não equivale a uma nova homologação offline por si só.

Os pacotes publicados anteriores permanecem preservados. Não houve alteração institucional ou de permissões para produzir o cenário. Texto a 200%, zoom real a 400%, leitor real e as demais pendências mantêm suas classificações próprias.
