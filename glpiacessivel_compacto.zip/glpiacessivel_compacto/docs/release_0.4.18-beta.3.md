# GLPI Acessível 0.4.18-beta.3

Esta versão corrige o fluxo de ações em massa identificado na conferência da beta.2. O núcleo do GLPI continua responsável pelas alterações, permissões e hooks; a conferência adicional dos participantes é somente de leitura.

## Fluxo e escolhas

As preparações de abas distintas permanecem independentes enquanto o perfil e a entidade forem os mesmos. A retenção é limitada a 20 comprovantes de página e cinco fluxos por sessão, com validade curta. Trocar o contexto pelo portal elimina os estados anteriores; contexto divergente e permissões atuais são revalidados no servidor.

As etapas válidas usam redirecionamento 303 após POST. A página GET apresenta o estado armazenado por um identificador opaco: não prepara nem executa operações. Cancelamento, confirmação e continuação permanecem POST com CSRF nativo. Voltar ou recarregar não reativa uma execução concluída, cancelada ou incerta.

Status, papel, tipo e participante exigem escolha explícita. Revisar conserva os valores enviados. As ações são identificadas como “Alterar status” e “Adicionar participante”; adicionar não substitui nem remove os participantes existentes. Outras operações continuam disponíveis na interface convencional, sem anúncio de cobertura integral do catálogo no portal.

O prazo de preparação ou de continuação pendente pode ser renovado por cinco minutos, até dez vezes ao longo do fluxo, após revalidação de contexto, seleção e disponibilidade nativa. Um aviso informa a proximidade da expiração. Renovar não executa nem continua a ação, não prorroga a sessão do GLPI e não recupera um estado nativo expirado. A confirmação não é preservada como consentimento para uma execução futura.

Durante a renovação, os parâmetros pendentes suportados são guardados temporariamente na aba e restaurados quando ainda compatíveis com os campos e opções disponíveis. Campos ocultos, tokens de segurança e confirmação não entram nesse rascunho. Se a preservação não for possível, o portal avisa antes de prosseguir; não trunca silenciosamente os valores.

Uma etapa de processamento recebe um prazo novo para apresentar seu resultado ou sua continuação, mesmo que o processamento ultrapasse a validade anterior. Consultar ou recarregar a página não prolonga esse prazo. Após uma execução incerta ou a expiração de uma continuação, consulte os chamados e não repita a operação inicial.

## Conferência de participantes

Os contadores originais do GLPI são apresentados separadamente da observação dos vínculos persistidos. A conferência distingue vínculo preexistente e mantido, vínculo observado após execução, vínculo não confirmado e leitura indisponível, limitada aos chamados selecionados e autorizados.

Essa distinção é necessária porque uma restrição aplicada na criação do vínculo pode não aparecer como falha no contador de atualização do chamado. A conferência não identifica automaticamente a causa, não comprova autoria exclusiva em alterações concorrentes e não corrige, remove ou repete operações.

Hooks de servidor continuam sendo executados pelo núcleo. Uma restrição apenas visual de outro plugin não garante bloqueio no servidor. Compatibilidade com um plugin específico depende da sua versão, configuração e homologação conjunta; os testes genéricos locais não substituem esse aceite.

## Instalação e limites

Versão `0.4.18-beta.3`, runtime `20261009-03`, sem migração nova de esquema. A atualização utiliza o ciclo nativo, preservando configurações e dados. Restaurar código não desfaz alterações de chamados realizadas pelo GLPI.

O alcance da validação consta em [Testes da beta.3](test_execution_0.4.18-beta.3.md). Avaliação manual com leitores de tela e validação do ambiente TRF/OpenShift permanecem necessárias. Não há alteração de configuração de infraestrutura nem promessa de compatibilidade universal com plugins externos.
