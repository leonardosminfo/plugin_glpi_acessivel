# GLPI Acessível 0.4.18-beta.9

Entrega do plano de atendimento ao relatório de aceitação, limitada às APIs públicas e rotas nativas comuns ao GLPI 10 e 11. O legado permanece preservado; não há SQL novo, nova tabela, índice ou migração nesta versão. Runtime: 20261018-04.

## Disponível

- Documentos abrem em nova aba, com aviso no link. Requerentes aparecem antes da descrição.
- Cabeçalhos ordenam pesquisas simples; pesquisas avançadas e salvas conservam o painel de ordenação existente.
- Prévia da descrição consulta a rota nativa, que verifica o acesso ao chamado. O conteúdo é filtrado para apresentação segura.
- Edição de texto simples e privacidade de acompanhamentos e tarefas salvos, com revalidação das permissões e do vínculo, CSRF, proteção contra repetição e preservação do rascunho em falhas. Atualizações e eventos usam as APIs públicas nativas.
- Imagens coladas na abertura, no acompanhamento e na tarefa entram na seleção de arquivos do formulário e seguem o processamento multipart existente. Não há envio automático nem endpoint alternativo.
- Atualização da lista respeita o intervalo configurado no GLPI e pode ser pausada. Foco, seleção, rascunho, diálogo e prévia impedem substituição automática do conteúdo. Erros interrompem a atualização automática.
- Links de estatísticas nativas por técnico atribuído e por técnico de tarefas, apenas com a permissão nativa. Não são novos indicadores calculados pelo plugin.

## Limites explícitos

- Exportação fiel às colunas da lista não foi habilitada: o contrato público comum às duas versões não garante essas colunas sem alterar preferências nativas. Não se oferece uma exportação diferente como equivalente.
- Texto rico, imagens e HTML salvos permanecem intactos. Sua edição textual é encaminhada ao chamado nativo; o editor simples do plugin não os converte nem remove. A privacidade pode ser alterada sem reenviar o conteúdo.
- Ordenação direta dos cabeçalhos de pesquisas avançadas/salvas não foi acrescentada. Utiliza-se a ordenação existente para preservar a consulta.
- Os reposicionamentos de “Pesquisa de chamados” e de “responsáveis depois do encaminhamento” foram adiados por orientação do usuário.
- Não foram acrescentados arraste de critérios, novas regras de ações em massa, suporte a plugin de etiquetas não identificado ou contadores próprios.

## Atualização e validação

Atualize pelo ciclo nativo de plugins, sem desinstalar. A numeração e o marcador de runtime renovam a referência dos arquivos estáticos. Preserve o pacote beta.8 para recuperação dos arquivos anteriores.

Consulte [os testes e seus limites](test_execution_0.4.18-beta.9.md). Testes automatizados e verificações locais não certificam conformidade integral com WCAG, eMAG ou RGAA e não substituem testes assistivos com usuários.
