# 0.4.18-beta.63 — Calendário nos filtros de data

O campo Valor dos critérios absolutos de data e data/hora integra o calendário fornecido pelo GLPI 10/11. O formulário e o mecanismo da pesquisa permanecem próprios do portal. Somente os arquivos do Flatpickr e do idioma instalado são carregados pelos helpers públicos de assets, sem incorporar formulário ou CSS global do GLPI e sem copiar outra biblioteca.

O campo digitável é independente do calendário: uma data impossível não é normalizada ou apagada pelo widget. Para data/hora, Confirmar data e hora preenche o filtro; Fechar calendário sem confirmar conserva o valor anterior. A pesquisa só é executada por Pesquisar. Datas relativas e operadores adicionais não foram incluídos.

Os controles têm rótulos, instruções, navegação por teclado, foco no dia selecionado e recuperação de erro para o campo visível. Valores canônicos, segundos e datas civis são preservados sem conversão UTC. Na ausência dos assets nativos, há alternativa de preenchimento pelo navegador ou texto, sem apagar valores antigos incompatíveis.

Erros de data preservam seu motivo e caminho seguro. O preenchimento rejeitado pode ser recuperado uma única vez no mesmo contexto de conta/perfil/entidade e catálogo por até cinco minutos, somente para correção no editor. Esse rascunho não é um token de pesquisa executável e não substitui os filtros aplicados.

Manual 3.11 contextual, completo e autônomo atualizado. Epoch `20261106-08`. Sem SQL novo, alteração de permissão ou mudança de regras nativas. A validação humana com NVDA/JAWS é registrada separadamente dos ensaios automatizados e do navegador.
