# GLPI Acessível 0.4.18-beta.10

Correção da apresentação dos relatórios, preservando os recursos entregues na beta.9. Versão 0.4.18-beta.10, runtime 20261019-01. Atualize pelo ciclo nativo de plugins, sem desinstalar.

## Correção desta revisão

- O aviso técnico sobre contrato de exportação deixou de aparecer na lista de chamados. A limitação fica documentada, não apresentada como uma ação ao usuário.
- O bloco “Relatórios nativos” não aparece quando não há estatísticas disponíveis para o perfil atual. Não fica um expansor vazio no percurso de teclado ou na leitura.
- Perfis autorizados continuam tendo os links das estatísticas nativas por técnico atribuído e por técnico de tarefas. Nenhuma permissão foi ampliada.

## Recursos acumulados da beta.9 e desta revisão

1. Documentos abrem em nova aba, com aviso no texto e no nome acessível do link.
2. Requerentes aparecem antes da descrição do chamado, mantendo as restrições de exibição dos contatos.
3. Cabeçalhos das pesquisas simples permitem ordenar pelos campos suportados, com indicação acessível da ordem. Campos sem ordenação nativa não recebem ordenação inventada.
4. A lista oferece prévia da descrição pela rota nativa, respeitando o acesso ao chamado; pode ser fechada por teclado, com retorno do foco.
5. Acompanhamentos e tarefas salvos podem ter texto simples e privacidade editados quando o GLPI autoriza. São revalidados acesso, vínculo, contexto e campos permitidos; há proteção CSRF, contra reenvio e preservação do rascunho em falhas.
6. Abertura de chamado, acompanhamento e tarefa aceitam imagem colada como anexo pendente. É possível conferir e remover arquivos antes do envio. O envio continua pelo formulário multipart e processamento já existente, sem upload automático.
7. A lista respeita a preferência nativa de atualização, inclusive “Nunca”, e oferece pausa/retomada local quando há intervalo. Foco, seleção, rascunhos, diálogos e prévias impedem substituição automática durante a interação. Falhas interrompem o ciclo automático.
8. Estatísticas continuam sendo relatórios convencionais, acessíveis somente a perfis autorizados e usando o contexto nativo de entidade e período. Não são novos contadores calculados pelo plugin.
9. Versão, runtime, catálogos e pacote são identificados de forma consistente para o ciclo nativo de atualização. Os pacotes anteriores permanecem preservados.
10. Novas funcionalidades não acrescentam SQL, tabelas, índices ou alterações do núcleo. Consultas legadas permanecem com o comportamento anterior.

## O que não foi habilitado

- Exportação fiel às colunas da lista: continua indisponível, sem oferecer outra consulta/colunas como equivalente.
- Edição textual de conteúdo rico: HTML, imagens e formatação são preservados; o texto é editado no chamado convencional. A privacidade pode ser alterada sem reenviar o conteúdo rico.
- Ordenação direta dos cabeçalhos em pesquisas avançadas/salvas: continua pelo painel de ordenação existente, preservando a consulta.
- Reposicionamento de “Pesquisa de chamados” e de “responsáveis depois do encaminhamento”: adiados pelo usuário.
- Não foram acrescentados arraste de critérios, regras próprias de ações em massa, suporte a plugin de etiquetas não identificado ou novos contadores por técnico.

## Testes e acessibilidade

Consulte [o relatório desta revisão](test_execution_0.4.18-beta.10.md) e [o relatório da beta.9](test_execution_0.4.18-beta.9.md). Testes automatizados e verificações locais não certificam conformidade integral WCAG, eMAG ou RGAA; avaliação assistiva com usuários continua necessária.
