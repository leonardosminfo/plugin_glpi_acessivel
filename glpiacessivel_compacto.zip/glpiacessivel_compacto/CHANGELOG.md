## 0.4.18-beta.62

- Melhora a Ajuda: explica a tabela de consulta, leitura por leitor de tela, fechamento antes de atalhos de navegação e alternativas por botões/links.
- Acrescenta legenda e cabeçalhos semânticos à tabela, documenta combinações alternativas existentes e elimina sua rolagem vertical aninhada.
- Protege atalhos contra saída de diálogos abertos, composição de texto, AltGraph e repetição involuntária; aceita Alt+Shift+mais somente para aumentar fonte.
- Atualiza manual contextual, completo e autônomo para 3.10, sem mudar funções, SQL ou regras nativas do GLPI 10/11.

## 0.4.18-beta.61

- Acrescenta apresentação Simples opcional no detalhe do chamado, com Completa como padrão e preferência individual pelas APIs de configuração do GLPI.
- Recolhe apenas informações complementares, contatos e formulários de responsáveis/status; preserva descrição, navegação, documentos, editor e ação em andamento.
- Protege rascunhos, arquivos pendentes, foco, erros, âncoras e confirmações, sem recarregar ou reenviar o chamado.
- Permite liberação desativada, por perfis ou para todos, sem conceder direitos nativos. Sem JavaScript permanece a apresentação completa.
- Atualiza manual contextual, completo e autônomo para 3.9, com 48 assuntos e sete figuras.
- Mantém GLPI 10/11, sem SQL novo ou alterações nas regras nativas.

## 0.4.18-beta.60

- Aumenta a altura inicial do editor rico para 20rem, mantendo a largura responsiva do campo.
- Oferece Ampliar campo e Restaurar altura padrão por teclado, com foco preservado e anúncio do resultado.
- Preserva conteúdo, imagens, arquivos pendentes e tela cheia nativa, sem mudanças de gravação ou regras do GLPI.
- Atualiza o manual contextual, completo e autônomo para 3.8.

## 0.4.18-beta.59

- Mantém formulários próprios na inclusão e edição de tarefas/acompanhamentos: integra somente editor e uploader públicos do GLPI, sem importar formulários completos.
- Preserva os modelos e campos complementares do portal; links antigos de inclusão levam ao mesmo bloco do chamado.
- Grava texto rico e imagens pelas classes nativas, com CSRF, liberação, contexto, concorrência e confirmação de anexos por identidade/vínculo.
- Mantém anexos opcionais e corrige o falso negativo de uploads deduplicados; associa rótulos e ajuda ao editor sem duplicação.
- Atualiza o manual contextual, completo e autônomo para 3.7. GLPI 10/11, sem SQL novo nem mudanças nas regras nativas.

## 0.4.18-beta.58

- Alinha a apresentação dos formulários nativos de tarefa e acompanhamento ao portal: editor e anexos em largura útil, campos abaixo, rótulos textuais, foco e temas consistentes.
- Completa a identificação dos seletores visíveis e do editor sem substituir controles, valores, eventos ou ações nativas.
- Simplifica a orientação inicial da edição e mantém a ajuda detalhada recolhida. Preserva texto rico, uploads, CSRF, permissões e destino nativo após salvar.
- Sincroniza a apresentação do documento editável com tema e ampliação do portal, sem reabrir o editor ou alterar o conteúdo armazenado.
- Atualiza o manual contextual, completo e autônomo para 3.6. GLPI 10/11, sem SQL novo nem alterações de regras nativas. As liberações existentes são preservadas.

## 0.4.18-beta.57

- Integra os assets oficiais do editor no layout existente do portal, sem carregar o menu e o cabeçalho convencionais do GLPI.
- Apresenta o formulário nativo autorizado de inclusão de acompanhamento e tarefa no respectivo bloco do chamado, evitando dois formulários concorrentes. Liberações desligadas e recuperação de anexos preservam o fluxo simples.
- Mantém formulários, uploads, CSRF, endpoints e regras nativas. A edição rica existente usa o mesmo carregamento integrado, sem converter HTML para texto simples.
- Elimina a inicialização duplicada do runtime e completa nomes acessíveis de controles nativos identificados apenas por ícones, sem alterar valores ou ações.
- Atualiza o manual contextual, completo e autônomo para 3.5. Soluções continuam com o comportamento anterior; a integração rica dessa operação é uma etapa separada.
- GLPI 10/11, sem SQL novo ou mudanças de permissões. Nenhuma liberação é ativada automaticamente.

## 0.4.18-beta.56

- Preserva o layout da beta.55 nas páginas de inclusão e edição: não entrega cabeçalho compacto nem reorganização da navegação, ajuda ou anexos.
- Mantém o mecanismo nativo já existente, com os formulários completos quando liberados, sem recortar campos ou alterar uploads, CSRF, permissões, flags ou endpoints.
- Conserva os caminhos simples e nativos de acordo com as mesmas liberações e autorizações, sem ativação automática de edição ou inclusão rica.
- Mantém manual 3.4 com o conteúdo e as orientações da beta.55, 47 assuntos e sete figuras, atualizando a cobertura para esta versão. GLPI 10/11, sem SQL novo nem mudanças nas regras nativas.

## 0.4.18-beta.55

- Acrescenta leitura textual de anexos, descrições da ocorrência autorizada e prévia opcional, independente da edição rica.
- Apresenta as ações de documentos produzidas pelo GLPI para o evento exato, preservando diferenças entre GLPI 10 e 11.
- Oferece inclusão por formulário nativo com liberação própria, inicialmente desativada, e proteção condicional do rascunho ao abrir esse percurso.
- Atualiza o manual para 3.3, sem SQL novo ou substituição das regras nativas.

## 0.4.18-beta.54

- Identifica as ações de edição completa, texto e visibilidade de acordo com a liberação e o conteúdo; não apresenta conteúdo rico como editável no textarea simples.
- Impede fallback silencioso quando o formulário nativo completo não carrega, preservando conteúdo, CSRF e fluxos de gravação existentes.
- Exibe arquivos vinculados à interação pela leitura autorizada existente, com orientação sobre imagem incorporada, descrição alternativa, dimensões e cancelamento.
- Mostra a interseção dos perfis das duas liberações de edição e sinaliza combinações incompletas, sem ampliar configurações automaticamente.
- Atualiza o manual contextual, completo e offline para 3.2; mantém GLPI 10/11, sem SQL novo ou mudanças nas regras nativas.

## 0.4.18-beta.53

- Acrescenta a apresentação global Completo, Compacto ou Oculto para o cartão “Interface acessível do GLPI”, sem desativar o acesso independente ao portal. O compacto mantém título, links e atalho visível, sem reduzir a fonte para compactar.
- Oferece edição de acompanhamento e tarefa já salvos pelo formulário nativo completo, condicionada à liberação de edição formatada, à liberação base de edição e à autorização nativa. Editor, imagens, anexos, campos, action e CSRF continuam sob responsabilidade do GLPI.
- O salvamento nativo pode retornar ao chamado convencional conforme o GLPI. Não transforma os formulários de criação nem amplia o POST do editor simples para HTML ou uploads; mantém as contingências e não promete remoção geral de documentos vinculados.
- Atualiza o manual para 3.1, com 46 assuntos e sete figuras; o capítulo de edição formatada usa sua própria regra de disponibilidade contextual.
- Sem SQL novo ou substituição de regras nativas. Escopo e evidências desta rodada em docs/release_0.4.18-beta.53.md e docs/test_execution_0.4.18-beta.53.md, sem contar testes de versões anteriores como aprovação desta entrega.

## 0.4.18-beta.52

- Deixa Registrar chamado, Limpar formulário e Abrir formulário em página completa no fluxo normal, ao final do formulário de criação do plugin, sem fixação na parte inferior da janela.
- Retira apenas sticky, deslocamento inferior, camada elevada e desfoque da barra; preserva os controles, espaçamento, quebra de linha, temas, validações, anexos e regras nativas.
- Não altera os ícones flutuantes, formulários nativos, PHP operacional, JavaScript ou SQL. Mantém GLPI 10/11 e manual 3.0 com cobertura atualizada.
- A verificação direcionada e seus limites estão em docs/test_execution_0.4.18-beta.52.md.

## 0.4.18-beta.51

- Corrige a perda da posição dos acessos ao navegar entre páginas na mesma aba, quando a configuração de runtime ainda não está pronta ou a quantidade de acessos muda entre telas.
- Vincula a leitura da posição à configuração estável de layout/tamanho, sem usar a composição de IDs da página como motivo para descartar um registro compatível, com migração da assinatura anterior.
- Mantém sessionStorage por aba, o referencial de coordenadas, os links originais e os controles de movimento da beta.50. Não acrescenta persistência entre abas, por conta ou em banco.
- Conserva o manual 3.0, seus 45 assuntos, sete figuras e conteúdo didático; atualiza somente a cobertura para beta.51.
- Sem SQL novo, mudanças de regras nativas ou novas mensagens. Verificação concluída com 152 testes de navegador, 2.724 testes/20.731 asserções por execução PHP 8.1/8.3 e navegação na mesma aba nos dois GLPI. Resultados em docs/test_execution_0.4.18-beta.51.md; totais anteriores não foram usados como aprovação automática.

## 0.4.18-beta.50

- Retoma os acessos realmente flutuantes sobre a página, sem faixa reservada nem novo scrollport, mantendo os quatro layouts e os tamanhos configurados.
- Acrescenta controles de posição separados dos links originais: arraste pela alça ou ajuste por botões de direção em passos de 8 pixels, com desfazer, restaurar e fechar. A pilha se move como conjunto.
- Conserva a posição somente nesta aba com sessionStorage, sem SQL novo ou alteração da preferência institucional.
- Protege o controle em foco por deslocamento temporário para um canto seguro; se nenhum canto couber, suspende somente o grupo obstrutor enquanto necessário, mantendo os caminhos alternativos de navegação.
- Atualiza o manual para 3.0, com orientação também para usuário comum, sem criar capítulos ou figuras. Preserva o histórico da beta.49 e não promete visibilidade física em geometria impossível.
- Conclui 149 testes de navegador isolados, 50 de manual e 2.724 testes/20.729 asserções por execução PHP 8.1/8.3, além dos percursos locais GLPI 10/11. Resultados e limites assistivos/institucionais em docs/test_execution_0.4.18-beta.50.md; checksum do pacote no recibo externo.

## 0.4.18-beta.49

- Permite que os acessos retornem automaticamente do fluxo seguro ao posicionamento fixo quando houver espaço seguro nos layouts conhecidos, sem recarregar a página.
- Condiciona a recuperação à geometria estável e à verificação de colisões, preservando foco e referência de leitura; não altera o HTML inicial nem a apresentação sem JavaScript.
- Atualiza o manual contextual, completo e autônomo para 2.9, mantendo 45 assuntos e sete figuras. Não promete posição fixa em geometria impossível, shells desconhecidos ou durante modais.
- Sem SQL novo, mudanças de permissões, regras nativas ou novas preferências. Resultados em conclusão e limites em docs/test_execution_0.4.18-beta.49.md.

## 0.4.18-beta.48

- Reserva uma faixa real da janela para manter os ícones do portal e chatbot fixos e circulares durante a rolagem nos layouts reconhecidos do GLPI 10/11 e do portal.
- Mantém conteúdo, painéis internos e rodapé ITIL acima da faixa, preservando os elementos, foco, formulários e contratos nativos. Não substitui APIs globais de rolagem.
- Atualiza o manual contextual, completo e autônomo para 2.8 e a documentação funcional. Conserva a proteção de modais, impressão e degradação de layouts não reconhecidos.
- Sem SQL novo, migrações ou mudanças nas regras nativas. Resultados e limites em docs/test_execution_0.4.18-beta.48.md.

## 0.4.18-beta.47

- Corrige a obstrução de Salvar por acesso flutuante, comprovada no GLPI 11 local. Detecta colisão com controles visíveis antes do foco e utiliza a apresentação em fluxo existente, sem redirecionar cliques nem alterar controles nativos.
- Mantém os mesmos nós, destinos e rótulos dos acessos; conserva o posicionamento fixo nos cenários sem colisão. Preserva layouts separados/empilhados e menus superior/lateral/recolhido.
- Amplia as regressões de preservação do acompanhamento durante a conferência de atribuição: modelo, privacidade, altura, cursor, arquivo pendente em fixture, cancelamento e falhas de contexto/transporte.
- Mantém o manual editorial 2.7 nas apresentações contextual, completa e autônoma, atualizando a cobertura para esta versão.
- Passa em 2.722 testes e 20.705 asserções em cada runtime PHP 8.1.31 e 8.3.14. Resultados de navegador e limites do ensaio autenticado com arquivo constam em `docs/test_execution_0.4.18-beta.47.md`.
- Mantém GLPI 10 e 11, sem SQL novo, mudanças nas regras nativas, configuração do Escalade ou permissões. Preserva os registros e o pacote da beta.46.

## 0.4.18-beta.46

- Atualiza responsáveis e participantes por uma única chamada pública nativa de atores, preservando a sequência enviada e os dados dos participantes não editados no payload, sem decompor a atribuição em gravações próprias.
- Permite múltiplas inclusões nos contratos reconhecidos, inclusive quando os hooks do Escalade deixam somente um grupo ao final; não confunde limpeza automática com restrição de entrada a um destino.
- Consulta a configuração oficial e o contexto efetivo para reconhecer o contrato da operação. Mantém continuação convencional antes da escrita quando o contrato não puder ser confirmado, sem alterar configurações ou regras do fornecedor.
- Acrescenta conferência somente de leitura antes da revisão, vinculada à intenção ordenada e à confirmação existente; mantém a revalidação independente no envio final.
- Apresenta novos grupos na ordem efetiva de envio, avisa sobre ajustes automáticos e distingue processamento pelo núcleo de confirmação integral dos participantes solicitados. Orienta conferir os responsáveis atuais.
- Informa o estado de espera e trata edição durante a conferência sem recarregamento ou foco forçado. Preserva os controles e as pendências na página; sair ou recarregar continua podendo perder rascunhos e exigir nova seleção de arquivos.
- Atualiza o manual para 2.7 nas apresentações contextual, completa e autônoma, mantendo 45 assuntos, sete figuras, IDs, links e créditos. A orientação de J-08 deixa de impor o limite geral da beta.45.
- Passa em 2.710 testes e 20.538 asserções em cada runtime PHP 8.1.31 e 8.3.14. As comparações reais nos GLPIs 10 e 11 verificaram duas ordens de inclusão com limpeza ativa; o percurso autorizado de Hotliner no GLPI 11 também teve resultado positivo.
- Mantém compatibilidade com GLPI 10 e 11, sem SQL novo nem mudanças nas regras nativas. Limpeza desligada, matriz de destinos permitidos/negados, outras combinações institucionais, entrega externa de notificações e NVDA/JAWS permanecem com validação própria pendente; os resultados locais não afirmam paridade universal.
- Registra o escopo e os resultados em `docs/release_0.4.18-beta.46.md` e `docs/test_execution_0.4.18-beta.46.md`, preservando a história da beta.45.

## 0.4.18-beta.45

- Contém antes da gravação alterações que incluam mais de um novo grupo técnico com Escalade ativo, oferecendo continuação explícita no mesmo chamado do GLPI convencional.
- Mantém distintos incluir um grupo novo, conservar grupos atuais e realizar um fluxo de múltiplos grupos novos; a contenção não cria uma proibição do núcleo nem replica regras do Escalade.
- Preserva escolhas e demais rascunhos na página até a decisão do usuário; o link convencional abre na mesma aba e informa que as escolhas não são transferidas.
- Atualiza o manual para 2.6 nas apresentações contextual, completa e autônoma, mantendo os 45 assuntos, as sete figuras, os destinos e os créditos.
- Mantém compatibilidade com GLPI 10 e 11, sem SQL novo, alterações de permissões ou regras nativas. A investigação do identificador do modelo após cancelar uma reaplicação não recebe correção nesta entrega sem efeito persistido comprovado.
- Registra resultados e limites em `docs/test_execution_0.4.18-beta.45.md`, sem somar evidências desta entrega às anteriores.

## 0.4.18-beta.44

- Corrige a recusa indevida dos ajustes de responsáveis feitos pelos hooks oficiais do Escalade nas combinações locais verificadas; conserva a conferência delimitada dos atores persistidos e informa o ajuste ao usuário.
- Preserva a origem no histórico do GLPI 10 enviando a inclusão e remoção de grupo no mesmo comando nativo, sem recriar o histórico.
- Usa o catálogo nativo de atores e sua validação exata também para novos grupos responsáveis; mantém a hidratação dos participantes atuais e respeita os filtros das extensões.
- Replica o contrato de token IDOR do seletor de atores do GLPI até 10.0.12 e a partir de 10.0.13/11, sem fallback que contorne autorização.
- Atualiza o manual HTML para 2.5 nas apresentações contextual, completa e autônoma.
- Explica, de forma condicional, que a inclusão de um novo grupo técnico responsável pode acionar regras do Escalade ativo e configurado para essa operação.
- Distingue grupo responsável, grupo observador e grupo de tarefa; orienta conferir responsáveis, status e histórico antes de repetir uma operação incerta.
- Ajusta a orientação de participantes em massa para não negar efeitos automáticos de extensões, preservando a distinção em relação ao botão Escalar.
- Preserva os 45 assuntos, os destinos de navegação, as sete figuras e os créditos. As orientações não prometem equivalência de todos os salvamentos ou suporte irrestrito a versões do Escalade.
- Registra a validação desta entrega em `docs/test_execution_0.4.18-beta.44.md`, separando resultados locais de pendências institucionais e assistivas.
- Instala e testa Escalade 2.10.8 no GLPI 11.0.7 local e 2.9.4 no GLPI 10.0.10 local, sem atualização do núcleo. A versão histórica 2.9.4 destina-se somente ao ensaio local autorizado; os pacotes Escalade não integram a distribuição do GLPI Acessível.

## 0.4.18-beta.43

- Atualiza o manual HTML para 2.4, mantendo as apresentações contextual, completa e autônoma.
- Faz os títulos H1 a H4 acompanharem o tamanho do texto, usando unidades relativas ao conteúdo, como os H5 e H6 já faziam.
- Identifica no índice e nos subtítulos de Pesquisas salvas as tarefas “Definir ou retirar a pesquisa padrão” e “Renomear ou excluir uma pesquisa salva”, sem mudar os destinos dos links.
- Preserva os 45 assuntos, as sete figuras, os créditos e as condições de uso. Não acrescenta SQL nem modifica consultas, permissões ou regras nativas do GLPI 10 e 11.
- Registra os testes desta entrega separadamente dos resultados anteriores no documento de execução da beta.43.
- Passa em 2.502 testes e 19.028 asserções por runtime PHP 8.1.31/8.3.14 e 54 testes distintos de navegador: 50 do manual e quatro da edição autônoma.
- Confirma os títulos acompanhando a preferência de texto de 120%, os dois destinos por teclado e o refluxo a 320/1.280 pixels nos GLPI 10 e 11 locais; restaura as preferências originais após os testes.

## 0.4.18-beta.42

- Atualiza o manual HTML para 2.3 com acesso visível ao sumário e ao primeiro percurso, mantendo o salto inicial para o conteúdo.
- Transforma as trilhas por público e as orientações iniciais por tarefa em links para os capítulos correspondentes.
- Inclui índices locais em J-06, J-08 e Pesquisas salvas, com destinos nos subtítulos existentes e foco de teclado, sem novas combinações de teclas.
- Aumenta os subtítulos menores sem alterar seus níveis semânticos; preserva a navegação e a leitura sem JavaScript.
- Mantém os 45 assuntos, as sete figuras, os créditos e as condições de envio, cancelamento, privacidade e disponibilidade nas apresentações contextual, completa e autônoma.
- Não acrescenta SQL nem altera permissões, consultas ou regras nativas do GLPI 10 e 11. Os resultados desta entrega estão no documento de execução da beta.42.
- Passa em 2.500 testes e 18.969 asserções por runtime PHP 8.1.31/8.3.14 e 52 testes distintos de navegador: 48 do manual e quatro da edição autônoma.

## 0.4.18-beta.41

- Atualiza o manual para 2.2 com revisão editorial voltada a quem não conhece o GLPI, preservando 45 assuntos, sete figuras, destinos e rótulos de controles.
- Diferencia as orientações sobre controles e contexto da edição integrada da leitura autônoma, que já oferece o manual completo.
- Substitui termos internos de engenharia por explicações dos efeitos práticos nas orientações de etiquetas, estatísticas, curadoria e administração, mantendo suas condições de uso.
- Simplifica a orientação de ajuda, aponta onde acessar estatísticas atualmente e transforma recomendações técnicas de anúncios em instruções para o usuário.
- Reduz repetições de teclado, rascunho e anexos no acompanhamento, preservando as condições de envio, cancelamento e público/privado de cada operação.
- Não modifica renderização, consultas, JavaScript, CSS, permissões ou regras nativas; mantém GLPI 10 e 11 sem SQL novo. Os retestes desta versão são registrados separadamente dos resultados anteriores.
- Passa em 2.498 testes/18.620 asserções por runtime PHP 8.1.31/8.3.14 e 47 testes distintos de navegador: 43 do manual e quatro da edição autônoma.
- Preserva estados, avisos, presença dos procedimentos, sumário e contexto nas quatro comparações autenticadas contextual/completa dos GLPI 10/11 locais. A revisão editorial alcança 12 seções, mantendo a estrutura de 45 assuntos, as sete figuras e os créditos; 279 arquivos protegidos e 39 ativos de voz permanecem intactos em relação à beta.40.

## 0.4.18-beta.40

- Atualiza o manual para 2.1 e distingue explicitamente a edição autônoma das edições integradas.
- Apresenta uma única nota “Sobre este manual” na edição autônoma, sem repetir os avisos de disponibilidade por assunto nem recomendar recarregar uma sessão conectada que não existe nessa edição.
- Mantém os avisos e o contexto confirmado nas leituras integradas contextual e completa; não usa ausência de URL ou falha de contexto para identificar o modo autônomo.
- Preserva 45 assuntos, sete figuras e as orientações para iniciantes, sem SQL novo, alteração nas regras nativas ou mudança de compatibilidade com GLPI 10/11.
- Registra os testes desta entrega separadamente dos resultados históricos da beta.39.
- Passa em 2.494 testes/18.546 asserções por runtime PHP 8.1.31/8.3.14 e 46 testes distintos de navegador: 42 do manual e quatro do autônomo. Não reutiliza os testes de entrada da beta.39 nessa contagem.
- Preserva, nas quatro comparações autenticadas contextual/completa dos GLPI 10/11 locais, assuntos, estados, avisos, procedimentos, sumário e contexto. Mantém as sete figuras, 278 arquivos protegidos e 39 ativos de voz em comparação com a beta.39.

## 0.4.18-beta.39

- Atualiza o manual para 2.0 com conceitos básicos, primeiro percurso seguro e procedimentos por tarefa, sem exigir experiência anterior com GLPI.
- Identifica o contexto confirmado da leitura por perfil, entidade, escopo e versão do GLPI, preservando o manual completo e a referência autônoma sem dados da sessão.
- Completa orientações de pesquisas salvas, gestão de roteiros, auditoria, voz e referência administrativa, preservando as jornadas e figuras anteriores.
- Usa direitos específicos existentes para orientar auditoria e gestão de roteiros; não usa o nome do perfil como autorização nem consulta registros operacionais para montar o manual.
- Valida leitura contextual/completa em três contextos legítimos dos GLPI 10/11 locais, navegação por teclado, identificação de escopo e reflow a 320 CSS px; o completo conserva 45 assuntos sem conceder ações.
- Passa em 58 testes distintos de navegador: 40 do manual, 14 da entrada/login e quatro do HTML autônomo sem JavaScript/rede em 320/1280 px e mídia de tela/impressão. Mídia de impressão não equivale a impressão física ou paginação homologada.
- Passa em 2.490 testes/18.367 asserções por runtime PHP 8.1.31/8.3.14 e preserva GLPI 10/11, operações de negócio, permissões e regras nativas, sem SQL novo. Leitor real, manual autenticado sem JS e aceite institucional permanecem separados; texto 200%/zoom 400% continuam adiados.

## 0.4.18-beta.38

- Acrescenta Observadores somente ao Resumo do chamado, reunindo pessoas e grupos já autorizados com identificação textual do tipo; preserva os controles e resumos da edição.
- Melhora exclusivamente a área Descrição do acompanhamento, com maior altura inicial e controles explícitos Ampliar campo e Restaurar altura padrão; restaurar não apaga o texto.
- Mantém o mesmo textarea e contrato de envio, sem novo editor rico, SQL, consultas de negócio, armazenamento de altura, autosave ou alteração de regras nativas.
- Atualiza o manual para 1.9 nas apresentações contextual/completa e exportação autônoma, com orientações em J-07/J-08 e figuras históricas preservadas.
- Valida teclado, foco, conteúdo e retorno à altura padrão nos GLPI 10/11 locais, com 12 combinações de largura/tema, janela baixa e alça nativa; verifica o manual 1.9 contextual/completo nos dois ambientes.
- Passa em 96 testes proporcionais de navegador e 2.472 testes/18.151 asserções por runtime PHP 8.1.31/8.3.14. Leitor real, arquivos/modelos/confirmações autenticados e aceite institucional mantêm seus limites próprios.

## 0.4.18-beta.37

- Corrige a disposição dos controles de Exibição dos resultados após sobreposição comprovada nos GLPI 10 e 11 locais: o campo Agrupamento perdia sua largura e era coberto pelo botão de colunas.
- Restringe o ajuste ao CSS do conjunto de itens por página, agrupamento e colunas, preservando DOM, valores, critérios, ordenações, envio da pesquisa e regras nativas, sem SQL novo.
- Mantém o manual 1.8 e suas figuras, atualizando somente a cobertura da versão nas edições contextual, completa e autônoma.
- Reteste local aprovado nas doze combinações de GLPI 10/11, larguras reais de 320/1280 CSS pixels e três temas, preservando valores e ordenações e o retorno do foco ao cancelar o diálogo de colunas.
- Mantém separada a triagem do VLibras e seus estados de disponibilidade; o ajuste da grade não altera JavaScript do widget nem comprova tradução remota ou conformidade integral.

## 0.4.18-beta.36

- Corrige o foco visível na imagem de um link em conteúdo rolável, após barreira visual comprovada no GLPI 11 local a 320 CSS pixels.
- Limita o ajuste à apresentação dentro de `.glpiacessivel-content`, sem alterar HTML armazenado, DOM, JavaScript de produção, links, regras nativas ou SQL.
- Preserva compatibilidade com GLPI 10 e 11 e manual 1.8, atualizando somente sua cobertura; procedimentos e versões reais das figuras permanecem iguais.
- Valida os conteúdos sintéticos nos dois ambientes, a 320/1280 CSS pixels e nos três temas, com rolagem local, alcance dos extremos e saída por Tab. No GLPI 11, o foco na imagem vinculada foi conferido à esquerda e à direita; no GLPI 10, a imagem final sem link não recebeu novo foco.
- Não declara encerramento integral da F3/F8 nem correção da limitação de alternativa textual da galeria nativa do GLPI 10.

## 0.4.18-beta.35

- Corrige a sobreposição dos botões de critérios sobre os campos de valor em pesquisas avançadas aninhadas, reproduzida por teclado nos GLPI 10 e 11 locais.
- Apresenta as ações em linha própria e permite que os campos se reorganizem conforme o espaço, sem alterar critérios, conectores, valores, ordenação ou ordem do DOM.
- Preserva regras e permissões nativas, sem SQL novo ou alteração de processamento de formulários.
- Mantém manual 1.8 com cobertura atualizada e registra os testes de teclado, temas e leitura offline do HTML autônomo.

## 0.4.18-beta.34

- Corrige o corte de textos e campos do painel de pesquisas salvas em telas estreitas, comprovado a 320 CSS pixels nos GLPI 10 e 11 locais.
- Permite que as colunas do painel e seu campo de busca encolham dentro da área disponível, preservando texto, controles, rolagem vertical e navegação existente.
- Não altera consultas, pesquisas salvas, permissões, regras nativas ou processamento dos formulários; sem SQL novo.
- Mantém o manual 1.8, com cobertura atualizada e procedimentos e figuras preservados.

## 0.4.18-beta.33

- Corrige a apresentação do botão Limpar anexos quando o atributo hidden indica que não há arquivos selecionados.
- Aplica regra CSS somente a esse controle, mantendo sua reapresentação ao selecionar arquivos e o retorno de foco ao seletor após limpar.
- Preserva a sincronização das listas da beta.32 e o processamento nativo de anexos, sem SQL novo, permissões ou regras próprias.
- Mantém manual 1.8 e compatibilidade GLPI 10/11; atualiza somente a cobertura da entrega e seus metadados.

## 0.4.18-beta.32

- Corrige a lista visual de anexos pendentes ao usar Limpar anexos no acompanhamento e na tarefa com colagem de imagens disponível.
- Sincroniza os componentes pelo evento de mudança do seletor, preservando a mensagem final, o foco e os demais rascunhos, sem enviar arquivos.
- Mantém processamento multipart, validações, visibilidade, permissões e regras nativas do GLPI 10 e 11, sem SQL novo.
- Atualiza versão/epoch e a cobertura do manual 1.8, sem alterar procedimentos nem as versões reais das figuras.

## 0.4.18-beta.31

- Corrige a interpretação adicional de entidades literais e a perda de espaços pré-formatados na leitura da descrição e das interações.
- Entrega o conteúdo armazenado intacto ao renderizador público nativo, preservando sanitização, galeria e fallback textual escapado.
- Não altera gravação, normalização de títulos, consultas, permissões ou regras do GLPI 10 e 11; sem SQL novo.
- Atualiza versão/epoch e cobertura do manual 1.8 sem mudar seus procedimentos ou as versões reais das figuras.

## 0.4.18-beta.30

- Corrige a prioridade do foco na navegação dos resultados quando uma consulta do catálogo de pesquisas salvas permanece no URL, sem alterar os critérios nem a ordenação.
- Preserva o foco solicitado para os resultados em vez de reabrir indevidamente o catálogo de pesquisas; mantém o acesso explícito ao catálogo.
- Mantém os contratos de Técnico vazio e etiqueta exata, a recuperação de anexos da beta.29 e as regras nativas do GLPI 10 e 11, sem SQL novo.
- Atualiza versão/epoch e a referência de cobertura do manual 1.8, sem mudar seus procedimentos ou as versões reais das figuras.

## 0.4.18-beta.29

- Recupera falhas conhecidas de upload anteriores à operação com orientação no formulário e preservação do rascunho, sem apresentar uma gravação como concluída.
- Mantém a seleção novamente explícita de arquivos recusados, sem repetir automaticamente a operação nem relaxar os limites e tipos aceitos pelo GLPI.
- Registra os quatro retestes positivos de anexos restantes, sem modificar a deduplicação ou as regras nativas; negativas e limites mantêm classificação própria.
- Atualiza versão/epoch e a cobertura do manual 1.8, preservando procedimentos, figuras, compatibilidade GLPI 10/11 e as quinze liberações; sem SQL novo.

## 0.4.18-beta.28

- Corrige a representação do ampersand e o falso resultado incerto da descrição no GLPI 10, conferindo a intenção original preservada pelo bootstrap nativo.
- Serializa texto antes do escape público do modelo legado, com aspas literais restritas ao nó textual 10; preserva o formato existente do GLPI 11.
- Recusa origem ausente/divergente, HTML real, limites excedidos e escapes ambíguos antes de gravar, sem desescape heurístico ou reenvio automático.
- Valida A/B, entidades intencionais e edição só do título nos dois GLPIs, mantendo direitos, regras, atores, status e quinze liberações.
- Atualiza os metadados e a referência do manual 1.8, sem SQL novo ou mudança de regras nativas.

### Candidata local 0.4.18-beta.27

- Preserva o registro intermediário: A passou, mas B foi recusado no GLPI 10 sem efeitos persistidos. Não foi aprovada como entrega final; substituída pela beta.28.

## 0.4.18-beta.26

- Evita interpretar novamente como HTML a descrição já projetada como texto no editor de dados do chamado.
- Preserva a descrição bruta, a revisão de concorrência, o escape da tela e o caminho nativo para conteúdo rico, sem mudar payloads ou regras.
- Amplia os testes locais de confirmação, cancelamento, purga, histórico e integridade editorial no GLPI 10 e 11.
- Registra separadamente os casos textuais do GLPI 10 e os ensaios de transporte ainda pendentes, sem declarar F1/F2 integralmente encerradas.
- Mantém manual 1.8 e gera versão/epoch novos, sem SQL novo nem alteração das liberações existentes.

## 0.4.18-beta.25

- Corrige a recusa de criação de pesquisa privada quando o estado aplicado inclui `tag_id`, mesmo sem etiqueta selecionada, ou o filtro Não solucionados.
- Compartilha o contrato estrito dos filtros frequentes entre a listagem e o salvamento, preservando os estados legados e a definição nativa compilada.
- Acrescenta regressões de ida e volta do estado, tipos e limites inválidos, contexto e preservação de critérios e colunas.
- Valida criação e reabertura autenticadas no GLPI 10 e 11, sem SQL novo, alteração de permissões ou regras do núcleo.
- Mantém o manual 1.8 com referência à nova versão, sem mudar procedimentos nem versões reais das capturas.

## 0.4.18-beta.24

- Distingue categorias autorizadas na abertura e na edição/reclassificação, inclusive no caminho sem seletor remoto, preservando os verificadores públicos nativos.
- Confere anexos reutilizados pelo conteúdo e vinculados ao objeto correto, sem depender apenas do nome armazenado pelo GLPI 10.
- Evita afirmar a visibilidade de uma tarefa com base apenas na escolha enviada quando o modelo nativo pode determinar outra visibilidade.
- Acrescenta regressões de expiração, concorrência e integridade de anexos; documenta os casos locais aprovados e ainda pendentes.
- Atualiza o manual HTML contextual, completo e autônomo para 1.8, com orientação sobre categorias de abertura e edição.
- Sem SQL novo, alteração de regras do núcleo ou ampliação das quinze liberações existentes.

## 0.4.18-beta.23

- Estabiliza a verificação pós-gravação da descrição sem repetir a atualização e preserva conteúdo rico por continuação no editor nativo.
- Diferencia a recuperação de confirmações ausentes, expiradas, indisponíveis e fora do contexto, mantendo as proteções existentes.
- Alinha ausência de técnico e elegibilidade de categorias aos contratos nativos específicos do GLPI 10 e 11.
- Contém imagens e conteúdo largo, melhora o campo de descrição e o feedback dos anexos e impede navegação por drop não suportado.
- Atualiza o manual contextual, completo e autônomo para 1.7; mantém as adaptações futuras fora da entrega, sem SQL novo nem novas regras nativas.

## 0.4.18-beta.22

- Atualiza o manual HTML para 1.6, com caminhos separados para aprovar e recusar uma solução.
- Corrige a sequência da recusa: comentário e anexos opcionais antes de Recusar solução, seguidos da revisão e confirmação ou cancelamento.
- Condiciona os exercícios de pesquisa à existência de pesquisa salva e de outra página, sem exigir dados fictícios ausentes.
- Esclarece a navegação contextual por sumário e títulos, preservando os destinos e o acesso ao manual completo.
- Mantém a fonte única das edições contextual, completa e autônoma, as sete imagens e as permissões nativas, sem SQL novo.

## 0.4.18-beta.21

- Atualiza o manual para 1.5 com sequência explícita de fechamento da Ajuda e retorno à aba original.
- Explica o exemplo de pesquisa aplicada, E/OU, agrupamento de critérios e a diferença para Grupo responsável e pesquisa salva.
- Organiza o atendimento por ações independentes e aproxima a figura da tarefa do procedimento correto.
- Explicita em texto a visibilidade dos registros e documentos, sem sugerir acesso público irrestrito.
- Nomeia os controles de revisão, confirmação, execução e cancelamento das ações em massa e reforça exercícios sem gravação.
- Diferencia orientação contextual de autorização operacional, preservando o manual completo, as sete imagens e as regras nativas, sem SQL novo.

## 0.4.18-beta.20

- Atualiza o manual HTML para 1.4, com figuras complementares dos filtros preparados, da pesquisa aplicada, da descrição e navegação, dos campos de tarefa e da revisão de mudança de status em massa.
- Preserva instruções completas em texto, acrescenta alternativas textuais e legendas e mantém o contexto verdadeiro das capturas de treinamento.
- Compartilha as figuras entre as apresentações contextual, completa e autônoma; respeita as restrições de cada procedimento no manual contextual.
- Publica e verifica as imagens a partir do manifesto editorial, incluindo cópias públicas compatíveis com GLPI 10 e 11 e incorporação no HTML offline.
- Mantém as quinze liberações, permissões, regras e contratos operacionais, sem SQL novo ou mudanças no núcleo do GLPI.

## 0.4.18-beta.19

- Inclui manual HTML 1.3 no plugin, com leitura contextual e acesso permanente ao conteúdo completo.
- Acrescenta os acessos pela Ajuda autenticada e pelo cartão de entrada da página inicial convencional.
- Organiza orientações conforme módulos, liberações e direitos gerais, distinguindo restrições explícitas de verificações inconclusivas.
- Mantém a leitura independente de pesquisas de chamados e de recuperação operacional de contexto, sem alterar permissões, configurações ou registros.
- Atualiza as treze jornadas, documenta as quinze liberações e gera HTML autônomo completo a partir da mesma fonte editorial.
- Preserva as diferenças e limitações GLPI 10/11 e Tag, sem SQL novo, novas tabelas ou alteração do core.

## 0.4.18-beta.18

- Centraliza os acessos estatísticos no Cockpit e remove a descoberta e o bloco de links convencionais da lista de Chamados.
- Preserva as liberações independentes da consulta acessível e dos links convencionais, além dos estados e perfis salvos.
- Vincula os links ao módulo Cockpit, mantendo as dependências existentes e a autorização nativa de estatísticas.
- Transfere o retorno de foco pelo histórico para o JavaScript comum, com links convencionais funcionais na mesma aba também sem JavaScript.
- Atualiza os guias sem alterar cálculos, contratos GLPI 10/11, SQL, esquema funcional ou suporte a versões do Tag.

## 0.4.18-beta.17

- Acrescenta coluna opcional de etiquetas, sem ordenação, com leitura nativa em até dois lotes para a página autorizada e sem consulta por chamado.
- Acrescenta filtro por uma etiqueta exata, reutilizando a pesquisa nativa, o seletor remoto acessível e o estado validado da pesquisa avançada.
- Preserva agrupamento lógico, pesquisas salvas, paginação e critérios indisponíveis; falhas não ampliam silenciosamente os resultados.
- Adiciona duas liberações independentes, inicialmente desativadas, preservando as treze anteriores.
- Corrige os cabeçalhos AJAX do seletor remoto para o contrato CSRF nativo do GLPI 11, mantendo o envio compatível com o GLPI 10.
- Preserva cores, contraste, nomes completos e estados de ausência/indisponibilidade nas apresentações inicial e dinâmica. Documenta os limites da integração ativa no GLPI 10, sem SQL novo nem alteração do core.

## 0.4.18-beta.16

- Acrescenta integração opcional de leitura das etiquetas vinculadas diretamente ao chamado pela Search API e pelos modelos públicos nativos, sem SQL novo.
- Preserva a cor original válida do Tag e escolhe texto preto ou branco conforme o contraste; nomes permanecem completos e independentes da cor.
- Adiciona duas liberações inicialmente desativadas: visualização e acesso à edição na interface convencional, sem anunciar edição local.
- Isola ausência, direitos insuficientes, versões desconhecidas e falhas de leitura sem interromper os demais blocos do chamado.
- Documenta a homologação real com Tag 2.14.8 no GLPI 11 e o bloqueio de instalação segura no GLPI 10.0.10 local.

## 0.4.18-beta.15

- Direciona as âncoras das estatísticas ao título, evitando foco no cartão inteiro e expansão indevida do atalho do chatbot.
- Preserva os endereços de consulta, paginação e retorno ao Cockpit, inclusive sem JavaScript.
- Mantém a proteção geral de foco, os layouts dos botões e os cálculos e permissões nativos.

## 0.4.18-beta.14

- Acrescenta consulta acessível de quatro contagens nativas por técnico atribuído, com entrada no Cockpit e execução somente após envio do período.
- Adiciona liberação independente da consulta estatística, inicialmente desativada, por perfil ativo ou para todos os usuários já autorizados.
- Mantém os links convencionais independentes, inclusive para a modalidade de tarefas, ainda sem adaptação homologada.
- Distingue desativação, perfil fora do público e indisponibilidade da política nas mensagens de varredura e revisão editorial em lote.
- Preserva resultados editoriais anteriores, cinco indicadores do Cockpit, preferências, permissões e contratos nativos, sem SQL novo ou alteração funcional de esquema/core.

## 0.4.18-beta.13

- Foco inicial no título da revisão de liberação, evitando que seções extensas expandam indevidamente o atalho do chatbot.
- Regressão com template e ativos reais em 1280 e 320 CSS px, sem alterar a proteção geral dos botões.

## 0.4.18-beta.12

- acrescenta liberação independente de dez funcionalidades, por estado desativado, perfis ativos selecionados ou todos os usuários já autorizados;
- disponibiliza administração acessível sem JavaScript, com revisão, confirmação, CSRF, contexto e conferência da persistência;
- protege as operações específicas de chamados e roteiros no servidor, preservando funções básicas, permissões e continuações nativas;
- mantém política existente e usa estado conservador quando a origem não pode ser comprovada; não infere a versão anterior pelo arquivo novo;
- reutiliza armazenamento existente e APIs públicas de perfis, sem SQL novo ou alteração de esquema/core;
- documenta a necessidade de coordenação de gravações administrativas, sem alegar exclusão mútua atômica ou sincronia instantânea de abas.

## 0.4.18-beta.11

- distingue o menu superior responsivo expandido da lateral verdadeira, sem desativar a proteção de foco ou o modo em fluxo por falta real de espaço;
- mantém o afastamento dos ícones em menus laterais e acompanha também o cabeçalho horizontal nativo;
- identifica os links de estatísticas como acesso à interface convencional, em tabela e na mesma aba, com orientação de retorno e alcance dos dados;
- restaura o foco ao link de origem no retorno por histórico quando possível, sem armazenar consultas ou tokens e sem substituir estados de outros componentes;
- consolida os relatórios de posicionamento e estatísticas, preservando permissões, consultas e regras nativas dos GLPI 10 e 11.

## 0.4.18-beta.10

- remove da interface o aviso técnico sobre indisponibilidade da exportação;
- oculta o bloco de relatórios quando não há estatísticas autorizadas, preservando os links nativos para perfis com permissão;
- mantém os recursos e limites documentados da beta.9, sem habilitar exportação ou alterar permissões.

## 0.4.18-beta.9

- abre documentos em nova aba com aviso e apresenta requerentes antes da descrição;
- permite ordenar cabeçalhos nas pesquisas simples e consultar a descrição pela rota nativa autorizada;
- oferece edição de texto simples e privacidade de acompanhamentos e tarefas pelas APIs públicas nativas; conteúdo rico permanece no editor nativo;
- aceita imagens coladas na abertura, nos acompanhamentos e nas tarefas pelo fluxo multipart já existente;
- respeita o intervalo nativo de atualização com pausa, retomada e proteção de foco e rascunhos;
- oferece acesso autorizado às estatísticas nativas; exportação fiel às colunas permanece indisponível sem contrato público comum às duas versões;
- mantém o legado de consultas e esquema sem mudança funcional; as novas funcionalidades não acrescentam SQL.

## 0.4.18-beta.8

- considera a área ocupada pelo menu lateral nativo ao posicionar os acessos flutuantes;
- acompanha abertura e recolhimento do menu sem alterar o núcleo ou as preferências do GLPI;
- evita que o foco no controle do menu acione o modo em fluxo por sobreposição indevida;
- amplia os testes de geometria e de foco para menus laterais abertos e recolhidos, incluindo a animação nativa;
- considera o tamanho transitório do controle focado, que pode ultrapassar a borda do menu durante a abertura.

## 0.4.18-beta.6

- permite escolher os lados dos acessos ao portal e ao chatbot ou empilhá-los à esquerda ou à direita, preservando a disposição anterior por padrão;
- acrescenta tamanho compacto opcional no empilhamento e restauração específica das preferências, sem alterar módulos ou permissões;
- propaga a configuração a páginas nativas e do plugin, com confirmação do salvamento e recarga do cache da requisição;
- adapta a reserva de espaço, protege o foco e os diálogos e mantém os acessos em fluxo quando a altura ou a sobreposição impedem uso seguro;
- atualiza o nome acessível do atalho do chatbot a partir do nome configurado, sem modificar o núcleo dos GLPI 10 e 11.

## 0.4.18-beta.5

- permite selecionar propostas pendentes da página e aprovar ou rejeitar em lote, com revisão das consequências antes da confirmação;
- revalida fontes, revisões e contexto em cada decisão, protege contra repetição e apresenta resultados parciais por proposta;
- acrescenta seleção por teclado, contador acessível, revisão sem JavaScript e retorno à seleção;
- reforça a revalidação de acesso na rejeição individual e o controle de contexto antes de confirmar transações;
- preserva o núcleo e as regras dos GLPI 10 e 11, sem novas tabelas nativas ou publicação automática.

## 0.4.18-beta.4

- acrescenta varredura administrativa manual e retomável da base nativa, com filtros e propostas de criação, atualização, inativação e reativação;
- separa publicação, vigência e autorização atual, impedindo respostas derivadas de fontes indisponíveis ou modificadas;
- mantém fontes e dependências em tabelas próprias, com migração aditiva V0007, revisão, CAS e transações;
- exige aprovação humana vinculada à revisão apresentada e conserva importações com fontes em quarentena até mapeamento;
- melhora a busca por termos e recusa recomendações ambíguas, sem apresentar score heurístico como probabilidade;
- acrescenta controles acessíveis e filtros paginados na fila editorial. Homologação institucional e avaliação manual com leitores de tela permanecem necessárias.

## 0.4.18-beta.3

- mantém preparações independentes entre abas no mesmo contexto, com retenção limitada e invalidação na troca de perfil ou entidade pelo portal;
- apresenta as etapas por GET após redirecionamento 303, sem executar alterações por GET e sem reativar preparações canceladas;
- exige escolhas explícitas de status, papel, tipo e participante, preservando valores ao revisar;
- separa contadores nativos da conferência autorizada dos vínculos de participantes, sem repetir operações nem contornar restrições de plugins;
- identifica o alcance das ações como alteração de status e adição de participante, sem substituição dos responsáveis existentes;
- acrescenta aviso de expiração e renovação limitada da preparação, sem executar a ação;
- preserva os parâmetros pendentes suportados durante a renovação, sem armazenar tokens ou consentimento e com aviso quando a preservação não for possível;
- atualiza versão e runtime sem migração de esquema. Validação local não equivale a homologação de plugins externos específicos ou certificação de acessibilidade.

## 0.4.18-beta.2

- acrescenta seleção coletiva limitada à página atual e preparação de ações em massa vinculada à sessão, contexto e IDs retornados pelo servidor;
- apresenta escolha, parâmetros nativos, revisão, confirmação, cancelamento prévio e contadores reais, com execução exclusivamente por MassiveAction do GLPI;
- disponibiliza alteração de status e adição de participantes quando oferecidas pelo núcleo; adição não substitui equipe nem reproduz escalonamento de outro plugin;
- preserva continuação nativa e bloqueia reenvio de operações concluídas, em execução ou com resultado incerto;
- registra diagnóstico de integração restrito, limitado e sem cabeçalhos, tokens ou árvore de entidades;
- melhora a visibilidade do foco quando controles são cobertos pelos botões flutuantes do próprio plugin;
- atualiza versão, runtime, assets e idiomas sem migração de esquema. Candidato local; homologação TRF e avaliação manual com leitores de tela permanecem necessárias.

## 0.4.18-beta.1

- preserva o nome configurado do chatbot, inclusive TiAjuda, usando o padrão somente quando o valor estiver ausente ou vazio;
- unifica a validação de origem dos resultados de chamados, seletores remotos e modelos, mantendo sessão, CSRF e permissões nativas;
- normaliza protocolo, hostname e porta efetiva sem confiar automaticamente em cabeçalhos de proxy; implantação com TLS externo ainda requer normalização confiável da infraestrutura;
- preserva o contexto recursivo já ativo de uma entidade folha aceito pelo núcleo, sem oferecer novos escopos ou ampliar permissões;
- limita mensagens de falha do catálogo de entidades a motivos internos conhecidos, sem exibir exceções arbitrárias;
- registra a prova do executor nativo de ações em massa nos dois núcleos; a interface no portal permanece pendente dos gates HTTP e assistivos da etapa B;
- atualiza versão, marcadores de runtime, catálogos e documentação; não altera o núcleo nem introduz migração de esquema.

## 0.4.17-beta.7

- coloca a descrição do chamado antes da navegação interna, preservando o acesso rápido para quem deseja saltá-la;
- separa descrição, documentos e requisitante em seções de primeiro nível, com hierarquia de títulos coerente;
- renomeia “Atalhos do chamado” para “Navegação do chamado” e mantém os fragmentos técnicos existentes para compatibilidade;
- acrescenta retorno equivalente em Níveis de serviço e preserva foco, hash, rascunhos e estado dos expansores;
- atualiza os catálogos pt-BR/en-GB e valida Axe, reflow a 320 px e as suítes completas; sem alteração de esquema ou permissões.

## 0.4.17-beta.6

- normaliza o título retornado pelo detalhe do chamado quando o GLPI fornece separadores hierárquicos codificados, sem modificar o registro nativo;
- apresenta a mesma projeção textual no editor geral e evita uma atualização falsa do título ao salvar outro campo no GLPI 10;
- mantém o snapshot bruto para revisão otimista e valida também a releitura codificada após uma alteração real do título;
- preserva o escape final no HTML e acrescenta regressões para entidades simples/duplas, alteração real e conteúdo semelhante a HTML; sem migração de esquema.

## 0.4.17-beta.5

- corrige a validação de campos obrigatórios da solução para consultar os vínculos nativos de requerentes, técnicos, grupos e fornecedores no GLPI 10 e 11;
- mantém o formulário de solução disponível para apresentar pendências e revalida permissões, atores obrigatórios e conteúdo no servidor antes da gravação;
- exige descrição da solução e impede que Solucionado ou Fechado sejam selecionados pelo formulário genérico de status, direcionando essas transições ao fluxo nativo de solução;
- acrescenta o atalho para a descrição do chamado e o retorno aos atalhos, com destino focável e comportamento compatível com teclado e leitor de tela;
- publica versão e runtime epoch novos para que o GLPI reconheça a atualização da beta.4; sem migração de esquema.

## 0.4.17-beta.4

- adiciona o filtro de pesquisa Não solucionados (novos, atribuídos, planejados e pendentes);
- alinha o destino de Meus chamados abertos ao indicador, preservando a aparência do botão;
- preserva mine isolado e pesquisas salvas; compartilha a definição de status entre indicador e pesquisa;
- esclarece o diagnóstico de timeout, sem modificar os limites de execução;
- validado por comparação nativa e HTTP autenticado no GLPI 10.0.10/8089 e 11.0.7/8080; sem migração de esquema.

## 0.4.17-beta.3

- corrige os leitores do arquivo VERSION para reconhecer tanto o formato legado `0.4.17.beta-2` quanto o formato canônico `0.4.17-beta.3`;
- publica o novo identificador no formato canônico, também reconhecido pelo leitor antigo quando ainda estiver em cache;
- impede regressões de nomenclatura exigindo o formato canônico de VERSION na verificação do pacote, além da igualdade com a versão esperada;
- preserva a detecção nativa de atualização do GLPI e as alterações funcionais da beta-2, sem mudança de esquema de banco;
- renova o runtime epoch para `20260917-03`; 1209 testes PHP (8036 asserções) aprovados, incluindo simulação de leitor antigo com marcador novo; validação no OPcache web permanece necessária.

## 0.4.17.beta-2

- seção recolhível de níveis de serviço, somente leitura: quatro prazos SLA/OLA e nomes dos acordos vinculados, respeitando campos ocultos pelo modelo nativo;
- distingue ausência de prazo/acordo de falha de consulta; sem cálculo próprio, alteração de regras ou consultas adicionais na listagem;
- inicia as interações do atendimento recolhidas e reabre a seção por fragmento direto ou após enviar acompanhamento/tarefa, preservando o anúncio do resultado;
- identifica a navegação interna como “Atalhos do chamado” e acrescenta quatro links “Voltar aos atalhos do chamado”;
- preserva as preferências nativas de datas da beta-1 e não altera esquema de banco;
- validação: 1197 testes PHP (8002 asserções) e 22 testes de interface aprovados; aceite assistivo e homologação permanecem necessários.

## 0.4.17.beta-1

- incorpora os ajustes da beta.14 e permite recolher as interações do atendimento, abertas inicialmente, sem ocultar as ações;
- navegação por fragmentos reabre a seção; teclado e foco mantêm o comportamento nativo;
- formata datas válidas do detalhe e da listagem conforme a preferência nativa do GLPI 10/11, preservando datas já formatadas e valores internos;
- não altera preferências dos usuários, fuso horário, filtros, ordenação ou esquema de banco;
- validação anterior ao empacotamento: 1196 testes PHP, 19 testes de interface e comparação dos três formatos nativos em GLPI 10/11. Aceite com leitor de tela permanece pendente.

## 0.4.16-beta.14

- restringe a grade da linha do tempo aos eventos diretos, impedindo que nomes de anexos fiquem comprimidos na coluna do marcador;
- apresenta o comentário nativo do documento junto ao anexo quando preenchido, preservando metadados, privacidade e quebras de linha, sem consulta adicional; conteúdo escapado e quebra de palavras longas;
- remove fornecedores vazios do resumo inicial e resumos de requerentes/observadores duplicados junto aos expansores editáveis;
- preserva resumos de leitura quando não há edição e mantém fornecedores existentes visíveis, mesmo quando o modelo não permite editar o campo;
- alinha a oferta e pesquisa de fornecedores ao modelo e seletor de atores nativo, incluindo filtros de plugins;
- mantém campos de fornecedores indisponíveis fora do POST, sem enviar seleção vazia nem remover vínculos;
- acrescenta regressões de apresentação, seleção atual, modelo oculto e integração nativa; não altera buscas de chamados ou esquema de banco.

## 0.4.16-beta.13

- reorganiza o detalhe do chamado com resumo, navegação interna, descrição, interações e atendimento;
- mantém responsáveis e status visíveis, com edição geral, histórico e participantes complementares em expansores nativos;
- preserva o POST único de atores, seleções múltiplas, sentinelas, confirmação crítica e regras nativas, inclusive atribuir a si em solucionados quando autorizado;
- abre expansores e abas ao navegar por fragmentos ou apresentar erros, mantendo rascunhos e validação de seletores obrigatórios;
- adiciona testes do template PHP realmente renderizado, teclado, dados do formulário, foco, estados e reflow;
- não altera SQL, buscas salvas, permissões, catálogo de entidades, transições ITIL ou esquema de banco. Aceite com leitores de tela e usuários permanece necessário.

## 0.4.16-beta.12

- usa `Entity::getEntitySelectorTree()` como fonte prioritária do mesmo catálogo apresentado pelo seletor nativo do GLPI 10.0.18 e do GLPI 11, sem interpretar seu HTML de apresentação;
- resolve os rótulos completos por `Dropdown::getDropdownName()` e não cria SQL, ACL ou expansão paralela de entidades;
- não recorre à árvore genérica quando o seletor nativo existe, mas falha ou devolve estrutura inválida, preservando o contexto atual sem ampliar permissões;
- distingue os escopos `direct:<id>` (“somente esta entidade”) e `tree:<id>` (“inclui subentidades”), expondo recursividade somente nas pastas oferecidas pelo GLPI;
- mantém `Session::changeActiveEntities()` como autoridade final e aceita valores numéricos antigos apenas como compatibilidade transitória, sempre resolvidos contra o catálogo autorizado atual;
- registra a recursividade na auditoria da troca de contexto e impede um estado recursivo sem opção correspondente no seletor;
- acrescenta regressões para GLPI 10.0.10, GLPI 10.0.18 e GLPI 11, falha fechada, folha não recursiva, teclado, Axe, reflow a 320 px e ampliação de texto a 200%;
- não altera lista ou busca de chamados, pesquisas salvas, atores, formulários, soluções, regras ITIL nem esquema de banco.

## 0.4.16-beta.11

- corrige a detecção da árvore de entidades no GLPI 10.0.18, no qual `Entity::getEntityTree()` existe, mas é privado;
- seleciona o construtor de árvore por capacidade realmente invocável e usa somente os adaptadores públicos nativos `getTreeForItem()`/`DbUtils::getTreeForItem()` quando necessário;
- mantém `Session::changeActiveEntities()` como autoridade final e preserva a falha fechada sem ampliar entidades, perfis ou direitos;
- adiciona regressões isoladas para o contrato privado presente no GLPI 10.0.18 e o contrato público das versões recentes;
- não altera busca, pesquisas salvas, chamados, SQL da listagem, atores, formulários ou fluxos ITIL da beta.10 e não requer migração de banco.

## 0.4.16-beta.10

- substitui a expansão própria do seletor de entidades pelas árvores usadas pelo GLPI: `getTreeForItem()` no GLPI 10 e `Entity::getEntityTree()` no GLPI 11, selecionadas por capacidade disponível;
- apresenta as entidades autorizadas em ordem e caminho hierárquicos, deduplicando concessões sobrepostas sem consultar SQL diretamente nem criar uma ACL paralela;
- usa o mesmo catálogo normalizado para exibição, pré-validação e escolha da recursividade, mantendo `Session::changeActiveEntities()` como autoridade final;
- preserva a representação nativa de “todas as entidades” em cada geração: marcador explícito no GLPI 11 e, no GLPI 10, conjunto efetivo completo somente quando o contexto não é uma raiz recursiva;
- ordena concessões recursivas sobrepostas pela árvore ancestral antes de deduplicar, mantendo caminho e ordem completos mesmo quando a concessão filha vier primeiro;
- preserva somente o contexto ativo quando a árvore nativa não puder ser construída e impede ampliação para `all` nesse estado;
- impede que grupos ou metadados de impersonação ampliem o catálogo do perfil ativo e rejeita IDs adulterados antes da mutação de sessão;
- torna o seletor mais compreensível para tecnologia assistiva com caminhos, texto “inclui subentidades”, ajuda associada, estado de opção única e recuperação acessível;
- mantém os fluxos de chamados, busca, pesquisas salvas, atribuição, solução, formulários e idempotência da beta.9 sem alteração de esquema de banco;
- renova versão, catálogos e runtime epoch para atualização identificável sem reinício obrigatório do PHP-FPM.

## 0.4.16-beta.9

- substitui as tentativas deliberadas de inserção duplicada no ledger de idempotência por uma reserva atômica `INSERT ... ON DUPLICATE KEY UPDATE`, preservando a chave única como autoridade de concorrência;
- relê o token opaco da reserva para distinguir vencedor, operação em andamento, repetição concluída e conflito, sem armazenar conteúdo de chamados, pesquisas ou formulários;
- aplica o mesmo contrato à reserva comum, ao marcador de resultado incerto e ao bloqueio persistente de reconciliação;
- usa releitura corrente com `SELECT ... FOR UPDATE` após a disputa, inclusive sob `REPEATABLE READ`, e renova linhas expiradas somente pelo identificador já bloqueado;
- retira a limpeza global de expirados da transação de reserva e a executa em lotes limitados por uma ação automática horária do GLPI;
- registra essa ação também em atualizações da beta.8 por meio da migração idempotente `V0006_idempotency_ledger_cron`;
- mantém falha fechada para erros reais do banco e não usa `INSERT IGNORE`, consulta prévia como trava nem fallback para a inserção legada;
- elimina o erro de chave duplicada esperado dos logs do GLPI durante reenvios concorrentes, sem alterar o esquema ou remover o índice único;
- não altera motor Search, SQL da lista de chamados, pesquisas salvas, ACLs, perfis, entidades, atores, formulários ou regras ITIL;
- renova versão e runtime epoch para uma atualização identificável da beta.8 sem reinício obrigatório do PHP-FPM.

## 0.4.16-beta.8

- substitui o atalho global do portal por `Ctrl+Alt+Shift+A` no GLPI 10, no GLPI 11 e nas páginas do plugin, deixando `Alt+A` livre para o recurso nativo do GLPI;
- mantém o link textual pós-login como acesso principal e associa sua orientação ao controle com `aria-describedby`, para que o atalho opcional também seja compreendido por leitores de tela;
- atualiza a Ajuda de acessibilidade e a ajuda do login com o mesmo atalho, sem regras diferentes por versão, perfil ou página;
- preserva o destino contextual do botão flutuante, enquanto o atalho global abre sempre a entrada do portal acessível;
- ignora o atalho em campos editáveis, composição/IME, AltGraph, repetição, eventos já tratados e diálogos abertos;
- publica versão e runtime epoch novos para impedir que o GLPI 10 ou o navegador reutilizem o JavaScript da beta.7;
- não altera motor Search, SQL, pesquisas salvas, ACLs, perfis, entidades, chamados, atores, formulários ou fluxos ITIL.

## 0.4.16-beta.7

- torna a entrada da interface acessível encontrável logo após o login, com link textual no conteúdo inicial da central, menu e botão flutuante; o atalho opcional único passa a ser `Ctrl+Alt+Shift+A`, sem capturar o `Alt+A` nativo, preservando sessão, perfil, entidade e permissões;
- condiciona todos os acessos ao portal à mesma autorização do servidor e publica `portalAvailable` para impedir que o JavaScript apresente um caminho não autorizado, sem nova consulta, tabela ou configuração;
- passa a descrever pesquisas salvas pelo nome autorizado e pelo snapshot efetivamente executado pelo `Search` nativo, tanto no HTML quanto no carregamento progressivo, sem expor SQL, IDs técnicos ou critérios brutos;
- elimina a mensagem incorreta de ausência de filtros durante pesquisas salvas e mantém o estado inicial como carregamento neutro até o GLPI confirmar a execução;
- usa o formatador de nomes do próprio GLPI na linha do tempo operacional e preserva sem heurística os snapshots textuais do histórico detalhado;
- alinha o seletor de localização da edição à publicação recursiva nativa: aceita entidade do chamado e ancestrais recursivos, recusando irmãos e ancestrais não recursivos, com nova validação antes da atualização nativa;
- preserva motor de busca, SQL, ACL, perfis, entidades, recursividade, ordenação, colunas, paginação, atores e fluxos ITIL existentes, sem migração de banco;
- renova versão, chave de assets e runtime epoch para atualização identificável da `0.4.16-beta.6`, com invalidação restrita do OPcache e sem reinício obrigatório do PHP-FPM.

## 0.4.16-beta.6

- preserva a ordenação padrão resolvida pelo `Search::manageParams()` nativo quando uma pesquisa salva não contém `sort` ou `order`, sem fixar campo ou SQL no plugin;
- normaliza os padrões escalares legítimos do GLPI 10 e os arrays do GLPI 11, mantendo bloqueio estrito para valores inválidos e preservando ordenações explícitas;
- verifica perda de critérios antes de completar a ordenação, impedindo que defaults ocultem filtros removidos pelo contexto nativo;
- diferencia filtros removidos pelo core de pesquisa indisponível e consulta concorrente do mesmo acesso de sobrecarga global, mantendo recusa segura, HTTP 429/422 e `Retry-After`;
- adiciona fixture discriminante de 45 chamados, comparação nativa/plugin em três páginas e perfis distintos, com falha anterior e resultado posterior comprovados nas duas versões;
- renova versão, chave de assets e runtime epoch para atualização identificável da `0.4.16-beta.5`, com invalidação restrita do OPcache e sem migração de banco.

## 0.4.16-beta.5

- reconhece o acionador nativo `search` em pesquisas salvas como apresentação, sem ampliar a lista de parâmetros semânticos ou substituir critérios;
- normaliza identificadores de ordenação para inteiros positivos antes da assinatura e da execução, corrigindo a divergência entre catálogo, controlador e repositório;
- distingue pesquisa salva indisponível de mudança efetiva de perfil/entidade na resposta assíncrona, preservando bloqueio seguro e permissões nativas;
- corrige a ocultação visual e assistiva do iframe e permite recuperação de carregamento tardio validado, sem recarregar automaticamente respostas preenchidas;
- condiciona o início do preenchimento à prontidão do formulário e inclui regressões com os estilos reais;
- mantém orçamento de consulta, proteção de capacidade, ACLs e motor Search nativo sem relaxamento;
- acrescenta ferramentas de dados sintéticos locais e comparação reproduzível de pesquisas entre perfis no GLPI 10 e 11, fora do pacote de instalação.

## 0.4.16-beta.4

- faz a ação “Aplicar colunas e pesquisar” executar imediatamente a consulta completa pelo envio canônico do formulário, sem exigir um segundo clique em “Aplicar filtros e pesquisar”;
- preserva critérios, ordenação, agrupamento, paginação, pesquisa salva, token e validação já existentes, alterando apenas a seleção e a ordem das colunas confirmadas;
- mantém o rascunho isolado até a confirmação e faz Cancelar ou Escape descartarem as mudanças sem consulta;
- impede envio duplo, usa `requestSubmit()` com o botão canônico, evita `form.submit()` e aplica `aria-busy` somente depois de validação válida;
- atualiza a contagem visível e o nome acessível do seletor de colunas, anuncia o início da pesquisa e mantém o foco no resumo quando houver erro;
- inclui regressões de navegador e contrato para adicionar, remover, reordenar, restaurar, cancelar, validar e enviar exatamente uma vez no GLPI 10 e 11;
- renova versão, assets e marcador de runtime para atualização identificável da beta.3 sem reinício obrigatório do PHP-FPM.

## 0.4.16-beta.3

- torna o aviso de compatibilidade da abertura contextual ao modelo realmente selecionado, removendo o alerta técnico permanente e referências indevidas ao GLPI 11 em instalações GLPI 10;
- diferencia pesquisa salva indisponível de timeout ou falha operacional, com mensagem neutra que preserva a privacidade e orienta retorno às pesquisas permitidas;
- oferece links para a lista nativa apenas quando a sessão autenticada usa a interface Central e possui direito de leitura de chamados, evitando redirecionamento enganoso no Self-Service;
- preserva integralmente `SavedSearch::getVisibilityCriteria()`, `SavedSearch::can(READ)`, entidades, recursividade e a execução pela Search API nativa do GLPI 10 e 11;
- adiciona a ação acessível independente “Atribuir a mim”, autorizada por `Ticket::canAssignToMe()` e gravada pelo contrato nativo `_itil_assign` do GLPI 10 e 11;
- usa somente a identidade da sessão, sem substituir técnicos, grupos, requerentes ou observadores pelo formulário geral de atribuição;
- exige CSRF, confirmação e revisão contextual, impede duplicação e confere o vínculo persistido antes de informar sucesso;
- verifica transações externas nas duas versões e distingue recusa de resultado incerto, sem repetir a mutação automaticamente;
- reconhece de forma estrita o estado inicial de transação retornado como `null` pelo `DBmysql` nativo do GLPI 10.0.10, preservando a recusa para adaptadores ou estados desconhecidos;
- amplia a linha de base para 1.031 testes PHPUnit e 6.750 asserções em PHP 8.1 e 8.3, 84 cenários de navegador, 4 testes do ensaio de carga, 2.693 mensagens i18n, PHPCS e PHPStan limpos;
- renova versão, assets e marcador de runtime para atualização identificável da `0.4.16-beta.2` sem reinício obrigatório do PHP-FPM.

## 0.4.16-beta.2

- torna a desinstalação segura diante de hooks já carregados e tabelas parcialmente removidas, sem consultar `configs` ausente nem recriar esquema por navegação;
- mantém bootstrap, idioma, configuração e callbacks inertes durante a desmontagem e remove a tabela de configuração por último;
- adiciona orçamento administrativo da pesquisa da lista entre `1000` e `9000 ms`, mantendo `3000 ms` como padrão e respeitando limite mais restritivo do DBA;
- preserva a SQL, ACL, entidades, critérios e ordenação produzidos pelo Search nativo do GLPI 10 e 11;
- normaliza MySQL `3024` e MariaDB `1969` como indisponibilidade `503` com `Retry-After`, sem SQL ou falso resultado vazio;
- deriva prazo do navegador, lease e espera; acima de `5000 ms` exige confirmação e força lista assíncrona, capacidade e uma consulta pesada simultânea;
- oferece recuperação acessível com filtros preservados, anúncio único, contagem fora da região viva e foco previsível após tentativa manual;
- amplia a linha de base para 868 testes PHPUnit e 5.311 asserções em PHP 8.1 e 8.3, 84 cenários de navegador, 2.670 mensagens i18n, PHPCS e PHPStan limpos;
- renova versão, assets e runtime epoch para atualização a partir da `0.4.16-beta` sem reinício obrigatório do PHP-FPM.

## 0.4.16-beta

- corrige o reflow real dos cartões de visibilidade de acompanhamento e tarefa em viewports com 305 e 320 pixels CSS, sem corte nem rolagem horizontal;
- passa a montar o resumo dos filtros frequentes a partir dos valores efetivamente enviados ao serviço, preservando `Status: Novo` na paginação sem substituir resumos nativos de pesquisas salvas ou avançadas;
- normaliza, somente no iframe FormCreator validado e de mesma origem, os nomes e descrições acessíveis de controles nativos e Select2, inclusive após recriação dinâmica;
- preserva atributos ARIA existentes e não altera valores, validação, CSRF, método, ação ou envio do formulário incorporado;
- explica quando nenhum tipo de solução está configurado ou elegível na entidade atual, mantendo a opção nativa de registrar sem tipo;
- torna a indisponibilidade do VLibras explícita e recuperável, informando que os demais recursos continuam disponíveis, com retentativa somente após reconexão e cooldown;
- amplia a linha de base para 845 testes PHPUnit e 5.191 asserções, 83 verificações de navegador, PHPStan/PHPCS limpos e 2.657 entradas compiladas nos catálogos;
- renova versão, chave de assets e marcador de runtime para atualização segura da `0.4.15-beta` sem reinício obrigatório do PHP-FPM.

## 0.4.15-beta

- substitui a aprovação e a recusa manuais da solução pelo mesmo contrato nativo `ITILFollowup` usado pelo GLPI 10 e 11, com `add_close` e `add_reopen`;
- usa `Ticket::isSolved()`, `Ticket::canApprove()`, `Ticket::canAddFollowups()` e `Ticket::isAllowedStatus()` sem conceder direitos adicionais pelo plugin;
- revalida revisão e permissões após bloqueio da linha, executa uma única mutação nativa e confirma acompanhamento, solução, autor, data, status e anexos antes de informar sucesso;
- corrige rollback quando o núcleo rejeita o acompanhamento e adiciona reconciliação segura do guard por resultado conclusivo ou baseline órfão inalterado após a janela de segurança;
- preserva repetição HTTP segura com identificador de operação independente da confirmação e fingerprints estáveis de anexos, sem armazenar conteúdo ou nomes no ledger;
- exige a multiplicidade correta de anexos homônimos e informa explicitamente quando temporários precisam ser selecionados novamente;
- diferencia na interface aprovar/fechar e recusar/reabrir, exige motivo somente na recusa, lista anexos integralmente no diálogo e focaliza o retorno PRG;
- contém a largura intrínseca dos três seletores de anexos no detalhe, preservando o reflow em 320 pixels CSS sem ocultar conteúdo;
- normaliza como decorativas somente as duas imagens sem texto alternativo injetadas no `shadow DOM` aberto do VLibras, preservando o nome acessível do botão e reaplicando o ajuste em re-renderizações do widget;
- amplia a linha de base para 840 testes PHPUnit e 5.170 asserções, 80 verificações de navegador, PHPStan/PHPCS limpos e 2.655 entradas compiladas nos catálogos.

## 0.4.14-beta

- normaliza exclusivamente no GLPI 11 a rejeição CSRF pré-controlador do POST HTML de adição de solução, sem revalidar token, repetir o controlador ou executar nova mutação;
- aplica recuperação PRG com `303 See Other`, mensagem contextual acessível, foco no alerta e releitura do estado atual do chamado;
- mantém o `403` nativo para outros endpoints, ações, mídias, requisições AJAX, IDs inválidos e recusas que não tenham origem comprovada no `CheckCsrfListener` do GLPI;
- preserva em normalizador separado o envelope JSON `ticket_results`, sem misturar contratos HTML e assíncronos;
- registra somente metadados permitidos da falha CSRF, sem token, descrição da solução ou demais conteúdos submetidos;
- renova versão, chave de assets e marcador de runtime para atualização segura da `0.4.13-beta` sem reinício obrigatório do PHP-FPM.

## 0.4.13-beta

- alinha o registro de solução ao `ITILSolution::add()` nativo do GLPI 10 e 11, sem atualização manual do status e com exatamente uma tentativa de mutação;
- cria antes da mutação um guard persistente por chamado, compartilhado entre sessões, que impede solução duplicada quando commit, rollback ou releitura ficam inconclusivos;
- confirma solução, vínculo, tipo, autor e status sob bloqueio da linha e na mesma transação; falhas comprovadamente revertidas liberam nova tentativa e resultados ambíguos permanecem bloqueados para reconciliação;
- usa no serviço o snapshot confirmado dentro da transação, elimina a segunda releitura sujeita a corrida e trata replay sem novo `add()` nem segunda auditoria terminal;
- mantém o guard quando a solução não pode ser lida ou apresenta vínculo divergente, e torna sua limpeza pós-commit uma manutenção que nunca reclassifica um sucesso nativo;
- inclui o resumo expansível da descrição completa no ciclo de foco do diálogo, com validação de Tab, Shift+Tab, Enter e Espaço;
- acrescenta testes comportamentais de commit, rollback, falhas ambíguas, replay, conflito, chaves distintas, troca de sessão, falha do guard, falha de limpeza e reconciliação;
- renova versão, chave de assets e marcador de runtime para atualização segura da `0.4.12-beta` sem reinício obrigatório do PHP-FPM.

## 0.4.12-beta

- reforça os seletores remotos com identificadores únicos de rótulo, associação simultânea por `for` e `aria-labelledby`, nome técnico preservado no `select` oculto e fallback acessível quando o rótulo HTML não estiver disponível;
- elimina a condição que levava validadores heurísticos a apresentar os `select` técnicos ocultos como campos sem rótulo, sem alterar valores, nomes ou submissão ao GLPI;
- amplia a regressão de navegador para nomes acessíveis exatos, clique no rótulo, colisão de IDs, referências ARIA, fallback sem `label` e os sete papéis nativos de atores;
- valida a implementação ao vivo no GLPI 10, com nomes e foco corretos, nenhum ID duplicado, nenhuma referência ARIA quebrada e nenhuma violação automatizada confirmada pelo Axe;
- renova versão, chave de assets e marcador de runtime para atualização segura da `0.4.11-beta` sem depender de reinício do PHP-FPM.

## 0.4.11-beta

- exige confirmação crítica também na edição dos dados gerais do chamado, com token descartável vinculado ao usuário, chamado e ação;
- apresenta antes do envio um resumo acessível somente dos campos alterados e não reproduz o conteúdo sensível da descrição no diálogo;
- bloqueia submissões sem alteração, mantém validações dinâmicas e anuncia o envio apenas depois da confirmação explícita;
- preserva o comportamento dos demais formulários críticos, inclusive atribuição, observadores, solução e alteração de status;
- renova versão, chave de assets e marcador de runtime para atualização segura da `0.4.10-beta` sem depender de reinício do PHP-FPM;
- amplia a matriz para 795 testes PHPUnit e 4.907 asserções em PHP 8.1 e 8.3.

## 0.4.10-beta

- adiciona edição acessível pós-abertura para título, descrição, tipo, categoria, localização, origem, urgência, impacto e prioridade, submetida ao `Ticket` nativo e verificada por releitura;
- respeita campos obrigatórios, campos somente leitura e prioridade do `TicketTemplate`, com falha fechada quando a semântica nativa não puder ser comprovada;
- amplia a gestão de atores para os sete conjuntos nativos: pessoas e grupos requerentes, técnicos e grupos responsáveis, fornecedores atribuídos, pessoas e grupos observadores;
- separa direitos nativos por papel (`canAdminActors()` e `canAssign()`), entidade e recursividade, sem conceder permissões pelo plugin;
- preserva relações omitidas e requerentes anônimos por e-mail, diferencia limpeza explícita e usa os payloads dinâmicos de ator processados pelo GLPI 10 e 11;
- reconcilia atores em transação única, com bloqueio da linha, revisão SHA-256 dos sete conjuntos, plano anterior à escrita, rollback e releitura integral da pós-condição;
- acrescenta confirmação acessível, resumo de inclusões e remoções, PRG, retorno de foco e recuperação segura para edição concorrente ou hidratação incompleta;
- renova o marcador de runtime para que a atualização e a invalidação restrita de OPcache reconheçam a `0.4.10-beta` sem reinício obrigatório do PHP-FPM;
- amplia a matriz para 792 testes PHPUnit e 4.883 asserções em PHP 8.1 e 8.3, 74 cenários de navegador, 2.580 mensagens auditadas, PHPStan e PHPCS sem erros.

## 0.4.9-beta

- recalibra a proteção por sessão da lista de chamados para `30/60/5`, permitindo cinco páginas imediatas e recompondo um crédito a cada dois segundos;
- migra automaticamente apenas a configuração histórica exata `6/60/2`, preservando qualquer ajuste administrativo parcial ou personalizado;
- versiona o token bucket por política e descarta somente o estado legado da lista, sem alterar outros dados da sessão;
- acrescenta à telemetria de rejeição página, tamanho, contagens estruturais e política efetiva, sem registrar termos ou valores pesquisados;
- torna a recuperação de `429` coerente e acessível: mensagem única, filtros preservados, rótulo estável, contagem fora da região viva, anúncio único de liberação e controles sem resultados ocultos;
- impede também a retentativa antecipada no fallback síncrono e comprova em navegador um único POST para cada uma das cinco primeiras páginas;
- mantém a proteção de capacidade simultânea e os limites nativos de SQL/hidratação sem alterações.

## 0.4.8-beta

- separa a proteção de dados pessoais do modo da auditoria persistente, com modos `full`, `critical` e `disabled`; o último exige habilitação local e confirmação explícita;
- torna `critical` o padrão de novas instalações, preserva `full` em atualizações e mantém a retenção histórica ativa em todos os modos;
- adiciona quatro direitos nativos e independentes para consulta, conteúdo sensível, exportação e eventos globais, sem inferir acesso por nome de perfil, `ticket UPDATE` ou revelação de PII;
- centraliza a autorização por perfil, entidade, recursividade e leitura nativa do chamado, com falha fechada e cursor de paginação vinculado ao contexto da sessão;
- entrega página administrativa acessível, filtros exatos, paginação limitada e exportação CSV protegida por direito, CSRF, limitação temporal e neutralização de fórmulas;
- impede qualquer ledger ou evento `pii.reveal` quando o mascaramento está desligado e bloqueia a revelação quando a trilha obrigatória não pode ser gravada atomicamente;
- sanitiza recursivamente os metadados, exclui texto livre, contatos, tokens, SQL, exceções e URIs, limita profundidade, campos e tamanho e registra IP somente em eventos de segurança;
- limita a retenção a cinco lotes ou dois segundos fora da requisição interativa e corrige o avanço do cursor quando linhas são descartadas por autorização;
- integra os direitos à tela nativa de perfis, à navegação, à configuração e ao chatbot, que passa a consumir o mesmo serviço autorizado da página;
- amplia a suíte com contratos dos modos, PII, sanitização, direitos cumulativos, escopo de entidade, eventos globais e invalidação de cursor.
- normaliza por migração idempotente os novos identificadores de entidade como chaves estrangeiras sem sinal e restringe `scope_kind` a 16 caracteres, seguindo o formato nativo do GLPI 10/11.

## 0.4.7-beta

- A apresentação mínima dos formulários nativos agora isola semanticamente apenas o cabeçalho, a navegação, o rodapé e o profiler oficiais reconhecidos no GLPI 10/11, com `hidden`, `inert` e `aria-hidden`, restauração reversível e observação restrita da barra de depuração tardia. Título, instruções, mensagens, campos, overlays funcionais e envio permanecem no fluxo acessível.
- Widgets globais do portal, chatbot e VLibras deixam de ser inicializados novamente dentro do iframe nativo reconhecido. Raízes oficiais tardias do VLibras também são isoladas no modo mínimo, mantendo uma única instância funcional desses recursos na página externa e removendo glifos duplicados da árvore acessível do formulário.

- separa os catálogos e as autorizações nativas de técnico e grupo de tarefa dos papéis de atribuição do chamado, com revalidação contextual imediatamente antes da mutação;
- preserva todos os estados nativos de planejamento, inclusive `Planning::INFO = 0`, e escolhe `Planning::TODO` como padrão sem depender do idioma da interface;
- recusa modelos de tarefa com motivo de pendência ainda não representável, preservando o comportamento nativo em vez de aplicar parcialmente seus efeitos;
- compartilha um resolvedor canônico de `TaskTemplate` entre catálogo, prévia e persistência e elimina a recarga repetida do chamado durante a montagem do catálogo;
- vincula atualizações de técnico, grupo responsável, pessoa observadora e grupo observador a uma revisão SHA-256 do estado lido, com falha fechada diante de tela desatualizada ou hidratação incompleta;
- usa `canAdminActors()` tanto no GLPI 10 quanto no GLPI 11 e delega a criação privada de acompanhamentos e tarefas à validação `CREATE` do objeto nativo, mantendo `SEEPRIVATE` somente na leitura da timeline;
- distingue pesquisa salva nativa não projetável de `Status = Todos`, bloqueia o seletor simplificado e orienta a edição pelo construtor avançado sem alterar a consulta original;
- descarta prévias assíncronas obsoletas, preserva seletores fixados por modelo com `disabled` e campo oculto e restaura o foco após incluir ou remover atores;
- projeta no formulário acessível os valores predefinidos compatíveis do `TicketTemplate` nativo, sincroniza seletores remotos, bloqueia campos protegidos e exige o formulário nativo quando título, descrição ou outra semântica não puderem ser reproduzidos fielmente;
- normaliza no GLPI 11 somente a exceção CSRF nativa comprovada do endpoint assíncrono de chamados como contrato `ticket_results` V2 com HTTP 403, cache proibido e `nosniff`, sem interceptar outros erros de acesso;
- reforça o backend compartilhado de capacidade com tentativa única e limitada do lock de circuito, validação de escrita integral e recuperação observável, sem espera sustentada na requisição web;
- amplia as fixtures locais com grupos por papel, técnico de tarefa, categoria, modelos HTML e até 10.000 chamados mediante confirmação, além de um ensaio autenticado concorrente reutilizável;
- acrescenta fixture nativa de `TicketTemplate` nas duas versões e um ensaio HTTP que exige o backend Search limitado, registra cada tentativa, separa sucesso/rejeição/falha e usa uma sessão por usuário virtual;
- endurece a fixture com marcador de propriedade, rotação de credencial, revogação de tokens, perfil técnico fechado, dupla confirmação e transação integral com rollback;
- endurece a fixture local: perfis com qualquer direito administrativo são recusados, o candidato ativo deve conservar exatamente uma atribuição controlada e toda divergência causa rollback;
- faz a autorização de leitura de modelos falhar fechada quando a API nativa não está disponível e comprova que a contenção do lock de circuito termina dentro de orçamento limitado;
- reconcilia as pesquisas sintéticas já existentes e acrescenta uma pesquisa positiva por grupo responsável para exercitar `GROUP BY`/`HAVING` pelas Search Options nativas, mantendo separada a pesquisa deliberadamente não projetável;
- libera o lock da sessão logo após a mutação do limitador por sessão, antes da admissão global e das respostas controladas, sem antecipar validação de origem, autenticação, ACL, CSRF, contexto ou estado;
- corrige o ensaio concorrente para distribuir exatamente as requisições de cada usuário virtual, comprova sessões distintas por fingerprints unidirecionais e prepara o pool HTTP fora da janela medida;
- atualiza os catálogos para 2.448 entradas e a matriz automatizada para 731 testes PHPUnit, 4.495 asserções, 72 cenários de navegador e 4 testes do ensaio de carga nos runtimes PHP 8.1 e 8.3.

## 0.4.6-beta

- alinha catálogo, acesso direto, criação de chamados e cockpit aos métodos de autorização nativos do perfil ativo, sem inferir acesso a formulários a partir do direito de criar chamados;
- separa as permissões nativas de atribuição e observação no detalhe, nos seletores remotos, no serviço e imediatamente antes da mutação;
- separa também os catálogos locais de técnicos e observadores quando o seletor remoto está desativado, com elegibilidade específica por papel e entidade;
- torna a reconciliação dos quatro papéis de atores transacional, com bloqueio da linha, plano completo antes da escrita, releitura exata e rollback em qualquer divergência;
- valida localização obrigatória pelo objeto autorizado e por consulta primária limitada, e aplica solução exatamente uma vez após todas as precondições nativas;
- corrige o nome nativo de visibilidade das categorias, preserva conteúdo e foco ao aplicar modelos de tarefa vazios e normaliza CSRF inválido da lista assíncrona como envelope JSON com HTTP 403;
- bloqueia o envio do formulário quando as condições dinâmicas ficam incertas, ignora respostas antigas, desabilita dados ocultos e mantém foco e mensagens coerentes nos três tipos de modelo;
- libera o bloqueio da sessão antes da Search, limita cada papel a 20 atores, valida grupos por IDs exatos e limita a 1.000 as relações hidratadas por página;
- atualiza os catálogos para 2.411 entradas e a matriz automatizada para 704 testes PHPUnit, 4.307 asserções e 58 cenários de navegador nos runtimes PHP 8.1 e 8.3.

## 0.4.5-beta

- preserva no formulário o status e o grupo frequentes que originaram uma pesquisa avançada aplicada, eliminando o retorno visual incorreto para `Todos`;
- mantém a definição nativa efetiva intacta e remove do editor somente o sufixo exato que o próprio servidor compilou, evitando duplicar o status como regra avançada;
- valida o estado de filtros frequentes em tokens de sessão e falha fechado quando definição, catálogo e projeção visual não coincidem;
- conserva compatibilidade com tokens legados e com a versão anterior do envelope, sem ampliar consultas, permissões ou resultados;
- atualiza a matriz automatizada para 680 testes PHPUnit e 4.136 asserções nos runtimes PHP 8.1 e 8.3.

## 0.4.4-beta

- unifica catálogo, hidratação e validação final de requerentes e atores em uma política exata por ID, perfil e entidade, elimina consultas `IN ()`/`NOT IN ()` e preserva relações anônimas ou omitidas;
- verifica a atualização conjunta de técnicos, pessoas observadoras, grupos responsáveis e grupos observadores por snapshot e releitura, distinguindo resultado inalterado, confirmado, rejeitado ou incerto sem repetir a mutação;
- integra validação dos seletores e confirmação crítica em um único fluxo acessível, com revalidação antes de exatamente um envio e mensagens técnicas redigidas;
- renderiza modelos de tarefa e solução exclusivamente pelas APIs nativas do GLPI antes da conversão segura para texto, recusando HTML/Twig residual e mantendo efeitos contextuais do modelo;
- cria solução uma única vez por `ITILSolution`, omite tipo zero, comprova vínculo, autor e estado final e bloqueia reenvio quando a releitura é inconclusiva;
- retira da árvore acessível o iframe inválido e acrescenta perfil mínimo próprio, fingerprintado e conservador para o Service Catalog do GLPI 11, mantendo fallback completo para DOM desconhecido;
- reforça a proteção contra saturação ao liberar a lease mesmo se o circuito falhar e registra tempos, memória, backend, circuito e resultado por allowlists sem conteúdo ou PII;
- atualiza a matriz automatizada para 678 testes PHPUnit, 47 testes de navegador e 2.388 mensagens internacionalizadas, preservando o mesmo pacote para GLPI 10/PHP 8.1 e GLPI 11/PHP 8.3.

## 0.4.3-beta

- torna o carregamento assíncrono e limitado da lista de chamados o padrão seguro, mantendo a desativação administrativa explícita;
- falha fechado quando filtros negativos de status não podem ser reconciliados com as Search Options nativas, sem ampliar silenciosamente o resultado;
- permite abertura em nome de outro requerente somente na interface central e após validação nativa, contextual e repetida junto à mutação; o Autoatendimento permanece fixo no usuário autenticado;
- orienta a busca delegada por nome ou usuário e estabiliza o fingerprint dos seletores no GLPI 11 com contexto e grupos normalizados, sem depender do mapa volátil de direitos da sessão;
- identifica as buscas remotas como AJAX para que o listener CSRF nativo do GLPI 11 valide o cabeçalho `X-GLPI-CSRF-TOKEN`, preservando o mesmo contrato no GLPI 10;
- atualiza de forma diferencial técnicos, grupos responsáveis, pessoas observadoras e grupos observadores, preserva atores omitidos ou inelegíveis já existentes e aceita limpeza explícita sem gerar consultas `IN ()`;
- exige confirmação vinculada ao usuário, chamado e ação antes de alterar atribuição ou observadores;
- acrescenta verificação pós-gravação diagnóstica das soluções nativas, sem repetir a mutação nem registrar seu conteúdo;
- refina títulos, resumo de chamado, rótulo contextual da pesquisa e nomes acessíveis dos artigos da base de conhecimento;
- amplia os gates de regressão para criação delegada, atores 0/1/N, teclado, foco, mensagens, reflow, WCAG automatizada e compatibilidade PHP/GLPI 10 e 11.

## 0.4.2-beta

- integra modelos de solução com catálogo contextual, prévia em texto seguro, tipo de solução autorizado e persistência por `ITILSolution` nos GLPI 10 e 11;
- formaliza a estratégia de formulários entre projeção acessível com submissão nativa, `iframe` nativo verificado e página completa, com validação direta de ACL por ID no Service Catalog do GLPI 11;
- acrescenta ponte WCAG/eMAG reversível e desativada por padrão para sincronizar tema, contraste, escala tipográfica, reflow e foco visível no formulário nativo same-origin, sem alterar campos, CSRF ou envio;
- adiciona marcador `VERSION`, modo fail-closed para runtime obsoleto, invalidação de OPcache restrita aos arquivos PHP reais do plugin e fingerprint comum de runtime;
- introduz ledger de migrações com checksum e lock de banco, além de diagnóstico administrativo da versão carregada, pacote em disco e OPcache;
- reforça os gates de pacote para exigir coerência de versão/fingerprint, os novos ativos e a ausência de `opcache_reset()`.

## 0.4.1-beta

- preserva byte a byte, no planejador, os fragmentos `SELECT`, `FROM`, `WHERE`, `GROUPBY`, `HAVING` e `ORDER` produzidos pela Search API nativa do GLPI 10 e 11 e substitui somente o `LIMIT`; o executor acrescenta apenas o controle não semântico de orçamento do banco;
- passa a aceitar pesquisas nativas válidas com aliases `ITEM_*`, `META_*`, agrupamentos, `HAVING`, ordenação por campos relacionados e Search Options fornecidas por plugins, sem reconstruir sua semântica;
- mantém janela máxima de 51 identificadores, hidrata no máximo 50 chamados e não chama `Search::getDatas()` nem uma contagem global no caminho da lista;
- aplica orçamento server-side de 3 segundos às instruções em MySQL e MariaDB, restaura `group_concat_max_len` da sessão e falha fechado em qualquer erro de preparação, execução ou restauração;
- verifica durante a instalação o requisito MySQL `>= 5.7.8` ou MariaDB `>= 10.2`, necessário para o orçamento server-side;
- eleva a validade mínima da reserva de capacidade para 8 segundos e conserva limitação por sessão, contexto e servidor com `Retry-After`;
- torna explícito o contrato V2 dos resultados SSR e assíncronos, integra o estado do total ao único anúncio acessível e respeita a espera informada pelo servidor antes de habilitar nova tentativa;
- acrescenta regressões de paridade SQL GLPI 10/11, `HAVING`, aliases, forma canônica do ID, timeout/restauração do banco, contrato de interface e mensagens por página.

## 0.4.0-beta

- substitui a materialização ilimitada da Search API na lista de chamados por uma consulta somente de identificadores, com `LIMIT`, linha sentinela e adaptadores explícitos para GLPI 10 e 11;
- pagina a lista sem depender de uma contagem global prévia, representando o total como adiado ou indisponível e mantendo navegação anterior/próxima sem anunciar um falso zero;
- falha de forma fechada quando a versão, o contrato nativo ou a forma da consulta não são reconhecidos, sem retornar a consulta antiga potencialmente ilimitada;
- limita tamanho de página e deslocamento e aplica proteção de capacidade sem usar o banco de dados no caminho crítico;
- separa retenção de auditoria da requisição interativa, adiciona índices temporais e prepara a limpeza para execução periódica;
- atualiza o contrato assíncrono, os estados de carregamento/erro e as mensagens acessíveis, com liberação garantida da capacidade e alternativa de recuperação;
- acrescenta testes de regressão de SQL limitado, compatibilidade GLPI 10/11, paginação sem total, sobrecarga, auditoria, internacionalização e acessibilidade.

## 0.2.39-beta

- distingue, no GLPI 10 e no GLPI 11, a ausência comprovada de grupos no contexto oficial de uma sessão ausente, malformada ou cuja carga nativa falhou;
- retorna lista vazia exata com backend `scope_empty` para `scope=group` sem grupos atuais e publica o indicador `group_open` como zero exato, sem consultar a Search API para esse escopo;
- mantém `Resultado indisponível` quando o contexto de grupos não permite comprovar a contagem, sem converter falha em zero;
- valida `group_id` explícito contra `glpigroups` do perfil e da entidade atuais e falha fechado, sem consulta, quando o identificador não pertence ao conjunto autorizado;
- preserva `scope=all`, `scope=mine`, `group_by`, ACL, entidade, perfil, recursividade e os demais indicadores do cockpit;
- acrescenta regressões de compatibilidade, segurança, contrato assíncrono e contagem de chamadas para os formatos de sessão do GLPI 10 e do GLPI 11;
- mantém o esquema e a persistência inalterados e exige a nota de versão e o plano de testes desta correção nos gates de pacote.

## 0.2.38-beta

- conecta as confirmações críticas à inicialização compartilhada do GLPI 10 e 11, com sentinela idempotente para impedir listeners e diálogos duplicados;
- corrige o foco inicial para o botão Cancelar, inclui a consequência na descrição do `alertdialog` e preserva o retorno ao acionador em Cancelar e `Escape`;
- impede o anúncio prematuro de processamento quando o envio foi interrompido para confirmação;
- preserva o submitter, a ação e o token corretos em aprovação e recusa, mantendo ACL, CSRF e validação de uso único no servidor;
- acrescenta regressões de navegador e contrato para diálogo, teclado, Axe, cancelamento sem mutação e submissão única;
- amplia a matriz GLPI 10 com Formcreator 2.13.10 e exige o mesmo artefato na repetição crítica do GLPI 11.

## 0.2.37-beta

- conclui a revisão linguística das jornadas públicas, administrativas e dos formulários dinâmicos, reunindo textos visíveis, nomes acessíveis, ajuda, validações e estados no contrato Gettext do plugin;
- substitui contagens artificiais com `(s)` por plurais naturais em português e inglês, inclusive seleções, erros, anexos, atores e resultados da auditoria de acessibilidade;
- deduplica anúncios de estado para que cada alteração relevante seja comunicada uma única vez, inclusive tema, contraste, alertas críticos e carregamento de formulários;
- apresenta falhas de sessão e CSRF em linguagem orientada à recuperação, sem expor detalhes técnicos ao usuário comum e preservando os diagnósticos necessários para administradores autorizados;
- amplia os gates globais de internacionalização para PHP, templates, JavaScript, catálogos POT/PO/MO, placeholders, mojibake, plurais e paridade dos ativos publicados;
- preserva integralmente ACL, perfil, entidade, recursividade, payloads, tokens, ordem de validação, APIs do GLPI e submissões nativas, sem criar tabela ou cópia de dados operacionais.

## 0.2.36-beta

- corrige no GLPI 11 o ciclo POST/Redirect/GET da busca avançada, das pesquisas salvas e da criação de chamados, mantendo o redirecionamento fora das fronteiras de exceção e preservando o token opaco, o foco nos resultados, a ACL, o CSRF e as validações;
- homologa a incorporação do Service Catalog do GLPI 11 por contrato conservador de mesma origem, rota, formulário, identificador e endpoint de envio, sem alterar o `POST` nativo e com nova tentativa somente do carregamento e alternativa de página completa;
- contém o shell autenticado, os seletores de contexto e as tabelas em viewport de 320 pixels CSS, mantendo alvos de 44 pixels e rolagem horizontal restrita à região tabular;
- amplia o gate linguístico para serviços, controladores, templates, JavaScript, ARIA e regiões vivas, cobrindo acentuação, msgids estáticos, catálogos, placeholders, mojibake e paridade dos ativos publicados;
- acrescenta regressões específicas para as fronteiras de redirecionamento do GLPI 11, o contrato do iframe nativo, a recuperação conservadora e o reflow do documento.

## 0.2.35-beta

- corrige acentuação, terminologia e cobertura Gettext na criação e no detalhe de chamados, inclusive rótulos, instruções, confirmações, ARIA e regiões vivas;
- centraliza as mensagens dinâmicas restantes da busca, dos resultados, seletores e diagnóstico local no catálogo JavaScript compartilhado, mantendo os fallbacks do servidor;
- acrescenta regressões para `Média`, `Descrição`, `Localização`, `Última atualização`, `Interações e ações ITIL`, `Solução` e demais textos observados na homologação;
- amplia os gates linguísticos, recompila POT/PO/MO e restaura a execução oficial dos testes de navegador pelo pnpm;
- preserva os contratos de ACL, contexto, Search API, semântica negativa de status, mutações e apresentação conservadora do Formcreator.

## 0.2.34-beta

- confirma a troca de perfil e entidade em uma segunda requisição, depois de a sessão nativa do GLPI ser gravada, e só então informa sucesso ao usuário;
- aplica redirecionamento PRG `303`, marcador opaco de uso único e saneamento dos parâmetros de contexto para impedir repetição da troca ao atualizar ou voltar;
- invalida estados de pesquisa, paginação, autocomplete e diagnóstico vinculados ao contexto anterior;
- descobre requisitante, técnico e observador pelos metadados estruturados das Search Options do GLPI 10/11, sem depender de identificadores ou rótulos traduzidos;
- compila `Meus chamados abertos` como um único grupo OR entre os três papéis e falha fechado quando o catálogo é ausente ou ambíguo;
- migra lista assíncrona e seletores remotos para o catálogo JavaScript Gettext compartilhado, com português acentuado, tradução inglesa e fallback progressivo para o HTML do servidor;
- amplia os gates de i18n para chaves JavaScript, placeholders, mojibake, catálogos compilados e paridade entre assets públicos e fontes.

## 0.2.33-beta

- corrige a semântica de `Status não é` no GLPI 10: a interface conserva o operador negativo, enquanto a fronteira nativa compila para `equals` com conector `AND NOT` ou `OR NOT`;
- aplica a mesma compilação à lista, aos indicadores do cockpit e às pesquisas salvas nativas, com leitura reversa para manter o resumo acessível fiel;
- identifica o campo Status pelos metadados autorizados da Search Option, sem depender de identificador numérico ou ampliar operadores de outros campos;
- acrescenta um fingerprint conservador para o layout vertical institucional do GLPI 10/Formcreator 2.13, preservando campos, CSRF, mensagens e envio e mantendo a interface completa em qualquer divergência;
- conclui a acentuação e o Gettext dos textos compartilhados do shell, do portal e da identificação da sessão;
- amplia regressões para parâmetros efetivos da Search API, polaridades negativas, grupos aninhados, pesquisas salvas, estrutura incorporada real e nomes acessíveis.

## 0.2.32-beta

- restaura o foco ao acionador quando o diálogo de escolha de colunas é fechado por `Escape`;
- amplia a paridade do filtro de status com a condição negativa autorizada pelo catálogo de operadores do GLPI;
- refina a apresentação incorporada de formulários com validação conservadora da estrutura, mantendo menu, campos, CSRF, mensagens e envio;
- corrige acentuação e cobertura Gettext nos textos visíveis e anunciados dos principais fluxos;
- repete explicitamente a autorização de leitura de chamados antes das ações de pesquisas salvas;
- acrescenta regressões de teclado, linguagem, operadores, apresentação Formcreator e autorização.

## 0.2.31-beta

- cria `front/tickets.php` como rota canônica da lista e do detalhe de chamados, evitando a captura por substring do Formcreator `replace_helpdesk` em perfis Self-Service do GLPI 10;
- mantém `front/ticket.php` como redirecionador de compatibilidade executado antes do bootstrap do GLPI, preservando query string e método de requisições antigas;
- migra menu, portal, cockpit, chatbot, formulários, pesquisas salvas, lista assíncrona, atalhos e redirecionamentos internos para a rota sem colisão, mantendo `/front/ticket.php` apenas como fallback nativo do GLPI;
- traduz os estados agregados `Not solved`, `Not closed`, `Processing`, `Solved + Closed` e `All` pelo domínio Gettext do plugin, sem alterar os tokens aceitos pela Search API;
- acrescenta contratos de regressão para impedir a reintrodução de URLs internas vulneráveis à substituição do helpdesk e valida o comportamento legado GET/HEAD/POST.

## 0.2.30-beta

- corrige a identificação do formulário Formcreator quando a página nativa contém formulários auxiliares, sem afrouxar a validação por ID;
- remove o redimensionamento recursivo do iframe que podia expandir a página até 6000 px e passa a usar uma área limitada, responsiva e com rolagem interna;
- mantém o menu do portal em todas as aberturas iniciadas pelo catálogo e marca `Formulários` como página atual durante a jornada;
- restaura as cinco variantes visuais do cockpit e recolhe período, escopo, atualização e fuso em detalhes acessíveis, preservando as métricas exatas da Search API;
- trata antecipadamente perfis sem direito de leitura em Chamados e Cockpit com uma página amigável do plugin, sem consultar catálogos ou contagens;
- impede o fallback síncrono pesado quando a preparação da lista assíncrona falha, oferecendo nova tentativa e a listagem nativa;
- acrescenta testes de regressão para múltiplos formulários nativos, altura limitada, navegação persistente, variantes do cockpit, ACL e falha controlada da lista.

## 0.2.29-beta

- separa no servidor a experiência pública dos diagnósticos administrativos do catálogo e da abertura de formulários;
- restringe os diagnósticos operacionais ao direito nativo `config/UPDATE`, com falha fechada, sem conceder acesso por nome ou identificador de perfil;
- substitui termos técnicos como motor, renderer, nativo, iframe, versão e fallback por instruções funcionais e mensagens amigáveis para usuários comuns;
- mantém códigos, versões, razões e métricas técnicas ausentes do modelo público e disponíveis somente em um diagnóstico administrativo recolhido e sanitizado;
- simplifica a jornada para voltar, identificar o formulário, preencher, tentar novamente e abrir em página completa, preservando a ACL, o CSRF e a submissão da fonte;
- unifica carregamento, sucesso, timeout, sessão expirada e erro em uma única região de estado, com `aria-busy`, deduplicação, descarte de respostas tardias e foco preservado;
- adiciona nova tentativa explícita e redimensionamento progressivo da área incorporada sem transformar falha visual em falha de autorização;
- corrige a hierarquia de títulos do portal e sincroniza a contagem visual das regras avançadas com o estado acessível;
- atualiza os catálogos Gettext, a documentação funcional e a solução tecnológica sem criar tabela ou copiar formulários e diagnósticos.

## 0.2.28-beta

- reorganiza a pesquisa de chamados em quatro camadas progressivas sobre o mesmo formulário e o mesmo estado canônico: busca rápida, acesso recorrente, filtros e exibição dos resultados;
- mantém uma única ação `Pesquisar`, preserva as pesquisas salvas nativas como fonte de verdade e deixa o resumo aplicado visível mesmo quando os painéis de edição estão fechados;
- substitui a varredura limitada a 500 chamados e as consultas N+1 do cockpit por cinco contagens independentes obtidas pela Search API nativa do GLPI;
- vincula cada indicador do cockpit a uma consulta canônica opaca e reautorizada, com período, escopo, horário de referência e alternativa explícita quando o resultado estiver indisponível;
- impede que falhas, operadores incompatíveis ou totais ausentes sejam apresentados como zero e mantém os indicadores limitados às permissões, ao perfil, à entidade, à recursividade e aos grupos ativos;
- inicia a revisão linguística transversal com acentuação, terminologia consistente, mensagens inequívocas e cobertura gettext nos fluxos de pesquisa e cockpit;
- amplia os contratos automatizados para equivalência entre indicador, detalhamento e lista, orçamento constante de consultas, estados desconhecidos e interação por teclado/leitor de tela.

## 0.2.27-beta

- centraliza o comprimento minimo dos seletores remotos: categoria e localizacao aceitam navegacao vazia ou consulta curta, enquanto usuarios e grupos conservam o minimo de dois caracteres;
- publica somente codigos estruturados permitidos para consultas curtas ou invalidas e mantem mensagens internas fora da resposta;
- sincroniza o resumo de erros dos seletores depois da primeira tentativa de envio, sem roubar foco nem apagar erros remanescentes;
- mantem o formulario nativo incorporado como jornada padrao e adiciona a apresentacao `native_embedded_minimal` como opcao separada, reversivel e protegida por gate server-side desativado por padrao;
- aplica a reducao visual do Formcreator somente com origem, rota, ID, versoes e estrutura reconhecidos, preservando a interface nativa completa quando qualquer guarda falhar;
- separa no diagnostico Axe as violacoes confirmadas dos achados que exigem revisao manual e mostra apenas contexto tecnico local, limitado e sem conteudo de formulario;
- amplia os contratos automatizados para autocomplete, resumo de erros, incorporacao nativa, falha segura, privacidade do diagnostico, foco e URLs de ajuda.
- consolida a linha de base em 450 testes PHPUnit, 2.652 asserções, 25 testes de navegador, 195 arquivos PHPCS e 817 mensagens i18n consistentes.

## 0.2.26-beta

- resolve a raiz web instalada do Formcreator pelo contrato do servidor, aceitando instalacoes validas em `/plugins/formcreator` e `/marketplace/formcreator` sem confiar em caminhos enviados pelo navegador;
- usa a mesma resolucao para catalogo, abertura e envio nativo de formularios, com falha conservadora quando a raiz oficial nao puder ser comprovada;
- mantem o Service Catalog nativo como integracao suportada no GLPI 11 e remove caminhos Formcreator fixos do codigo de execucao;
- torna `ticket-results.js` um ativo pertencente a pagina de chamados, carregado tambem nos layouts standalone dos modos portal e hibrido;
- aplica melhoria progressiva real na lista assincrona: o HTML inicial nao declara carregamento, conserva o fallback nativo visivel e somente usa `aria-busy` durante uma requisicao efetiva;
- adiciona estados terminais acessiveis, limite de espera, descarte de resposta tardia, nova tentativa manual e tratamento de sessao, contexto, frequencia, JSON e indisponibilidade;
- amplia a linha de base para 417 testes PHPUnit, 2.335 assercoes e 13 testes de navegador, incluindo raiz `/marketplace`, caminho invalido, ativo ausente, endpoint pendente e ausencia de espera indefinida;
- endurece o verificador do pacote para exigir o resolvedor nativo, a nota desta versao, a inclusao direta do ativo da lista e a ausencia de caminhos Formcreator fixos.

## 0.2.25-beta

- elimina a hidratacao N+1 da lista de chamados e passa a montar cada pagina com consultas em lote, preservando a ordem e a ACL da Search API;
- adiciona carregamento assincrono opcional dos resultados, com estado opaco vinculado ao contexto, respostas JSON `no-store`, descarte de respostas antigas e fallback nativo;
- projeta a resposta JSON somente para as colunas solicitadas, sem expor conteudo, IDs relacionais ou nomes de atores nao selecionados;
- cria um autocomplete remoto e paginado unico para categoria, localizacao, tecnicos, grupos e observadores, com selecao simples/multipla, teclado, leitor de tela e botao externo de mais resultados;
- separa os contratos de valores de Search Options e recursos operacionais, limita frequencia, usa cursor opaco e revalida todos os IDs sem efeito parcial;
- corrige o catalogo Formcreator 2.13 com consulta coletiva nativa, instancia carregada antes de `canViewForRequest()`, busca no servidor, paginacao e revalidacao de URL direta;
- evita carregar catalogos extensos e schemas de formularios na listagem quando as novas frentes estao ativas;
- adiciona gates server-side independentes para lista, catalogo e autocompletes de abertura/roteamento, desativados por padrao para canario e rollback, sem criar tabela ou alterar esquema;
- amplia os contratos automatizados para 405 testes PHPUnit, 2.284 assercoes e 11 testes de navegador em seis arquivos;
- atualiza documentacao tecnologica, funcional, roadmaps, nota de release, build e verificacao do pacote.

## 0.2.24-beta

- reposiciona a nota `Portal Acessivel disponivel apos o login.` imediatamente depois do botao `Entrar` no formulario nativo;
- preserva a ordem real do DOM e de leitura, sem posicionamento absoluto, alteracao de foco ou anuncio `aria-live`;
- limita o seletor ao formulario oficial que contem `#login_name` e ao submit nomeado, sem ler credenciais ou interceptar a autenticacao;
- mantem a nota na area nativa do hook quando a estrutura do login nao for reconhecida, em vez de ocultar ou aproximar silenciosamente;
- usa o hook oficial `add_javascript_anonymous_page` para carregar um ativo externo pequeno e de mesma origem, mantendo o aviso sem links, campos, botoes ou rota alternativa;
- adiciona largura fluida e quebra segura do texto apos a movimentacao para reflow e ampliacao;
- cobre estruturas equivalentes ao GLPI 10 e 11, fallback e idempotencia com testes unitarios e de navegador.

## 0.2.23-beta

- reformula o aviso pre-login como nota semantica `role="note"` com nome acessivel proprio;
- simplifica a mensagem para `Portal Acessivel disponivel apos o login.`;
- usa classes visuais nativas do GLPI para manter caixa informativa, espacamento e alinhamento mesmo quando o CSS anonimo do plugin nao e carregado;
- reduz o icone decorativo para 32 px sem alterar o logotipo usado nas demais telas;
- mantem o aviso fora da ordem de Tab, sem `aria-live`, link, botao, formulario, campo ou JavaScript;
- amplia as regressoes para semantica, rotulo, tamanho do icone, classes nativas e ausencia de anuncios intrusivos.

## 0.2.22-beta

- adiciona a preferencia `show_login_accessibility_notice`, desativada por padrao, para exibir um aviso estatico na area auxiliar do login nativo;
- mantem o aviso sem link, formulario, campo, JavaScript ou rota alternativa e evita duplicidade com `accessible_bridge`;
- registra o hook pre-login somente quando a ponte compativel ou o aviso opcional estiverem ativos;
- passa a identificar o usuario autenticado como `login — primeiro nome`, usando `glpiname` e `glpifirstname` da sessao oficial do GLPI 10/11;
- recua para somente o login quando o primeiro nome estiver vazio e deixa de usar o sobrenome no rotulo do cabecalho;
- persiste e audita a nova preferencia na tabela chave/valor existente, sem criar tabela ou alterar esquema;
- documenta a restricao de posicionamento do hook nativo e preserva a superficie de autenticacao exclusiva do GLPI em `native_only`;
- amplia testes de configuracao, HTML pre-login nao interativo e identidade de sessao.

## 0.2.21-beta

- adiciona `authentication_entry_mode` como politica unica da entrada pre-autenticacao;
- adota `native_only` como padrao seguro e redireciona acessos anonimos ao login oficial do GLPI;
- deixa de registrar e renderizar o botao pre-login quando o login unificado esta ativo;
- preserva `accessible_bridge` como compatibilidade e rollback administrativo;
- reserva `strict_authenticated_portal` para uma versao futura, sem exibi-lo ou aceita-lo antes da separacao real das rotas;
- registra alteracoes de modo na auditoria sem dados sensiveis e inclui o estado no diagnostico operacional;
- mantem o atalho autenticado do portal separado da politica de login e preserva GLPI 10 e 11;
- consolida o gate em 368 testes PHPUnit e 2.052 assercoes, PHPStan aprovado, PHPCS em 169 de 169 arquivos, 3 de 3 testes de navegador e 560 mensagens i18n;

## 0.2.20-beta

- separa grupos tecnicos e grupos observadores na criacao e no roteamento de chamados;
- filtra os grupos por `is_assign` ou `is_watcher`, estado ativo, exclusao e entidade real do chamado;
- rejeita grupos recursivos de ramos alheios e revalida no servidor todos os IDs enviados;
- substitui grupos com o contrato nativo do GLPI, usando IDs de relacao nas exclusoes e preservando os demais atores;
- permite limpar um papel e preserva grupos existentes que deixaram de estar disponiveis no catalogo;
- aplica no GLPI 10 um fallback acessivel e tolerante a falhas para exibir `logo.png` no cartao do plugin ativo;
- reconhece instalacoes em `/plugins` e `/marketplace`, preservando o logotipo nativo do GLPI 11;
- consolida o gate em 361 testes PHPUnit e 2.025 assercoes, PHPStan aprovado, PHPCS em 169 de 169 arquivos, 3 de 3 testes de navegador e 555 mensagens i18n;
## 0.2.19-beta

- corrige o resultado `aria-prohibited-attr` reproduzido com os filtros avancados abertos;
- declara como grupos nomeados os botoes de adicao de regras e as acoes de pesquisas salvas;
- preserva os nomes acessiveis e a operacao por teclado sem alterar filtros, ACLs ou persistencia;
- adiciona regressao automatizada para impedir atributos de nomeacao sobre esses conteineres com papel generico;
- mantem `logo.png`, a documentacao tecnologica e funcional e a compatibilidade declarada com GLPI 10 e 11;
- consolida o gate em 351 testes PHPUnit e 1.944 assercoes, PHPStan aprovado e PHPCS em 168 de 168 arquivos.

## 0.2.18-beta

- substitui as iniciais `GA` pelo simbolo visual do GLPI Acessivel no gerenciador de plugins;
- adiciona `logo.png` quadrado, otimizado e reconhecido localmente pelo Marketplace do GLPI;
- mantem a imagem original em alta resolucao e aponta os metadados publicos para o novo icone;
- torna `logo.png` obrigatorio no empacotamento e adiciona regressao de formato, dimensoes, tamanho e inclusao no ZIP;
- nao altera banco de dados, permissoes ou funcionalidades e preserva a compatibilidade declarada com GLPI 10 e 11;
- inclui os documentos tecnologico, funcional e a nota especifica da versao no pacote de distribuicao;
- consolida o gate em 350 testes PHPUnit e 1.935 assercoes, PHPStan aprovado e PHPCS em 168 de 168 arquivos.

## 0.2.17-beta

- corrige a pesquisa por texto ou escopo sem regras avançadas, normalizando com segurança a submissão HTML real;
- torna o resumo fiel a metacritérios modernos e preserva o estado ativo de pesquisas salvas compostas apenas por ordenação, colunas ou excluídos;
- aproxima a aplicação de pesquisas salvas do GLPI 10 e 11, recuperando `list_limit` e tratando `all` e `view` somente quando autorizados;
- move o foco para os painéis abertos, fecha com Escape, devolve o foco e restaura as seis colunas padrão reais;
- remove duplicação e anúncios excessivos do resumo e esclarece rótulos, conectores e a ação Limpar filtros;
- limita a varredura do catálogo, filtra nomes no banco, trata cursor inválido, reforça o rate limit global e corrige `empty`/`notempty` remotos;
- inclui documentação tecnológica e funcional permanente no pacote;
- consolida o gate em 348 testes PHPUnit e 1.924 asserções, PHPStan aprovado, PHPCS em 167 de 167 arquivos e 2 de 2 testes de navegador;
- mantém a classificação beta e exige homologação externa em GLPI 10 e 11 com leitores de tela, teclado, perfis, entidades e volumes representativos.

## 0.2.16-beta

- mantém o seletor de escopo como atalho explícito para todos os chamados permitidos, meus chamados e chamados dos grupos, sem alterar as ACLs nativas do GLPI;
- deixa de apresentar o escopo padrão como filtro escolhido no resumo da consulta em edição e no resumo da pesquisa aplicada;
- continua narrando os escopos não padrão para que leitores de tela reconheçam quando a consulta foi restringida pelo usuário;
- normaliza nomes hierárquicos de entidade vindos da sessão do GLPI e corrige mensagens como `JF2R &#62; InternoTi` para `JF2R > InternoTi`, mantendo escape seguro no HTML;
- consolida o gate em 331 testes PHPUnit e 1.843 asserções, PHPStan aprovado, PHPCS em 167 de 167 arquivos, 2 de 2 testes de navegador e 555 mensagens i18n;
- mantém a classificação beta e exige homologação externa em GLPI 10 e 11 antes de produção.
## 0.2.15-beta

- apresenta um resumo fiel e acessível da pesquisa efetivamente aplicada, incluindo critérios, metacritérios, ordenações, registros excluídos, colunas e paginação sem publicar IDs ou metadados internos;
- preserva a AST versão 3 e recupera diretamente do `SavedSearch` do GLPI as pesquisas compatíveis, sem cópia ou persistência paralela;
- adapta os parâmetros nativos do GLPI 10 e 11 por lista permitida semântica, preservando `forcetoview` e descartando `table`, `users_id` e chaves arbitrárias;
- classifica como `native_only` as definições que não podem ser representadas com fidelidade e mantém o caminho explícito para abrir a pesquisa completa no GLPI;
- reorganiza a pesquisa de chamados em uma barra compacta com controles textuais para pesquisar, abrir pesquisas salvas, salvar, configurar resultados, escolher registros ativos ou excluídos e limpar;
- implementa painéis de divulgação exclusivos com `aria-expanded`, `aria-controls`, Escape, devolução de foco, reflow a 320 px e botões que não submetem o formulário ao apenas abrir opções;
- mantém registros excluídos como dois radios autorizados por `allow_deleted` e protege mutações de SavedSearch com POST, CSRF, confirmação, idempotência e ACL nativa;
- consolida o gate em 329 testes PHPUnit e 1.838 asserções, PHPStan aprovado, PHPCS em 167 de 167 arquivos, 2 de 2 testes de navegador e 555 mensagens i18n;
- mantém a classificação beta e exige homologação externa em GLPI 10 e 11 com leitores de tela, teclado, perfis, entidades e volumes representativos antes de produção.
## 0.2.14-beta

- introduz contratos de valor por combinação de campo e operador, derivados das Search Options autorizadas do GLPI 10 e 11;
- trata Título e Descrição como texto livre e apresenta Status, Prioridade, Urgência e Impacto com domínios locais nativos quando comprovados;
- valida e canonicaliza no servidor valores vazios, texto, inteiros, decimais, datas, booleanos, listas locais e identificadores remotos;
- falha de forma fechada para tipos, campos, operadores e valores sem contrato homologado, sem expor tabela, linkfield, condição ou metadados de autorização ao navegador;
- exige operador e revisão contextual no endpoint de valores e distingue respostas `403`, `409`, `422`, `429` e `503`;
- revalida cada ID remoto no contexto atual de ACL, perfil, entidade e recursividade antes de emitir o token opaco do fluxo PRG;
- separa os limites de requisição do autocomplete e da autorização final, evitando que uma jornada normal bloqueie a submissão;
- corrige associação de erro e foco no combobox visível e acrescenta estados recuperáveis de carregamento, timeout, repetição, fim de lista e carregamento adicional;
- mantém SavedSearch do GLPI como fonte de verdade, preserva a AST versão 3 e não requer migração de banco;
- identifica explicitamente o pacote como beta para homologação externa, ainda dependente da matriz real GLPI 10/11 e de ensaios com tecnologias assistivas antes de produção.

## 0.2.13-beta

- aproxima os valores dos filtros avançados do comportamento nativo observado no GLPI;
- abre a primeira página das opções autorizadas ao focar campos remotos com os operadores `é`, `não é`, `sob` e `não sob`;
- mantém pesquisa textual a partir de dois caracteres, paginação de 25 itens e carregamento adicional explícito;
- preserva ACL, entidade, recursividade, metadados nativos, IDOR, CSRF e limite por sessão em toda consulta de valores;
- alinha ordem e rótulos agregados de Status com a pesquisa nativa do GLPI;
- mantém o combobox acessível com setas, Home, End, Enter, Escape, foco e anúncios de carregamento;
- amplia a regressão automatizada para 280 testes e 1.420 asserções.
## 0.2.12-beta

- unifica busca textual, escopo, critérios avançados e opções de resultado em uma experiência próxima à pesquisa nativa do GLPI;
- deriva campos, operadores, valores, metacritérios e colunas disponíveis das Search Options autorizadas do GLPI 10 e 11;
- permite escolher, ordenar e remover colunas da lista com diálogo acessível, mantendo ID e título como colunas obrigatórias;
- aplica busca textual e escopo na mesma consulta nativa dos critérios, sem cópia local, pós-filtro ou limite artificial de varredura;
- cria, recupera e administra pesquisas salvas diretamente em `SavedSearch`, sem banco paralelo do plugin;
- melhora teclado, foco, anúncios, resumo dos filtros aplicados, reflow a 320 px, alto contraste e `forced-colors`;
- preserva o fluxo POST/CSRF/PRG, token opaco, listas permitidas contextuais e revalidação de ACL;
- amplia a regressão automatizada para 280 testes e 1.413 asserções.
## 0.2.11-beta

- adiciona autocomplete acessível por nome para valores remotos dos filtros nativos de chamados;
- recupera o rótulo autorizado dos valores de pesquisas salvas diretamente no GLPI, sem cópia ou cache persistente;
- usa os provedores de dropdown e IDOR do GLPI 10/11 com direito, condição, entidade e recursividade da Search Option;
- separa o rótulo apresentado do identificador técnico enviado à pesquisa;
- inclui teclado completo, anúncios, paginação, cancelamento de requisições, reflow e alto contraste;
- protege o endpoint com POST, autenticação, autorização, CSRF, parâmetros fechados e limite por sessão;
- amplia a regressão automatizada para 272 testes e 1.314 asserções.
## 0.2.10-beta

- reorganiza a listagem para apresentar os filtros antes das pesquisas salvas e dos resultados;
- torna a busca avancada o modo inicial, mantendo os filtros rapidos como alternativa explicita;
- organiza criterios por categoria, campo, condicao e valor usando os grupos das Search Options nativas;
- adiciona adaptacao de catalogo para as APIs de pesquisa do GLPI 10 e 11;
- remove o metadado interno `searchopt` no servidor e no cliente e rejeita operadores desconhecidos;
- agrupa ordenacao, paginacao e colunas em opcoes progressivamente expansiveis dos resultados;
- melhora sequencia visual, foco, anuncios, reflow, alto contraste e forced-colors;
- preserva o SavedSearch do GLPI como unica fonte das pesquisas salvas, sem copias locais;
- amplia a regressao automatizada para 227 testes e 1.128 assercoes.

## 0.2.9-beta

- adiciona busca avancada acessivel de chamados com criterios aninhados, regras globais, multiplas ordenacoes, colunas, paginacao e lixeira autorizada;
- deriva campos, operadores, tipos de valor, metacriterios e capacidade de exclusao diretamente do catalogo contextual da Search API do GLPI;
- traduz o formulario para uma AST nativa versionada, validada por listas permitidas do perfil e da entidade ativos;
- aplica a pesquisa por POST protegido com CSRF e PRG, mantendo a definicao na sessao e expondo somente um token opaco e temporario na URL;
- recupera pesquisas autorizadas ja salvas no GLPI para o construtor e salva novas pesquisas avancadas somente em SavedSearch, sem persistencia local;
- executa criterios, metacriterios e todas as ordenacoes pela Search API, sem pos-filtro, truncamento ou aproximacao silenciosa;
- falha de forma fechada quando catalogo, contexto, token, autorizacao ou Search API nao permitem execucao fiel;
- melhora teclado, foco, anuncios, resumo em linguagem natural, validacao de erros, reflow, alto contraste e forced-colors para leitores de tela.

## 0.2.8-beta

- torna `SavedSearch` e `SavedSearch_User` do GLPI as unicas fontes de verdade para pesquisas e padrao de chamados;
- remove copia, importacao, CRUD e persistencia local de filtros, inclusive o modelo e a criacao de `ticketviews`;
- remove a tabela legada somente quando o preflight com lock confirma que ela esta vazia;
- adiciona catalogo nativo pesquisavel e paginado em 25 itens, lookup direto e pesquisa padrao fora da pagina atual;
- cria, renomeia, exclui e define padrao diretamente no GLPI conforme ACL, entidade e capacidade do objeto;
- preserva criterios, metacriterios, multiplas ordenacoes e lixeira pela Search API, sem aproximacao silenciosa;
- elimina a varredura de ate 500 chamados da listagem e falha com lista vazia quando a Search API fica indisponivel;
- protege mutacoes com CSRF, fingerprint e ledger idempotente no mesmo limite transacional da operacao nativa;
- limita a query final a 48 KiB e bloqueia definicoes nao homologadas com a opcao `Abrir no GLPI`;
- entrega catalogo e exclusao acessiveis com busca explicita, teclado, foco deterministico, anuncios e `forced-colors`.
## 0.2.7-beta

- recupera pesquisas privadas e publicas de chamados ja salvas no GLPI, respeitando usuario, perfil e entidade;
- classifica pesquisas nativas como compativeis, copiaveis ou disponiveis somente no GLPI;
- executa criterios homologados pela Search API e bloqueia fallback que perderia filtros;
- permite criar copias editaveis, salvar pesquisas privadas e definir uma pesquisa padrao no portal;
- salva escopo, status, texto, grupo, agrupamento, paginacao, ordenacao e colunas visiveis;
- adiciona gerenciamento por controles HTML nativos, sem depender de arrastar, e mensagens anunciaveis;
- adiciona persistencia versionada, auditoria sem termos livres, testes e roteiro de homologacao assistiva;
- bloqueia chaves removidas ou sem autorizacao, parametros truncados, tipos nativos diferentes de pesquisa e escopo de lixeira;
- restringe copias a traducoes comprovadamente equivalentes e impede salvamento generico de pesquisas nativas;
- torna a troca de pesquisa padrao transacional, contextualiza nomes acessiveis e localiza a interface em pt_BR e en_GB.

## 0.2.6-beta

- apresenta documentos do chamado como links de download acessiveis, com nome, formato, tamanho, origem, data e visibilidade;
- inclui anexos de acompanhamentos e tarefas no evento correspondente da timeline;
- preserva ACL do chamado, direito de leitura do item pai, privacidade, relacionamento `Document_Item` e autorizacao nativa do documento;
- delega o download ao endpoint oficial do GLPI 10/11 sem expor caminho, hash ou armazenamento interno;
- adiciona selecao de arquivos anunciavel e operavel por teclado para acompanhamentos e tarefas;
- preserva sucesso parcial quando a acao ITIL e registrada, mas o vinculo do anexo nao pode ser confirmado;
- amplia os testes de regressao, internacionaliza as novas mensagens e recompila os catalogos gettext.

## 0.2.5-beta

- exige explicitamente `SEEPRIVATE` para consultar acompanhamentos e tarefas privados na timeline;
- filtra itens privados antes da consulta e revalida cada linha antes de copiar conteudo ou metadados;
- mantem a ACL nativa `item->can(READ)` como segunda camada de autorizacao;
- adota bloqueio conservador quando classe, constante, sessao ou permissao privada nao estiver disponivel;
- corrige o vazamento observado no GLPI 10 quando o autor Self-Service conseguia reler a propria nota privada;
- preserva os controles privados para perfis autorizados e o fluxo exclusivamente publico para Self-Service.
## 0.2.4-beta

- separa o direito de criar acompanhamentos e tarefas do direito SEEPRIVATE exigido para itens privados;
- bloqueia no servidor POST forjado de nota ou tarefa privada para perfis sem permissao;
- oculta opcoes e modelos privados quando a ACL nativa nao os permite;
- mantem o envio publico disponivel para Self-Service conforme a permissao do chamado;
- evita pagina vazia ao trocar para perfil ou entidade sem acesso ao chamado;
- melhora rotulos, descricoes, foco e percepcao visual da opcao de visibilidade selecionada;
- amplia a regressao de ACL, seguranca e acessibilidade para os cenarios encontrados na homologacao.
## 0.2.3-beta

- adiciona escolha explicita entre resposta publica e nota interna privada nos acompanhamentos;
- substitui a opcao ambigua de tarefa privada por radios acessiveis para tarefa publica ou interna;
- usa as preferencias nativas do GLPI como valor inicial e preserva a privacidade definida por modelos de acompanhamento;
- revalida a privacidade na autorizacao e na persistencia, inclusive contra alteracao maliciosa do POST;
- delega a leitura de cada item da timeline para a ACL nativa de ITILFollowup, TicketTask e ITILSolution;
- identifica em texto a visibilidade e o autor dos eventos que o perfil atual pode consultar;
- mantem anexos com a mesma visibilidade do acompanhamento ou tarefa;
- internacionaliza os novos rotulos e amplia as regressoes de seguranca, ACL e acessibilidade.
## 0.2.2-beta

- mantem disponivel a opcao Todas as entidades quando o GLPI ativa o escopo recursivo, mesmo com uma unica raiz permitida;
- confirma que a entrada direta pelo portal acessivel carrega os perfis nativos e preserva o perfil padrao escolhido pelo GLPI;
- evita uma area de acoes vazia quando ACL e politica de modulos nao liberam nenhuma funcionalidade;
- orienta o usuario a trocar para outro perfil permitido ou solicitar revisao administrativa, sem expor diagnosticos tecnicos;
- preserva as ACLs, entidades e estados de modulo nativos no GLPI 10 e 11.
## 0.2.1-beta

- corrige o retorno do login acessivel, evitando dupla codificacao e redirecionamentos inesperados;
- torna a recuperacao pos-login uma etapa controlada e bloqueia paginas operacionais com sessao parcial;
- separa a troca de perfil da troca de entidade e valida o resultado efetivo das APIs nativas;
- corrige o escopo de todas as entidades e restringe o retorno a rotas locais do plugin;
- limpa memoria e confirmacoes pendentes quando perfil ou entidade muda;
- melhora foco, anuncio de progresso e isolamento do dialogo de ajuda no login;
- adiciona regressao de autenticacao/contexto e corrige as rotas da auditoria autenticada;
- inclui gerador local idempotente de massa sintetica `[A11Y-QA]` para ensaios com tecnologias assistivas.

## 0.2-beta

- consolida a primeira beta publica para GitHub, preservando compatibilidade declarada com GLPI 10 e 11;
- sincroniza metadados, URL de download, catalogos gettext e documentacao da release;
- corrige o namespace dos auxiliares SQL de instalacao e desinstalacao;
- adiciona politica de seguranca, guia de contribuicao, avisos de terceiros e licenca GPL integral;
- endurece a higiene do repositorio e a verificacao automatica do pacote;
- amplia o CI para PHPUnit, PHPStan, PHPCS, Composer Audit e validacao de i18n;
- documenta axe-core 4.10.3, MPL-2.0, fonte correspondente, hash e avisos transitivos;
- adota DCO 1.1 e sign-off para a procedencia de contribuicoes;
- explicita politica de licenciamento, marcas e checklist de propriedade intelectual;
- faz o gate de release validar documentos juridicos e o hash do axe-core.
- publica o pacote principal no perfil enxuto, sem binarios de voz com redistribuicao pendente;
- documenta explicitamente limites de homologacao assistiva, formularios dinamicos e traducao en-GB.
## 0.1.112-beta

- adiciona liberacao gradual por funcionalidade com estados disponivel, oculto e indisponivel;
- mantem ACL, perfil, entidade e permissoes nativas do GLPI como autoridade final;
- bloqueia rotas GET/POST e intents do chatbot para modulos indisponiveis, inclusive conversas ja iniciadas;
- inclui presets administrativos para apresentacao, demonstracao, piloto Self-Service e piloto tecnico;
- ajusta menus, cards, ajuda, atalhos e botao flutuante conforme a configuracao efetiva;
- preserva configuracoes legadas de Formularios e Chatbot durante atualizacao;
- adiciona auditoria, diagnostico, traducoes e regressao automatizada para a politica de modulos.

## 0.1.111-beta

- permite definir o nome publico do chatbot nas configuracoes gerais, mantendo Assistente como padrao;
- propaga o nome para interface, respostas, voz, ARIA e curadoria de roteiros com escape contextual;
- normaliza HTML, controles, marcadores bidirecionais, espacos e comprimento antes de persistir;
- corrige os rotulos ARIA da leitura automatica e internacionaliza as frases com placeholders;
- adiciona migracao idempotente, auditoria sem registrar o nome e testes unitarios de seguranca e fallback.
## 0.1.110-beta

- corrige o fundo preto herdado pelos textos dentro da resposta amarela da Assistente no alto contraste;
- torna transparentes os fundos internos da bolha, preservando texto preto sobre amarelo e o selo independente;
- valida a cascata completa nos modos normal e alto contraste.

## 0.1.109-beta

- corrige o contraste das respostas da Assistente no tema normal e noturno;
- substitui o gradiente por fundo solido `#005a9c` com texto branco, atingindo aproximadamente 7,14:1;
- isola a regra de cor da bolha para impedir sobrescrita pelas regras globais, preservando o selo e o alto contraste.

## 0.1.108-beta

- fecha a equivalencia da Search API no GLPI 11 para mine, busca textual, group_id, grupo unico e multiplos grupos com criterios OR aninhados;
- preserva o fallback seguro quando a Search API nao representa o filtro ou retorna resultado vazio inconclusivo;
- valida entidade ativa concreta e aplica recursividade somente quando o contexto nativo autoriza;
- pagina todo o Service Catalog GLPI 11 e respeita ServiceCatalog::canView() na exibicao do menu;
- correlaciona anexos da criacao, acompanhamento e tarefa com o item recem-criado, nome original e vinculo final Document_Item;
- amplia a auditoria local para resultados que exigem revisao manual e a automacao Pa11y/Axe para WCAG 2.2 A/AA;
- melhora reflow dos botoes flutuantes e respeita prefers-reduced-motion nos controles de voz.
## 0.1.107-beta

- publica o Axe local em uma rota web compativel com GLPI 11 e permite nova tentativa apos falha de carregamento;
- corrige a negacao de acesso a configuracao com HTTP 403 e pagina acessivel, sem excecao bruta;
- usa os rotulos nativos e traduzidos de status do GLPI, incluindo o status de aprovacao do GLPI 11;
- corrige os erros formais bloqueantes do PHPCS e adiciona testes de regressao.
## 0.1.106-beta

- adiciona a opcao geral `Mascarar contatos pessoais`, desativada por padrao;
- preserva a exibicao dos contatos conforme ACL nativa do chamado quando a opcao esta desativada;
- mantem mascaramento, revelacao temporaria, justificativa e auditoria quando a opcao esta ativada;
- registra a configuracao nos diagnosticos e na auditoria administrativa;
- amplia a regressao para validar os estados visivel e mascarado.
## 0.1.105-beta

- reforca isolamento por entidade e ACL nativa em tickets, templates ITIL, auditoria e roteiros;
- elimina a descoberta recursiva de fonte de login por HTTP e usa o seletor nativo do GLPI em memoria;
- valida novamente templates, artigos KB e permissoes imediatamente antes de operacoes sensiveis;
- protege uploads temporarios com ownership, descarte automatico e commit somente apos sucesso nativo;
- mascara dados pessoais por padrao e adiciona revelacao temporaria, justificada e auditada;
- torna aprovacao/rejeicao de roteiros resistente a replay e concorrencia;
- reduz o fallback de listagem para 500 chamados e comunica resultados parciais sem expor diagnosticos tecnicos a usuarios comuns;
- adiciona testes de regressao para fronteiras de entidade, template, login, upload e dados pessoais.

## 0.1.104-beta

- Corrige ACL de roteamento e mudanca de status por chamado, respeitando Ticket::canAssign() e a matriz nativa de transicoes.
- Bloqueia bypass de roteamento por UPDATE generico e remove aprovacao implicita quando o requisitante nao esta identificado.

## 0.1.102-beta

- implementa os contratos P1 de fallback Search API, com grupo atribuido alinhado ao GLPI e sinalizacao explicita de resultados parciais no limite de 5.000 chamados;
- endurece a confirmacao de anexos com `Document`/`Document_Item` e informa sucesso parcial sem permitir reenvio duplicado;
- melhora a submissao delegada de formularios GLPI 11/Formcreator, tratando redirecionamentos nativos e respostas inesperadas;
- normaliza erros de formulario e torna o resumo de validacao navegavel por teclado e leitor de tela;
- documenta o escopo homologado e os limites beta da paridade de formularios.
## 0.1.101-beta

- normaliza perfil, entidade e grupos pelo contexto nativo antes das telas autenticadas;
- preserva ACL e fallback nativo ao detectar contexto operacional incompleto.
## 0.1.100-beta

- corrige o retorno de foco quando condicoes dinamicas ocultam o campo ativo;
- adiciona reflow assistivo para controles de voz, formularios e iframe nativo;
- adiciona suporte visual a forced-colors para foco e bordas;
- mantem a validacao e a submissao sob o motor nativo homologado.
- detecta iframe nativo sem formulario e oferece foco no link de pagina completa;
- bloqueia temporariamente o envio convertido quando o motor de condicoes falha.
## 0.1.99-beta

- refina o alto contraste dos cards de sugestao do chatbot;
- mantem fundo preto no estado normal, hover e foco;
- usa titulo amarelo, descricao branca e anel de foco branco;
- evita que o foco pareca um estado selecionado permanente.
## 0.1.98-beta

- corrige o contraste dos atalhos do chatbot no alto contraste;
- remove a cascata preto sobre preto dos textos secundarios `small`;
- garante foco visivel com contorno branco e faixa preta de separacao;
- sincroniza o CSS publico durante a geracao do pacote.
## 0.1.97-beta

- adiciona contrato centralizado de capacidades para separar renderizacao acessivel, delegacao nativa e submissao propria;
- adiciona gate de submissao que bloqueia qualquer tentativa propria sem homologacao explicita de ACL, condicoes, destinos, validacoes e anexos;
- expõe diagnostico estruturado de fallback nativo para Service Catalog GLPI 11 e Formcreator GLPI 10;
- corrige a limpeza de `aria-describedby` para remover referencias de erros antigos apos nova validacao;
- amplia a regressao automatizada para 68 testes e 370 assercoes.
## 0.1.96-beta

- Normaliza erros de validacao no servidor e no renderer para `{field, code, message}`, sem depender de busca por substring.
- Atualiza o renderer convertido para consumir mapas nativos de obrigatoriedade e bloqueio, mantendo `required`, `aria-required` e `disabled` sincronizados antes da validacao.
- Endurece a verificacao de anexos de tickets: conta documentos distintos e confirma sua existencia antes de considerar o vinculo `Document_Item` completo.
- Mantem campos nativos de usuario, grupo, dispositivo, ativo, LDAP e tag no fallback ate homologacao real de seletores e ACL por perfil/entidade.
- Formaliza o limite beta de 5.000 chamados e a necessidade de comparacao por IDs reais para `mine`, `group` e `group_id`.
## 0.1.95-beta

- Elimina os 89 achados do PHPStan com stubs de desenvolvimento para a API global do GLPI/Formcreator, sem incluir esses stubs no pacote.
- Corrige o prefixo duplicado do autoloader e documenta a excecao legitima dos doubles globais no PHPCS.
- Remove 821 violacoes mecanicas do PHPCS; permanecem avisos historicos de linhas longas para saneamento incremental.
- Mantem a regressao verde: 62 testes e 360 assercoes.

- Endurece Search API para grupos multiplos e papeis ITIL quando os Search Options reais estao disponiveis.
- Mantem fallback textual quando titulo e conteudo nao podem ser representados nativamente.
- Bloqueia conversao propria diante de condicoes nativas nao normalizadas.
- Confirma um vinculo Document_Item por anexo enviado e formaliza o limite beta de 5.000 chamados.
- Corrige o contrato de excecoes de validacao e a descoberta de APIs do Formcreator.
- Torna explicito o contraste dos placeholders dos campos de pergunta e descricao nos modos claro, noturno e alto contraste.

# Changelog

## 0.1.92-beta

- Corrige os quatro achados de contraste identificados na auditoria Pa11y autenticada.
- Define cores explícitas para campos principais e avatar no tema claro, noturno e alto contraste.
## 0.1.91-beta

- Restringe mensagens tecnicas de fallback e identificacao do backend da listagem de chamados a administradores ou perfis com config/UPDATE.
- Mantem a listagem, os filtros e as validacoes de ACL disponiveis para usuarios comuns sem expor detalhes internos da Search API.
## 0.1.87-beta

- Adiciona auditoria local Axe, restrita a configuradores GLPI, sem telemetria ou persistencia.
- Adiciona ferramentas Pa11y com captura manual de sessao local para homologacao autenticada.
- Inclui assets locais Axe, documentacao e exclusoes de sessao no Git.

## 0.1.86-beta

- Migra os namespaces de runtime para `GlpiPlugin\\Glpiacessivel`.
- Padroniza metadados, XML de catalogo e pacote Marketplace/offline.
- Adiciona pipeline de qualidade, compilacao gettext e checksum de release.
- Mantem Search API e formularios sob gates de equivalencia e homologacao real.

## 0.1.85-beta

- Suporta multiplos targets de ticket delegados ao Formcreator 2.13.11.

# 0.4.18-beta.63

- Calendário GLPI isolado e campo digitável para filtros absolutos de data e data/hora, sem alterar o layout ou a Search API.
- Precisão de segundos, teclado, foco e valores inválidos preservados; confirmação de horário sem executar pesquisa.
- Erros de data específicos e recuperação contextual do preenchimento rejeitado, separada da pesquisa aplicada.
- Manual 3.11 contextual, completo e offline atualizado. GLPI 10/11, sem SQL novo ou novas regras nativas.

