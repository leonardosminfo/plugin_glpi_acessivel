<?php

declare(strict_types=1);

// The read-only preflight uses a dedicated CSRF token, separate from the final write.
define('GLPI_KEEP_CSRF_TOKEN', '1');
require_once dirname(__DIR__, 3) . '/inc/includes.php';
require_once dirname(__DIR__) . '/setup.php';

\GlpiPlugin\Glpiacessivel\UI\Controller\TicketController::routingPreflight();
