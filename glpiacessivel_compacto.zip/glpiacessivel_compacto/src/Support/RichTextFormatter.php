<?php

declare(strict_types=1);

namespace GlpiPlugin\Glpiacessivel\Support;

final class RichTextFormatter
{
    public static function toHtml(?string $content): string
    {
        // Rich content is already in the native storage representation. Label
        // normalization would decode intentional entities and collapse preformatted
        // whitespace before the GLPI renderer interprets it.
        $content = (string) $content;
        if ($content === '') {
            return '';
        }

        if (class_exists('\Glpi\RichText\RichText')) {
            try {
                if (method_exists('\Glpi\RichText\RichText', 'getEnhancedHtml')) {
                    return \Glpi\RichText\RichText::getEnhancedHtml($content, ['images_gallery' => true]);
                }

                if (method_exists('\Glpi\RichText\RichText', 'getSafeHtml')) {
                    return \Glpi\RichText\RichText::getSafeHtml($content);
                }
            } catch (\Throwable $e) {
                // Fallback abaixo: nunca interrompe a tela por diferenca de assinatura entre versoes.
            }
        }

        return nl2br(htmlspecialchars($content, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8'));
    }
}
