<?php

declare(strict_types=1);

namespace GlpiPlugin\Glpiacessivel\Support;

use GlpiPlugin\Glpiacessivel\Application\ChatbotService;
use GlpiPlugin\Glpiacessivel\Application\ChatbotPlaybookService;
use GlpiPlugin\Glpiacessivel\Application\ConfigService;
use GlpiPlugin\Glpiacessivel\Application\PortalModulePolicy;
use GlpiPlugin\Glpiacessivel\Application\RemoteSearchValueAuthorizer;
use GlpiPlugin\Glpiacessivel\Application\ContextService;
use GlpiPlugin\Glpiacessivel\Application\FormService;
use GlpiPlugin\Glpiacessivel\Application\KnowledgeBaseService;
use GlpiPlugin\Glpiacessivel\Application\TicketService;
use GlpiPlugin\Glpiacessivel\Application\SavedTicketSearchService;
use GlpiPlugin\Glpiacessivel\Domain\Pii\PiiMasker;
use GlpiPlugin\Glpiacessivel\Domain\Security\Authorization;
use GlpiPlugin\Glpiacessivel\Domain\Security\AuditAuthorization;
use GlpiPlugin\Glpiacessivel\Domain\Ticket\TicketCreationPolicy;
use GlpiPlugin\Glpiacessivel\Domain\Ticket\TicketPolicy;
use GlpiPlugin\Glpiacessivel\Infrastructure\Audit\AuditLogger;
use GlpiPlugin\Glpiacessivel\Infrastructure\Audit\AuditEventPolicy;
use GlpiPlugin\Glpiacessivel\Infrastructure\Audit\AuditQueryService;
use GlpiPlugin\Glpiacessivel\Infrastructure\FormCatalog\Formcreator213CatalogGateway;
use GlpiPlugin\Glpiacessivel\Infrastructure\Repository\FormRepository;
use GlpiPlugin\Glpiacessivel\Infrastructure\Repository\PlaybookRepository;
use GlpiPlugin\Glpiacessivel\Infrastructure\Repository\TicketRepository;
use GlpiPlugin\Glpiacessivel\Infrastructure\Repository\NativeSavedSearchGateway;
use GlpiPlugin\Glpiacessivel\Infrastructure\Security\IdempotencyLedger;
use GlpiPlugin\Glpiacessivel\Infrastructure\Search\GlpiSearchValueProvider;
use GlpiPlugin\Glpiacessivel\Infrastructure\Search\GlpiSearchValueRateLimiter;
use GlpiPlugin\Glpiacessivel\Infrastructure\Search\GlpiResourceSelectorProvider;
use GlpiPlugin\Glpiacessivel\Infrastructure\Search\GlpiBoundedTicketSearchGateway;

final class Container
{
    private static ?self $instance = null;

    private ?AuditLogger $auditLogger = null;
    private ?TicketRepository $ticketRepository = null;
    private ?PlaybookRepository $playbookRepository = null;
    private ?FormRepository $formRepository = null;
    private ?NativeSavedSearchGateway $savedTicketSearchRepository = null;
    private ?TicketPolicy $ticketPolicy = null;
    private ?TicketCreationPolicy $ticketCreationPolicy = null;
    private ?TicketService $ticketService = null;
    private ?KnowledgeBaseService $knowledgeBaseService = null;
    private ?FormService $formService = null;
    private ?ChatbotPlaybookService $chatbotPlaybookService = null;
    private ?ChatbotService $chatbotService = null;
    private ?ConfigService $configService = null;
    private ?PortalModulePolicy $portalModulePolicy = null;
    private ?ContextService $contextService = null;
    private ?SavedTicketSearchService $savedTicketSearchService = null;
    private ?PiiMasker $piiMasker = null;
    private ?Authorization $authorization = null;
    private ?AuditAuthorization $auditAuthorization = null;
    private ?AuditQueryService $auditQueryService = null;
    private ?IdempotencyLedger $idempotencyLedger = null;
    private ?GlpiSearchValueProvider $searchValueProvider = null;
    private ?GlpiSearchValueRateLimiter $searchValueRateLimiter = null;
    private ?RemoteSearchValueAuthorizer $remoteSearchValueAuthorizer = null;
    private ?GlpiResourceSelectorProvider $resourceSelectorProvider = null;

    public static function get(): self
    {
        if (self::$instance === null) {
            self::$instance = new self();
        }

        return self::$instance;
    }

    public function featureReleasePolicy(): \GlpiPlugin\Glpiacessivel\Application\FeatureReleasePolicy
    {
        return new \GlpiPlugin\Glpiacessivel\Application\FeatureReleasePolicy();
    }

    public function nativeTicketStatisticsService(): \GlpiPlugin\Glpiacessivel\Application\NativeTicketStatisticsService
    {
        return new \GlpiPlugin\Glpiacessivel\Application\NativeTicketStatisticsService();
    }

    public function ticketTagsService(): \GlpiPlugin\Glpiacessivel\Application\TicketTagsService
    {
        return new \GlpiPlugin\Glpiacessivel\Application\TicketTagsService(
            new \GlpiPlugin\Glpiacessivel\Infrastructure\Tags\GlpiTicketTagsGateway()
        );
    }

    public function ticketTagsPageService(): \GlpiPlugin\Glpiacessivel\Application\TicketTagsPageService
    {
        return new \GlpiPlugin\Glpiacessivel\Application\TicketTagsPageService(
            new \GlpiPlugin\Glpiacessivel\Infrastructure\Tags\GlpiTicketTagsPageGateway()
        );
    }

    public function auditLogger(): AuditLogger
    {
        if ($this->auditLogger === null) {
            $this->auditLogger = new AuditLogger(new AuditEventPolicy($this->configService()));
        }

        return $this->auditLogger;
    }

    public function ticketRepository(): TicketRepository
    {
        if ($this->ticketRepository === null) {
            global $DB;
            $solutionIdempotencyLedger = isset($DB) && $DB instanceof \DBmysql
                ? $this->idempotencyLedger()
                : null;
            $boundedSearchGateway = GlpiBoundedTicketSearchGateway::forCurrentRuntime(
                $this->configService()->getTicketListStatementTimeoutMilliseconds(),
                $this->configService()->isTicketListPerformanceLimitsEnabled()
            );
            $this->ticketRepository = new TicketRepository(
                $boundedSearchGateway,
                $solutionIdempotencyLedger
            );
        }

        return $this->ticketRepository;
    }

    public function playbookRepository(): PlaybookRepository
    {
        if ($this->playbookRepository === null) {
            $this->playbookRepository = new PlaybookRepository();
        }

        return $this->playbookRepository;
    }
    public function formRepository(): FormRepository
    {
        if ($this->formRepository === null) {
            $formCatalogEnabled = false;
            try {
                $formCatalogEnabled = $this->configService()->isFormCatalogV2Enabled();
            } catch (\Throwable $e) {
                // A missing configuration store must keep the new catalog off.
                $formCatalogEnabled = false;
            }
            $this->formRepository = new FormRepository(new Formcreator213CatalogGateway(
                null,
                '\\PluginFormcreatorForm',
                null,
                null,
                null,
                $formCatalogEnabled
            ));
        }

        return $this->formRepository;
    }

    public function savedTicketSearchRepository(): NativeSavedSearchGateway
    {
        if ($this->savedTicketSearchRepository === null) {
            $this->savedTicketSearchRepository = new NativeSavedSearchGateway();
        }

        return $this->savedTicketSearchRepository;
    }

    public function ticketPolicy(): TicketPolicy
    {
        if ($this->ticketPolicy === null) {
            $this->ticketPolicy = new TicketPolicy();
        }

        return $this->ticketPolicy;
    }

    public function ticketCreationPolicy(): TicketCreationPolicy
    {
        if ($this->ticketCreationPolicy === null) {
            $this->ticketCreationPolicy = new TicketCreationPolicy();
        }

        return $this->ticketCreationPolicy;
    }

    public function piiMasker(): PiiMasker
    {
        if ($this->piiMasker === null) {
            $this->piiMasker = new PiiMasker();
        }

        return $this->piiMasker;
    }

    public function authorization(): Authorization
    {
        if ($this->authorization === null) {
            $this->authorization = new Authorization();
        }

        return $this->authorization;
    }

    public function auditAuthorization(): AuditAuthorization
    {
        if ($this->auditAuthorization === null) {
            $this->auditAuthorization = new AuditAuthorization();
        }

        return $this->auditAuthorization;
    }

    public function auditQueryService(): AuditQueryService
    {
        global $DB;
        if (!isset($DB) || !($DB instanceof \DBmysql)) {
            throw new \RuntimeException('audit_query_database_unavailable');
        }
        if ($this->auditQueryService === null) {
            $this->auditQueryService = new AuditQueryService($DB, $this->auditAuthorization());
        }

        return $this->auditQueryService;
    }

    public function ticketService(): TicketService
    {
        if ($this->ticketService === null) {
            global $DB;
            $solutionIdempotencyLedger = isset($DB) && $DB instanceof \DBmysql
                ? $this->idempotencyLedger()
                : null;
            $this->ticketService = new TicketService(
                $this->ticketRepository(),
                $this->ticketPolicy(),
                $this->ticketCreationPolicy(),
                $this->auditLogger(),
                $this->piiMasker(),
                $this->authorization(),
                $this->configService(),
                $this->resourceSelectorProvider(),
                $solutionIdempotencyLedger,
                $this->ticketTagsPageService()
            );
        }

        return $this->ticketService;
    }

    public function knowledgeBaseService(): KnowledgeBaseService
    {
        if ($this->knowledgeBaseService === null) {
            $this->knowledgeBaseService = new KnowledgeBaseService(
                $this->auditLogger(),
                $this->authorization()
            );
        }

        return $this->knowledgeBaseService;
    }
    public function formService(): FormService
    {
        if ($this->formService === null) {
            $this->formService = new FormService(
                $this->formRepository(),
                $this->authorization(),
                $this->auditLogger()
            );
        }

        return $this->formService;
    }

    public function chatbotService(): ChatbotService
    {
        if ($this->chatbotService === null) {
            $this->chatbotService = new ChatbotService(
                $this->ticketService(),
                $this->knowledgeBaseService(),
                $this->auditLogger(),
                $this->authorization(),
                $this->configService(),
                $this->portalModulePolicy(),
                $this->chatbotPlaybookService()
            );
        }

        return $this->chatbotService;
    }

    public function chatbotPlaybookService(): ChatbotPlaybookService
    {
        if ($this->chatbotPlaybookService === null) {
            $this->chatbotPlaybookService = new ChatbotPlaybookService(
                $this->ticketRepository(),
                $this->playbookRepository(),
                $this->auditLogger()
            );
        }

        return $this->chatbotPlaybookService;
    }

    public function configService(): ConfigService
    {
        if ($this->configService === null) {
            $this->configService = new ConfigService();
        }

        return $this->configService;
    }

    public function portalModulePolicy(): PortalModulePolicy
    {
        if ($this->portalModulePolicy === null) {
            $this->portalModulePolicy = new PortalModulePolicy($this->configService());
        }

        return $this->portalModulePolicy;
    }

    public function contextService(): ContextService
    {
        if ($this->contextService === null) {
            $this->contextService = new ContextService($this->auditLogger());
        }

        return $this->contextService;
    }

    public function idempotencyLedger(): IdempotencyLedger
    {
        global $DB;
        if (!isset($DB) || !($DB instanceof \DBmysql)) {
            throw new \RuntimeException('idempotency_ledger_database_unavailable');
        }
        if ($this->idempotencyLedger === null) {
            $this->idempotencyLedger = new IdempotencyLedger($DB);
        }
        return $this->idempotencyLedger;
    }

    public function savedTicketSearchService(): SavedTicketSearchService
    {
        if ($this->savedTicketSearchService === null) {
            $this->savedTicketSearchService = new SavedTicketSearchService(
                $this->savedTicketSearchRepository(),
                $this->authorization(),
                $this->auditLogger()
            );
        }

        return $this->savedTicketSearchService;
    }

    public function searchValueProvider(): GlpiSearchValueProvider
    {
        if ($this->searchValueProvider === null) {
            $this->searchValueProvider = new GlpiSearchValueProvider();
        }

        return $this->searchValueProvider;
    }

    public function remoteSearchValueAuthorizer(): RemoteSearchValueAuthorizer
    {
        if ($this->remoteSearchValueAuthorizer === null) {
            $this->remoteSearchValueAuthorizer = new RemoteSearchValueAuthorizer(
                $this->searchValueProvider(),
                $this->searchValueRateLimiter()
            );
        }

        return $this->remoteSearchValueAuthorizer;
    }

    public function searchValueRateLimiter(): GlpiSearchValueRateLimiter
    {
        if ($this->searchValueRateLimiter === null) {
            $this->searchValueRateLimiter = new GlpiSearchValueRateLimiter();
        }

        return $this->searchValueRateLimiter;
    }

    public function resourceSelectorProvider(): GlpiResourceSelectorProvider
    {
        if ($this->resourceSelectorProvider === null) {
            $this->resourceSelectorProvider = new GlpiResourceSelectorProvider();
        }

        return $this->resourceSelectorProvider;
    }
}
