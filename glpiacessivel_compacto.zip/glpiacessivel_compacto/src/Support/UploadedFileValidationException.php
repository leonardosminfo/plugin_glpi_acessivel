<?php

declare(strict_types=1);

namespace GlpiPlugin\Glpiacessivel\Support;

/** A known upload preparation refusal, before any business-model operation. */
final class UploadedFileValidationException extends \RuntimeException
{
    public readonly string $reason;

    public function __construct(string $reason, string $filename = '')
    {
        $known = ['too_large', 'incomplete', 'type_not_allowed', 'invalid', 'unavailable'];
        $this->reason = in_array($reason, $known, true)
            ? $reason : 'unavailable';
        $filename = basename(str_replace('\\', '/', $filename));
        $filename = mb_substr((string) preg_replace('/[\x00-\x1f\x7f]/', '', $filename), 0, 120, 'UTF-8');
        $message = match ($this->reason) {
            'too_large' => sprintf(
                I18n::translate('O arquivo excede o limite de envio permitido: %s.'),
                $filename
            ),
            'incomplete' => sprintf(
                I18n::translate('O envio do arquivo ficou incompleto: %s. Selecione-o novamente.'),
                $filename
            ),
            'type_not_allowed' => sprintf(
                I18n::translate('O tipo de arquivo não é permitido pelo GLPI: %s.'),
                $filename
            ),
            'invalid' => sprintf(
                I18n::translate('Não foi possível preparar o arquivo selecionado: %s. Selecione-o novamente.'),
                $filename
            ),
            default => I18n::translate(
                'Não foi possível preparar os anexos. Selecione os arquivos novamente ou tente mais tarde.'
            ),
        };
        parent::__construct($message);
    }
}
