<?php

declare(strict_types=1);

namespace GlpiPlugin\Glpiacessivel\Support;

/** Bounded, session-owned selections. Tokens never grant native authorization. */
final class EditorialBatchState
{
    private const KEY = 'glpiacessivel_editorial_batches';
    public const LIMIT = 20;

    public static function context(): string
    {
        return hash('sha256', json_encode([
            (int) ($_SESSION['glpiID'] ?? 0), (int) ($_SESSION['glpiactiveprofile']['id'] ?? 0),
            (int) ($_SESSION['glpiactive_entity'] ?? 0), !empty($_SESSION['glpiactive_entity_recursive']),
        ]) ?: '');
    }

    public static function page(array $items, array $filters, array $selected = []): string
    {
        $rows = [];
        foreach ($items as $item) {
            if (($item['status'] ?? '') === 'pending') {
                $rows[] = self::row($item);
            }
        }
        if (count($rows) > self::LIMIT) {
            throw new \InvalidArgumentException('batch_limit');
        }
        return self::store(['kind' => 'page', 'rows' => $rows, 'filters' => $filters,
            'selected' => array_values(array_intersect(array_column($rows, 'id'), $selected)),
            'expires_at' => time() + 3600]);
    }

    public static function selection(string $token, array $ids, bool $all = false): array
    {
        $page = self::get($token);
        if ($page['kind'] !== 'page' || $page['expired']) {
            throw new \RuntimeException('batch_page_expired');
        }
        if (count($ids) > self::LIMIT) {
            throw new \InvalidArgumentException('batch_limit');
        }
        $selected = [];
        foreach ($ids as $id) {
            if (!is_scalar($id) || !ctype_digit((string) $id) || (int) $id <= 0) {
                throw new \InvalidArgumentException('batch_selection_invalid');
            }
            $selected[(int) $id] = true;
        }
        $allowed = array_column($page['rows'], 'id');
        if (array_diff(array_keys($selected), $allowed) !== []) {
            throw new \RuntimeException('batch_selection_outside_page');
        }
        $rows = $all ? $page['rows'] : array_values(array_filter(
            $page['rows'],
            static fn(array $row): bool => isset($selected[$row['id']])
        ));
        if ($rows === []) {
            throw new \InvalidArgumentException('batch_selection_empty');
        }
        return ['rows' => $rows, 'filters' => $page['filters']];
    }

    public static function review(array $selection, string $action, array $prepared): string
    {
        if (!in_array($action, ['approve', 'reject'], true) || count($selection['rows']) > self::LIMIT) {
            throw new \InvalidArgumentException('batch_action_invalid');
        }
        return self::store(['kind' => 'review', 'phase' => 'review', 'action' => $action,
            'rows' => $selection['rows'], 'filters' => $selection['filters'],
            'manifest' => $prepared['manifest'] ?? $selection['rows'],
            'ready' => !empty($prepared['eligible']), 'expires_at' => time() + 1800]);
    }

    public static function get(string $token): array
    {
        self::purge();
        $record = $_SESSION[self::KEY][$token] ?? null;
        if (!is_array($record) || !hash_equals($record['context'], self::context())) {
            throw new \RuntimeException('batch_context_or_token_invalid');
        }
        $record['expired'] = (int) $record['expires_at'] < time();
        return $record;
    }

    public static function claim(string $token): array
    {
        $record = self::get($token);
        if ($record['kind'] !== 'review' || $record['phase'] !== 'review' || $record['expired'] || !$record['ready']) {
            throw new \RuntimeException('batch_confirmation_invalid');
        }
        $_SESSION[self::KEY][$token]['phase'] = 'processing';
        return $record;
    }

    public static function finish(string $token, array $result): void
    {
        $record = self::get($token);
        if ($record['kind'] !== 'review' || $record['phase'] !== 'processing') {
            throw new \RuntimeException('batch_result_invalid');
        }
        $_SESSION[self::KEY][$token]['phase'] = 'result';
        // The service returns categorical outcomes only. Never store article copies.
        $_SESSION[self::KEY][$token]['result'] = ['status' => $result['status'] ?? 'interrupted',
            'action' => $record['action'], 'items' => array_map(static fn(array $item): array => [
                'id' => (int) ($item['id'] ?? 0), 'status' => (string) ($item['status'] ?? 'unknown'),
                'reason' => (string) ($item['reason'] ?? 'unknown'),
            ], array_slice((array) ($result['items'] ?? []), 0, self::LIMIT))];
    }

    public static function discard(string $token): void
    {
        $record = self::get($token);
        if ($record['kind'] !== 'review' || $record['phase'] !== 'review') {
            throw new \RuntimeException('batch_cancel_invalid');
        }
        unset($_SESSION[self::KEY][$token]);
    }

    public static function row(array $item): array
    {
        return ['id' => (int) ($item['id'] ?? 0), 'revision' => (int) ($item['revision'] ?? 1),
            'target_playbook_id' => (int) ($item['target_playbook_id'] ?? 0),
            'expected_revision' => (int) ($item['expected_revision'] ?? 0)];
    }

    private static function store(array $record): string
    {
        self::purge();
        $token = bin2hex(random_bytes(24));
        $_SESSION[self::KEY][$token] = $record + ['context' => self::context(), 'created_at' => time()];
        $_SESSION[self::KEY] = array_slice($_SESSION[self::KEY], -30, null, true);
        return $token;
    }

    private static function purge(): void
    {
        $records = is_array($_SESSION[self::KEY] ?? null) ? $_SESSION[self::KEY] : [];
        foreach ($records as $token => $record) {
            if (!is_array($record) || (int) ($record['created_at'] ?? 0) < time() - 86400) {
                unset($records[$token]);
            }
        }
        $_SESSION[self::KEY] = $records;
    }
}
