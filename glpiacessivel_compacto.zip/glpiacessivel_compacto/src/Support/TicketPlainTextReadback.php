<?php

declare(strict_types=1);

namespace GlpiPlugin\Glpiacessivel\Support;

/**
 * Strict readback of the simple editor's escaped-text / br serialization.
 * This is deliberately not a general HTML-to-text converter: unknown markup
 * must not turn structural loss into a successful plain-text comparison.
 */
final class TicketPlainTextReadback
{
    public const MAX_INPUT_BYTES = 65536;

    public function extract(string $stored): ?string
    {
        if (
            strlen($stored) > self::MAX_INPUT_BYTES
            || preg_match('//u', $stored) !== 1
            || preg_match('/[\x00-\x08\x0B\x0C\x0E-\x1F]/', $stored) === 1
        ) {
            return null;
        }

        $body = str_replace(["\r\n", "\r"], "\n", $stored);
        // Only an attribute-free, single outer paragraph/div is admitted.
        // Nested/multiple blocks, links, images, styling and attributes remain
        // outside this contract even when a broad projector reports no loss.
        if (preg_match('~\A<(p|div)>(.*)</\1>\z~isD', $body, $wrapper) === 1) {
            $body = $wrapper[2];
        }
        $body = preg_replace('~<br\s*/?>~i', "\n", $body);
        if (!is_string($body) || str_contains($body, '<')) {
            return null;
        }
        preg_match_all('/&#(?:x[0-9a-f]+|[0-9]+);/i', $body, $numericEntities);
        foreach ($numericEntities[0] as $entity) {
            if (html_entity_decode($entity, ENT_QUOTES | ENT_HTML5, 'UTF-8') === $entity) {
                return null;
            }
        }

        // Decode once, after recognizing tags. A literal &lt;br&gt; remains
        // literal text; it is never interpreted a second time as a newline.
        $text = html_entity_decode($body, ENT_QUOTES | ENT_HTML5, 'UTF-8');
        if (preg_match('/[\x00-\x08\x0B\x0C\x0E-\x1F]/', $text) === 1) {
            return null;
        }
        return str_replace(["\r\n", "\r"], "\n", $text);
    }
}
