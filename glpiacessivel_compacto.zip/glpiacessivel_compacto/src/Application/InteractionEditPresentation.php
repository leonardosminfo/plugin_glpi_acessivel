<?php

declare(strict_types=1);

namespace GlpiPlugin\Glpiacessivel\Application;

/** Presentation only; the caller must authorize the parent and interaction first. */
final class InteractionEditPresentation
{
    public static function mode(array $context, bool $completeReleased): string
    {
        if ($completeReleased) {
            return 'native';
        }
        if (!empty($context['can_edit_content'])) {
            return !empty($context['can_change_privacy']) ? 'simple' : 'text';
        }
        return !empty($context['can_change_privacy']) ? 'visibility' : 'unavailable';
    }

    public static function title(string $mode, string $kind): string
    {
        return match ($mode) {
            'native' => $kind === 'task' ? __('Editar tarefa', 'glpiacessivel') : __('Editar acompanhamento', 'glpiacessivel'),
            'simple' => __('Editar texto e visibilidade', 'glpiacessivel'),
            'text' => __('Editar texto', 'glpiacessivel'),
            'visibility' => __('Alterar visibilidade', 'glpiacessivel'),
            default => __('Edição da interação', 'glpiacessivel'),
        };
    }
}
