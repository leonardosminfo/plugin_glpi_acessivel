<?php

declare(strict_types=1);

namespace GlpiPlugin\Glpiacessivel\Application;

use GlpiPlugin\Glpiacessivel\Domain\Knowledge\KnowledgeSourceReader;

/** No persisted permission grants: every invocation revalidates the session. */
final class PlaybookEligibilityPolicy
{
    public function __construct(private KnowledgeSourceReader $reader)
    {
    }

    public function evaluate(array $playbook, array $dependencies): ?array
    {
        if ((int) ($playbook['is_active'] ?? 0) !== 1) {
            return null;
        }
        if (($playbook['origin_type'] ?? '') === 'legacy') {
            return null;
        }
        $references = (array) ($playbook['kb_articles'] ?? []);
        // Unmapped legacy sources cannot authorize copied content.
        if ($dependencies === [] && $references !== []) {
            return null;
        }
        if ($dependencies === [] && ($playbook['content']['source_type'] ?? '') === 'knowledge_base') {
            return null;
        }
        $authorized = [];
        $alternatives = [];
        $checked = [];
        foreach ($dependencies as $dependency) {
            $id = (int) ($dependency['source_id'] ?? $dependency['knowbaseitems_id'] ?? 0);
            if ($id <= 0) {
                return null;
            }
            if (
                isset($dependency['installation_id'])
                && !hash_equals(KnowledgeScanService::installationId(), (string) $dependency['installation_id'])
            ) {
                return null;
            }
            if (!isset($checked[$id])) {
                $checked[$id] = $this->reader->readForAnswer($id);
            }
            $source = $checked[$id];
            $expected = (string) ($dependency['text_hash'] ?? '');
            $valid = !empty($source['eligible'])
                && ($source['publication'] ?? '') === 'published'
                && ($source['validity'] ?? '') === 'current'
                && $expected !== ''
                && hash_equals($expected, (string) ($source['text_hash'] ?? ''));
            $role = (string) ($dependency['role'] ?? 'required');
            if ($role === 'alternative') {
                $group = (string) ($dependency['alternative_group'] ?? '');
                // Alternative sources are safe only for separately sourced sections.
                if ($group === '' || empty($dependency['section_key'] ?? $dependency['section'] ?? '')) {
                    return null;
                }
                $alternatives[$group] = ($alternatives[$group] ?? false) || $valid;
            } elseif (!$valid) {
                return null;
            }
            if ($valid) {
                $authorized[$id] = $source;
            }
        }
        if (in_array(false, $alternatives, true)) {
            return null;
        }
        // Mixed summaries cannot safely retain fragments from an unavailable alternative.
        if ($alternatives !== [] && count($authorized) !== count($checked)) {
            return null;
        }
        foreach ($references as $reference) {
            if (!is_array($reference) || !isset($authorized[(int) ($reference['id'] ?? 0)])) {
                return null;
            }
        }
        $playbook['kb_articles'] = array_values(array_map(static fn(array $source): array => [
            'id' => (int) $source['id'],
            'name' => (string) $source['name'],
        ], $authorized));
        $playbook['authorized_sources'] = array_values($authorized);
        return $playbook;
    }
}
