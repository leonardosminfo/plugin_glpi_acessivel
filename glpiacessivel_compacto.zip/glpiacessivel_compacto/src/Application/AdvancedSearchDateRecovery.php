<?php

declare(strict_types=1);

namespace GlpiPlugin\Glpiacessivel\Application;

use GlpiPlugin\Glpiacessivel\Domain\Ticket\NativeSearchDefinitionValidator;
use GlpiPlugin\Glpiacessivel\Domain\Ticket\NativeSearchValidationException;
use GlpiPlugin\Glpiacessivel\Infrastructure\Security\GlpiSessionContextSnapshot;

/** A one-use editor draft, never an applied search or an executable token. */
final class AdvancedSearchDateRecovery
{
    private const SESSION_KEY = 'glpiacessivel_advanced_date_recovery_v1';
    private const TTL_SECONDS = 300;
    private \Closure $context;
    private \Closure $clock;

    /** @param callable():string|null $context @param callable():int|null $clock */
    public function __construct(?callable $context = null, ?callable $clock = null)
    {
        $this->context = \Closure::fromCallable($context ?? static function (): string {
            return (new GlpiSessionContextSnapshot())->snapshot()['revision'];
        });
        $this->clock = \Closure::fromCallable($clock ?? static fn(): int => time());
    }

    public static function isDateCode(string $code): bool
    {
        return in_array($code, ['native_search_date_invalid', 'native_search_datetime_invalid'], true);
    }

    public static function isValuePath(string $path): bool
    {
        return preg_match('/\Adefinition\.(?:criteria\.(?:[0-9]|[1-4][0-9])(?:\.criteria\.(?:[0-9]|[1-4][0-9])){0,4}|metacriteria\.(?:[0-9]|1[0-9]|2[0-4]))\.value\z/D', $path) === 1;
    }

    /**
     * $translated is the bounded form projection before frequent filters are
     * compiled. $compiled locates the failing leaf if the compiler wrapped OR
     * criteria. Only the editor projection is retained.
     */
    public function remember(array $translated, array $compiled, NativeSearchValidationException $error, string $catalogRevision): bool
    {
        $this->clear();
        try {
            if (
                !self::isDateCode($error->reasonCode()) || !self::isValuePath($error->fieldPath())
                || !$this->validDraft($translated) || !$this->isRevision($catalogRevision)
                || !hash_equals($catalogRevision, $translated['context_revision'])
            ) {
                return false;
            }
            $leaf = $this->leafAt($compiled, $error->fieldPath());
            if ($leaf === null || !is_string($leaf['value'] ?? null) || !$this->safeString($leaf['value'], 64)) {
                return false;
            }
            $path = $this->findLeafPath($translated['definition'], $leaf);
            $context = ($this->context)();
            if ($path === null || !$this->isRevision($context)) {
                return false;
            }
            $_SESSION[self::SESSION_KEY] = ['draft' => $translated, 'code' => $error->reasonCode(),
                'path' => $path, 'context' => $context, 'catalog_revision' => $catalogRevision,
                'created_at' => ($this->clock)()];
            return true;
        } catch (\Throwable) {
            return false;
        }
    }

    /** @return array{draft:array,code:string,path:string}|null */
    public function consume(string $catalogRevision, string $code): ?array
    {
        $record = $_SESSION[self::SESSION_KEY] ?? null;
        $this->clear();
        try {
            $now = ($this->clock)();
            if (
                !is_array($record) || count($record) !== 6 || !self::isDateCode($code)
                || ($record['code'] ?? null) !== $code || !$this->isRevision($catalogRevision)
                || !is_string($record['catalog_revision'] ?? null)
                || !hash_equals($catalogRevision, $record['catalog_revision'])
                || !is_string($record['context'] ?? null) || !hash_equals($record['context'], ($this->context)())
                || !is_int($record['created_at'] ?? null) || $record['created_at'] > $now
                || $record['created_at'] + self::TTL_SECONDS < $now
                || !is_array($record['draft'] ?? null) || !$this->validDraft($record['draft'])
                || !hash_equals($catalogRevision, $record['draft']['context_revision'])
                || !is_string($record['path'] ?? null) || !self::isValuePath($record['path'])
                || $this->leafAt($record['draft']['definition'], $record['path']) === null
            ) {
                return null;
            }
            $leaf = $this->leafAt($record['draft']['definition'], $record['path']);
            if ($leaf === null || !$this->safeString($leaf['value'] ?? null, 64)) {
                return null;
            }
            return ['draft' => $record['draft'], 'code' => $code, 'path' => $record['path']];
        } catch (\Throwable) {
            return null;
        }
    }

    public function clear(): void
    {
        unset($_SESSION[self::SESSION_KEY]);
    }

    private function validDraft(array $draft): bool
    {
        $encoded = json_encode($draft, JSON_UNESCAPED_UNICODE);
        if (
            !is_string($encoded) || strlen($encoded) > NativeSearchDefinitionValidator::MAX_DEFINITION_BYTES
            || !$this->hasKeys($draft, ['definition', 'page_size', 'focus_results', 'context_revision', 'frequent_filters', 'presentation'])
            || !in_array($draft['page_size'] ?? null, [10, 20, 50, 100], true)
            || !is_bool($draft['focus_results'] ?? null) || !$this->isRevision($draft['context_revision'] ?? null)
            || !is_array($draft['frequent_filters'] ?? null) || !is_array($draft['presentation'] ?? null)
            || !$this->hasKeys($draft['presentation'], ['group_by'])
            || !in_array($draft['presentation']['group_by'], ['none', 'group'], true)
        ) {
            return false;
        }
        AdvancedTicketSearchFrequentFilters::validate($draft['frequent_filters']);
        $definition = $draft['definition'] ?? null;
        if (
            !is_array($definition) || !$this->hasKeys($definition, ['version', 'itemtype', 'text', 'scope', 'criteria',
            'metacriteria', 'sort', 'order', 'is_deleted', 'columns']) || $definition['version'] !== 3
            || $definition['itemtype'] !== 'Ticket' || !$this->safeString($definition['text'], 4096)
            || !in_array($definition['scope'], ['all', 'mine', 'group'], true)
            || !in_array($definition['is_deleted'], [0, 1], true)
            || !is_array($definition['sort']) || !array_is_list($definition['sort']) || count($definition['sort']) > 5
            || !is_array($definition['order']) || !array_is_list($definition['order'])
            || count($definition['sort']) !== count($definition['order'])
            || !is_array($definition['columns']) || !array_is_list($definition['columns']) || count($definition['columns']) > 50
        ) {
            return false;
        }
        foreach ($definition['sort'] as $index => $field) {
            if (!$this->field($field) || !in_array($definition['order'][$index], ['ASC', 'DESC'], true)) {
                return false;
            }
        }
        foreach ($definition['columns'] as $column) {
            if (!is_int($column) && !$this->safeString($column, 100)) {
                return false;
            }
        }
        $count = 0;
        $metaCount = 0;
        return $this->validTree($definition['criteria'], false, 0, $count)
            && $this->validTree($definition['metacriteria'], true, 0, $metaCount) && $metaCount <= 25;
    }

    private function validTree(mixed $nodes, bool $meta, int $depth, int &$count): bool
    {
        if (!is_array($nodes) || !array_is_list($nodes) || $depth > 4 || count($nodes) > 50) {
            return false;
        }
        foreach ($nodes as $node) {
            if (!is_array($node) || ++$count > 50 || !in_array($node['link'] ?? null, ['AND', 'OR', 'AND NOT', 'OR NOT'], true)) {
                return false;
            }
            if (array_key_exists('criteria', $node)) {
                if ($meta || !$this->hasKeys($node, ['link', 'criteria']) || !$this->validTree($node['criteria'], false, $depth + 1, $count)) {
                    return false;
                }
                continue;
            }
            if (
                array_diff(array_keys($node), ['link', 'field', 'searchtype', 'value', 'meta', 'itemtype']) !== []
                || !$this->field($node['field'] ?? null)
                || !in_array($node['searchtype'] ?? null, ['contains', 'notcontains', 'equals', 'notequals', 'under',
                    'notunder', 'lessthan', 'morethan', 'empty', 'notempty'], true)
                || !array_key_exists('value', $node) || !is_string($node['value']) || !$this->safeString($node['value'], 4096)
            ) {
                return false;
            }
            if (($meta || array_key_exists('itemtype', $node)) && (!$this->safeString($node['itemtype'] ?? null, 160) || $node['itemtype'] === '')) {
                return false;
            }
            if (array_key_exists('meta', $node) && !in_array($node['meta'], [1, '1'], true)) {
                return false;
            }
        }
        return true;
    }

    private function hasKeys(array $value, array $keys): bool
    {
        return count($value) === count($keys) && array_diff(array_keys($value), $keys) === [];
    }

    private function field(mixed $field): bool
    {
        return (is_int($field) && $field > 0)
            || (is_string($field) && preg_match('/\A(?:[1-9][0-9]{0,9}|all|view)\z/D', $field) === 1);
    }

    private function safeString(mixed $value, int $limit): bool
    {
        return is_string($value) && strlen($value) <= $limit && preg_match('//u', $value) === 1
            && preg_match('/[\x00-\x1F\x7F]/', $value) !== 1;
    }

    private function isRevision(mixed $revision): bool
    {
        return is_string($revision) && preg_match('/\A[a-f0-9]{64}\z/D', $revision) === 1;
    }

    private function leafAt(array $definition, string $path): ?array
    {
        if (!self::isValuePath($path)) {
            return null;
        }
        $segments = explode('.', $path);
        array_shift($segments);
        array_pop($segments);
        $current = $definition;
        foreach ($segments as $segment) {
            if (!is_array($current) || !array_key_exists($segment, $current)) {
                return null;
            }
            $current = $current[$segment];
        }
        return is_array($current) && !isset($current['criteria']) ? $current : null;
    }

    private function findLeafPath(array $definition, array $leaf): ?string
    {
        $visit = function (array $nodes, string $base) use (&$visit, $leaf): ?string {
            foreach ($nodes as $index => $node) {
                $path = $base . '.' . $index;
                if (isset($node['criteria'])) {
                    $nested = $visit($node['criteria'], $path . '.criteria');
                    if ($nested !== null) {
                        return $nested;
                    }
                } elseif ($node === $leaf) {
                    return $path . '.value';
                }
            }
            return null;
        };
        return $visit($definition['criteria'], 'definition.criteria')
            ?? $visit($definition['metacriteria'], 'definition.metacriteria');
    }
}
