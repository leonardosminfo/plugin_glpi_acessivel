<?php

declare(strict_types=1);

namespace GlpiPlugin\Glpiacessivel\Application;

/** Additional exposure restriction. Never replaces the native object/action authorization. */
final class FeatureReleasePolicy
{
    private static ?array $cached = null;
    private static bool $cachedValid = false;
    private static array $cachedModules = [];

    public static function reset(): void
    {
        self::$cached = null;
        self::$cachedValid = false;
        self::$cachedModules = [];
    }

    public static function configuration(bool $fresh = false): array
    {
        if (!$fresh && self::$cached !== null) {
            return self::$cached;
        }
        self::$cachedModules = [];
        $raw = (new ConfigService())->getFeatureReleasePolicyValue();
        $decoded = $raw === '' ? null : json_decode($raw, true);
        $valid = is_array($decoded) && ($decoded['schema_version'] ?? null) === 1 && is_array($decoded['features'] ?? null);
        $features = FeatureReleaseCatalog::seedForOrigin(null);
        if ($valid) {
            foreach ($features as $id => $_) {
                try {
                    $features[$id] = self::normalizeEntry($decoded['features'][$id] ?? ['mode' => 'off', 'profile_ids' => []]);
                } catch (\InvalidArgumentException) {
                    $valid = false;
                    break;
                }
            }
        }
        if (!$valid) {
            $features = FeatureReleaseCatalog::seedForOrigin(null);
        }
        self::$cachedValid = $valid;
        return self::$cached = [
            'schema_version' => 1,
            'revision' => hash('sha256', $raw),
            'features' => $features,
            'review_required' => !$valid || !empty($decoded['review_required']),
        ];
    }

    public static function allows(string $id, bool $fresh = false): bool
    {
        return self::evaluate($id, $fresh)['allowed'];
    }

    /** Exposure only: native rights and action/context validation remain the caller's responsibility.
     * @return array{allowed: bool, reason: string, feature: string}
     */
    public static function evaluate(string $id, bool $fresh = false): array
    {
        $known = isset(FeatureReleaseCatalog::all()[$id]);
        $decision = static fn(string $reason): array => [
            'allowed' => $reason === 'allowed', 'reason' => $reason, 'feature' => $known ? $id : '',
        ];
        try {
            $definitions = FeatureReleaseCatalog::all();
            if (!$known) {
                return $decision('unknown_feature');
            }
            if (!class_exists('Session') || (int) \Session::getLoginUserID() <= 0) {
                return $decision('session_unavailable');
            }
            $profileId = (int) ($_SESSION['glpiactiveprofile']['id'] ?? 0);
            if ($profileId <= 0) {
                return $decision('profile_unavailable');
            }
            // Off features take no module lookup. Cache only the module's configured
            // availability, never a user/profile decision; fresh/reset clears both snapshots.
            $configuration = self::configuration($fresh);
            if (!self::$cachedValid) {
                return $decision('policy_unavailable');
            }
            if (!self::releasedForProfile($configuration, $id, $profileId)) {
                return $decision($configuration['features'][$id]['mode'] === 'off'
                    ? 'feature_disabled' : 'profile_excluded');
            }
            if (
                $id === 'tickets.interaction_rich_edit'
                && !self::releasedForProfile($configuration, 'tickets.interaction_edit', $profileId)
            ) {
                return $decision('dependency_disabled');
            }
            $definition = $definitions[$id];
            $module = $definition['module'];
            if ($module !== '') {
                if (!array_key_exists($module, self::$cachedModules)) {
                    self::$cachedModules[$module] = (new PortalModulePolicy(new ConfigService()))->isEnabled($module);
                }
                return $decision(self::$cachedModules[$module] ? 'allowed' : 'module_disabled');
            }
            return $decision('allowed');
        } catch (\Throwable) {
            return $decision('policy_unavailable');
        }
    }

    public static function releasedForProfile(array $configuration, string $id, int $profileId): bool
    {
        if (!isset(FeatureReleaseCatalog::all()[$id]) || $profileId <= 0) {
            return false;
        }
        try {
            $entry = self::normalizeEntry($configuration['features'][$id] ?? []);
            return $entry['mode'] === 'all' || ($entry['mode'] === 'profiles' && in_array($profileId, $entry['profile_ids'], true));
        } catch (\InvalidArgumentException) {
            return false;
        }
    }

    public static function requireAllowed(string $id, bool $fresh = false): void
    {
        $decision = self::evaluate($id, $fresh);
        if (!$decision['allowed']) {
            throw new FeatureReleaseDenied($decision['feature'], $decision['reason']);
        }
    }

    public static function profileCatalog(): array
    {
        try {
            if (!class_exists('Profile') || !is_callable(['Profile', 'canView']) || !\Profile::canView()) {
                throw new \RuntimeException();
            }
            // Public CommonDBTM API; Profile is not entity-scoped. Do not invent a parallel query or ACL.
            $rows = (new \Profile())->find([], ['id ASC'], 1001);
            if (!is_array($rows) || count($rows) > 1000) {
                throw new \RuntimeException();
            }
            $profiles = [];
            foreach ($rows as $row) {
                if (!is_array($row) || (int) ($row['id'] ?? 0) <= 0 || !is_string($row['name'] ?? null)) {
                    throw new \RuntimeException();
                }
                $profiles[] = ['id' => (int) $row['id'], 'name' => $row['name']];
            }
            return ['available' => true, 'profiles' => $profiles, 'reason' => ''];
        } catch (\Throwable) {
            return ['available' => false, 'profiles' => [], 'reason' => 'profile_catalog_unavailable'];
        }
    }

    public static function review(array $postedFeatures): array
    {
        $current = self::configuration(true);
        $known = FeatureReleaseCatalog::all();
        if (array_diff(array_keys($postedFeatures), array_keys($known)) !== []) {
            throw new \InvalidArgumentException(__('Funcionalidade desconhecida. Recarregue a configuração.', 'glpiacessivel'));
        }
        $features = [];
        $catalog = null;
        foreach ($known as $id => $_) {
            $entry = self::normalizeEntry(array_key_exists($id, $postedFeatures)
                ? $postedFeatures[$id] : $current['features'][$id]);
            if ($entry['mode'] === 'profiles') {
                $catalog ??= self::profileCatalog();
                if (!$catalog['available'] || array_diff($entry['profile_ids'], array_column($catalog['profiles'], 'id')) !== []) {
                    throw new \InvalidArgumentException(__('Não foi possível validar os perfis selecionados. Confira as permissões e recarregue a página.', 'glpiacessivel'));
                }
            }
            $features[$id] = $entry;
        }
        return ['schema_version' => 1, 'revision' => $current['revision'], 'features' => $features];
    }

    /** Administrative preview only. Does not infer native rights or change selections. */
    public static function interactionCoverage(array $features, array $profiles): array
    {
        $rows = [];
        foreach ($profiles as $profile) {
            $id = (int) ($profile['id'] ?? 0);
            if ($id <= 0) {
                continue;
            }
            $configuration = ['features' => $features];
            $base = self::releasedForProfile($configuration, 'tickets.interaction_edit', $id);
            $rich = self::releasedForProfile($configuration, 'tickets.interaction_rich_edit', $id);
            if ($base || $rich) {
                $rows[] = ['id' => $id, 'name' => (string) $profile['name'], 'base' => $base,
                    'complete' => $base && $rich, 'incomplete' => $rich && !$base];
            }
        }
        return $rows;
    }

    public static function save(array $features, string $expectedRevision): void
    {
        if (!\Session::haveRight('config', UPDATE)) {
            throw new \RuntimeException(__('Sem permissão para alterar a liberação.', 'glpiacessivel'));
        }
        $reviewed = self::review($features);
        if (!hash_equals($reviewed['revision'], $expectedRevision)) {
            throw new \RuntimeException(__('A configuração foi alterada. Recarregue e revise novamente.', 'glpiacessivel'));
        }
        $raw = json_encode(['schema_version' => 1, 'revision' => bin2hex(random_bytes(16)), 'features' => $reviewed['features']], JSON_THROW_ON_ERROR);
        $config = new ConfigService();
        $config->setValue('feature_release_policy', $raw);
        self::reset();
        if (!hash_equals($raw, $config->getFeatureReleasePolicyValue())) {
            throw new \RuntimeException(__('Não foi possível confirmar o salvamento da liberação. Recarregue antes de tentar novamente.', 'glpiacessivel'));
        }
    }

    /** Explicit installation/provisioning only. Unknown origin remains restrictive and requires review. */
    public static function initialize(?string $trustedOrigin = null): void
    {
        $config = new ConfigService();
        if ($config->getFeatureReleasePolicyValue() !== '') {
            return;
        }
        $config->setValue('feature_release_policy', json_encode([
            'schema_version' => 1,
            'features' => FeatureReleaseCatalog::seedForOrigin($trustedOrigin),
            'review_required' => true,
        ], JSON_THROW_ON_ERROR));
        self::reset();
        if ($config->getFeatureReleasePolicyValue() === '') {
            throw new \RuntimeException('feature_release_initialization_unconfirmed');
        }
    }

    private static function normalizeEntry(mixed $entry): array
    {
        if (!is_array($entry) || !in_array($entry['mode'] ?? null, ['off', 'profiles', 'all'], true)) {
            throw new \InvalidArgumentException(__('Escolha um estado válido para cada funcionalidade.', 'glpiacessivel'));
        }
        if ($entry['mode'] !== 'profiles') {
            return ['mode' => $entry['mode'], 'profile_ids' => []];
        }
        if (!is_array($entry['profile_ids'] ?? null) || count($entry['profile_ids']) > 1000) {
            throw new \InvalidArgumentException(__('Selecione ao menos um perfil válido.', 'glpiacessivel'));
        }
        $ids = [];
        foreach ($entry['profile_ids'] as $id) {
            if ((!is_int($id) && !is_string($id)) || preg_match('/\A[1-9][0-9]{0,9}\z/D', (string) $id) !== 1) {
                throw new \InvalidArgumentException(__('Selecione ao menos um perfil válido.', 'glpiacessivel'));
            }
            $ids[] = (int) $id;
        }
        $ids = array_values(array_unique($ids));
        sort($ids, SORT_NUMERIC);
        if ($ids === []) {
            throw new \InvalidArgumentException(__('Selecione ao menos um perfil válido.', 'glpiacessivel'));
        }
        return ['mode' => 'profiles', 'profile_ids' => $ids];
    }
}
