<?php

declare(strict_types=1);

namespace GlpiPlugin\Glpiacessivel\Application;

use GlpiPlugin\Glpiacessivel\Infrastructure\Audit\AuditLogger;
use GlpiPlugin\Glpiacessivel\Infrastructure\Audit\RestrictedIntegrationDiagnostics;
use GlpiPlugin\Glpiacessivel\Infrastructure\Session\GlpiSessionContextGateway;
use GlpiPlugin\Glpiacessivel\Support\I18n;
use GlpiPlugin\Glpiacessivel\Support\TextNormalizer;

final class ContextService
{
    private AuditLogger $auditLogger;
    private GlpiSessionContextGateway $contextGateway;

    private const CONFIRMATION_SESSION_KEY = 'glpiacessivel_context_switch_confirmations_v1';
    private const CONFIRMATION_TTL = 120;
    private const CONFIRMATION_LIMIT = 5;
    private const ENTITY_SCOPE_DIRECT_PREFIX = 'direct:';
    private const ENTITY_SCOPE_TREE_PREFIX = 'tree:';

    public function __construct(AuditLogger $auditLogger, ?GlpiSessionContextGateway $contextGateway = null)
    {
        $this->auditLogger = $auditLogger;
        $this->contextGateway = $contextGateway ?? new GlpiSessionContextGateway();
    }

    /**
     * @return array{
     *   current_entity_id:int,
     *   current_entity_name:string,
     *   current_entity_scope_name:string,
     *   current_entity_value:string,
     *   is_all_entities:bool,
     *   current_profile_id:int,
     *   current_profile_name:string,
     *   user_label:string,
     *   is_valid:bool,
     *   summary:string,
     *   profiles:array<int,array{id:int,name:string}>,
     *   entities:array<string,array{id:int|string,value:string,name:string,recursive:bool,has_recursive_alternative:bool}>,
     *   entity_options_status:string,
     *   entity_options_complete:bool
     * }
     */
    public function getContext(): array
    {
        $currentEntityId = (int) ($_SESSION['glpiactive_entity'] ?? 0);
        $currentProfileId = (int) ($_SESSION['glpiactiveprofile']['id'] ?? 0);
        $isAllEntities = $this->isAllEntitiesScope();
        $entityName = $isAllEntities
            ? I18n::translate('Todas as entidades permitidas')
            : $this->currentEntityName($currentEntityId);
        $currentRecursive = !$isAllEntities && !empty($_SESSION['glpiactive_entity_recursive']);
        $currentEntityValue = $isAllEntities
            ? 'all'
            : $this->entityScopeValue($currentEntityId, $currentRecursive);
        $currentEntityScopeName = $isAllEntities
            ? $entityName
            : $entityName . I18n::translate(
                $currentRecursive ? ' — inclui subentidades' : ' — somente esta entidade'
            );
        $entityCatalog = $this->entityCatalog();
        (new RestrictedIntegrationDiagnostics())->entityCatalog($entityCatalog);
        $profileName = $this->profileName($currentProfileId);
        $isValid = $this->isCurrentContextValid($currentProfileId);

        return [
            'current_entity_id' => $currentEntityId,
            'current_entity_name' => $entityName,
            'current_entity_scope_name' => $currentEntityScopeName,
            'current_entity_value' => $currentEntityValue,
            'is_all_entities' => $isAllEntities,
            'current_profile_id' => $currentProfileId,
            'current_profile_name' => $profileName,
            'user_label' => $this->currentUserLabel(),
            'is_valid' => $isValid,
            'summary' => $isValid
                ? sprintf(I18n::translate('Consultando como %s na entidade %s.'), $profileName, $currentEntityScopeName)
                : I18n::translate('Contexto de entidade ou perfil não definido.'),
            'profiles' => $this->profileOptions(),
            'entities' => $this->entityOptions($entityCatalog),
            'entity_options_status' => !empty($entityCatalog['complete']) ? 'ready' : 'fallback',
            'entity_options_complete' => !empty($entityCatalog['complete']),
        ];
    }

    public function hasValidContext(): bool
    {
        return !empty($this->getContext()['is_valid']);
    }

    /**
     * @return array<string, mixed>
     */
    public function switchContext(int $profileId, string $entityValue, string $returnTo = ''): array
    {
        $before = [
            'profile_id' => (int) ($_SESSION['glpiactiveprofile']['id'] ?? 0),
            'entity_id' => (int) ($_SESSION['glpiactive_entity'] ?? 0),
            'all_entities' => $this->isAllEntitiesScope(),
            'recursive' => !empty($_SESSION['glpiactive_entity_recursive']),
        ];

        $profileChanged = false;
        $entitySelectionAdjusted = false;
        if ($profileId > 0 && $profileId !== $before['profile_id']) {
            $profile = $_SESSION['glpiprofiles'][$profileId] ?? null;
            if (!is_array($profile) || empty($profile['entities'])) {
                throw new \RuntimeException('Perfil inválido ou sem entidade para o usuário atual.');
            }

            $profileConfirmed = $this->contextGateway->changeProfile($profileId);
            $this->clearContextBoundSessionState();
            if (!$profileConfirmed) {
                throw new \RuntimeException('O GLPI não confirmou a troca de perfil.');
            }
            $profileChanged = true;
        }

        $entityValue = trim($entityValue);
        $scope = $this->resolveEntityScope($entityValue);
        if ($scope === null) {
            if ($profileChanged) {
                // The form listed entities from the previous profile. Keep the
                // entity selected natively by GLPI and let the next page reload
                // the valid entity options for the new profile.
                $entitySelectionAdjusted = true;
            } else {
                throw new \RuntimeException('Entidade inválida para o perfil selecionado.');
            }
        } else {
            $changed = false;
            if ($scope['entity_id'] === 'all') {
                // Use the native default. GLPI 11 forces recursion for "all";
                // GLPI 10 preserves its full-structure semantics with false.
                $changed = $this->contextGateway->changeEntity('all', false);
            } else {
                $changed = $this->contextGateway->changeEntity(
                    $scope['entity_id'],
                    $scope['recursive']
                );
            }

            $this->clearContextBoundSessionState();
            if (!$changed) {
                throw new \RuntimeException('Entidade inválida para o perfil selecionado.');
            }
        }

        $status = (new \GlpiPlugin\Glpiacessivel\Security\SessionContextGuard())->status();
        if (empty($status['session_ready'])) {
            throw new \RuntimeException('O GLPI não confirmou um contexto operacional completo.');
        }

        $after = [
            'profile_id' => (int) ($_SESSION['glpiactiveprofile']['id'] ?? 0),
            'entity_id' => (int) ($_SESSION['glpiactive_entity'] ?? 0),
            'all_entities' => $this->isAllEntitiesScope(),
            'recursive' => !empty($_SESSION['glpiactive_entity_recursive']),
        ];

        $this->clearContextBoundSessionState();
        $this->auditLogger->log('context.switch', [
            'before' => $before,
            'after' => $after,
            'profile_changed' => $profileChanged ? 1 : 0,
            'entity_selection_adjusted' => $entitySelectionAdjusted ? 1 : 0,
            'return_to_len' => strlen($returnTo),
        ]);

        $context = $this->getContext();
        $context['profile_changed'] = $profileChanged;
        $context['entity_selection_adjusted'] = $entitySelectionAdjusted;

        return $context;
    }

    /**
     * Apply a native context switch and create a one-shot marker that can only
     * be confirmed by a subsequent request using the same persisted session.
     *
     * @return array{confirmation_token:string,return_to:string,context:array<string,mixed>}
     */
    public function beginConfirmedSwitch(int $profileId, string $entityValue, string $returnTo = ''): array
    {
        $returnTo = $this->safeReturnTo($returnTo);
        $context = $this->switchContext($profileId, $entityValue, $returnTo);
        $snapshot = $this->contextGateway->snapshot();
        $token = bin2hex(random_bytes(24));
        $tokenHash = hash('sha256', $token);
        $now = time();
        $this->pruneConfirmations($now);

        $confirmations = (array) ($_SESSION[self::CONFIRMATION_SESSION_KEY] ?? []);
        $confirmations[$tokenHash] = [
            'expected_fingerprint' => $snapshot['context_fingerprint'],
            'expected_profile_id' => $snapshot['profile_id'],
            'expected_entity_value' => $snapshot['entity_value'],
            'return_to' => $returnTo,
            'profile_changed' => !empty($context['profile_changed']),
            'entity_selection_adjusted' => !empty($context['entity_selection_adjusted']),
            'expires_at' => $now + self::CONFIRMATION_TTL,
        ];
        if (count($confirmations) > self::CONFIRMATION_LIMIT) {
            $confirmations = array_slice($confirmations, -self::CONFIRMATION_LIMIT, null, true);
        }
        $_SESSION[self::CONFIRMATION_SESSION_KEY] = $confirmations;

        $this->auditLogger->log('context.switch.pending', [
            'profile_id' => $snapshot['profile_id'],
            'entity_value' => $snapshot['entity_value'],
            'confirmation_hash' => substr($tokenHash, 0, 12),
        ]);

        return [
            'confirmation_token' => $token,
            'return_to' => $returnTo,
            'context' => $context,
        ];
    }

    /**
     * @return array{confirmed:bool,return_to:string,context:array<string,mixed>,profile_changed:bool,entity_selection_adjusted:bool,error_code:string}
     */
    public function confirmContextSwitch(string $token): array
    {
        $fallback = $this->safeReturnTo('');
        if (preg_match('/^[a-f0-9]{48}$/D', $token) !== 1) {
            return $this->failedConfirmation($fallback, 'confirmation_invalid');
        }

        $now = time();
        $this->pruneConfirmations($now);
        $tokenHash = hash('sha256', $token);
        $confirmations = (array) ($_SESSION[self::CONFIRMATION_SESSION_KEY] ?? []);
        $marker = $confirmations[$tokenHash] ?? null;
        unset($confirmations[$tokenHash]);
        if ($confirmations === []) {
            unset($_SESSION[self::CONFIRMATION_SESSION_KEY]);
        } else {
            $_SESSION[self::CONFIRMATION_SESSION_KEY] = $confirmations;
        }
        if (!is_array($marker) || (int) ($marker['expires_at'] ?? 0) < $now) {
            return $this->failedConfirmation($fallback, 'confirmation_missing_or_expired');
        }

        $actual = $this->contextGateway->snapshot();
        $confirmed = hash_equals(
            (string) ($marker['expected_fingerprint'] ?? ''),
            $actual['context_fingerprint']
        );
        $returnTo = $this->safeReturnTo((string) ($marker['return_to'] ?? ''));
        $this->auditLogger->log('context.switch.confirmed', [
            'result' => $confirmed ? 'confirmed' : 'mismatch',
            'expected_profile_id' => (int) ($marker['expected_profile_id'] ?? 0),
            'actual_profile_id' => $actual['profile_id'],
            'expected_entity_value' => (string) ($marker['expected_entity_value'] ?? ''),
            'actual_entity_value' => $actual['entity_value'],
            'confirmation_hash' => substr($tokenHash, 0, 12),
        ]);

        if (!$confirmed) {
            return $this->failedConfirmation($returnTo, 'context_mismatch');
        }

        return [
            'confirmed' => true,
            'return_to' => $returnTo,
            'context' => $this->getContext(),
            'profile_changed' => !empty($marker['profile_changed']),
            'entity_selection_adjusted' => !empty($marker['entity_selection_adjusted']),
            'error_code' => 'ready',
        ];
    }

    public function commitSession(): bool
    {
        return $this->contextGateway->commit();
    }

    public function safeReturnTo(string $returnTo): string
    {
        $fallback = \GlpiPlugin\Glpiacessivel\Support\Url::plugin('front/acessivel.php');
        $returnTo = trim($returnTo);
        if ($returnTo === '' || preg_match('/[\\x00-\\x1F\\x7F]/', $returnTo) === 1) {
            return $fallback;
        }

        $parts = parse_url($returnTo);
        if (!is_array($parts)) {
            return $fallback;
        }

        foreach (['scheme', 'host', 'port', 'user', 'pass'] as $externalPart) {
            if (array_key_exists($externalPart, $parts)) {
                return $fallback;
            }
        }

        $path = (string) ($parts['path'] ?? '');
        $allowedPrefix = \GlpiPlugin\Glpiacessivel\Support\Url::plugin('front/');
        if ($path === '' || !str_starts_with($path, $allowedPrefix) || str_contains($path, '/..')) {
            return $fallback;
        }

        $query = [];
        if (isset($parts['query'])) {
            parse_str((string) $parts['query'], $query);
            foreach (
                [
                    'force_profile', 'force_entity', 'newprofile', 'active_entity',
                    'is_recursive', 'context_confirmation',
                ] as $contextParameter
            ) {
                unset($query[$contextParameter]);
            }
        }

        $safe = $path;
        if ($query !== []) {
            $safe .= '?' . http_build_query($query, '', '&', PHP_QUERY_RFC3986);
        }
        if (isset($parts['fragment']) && preg_match('/^[A-Za-z0-9._:-]+$/D', (string) $parts['fragment']) === 1) {
            $safe .= '#' . $parts['fragment'];
        }

        return $safe;
    }

    private function pruneConfirmations(int $now): void
    {
        $confirmations = (array) ($_SESSION[self::CONFIRMATION_SESSION_KEY] ?? []);
        foreach ($confirmations as $hash => $marker) {
            if (!is_array($marker) || (int) ($marker['expires_at'] ?? 0) < $now) {
                unset($confirmations[$hash]);
            }
        }
        if ($confirmations === []) {
            unset($_SESSION[self::CONFIRMATION_SESSION_KEY]);
            return;
        }
        $_SESSION[self::CONFIRMATION_SESSION_KEY] = $confirmations;
    }

    /**
     * @return array{confirmed:bool,return_to:string,context:array<string,mixed>,profile_changed:bool,entity_selection_adjusted:bool,error_code:string}
     */
    private function failedConfirmation(string $returnTo, string $errorCode): array
    {
        return [
            'confirmed' => false,
            'return_to' => $returnTo,
            'context' => $this->getContext(),
            'profile_changed' => false,
            'entity_selection_adjusted' => false,
            'error_code' => $errorCode,
        ];
    }

    /**
     * @return array<int,array{id:int,name:string}>
     */
    private function profileOptions(): array
    {
        $profiles = [];
        foreach ((array) ($_SESSION['glpiprofiles'] ?? []) as $id => $profile) {
            $id = (int) $id;
            if ($id <= 0) {
                continue;
            }

            $profiles[] = [
                'id' => $id,
                'name' => $this->profileName($id, is_array($profile) ? $profile : []),
            ];
        }

        usort($profiles, static fn (array $a, array $b): int => strcasecmp($a['name'], $b['name']));

        return $profiles;
    }

    /**
     * @return array<string,array{id:int|string,value:string,name:string,recursive:bool,has_recursive_alternative:bool}>
     */
    private function entityOptions(?array $entityCatalog = null): array
    {
        $entities = [];
        $entityCatalog = $entityCatalog ?? $this->entityCatalog();

        if (empty($entityCatalog['complete'])) {
            if ($this->isAllEntitiesScope()) {
                return [
                    'all' => [
                        'id' => 'all',
                        'value' => 'all',
                        'name' => I18n::translate('Todas as entidades permitidas'),
                        'recursive' => true,
                        'has_recursive_alternative' => false,
                    ],
                ];
            }

            $activeId = (int) ($_SESSION['glpiactive_entity'] ?? 0);
            $recursive = !empty($_SESSION['glpiactive_entity_recursive']);
            $value = $this->entityScopeValue($activeId, $recursive);
            return [
                $value => [
                    'id' => $activeId,
                    'value' => $value,
                    'name' => $this->currentEntityName($activeId)
                        . ($recursive ? I18n::translate(' (árvore)') : ''),
                    'recursive' => $recursive,
                    'has_recursive_alternative' => false,
                ],
            ];
        }

        if ($this->isAllEntitiesScope() || $this->catalogEntityCount($entityCatalog) > 1) {
            $entities['all'] = [
                'id' => 'all',
                'value' => 'all',
                'name' => I18n::translate('Todas as entidades permitidas'),
                'recursive' => true,
                'has_recursive_alternative' => false,
            ];
        }

        foreach ((array) ($entityCatalog['nodes'] ?? []) as $node) {
            if (!is_array($node)) {
                continue;
            }
            $id = (int) ($node['id'] ?? -1);
            if ($id < 0) {
                continue;
            }
            $path = array_values(array_filter(
                array_map('strval', (array) ($node['path'] ?? [])),
                static fn (string $part): bool => trim($part) !== ''
            ));
            $name = $path !== []
                ? implode(' > ', $path)
                : trim((string) ($node['name'] ?? ''));
            if ($name === '') {
                $name = $this->entityName($id);
            }
            $hasChildren = !empty($node['has_children']);
            $directValue = $this->entityScopeValue($id, false);
            $entities[$directValue] = [
                'id' => $id,
                'value' => $directValue,
                'name' => $name,
                'recursive' => false,
                'has_recursive_alternative' => $hasChildren,
            ];
            if ($hasChildren || $this->isCurrentRecursiveEntity($id)) {
                $treeValue = $this->entityScopeValue($id, true);
                $entities[$treeValue] = [
                    'id' => $id,
                    'value' => $treeValue,
                    'name' => $name . I18n::translate(' (árvore)'),
                    'recursive' => true,
                    'has_recursive_alternative' => $hasChildren,
                ];
            }
        }

        return $entities;
    }

    /** @return array{entity_id:int|string,recursive:bool}|null */
    private function resolveEntityScope(string $entityValue): ?array
    {
        $entityValue = trim($entityValue);
        if ($entityValue === '' || $entityValue === 'current') {
            if ($this->isAllEntitiesScope()) {
                return ['entity_id' => 'all', 'recursive' => false];
            }

            return [
                'entity_id' => max(0, (int) ($_SESSION['glpiactive_entity'] ?? 0)),
                'recursive' => !empty($_SESSION['glpiactive_entity_recursive']),
            ];
        }

        $entityCatalog = $this->entityCatalog();
        if ($entityValue === 'all') {
            return ($this->isAllEntitiesScope()
                || (!empty($entityCatalog['complete']) && $this->catalogEntityCount($entityCatalog) > 1))
                ? ['entity_id' => 'all', 'recursive' => false]
                : null;
        }

        $scopeMap = $this->allowedEntityScopeMap($entityCatalog);
        if (isset($scopeMap[$entityValue])) {
            return $scopeMap[$entityValue];
        }

        // Transitional compatibility for a form rendered before this release.
        // Legacy numeric values are resolved on the server to the same scope
        // previously exposed: recursive when the native node has children,
        // direct otherwise. They are never emitted by the new interface.
        if (preg_match('/^\d+$/D', $entityValue) !== 1) {
            return null;
        }
        $entityId = (int) $entityValue;
        $treeValue = $this->entityScopeValue($entityId, true);
        if (isset($scopeMap[$treeValue])) {
            return $scopeMap[$treeValue];
        }
        $directValue = $this->entityScopeValue($entityId, false);

        return $scopeMap[$directValue] ?? null;
    }

    /** @return array<string,array{entity_id:int,recursive:bool}> */
    private function allowedEntityScopeMap(?array $entityCatalog = null): array
    {
        $entityCatalog = $entityCatalog ?? $this->entityCatalog();
        if (empty($entityCatalog['complete'])) {
            if ($this->isAllEntitiesScope()) {
                return [];
            }

            $activeId = (int) ($_SESSION['glpiactive_entity'] ?? 0);
            $recursive = !empty($_SESSION['glpiactive_entity_recursive']);
            $value = $this->entityScopeValue($activeId, $recursive);
            return [
                $value => ['entity_id' => $activeId, 'recursive' => $recursive],
            ];
        }

        $scopes = [];
        foreach ((array) ($entityCatalog['nodes'] ?? []) as $node) {
            if (!is_array($node)) {
                continue;
            }
            $entityId = (int) ($node['id'] ?? -1);
            if ($entityId < 0) {
                continue;
            }
            $directValue = $this->entityScopeValue($entityId, false);
            $scopes[$directValue] = ['entity_id' => $entityId, 'recursive' => false];
            if (!empty($node['has_children']) || $this->isCurrentRecursiveEntity($entityId)) {
                $treeValue = $this->entityScopeValue($entityId, true);
                $scopes[$treeValue] = ['entity_id' => $entityId, 'recursive' => true];
            }
        }

        return $scopes;
    }

    private function entityScopeValue(int $entityId, bool $recursive): string
    {
        return ($recursive ? self::ENTITY_SCOPE_TREE_PREFIX : self::ENTITY_SCOPE_DIRECT_PREFIX)
            . max(0, $entityId);
    }

    /** Preserve a native leaf context without offering new recursive leaf scopes. */
    private function isCurrentRecursiveEntity(int $entityId): bool
    {
        return (int) ($_SESSION['glpiactive_entity'] ?? -1) === $entityId
            && !empty($_SESSION['glpiactive_entity_recursive'])
            && !$this->isAllEntitiesScope();
    }

    /** @param array<string,mixed> $entityCatalog */
    private function catalogEntityCount(array $entityCatalog): int
    {
        $ids = [];
        foreach ((array) ($entityCatalog['nodes'] ?? []) as $node) {
            if (!is_array($node)) {
                continue;
            }
            $entityId = (int) ($node['id'] ?? -1);
            if ($entityId >= 0) {
                $ids[$entityId] = true;
            }
        }

        return count($ids);
    }

    /**
     * @return array{
     *   complete:bool,
     *   source:string,
     *   reason_code:string,
     *   nodes:array<int,array{
     *     id:int,name:string,path:array<int,string>,depth:int,has_children:bool
     *   }>
     * }
     */
    private function entityCatalog(): array
    {
        $catalog = $this->contextGateway->availableEntityCatalog();
        if (empty($catalog['complete']) || $this->isAllEntitiesScope()) {
            return $catalog;
        }

        $activeId = (int) ($_SESSION['glpiactive_entity'] ?? 0);
        foreach ((array) ($catalog['nodes'] ?? []) as $node) {
            if (is_array($node) && (int) ($node['id'] ?? -1) === $activeId) {
                return $catalog;
            }
        }

        return [
            'complete' => false,
            'source' => 'unavailable',
            'reason_code' => !empty($_SESSION['glpiactive_entity_recursive'])
                ? 'active_entity_scope_missing_from_catalog'
                : 'active_entity_missing_from_catalog',
            'nodes' => [],
        ];
    }

    private function clearContextBoundSessionState(): void
    {
        foreach (
            [
            'glpiacessivel_chatbot_context',
            'glpiacessivel_chatbot_conversation_id',
            'glpiacessivel_ticket_critical_confirmations',
            'glpiacessivel_playbook_critical_confirmations',
            'glpiacessivel_pii_reveal',
            'glpiacessivel_ticket_search_states_v2',
            'glpiacessivel_ticket_list_states_v1',
            'glpiacessivel_mass_actions_v1',
            'glpiacessivel_resource_selector_cursor_key',
            'glpiacessivel_saved_search_cursor_key',
            'glpiacessivel_advanced_search_error_v2',
            ] as $key
        ) {
            unset($_SESSION[$key]);
        }
    }

    private function isCurrentContextValid(int $currentProfileId): bool
    {
        if ($currentProfileId <= 0) {
            return false;
        }

        if (!isset($_SESSION['glpiactive_entity']) && !$this->isAllEntitiesScope()) {
            return false;
        }

        return true;
    }

    private function isAllEntitiesScope(): bool
    {
        return $this->contextGateway->isFullStructure();
    }

    private function profileName(int $profileId, array $profileData = []): string
    {
        $name = trim((string) ($profileData['name'] ?? ''));
        if ($name !== '') {
            return $name;
        }

        if ($profileId > 0 && class_exists('\Profile')) {
            $profile = new \Profile();
            if ($profile->getFromDB($profileId)) {
                return (string) ($profile->fields['name'] ?? ('Perfil ' . $profileId));
            }
        }

        return $profileId > 0 ? ('Perfil ' . $profileId) : 'Perfil atual';
    }

    private function currentEntityName(int $entityId): string
    {
        $name = TextNormalizer::fromGlpi(
            (string) ($_SESSION['glpiactive_entity_name'] ?? '')
        );
        if ($name !== '') {
            return $name;
        }

        return $this->entityName($entityId);
    }

    private function entityName(int $entityId): string
    {
        if (class_exists('\Dropdown')) {
            $name = TextNormalizer::fromGlpi((string) \Dropdown::getDropdownName('glpi_entities', $entityId));
            if (trim($name) !== '') {
                return $name;
            }
        }

        if (class_exists('\Entity')) {
            $entity = new \Entity();
            if ($entity->getFromDB($entityId)) {
                $rawName = (string) ($entity->fields['completename']
                    ?? $entity->fields['name']
                    ?? ('Entidade ' . $entityId));
                return TextNormalizer::fromGlpi($rawName);
            }
        }

        return $entityId === 0 ? 'Entidade raiz' : ('Entidade ' . $entityId);
    }

    private function currentUserLabel(): string
    {
        $login = trim(TextNormalizer::fromGlpi((string) ($_SESSION['glpiname'] ?? '')));
        $firstName = trim(TextNormalizer::fromGlpi((string) ($_SESSION['glpifirstname'] ?? '')));

        if ($firstName !== '' && $login !== '') {
            return $login . ' — ' . $firstName;
        }

        if ($login !== '') {
            return $login;
        }

        if ($firstName !== '') {
            return $firstName;
        }

        return function_exists('__') ? \__('Usuário atual', 'glpiacessivel') : 'Usuário atual';
    }
}
