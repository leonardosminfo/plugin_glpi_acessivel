<?php

declare(strict_types=1);

namespace GlpiPlugin\Glpiacessivel\Application;

use GlpiPlugin\Glpiacessivel\Support\Bootstrap;
use GlpiPlugin\Glpiacessivel\Support\TextNormalizer;
use GlpiPlugin\Glpiacessivel\Infrastructure\Audit\AuditRights;

/** Read-only, request-local documentation discovery. Never authorizes an operation. */
final class ManualAvailabilitySnapshot
{
    /** @var array<string,\Closure> */
    private array $readers;
    /** @var array<string,mixed> */
    private array $cache = [];

    /** Public read-only seams keep tests independent of a running GLPI. */
    public function __construct(array $readers = [])
    {
        $defaults = [
            'context' => static fn(): bool => is_callable(['Session', 'getLoginUserID'])
                && (int) \Session::getLoginUserID() > 0
                && (int) ($_SESSION['glpiactiveprofile']['id'] ?? 0) > 0
                && in_array($_SESSION['glpiactiveprofile']['interface'] ?? '', ['central', 'helpdesk'], true)
                && isset($_SESSION['glpiactive_entity']) && empty($_SESSION['glpi_password_expired']),
            'storage' => static fn(): bool => Bootstrap::configStorageAvailable(),
            'module' => static fn(string $module): string => (new PortalModulePolicy(new ConfigService()))->getEffectiveState($module),
            'feature' => static fn(string $feature): array => FeatureReleasePolicy::evaluate($feature),
            'right' => static function (string $name, array $masks): ?bool {
                if (!is_callable(['Session', 'haveRight']) || $masks === []) {
                    return null;
                }
                foreach ($masks as $mask) {
                    if (\Session::haveRight($name, $mask)) {
                        return true;
                    }
                }
                return false;
            },
            'version' => static fn(): string => defined('GLPI_VERSION') ? (string) GLPI_VERSION : '',
            'interface' => static fn(): mixed => $_SESSION['glpiactiveprofile']['interface'] ?? null,
            // Session labels only: no entity catalog or operational context recovery.
            'identity' => static fn(): array => [
                'profile' => $_SESSION['glpiactiveprofile']['name'] ?? null,
                'entity' => $_SESSION['glpiactive_entity_name'] ?? null,
                'all_entities' => ($_SESSION['glpiactive_entity'] ?? null) === 'all'
                    || in_array($_SESSION['glpientity_fullstructure'] ?? null, [true, 1, '1'], true),
                'recursive' => $_SESSION['glpiactive_entity_recursive'] ?? null,
                'active_entities' => $_SESSION['glpiactiveentities'] ?? null,
            ],
            'statistics' => static fn(): bool => is_callable(['Stat', 'getItems']) && is_callable(['Stat', 'getData']),
            // No Search discovery: metadata alone cannot certify the Tag Search contract.
            'tag' => static function (): array {
                if (!is_callable(['Plugin', 'isPluginActive'])) {
                    return ['state' => 'unknown'];
                }
                if (!(bool) call_user_func(['Plugin', 'isPluginActive'], 'tag')) {
                    return ['state' => 'unsupported'];
                }
                return ['state' => 'unknown'];
            },
            'forms' => static function (): ?bool {
                if (class_exists('Glpi\\Form\\ServiceCatalog\\ServiceCatalog')) {
                    return null; // Per-form access is intentionally not probed by documentation.
                }
                if (!is_callable(['Plugin', 'isPluginActive'])) {
                    return null;
                }
                return (bool) call_user_func(['Plugin', 'isPluginActive'], 'formcreator') ? null : false;
            },
        ];
        foreach ($defaults as $name => $reader) {
            $this->readers[$name] = \Closure::fromCallable($readers[$name] ?? $reader);
        }
    }

    /** @return string[] */
    public static function rules(): array
    {
        return array_merge(['always', 'tickets_read', 'tickets_create', 'forms', 'knowledge',
            'cockpit', 'chatbot', 'administration', 'audit_read', 'audit_export', 'playbooks_manage'], array_keys(FeatureReleaseCatalog::all()));
    }

    /** Labels describe this opening only. They never grant access or change session state.
     * @return array{confirmed:bool,profile:string,entity:string,scope:string,glpi_version:string}
     */
    public function readingContext(): array
    {
        if (isset($this->cache['reading-context'])) {
            return $this->cache['reading-context'];
        }
        $result = ['confirmed' => false, 'profile' => '', 'entity' => '', 'scope' => '',
            'glpi_version' => self::label($this->read('version'))];
        if ($this->read('context') !== true) {
            return $this->cache['reading-context'] = $result;
        }
        $identity = $this->read('identity');
        if (!is_array($identity)) {
            return $this->cache['reading-context'] = $result;
        }
        $result['confirmed'] = true;
        $result['profile'] = self::label($identity['profile'] ?? null);
        $result['entity'] = self::label($identity['entity'] ?? null);
        if (($identity['all_entities'] ?? null) === true) {
            $result['scope'] = 'Todas as entidades permitidas';
        } elseif (in_array($identity['recursive'] ?? null, [true, 1, '1'], true)) {
            $result['scope'] = 'Inclui subentidades autorizadas';
        } elseif (in_array($identity['recursive'] ?? null, [false, 0, '0'], true)) {
            $entities = [];
            foreach (is_array($identity['active_entities'] ?? null) ? $identity['active_entities'] : [] as $key => $value) {
                $candidate = is_numeric($value) ? (int) $value : (is_numeric($key) ? (int) $key : -1);
                if ($candidate >= 0) {
                    $entities[$candidate] = true;
                }
            }
            // GLPI 10 can represent "all" as a non-recursive effective union.
            // Without its authorized catalog, multiple active IDs do not prove "all".
            $result['scope'] = match (true) {
                count($entities) > 1 => 'Múltiplas entidades autorizadas ativas; alcance total não confirmado',
                count($entities) === 1 => 'Somente esta entidade',
                default => '',
            };
        }
        return $this->cache['reading-context'] = $result;
    }

    private static function label(mixed $value): string
    {
        if (!is_string($value) || strlen($value) > 4000 || preg_match('/[\x00-\x08\x0b\x0c\x0e-\x1f\x7f]/', $value) === 1) {
            return '';
        }
        return TextNormalizer::fromGlpi($value);
    }

    /** @return array{state:string,message:string} */
    public function evaluate(string $rule): array
    {
        $key = 'rule:' . $rule;
        if (isset($this->cache[$key])) {
            return $this->cache[$key];
        }
        if (!in_array($rule, self::rules(), true)) {
            return $this->cache[$key] = self::state('unknown');
        }
        if ($rule === 'always') {
            return $this->cache[$key] = self::state('available');
        }
        try {
            if ($this->read('context') !== true) {
                return $this->cache[$key] = self::state('unknown');
            }
            return $this->cache[$key] = $this->resolve($rule);
        } catch (\Throwable) {
            return $this->cache[$key] = self::state('unknown');
        }
    }

    private function resolve(string $rule): array
    {
        $features = FeatureReleaseCatalog::all();
        if (isset($features[$rule])) {
            $checks = [$this->feature($rule)];
            $module = $features[$rule]['module'];
            if ($module !== '') {
                $checks[] = $this->module($module);
            }
            if (str_starts_with($rule, 'playbooks.')) {
                $checks[] = $this->base('playbooks_manage');
            } elseif (str_starts_with($rule, 'reports.')) {
                $checks[] = $this->right('statistic', ['READ']);
                $checks[] = $this->ticketRead();
                $statistics = $this->read('statistics');
                $checks[] = self::state($statistics === true ? 'available' : ($statistics === false ? 'unsupported' : 'unknown'));
                $version = (string) $this->read('version');
                $checks[] = self::state(preg_match('/\A(?:10|11)\.\d+\.\d+(?:[-+][\w.-]+)?\z/D', $version) === 1
                    ? 'available' : 'unsupported');
            } elseif ($rule === 'tickets.clipboard_images') {
                $checks[] = $this->combine([$this->base('tickets_read'), $this->base('tickets_create')], true);
            } else {
                $checks[] = $this->ticketRead();
            }
            if ($rule === 'tickets.interaction_rich_edit') {
                $checks[] = $this->feature('tickets.interaction_edit');
            }
            if ($rule === 'presentation_simple_mode') {
                // Documentation follows the presentation gate and the same supported
                // GLPI families, without reading or changing a user preference.
                $checks[] = self::state(preg_match('/\A(?:10|11)\.\d+\.\d+(?:[-+][\w.-]+)?\z/D', (string) $this->read('version')) === 1
                    ? 'available' : 'unsupported');
            }
            if (in_array($rule, ['tickets.interaction_rich_edit', 'tickets.interaction_rich_add'], true)) {
                $checks[] = self::state(preg_match('/\A(?:10|11)\.\d+\.\d+(?:[-+][\w.-]+)?\z/D', (string) $this->read('version')) === 1
                    ? 'available' : 'unsupported');
            }
            if (in_array($rule, ['tickets.mass_status', 'tickets.mass_participants', 'tickets.interaction_edit', 'tickets.interaction_rich_edit', 'tickets.interaction_rich_add'], true)) {
                // Item ownership, native massive-action catalogs and plugins can change
                // write eligibility. A general READ right cannot prove it, nor can an
                // absent global UPDATE right disprove rights on an owned interaction.
                $checks[] = self::state('unknown');
            }
            if (str_starts_with($rule, 'tickets.tags_')) {
                $checks[] = $this->right('plugin_tag_tag', [$rule === 'tickets.tags_edit' ? 'UPDATE' : 'READ']);
                if ($rule === 'tickets.tags_edit') {
                    $checks[] = $this->feature('tickets.tags_view');
                    $checks[] = $this->right('plugin_tag_tag', ['READ']);
                    $ticketUpdate = $this->right('ticket', ['UPDATE']);
                    // A per-ticket UPDATE check is intentionally deferred to the native continuation.
                    $checks[] = $ticketUpdate['state'] === 'available' ? $ticketUpdate : self::state('unknown');
                }
                $metadata = $this->read('tag');
                $checks[] = self::state(is_array($metadata) && ($metadata['state'] ?? '') === 'unsupported'
                    ? 'unsupported' : 'unknown');
            }
            return $this->combine($checks);
        }
        return $this->base($rule);
    }

    private function base(string $rule): array
    {
        return match ($rule) {
            'tickets_read' => $this->combine([$this->module('tickets'), $this->ticketRead()]),
            'tickets_create' => $this->combine([$this->module('ticket_create'), $this->right('ticket', ['CREATE'])]),
            'knowledge' => $this->combine([$this->module('knowledge'), $this->right('knowbase', ['READ', 'KnowbaseItem::READFAQ'])]),
            'cockpit' => $this->combine([$this->module('cockpit'), $this->ticketRead()]),
            'administration' => $this->right('config', ['UPDATE']),
            'audit_read' => $this->right(AuditRights::READ, ['READ']),
            'audit_export' => $this->combine([$this->right(AuditRights::READ, ['READ']),
                $this->right(AuditRights::EXPORT, ['READ'])]),
            'playbooks_manage' => $this->combine([$this->module('playbooks'),
                $this->right('config', ['UPDATE']), $this->right('knowbase', ['READ']),
                $this->right('knowbase', ['KnowbaseItem::KNOWBASEADMIN']),
                self::state(
                    match ($this->read('interface')) {
                    'central' => 'available',
                    'helpdesk' => 'denied',
                    default => 'unknown',
                    }
                )]),
            'forms' => $this->combine([$this->module('forms'), self::state($this->read('forms') === false ? 'unsupported' : 'unknown')]),
            'chatbot' => $this->combine([$this->module('chatbot'), $this->combine([
                $this->ticketRead(), $this->right('ticket', ['CREATE']),
                $this->right('knowbase', ['READ', 'KnowbaseItem::READFAQ']),
                self::state($this->read('forms') === false ? 'unsupported' : 'unknown'),
            ], true)]),
            default => self::state('unknown'),
        };
    }

    private function ticketRead(): array
    {
        return $this->right('ticket', ['READ', 'Ticket::READMY', 'Ticket::READALL',
            'Ticket::READGROUP', 'Ticket::READASSIGN', 'Ticket::READNEWTICKET']);
    }

    /** @param string[] $constants */
    private function right(string $name, array $constants): array
    {
        $masks = [];
        foreach ($constants as $constant) {
            if (defined($constant)) {
                $masks[] = (int) constant($constant);
            }
        }
        $result = $this->read('right', $name, array_values(array_unique($masks)));
        return self::state($result === true ? 'available' : ($result === false ? 'denied' : 'unknown'));
    }

    private function module(string $module): array
    {
        if ($this->read('storage') !== true) {
            return self::state('unknown');
        }
        return self::state(match ($this->read('module', $module)) {
            ConfigService::MODULE_STATE_AVAILABLE => 'available',
            ConfigService::MODULE_STATE_HIDDEN => 'hidden',
            ConfigService::MODULE_STATE_DISABLED => 'disabled',
            default => 'unknown',
        });
    }

    private function feature(string $feature): array
    {
        if ($this->read('storage') !== true) {
            return self::state('unknown');
        }
        $decision = $this->read('feature', $feature);
        return self::state(match (is_array($decision) ? ($decision['reason'] ?? '') : '') {
            'allowed' => 'available',
            'feature_disabled', 'module_disabled' => 'disabled',
            'profile_excluded' => 'excluded',
            default => 'unknown',
        });
    }

    private function read(string $name, mixed ...$arguments): mixed
    {
        $key = 'read:' . $name . ':' . serialize($arguments);
        if (!array_key_exists($key, $this->cache)) {
            try {
                $this->cache[$key] = ($this->readers[$name])(...$arguments);
            } catch (\Throwable) {
                $this->cache[$key] = null;
            }
        }
        return $this->cache[$key];
    }

    private function combine(array $checks, bool $any = false): array
    {
        $states = array_column($checks, 'state');
        if ($any) {
            if (in_array('available', $states, true)) {
                return self::state('available');
            }
            if (in_array('unknown', $states, true)) {
                return self::state('unknown');
            }
            foreach (['disabled', 'excluded', 'denied', 'hidden', 'unsupported'] as $state) {
                if (in_array($state, $states, true)) {
                    return self::state($state);
                }
            }
            return self::state('unknown');
        }
        foreach (['disabled', 'excluded', 'denied', 'hidden', 'unsupported', 'unknown'] as $state) {
            if (in_array($state, $states, true)) {
                return self::state($state);
            }
        }
        return self::state('available');
    }

    private static function state(string $state): array
    {
        return ['state' => $state, 'message' => match ($state) {
            'available' => 'Disponível em caráter geral para o perfil ativo. Cada operação continua sujeita às permissões e condições do GLPI.',
            'disabled' => 'Esta funcionalidade está desativada neste ambiente.',
            'excluded' => 'Esta funcionalidade não foi liberada para seu perfil ativo.',
            'denied' => 'O perfil ativo não possui a permissão geral necessária para esta funcionalidade.',
            'hidden' => 'Este módulo não está apresentado na navegação do perfil atual.',
            'unsupported' => 'A dependência desta funcionalidade não está disponível ou é incompatível neste ambiente.',
            default => 'Não foi possível confirmar a disponibilidade nesta leitura. Consulte o manual completo; a tela da funcionalidade fará a validação nativa.',
        }];
    }
}
