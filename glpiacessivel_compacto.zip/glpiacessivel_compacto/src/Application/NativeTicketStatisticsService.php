<?php

declare(strict_types=1);

namespace GlpiPlugin\Glpiacessivel\Application;

use GlpiPlugin\Glpiacessivel\Infrastructure\Statistics\GlpiNativeStatisticsGateway;

/** Validates and paginates native rows, but never calculates a statistic. */
final class NativeTicketStatisticsService
{
    private NativeTicketStatisticsGateway $gateway;

    public function __construct(?NativeTicketStatisticsGateway $gateway = null)
    {
        $this->gateway = $gateway ?? new GlpiNativeStatisticsGateway();
    }

    public function capabilities(): array
    {
        return $this->gateway->capabilities();
    }

    /** Same calendar-year default as stat.tracking.php on both examined generations. */
    public function defaults(): array
    {
        return ['mode' => 'assigned', 'date1' => date('Y-m-d', mktime(
            1,
            0,
            0,
            (int) date('m'),
            (int) date('d'),
            (int) date('Y') - 1
        )),
            'date2' => date('Y-m-d'), 'start' => 0];
    }

    /** Throws on any incomplete page; no partial success, synthetic zero or row total of tickets. */
    public function query(array $input, string $contextRevision): array
    {
        $mode = $input['mode'] ?? 'assigned';
        if ($mode !== 'assigned') {
            throw new NativeTicketStatisticsException('native_statistics_mode_unsupported', 'mode');
        }
        foreach (['date1', 'date2'] as $field) {
            if (!is_string($input[$field] ?? null) || !$this->validDate($input[$field])) {
                throw new NativeTicketStatisticsException('native_statistics_date_invalid', $field);
            }
        }
        if ($input['date1'] > $input['date2']) {
            throw new NativeTicketStatisticsException('native_statistics_period_invalid', 'date2');
        }
        $start = $input['start'] ?? 0;
        if (is_string($start) && preg_match('/\A(?:0|[1-9][0-9]{0,8})\z/D', $start) === 1) {
            $start = (int) $start;
        }
        if (!is_int($start) || $start < 0 || $start > 999999999) {
            throw new NativeTicketStatisticsException('native_statistics_offset_invalid', 'start');
        }
        if ($contextRevision === '') {
            throw new NativeTicketStatisticsException('native_statistics_context_invalid');
        }
        $context = $this->gateway->context();
        $pageSize = $this->gateway->pageSize();
        if ($start % $pageSize !== 0) {
            throw new NativeTicketStatisticsException('native_statistics_offset_invalid', 'start');
        }
        $begin = microtime(true);
        $items = $this->gateway->items($mode, $input['date1'], $input['date2']);
        $discovered = microtime(true);
        $identities = [];
        foreach ($items as $item) {
            $id = is_array($item) && array_key_exists('id', $item) ? $item['id'] : false;
            if (
                is_string($id) && preg_match('/\A(?:0|[1-9][0-9]*)\z/D', $id) === 1
                && strlen($id) <= strlen((string) PHP_INT_MAX)
                && (strlen($id) < strlen((string) PHP_INT_MAX) || strcmp($id, (string) PHP_INT_MAX) <= 0)
            ) {
                $id = (int) $id;
            }
            if (
                (!is_int($id) && $id !== null) || (is_int($id) && $id < 0)
                || !is_array($item) || !isset($item['link']) || !is_string($item['link'])
            ) {
                throw new NativeTicketStatisticsException('native_statistics_response_invalid');
            }
            $key = $id === null ? 'unassigned' : 'user:' . $id;
            if (isset($identities[$key])) {
                throw new NativeTicketStatisticsException('native_statistics_response_invalid');
            }
            $identities[$key] = true;
        }
        $total = count($items);
        if ($start > 0 && $start >= $total) {
            throw new NativeTicketStatisticsException('native_statistics_offset_invalid', 'start');
        }
        $rows = [];
        foreach (array_slice(array_values($items), $start, $pageSize) as $item) {
            $this->assertContext($context);
            $data = $this->gateway->data($mode, $input['date1'], $input['date2'], $item);
            $row = ['id' => $item['id'] === null ? null : (int) $item['id'],
                'label' => html_entity_decode(strip_tags($item['link']), ENT_QUOTES | ENT_HTML5, 'UTF-8')];
            if (trim($row['label']) === '') {
                if ($row['id'] !== null && $row['id'] !== 0) {
                    throw new NativeTicketStatisticsException('native_statistics_response_invalid');
                }
                $row['label'] = __('Sem técnico atribuído', 'glpiacessivel');
            }
            foreach (['opened', 'solved', 'late', 'closed'] as $indicator) {
                if (
                    !isset($data[$indicator]) || !is_array($data[$indicator])
                    || count($data[$indicator]) !== 1 || !array_key_exists($item['link'], $data[$indicator])
                ) {
                    throw new NativeTicketStatisticsException('native_statistics_response_invalid');
                }
                $value = $data[$indicator][$item['link']];
                if (!is_int($value) || $value < 0) {
                    throw new NativeTicketStatisticsException('native_statistics_response_invalid');
                }
                $row[$indicator] = $value;
            }
            $rows[] = $row;
        }
        $this->assertContext($context);
        return ['mode' => $mode, 'date1' => $input['date1'], 'date2' => $input['date2'],
            'start' => $start, 'page_size' => $pageSize, 'total_rows' => $total, 'rows' => $rows,
            'complete' => true, 'context_revision' => $contextRevision,
            'timings' => ['discovery_ms' => round(($discovered - $begin) * 1000, 2),
                'calculation_ms' => round((microtime(true) - $discovered) * 1000, 2),
                'items_calls' => 1, 'data_calls' => count($rows)]];
    }

    private function assertContext(array $expected): void
    {
        if ($this->gateway->context() !== $expected) {
            throw new NativeTicketStatisticsException('native_statistics_context_changed');
        }
    }

    private function validDate(string $value): bool
    {
        if (preg_match('/\A\d{4}-\d{2}-\d{2}\z/D', $value) !== 1) {
            return false;
        }
        $date = \DateTimeImmutable::createFromFormat('!Y-m-d', $value);
        return $date !== false && $date->format('Y-m-d') === $value && substr($value, 0, 4) !== '0000';
    }
}
