<?php

declare(strict_types=1);

namespace GlpiPlugin\Glpiacessivel\Application;

/** Bounded read-only input. A context revision detects stale forms; it grants no rights. */
final class NativeStatisticsRequest
{
    public static function parse(array $input, array $defaults, string $contextRevision): array
    {
        $filters = $defaults;
        $errors = [];
        $allowed = ['mode', 'date1', 'date2', 'start', 'consult', 'context_revision'];
        if (array_diff(array_keys($input), $allowed) !== []) {
            $errors['request'] = 'invalid_request';
        }
        foreach ($input as $key => $value) {
            if (!is_string($value) || strlen($value) > 128) {
                $errors[in_array($key, ['mode', 'date1', 'date2', 'start'], true) ? $key : 'request'] = 'invalid_request';
            }
        }
        foreach (['mode', 'date1', 'date2', 'start'] as $key) {
            if (isset($input[$key]) && is_string($input[$key]) && strlen($input[$key]) <= 128) {
                $filters[$key] = $input[$key];
            }
        }
        $consult = array_key_exists('consult', $input);
        if ($consult && ($input['consult'] ?? null) !== '1') {
            $errors['request'] = 'invalid_request';
        }
        if (
            $consult && (
            !is_string($input['context_revision'] ?? null)
            || !hash_equals($contextRevision, $input['context_revision'])
            )
        ) {
            $errors['context_revision'] = 'context_changed';
        }
        // An old result URL without explicit submission must never start a calculation.
        return ['filters' => $filters, 'consult' => $consult, 'errors' => $errors];
    }
}
