<?php

declare(strict_types=1);

namespace GlpiPlugin\Glpiacessivel\Application;

use GlpiPlugin\Glpiacessivel\UI\Presenter\TicketTagColorPresenter;

/** Read presentation only; ticket actions never depend on this optional service. */
final class TicketTagsService
{
    private \Closure $released;

    public function __construct(private TicketTagsGateway $gateway, ?callable $released = null)
    {
        $this->released = $released === null
            ? static fn(string $feature): bool => FeatureReleasePolicy::allows($feature)
            : \Closure::fromCallable($released);
    }

    /** @return array<string,mixed> */
    public function forTicket(int $ticketId): array
    {
        $model = ['state' => 'disabled', 'items' => [], 'reason' => '', 'message' => '',
            'native_url' => '', 'edit_available' => false];
        try {
            // Do not load or call the third-party plugin when this feature is off.
            if ($ticketId < 1 || !($this->released)('tickets.tags_view')) {
                return $model;
            }
            $capability = $this->gateway->inspect($ticketId);
            $state = (string) ($capability['state'] ?? 'unsupported');
            if (in_array($state, ['absent', 'denied'], true)) {
                $model['state'] = $state;
                return $model;
            }
            if ($state !== 'ready') {
                $model['state'] = 'unavailable';
                $model['reason'] = 'tag_contract_unavailable';
                // phpcs:ignore Generic.Files.LineLength -- Keep the translated message as one extraction literal.
                $model['message'] = __('A integração de etiquetas não está disponível nesta combinação de versões. As demais ações do chamado continuam disponíveis.', 'glpiacessivel');
                return $model;
            }
            $nativeUrl = (string) ($capability['native_url'] ?? '');
            $nativeEdit = ($capability['can_edit'] ?? false) === true && ($this->released)('tickets.tags_edit');
            // A native continuation is not an accessible local edit form.
            $model['native_url'] = $nativeEdit ? $nativeUrl : '';
            $model['native_edit_available'] = $nativeEdit;
            $rows = $this->gateway->read($ticketId);
            if (count($rows) > 100) {
                throw new \UnexpectedValueException('tag_result_too_large');
            }
            $items = [];
            $names = [];
            $colors = new TicketTagColorPresenter();
            foreach ($rows as $row) {
                if (
                    !is_array($row) || !is_int($row['id'] ?? null) || $row['id'] < 1
                    || !is_string($row['name'] ?? null) || trim($row['name']) === ''
                    || strlen($row['name']) > 4096 || isset($items[$row['id']])
                ) {
                    throw new \UnexpectedValueException('tag_result_invalid');
                }
                $name = $row['name'];
                $color = $colors->present($row['color'] ?? null);
                $items[$row['id']] = ['id' => $row['id'], 'name' => $name,
                    'color_available' => $color['state'] === 'native',
                    'color' => $color['state'] === 'native' ? $color['background_color'] : null,
                    'foreground' => $color['state'] === 'native' ? $color['text_color'] : null];
                $names[$name] = ($names[$name] ?? 0) + 1;
            }
            foreach ($items as &$item) {
                if ($names[$item['name']] > 1) {
                    $item['name'] = sprintf(__('%s — etiqueta #%d', 'glpiacessivel'), $item['name'], $item['id']);
                }
            }
            unset($item);
            $model['state'] = 'ready';
            $model['items'] = array_values($items);
            if (array_filter($items, static fn(array $item): bool => !$item['color_available']) !== []) {
                // phpcs:ignore Generic.Files.LineLength -- Keep the translated message as one extraction literal.
                $model['message'] = __('A cor original de uma ou mais etiquetas está indisponível. Seus nomes foram preservados em uma apresentação neutra.', 'glpiacessivel');
            }
            return $model;
        } catch (\Throwable) {
            // No partial result, no fabricated empty list, no retry or business write.
            $model['state'] = 'unavailable';
            $model['items'] = [];
            $model['reason'] = 'tag_read_unavailable';
            // phpcs:ignore Generic.Files.LineLength -- Keep the translated message as one extraction literal.
            $model['message'] = __('Não foi possível consultar as etiquetas deste chamado. Isso não significa que ele esteja sem etiquetas. As demais ações continuam disponíveis.', 'glpiacessivel');
            return $model;
        }
    }
}
