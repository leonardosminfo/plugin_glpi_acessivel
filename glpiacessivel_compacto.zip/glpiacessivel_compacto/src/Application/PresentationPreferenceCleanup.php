<?php

declare(strict_types=1);

namespace GlpiPlugin\Glpiacessivel\Application;

/** Lifecycle-only cleanup through the same public Config API as persistence. */
final class PresentationPreferenceCleanup
{
    private \Closure $reader;
    private \Closure $deleter;
    private \Closure $available;

    /**
     * @param callable(array):array<string,mixed>|null $reader
     * @param callable(array):void|null $deleter
     * @param callable():bool|null $available
     */
    public function __construct(?callable $reader = null, ?callable $deleter = null, ?callable $available = null)
    {
        $this->reader = \Closure::fromCallable($reader ?? static function (array $keys): array {
            return \Config::getConfigurationValues(PresentationPreferenceService::CONTEXT, $keys);
        });
        $this->deleter = \Closure::fromCallable($deleter ?? static function (array $keys): void {
            \Config::deleteConfigurationValues(PresentationPreferenceService::CONTEXT, $keys);
        });
        $this->available = \Closure::fromCallable($available ?? static function (): bool {
            return is_callable(['Config', 'getConfigurationValues']) && is_callable(['Config', 'deleteConfigurationValues']);
        });
    }

    public function forUser(int $userId): bool
    {
        if ($userId <= 0) {
            return false;
        }
        return $this->delete(['presentation_mode_user_' . $userId]);
    }

    /** Enumerating this isolated namespace is reserved for plugin uninstall. */
    public function all(): bool
    {
        try {
            if (!($this->available)()) {
                return false;
            }
            $keys = array_values(array_filter(array_keys(($this->reader)([])), static function ($key): bool {
                return is_string($key) && preg_match('/\Apresentation_mode_user_[1-9][0-9]*\z/D', $key) === 1;
            }));
            return $keys === [] || $this->delete($keys);
        } catch (\Throwable) {
            return false;
        }
    }

    /** @param list<string> $keys */
    private function delete(array $keys): bool
    {
        try {
            if (!($this->available)()) {
                return false;
            }
            ($this->deleter)($keys);
            return array_intersect_key(($this->reader)($keys), array_fill_keys($keys, true)) === [];
        } catch (\Throwable) {
            return false;
        }
    }
}
