<?php

declare(strict_types=1);

namespace GlpiPlugin\Glpiacessivel\Application;

/** Expected exposure refusal; contains no profile list, submitted data or storage diagnostics. */
final class FeatureReleaseDenied extends \RuntimeException
{
    public function __construct(public readonly string $feature, public readonly string $reason)
    {
        parent::__construct(__('Esta funcionalidade não está liberada para seu perfil atual.', 'glpiacessivel'));
    }
}
