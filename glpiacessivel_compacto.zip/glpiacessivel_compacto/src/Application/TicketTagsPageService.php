<?php

declare(strict_types=1);

namespace GlpiPlugin\Glpiacessivel\Application;

use GlpiPlugin\Glpiacessivel\UI\Presenter\TicketTagColorPresenter;

/** Optional presentation enrichment cannot alter the selected tickets or their order. */
final class TicketTagsPageService
{
    private \Closure $released;
    private string $lastReason = '';

    public function lastReason(): string
    {
        return $this->lastReason;
    }

    public function __construct(private TicketTagsPageGateway $gateway, ?callable $released = null)
    {
        $this->released = \Closure::fromCallable($released
            ?? static fn(string $key): bool => FeatureReleasePolicy::allows($key));
    }

    /** @param array<array-key,array<string,mixed>> $items @param array<string,mixed> $filters */
    public function enrich(array $items, array $filters): array
    {
        $this->lastReason = '';
        if (
            !in_array('tags', (array) ($filters['columns'] ?? []), true)
            || !($this->released)('tickets.tags_column') || $items === []
        ) {
            return $items;
        }
        $models = [];
        try {
            $ids = [];
            foreach ($items as $item) {
                $id = $item['id'] ?? null;
                if ((!is_int($id) && !is_string($id)) || !ctype_digit((string) $id) || (int) $id < 1) {
                    throw new \RuntimeException('tag_page_invalid');
                }
                $ids[] = (int) $id;
            }
            $map = $this->gateway->read($ids);
            if (count($map) !== count($ids) || array_diff($ids, array_keys($map)) !== []) {
                throw new \RuntimeException('tag_page_incomplete');
            }
            $colors = new TicketTagColorPresenter();
            foreach ($map as $id => $rows) {
                $tags = [];
                $names = [];
                foreach ($rows as $row) {
                    if (
                        !is_int($row['id'] ?? null) || $row['id'] < 1 || isset($tags[$row['id']])
                        || !is_string($row['name'] ?? null) || trim($row['name']) === ''
                    ) {
                        throw new \RuntimeException('tag_page_invalid');
                    }
                    $color = $colors->present($row['color'] ?? null);
                    $tags[$row['id']] = ['id' => $row['id'], 'name' => $row['name'],
                        'color_available' => $color['state'] === 'native',
                        'color' => $color['state'] === 'native' ? $color['background_color'] : null,
                        'foreground' => $color['state'] === 'native' ? $color['text_color'] : null];
                    $names[$row['name']] = ($names[$row['name']] ?? 0) + 1;
                }
                foreach ($tags as &$tag) {
                    if ($names[$tag['name']] > 1) {
                        $tag['name'] = sprintf(__('%s — etiqueta #%d', 'glpiacessivel'), $tag['name'], $tag['id']);
                    }
                }
                unset($tag);
                $models[$id] = ['state' => $tags === [] ? 'empty' : 'ready', 'items' => array_values($tags),
                    'color_unavailable' => array_filter($tags, static fn(array $tag): bool => !$tag['color_available']) !== []];
            }
        } catch (\Throwable $error) {
            $this->lastReason = preg_match('/\Atag_page_[a-z_]{1,50}\z/D', $error->getMessage()) === 1
                ? $error->getMessage() : 'tag_page_failed';
            $models = [];
        }
        foreach ($items as &$item) {
            $item['tags'] = $models[(int) ($item['id'] ?? 0)]
                ?? ['state' => 'unavailable', 'items' => [], 'color_unavailable' => false];
        }
        unset($item);
        return $items;
    }
}
