<?php

declare(strict_types=1);

namespace GlpiPlugin\Glpiacessivel\Application;

use GlpiPlugin\Glpiacessivel\Infrastructure\Audit\AuditLogger;
use GlpiPlugin\Glpiacessivel\Infrastructure\Repository\PlaybookRepository;
use GlpiPlugin\Glpiacessivel\Infrastructure\Repository\TicketRepository;
use GlpiPlugin\Glpiacessivel\Support\TextNormalizer;
use GlpiPlugin\Glpiacessivel\Domain\Knowledge\KnowledgeSourceReader;
use GlpiPlugin\Glpiacessivel\Infrastructure\Knowledge\NativeKnowledgeSourceReader;

final class ChatbotPlaybookService
{
    private const MATCH_STOPWORDS = [
        'a', 'o', 'os', 'as', 'de', 'da', 'do', 'das', 'dos', 'e', 'em', 'no', 'na',
        'nos', 'nas', 'um', 'uma', 'uns', 'umas', 'para', 'por', 'com', 'sem', 'que',
        'meu', 'minha', 'meus', 'minhas', 'tenho', 'preciso', 'quero', 'favor', 'ajuda',
        'problema', 'erro', 'falha', 'nao', 'esta', 'estou', 'sou', 'ao', 'aos',
    ];

    private const TERM_SYNONYMS = [
        'vpn' => ['vpn', 'forticlient', 'forti', 'remoto', 'mfa', 'token', 'conexao', 'conecta', 'autenticacao'],
        'office' => ['office', 'office365', 'microsoft', 'm365', 'outlook', 'teams', 'onedrive', 'email', 'caixa', 'postal'],
        'impressora' => ['impressora', 'scanner', 'multifuncional', 'imprimir', 'impressao', 'toner', 'fila'],
        'senha' => ['senha', 'login', 'conta', 'bloqueado', 'bloqueada', 'expirada', 'trocar', 'reset'],
        'certificado' => ['certificado', 'assinatura', 'token', 'a1', 'a3', 'pje', 'sei'],
        'rede' => ['rede', 'internet', 'wifi', 'wi', 'fi', 'cabo', 'conexao', 'lento', 'instavel'],
        'glpi' => ['glpi', 'chamado', 'ticket', 'status', 'prazo', 'acompanhar', 'solicitacao'],
    ];

    /** @var TicketRepository */
    private $ticketRepository;
    /** @var PlaybookRepository */
    private $playbookRepository;
    /** @var AuditLogger */
    private $auditLogger;
    private KnowledgeSourceReader $sourceReader;

    public function __construct(
        TicketRepository $ticketRepository,
        PlaybookRepository $playbookRepository,
        AuditLogger $auditLogger,
        ?KnowledgeSourceReader $sourceReader = null
    ) {
        $this->ticketRepository = $ticketRepository;
        $this->playbookRepository = $playbookRepository;
        $this->auditLogger = $auditLogger;
        $this->sourceReader = $sourceReader ?? new NativeKnowledgeSourceReader();
    }

    public function runInitialKnowledgeScan(array $options = []): array
    {
        return $this->scanService()->start($options);
    }

    public function continueKnowledgeScan(int $id): array
    {
        return $this->scanService()->continue($id);
    }

    public function pauseKnowledgeScan(int $id): array
    {
        return $this->scanService()->stop($id, false);
    }

    public function cancelKnowledgeScan(int $id): array
    {
        return $this->scanService()->stop($id, true);
    }

    public function listKnowledgeJobs(int $limit = 20): array
    {
        if (!$this->canReviewKnowledge()) {
            return [];
        }
        return $this->playbookRepository->listJobs($limit);
    }

    public function canReviewKnowledge(): bool
    {
        return $this->sourceReader->canReview();
    }

    public function listKnowledgeSuggestions(array $filters): array
    {
        if (!$this->canReviewKnowledge()) {
            return ['items' => [], 'total' => 0, 'page' => 1, 'page_size' => 20];
        }
        $result = $this->playbookRepository->listEditorialSuggestions($filters);
        $items = (array) ($result['items'] ?? []);
        $visible = $this->visibleEditorialItems($items);
        // Do not expose aggregate counts from a page with unreadable sources.
        if (count($visible) !== count($items)) {
            return ['items' => [], 'total' => null, 'page' => 1, 'page_size' => (int) ($result['page_size'] ?? 20),
                'access_incomplete' => true, 'has_more' => false];
        }
        $result['items'] = $visible;
        $result['has_more'] = (int) ($result['total'] ?? 0) > (int) ($result['page'] ?? 1) * (int) ($result['page_size'] ?? 20);
        // An aggregate SQL count has not been individually authorized.
        $result['total'] = null;
        return $result;
    }

    private function scanService(): KnowledgeScanService
    {
        return new KnowledgeScanService(
            $this->sourceReader,
            $this->playbookRepository,
            fn(array $source): ?array => $this->suggestionFromKnowledgeArticle($source)
        );
    }

    public function listPendingSuggestions(int $limit = 80): array
    {
        return $this->visibleEditorialItems($this->playbookRepository->listSuggestions('pending', $limit));
    }

    public function listApprovedPlaybooks(int $limit = 120): array
    {
        return $this->visibleEditorialItems($this->playbookRepository->listPlaybooks($limit));
    }

    private function visibleEditorialItems(array $items): array
    {
        if (!$this->canReviewKnowledge()) {
            return [];
        }
        return array_values(array_filter($items, function (array $item): bool {
            $ids = [];
            foreach ((array) ($item['kb_articles'] ?? []) as $reference) {
                $ids[] = (int) ($reference['id'] ?? 0);
            }
            foreach ((array) ($item['evidence'] ?? []) as $reference) {
                $ids[] = (int) ($reference['source_id'] ?? 0);
            }
            foreach (array_unique($ids) as $id) {
                $source = $this->sourceReader->readForEditorialReview($id);
                if (($source['publication'] ?? 'unknown') === 'unknown') {
                    return false;
                }
            }
            return true;
        }));
    }

    public function updateSuggestion(int $id, array $input): bool
    {
        $existing = $this->playbookRepository->getSuggestion($id);
        if (
            !$this->canReviewKnowledge() || $existing === null
            || (int) ($input['proposal_revision'] ?? 0) !== (int) ($existing['revision'] ?? 1)
            || (string) ($existing['status'] ?? '') !== 'pending'
        ) {
            return false;
        }

        $payload = $this->playbookPayloadFromInput($input, $existing);
        $payload['title'] = $payload['name'];
        $payload['confidence'] = (float) ($existing['confidence'] ?? 0.7);
        $payload['expected_revision'] = (int) $existing['revision'];
        if (!empty($existing['content']['import_requires_mapping'])) {
            if ($this->verifiedDependencies($payload['kb_articles']) === null) {
                return false;
            }
            unset($payload['content']['import_requires_mapping']);
        }

        $updated = $this->playbookRepository->updateSuggestion($id, $payload);
        if ($updated) {
            $this->auditLogger->log('chatbot.playbook.suggestion.updated', [
                'author_user_id' => (int) ($_SESSION['glpiID'] ?? 0),
                'suggestion_id' => $id,
                'kb_articles_count' => count((array) ($payload['kb_articles'] ?? [])),
            ]);
        }

        return $updated;
    }

    public function approveSuggestion(int $id, ?int $expectedProposalRevision = null, ?array $sourceSnapshots = null): ?int
    {
        $context = $this->playbookRepository->currentJobContext();
        $suggestion = $this->playbookRepository->getSuggestion($id);
        if (
            !$this->canReviewKnowledge() || $suggestion === null
            || $expectedProposalRevision === null
            || (int) ($suggestion['revision'] ?? 1) !== $expectedProposalRevision
            || ($suggestion['status'] ?? '') !== 'pending'
        ) {
            return null;
        }
        if (!empty($suggestion['content']['import_requires_mapping'])) {
            return null;
        }
        if ($sourceSnapshots !== null && $this->editorialSourceSnapshots($suggestion) !== $sourceSnapshots) {
            return null;
        }
        $evidence = (array) ($suggestion['evidence'] ?? []);
        if ($evidence !== [] || !empty($suggestion['dedupe_key'])) {
            if (!$this->sourceReader->canReview() || ($suggestion['action'] ?? '') === 'review') {
                return null;
            }
            $current = [];
            foreach ($evidence as $expected) {
                if (($expected['installation_id'] ?? '') !== KnowledgeScanService::installationId()) {
                    return null;
                }
                $sourceId = (int) ($expected['source_id'] ?? 0);
                $source = $this->sourceReader->readForEditorialReview($sourceId);
                if (
                    ($source['publication'] ?? 'unknown') === 'unknown'
                    || !hash_equals((string) ($expected['text_hash'] ?? ''), (string) ($source['text_hash'] ?? ''))
                    || !hash_equals((string) ($expected['publication_hash'] ?? ''), (string) ($source['publication_hash'] ?? ''))
                    || ($expected['validity'] ?? '') !== ($source['validity'] ?? '')
                ) {
                    return null;
                }
                if (
                    in_array($suggestion['action'] ?? 'create', ['create', 'update', 'reactivate'], true)
                    && (($source['publication'] ?? '') !== 'published' || ($source['validity'] ?? '') !== 'current')
                ) {
                    return null;
                }
                $current[] = array_merge($expected, $source, ['source_id' => $sourceId]);
            }
            $this->assertEditorialContext($context);
            $applied = $this->playbookRepository->applyEditorialSuggestion(
                $id,
                $current,
                $expectedProposalRevision,
                fn() => $this->assertEditorialDecisionContext($context, $suggestion, $sourceSnapshots)
            );
            $playbookId = ($applied['status'] ?? '') === 'approved' ? (int) ($applied['id'] ?? 0) : null;
        } else {
            // Legacy/manual proposals with sources must establish fresh dependencies.
            $dependencies = $this->verifiedDependencies((array) ($suggestion['kb_articles'] ?? []));
            if ($dependencies === null) {
                return null;
            }
            $this->assertEditorialContext($context);
            $playbookId = $this->playbookRepository->approveManualSuggestionWithSources(
                $id,
                $dependencies,
                $expectedProposalRevision,
                fn() => $this->assertEditorialDecisionContext($context, $suggestion, $sourceSnapshots)
            );
        }
        if ($playbookId !== null) {
            $this->auditLogger->log('chatbot.playbook.approved', [
                'author_user_id' => (int) ($_SESSION['glpiID'] ?? 0),
                'suggestion_id' => $id,
                'playbook_id' => $playbookId,
            ]);
        }

        return $playbookId;
    }

    public function rejectSuggestion(int $id, ?int $expectedProposalRevision = null, ?array $sourceSnapshots = null): bool
    {
        $context = $this->playbookRepository->currentJobContext();
        $suggestion = $this->visibleEditorialDecision($id);
        if (
            $suggestion === null || $expectedProposalRevision === null
            || (int) ($suggestion['revision'] ?? 1) !== $expectedProposalRevision
            || (string) ($suggestion['status'] ?? '') !== 'pending'
        ) {
            return false;
        }
        if ($sourceSnapshots !== null && $this->editorialSourceSnapshots($suggestion) !== $sourceSnapshots) {
            return false;
        }
        $this->assertEditorialContext($context);
        $result = $this->playbookRepository->rejectSuggestion(
            $id,
            $expectedProposalRevision,
            fn() => $this->assertEditorialDecisionContext($context, $suggestion, $sourceSnapshots)
        );
        if ($result) {
            $this->auditLogger->log('chatbot.playbook.rejected', [
                'author_user_id' => (int) ($_SESSION['glpiID'] ?? 0),
                'suggestion_id' => $id,
            ]);
        }

        return $result;
    }

    /** Fresh native authorization is required even when displaying a previous result. */
    public function visibleEditorialDecision(int $id): ?array
    {
        $context = $this->playbookRepository->currentJobContext();
        if (!$this->canReviewKnowledge()) {
            return null;
        }
        $suggestion = $this->playbookRepository->getSuggestion($id);
        if (
            $suggestion === null || $this->editorialSourceSnapshots($suggestion) === null
            || $context !== $this->playbookRepository->currentJobContext() || !$this->canReviewKnowledge()
        ) {
            return null;
        }
        return $suggestion;
    }

    /** Prepare an exact, bounded selection without writing observations or decisions. */
    public function prepareEditorialBatch(array $rows, string $action): array
    {
        $this->validateEditorialBatchRows($rows, $action);
        $context = $this->playbookRepository->currentJobContext();
        $items = [];
        $manifest = [];
        $targets = [];
        foreach ($rows as $row) {
            $id = (int) $row['id'];
            $suggestion = $this->visibleEditorialDecision($id);
            $snapshots = $suggestion === null ? null : $this->editorialSourceSnapshots($suggestion);
            $reason = $suggestion === null || $snapshots === null ? 'source_unavailable'
                : $this->editorialBatchItemReason($suggestion, $row, $action, $snapshots);
            if ($snapshots === null) {
                $suggestion = null;
            }
            if ($context !== $this->playbookRepository->currentJobContext() || !$this->canReviewKnowledge()) {
                $reason = 'context_changed';
                $suggestion = null;
            }
            if ($suggestion !== null) {
                $suggestion['editorial_reason'] = (string) ($suggestion['reason'] ?? '');
                $targetId = (int) ($suggestion['target_playbook_id'] ?? 0);
                $suggestion['current_playbook'] = $targetId > 0 ? $this->playbookRepository->getPlaybook($targetId) : null;
            }
            $items[] = array_merge($suggestion ?? ['id' => $id], ['eligible' => $reason === '', 'reason' => $reason]);
            $manifest[] = [
                'id' => $id, 'revision' => (int) $row['revision'],
                'expected_revision' => (int) $row['expected_revision'],
                'target_playbook_id' => (int) $row['target_playbook_id'],
                'source_snapshots' => $snapshots ?? [],
            ];
            $target = (int) ($suggestion['target_playbook_id'] ?? 0);
            if ($action === 'approve' && $target > 0) {
                $targets[$target][] = count($items) - 1;
            }
        }
        foreach ($targets as $indexes) {
            if (count($indexes) > 1) {
                foreach ($indexes as $index) {
                    $items[$index]['eligible'] = false;
                    $items[$index]['reason'] = 'shared_target';
                }
            }
        }
        if ($context !== $this->playbookRepository->currentJobContext() || !$this->canReviewKnowledge()) {
            // Do not retain any titles collected under a context that changed during review.
            $items = array_map(static fn(array $row): array => [
                'id' => (int) $row['id'], 'eligible' => false, 'reason' => 'context_changed',
            ], $rows);
        }
        $eligible = count(array_filter($items, static fn(array $item): bool => $item['eligible'])) === count($items);
        return ['items' => $items, 'manifest' => $manifest, 'eligible' => $eligible,
            'status' => $eligible ? 'ready' : 'blocked', 'reason' => $eligible ? '' : 'selection_blocked'];
    }

    /** Caller owns the single-use confirmation; this method never retries an uncertain write. */
    public function executeEditorialBatch(array $manifest, string $action): array
    {
        $rows = isset($manifest['items']) && is_array($manifest['items']) ? $manifest['items'] : $manifest;
        $this->validateEditorialBatchRows($rows, $action);
        foreach ($rows as $row) {
            if (!isset($row['source_snapshots']) || !is_array($row['source_snapshots'])) {
                throw new \InvalidArgumentException('invalid_source_snapshot');
            }
        }
        $context = $this->playbookRepository->currentJobContext();
        $operationId = (string) ($manifest['operation_id'] ?? bin2hex(random_bytes(16)));
        $results = [];
        $stop = '';
        $targets = array_count_values(array_filter(array_map(
            static fn(array $row): int => (int) $row['target_playbook_id'],
            $rows
        )));
        foreach ($rows as $row) {
            $id = (int) $row['id'];
            $status = 'not_processed';
            $reason = $stop;
            if ($stop === '') {
                try {
                    if ($context !== $this->playbookRepository->currentJobContext() || !$this->canReviewKnowledge()) {
                        $stop = $reason = 'context_changed';
                    } elseif ($action === 'approve' && ($targets[(int) $row['target_playbook_id']] ?? 0) > 1) {
                        $status = 'conflict';
                        $reason = 'shared_target';
                    } else {
                        $prepared = $this->prepareEditorialBatch([$row], $action);
                        $reason = (string) $prepared['items'][0]['reason'];
                        if ($context !== $this->playbookRepository->currentJobContext() || !$this->canReviewKnowledge()) {
                            $stop = $reason = 'context_changed';
                        } elseif ($reason !== '') {
                            $status = $reason === 'already_decided' ? 'already_decided'
                                : (in_array($reason, ['proposal_changed', 'target_changed', 'source_changed'], true)
                                    ? 'conflict' : 'not_applied');
                        } else {
                            $applied = $action === 'approve'
                                ? $this->approveSuggestion($id, (int) $row['revision'], $row['source_snapshots']) !== null
                                : $this->rejectSuggestion($id, (int) $row['revision'], $row['source_snapshots']);
                            $status = $applied ? 'applied' : 'conflict';
                            $reason = $applied ? '' : 'decision_precondition_changed';
                        }
                    }
                } catch (\Throwable $error) {
                    $status = 'unknown';
                    $stop = $reason = 'result_unconfirmed';
                }
            }
            $result = ['id' => $id, 'status' => $status, 'reason' => $reason];
            $results[] = $result;
            $this->auditLogger->log('chatbot.playbook.batch.item', array_merge($result, [
                'operation_id' => $operationId, 'action' => $action,
            ]));
        }
        $complete = count(array_filter($results, static fn(array $row): bool => $row['status'] === 'applied')) === count($rows);
        return ['items' => $results, 'operation_id' => $operationId,
            'status' => $stop !== '' ? 'interrupted' : ($complete ? 'completed' : 'partial')];
    }

    private function validateEditorialBatchRows(array $rows, string $action): void
    {
        if (!in_array($action, ['approve', 'reject'], true) || $rows === [] || count($rows) > 20) {
            throw new \InvalidArgumentException('invalid_editorial_selection');
        }
        $ids = [];
        foreach ($rows as $row) {
            foreach (['id', 'revision', 'expected_revision', 'target_playbook_id'] as $field) {
                $value = is_array($row) ? ($row[$field] ?? null) : null;
                if (
                    (!is_int($value) && !(is_string($value) && ctype_digit($value)))
                    || (int) $value < (in_array($field, ['id', 'revision'], true) ? 1 : 0)
                ) {
                    throw new \InvalidArgumentException('invalid_editorial_selection');
                }
            }
            if (isset($ids[(int) $row['id']])) {
                throw new \InvalidArgumentException('duplicate_editorial_selection');
            }
            $ids[(int) $row['id']] = true;
        }
    }

    /** Null means unreadable, not unpublished. No snapshot is a future access grant. */
    private function editorialSourceSnapshots(array $suggestion): ?array
    {
        $ids = [];
        $targetId = (int) ($suggestion['target_playbook_id'] ?? 0);
        if ($targetId > 0) {
            $target = $this->playbookRepository->getPlaybook($targetId);
            if ($target !== null) {
                foreach ((array) ($target['kb_articles'] ?? []) as $article) {
                    $ids[] = (int) ($article['id'] ?? 0);
                }
                foreach ($this->playbookRepository->getPlaybookSources($targetId) as $source) {
                    $ids[] = (int) ($source['source_id'] ?? 0);
                }
            }
        }
        foreach ((array) ($suggestion['kb_articles'] ?? []) as $article) {
            $ids[] = (int) ($article['id'] ?? 0);
        }
        foreach ((array) ($suggestion['evidence'] ?? []) as $evidence) {
            $ids[] = (int) ($evidence['source_id'] ?? 0);
        }
        $ids = array_unique($ids);
        sort($ids, SORT_NUMERIC);
        $snapshots = [];
        foreach ($ids as $id) {
            $source = $this->sourceReader->readForEditorialReview($id);
            if ($id <= 0 || ($source['publication'] ?? 'unknown') === 'unknown') {
                return null;
            }
            $snapshots[] = ['id' => $id, 'text_hash' => (string) ($source['text_hash'] ?? ''),
                'publication_hash' => (string) ($source['publication_hash'] ?? ''),
                'publication' => (string) $source['publication'], 'validity' => (string) ($source['validity'] ?? 'unknown')];
        }
        return $snapshots;
    }

    private function editorialBatchItemReason(array $suggestion, array $row, string $action, array $snapshots): string
    {
        if ((string) ($suggestion['status'] ?? '') !== 'pending') {
            return 'already_decided';
        }
        if ((int) ($suggestion['revision'] ?? 1) !== (int) $row['revision']) {
            return 'proposal_changed';
        }
        if (
            (int) ($suggestion['expected_revision'] ?? 0) !== (int) $row['expected_revision']
            || (int) ($suggestion['target_playbook_id'] ?? 0) !== (int) $row['target_playbook_id']
        ) {
            return 'target_changed';
        }
        if (isset($row['source_snapshots']) && $row['source_snapshots'] !== $snapshots) {
            return 'source_changed';
        }
        if ($action === 'reject') {
            return '';
        }
        if (!empty($suggestion['content']['import_requires_mapping'])) {
            return 'mapping_required';
        }
        $effect = (string) ($suggestion['action'] ?? 'create');
        if (!in_array($effect, ['create', 'update', 'inactivate', 'reactivate'], true)) {
            return 'individual_review_required';
        }
        $evidenceRows = (array) ($suggestion['evidence'] ?? []);
        if (
            ($evidenceRows === [] && !empty($suggestion['dedupe_key']))
            || ($evidenceRows === [] && $effect !== 'create')
        ) {
            return 'individual_review_required';
        }
        if ((int) ($suggestion['entities_id'] ?? -1) !== (int) ($_SESSION['glpiactive_entity'] ?? -2)) {
            return 'entity_mismatch';
        }
        $target = (int) ($suggestion['target_playbook_id'] ?? 0);
        $playbook = $target > 0 ? $this->playbookRepository->getPlaybook($target) : null;
        if (
            ($effect === 'create' && $target !== 0) || ($effect !== 'create'
            && ($playbook === null || (int) $playbook['revision'] !== (int) $row['expected_revision']))
        ) {
            return 'target_changed';
        }
        if ($playbook !== null && (int) ($playbook['entities_id'] ?? -1) !== (int) ($_SESSION['glpiactive_entity'] ?? -2)) {
            return 'entity_mismatch';
        }
        if ($effect === 'reactivate' && ($playbook['origin_type'] ?? '') !== 'kb_derived') {
            return 'manual_reactivation_forbidden';
        }
        foreach ($evidenceRows as $evidence) {
            $current = array_values(array_filter($snapshots, static fn(array $source): bool =>
                $source['id'] === (int) ($evidence['source_id'] ?? 0)))[0] ?? null;
            if (
                ($evidence['installation_id'] ?? '') !== KnowledgeScanService::installationId()
                || $current === null || ($evidence['text_hash'] ?? '') !== $current['text_hash']
                || ($evidence['publication_hash'] ?? '') !== $current['publication_hash']
                || ($evidence['validity'] ?? '') !== $current['validity']
            ) {
                return 'source_changed';
            }
            $observed = $this->playbookRepository->getKnowledgeSource($evidence);
            if (
                $observed === null || ($observed['text_hash'] ?? '') !== $current['text_hash']
                || ($observed['publication_hash'] ?? '') !== $current['publication_hash']
                || ($observed['publication'] ?? '') !== $current['publication']
            ) {
                return 'source_changed';
            }
        }
        if ($effect === 'inactivate') {
            $groups = [];
            $published = true;
            foreach ($evidenceRows as $evidence) {
                $apt = ($evidence['publication'] ?? '') === 'published' && ($evidence['validity'] ?? '') === 'current';
                if (($evidence['role'] ?? 'required') === 'required' && !$apt) {
                    $published = false;
                } elseif (($evidence['role'] ?? '') === 'alternative') {
                    $group = (string) ($evidence['alternative_group'] ?? '');
                    $groups[$group] = ($groups[$group] ?? false) || $apt;
                }
            }
            $published = $published && !in_array(false, $groups, true);
            return in_array('unpublished', array_column($evidenceRows, 'publication'), true) && !$published
                ? '' : 'source_ineligible';
        }
        $proposedIds = array_merge(
            array_map(static fn(array $article): int => (int) ($article['id'] ?? 0), (array) ($suggestion['kb_articles'] ?? [])),
            array_map(static fn(array $evidence): int => (int) ($evidence['source_id'] ?? 0), $evidenceRows)
        );
        foreach ($snapshots as $source) {
            if (
                in_array($source['id'], $proposedIds, true)
                && ($source['publication'] !== 'published' || $source['validity'] !== 'current')
            ) {
                return 'source_ineligible';
            }
        }
        return '';
    }

    private function assertEditorialContext(array $context): void
    {
        if ($context !== $this->playbookRepository->currentJobContext() || !$this->canReviewKnowledge()) {
            throw new \RuntimeException('editorial_context_changed');
        }
    }

    private function assertEditorialDecisionContext(array $context, array $suggestion, ?array $snapshots): void
    {
        $this->assertEditorialContext($context);
        // The mutation may legitimately replace target dependencies. Re-read the exact
        // sources reviewed, not the target's newly written dependency set.
        $current = $this->editorialSourceSnapshots($snapshots === null ? $suggestion : [
            'kb_articles' => array_map(static fn(array $source): array => ['id' => (int) $source['id']], $snapshots),
        ]);
        if ($current === null || ($snapshots !== null && $snapshots !== $current)) {
            throw new \RuntimeException('editorial_source_changed');
        }
        $this->assertEditorialContext($context);
    }

    public function importApprovedPlaybooks(array $items): int
    {
        $result = $this->importPlaybooks($items, 'active');
        $count = (int) $result['active'] + (int) $result['inactive'];

        return $count;
    }

    public function importPlaybooks(array $items, string $defaultStatus = 'active'): array
    {
        $result = $this->playbookRepository->importPlaybooks($items, $defaultStatus);
        $this->auditLogger->log('chatbot.playbook.imported', [
            'author_user_id' => (int) ($_SESSION['glpiID'] ?? 0),
            'active' => (int) ($result['active'] ?? 0),
            'inactive' => (int) ($result['inactive'] ?? 0),
            'pending' => (int) ($result['pending'] ?? 0),
            'skipped' => (int) ($result['skipped'] ?? 0),
        ]);

        return $result;
    }

    public function createPlaybook(array $input): array
    {
        if (!$this->canReviewKnowledge()) {
            return ['status' => 'invalid', 'id' => 0];
        }
        $status = $this->normalizeStatus((string) ($input['status'] ?? 'active'));
        $payload = $this->playbookPayloadFromInput($input);
        $dependencies = $this->verifiedDependencies($payload['kb_articles']);
        if ($dependencies === null && $status !== 'pending') {
            return ['status' => 'invalid', 'id' => 0];
        }

        if ($payload['name'] === '') {
            return ['status' => 'invalid', 'id' => 0];
        }

        if ($status === 'pending') {
            $suggestionId = $this->playbookRepository->createSuggestion(0, [
                'source_type' => 'manual',
                'title' => $payload['name'],
                'intent' => $payload['intent'],
                'confidence' => 0.7,
                'keywords' => $payload['keywords'],
                'questions' => $payload['questions'],
                'kb_articles' => $payload['kb_articles'],
                'category_hint' => $payload['category_hint'],
                'group_hint' => $payload['group_hint'],
                'ticket_template' => $payload['ticket_template'],
                'content' => $payload['content'],
                'status' => 'pending',
            ]);
            $this->auditLogger->log('chatbot.playbook.created_pending', [
                'author_user_id' => (int) ($_SESSION['glpiID'] ?? 0),
                'suggestion_id' => $suggestionId,
            ]);

            return ['status' => 'pending', 'id' => $suggestionId];
        }

        $payload['is_active'] = $status === 'active' ? 1 : 0;
        $payload['origin_type'] = 'manual';
        $playbookId = $this->playbookRepository->savePlaybookWithSources($payload, $dependencies ?? []);
        if ($playbookId === null) {
            return ['status' => 'invalid', 'id' => 0];
        }
        $this->auditLogger->log('chatbot.playbook.created', [
            'author_user_id' => (int) ($_SESSION['glpiID'] ?? 0),
            'playbook_id' => $playbookId,
            'status' => $status,
            'kb_articles_count' => count($payload['kb_articles']),
        ]);

        return ['status' => $status, 'id' => $playbookId];
    }

    public function updatePlaybook(int $id, array $input): bool
    {
        if (!$this->canReviewKnowledge()) {
            return false;
        }
        $existing = $this->playbookRepository->getPlaybook($id);
        if ($existing === null || (int) ($input['revision'] ?? 0) !== (int) ($existing['revision'] ?? 1)) {
            return false;
        }

        $status = $this->normalizeStatus((string) ($input['status'] ?? 'active'));
        if ($status === 'pending') {
            return false;
        }

        $payload = $this->playbookPayloadFromInput($input, $existing);
        $payload['is_active'] = $status === 'active' ? 1 : 0;
        $payload['origin_type'] = 'manual';
        $dependencies = $this->verifiedDependencies($payload['kb_articles']);
        if ($dependencies === null) {
            return false;
        }

        $updated = $this->playbookRepository->savePlaybookWithSources($payload, $dependencies, $id, (int) $existing['revision']) !== null;
        if ($updated) {
            $this->auditLogger->log('chatbot.playbook.updated', [
                'author_user_id' => (int) ($_SESSION['glpiID'] ?? 0),
                'playbook_id' => $id,
                'status' => $status,
                'kb_articles_count' => count((array) ($payload['kb_articles'] ?? [])),
            ]);
        }

        return $updated;
    }

    public function deletePlaybook(int $id): bool
    {
        $deleted = $this->playbookRepository->deletePlaybook($id);
        if ($deleted) {
            $this->auditLogger->log('chatbot.playbook.deleted', [
                'author_user_id' => (int) ($_SESSION['glpiID'] ?? 0),
                'playbook_id' => $id,
            ]);
        }

        return $deleted;
    }

    public function returnPlaybookToPending(int $id): bool
    {
        // Returning to review must preserve the original identity and history.
        // A dedicated targeted review workflow is required; never delete here.
        return false;
    }

    public function exportApprovedPlaybooks(): array
    {
        return $this->visibleEditorialItems($this->playbookRepository->exportApprovedPlaybooks());
    }

    public function matchApprovedPlaybook(string $text, string $intent = ''): ?array
    {
        $normalized = $this->normalize($text);
        if ($normalized === '') {
            return null;
        }

        $terms = $this->meaningfulTerms($normalized);
        $expandedTerms = $this->expandTerms($terms);
        $best = null;
        $bestScore = 0.0;
        $runnerUpScore = 0.0;

        $candidates = $this->playbookRepository->listCandidatePlaybooks(implode(' ', $expandedTerms), 80);
        foreach ($candidates as $playbook) {
            if ($intent !== '' && trim((string) ($playbook['intent'] ?? '')) !== $intent) {
                continue;
            }

            $playbook = $this->revalidatePlaybook($playbook);
            if ($playbook === null) {
                continue;
            }

            $keywords = $this->normalizedList($this->playbookSearchTerms($playbook));
            $questions = $this->normalizedList((array) ($playbook['questions'] ?? []));
            $score = $this->scoreMatch($normalized, $terms, $expandedTerms, $keywords, $questions);
            if ($score > $bestScore) {
                $runnerUpScore = $bestScore;
                $bestScore = $score;
                $best = $playbook;
            } elseif ($score > $runnerUpScore) {
                $runnerUpScore = $score;
            }
        }

        if ($best === null || $bestScore < 0.28 || ($runnerUpScore >= 0.28 && $bestScore - $runnerUpScore < 0.08)) {
            return null;
        }

        $best['match_score'] = round($bestScore, 2);
        $best['match_terms'] = array_slice($terms, 0, 8);
        return $best;
    }

    public function revalidatePlaybook(array $playbook): ?array
    {
        $id = (int) ($playbook['id'] ?? 0);
        if ($id <= 0) {
            return null;
        }
        try {
            $fresh = $this->playbookRepository->getPlaybook($id);
            if ($fresh === null || (int) ($fresh['revision'] ?? 0) !== (int) ($playbook['revision'] ?? 0)) {
                return null;
            }
            $validated = (new PlaybookEligibilityPolicy($this->sourceReader))->evaluate(
                $fresh,
                $this->playbookRepository->getPlaybookSources($id)
            );
            if ($validated !== null) {
                $validated['match_score'] = (float) ($playbook['match_score'] ?? 0.0);
                $validated['match_terms'] = (array) ($playbook['match_terms'] ?? []);
            }
            return $validated;
        } catch (\Throwable $e) {
            // No source metadata or copied content is returned on uncertainty.
            return null;
        }
    }

    private function verifiedDependencies(array $articles): ?array
    {
        $context = $this->playbookRepository->currentJobContext();
        if ($articles === []) {
            return [];
        }
        if (!$this->sourceReader->canReview()) {
            return null;
        }
        $dependencies = [];
        foreach ($articles as $article) {
            $id = (int) ($article['id'] ?? 0);
            if ($id <= 0) {
                return null;
            }
            $source = $this->sourceReader->readForEditorialReview($id);
            if (($source['publication'] ?? '') !== 'published' || ($source['validity'] ?? '') !== 'current') {
                return null;
            }
            $this->assertEditorialContext($context);
            $identity = [
                'installation_id' => KnowledgeScanService::installationId(), 'source_type' => 'KnowbaseItem',
                'source_id' => $id,
            ];
            $this->playbookRepository->upsertKnowledgeSource($identity, $source);
            $dependencies[] = array_merge($identity, ['text_hash' => (string) $source['text_hash'],
                'publication_hash' => (string) $source['publication_hash'], 'publication' => 'published',
                'validity' => 'current', 'role' => 'required',
            ]);
        }
        return $dependencies;
    }

    private function suggestionFromKnowledgeArticle(array $article): ?array
    {
        $title = TextNormalizer::fromGlpi((string) ($article['name'] ?? $article['assunto'] ?? ''));
        if ($title === '') {
            return null;
        }

        $content = TextNormalizer::fromGlpi((string) ($article['content_text'] ?? $article['answer_text'] ?? $article['answer'] ?? ''));
        if ($content === '') {
            return null;
        }
        // A reviewable extract, bounded at a sentence boundary when available.
        $paragraphs = preg_split('/(?<=[.!?])\s+/u', $content) ?: [$content];
        $summary = '';
        foreach ($paragraphs as $paragraph) {
            if (mb_strlen($summary . $paragraph, 'UTF-8') > 1200) {
                break;
            }
            $summary .= ($summary === '' ? '' : ' ') . $paragraph;
        }
        if ($summary === '') {
            $summary = rtrim(mb_substr($content, 0, 1200, 'UTF-8'));
        }
        $keywords = $this->extractKeywords($title . ' ' . $content);
        if ($keywords === []) {
            $keywords = $this->terms($this->normalize($title));
        }

        return [
            'source_type' => 'kb',
            'title' => $title,
            'intent' => 'kb_recomendar_contextual',
            'confidence' => 0.0,
            'keywords' => array_slice($keywords, 0, 18),
            'questions' => [
                'Como resolver ' . $title . '?',
                'Tenho problema com ' . $title,
                'Preciso de orientação sobre ' . $title,
            ],
            'kb_articles' => [[
                'id' => (int) ($article['id'] ?? 0),
                'name' => $title,
            ]],
            'category_hint' => (string) ($article['category'] ?? ''),
            'content' => [
                'answer_summary' => $summary,
                'source_date_mod' => (string) ($article['date_mod'] ?? ''),
                'source_type' => 'knowledge_base',
            ],
        ];
    }

    private function extractKeywords(string $text): array
    {
        $stopwords = [
            'para', 'pela', 'pelo', 'com', 'sem', 'uma', 'umas', 'uns', 'dos', 'das', 'que',
            'como', 'sobre', 'esse', 'essa', 'este', 'esta', 'voce', 'usuario', 'glpi',
            'base', 'conhecimento', 'artigo', 'faq', 'problema', 'orientacao',
        ];

        $terms = $this->terms($this->normalize($text));
        $terms = array_values(array_filter($terms, static function (string $term) use ($stopwords): bool {
            return strlen($term) >= 4 && !in_array($term, $stopwords, true);
        }));

        $counts = [];
        foreach ($terms as $term) {
            $counts[$term] = ($counts[$term] ?? 0) + 1;
        }
        arsort($counts);

        return array_keys($counts);
    }

    private function scoreMatch(string $normalized, array $terms, array $expandedTerms, array $keywords, array $questions): float
    {
        $terms = $this->textList($terms);
        $expandedTerms = $this->textList($expandedTerms);
        $keywords = $this->textList($keywords);
        $questions = $this->textList($questions);

        $score = 0.0;
        foreach ($questions as $question) {
            if ($question !== '' && (str_contains($normalized, $question) || str_contains($question, $normalized))) {
                $score += $normalized === $question ? 0.75 : 0.55;
            }
        }

        $keywordHits = 0;
        $phrasePartialHits = 0;
        $documentTerms = [];
        foreach ($keywords as $keyword) {
            if ($keyword === '') {
                continue;
            }

            $keywordTerms = $this->meaningfulTerms($keyword);
            foreach ($keywordTerms as $term) {
                $documentTerms[$this->stemTerm($term)] = true;
            }

            if (in_array($keyword, $terms, true) || str_contains($normalized, $keyword) || str_contains($keyword, $normalized)) {
                $keywordHits++;
                continue;
            }

            $phraseHits = 0;
            foreach ($keywordTerms as $term) {
                $stem = $this->stemTerm($term);
                if (
                    in_array($term, $expandedTerms, true)
                    || in_array($stem, $expandedTerms, true)
                    || $this->fuzzyTermHit($term, $expandedTerms)
                ) {
                    $keywordHits++;
                    $phraseHits++;
                }
            }

            if ($phraseHits >= 2) {
                $phrasePartialHits++;
            }
        }

        if ($keywordHits > 0) {
            $score += min(0.78, 0.32 + (($keywordHits - 1) * 0.12));
            $coverage = $keywordHits / max(1, min(count($documentTerms), 8));
            $score += min(0.28, $coverage * 0.28);
        }

        if ($phrasePartialHits > 0) {
            $score += min(0.18, $phrasePartialHits * 0.06);
        }

        $queryHits = 0;
        $documentTermList = array_keys($documentTerms);
        foreach ($terms as $term) {
            $stem = $this->stemTerm($term);
            if (
                isset($documentTerms[$stem])
                || isset($documentTerms[$term])
                || $this->fuzzyTermHit($term, $documentTermList)
            ) {
                $queryHits++;
            }
        }

        if ($terms !== [] && $queryHits > 0) {
            $score += min(0.24, ($queryHits / max(1, count($terms))) * 0.24);
        }

        return min(1.0, $score);
    }

    /**
     * Build searchable evidence from the approved roteiro itself.
     * This keeps chatbot routing data-driven instead of hardcoded by topic.
     */
    private function playbookSearchTerms(array $playbook): array
    {
        $terms = [];
        $this->collectTextValues((array) ($playbook['keywords'] ?? []), $terms);
        $this->collectTextValues((array) ($playbook['questions'] ?? []), $terms);
        foreach (['name', 'category_hint', 'group_hint'] as $field) {
            $value = trim((string) ($playbook[$field] ?? ''));
            if ($value !== '') {
                $terms[] = $value;
            }
        }

        foreach ((array) ($playbook['kb_articles'] ?? []) as $article) {
            if (!is_array($article)) {
                continue;
            }

            $id = (int) ($article['id'] ?? 0);
            $name = trim((string) ($article['name'] ?? ''));
            if ($id > 0) {
                $terms[] = 'artigo ' . $id;
            }
            if ($name !== '') {
                $terms[] = $name;
            }
        }

        $this->collectTextValues((array) ($playbook['content'] ?? []), $terms);
        $this->collectTextValues((array) ($playbook['ticket_template'] ?? []), $terms);

        return $terms;
    }

    private function collectTextValues(array $values, array &$terms): void
    {
        foreach ($values as $value) {
            if (is_array($value)) {
                $this->collectTextValues($value, $terms);
                continue;
            }

            if (is_scalar($value) && !is_bool($value)) {
                $text = trim((string) $value);
                if ($text !== '') {
                    $terms[] = $text;
                }
            }
        }
    }

    private function textList(array $items): array
    {
        $texts = [];
        $this->collectTextValues($items, $texts);

        $result = [];
        foreach ($texts as $text) {
            $value = trim((string) $text);
            if ($value === '') {
                continue;
            }
            // IDs isolados e flags numericas nao ajudam o matcher semantico.
            if (ctype_digit($value) && strlen($value) < 3) {
                continue;
            }
            $result[] = $value;
        }

        return array_values(array_unique($result));
    }

    private function normalizedList(array $items): array
    {
        $normalized = [];
        foreach ($this->textList($items) as $item) {
            $value = $this->normalize($item);
            if ($value !== '') {
                $normalized[] = $value;
            }
        }

        return array_values(array_unique($normalized));
    }

    private function normalize(string $text): string
    {
        $text = TextNormalizer::fromGlpi($text);
        $text = mb_strtolower($text, 'UTF-8');
        $converted = iconv('UTF-8', 'ASCII//TRANSLIT//IGNORE', $text);
        if (is_string($converted)) {
            $text = $converted;
        }
        $text = preg_replace('/[^a-z0-9\s]+/i', ' ', $text) ?? $text;
        return trim(preg_replace('/\s+/', ' ', $text) ?? $text);
    }

    private function terms(string $normalized): array
    {
        if ($normalized === '') {
            return [];
        }

        return array_values(array_unique(array_filter(explode(' ', $normalized))));
    }

    private function meaningfulTerms(string $normalized): array
    {
        return array_values(array_filter($this->terms($normalized), static function (string $term): bool {
            return strlen($term) >= 2 && !in_array($term, self::MATCH_STOPWORDS, true);
        }));
    }

    private function expandTerms(array $terms): array
    {
        $expanded = [];
        foreach ($this->textList($terms) as $term) {
            $term = $this->normalize($term);
            if ($term === '') {
                continue;
            }
            $expanded[] = $term;
            $expanded[] = $this->stemTerm($term);

            foreach (self::TERM_SYNONYMS as $canonical => $synonyms) {
                if ($term === $canonical || in_array($term, $synonyms, true)) {
                    $expanded[] = $canonical;
                    foreach ($synonyms as $synonym) {
                        $expanded[] = $synonym;
                        $expanded[] = $this->stemTerm($synonym);
                    }
                }
            }
        }

        return array_values(array_unique(array_filter($expanded)));
    }

    private function stemTerm(string $term): string
    {
        $term = trim($term);
        if ($term === '') {
            return '';
        }

        $suffixes = ['mente', 'idades', 'idade', 'acoes', 'acao', 'coes', 'ando', 'endo', 'indo', 'ados', 'adas', 'ado', 'ada', 'icos', 'icas', 'ico', 'ica', 's'];
        foreach ($suffixes as $suffix) {
            if (strlen($term) > strlen($suffix) + 3 && substr($term, -strlen($suffix)) === $suffix) {
                return substr($term, 0, -strlen($suffix));
            }
        }

        return $term;
    }

    private function fuzzyTermHit(string $term, array $expandedTerms): bool
    {
        $term = trim($term);
        if ($term === '' || strlen($term) < 5) {
            return false;
        }

        foreach ($this->textList($expandedTerms) as $candidate) {
            $candidate = trim($candidate);
            if ($candidate === '' || strlen($candidate) < 5 || abs(strlen($candidate) - strlen($term)) > 2) {
                continue;
            }

            if (levenshtein($term, $candidate) <= 1) {
                return true;
            }

            similar_text($term, $candidate, $percent);
            if ($percent >= 86.0) {
                return true;
            }
        }

        return false;
    }

    private function listFromInput($value): array
    {
        if (is_array($value)) {
            $items = $value;
        } else {
            $items = preg_split('/[\r\n,;]+/', (string) $value) ?: [];
        }

        return array_values(array_filter(array_map(static function ($item): string {
            return trim((string) $item);
        }, $items), static function (string $item): bool {
            return $item !== '';
        }));
    }

    private function playbookPayloadFromInput(array $input, array $existing = []): array
    {
        $content = (array) ($existing['content'] ?? []);
        foreach (
            [
            'answer_summary' => 'answer_summary',
            'first_steps' => 'first_steps',
            'when_open_ticket' => 'when_open_ticket',
            'required_data' => 'required_data',
            ] as $inputKey => $contentKey
        ) {
            if (!array_key_exists($inputKey, $input)) {
                continue;
            }
            $value = trim((string) ($input[$inputKey] ?? ''));
            if ($value !== '') {
                $content[$contentKey] = $value;
            } else {
                unset($content[$contentKey]);
            }
        }

        return [
            'name' => trim((string) ($input['name'] ?? '')),
            'intent' => trim((string) ($input['intent'] ?? 'kb_recomendar_contextual')),
            'keywords' => $this->listFromInput($input['keywords'] ?? []),
            'questions' => $this->listFromInput($input['questions'] ?? []),
            'kb_articles' => $this->kbArticlesFromInput($input['kb_articles'] ?? ($existing['kb_articles'] ?? [])),
            'category_hint' => trim((string) ($input['category_hint'] ?? '')),
            'group_hint' => trim((string) ($input['group_hint'] ?? '')),
            'ticket_template' => (array) ($existing['ticket_template'] ?? []),
            'content' => $content,
        ];
    }

    private function kbArticlesFromInput($value): array
    {
        if (is_array($value)) {
            $items = $value;
        } else {
            $items = preg_split('/[\r\n]+/', (string) $value) ?: [];
        }

        $articles = [];
        foreach ($items as $item) {
            if (is_array($item)) {
                $id = (int) ($item['id'] ?? 0);
                $name = trim((string) ($item['name'] ?? ''));
            } else {
                $line = trim((string) $item);
                if ($line === '') {
                    continue;
                }
                $parts = preg_split('/\s*[|;-]\s*/', $line, 2) ?: [$line];
                $id = ctype_digit((string) ($parts[0] ?? '')) ? (int) $parts[0] : 0;
                $name = $id > 0 ? trim((string) ($parts[1] ?? '')) : $line;
            }

            if ($id <= 0 && $name === '') {
                continue;
            }

            $articles[] = [
                'id' => $id,
                'name' => $name,
            ];
            if (count($articles) >= 20) {
                break;
            }
        }

        return $articles;
    }

    private function normalizeStatus(string $status): string
    {
        $status = strtolower(trim($status));
        if (in_array($status, ['pending', 'pendente', 'review', 'analise'], true)) {
            return 'pending';
        }
        if (in_array($status, ['inactive', 'inativo', 'disabled', '0'], true)) {
            return 'inactive';
        }

        return 'active';
    }
}
