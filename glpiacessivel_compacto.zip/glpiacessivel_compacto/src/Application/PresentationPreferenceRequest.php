<?php

declare(strict_types=1);

namespace GlpiPlugin\Glpiacessivel\Application;

/** Strict request projection: clients cannot nominate another account or key. */
final class PresentationPreferenceRequest
{
    public const CONTRACT = 'presentation_preference';
    public const VERSION = 1;
    public const MAX_BODY_BYTES = 1024;

    public static function mode(string $raw, int $contentLength = 0): string
    {
        if ($contentLength < 0 || $contentLength > self::MAX_BODY_BYTES || $raw === '' || strlen($raw) > self::MAX_BODY_BYTES) {
            throw new \InvalidArgumentException('invalid_request');
        }
        $input = json_decode($raw, true, 4, JSON_THROW_ON_ERROR);
        if (!is_array($input) || array_is_list($input) || count($input) !== 3) {
            throw new \InvalidArgumentException('invalid_request');
        }
        foreach (array_keys($input) as $key) {
            if (!in_array($key, ['contract', 'version', 'mode'], true)) {
                throw new \InvalidArgumentException('invalid_request');
            }
        }
        if (
            ($input['contract'] ?? null) !== self::CONTRACT
            || ($input['version'] ?? null) !== self::VERSION
            || !in_array($input['mode'] ?? null, ['simple', 'complete'], true)
        ) {
            throw new \InvalidArgumentException('invalid_request');
        }
        return $input['mode'];
    }
}
