<?php

declare(strict_types=1);

namespace GlpiPlugin\Glpiacessivel\Application;

final class FeatureReleaseCatalog
{
    /** @return array<string,array{label:string,description:string,module:string,introduced:string}> */
    public static function all(): array
    {
        return [
            'presentation_simple_mode' => ['label' => 'Modo simples no detalhe do chamado', 'description' => 'Permite escolher uma apresentação com menos blocos abertos por vez, sem remover funcionalidades nem alterar permissões. O modo completo permanece disponível.', 'module' => 'tickets', 'introduced' => '0.4.18-beta.61'],
            'tickets.mass_status' => ['label' => 'Alterar status em massa', 'description' => 'Permite preparar e confirmar alterações coletivas oferecidas pelo GLPI.', 'module' => 'tickets', 'introduced' => '0.4.18-beta.2'],
            'tickets.mass_participants' => ['label' => 'Adicionar participantes em massa', 'description' => 'Adiciona participantes pelas ações nativas, sem substituir os responsáveis existentes.', 'module' => 'tickets', 'introduced' => '0.4.18-beta.2'],
            'tickets.interaction_edit' => ['label' => 'Editar acompanhamentos e tarefas salvos', 'description' => 'Liberação básica da edição. Oferece texto simples e visibilidade conforme o conteúdo e os direitos. Para edição completa, libere também a opção de conteúdo formatado para os mesmos perfis.', 'module' => 'tickets', 'introduced' => '0.4.18-beta.9'],
            'tickets.interaction_rich_edit' => ['label' => 'Editar conteúdo formatado de acompanhamentos e tarefas', 'description' => 'Inclui o editor e a seleção de arquivos do GLPI no formulário do portal para alterar texto, imagens e visibilidade autorizados. Exige a edição de interações liberada e não libera a inclusão.', 'module' => 'tickets', 'introduced' => '0.4.18-beta.53'],
            'tickets.interaction_rich_add' => ['label' => 'Adicionar acompanhamentos e tarefas com formatação', 'description' => 'Inclui o editor e a seleção de arquivos do GLPI nos formulários do portal, mantendo os campos já disponíveis. Exige permissão nativa de criar, independentemente da edição. Sem a liberação, os campos simples continuam disponíveis.', 'module' => 'tickets', 'introduced' => '0.4.18-beta.55'],
            'tickets.clipboard_images' => ['label' => 'Colar imagens como anexos', 'description' => 'Adiciona imagens coladas ao formulário. O upload comum continua disponível.', 'module' => '', 'introduced' => '0.4.18-beta.9'],
            'tickets.description_preview' => ['label' => 'Prévia da descrição na lista', 'description' => 'Mostra a descrição pela rota nativa autorizada sem abrir o detalhe.', 'module' => 'tickets', 'introduced' => '0.4.18-beta.9'],
            'tickets.header_sort' => ['label' => 'Ordenar pelos cabeçalhos', 'description' => 'Acrescenta atalhos nas pesquisas simples, preservando a ordenação normal.', 'module' => 'tickets', 'introduced' => '0.4.18-beta.9'],
            'tickets.native_refresh' => ['label' => 'Atualização automática da lista', 'description' => 'Usa o intervalo nativo com proteção de foco e rascunhos; a atualização manual permanece.', 'module' => 'tickets', 'introduced' => '0.4.18-beta.9'],
            'tickets.tags_view' => ['label' => 'Visualizar etiquetas nos chamados', 'description' => 'Exibe etiquetas e suas cores quando o plugin Tag e seu contrato de leitura são compatíveis.', 'module' => 'tickets', 'introduced' => '0.4.18-beta.16'],
            'tickets.tags_edit' => ['label' => 'Acesso à edição nativa de etiquetas', 'description' => 'Disponibiliza continuação na interface convencional para usuários autorizados; não habilita edição local no portal.', 'module' => 'tickets', 'introduced' => '0.4.18-beta.16'],
            'tickets.tags_column' => ['label' => 'Etiquetas na listagem de chamados', 'description' => 'Apresenta etiquetas na coluna opcional, usando leitura nativa em lote quando compatível.', 'module' => 'tickets', 'introduced' => '0.4.18-beta.17'],
            'tickets.tags_filter' => ['label' => 'Filtrar chamados por etiqueta', 'description' => 'Permite pesquisar uma etiqueta exata pelo contrato nativo autorizado, sem alterar as permissões.', 'module' => 'tickets', 'introduced' => '0.4.18-beta.17'],
            'playbooks.knowledge_scan' => ['label' => 'Varredura retomável da base de conhecimento', 'description' => 'Permite iniciar trabalhos e novos lotes. Consulta, pausa e cancelamento seguro permanecem disponíveis.', 'module' => 'playbooks', 'introduced' => '0.4.18-beta.4'],
            'playbooks.batch_review' => ['label' => 'Aprovar ou rejeitar propostas em lote', 'description' => 'Disponibiliza decisões coletivas com revisão. A decisão individual continua disponível.', 'module' => 'playbooks', 'introduced' => '0.4.18-beta.5'],
            'reports.native_links' => ['label' => 'Acessos às estatísticas convencionais', 'description' => 'Exibe links para relatórios nativos, que continuam exigindo permissão de estatísticas.', 'module' => 'cockpit', 'introduced' => '0.4.18-beta.9'],
            'reports.cockpit_statistics' => ['label' => 'Estatísticas nativas acessíveis no Cockpit', 'description' => 'Consulta contagens nativas homologadas no portal, preservando perfil, entidade e permissão de estatísticas.', 'module' => 'cockpit', 'introduced' => '0.4.18-beta.14'],
        ];
    }

    /** @return array<string,array{mode:string,profile_ids:int[]}> */
    public static function seedForOrigin(?string $version): array
    {
        $known = is_string($version) && preg_match('/\A0\.4\.(?:17-beta\.7|18-beta\.(?:[1-9]|1[01]))\z/D', $version) === 1;
        $features = [];
        foreach (self::all() as $id => $definition) {
            $features[$id] = ['mode' => $known && version_compare((string) $version, $definition['introduced'], '>=') ? 'all' : 'off', 'profile_ids' => []];
        }
        return $features;
    }
}
