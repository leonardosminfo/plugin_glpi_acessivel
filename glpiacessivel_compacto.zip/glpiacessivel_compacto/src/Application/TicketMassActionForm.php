<?php

declare(strict_types=1);

namespace GlpiPlugin\Glpiacessivel\Application;

use GlpiPlugin\Glpiacessivel\Support\I18n;

/** Validate a projection of controls offered by the native renderer. */
final class TicketMassActionForm
{
    public function values(array $form, array $submitted): array
    {
        $pairs = [];
        $review = [];
        $names = [];
        foreach ($submitted as $index => $value) {
            if (!ctype_digit((string) $index) || !isset($form['controls'][(int) $index])) {
                throw new \InvalidArgumentException('mass_form_invalid');
            }
        }
        foreach ($form['controls'] as $index => $control) {
            if (isset($names[$control['name']])) {
                throw new \InvalidArgumentException('mass_form_ambiguous');
            }
            $names[$control['name']] = true;
            if (!empty($control['disabled'])) {
                continue;
            }
            $value = $submitted[$index] ?? '';
            if (!is_string($value) || strlen($value) > 4096 || !empty($control['multiple'])) {
                throw new \InvalidArgumentException('mass_form_invalid');
            }
            if (!empty($control['required']) && trim($value) === '') {
                throw new \InvalidArgumentException('mass_form_required');
            }
            $label = $value;
            if ($control['type'] === 'select') {
                $offered = false;
                foreach ($control['options'] as $option) {
                    if ($option['value'] === $value && empty($option['disabled'])) {
                        $offered = true;
                        $label = $option['label'];
                    }
                }
                if (!$offered) {
                    throw new \InvalidArgumentException('mass_form_value_not_offered');
                }
            } elseif (in_array($control['type'], ['checkbox', 'radio'], true)) {
                if ($value === '') {
                    continue;
                }
                if ($value !== $control['value']) {
                    throw new \InvalidArgumentException('mass_form_value_not_offered');
                }
            } elseif ($control['type'] === 'email' && $value !== '' && filter_var($value, FILTER_VALIDATE_EMAIL) === false) {
                throw new \InvalidArgumentException('mass_form_email_invalid');
            } elseif ($control['type'] === 'number' && $value !== '' && !is_numeric($value)) {
                throw new \InvalidArgumentException('mass_form_number_invalid');
            }
            $pairs[] = rawurlencode($control['name']) . '=' . rawurlencode($value);
            $name = $control['name'];
            $heading = match (true) {
                $name === 'status' => 'Status do chamado',
                $name === 'id_field' => 'Campo do chamado',
                $name === 'actortype' => 'Papel no chamado',
                str_ends_with($name, '[_type]') => 'Tipo de participante',
                str_ends_with($name, '_id]') => 'Participante',
                str_contains($name, 'use_notif') => 'Receber notificações',
                str_contains($name, 'email') => 'Endereço de e-mail',
                default => 'Parâmetro da ação: %s',
            };
            $review[] = sprintf(I18n::translate($heading), $name) . ': ' . $label;
        }
        parse_str(implode('&', $pairs), $values);
        return ['values' => $values, 'review' => $review];
    }
}
