<?php

declare(strict_types=1);

namespace GlpiPlugin\Glpiacessivel\Application;

/** Fixed, packaged editorial content; no query parameter selects a file. */
final class ManualCatalog
{
    public function load(): array
    {
        $path = dirname(__DIR__, 2) . '/resources/manual/pt-BR.json';
        $content = @file_get_contents($path, false, null, 0, 2097153);
        if (!is_string($content) || strlen($content) > 2097152) {
            throw new \RuntimeException('manual_content_unavailable');
        }
        return self::validate(json_decode($content, true, 64, JSON_THROW_ON_ERROR));
    }

    public static function validate(mixed $manual): array
    {
        if (!is_array($manual)) {
            throw new \InvalidArgumentException('manual_content_invalid');
        }
        foreach (['title', 'lead', 'manual_version', 'covered_plugin_version', 'revision', 'credit'] as $key) {
            if (!is_string($manual[$key] ?? null) || trim($manual[$key]) === '' || strlen($manual[$key]) > 4000) {
                throw new \InvalidArgumentException('manual_metadata_invalid');
            }
        }
        if (!is_array($manual['sections'] ?? null) || $manual['sections'] === [] || count($manual['sections']) > 150) {
            throw new \InvalidArgumentException('manual_sections_invalid');
        }
        $seen = ['manual-title' => true, 'manual-summary' => true, 'manual-content' => true,
            'manual-context-title' => true, 'manual-reading-context-title' => true];
        foreach ($manual['sections'] as $section) {
            if (
                !is_array($section) || !is_string($section['id'] ?? null)
                || preg_match('/\A[a-z][a-z0-9-]{0,79}\z/D', $section['id']) !== 1
                || isset($seen[$section['id']]) || !is_string($section['title'] ?? null)
                || trim($section['title']) === '' || strlen($section['title']) > 300
                || !in_array($section['rule'] ?? null, ManualAvailabilitySnapshot::rules(), true)
                || !in_array($section['level'] ?? null, [2, 3], true)
                || !is_string($section['html'] ?? null) || strlen($section['html']) > 131072
            ) {
                throw new \InvalidArgumentException('manual_section_invalid');
            }
            $seen[$section['id']] = true;
        }
        return $manual;
    }
}
