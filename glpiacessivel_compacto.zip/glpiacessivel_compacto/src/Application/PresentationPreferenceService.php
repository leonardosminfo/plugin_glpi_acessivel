<?php

declare(strict_types=1);

namespace GlpiPlugin\Glpiacessivel\Application;

/** A presentation preference, never an operational permission or search state. */
final class PresentationPreferenceService
{
    public const FEATURE = 'presentation_simple_mode';
    public const CONTEXT = 'plugin:glpiacessivel:ui';
    private const KEY_PREFIX = 'presentation_mode_user_';

    private \Closure $reader;
    private \Closure $writer;
    private \Closure $currentUser;
    private \Closure $released;
    private \Closure $available;

    /**
     * The optional adapters keep tests independent of GLPI's global classes.
     * Production always derives the key from the authenticated account.
     *
     * @param callable(string):array<string,mixed>|null $reader
     * @param callable(string,string):void|null $writer
     * @param callable():int|null $currentUser
     * @param callable():bool|null $released
     * @param callable():bool|null $available
     */
    public function __construct(
        ?callable $reader = null,
        ?callable $writer = null,
        ?callable $currentUser = null,
        ?callable $released = null,
        ?callable $available = null
    ) {
        $this->reader = \Closure::fromCallable($reader ?? static function (string $key): array {
            return \Config::getConfigurationValues(self::CONTEXT, [$key]);
        });
        $this->writer = \Closure::fromCallable($writer ?? static function (string $key, string $mode): void {
            \Config::setConfigurationValues(self::CONTEXT, [$key => $mode]);
        });
        $this->currentUser = \Closure::fromCallable($currentUser ?? static function (): int {
            return is_callable(['Session', 'getLoginUserID']) ? (int) \Session::getLoginUserID() : 0;
        });
        $this->released = \Closure::fromCallable($released ?? static function (): bool {
            return FeatureReleasePolicy::allows(self::FEATURE, true);
        });
        $this->available = \Closure::fromCallable($available ?? static function (): bool {
            return is_callable(['Config', 'getConfigurationValues'])
                && is_callable(['Config', 'setConfigurationValues']);
        });
    }

    /** @return array{enabled:bool,preferred_mode:string,storage_available:bool} */
    public function snapshot(bool $supported = true): array
    {
        $fallback = ['enabled' => false, 'preferred_mode' => 'complete', 'storage_available' => false];
        if (!$supported) {
            return $fallback;
        }
        try {
            $userId = ($this->currentUser)();
            if ($userId <= 0 || !($this->released)() || !($this->available)()) {
                return $fallback;
            }
            $key = self::KEY_PREFIX . $userId;
            $values = ($this->reader)($key);
            $mode = $values[$key] ?? 'complete';
            return [
                'enabled' => true,
                'preferred_mode' => self::isMode($mode) ? $mode : 'complete',
                'storage_available' => true,
            ];
        } catch (\Throwable) {
            return $fallback;
        }
    }

    /** Save only the logged-in account's preference and confirm native readback. */
    public function save(string $mode): string
    {
        if (!self::isMode($mode)) {
            throw new \InvalidArgumentException('invalid_mode');
        }
        $userId = ($this->currentUser)();
        if ($userId <= 0 || !($this->released)()) {
            throw new \DomainException('presentation_not_available');
        }
        if (!($this->available)()) {
            throw new \RuntimeException('presentation_storage_unavailable');
        }

        $key = self::KEY_PREFIX . $userId;
        ($this->writer)($key, $mode);
        $values = ($this->reader)($key);
        if (($values[$key] ?? null) !== $mode) {
            // A native API may return normally without confirming persistence.
            // The caller must not announce a successful save in this case.
            throw new \RuntimeException('presentation_preference_not_confirmed');
        }
        return $mode;
    }

    private static function isMode(mixed $mode): bool
    {
        return $mode === 'simple' || $mode === 'complete';
    }
}
