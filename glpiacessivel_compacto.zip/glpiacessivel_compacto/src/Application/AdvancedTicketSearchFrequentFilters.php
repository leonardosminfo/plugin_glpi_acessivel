<?php

declare(strict_types=1);

namespace GlpiPlugin\Glpiacessivel\Application;

use GlpiPlugin\Glpiacessivel\Domain\Ticket\NativeSearchValidationException;

/**
 * Shared presentation metadata contract for an applied advanced search.
 * Criteria are already compiled and separately authorized against the native
 * catalog. This validator neither builds criteria nor grants access to a tag.
 */
final class AdvancedTicketSearchFrequentFilters
{
    /** @param array<string,mixed> $filters
     * @return array{status:string,group_id:int,tag_id?:int}
     */
    public static function validate(array $filters): array
    {
        $status = $filters['status'] ?? null;
        $groupId = $filters['group_id'] ?? null;
        if (
            !in_array(array_keys($filters), [['status', 'group_id'], ['status', 'group_id', 'tag_id']], true)
            || !is_string($status)
            || !TicketStatusFilter::isValid($status)
            || !is_int($groupId)
            || $groupId < 0
        ) {
            throw new NativeSearchValidationException(
                'native_search_frequent_filters_invalid',
                'advanced.frequent_filters'
            );
        }

        $validated = ['status' => $status, 'group_id' => $groupId];
        if (array_key_exists('tag_id', $filters)) {
            if (!is_int($filters['tag_id']) || $filters['tag_id'] < 0 || $filters['tag_id'] > 2147483647) {
                throw new NativeSearchValidationException('native_search_tag_unsupported', 'advanced.tag_id');
            }
            $validated['tag_id'] = $filters['tag_id'];
        }
        return $validated;
    }
}
