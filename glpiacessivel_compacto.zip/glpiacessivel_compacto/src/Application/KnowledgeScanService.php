<?php

declare(strict_types=1);

namespace GlpiPlugin\Glpiacessivel\Application;

use GlpiPlugin\Glpiacessivel\Domain\Knowledge\KnowledgeSourceReader;
use GlpiPlugin\Glpiacessivel\Infrastructure\Repository\PlaybookRepository;

/** Finite manual jobs. Source reads never publish a playbook. */
final class KnowledgeScanService
{
    public function __construct(private KnowledgeSourceReader $reader, private PlaybookRepository $repository, private \Closure $generator)
    {
    }

    public static function context(): array
    {
        return [
            'user_id' => (int) ($_SESSION['glpiID'] ?? 0),
            'profile_id' => (int) ($_SESSION['glpiactiveprofile']['id'] ?? 0),
            'entity_id' => (int) ($_SESSION['glpiactive_entity'] ?? -1),
            'recursive' => !empty($_SESSION['glpiactive_entity_recursive']),
        ];
    }

    public static function installationId(): string
    {
        global $CFG_GLPI, $DB;
        return hash('sha256', (string) ($CFG_GLPI['url_base'] ?? '') . '|'
            . (defined('GLPI_ROOT') ? GLPI_ROOT : dirname(__DIR__, 2)) . '|'
            . (string) ($DB->dbdefault ?? ''));
    }

    public function start(array $options): array
    {
        $this->requireReview();
        $options = [
            'limit' => min(5000, max(1, (int) ($options['limit'] ?? 200))),
            'batch_size' => min(50, max(1, (int) ($options['batch_size'] ?? 25))),
            'faq_only' => (bool) ($options['faq_only'] ?? $options['public_only'] ?? false),
            'publication' => in_array($options['publication'] ?? 'all', ['all', 'published', 'unpublished'], true)
                ? ($options['publication'] ?? 'all') : 'all',
            'high_water' => $this->reader->highWaterMark(),
            'context' => self::context(),
            'source_scope' => 'native_editorial',
            'adapter_version' => 1,
        ];
        $id = $this->repository->createJob('kb_editorial', $options);
        if ($id <= 0) {
            throw new \RuntimeException('knowledge_job_not_created');
        }
        return $this->continue($id);
    }

    public function continue(int $id): array
    {
        $this->requireReview();
        $context = self::context();
        $job = $this->repository->getJob($id);
        if ($job === null) {
            throw new \RuntimeException('knowledge_job_unavailable');
        }
        if (in_array($job['status'] ?? '', ['completed', 'cancelled', 'partial'], true)) {
            return $this->result($job);
        }
        $job = $this->repository->withJobBatch($id, $context, (int) ($job['revision'] ?? 0), function (array $claimed) use ($context): array {
            $options = (array) ($claimed['options'] ?? json_decode((string) ($claimed['options_json'] ?? '{}'), true));
            $cursor = (array) ($claimed['cursor'] ?? json_decode((string) ($claimed['cursor_json'] ?? '{}'), true));
            $counts = (array) ($cursor['counts'] ?? []);
            foreach (['examined', 'processed', 'suggestions', 'skipped', 'failed'] as $key) {
                $counts[$key] = (int) ($counts[$key] ?? 0);
            }
            $remaining = max(0, (int) ($options['limit'] ?? 200) - $counts['examined']);
            if ($remaining === 0) {
                return ['cursor' => $cursor, 'counts' => $counts, 'status' => 'partial', 'message' => 'Limite total atingido; inicie outra varredura com limite maior para ampliar a cobertura.'];
            }
            // Scan all IDs: creation filters must not hide retirement of existing sources.
            $page = $this->reader->nextEditorialPage(
                (int) ($cursor['after'] ?? 0),
                (int) ($options['high_water'] ?? 0),
                min($remaining, (int) ($options['batch_size'] ?? 25)),
                false,
                'all'
            );
            if (($page['status'] ?? '') !== 'ok') {
                throw new \RuntimeException('knowledge_page_failed');
            }
            $counts['examined'] += (int) ($page['examined'] ?? 0);
            foreach ((array) ($page['sources'] ?? []) as $source) {
                if (($source['publication'] ?? 'unknown') === 'unknown') {
                    if (($source['reason'] ?? '') === 'read_denied') {
                        $counts['skipped']++;
                    } else {
                        $counts['failed']++;
                    }
                    continue;
                }
                $counts['processed']++;
                $identity = ['installation_id' => self::installationId(), 'source_type' => 'KnowbaseItem', 'source_id' => (int) $source['id']];
                $this->repository->upsertKnowledgeSource($identity, $source);
                $linked = $this->repository->findPlaybooksBySource((int) $source['id']);
                $evidence = [array_merge($identity, [
                    'text_hash' => (string) ($source['text_hash'] ?? ''),
                    'publication_hash' => (string) ($source['publication_hash'] ?? ''),
                    'publication' => (string) $source['publication'], 'validity' => (string) $source['validity'],
                    'role' => 'required',
                ])];
                if ($linked !== []) {
                    foreach ($linked as $playbook) {
                        $this->reconcile($claimed, $playbook, $source, $evidence, $counts);
                    }
                } elseif (
                    ($source['publication'] ?? '') === 'published' && ($source['validity'] ?? '') === 'current'
                    && (!$options['faq_only'] || !empty($source['is_faq']))
                    && in_array($options['publication'] ?? 'all', ['all', 'published'], true)
                ) {
                    $payload = ($this->generator)($source);
                    if ($payload !== null) {
                        $this->propose((int) $claimed['id'], 'create', 0, 0, $payload, $evidence, 'Fonte publicada disponível para curadoria.', $counts);
                    } else {
                        $counts['skipped']++;
                    }
                }
            }
            if (self::context() !== $context || !$this->reader->canReview()) {
                throw new \RuntimeException('knowledge_context_changed');
            }
            $cursor['after'] = (int) ($page['cursor'] ?? $cursor['after'] ?? 0);
            $cursor['counts'] = $counts;
            $hasMore = !empty($page['has_more']);
            $status = $hasMore ? ($counts['examined'] >= (int) $options['limit'] ? 'partial' : 'paused')
                : ($counts['failed'] > 0 ? 'partial' : 'completed');
            return ['cursor' => $cursor, 'counts' => $counts, 'status' => $status,
                'message' => $status === 'completed' ? 'Escopo inicial percorrido; propostas aguardam revisão.' : 'Lote preservado; nenhuma orientação foi publicada automaticamente.'];
        });
        if ($job === null) {
            throw new \RuntimeException('knowledge_job_conflict');
        }
        return $this->result($job);
    }

    public function stop(int $id, bool $cancel): array
    {
        $this->requireReview();
        $job = $this->repository->getJob($id);
        if ($job === null || in_array($job['status'] ?? '', ['completed', 'cancelled', 'partial'], true)) {
            throw new \RuntimeException('knowledge_job_unavailable');
        }
        $job = $this->repository->withJobBatch($id, self::context(), (int) ($job['revision'] ?? 0), static function (array $claimed) use ($cancel): array {
            $cursor = (array) ($claimed['cursor'] ?? json_decode((string) ($claimed['cursor_json'] ?? '{}'), true));
            return ['cursor' => $cursor, 'counts' => (array) ($cursor['counts'] ?? []),
                'status' => $cancel ? 'cancelled' : 'paused', 'message' => 'Propostas anteriores preservadas.'];
        });
        if ($job === null) {
            throw new \RuntimeException('knowledge_job_conflict');
        }
        return $this->result($job);
    }

    private function reconcile(array $job, array $playbook, array $source, array $evidence, array &$counts): void
    {
        if ((int) ($playbook['entities_id'] ?? self::context()['entity_id']) !== self::context()['entity_id']) {
            $counts['skipped']++;
            return;
        }
        $dependencies = $this->repository->getPlaybookSources((int) $playbook['id']);
        if ($dependencies === []) {
            foreach ((array) ($playbook['kb_articles'] ?? []) as $reference) {
                if (!is_array($reference) || (int) ($reference['id'] ?? 0) <= 0) {
                    $counts['skipped']++;
                    return;
                }
                $dependencies[] = ['installation_id' => self::installationId(), 'source_type' => 'KnowbaseItem',
                    'source_id' => (int) $reference['id'], 'text_hash' => '', 'role' => 'required'];
            }
        }
        $allEvidence = [];
        foreach ($dependencies as $dependency) {
            if (($dependency['installation_id'] ?? '') !== self::installationId()) {
                $counts['skipped']++;
                return;
            }
            $id = (int) ($dependency['source_id'] ?? 0);
            $current = $id === (int) $source['id'] ? $source : $this->reader->readForEditorialReview($id);
            if (($current['publication'] ?? 'unknown') === 'unknown') {
                $counts['skipped']++;
                return;
            }
            $this->repository->upsertKnowledgeSource([
                'installation_id' => self::installationId(), 'source_type' => 'KnowbaseItem', 'source_id' => $id,
            ], $current);
            $allEvidence[] = array_merge($dependency, [
                'source_id' => $id, 'text_hash' => (string) ($current['text_hash'] ?? ''),
                'publication_hash' => (string) ($current['publication_hash'] ?? ''),
                'publication' => (string) $current['publication'], 'validity' => (string) $current['validity'],
            ]);
        }
        $allEvidence = $allEvidence === [] ? $evidence : $allEvidence;
        $action = '';
        $payload = $playbook;
        $payload['title'] = (string) ($playbook['name'] ?? '');
        $reason = '';
        if (($source['publication'] ?? '') === 'unpublished') {
            if ((int) ($playbook['is_active'] ?? 0) === 1) {
                $action = 'inactivate';
                $reason = 'Fonte vinculada observada como não publicada; revisar as dependências.';
            }
        } elseif (($source['validity'] ?? '') !== 'current') {
            $action = 'review';
            $reason = 'Revisão temporal; não é evidência de retirada editorial.';
        } else {
            $matching = array_values(array_filter($dependencies, static fn(array $row): bool => (int) ($row['source_id'] ?? 0) === (int) $source['id']));
            $changed = $matching === []
                || (string) ($matching[0]['text_hash'] ?? '') !== (string) ($source['text_hash'] ?? '')
                || (string) ($matching[0]['publication_hash'] ?? '') !== (string) ($source['publication_hash'] ?? '');
            if ($changed) {
                $action = 'update';
                $reason = 'Revisão da fonte ou vínculo legado; preservar edição manual até aprovação.';
                // Do not overwrite a mixed summary with one article's text.
                if (count($allEvidence) === 1 && ($playbook['origin_type'] ?? '') === 'kb_derived') {
                    $payload = ($this->generator)($source) ?? $payload;
                }
            } elseif ((int) ($playbook['is_active'] ?? 0) === 0 && ($playbook['origin_type'] ?? '') === 'kb_derived') {
                $action = 'reactivate';
                $reason = 'Fonte publicada; reativação requer decisão editorial explícita.';
            }
        }
        if ($action !== '') {
            $this->propose((int) $job['id'], $action, (int) $playbook['id'], (int) ($playbook['revision'] ?? 0), $payload, $allEvidence, $reason, $counts);
        }
    }

    private function propose(int $jobId, string $action, int $target, int $revision, array $payload, array $evidence, string $reason, array &$counts): void
    {
        usort($evidence, static fn(array $a, array $b): int => (int) $a['source_id'] <=> (int) $b['source_id']);
        $payload = array_merge($payload, ['action' => $action, 'target_playbook_id' => $target,
            'expected_revision' => $revision, 'evidence' => $evidence, 'reason' => $reason,
            'dedupe_key' => hash('sha256', json_encode([self::context()['entity_id'], $action, $target, $revision, $evidence, 1], JSON_UNESCAPED_UNICODE | JSON_THROW_ON_ERROR))]);
        $payload['content'] = array_merge((array) ($payload['content'] ?? []), ['editorial_reason' => $reason]);
        $id = $this->repository->createEditorialSuggestion($jobId, $payload);
        if ($id > 0) {
            $counts['suggestions']++;
        }
    }

    private function result(array $job): array
    {
        $cursor = (array) ($job['cursor'] ?? json_decode((string) ($job['cursor_json'] ?? '{}'), true));
        return array_merge(['job_id' => (int) ($job['id'] ?? 0), 'status' => (string) ($job['status'] ?? 'failed'),
            'processed' => (int) ($job['processed_count'] ?? 0), 'suggestions' => (int) ($job['suggestions_count'] ?? 0)], (array) ($cursor['counts'] ?? []));
    }

    private function requireReview(): void
    {
        if (!$this->reader->canReview()) {
            throw new \RuntimeException('knowledge_review_forbidden');
        }
    }
}
