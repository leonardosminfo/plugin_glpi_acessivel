<?php

declare(strict_types=1);

namespace GlpiPlugin\Glpiacessivel\Application;

/** Optional public Tag integration. No parallel storage or write processor. */
interface TicketTagsGateway
{
    /** @return array{state:string,reason:string,native_url:string,can_edit:bool,plugin_version:string} */
    public function inspect(int $ticketId): array;

    /** @return array<int,array{id:int,name:string,color:mixed}> */
    public function read(int $ticketId): array;
}
