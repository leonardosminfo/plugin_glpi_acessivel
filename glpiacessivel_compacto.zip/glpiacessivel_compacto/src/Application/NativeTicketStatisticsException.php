<?php

declare(strict_types=1);

namespace GlpiPlugin\Glpiacessivel\Application;

/** A finite reason, never a native exception message or sensitive report payload. */
final class NativeTicketStatisticsException extends \RuntimeException
{
    public function __construct(public readonly string $reason, public readonly ?string $field = null)
    {
        parent::__construct($reason);
    }
}
