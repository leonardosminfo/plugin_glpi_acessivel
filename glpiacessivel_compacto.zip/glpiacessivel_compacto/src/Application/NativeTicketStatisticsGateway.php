<?php

declare(strict_types=1);

namespace GlpiPlugin\Glpiacessivel\Application;

/** Read-only native statistics boundary. No alternative calculation is permitted. */
interface NativeTicketStatisticsGateway
{
    public function capabilities(): array;

    public function pageSize(): int;

    public function context(): array;

    public function items(string $mode, string $date1, string $date2): array;

    public function data(string $mode, string $date1, string $date2, array $nativeItem): array;
}
