<?php

declare(strict_types=1);

namespace GlpiPlugin\Glpiacessivel\Application;

/** Bounded per-tab form intent. This is not a database lock/version guarantee. */
final class InteractionEditState
{
    private const KEY = 'glpiacessivel_interaction_edits_v1';

    /** @param array<string,mixed> $baseline */
    public function issue(array $baseline, string $revision): string
    {
        $states = $this->states();
        $token = bin2hex(random_bytes(24));
        $states[$token] = ['baseline' => $baseline, 'revision' => $revision, 'expires' => time() + 1800];
        $_SESSION[self::KEY] = array_slice($states, -10, null, true);
        return $token;
    }

    /** @return array<string,mixed> */
    public function resolve(string $token, string $revision): array
    {
        $state = $this->states()[$token] ?? null;
        if (!is_array($state) || !hash_equals((string) $state['revision'], $revision)) {
            throw new \DomainException('interaction_form_expired');
        }
        return $state['baseline'];
    }

    public function consume(string $token): void
    {
        unset($_SESSION[self::KEY][$token]);
    }

    /** @return array<string,array<string,mixed>> */
    private function states(): array
    {
        $states = (array) ($_SESSION[self::KEY] ?? []);
        foreach ($states as $token => $state) {
            if (!is_array($state) || (int) ($state['expires'] ?? 0) < time()) {
                unset($states[$token]);
            }
        }
        $_SESSION[self::KEY] = $states;
        return $states;
    }
}
