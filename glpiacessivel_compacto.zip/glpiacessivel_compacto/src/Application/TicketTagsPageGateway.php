<?php

declare(strict_types=1);

namespace GlpiPlugin\Glpiacessivel\Application;

interface TicketTagsPageGateway
{
    /** @param list<int> $ticketIds @return array<int,list<array{id:int,name:string,color:mixed}>> */
    public function read(array $ticketIds): array;
}
