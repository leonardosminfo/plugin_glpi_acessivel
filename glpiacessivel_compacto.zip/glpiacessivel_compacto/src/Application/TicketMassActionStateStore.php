<?php

declare(strict_types=1);

namespace GlpiPlugin\Glpiacessivel\Application;

/** Session-bound, short-lived preparation; browser IDs are never authority. */
final class TicketMassActionStateStore
{
    private const KEY = 'glpiacessivel_mass_actions_v1';
    private const TTL = 300;
    private const LIMIT = 1000;
    private const PAGE_LIMIT = 20;

    /** Called when the native context changes, never by read-only presentation. */
    public function observeContext(string $revision): void
    {
        $this->assertRevision($revision);
        $state = $this->state();
        if (($state['revision'] ?? '') !== $revision || !isset($state['pages'])) {
            $_SESSION[self::KEY] = ['secret' => bin2hex(random_bytes(32)), 'revision' => $revision,
                'pages' => [], 'flows' => []];
        }
    }

    public function beginPage(string $revision): string
    {
        $this->observeContext($revision);
        $state = $this->state();
        $pages = array_filter($state['pages'], static fn(int $expiry): bool => $expiry >= time());
        while (count($pages) >= self::PAGE_LIMIT) {
            array_shift($pages);
        }
        $page = bin2hex(random_bytes(16));
        $pages[$page] = time() + self::TTL;
        $state['pages'] = $pages;
        $_SESSION[self::KEY] = $state;
        return $page;
    }

    /** @param array<int,mixed> $ids */
    public function signPage(array $ids, string $revision, string $generation): string
    {
        $ids = $this->ids($ids);
        if ($ids === []) {
            return '';
        }
        $state = $this->state();
        if (
            !isset($state['secret']) || ($state['revision'] ?? '') !== $revision
            || ($state['pages'][$generation] ?? 0) < time()
        ) {
            return '';
        }
        $payload = $this->encode(json_encode([
            'ids' => $ids, 'revision' => $revision, 'page' => $generation, 'expires' => time() + self::TTL,
        ], JSON_THROW_ON_ERROR));
        return $payload . '.' . hash_hmac('sha256', $payload, $state['secret']);
    }

    /** @param array<int,mixed> $selected @return int[] */
    public function verifyPage(string $proof, array $selected, string $revision): array
    {
        $this->assertRevision($revision);
        if (strlen($proof) > 32768 || preg_match('/\A([A-Za-z0-9_-]+)\.([a-f0-9]{64})\z/D', $proof, $m) !== 1) {
            throw new \RuntimeException('mass_selection_expired');
        }
        $state = $this->state();
        $secret = $state['secret'] ?? '';
        if ($secret === '' || !hash_equals(hash_hmac('sha256', $m[1], $secret), $m[2])) {
            throw new \RuntimeException('mass_selection_expired');
        }
        $raw = base64_decode(strtr($m[1], '-_', '+/'), true);
        $data = is_string($raw) ? json_decode($raw, true) : null;
        if (
            !is_array($data) || ($data['revision'] ?? '') !== $revision
            || ($state['revision'] ?? '') !== $revision
            || !is_string($data['page'] ?? null) || ($state['pages'][$data['page']] ?? 0) < time()
            || !is_int($data['expires'] ?? null) || $data['expires'] < time()
        ) {
            throw new \RuntimeException('mass_selection_expired');
        }
        $ids = $this->ids($selected);
        $allowed = $this->ids((array) ($data['ids'] ?? []));
        if ($ids === [] || array_diff($ids, $allowed) !== []) {
            throw new \RuntimeException('mass_selection_invalid');
        }
        return $ids;
    }

    /** @param int[] $ids @param array<string,mixed> $native */
    public function create(array $ids, string $revision, array $native): string
    {
        $this->assertRevision($revision);
        $state = $this->state();
        if (($state['revision'] ?? '') !== $revision) {
            throw new \RuntimeException('mass_context_invalid');
        }
        $token = bin2hex(random_bytes(24));
        $flows = array_filter(
            (array) ($state['flows'] ?? []),
            static fn($flow): bool => is_array($flow) && ($flow['expires'] ?? 0) >= time()
        );
        while (count($flows) >= 5) {
            array_shift($flows);
        }
        $flows[$token] = ['ids' => $this->ids($ids), 'revision' => $revision,
            'expires' => time() + self::TTL, 'renewals' => 0,
            'stage' => 'catalog', 'status' => 'ready', 'native' => $native];
        $state['flows'] = $flows;
        $_SESSION[self::KEY] = $state;
        return $token;
    }

    /** @return array<string,mixed> */
    public function resolve(string $token, string $revision): array
    {
        $this->assertRevision($revision);
        $state = $this->state();
        $flow = $state['flows'][$token] ?? null;
        if (
            preg_match('/\A[a-f0-9]{48}\z/D', $token) !== 1 || !is_array($flow)
            || ($flow['expires'] ?? 0) < time() || ($flow['revision'] ?? '') !== $revision
            || ($state['revision'] ?? '') !== $revision
        ) {
            throw new \RuntimeException('mass_selection_expired');
        }
        return $flow;
    }

    /** @param array<string,mixed> $flow */
    public function save(string $token, array $flow): void
    {
        $state = $this->state();
        if (!isset($state['flows'][$token]) || ($state['flows'][$token]['status'] ?? '') === 'cancelled') {
            throw new \RuntimeException('mass_selection_expired');
        }
        if (in_array($flow['status'] ?? '', ['running', 'waiting', 'done', 'unknown'], true)) {
            // A native batch can finish after preparation expires. Keep its result/continuation
            // readable for a fresh bounded window without refreshing it on GET or ready stages.
            $flow['expires'] = time() + self::TTL;
        }
        $state['flows'][$token] = $flow;
        $_SESSION[self::KEY] = $state;
    }

    public function cancel(string $token): void
    {
        $state = $this->state();
        if (!isset($state['flows'][$token]) || ($state['flows'][$token]['status'] ?? '') !== 'ready') {
            throw new \RuntimeException('mass_stage_invalid');
        }
        // Keep a bounded tombstone so GET/back cannot recreate an executable preparation.
        $state['flows'][$token] = array_intersect_key(
            $state['flows'][$token],
            array_flip(['ids', 'revision', 'expires'])
        )
            + ['stage' => 'cancelled', 'status' => 'cancelled'];
        $_SESSION[self::KEY] = $state;
    }

    /** Explicit, limited extension after the caller rechecks the current native ACL. */
    public function extend(string $token, string $revision): array
    {
        $flow = $this->resolve($token, $revision);
        if (!in_array($flow['status'], ['ready', 'waiting'], true) || ($flow['renewals'] ?? 0) >= 10) {
            throw new \RuntimeException('mass_stage_invalid');
        }
        $flow['expires'] = time() + self::TTL;
        $flow['renewals'] = ($flow['renewals'] ?? 0) + 1;
        $this->save($token, $flow);
        return $flow;
    }

    /** @param array<int,mixed> $ids @return int[] */
    private function ids(array $ids): array
    {
        if (count($ids) > self::LIMIT) {
            throw new \RuntimeException('mass_selection_invalid');
        }
        $result = [];
        foreach ($ids as $id) {
            if (
                (!is_int($id) && !is_string($id)) || !ctype_digit((string) $id) || (int) $id < 1
                || isset($result[(int) $id])
            ) {
                throw new \RuntimeException('mass_selection_invalid');
            }
            $result[(int) $id] = (int) $id;
        }
        return array_values($result);
    }

    private function assertRevision(string $revision): void
    {
        if (preg_match('/\A[a-f0-9]{64}\z/D', $revision) !== 1) {
            throw new \RuntimeException('mass_context_invalid');
        }
    }

    private function encode(string $value): string
    {
        return rtrim(strtr(base64_encode($value), '+/', '-_'), '=');
    }

    /** @return array<string,mixed> */
    private function state(): array
    {
        $state = $_SESSION[self::KEY] ?? [];
        return is_array($state) ? $state : [];
    }
}
