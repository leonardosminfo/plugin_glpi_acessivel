<?php

declare(strict_types=1);

namespace GlpiPlugin\Glpiacessivel\Application;

use GlpiPlugin\Glpiacessivel\Infrastructure\Security\GlpiSessionContextSnapshot;

/** Read-only observation, independent of native counters and never a retry. */
final class TicketMassActionVerification
{
    private \Closure $reader;
    private \Closure $context;

    /** Reader must authorize the ticket before returning the requested link's presence. */
    public function __construct(?callable $reader = null, ?callable $context = null)
    {
        $this->reader = $reader === null
            ? \Closure::fromCallable([self::class, 'nativePresence'])
            : \Closure::fromCallable($reader);
        $this->context = $context === null
            ? static fn(): string => (new GlpiSessionContextSnapshot())->snapshot()['revision']
            : \Closure::fromCallable($context);
    }

    /** @param array<string,mixed> $submission @param int[] $ids @return array<string,mixed> */
    public function capture(array $submission, array $ids): array
    {
        $target = $this->target($submission);
        if ($target === null) {
            return [];
        }
        $ids = $this->ids($ids);
        $revision = $this->revision();
        $presence = [];
        foreach ($ids as $id) {
            $presence[$id] = $revision === null ? null : $this->presence($id, $target, $revision);
        }
        return ['target' => $target, 'ids' => $ids, 'revision' => $revision, 'presence' => $presence];
    }

    /** @param array<string,mixed> $submission @param int[] $ids @param array<string,mixed> $before */
    public function verify(array $submission, array $ids, array $before): array
    {
        $target = $this->target($submission);
        $counts = array_fill_keys(['preexisting', 'confirmed', 'not_confirmed', 'unavailable'], 0);
        $result = ['applicable' => $target !== null, 'counts' => $counts, 'items' => []];
        if ($target === null) {
            return $result;
        }
        $ids = $this->ids($ids);
        $revision = $this->revision();
        $valid = $revision !== null && $revision === ($before['revision'] ?? null)
            && $target === ($before['target'] ?? null) && $ids === ($before['ids'] ?? null);
        foreach ($ids as $id) {
            $old = $before['presence'][$id] ?? null;
            $now = $valid ? $this->presence($id, $target, $revision) : null;
            $category = !is_bool($old) || !is_bool($now) ? 'unavailable'
                : (!$now ? 'not_confirmed' : ($old ? 'preexisting' : 'confirmed'));
            ++$result['counts'][$category];
            $result['items'][] = ['id' => $id, 'category' => $category];
        }
        if ($this->revision() !== $revision) {
            // The report must not retain an earlier item's observation in an old context.
            $result['counts'] = $counts;
            $result['counts']['unavailable'] = count($ids);
            $result['items'] = array_map(static fn(int $id): array => ['id' => $id, 'category' => 'unavailable'], $ids);
        }
        return $result;
    }

    /** Native public getters are persisted actor links, not inherited group membership. */
    public static function nativePresence(int $id, array $target): bool
    {
        $ticket = new \Ticket();
        if (!$ticket->can($id, READ) || !$ticket->getFromDB($id)) {
            throw new \RuntimeException('mass_verification_unavailable');
        }
        $roles = ['requester' => \CommonITILActor::REQUESTER,
            'assign' => \CommonITILActor::ASSIGN, 'observer' => \CommonITILActor::OBSERVER];
        $methods = ['user' => 'getUsers', 'group' => 'getGroups', 'supplier' => 'getSuppliers'];
        $method = $methods[$target['type']];
        $links = $ticket->$method($roles[$target['role']]);
        if (!is_array($links)) {
            throw new \RuntimeException('mass_verification_unavailable');
        }
        foreach ($links as $link) {
            if (is_array($link) && (int) ($link[$target['field']] ?? 0) === $target['id']) {
                return true;
            }
        }
        return false;
    }

    /** @return array{role:string,type:string,field:string,id:int}|null */
    private function target(array $submission): ?array
    {
        if (($submission['processor'] ?? '') !== 'Ticket' || ($submission['action'] ?? '') !== 'add_actor') {
            return null;
        }
        $found = [];
        foreach (['requester', 'assign', 'observer'] as $role) {
            if (isset($submission['_itil_' . $role])) {
                $found[$role] = $submission['_itil_' . $role];
            }
        }
        if (count($found) !== 1) {
            throw new \InvalidArgumentException('mass_verification_target_invalid');
        }
        $role = (string) array_key_first($found);
        $actor = $found[$role];
        $type = is_array($actor) ? ($actor['_type'] ?? '') : '';
        $fields = ['user' => 'users_id', 'group' => 'groups_id', 'supplier' => 'suppliers_id'];
        if (!is_string($type) || !isset($fields[$type])) {
            throw new \InvalidArgumentException('mass_verification_target_invalid');
        }
        $field = $fields[$type];
        $value = $actor[$field] ?? null;
        if (
            (!is_int($value) && !is_string($value)) || preg_match('/\A[1-9][0-9]*\z/D', (string) $value) !== 1
            || filter_var($value, FILTER_VALIDATE_INT) === false
        ) {
            throw new \InvalidArgumentException('mass_verification_target_invalid');
        }
        return ['role' => $role, 'type' => $type, 'field' => $field, 'id' => (int) $value];
    }

    private function ids(array $ids): array
    {
        if ($ids === [] || count($ids) > 1000) {
            throw new \InvalidArgumentException('mass_verification_selection_invalid');
        }
        foreach ($ids as $id) {
            if (!is_int($id) || $id < 1) {
                throw new \InvalidArgumentException('mass_verification_selection_invalid');
            }
        }
        $ids = array_values(array_unique($ids));
        sort($ids, SORT_NUMERIC);
        return $ids;
    }

    private function revision(): ?string
    {
        try {
            $revision = ($this->context)();
            return is_string($revision) && $revision !== '' ? $revision : null;
        } catch (\Throwable) {
            return null;
        }
    }

    private function presence(int $id, array $target, string $revision): ?bool
    {
        try {
            if ($this->revision() !== $revision) {
                return null;
            }
            $presence = ($this->reader)($id, $target);
            // Do not return observed data if authorization context changed during the read.
            return $this->revision() === $revision && is_bool($presence) ? $presence : null;
        } catch (\Throwable) {
            return null;
        }
    }
}
