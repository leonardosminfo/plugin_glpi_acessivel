<?php

declare(strict_types=1);

namespace GlpiPlugin\Glpiacessivel\Infrastructure\Audit;

/** Bounded, allowlisted diagnostics under the existing audit ACL and policy. */
final class RestrictedIntegrationDiagnostics
{
    private const ORIGIN_CODES = [
        'fetch_site_invalid', 'fetch_site_not_allowed', 'request_origin_invalid',
        'origin_invalid', 'origin_mismatch',
    ];
    private const CATALOG_CODES = [
        'invalid_profile_entities', 'empty_profile_entities',
        'native_entity_selector_unavailable', 'native_entity_tree_missing_root',
        'native_entity_tree_empty', 'invalid_native_entity_selector_tree',
        'invalid_native_entity_selector_node', 'invalid_native_entity_selector_id',
        'invalid_native_entity_selector_children', 'invalid_native_entity_selector_folder',
        'unexpected_native_entity_selector_root', 'non_recursive_entity_selector_children',
        'native_entity_selector_missing_root', 'native_entity_selector_empty',
        'native_entity_tree_api_unavailable', 'invalid_native_entity_tree',
        'native_entity_name_api_unavailable', 'invalid_native_entity_selector_name',
        'invalid_native_entity_id', 'invalid_native_entity_node', 'invalid_native_entity_name',
        'invalid_native_entity_children', 'invalid_native_entity_tree_roots',
        'native_entity_tree_unavailable', 'active_entity_scope_missing_from_catalog',
        'active_entity_missing_from_catalog',
    ];
    private const ENDPOINTS = ['ticket.results', 'ticket.resource-selector', 'ticket.template'];
    private const WINDOW_SECONDS = 60;
    private const MAX_EVENTS = 10;
    private const GATE_FILE = 'glpiacessivel-integration-diagnostics.json';

    private AuditEventPolicy $policy;
    /** @var \Closure(string,array<string,string>):void */
    private \Closure $writer;
    /** @var \Closure():int */
    private \Closure $clock;
    private ?string $directory;

    /**
     * Optional dependencies are for tests; production uses the native cache
     * directory and audit table, never a universal temp directory or new ACL.
     * @param null|callable(string,array<string,string>):void $writer
     * @param null|callable():int $clock
     */
    public function __construct(
        ?AuditEventPolicy $policy = null,
        ?callable $writer = null,
        ?string $directory = null,
        ?callable $clock = null
    ) {
        $this->policy = $policy ?? new AuditEventPolicy();
        $this->writer = $writer !== null ? \Closure::fromCallable($writer)
            : function (string $event, array $payload): void {
                (new AuditLogger($this->policy))->log($event, $payload);
            };
        $this->directory = $directory ?? (defined('GLPI_CACHE_DIR') ? (string) constant('GLPI_CACHE_DIR') : null);
        $this->clock = $clock !== null ? \Closure::fromCallable($clock) : static fn(): int => time();
    }

    /** @param array{allowed:bool,reason:string} $decision */
    public function origin(string $endpoint, array $decision): void
    {
        if ($decision['allowed'] || !in_array($endpoint, self::ENDPOINTS, true)) {
            return;
        }
        if (!in_array($decision['reason'], self::ORIGIN_CODES, true)) {
            return;
        }
        $this->record('diagnostic.integration_origin', $endpoint, $decision['reason']);
    }

    /** @param array<string,mixed> $catalog */
    public function entityCatalog(array $catalog): void
    {
        if (!empty($catalog['complete'])) {
            return;
        }
        $code = $catalog['reason_code'] ?? '';
        if (!is_string($code) || !in_array($code, self::CATALOG_CODES, true)) {
            $code = 'native_entity_tree_unavailable';
        }
        $this->record('diagnostic.entity_catalog', 'context.entity-catalog', $code);
    }

    private function record(string $event, string $endpoint, string $code): void
    {
        try {
            // No fallback log when disabled. Logging must never change a 403,
            // invalidate the current context, or expose native exceptions.
            if (!$this->policy->shouldPersist($event) || !$this->admit($event . ':' . $endpoint . ':' . $code)) {
                return;
            }
            ($this->writer)($event, [
                'endpoint' => $endpoint,
                'issue_code' => $code,
                'plugin_version' => $this->version('PLUGIN_GLPIACESSIVEL_VERSION'),
                'glpi_version' => $this->version('GLPI_VERSION'),
            ]);
        } catch (\Throwable) {
            // The diagnostic is best-effort; the security decision is final.
        }
    }

    private function version(string $constant): string
    {
        $value = defined($constant) ? (string) constant($constant) : 'unknown';
        return preg_match('/\A[a-zA-Z0-9.-]{1,64}\z/D', $value) === 1 ? $value : 'unknown';
    }

    /** Per cache directory/replica: at most 10 events per fixed 60s window,
     * and one event for each endpoint/code. No session or request data stored.
     */
    private function admit(string $key): bool
    {
        if ($this->directory === null || !is_dir($this->directory) || !is_writable($this->directory)) {
            return false;
        }
        $directory = realpath($this->directory);
        if ($directory === false) {
            return false;
        }
        $file = $directory . DIRECTORY_SEPARATOR . self::GATE_FILE;
        if (is_link($file) || (file_exists($file) && (!is_file($file) || realpath($file) !== $file))) {
            return false;
        }
        $handle = @fopen($file, 'c+b');
        if (!is_resource($handle)) {
            return false;
        }
        try {
            if (!flock($handle, LOCK_EX | LOCK_NB)) {
                return false;
            }
            @chmod($file, 0600);
            $window = intdiv(max(0, ($this->clock)()), self::WINDOW_SECONDS);
            $raw = stream_get_contents($handle, 4097);
            $state = is_string($raw) && strlen($raw) <= 4096 ? json_decode($raw, true) : null;
            if (!is_array($state) || ($state['window'] ?? null) !== $window) {
                $state = ['window' => $window, 'count' => 0, 'seen' => []];
            }
            $count = $state['count'] ?? self::MAX_EVENTS;
            $seen = $state['seen'] ?? null;
            if (!is_int($count) || $count < 0 || $count >= self::MAX_EVENTS || !is_array($seen) || isset($seen[$key])) {
                return false;
            }
            $state['count'] = $count + 1;
            $state['seen'][$key] = true;
            $encoded = json_encode($state, JSON_THROW_ON_ERROR);
            if (strlen($encoded) > 4096) {
                return false;
            }
            if (!rewind($handle) || !ftruncate($handle, 0) || fwrite($handle, $encoded) !== strlen($encoded) || !fflush($handle)) {
                return false;
            }
            return true;
        } finally {
            flock($handle, LOCK_UN);
            fclose($handle);
        }
    }
}
