<?php

declare(strict_types=1);

namespace GlpiPlugin\Glpiacessivel\Infrastructure\Knowledge;

use GlpiPlugin\Glpiacessivel\Infrastructure\Security\GlpiSessionContextSnapshot;
use GlpiPlugin\Glpiacessivel\Domain\Knowledge\KnowledgeSourceReader;
use GlpiPlugin\Glpiacessivel\Support\TextNormalizer;

/** Read-only GLPI source adapter. No persisted observation grants future access. */
final class NativeKnowledgeSourceReader implements KnowledgeSourceReader
{
    private const MAX_SOURCE_BYTES = 1048576;
    private const MAX_PAGE_TEXT_BYTES = 8388608;
    private const PAGE_SECONDS = 5.0;
    private \Closure $item;
    private \Closure $relations;
    private \Closure $clock;
    private \Closure $catalog;
    private \Closure $review;
    private \Closure $context;
    private \Closure $timer;

    /** Injectable boundaries are for tests; production uses public native APIs only. */
    public function __construct(
        ?callable $item = null,
        ?callable $relations = null,
        ?callable $clock = null,
        ?callable $catalog = null,
        ?callable $review = null,
        ?callable $context = null,
        ?callable $timer = null
    ) {
        $this->item = \Closure::fromCallable($item ?? [self::class, 'nativeItem']);
        $this->relations = \Closure::fromCallable($relations ?? [self::class, 'nativeRelations']);
        $this->clock = \Closure::fromCallable($clock ?? [self::class, 'nativeClock']);
        $this->catalog = \Closure::fromCallable($catalog ?? [self::class, 'nativeCatalog']);
        $this->review = \Closure::fromCallable($review ?? [self::class, 'nativeCanReview']);
        $this->context = $context === null
            ? static fn(): string => (new GlpiSessionContextSnapshot())->snapshot()['revision']
            : \Closure::fromCallable($context);
        $this->timer = $timer === null ? static fn(): float => microtime(true) : \Closure::fromCallable($timer);
    }

    public function canReview(): bool
    {
        try {
            return ($this->review)() === true;
        } catch (\Throwable) {
            return false;
        }
    }

    /** @return array<string,mixed> */
    public function readForEditorialReview(int $id): array
    {
        return $this->canReview() ? $this->read($id, true) : $this->unavailable($id, 'review_denied');
    }

    /** @return array<string,mixed> */
    public function readForAnswer(int $id): array
    {
        return $this->read($id, false);
    }

    public function highWaterMark(): int
    {
        if (!$this->canReview()) {
            return 0;
        }
        try {
            $context = ($this->context)();
            $result = ($this->catalog)('high_water', 0, 0, 1, false);
            if (($this->context)() !== $context || !is_int($result) || $result < 0 || !$this->canReview()) {
                throw new \RuntimeException('knowledge_catalog_unavailable');
            }
            return $result;
        } catch (\Throwable) {
            throw new \RuntimeException('knowledge_catalog_unavailable');
        }
    }

    /** @return array<string,mixed> */
    public function nextEditorialPage(
        int $after,
        int $highWater,
        int $limit,
        bool $faqOnly,
        string $publication = 'all'
    ): array {
        $after = max(0, $after);
        $empty = ['sources' => [], 'examined' => 0, 'skipped' => 0, 'cursor' => $after, 'has_more' => false,
            'status' => 'unknown', 'reason' => 'catalog_unavailable'];
        if (!$this->canReview()) {
            return array_replace($empty, ['reason' => 'review_denied']);
        }
        if (!in_array($publication, ['all', 'published', 'unpublished'], true) || $highWater < $after) {
            return array_replace($empty, ['reason' => 'invalid_cursor']);
        }
        try {
            $started = ($this->timer)();
            $context = ($this->context)();
            $limit = min(100, max(1, $limit));
            $rows = ($this->catalog)('page', $after, $highWater, $limit + 1, $faqOnly);
            if (!is_array($rows)) {
                throw new \RuntimeException('knowledge_catalog_unavailable');
            }
            $ids = [];
            foreach ($rows as $row) {
                $id = is_array($row) ? ($row['id'] ?? null) : $row;
                if (!is_numeric($id) || (int) $id <= $after || (int) $id > $highWater) {
                    throw new \RuntimeException('knowledge_catalog_unavailable');
                }
                $ids[(int) $id] = (int) $id;
            }
            sort($ids, SORT_NUMERIC);
            $hasMore = count($ids) > $limit;
            $ids = array_slice($ids, 0, $limit);
            $sources = [];
            $examined = 0;
            $bytes = 0;
            $cursor = $after;
            $reason = '';
            foreach ($ids as $id) {
                if (($this->timer)() - $started >= self::PAGE_SECONDS || $bytes >= self::MAX_PAGE_TEXT_BYTES) {
                    $hasMore = true;
                    $reason = 'page_budget';
                    break;
                }
                $source = $this->readForEditorialReview($id);
                ++$examined;
                $cursor = $id;
                if ($publication === 'all' || $source['publication'] === $publication) {
                    $sources[] = $source;
                    $bytes += strlen((string) $source['content_text']) + strlen((string) $source['name']);
                }
            }
            if (($this->context)() !== $context || !$this->canReview()) {
                return array_replace($empty, ['reason' => 'context_changed']);
            }
            return ['sources' => $sources, 'examined' => $examined, 'skipped' => $examined - count($sources),
                'cursor' => $cursor, 'has_more' => $hasMore, 'status' => 'ok', 'reason' => $reason];
        } catch (\Throwable) {
            return $empty;
        }
    }

    /** @return array<string,mixed> */
    private function read(int $id, bool $editorial): array
    {
        if ($id <= 0) {
            return $this->unavailable(0, 'invalid_id');
        }
        try {
            $context = ($this->context)();
            $item = ($this->item)($id);
            if (
                !is_object($item) || !is_array($item->fields ?? null)
                || (int) ($item->fields['id'] ?? 0) !== $id || !method_exists($item, 'countVisibilities')
            ) {
                return $this->unavailable($id, 'read_unavailable');
            }
            $fields = $item->fields;
            $links = ($this->relations)($id);
            $canonical = $this->canonicalRelations($links, $id);
            $count = array_sum(array_map('count', $links));
            if ($item->countVisibilities() !== $count) {
                return $this->unavailable($id, 'publication_changed');
            }
            $publication = $count > 0 ? 'published' : 'unpublished';
            $time = ($this->clock)($id, $fields);
            $validity = $this->validity($time, $fields);
            if (($this->context)() !== $context || ($editorial && !$this->canReview())) {
                return $this->unavailable($id, 'context_changed');
            }
            $eligible = $publication === 'published' && $validity === 'current';
            if (!$editorial && !$eligible) {
                return array_replace(
                    $this->unavailable($id, 'source_ineligible'),
                    ['publication' => $publication, 'validity' => $validity]
                );
            }
            $name = TextNormalizer::fromGlpi((string) ($fields['name'] ?? ''));
            $raw = (string) ($fields['answer'] ?? '');
            if (strlen($raw) > self::MAX_SOURCE_BYTES) {
                return $this->unavailable($id, 'source_too_large');
            }
            $raw = preg_replace('/<(script|style)\b[^>]*>.*?<\/\1\s*>/is', '', $raw) ?? $raw;
            $raw = preg_replace('/<(?:br\s*\/?|\/p|\/div|\/li|\/h[1-6])>/i', "\n", $raw) ?? $raw;
            $text = TextNormalizer::fromGlpi(strip_tags($raw));
            $hasText = $name !== '' && $text !== '';
            $eligible = $eligible && $hasText;
            if (!$editorial && !$eligible) {
                return array_replace(
                    $this->unavailable($id, 'no_text'),
                    ['publication' => $publication, 'validity' => $validity]
                );
            }
            // Base KnowbaseItem has no language column; do not fabricate a content revision from session locale.
            $language = (string) ($fields['language'] ?? '');
            $categories = [];
            foreach ((array) ($fields['_categories'] ?? []) as $categoryId) {
                if ((int) $categoryId > 0 && class_exists('Dropdown')) {
                    $categories[] = TextNormalizer::fromGlpi((string) \Dropdown::getDropdownName(
                        'glpi_knowbaseitemcategories',
                        (int) $categoryId
                    ));
                }
            }
            return ['id' => $id, 'name' => $name, 'content_text' => $text, 'category' => implode(' / ', $categories),
                'language' => $language, 'is_faq' => !empty($fields['is_faq']),
                'date_mod' => (string) ($fields['date_mod'] ?? ''),
                'begin_date' => $fields['begin_date'] ?? null, 'end_date' => $fields['end_date'] ?? null,
                'publication' => $publication, 'validity' => $validity,
                'text_hash' => $this->hash([$name, $text, $language]),
                'publication_hash' => $this->hash($canonical), 'eligible' => $eligible,
                'reason' => $validity === 'unknown' ? 'validity_unknown' : ($hasText ? '' : 'no_text')];
        } catch (\Throwable $exception) {
            $reason = $exception->getMessage() === 'read_denied' ? 'read_denied' : 'read_unavailable';
            return $this->unavailable($id, $reason);
        }
    }

    /** @return array<string,mixed> */
    private function unavailable(int $id, string $reason): array
    {
        return ['id' => max(0, $id), 'name' => '', 'content_text' => '', 'category' => '',
            'language' => '', 'is_faq' => false, 'date_mod' => '', 'begin_date' => null, 'end_date' => null,
            'publication' => 'unknown', 'validity' => 'unknown', 'text_hash' => '',
            'publication_hash' => '', 'eligible' => false, 'reason' => $reason];
    }

    /** Full, global native relations; neither entity-filtered nor a count-only hash. */
    private function canonicalRelations(mixed $links, int $id): array
    {
        if (!is_array($links) || count($links) !== 4) {
            throw new \RuntimeException('knowledge_publication_unavailable');
        }
        $canonical = [];
        foreach (
            ['users' => 'users_id', 'groups' => 'groups_id',
            'profiles' => 'profiles_id', 'entities' => 'entities_id'] as $family => $target
        ) {
            if (!isset($links[$family]) || !is_array($links[$family])) {
                throw new \RuntimeException('knowledge_publication_unavailable');
            }
            $rows = [];
            foreach ($links[$family] as $group) {
                if (!is_array($group) || $group === []) {
                    throw new \RuntimeException('knowledge_publication_unavailable');
                }
                foreach ($group as $row) {
                    if (
                        !is_array($row) || !isset($row[$target], $row['knowbaseitems_id'])
                        || (int) $row['knowbaseitems_id'] !== $id
                    ) {
                        throw new \RuntimeException('knowledge_publication_unavailable');
                    }
                    $values = [];
                    foreach ($row as $key => $value) {
                        if (!is_scalar($value) && $value !== null) {
                            throw new \RuntimeException('knowledge_publication_unavailable');
                        }
                        $values[(string) $key] = $value === null ? null : (string) $value;
                    }
                    ksort($values, SORT_STRING);
                    $rows[] = $values;
                }
            }
            usort($rows, fn(array $a, array $b): int => strcmp($this->hash($a), $this->hash($b)));
            $canonical[$family] = $rows;
        }
        return $canonical;
    }

    private function hash(array $value): string
    {
        return hash('sha256', json_encode($value, JSON_THROW_ON_ERROR | JSON_UNESCAPED_UNICODE));
    }

    private function validity(mixed $time, array $fields): string
    {
        if (!is_array($time) || !is_numeric($time['now'] ?? null)) {
            return 'unknown';
        }
        foreach (['begin', 'end'] as $key) {
            $raw = $fields[$key . '_date'] ?? null;
            if ($raw !== null) {
                $parsed = is_string($raw)
                    ? \DateTimeImmutable::createFromFormat('!Y-m-d H:i:s', $raw, new \DateTimeZone('UTC')) : false;
                if (!$parsed || $parsed->format('Y-m-d H:i:s') !== $raw) {
                    return 'unknown';
                }
            }
            if (!array_key_exists($key, $time) || ($raw !== null && !is_numeric($time[$key]))) {
                return 'unknown';
            }
            if ($raw === null && $time[$key] !== null) {
                return 'unknown';
            }
        }
        if ($time['begin'] !== null && $time['end'] !== null && $time['end'] <= $time['begin']) {
            return 'unknown';
        }
        if ($time['begin'] !== null && $time['begin'] >= $time['now']) {
            return 'future';
        }
        return $time['end'] !== null && $time['end'] <= $time['now'] ? 'expired' : 'current';
    }

    private static function nativeCanReview(): bool
    {
        return class_exists('KnowbaseItem') && defined('KnowbaseItem::KNOWBASEADMIN')
            && \Session::getLoginUserID() > 0 && \Session::getCurrentInterface() === 'central'
            && \Session::haveRight('config', UPDATE) && \Session::haveRight('knowbase', READ)
            && \Session::haveRight('knowbase', \KnowbaseItem::KNOWBASEADMIN);
    }

    private static function nativeItem(int $id): ?object
    {
        $item = new \KnowbaseItem();
        if (!$item->getFromDB($id)) {
            return null;
        }
        if (!$item->can($id, READ)) {
            throw new \RuntimeException('read_denied');
        }
        return $item;
    }

    private static function nativeRelations(int $id): array
    {
        $relations = [];
        foreach (
            ['users' => ['KnowbaseItem_User', 'getUsers'], 'groups' => ['Group_KnowbaseItem', 'getGroups'],
            'profiles' => ['KnowbaseItem_Profile', 'getProfiles'],
            'entities' => ['Entity_KnowbaseItem', 'getEntities']] as $family => $method
        ) {
            $relations[$family] = $method($id);
            self::checkDatabaseError();
        }
        return $relations;
    }

    private static function checkDatabaseError(): void
    {
        global $DB;
        if (!is_object($DB) || !method_exists($DB, 'errno') || (int) $DB->errno() !== 0) {
            throw new \RuntimeException('knowledge_database_unavailable');
        }
    }

    private static function nativeClock(int $id, array $fields): array
    {
        global $DB;
        $row = $DB->request(['SELECT' => [
            new \QueryExpression('UNIX_TIMESTAMP(NOW()) AS now_epoch'),
            new \QueryExpression('UNIX_TIMESTAMP(begin_date) AS begin_epoch'),
            new \QueryExpression('UNIX_TIMESTAMP(end_date) AS end_epoch'), 'begin_date', 'end_date'],
            'FROM' => 'glpi_knowbaseitems', 'WHERE' => ['id' => $id], 'LIMIT' => 1])->current();
        self::checkDatabaseError();
        if (
            !is_array($row) || ($row['begin_date'] ?? null) !== ($fields['begin_date'] ?? null)
            || ($row['end_date'] ?? null) !== ($fields['end_date'] ?? null)
        ) {
            throw new \RuntimeException('knowledge_clock_unavailable');
        }
        return ['now' => $row['now_epoch'] ?? null, 'begin' => $row['begin_epoch'] ?? null,
            'end' => $row['end_epoch'] ?? null];
    }

    private static function nativeCatalog(string $mode, int $after, int $high, int $limit, bool $faqOnly): mixed
    {
        global $DB;
        if ($mode === 'high_water') {
            $row = $DB->request(['SELECT' => new \QueryExpression('COALESCE(MAX(id), 0) AS high_water'),
                'FROM' => 'glpi_knowbaseitems'])->current();
            self::checkDatabaseError();
            if (!is_array($row) || !is_numeric($row['high_water'] ?? null)) {
                throw new \RuntimeException('knowledge_catalog_unavailable');
            }
            return (int) $row['high_water'];
        }
        $criteria = \KnowbaseItem::getVisibilityCriteria(true);
        if (!isset($criteria['WHERE']) || !is_array($criteria['WHERE'])) {
            throw new \RuntimeException('knowledge_catalog_unavailable');
        }
        $criteria['FROM'] = 'glpi_knowbaseitems';
        $criteria['SELECT'] = ['glpi_knowbaseitems.id'];
        $criteria['DISTINCT'] = true;
        $criteria['WHERE'][] = ['glpi_knowbaseitems.id' => ['>', $after]];
        $criteria['WHERE'][] = ['glpi_knowbaseitems.id' => ['<=', $high]];
        if ($faqOnly) {
            $criteria['WHERE'][] = ['glpi_knowbaseitems.is_faq' => 1];
        }
        $criteria['ORDERBY'] = ['glpi_knowbaseitems.id ASC'];
        $criteria['LIMIT'] = $limit;
        $rows = iterator_to_array($DB->request($criteria), false);
        self::checkDatabaseError();
        return $rows;
    }
}
