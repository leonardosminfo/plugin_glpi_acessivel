<?php

declare(strict_types=1);

namespace GlpiPlugin\Glpiacessivel\Infrastructure\Repository;

final class PlaybookRepository
{
    private const TABLE_JOBS = 'glpi_plugin_glpiacessivel_playbookjobs';
    private const TABLE_SUGGESTIONS = 'glpi_plugin_glpiacessivel_playbooksuggestions';
    private const TABLE_PLAYBOOKS = 'glpi_plugin_glpiacessivel_playbooks';
    private const TABLE_SOURCES = 'glpi_plugin_glpiacessivel_knowledge_sources';
    private const TABLE_DEPENDENCIES = 'glpi_plugin_glpiacessivel_playbook_sources';
    private int $transactionDepth = 0;

    /** @return array<string, int|bool> */
    public function currentJobContext(): array
    {
        return [
            'user_id' => $this->currentUserId(),
            'profile_id' => (int) ($_SESSION['glpiactiveprofile']['id'] ?? 0),
            'entity_id' => $this->currentEntityId(),
            'recursive' => !empty($_SESSION['glpiactive_entity_recursive']),
        ];
    }

    public function getJob(int $id): ?array
    {
        global $DB;
        $row = $DB->request([
            'FROM' => self::TABLE_JOBS,
            'WHERE' => array_merge(['id' => $id, 'users_id' => $this->currentUserId()], $this->entityCriteria()),
            'LIMIT' => 1,
        ])->current();
        if (!is_array($row)) {
            return null;
        }
        if ((string) ($row['context_hash'] ?? '') !== $this->contextHash($this->currentJobContext())) {
            return null;
        }
        foreach (['options', 'cursor', 'context', 'counts'] as $field) {
            $row[$field] = $this->fromJson((string) ($row[$field . '_json'] ?? '[]'));
        }
        return $row;
    }

    public function listJobs(int $limit = 30): array
    {
        global $DB;
        $rows = $DB->request([
            'FROM' => self::TABLE_JOBS,
            'WHERE' => array_merge(['users_id' => $this->currentUserId()], $this->entityCriteria()),
            'ORDER' => ['id DESC'],
            'LIMIT' => min(100, max(1, $limit)),
        ]);
        $jobs = [];
        foreach ($rows as $row) {
            $job = $this->getJob((int) ($row['id'] ?? 0));
            if ($job !== null) {
                $jobs[] = $job;
            }
        }
        return $jobs;
    }

    /** A successful claim increments revision and returns its server-owned lease. */
    public function claimJob(int $id, array $context, int $expectedRevision, int $seconds = 60): ?array
    {
        global $DB;
        $this->assertJobContext($context);
        $job = $this->getJob($id);
        if (
            $job === null || !$this->jobMatchesContext($job, $context)
            || !in_array((string) $job['status'], ['queued', 'running', 'paused', 'partial'], true)
        ) {
            return null;
        }
        $now = date('Y-m-d H:i:s');
        $token = bin2hex(random_bytes(32));
        $where = [
            'id' => $id,
            'users_id' => $this->currentUserId(),
            'entities_id' => $this->currentEntityId(),
            'context_hash' => $this->contextHash($context),
            'revision' => $expectedRevision,
            'status' => ['queued', 'running', 'paused', 'partial'],
            'OR' => [['lease_token' => null], ['lease_until' => ['<', $now]]],
        ];
        if (
            !$DB->update(self::TABLE_JOBS, [
            'revision' => $expectedRevision + 1,
            'lease_token' => $token,
            'lease_until' => date('Y-m-d H:i:s', time() + min(120, max(10, $seconds))),
            'status' => 'running',
            'updated_at' => $now,
            ], $where) || (int) $DB->affectedRows() !== 1
        ) {
            return null;
        }
        return $this->getJob($id);
    }

    /** Counts are absolute checkpoints, never replayable increments. */
    public function checkpointJob(
        int $id,
        array $context,
        int $expectedRevision,
        string $leaseToken,
        array $cursor,
        array $counts,
        string $status = 'paused',
        string $message = ''
    ): bool {
        global $DB;
        $this->assertJobContext($context);
        if (
            !in_array($status, ['paused', 'completed', 'partial', 'cancelled'], true)
            || preg_match('/^[a-f0-9]{64}$/D', $leaseToken) !== 1
        ) {
            throw new \InvalidArgumentException('invalid_editorial_checkpoint');
        }
        foreach ($counts as $key => $value) {
            $counts[$key] = max(0, (int) $value);
        }
        $now = date('Y-m-d H:i:s');
        return (bool) $DB->update(self::TABLE_JOBS, [
            'revision' => $expectedRevision + 1,
            'cursor_json' => $this->toJson($cursor),
            'counts_json' => $this->toJson($counts),
            'processed_count' => (int) ($counts['processed'] ?? 0),
            'suggestions_count' => (int) ($counts['suggestions'] ?? 0),
            'status' => $status,
            'message' => mb_substr($message, 0, 250, 'UTF-8'),
            'lease_token' => null,
            'lease_until' => null,
            'finished_at' => in_array($status, ['completed', 'cancelled'], true) ? $now : null,
            'updated_at' => $now,
        ], [
            'id' => $id,
            'users_id' => $this->currentUserId(),
            'entities_id' => $this->currentEntityId(),
            'context_hash' => $this->contextHash($context),
            'revision' => $expectedRevision,
            'lease_token' => $leaseToken,
            'status' => 'running',
        ]) && (int) $DB->affectedRows() === 1;
    }

    /**
     * All source/proposal writes in callback and their cursor/counters commit together.
     * Callback receives the claimed job and returns cursor/counts/status/message.
     */
    public function withJobBatch(int $id, array $context, int $expectedRevision, callable $callback): ?array
    {
        return $this->transaction(function () use ($id, $context, $expectedRevision, $callback): ?array {
            $job = $this->claimJob($id, $context, $expectedRevision);
            if ($job === null) {
                return null;
            }
            $result = $callback($job);
            if (
                !is_array($result) || !$this->checkpointJob(
                    $id,
                    $context,
                    (int) $job['revision'],
                    (string) $job['lease_token'],
                    (array) ($result['cursor'] ?? []),
                    (array) ($result['counts'] ?? []),
                    (string) ($result['status'] ?? 'paused'),
                    (string) ($result['message'] ?? '')
                )
            ) {
                throw new \RuntimeException('editorial_checkpoint_conflict');
            }
            return $this->getJob($id);
        });
    }

    /** Identity is installation + native type + native ID; no editorial entity alias. */
    public function upsertKnowledgeSource(array $identity, array $metadata): int
    {
        global $DB;
        $identity = $this->sourceIdentity($identity);
        $where = $identity;
        $existing = $this->sourceRow($where);
        $data = [
            'text_hash' => $this->validatedHash((string) ($metadata['text_hash'] ?? $metadata['content_hash'] ?? '')),
            'publication_hash' => $this->validatedHash((string) ($metadata['publication_hash'] ?? '')),
            'publication' => $this->choice(
                (string) ($metadata['publication'] ?? 'unknown'),
                ['published', 'unpublished', 'unknown']
            ),
            'validity' => $this->choice(
                (string) ($metadata['validity'] ?? 'unknown'),
                ['current', 'future', 'expired', 'unknown']
            ),
            'provider' => mb_substr((string) ($metadata['provider'] ?? 'native'), 0, 40, 'UTF-8'),
            'proof_json' => $this->toJson((array) ($metadata['proof'] ?? [])),
            'date_mod' => ($metadata['date_mod'] ?? '') !== '' ? (string) $metadata['date_mod'] : null,
            'observed_at' => date('Y-m-d H:i:s'),
        ];
        if ($existing !== null) {
            $revision = (int) $existing['revision'];
            // Observation revision is a CAS token, not a publication/text hash.
            $data['revision'] = $revision + 1;
            if (!$DB->update(self::TABLE_SOURCES, $data, ['id' => (int) $existing['id'], 'revision' => $revision])) {
                throw new \RuntimeException('editorial_source_update_failed');
            }
            if ((int) $DB->affectedRows() !== 1) {
                throw new \RuntimeException('editorial_source_revision_conflict');
            }
            return (int) $existing['id'];
        }
        if (!$DB->insert(self::TABLE_SOURCES, array_merge($identity, $data, ['revision' => 1]))) {
            // Concurrent canonical insert: only reuse identical evidence.
            $current = $this->sourceRow($where);
            if (
                $current !== null && $current['text_hash'] === $data['text_hash']
                && $current['publication_hash'] === $data['publication_hash']
            ) {
                return (int) $current['id'];
            }
            throw new \RuntimeException('editorial_source_insert_failed');
        }
        return $this->requiredInsertId();
    }

    public function getKnowledgeSource(array $identity): ?array
    {
        $row = $this->sourceRow($this->sourceIdentity($identity));
        if ($row !== null) {
            $row['proof'] = $this->fromJson((string) ($row['proof_json'] ?? '[]'));
            $row['source_id'] = (int) $row['native_id'];
            $row['source_type'] = (string) $row['source_kind'];
        }
        return $row;
    }

    public function replacePlaybookSources(int $id, array $evidence): void
    {
        $this->transaction(fn() => $this->writePlaybookSources($id, $evidence));
    }

    private function writePlaybookSources(int $id, array $evidence): void
    {
        global $DB;
        if ($this->getPlaybook($id) === null) {
            throw new \RuntimeException('editorial_playbook_not_visible');
        }
        $links = $this->dependencyRows($evidence);
        if (!$DB->delete(self::TABLE_DEPENDENCIES, ['playbook_id' => $id])) {
            throw new \RuntimeException('editorial_dependencies_delete_failed');
        }
        foreach ($links as $link) {
            if (!$DB->insert(self::TABLE_DEPENDENCIES, array_merge(['playbook_id' => $id], $link))) {
                throw new \RuntimeException('editorial_dependency_insert_failed');
            }
        }
    }

    /** source_id is native ID; knowledge_source_id is the plugin's foreign key. */
    public function getPlaybookSources(int $id): array
    {
        global $DB;
        if ($this->getPlaybook($id) === null) {
            return [];
        }
        $result = [];
        foreach ($DB->request(['FROM' => self::TABLE_DEPENDENCIES, 'WHERE' => ['playbook_id' => $id]]) as $link) {
            $source = $this->sourceRow(['id' => (int) $link['source_id']]);
            if ($source === null) {
                $result[] = ['source_id' => 0, 'role' => 'required', 'publication' => 'unknown'];
                continue;
            }
            $result[] = array_merge($link, [
                'knowledge_source_id' => (int) $source['id'],
                'source_id' => (int) $source['native_id'],
                'native_id' => (int) $source['native_id'],
                'installation_id' => (string) $source['installation_id'],
                'source_type' => (string) $source['source_kind'],
                'role' => (string) $link['requirement'],
                'publication' => (string) $source['publication'],
                'validity' => (string) $source['validity'],
            ]);
        }
        return $result;
    }

    public function findPlaybooksBySource(int $nativeId): array
    {
        global $DB;
        $result = [];
        $sources = $DB->request([
            'FROM' => self::TABLE_SOURCES,
            'WHERE' => ['native_id' => $nativeId, 'source_kind' => 'KnowbaseItem'],
        ]);
        foreach ($sources as $source) {
            $links = $DB->request([
                'FROM' => self::TABLE_DEPENDENCIES, 'WHERE' => ['source_id' => (int) $source['id']],
            ]);
            foreach ($links as $link) {
                $playbook = $this->getPlaybook((int) $link['playbook_id']);
                if ($playbook !== null) {
                    $result[(int) $playbook['id']] = $playbook;
                }
            }
        }
        // Historical JSON references are candidates for editorial review, not
        // approved dependencies. Numeric coincidence never authorizes a reply.
        foreach (
            $DB->request([
            'FROM' => self::TABLE_PLAYBOOKS,
            'WHERE' => array_merge(['kb_articles_json' => ['LIKE', '%' . $nativeId . '%']], $this->entityCriteria()),
            ]) as $row
        ) {
            foreach ($this->fromJson((string) ($row['kb_articles_json'] ?? '[]')) as $article) {
                if (is_array($article) && (int) ($article['id'] ?? 0) === $nativeId) {
                    $decoded = $this->decodeRows([$row]);
                    $result[(int) $row['id']] = $decoded[0];
                    break;
                }
            }
        }
        return array_values($result);
    }

    public function createEditorialSuggestion(int $jobId, array $payload): int
    {
        global $DB;
        $key = $this->validatedHash((string) ($payload['dedupe_key'] ?? ''));
        $existing = $DB->request([
            'FROM' => self::TABLE_SUGGESTIONS,
            'WHERE' => ['dedupe_key' => $key, 'entities_id' => $this->currentEntityId()],
            'LIMIT' => 1,
        ])->current();
        if (is_array($existing)) {
            return 0;
        }
        $action = $this->choice(
            (string) ($payload['action'] ?? 'create'),
            ['create', 'update', 'inactivate', 'reactivate', 'review']
        );
        $id = $this->createSuggestion($jobId, array_merge($payload, [
            'status' => 'pending', 'action' => $action, 'dedupe_key' => $key,
        ]));
        if ($id <= 0) {
            $existing = $DB->request([
                'FROM' => self::TABLE_SUGGESTIONS,
                'WHERE' => ['dedupe_key' => $key, 'entities_id' => $this->currentEntityId()],
                'LIMIT' => 1,
            ])->current();
            if (is_array($existing)) {
                return 0;
            }
            throw new \RuntimeException('editorial_proposal_write_failed');
        }
        return $id;
    }

    public function listEditorialSuggestions(array $filters = []): array
    {
        global $DB;
        $where = $this->entityCriteria();
        $state = (string) ($filters['state'] ?? 'pending');
        $action = (string) ($filters['action'] ?? 'all');
        if ($state !== 'all') {
            $where['status'] = $this->choice(
                $state,
                ['pending', 'approved', 'rejected', 'conflict', 'superseded', 'failed']
            );
        }
        if ($action !== 'all') {
            $where['action'] = $this->choice($action, ['create', 'update', 'inactivate', 'reactivate', 'review']);
        }
        $count = $DB->request(['COUNT' => 'total', 'FROM' => self::TABLE_SUGGESTIONS, 'WHERE' => $where])->current();
        $total = is_array($count) ? max(0, (int) ($count['total'] ?? 0)) : 0;
        $size = min(50, max(1, (int) ($filters['page_size'] ?? 20)));
        $page = min(max(1, (int) ($filters['page'] ?? 1)), max(1, (int) ceil($total / $size)));
        $items = $this->decodeRows($DB->request([
            'FROM' => self::TABLE_SUGGESTIONS,
            'WHERE' => $where,
            'ORDER' => ['id DESC'],
            'START' => ($page - 1) * $size,
            'LIMIT' => $size,
        ]));
        return ['items' => $items, 'total' => $total, 'page' => $page, 'page_size' => $size];
    }

    /** Native authorization is the service's responsibility before this transaction. */
    public function applyEditorialSuggestion(
        int $id,
        array $expectedSourceEvidence,
        ?int $expectedProposalRevision = null,
        ?callable $beforeCommit = null
    ): array {
        return $this->transaction(function () use ($id, $expectedSourceEvidence, $expectedProposalRevision, $beforeCommit): array {
            global $DB;
            $suggestion = $this->getSuggestion($id);
            if (
                $suggestion === null || (string) $suggestion['status'] !== 'pending'
                || ($expectedProposalRevision !== null
                    && (int) ($suggestion['revision'] ?? 1) !== $expectedProposalRevision)
            ) {
                return ['status' => 'conflict', 'id' => 0];
            }
            $action = (string) ($suggestion['action'] ?? 'create');
            if (
                $action === 'review' || $expectedSourceEvidence === []
                || $this->toJson($this->normalizedEvidence((array) $suggestion['evidence']))
                !== $this->toJson($this->normalizedEvidence($expectedSourceEvidence))
            ) {
                return ['status' => 'conflict', 'id' => 0];
            }
            $this->dependencyRows($expectedSourceEvidence);
            $publication = array_column($expectedSourceEvidence, 'publication');
            if (
                ($action === 'inactivate' && (!in_array('unpublished', $publication, true)
                || $this->evidenceIsPublished($expectedSourceEvidence)))
                || ($action !== 'inactivate' && !$this->evidenceIsPublished($expectedSourceEvidence))
            ) {
                return ['status' => 'conflict', 'id' => 0];
            }
            foreach ($expectedSourceEvidence as $evidence) {
                $source = $this->sourceRow($this->sourceIdentity($evidence));
                if (
                    $source === null || $source['text_hash'] !== $evidence['text_hash']
                    || $source['publication_hash'] !== $evidence['publication_hash']
                    || $source['publication'] !== ($evidence['publication'] ?? 'unknown')
                ) {
                    return ['status' => 'conflict', 'id' => 0];
                }
            }
            $target = max(0, (int) ($suggestion['target_playbook_id'] ?? 0));
            $expected = (int) ($suggestion['expected_revision'] ?? 0);
            $playbook = $target > 0 ? $this->getPlaybook($target) : null;
            if (
                ($action === 'create' && $target !== 0)
                || ($action !== 'create' && ($playbook === null || (int) $playbook['revision'] !== $expected))
            ) {
                return ['status' => 'conflict', 'id' => 0];
            }
            if (
                !$DB->update(self::TABLE_SUGGESTIONS, ['status' => 'approving'], [
                'id' => $id, 'entities_id' => $this->currentEntityId(), 'status' => 'pending',
                'revision' => (int) ($suggestion['revision'] ?? 1),
                ]) || (int) $DB->affectedRows() !== 1
            ) {
                throw new \RuntimeException('editorial_approval_conflict');
            }
            $now = date('Y-m-d H:i:s');
            if ($action === 'create') {
                $target = $this->createPlaybook(array_merge($suggestion, [
                    'name' => (string) $suggestion['title'],
                    'origin_type' => 'kb_derived',
                    'origin_proposal_id' => $id,
                    'source_suggestion_id' => $id,
                ]), true);
                $revision = 1;
            } else {
                $revision = $expected + 1;
                $data = ['revision' => $revision, 'updated_at' => $now];
                if ($action === 'inactivate') {
                    $data['is_active'] = 0;
                } elseif ($action === 'reactivate') {
                    if ((string) ($playbook['origin_type'] ?? '') !== 'kb_derived') {
                        throw new \RuntimeException('editorial_manual_reactivation_forbidden');
                    }
                    $data['is_active'] = 1;
                    $data = array_merge($data, $this->playbookContentData($suggestion));
                } else {
                    $data = array_merge($data, $this->playbookContentData($suggestion));
                    $data['origin_type'] = (string) ($suggestion['content']['source_type'] ?? '') === 'knowledge_base'
                        ? 'kb_derived' : 'manual';
                }
                if (
                    !$DB->update(self::TABLE_PLAYBOOKS, $data, [
                    'id' => $target, 'revision' => $expected, 'entities_id' => $this->currentEntityId(),
                    ]) || (int) $DB->affectedRows() !== 1
                ) {
                    throw new \RuntimeException('editorial_target_revision_conflict');
                }
            }
            if ($action !== 'inactivate') {
                $this->replacePlaybookSources($target, $expectedSourceEvidence);
            }
            if (
                !$DB->update(self::TABLE_SUGGESTIONS, [
                'status' => 'approved', 'reviewed_by' => $this->currentUserId(),
                'reviewed_at' => $now, 'updated_at' => $now,
                ], ['id' => $id, 'status' => 'approving', 'entities_id' => $this->currentEntityId()])
                || (int) $DB->affectedRows() !== 1
            ) {
                throw new \RuntimeException('editorial_decision_write_failed');
            }
            if ($beforeCommit !== null) {
                $beforeCommit();
            }
            return ['status' => 'approved', 'id' => $target, 'revision' => $revision];
        });
    }

    /** Candidate retrieval uses terms before ranking, rather than 200 newest rows. */
    public function listCandidatePlaybooks(string $query, int $limit = 60): array
    {
        global $DB;
        $terms = array_slice(array_values(array_unique(array_filter(
            preg_split('/[^\p{L}\p{N}_]+/u', mb_strtolower($query, 'UTF-8')) ?: [],
            static fn(string $term): bool => mb_strlen($term, 'UTF-8') >= 3
        ))), 0, 12);
        if ($terms === []) {
            return [];
        }
        $or = [];
        foreach ($terms as $term) {
            // LIKE wildcards are not user-controlled; query-builder escapes literals.
            foreach (['name', 'keywords_json', 'questions_json', 'content_json', 'category_hint'] as $field) {
                $or[] = [$field => ['LIKE', '%' . $term . '%']];
            }
        }
        return $this->decodeRows($DB->request([
            'FROM' => self::TABLE_PLAYBOOKS,
            'WHERE' => array_merge(['is_active' => 1, 'OR' => $or], $this->entityCriteria()),
            'ORDER' => ['id ASC'],
            'LIMIT' => min(300, max(1, $limit)),
        ]));
    }

    public function createJob(string $jobType, array $options = []): int
    {
        global $DB;

        $now = date('Y-m-d H:i:s');
        $context = $this->currentJobContext();
        if (
            !$DB->insert(self::TABLE_JOBS, [
            'users_id' => $this->currentUserId(),
            'entities_id' => $this->currentEntityId(),
            'job_type' => $jobType,
            'status' => $jobType === 'kb_editorial' ? 'queued' : 'running',
            'source_scope' => (string) ($options['source_scope'] ?? 'kb_public'),
            'options_json' => $this->toJson($options),
            'cursor_json' => $this->toJson((array) ($options['cursor'] ?? [])),
            'revision' => 1,
            'context_hash' => $this->contextHash($context),
            'context_json' => $this->toJson($context),
            'counts_json' => $this->toJson([]),
            'lease_token' => null,
            'lease_until' => null,
            'processed_count' => 0,
            'suggestions_count' => 0,
            'message' => '',
            'started_at' => $now,
            'finished_at' => null,
            'created_at' => $now,
            'updated_at' => $now,
            ])
        ) {
            throw new \RuntimeException('editorial_job_insert_failed');
        }

        return $this->lastInsertId();
    }

    public function finishJob(int $jobId, string $status, int $processed, int $suggestions, string $message = ''): void
    {
        global $DB;

        if ($jobId <= 0) {
            return;
        }

        $DB->update(self::TABLE_JOBS, [
            'status' => $status,
            'processed_count' => max(0, $processed),
            'suggestions_count' => max(0, $suggestions),
            'message' => mb_substr($message, 0, 250, 'UTF-8'),
            'finished_at' => date('Y-m-d H:i:s'),
            'updated_at' => date('Y-m-d H:i:s'),
        ], array_merge(['id' => $jobId], $this->entityCriteria()));
    }

    public function createSuggestion(int $jobId, array $payload): int
    {
        global $DB;

        $now = date('Y-m-d H:i:s');
        if (
            !$DB->insert(self::TABLE_SUGGESTIONS, [
            'jobs_id' => max(0, $jobId),
            'entities_id' => $this->currentEntityId(),
            'source_type' => (string) ($payload['source_type'] ?? 'kb'),
            'title' => mb_substr((string) ($payload['title'] ?? ''), 0, 250, 'UTF-8'),
            'intent' => (string) ($payload['intent'] ?? 'kb_recomendar_contextual'),
            'confidence' => (string) round((float) ($payload['confidence'] ?? 0.7), 2),
            'keywords_json' => $this->toJson((array) ($payload['keywords'] ?? [])),
            'questions_json' => $this->toJson((array) ($payload['questions'] ?? [])),
            'kb_articles_json' => $this->toJson((array) ($payload['kb_articles'] ?? [])),
            'category_hint' => mb_substr((string) ($payload['category_hint'] ?? ''), 0, 250, 'UTF-8'),
            'group_hint' => mb_substr((string) ($payload['group_hint'] ?? ''), 0, 250, 'UTF-8'),
            'ticket_template_json' => $this->toJson((array) ($payload['ticket_template'] ?? [])),
            'status' => (string) ($payload['status'] ?? 'pending'),
            'content_json' => $this->toJson((array) ($payload['content'] ?? [])),
            'reviewed_by' => 0,
            'reviewed_at' => null,
            'created_at' => $now,
            'updated_at' => $now,
            'action' => (string) ($payload['action'] ?? 'create'),
            'target_playbook_id' => max(0, (int) ($payload['target_playbook_id'] ?? 0)),
            'expected_revision' => max(0, (int) ($payload['expected_revision'] ?? 0)),
            'evidence_json' => $this->toJson((array) ($payload['evidence'] ?? [])),
            'dedupe_key' => $payload['dedupe_key'] ?? null,
            'reason' => mb_substr((string) ($payload['reason'] ?? ''), 0, 250, 'UTF-8'),
            'revision' => 1,
            ])
        ) {
            return 0;
        }

        return $this->lastInsertId();
    }

    public function listSuggestions(string $status = 'pending', int $limit = 50): array
    {
        global $DB;

        $where = $this->entityCriteria();
        if ($status !== 'all') {
            $where['status'] = $status;
        }

        $criteria = [
            'FROM' => self::TABLE_SUGGESTIONS,
            'WHERE' => $where,
            'ORDER' => ['id DESC'],
            'LIMIT' => min(200, max(1, $limit)),
        ];

        return $this->decodeRows($DB->request($criteria));
    }

    public function getSuggestion(int $id): ?array
    {
        global $DB;

        $row = $DB->request([
            'FROM' => self::TABLE_SUGGESTIONS,
            'WHERE' => array_merge(['id' => $id], $this->entityCriteria()),
            'LIMIT' => 1,
        ])->current();

        if (!$row) {
            return null;
        }

        $rows = $this->decodeRows([$row]);
        return $rows[0] ?? null;
    }

    public function updateSuggestion(int $id, array $payload): bool
    {
        global $DB;

        $existing = $this->getSuggestion($id);
        if ($id <= 0 || $existing === null) {
            return false;
        }
        if (
            isset($payload['expected_revision'])
            && (int) $payload['expected_revision'] !== (int) ($existing['revision'] ?? 1)
        ) {
            return false;
        }

        return (bool) $DB->update(self::TABLE_SUGGESTIONS, [
            'title' => mb_substr((string) ($payload['title'] ?? $payload['name'] ?? ''), 0, 250, 'UTF-8'),
            'intent' => (string) ($payload['intent'] ?? 'kb_recomendar_contextual'),
            'confidence' => (string) round((float) ($payload['confidence'] ?? 0.7), 2),
            'keywords_json' => $this->toJson((array) ($payload['keywords'] ?? [])),
            'questions_json' => $this->toJson((array) ($payload['questions'] ?? [])),
            'kb_articles_json' => $this->toJson((array) ($payload['kb_articles'] ?? [])),
            'category_hint' => mb_substr((string) ($payload['category_hint'] ?? ''), 0, 250, 'UTF-8'),
            'group_hint' => mb_substr((string) ($payload['group_hint'] ?? ''), 0, 250, 'UTF-8'),
            'ticket_template_json' => $this->toJson((array) ($payload['ticket_template'] ?? [])),
            'content_json' => $this->toJson((array) ($payload['content'] ?? [])),
            'updated_at' => date('Y-m-d H:i:s'),
            'revision' => (int) ($existing['revision'] ?? 1) + 1,
        ], array_merge([
            'id' => $id,
            'status' => 'pending',
            'revision' => (int) ($existing['revision'] ?? 1),
        ], $this->entityCriteria())) && (int) $DB->affectedRows() === 1;
    }

    public function approveSuggestion(int $id, ?int $expectedProposalRevision = null): ?int
    {
        return $this->transaction(fn(): ?int => $this->approveManualSuggestion($id, $expectedProposalRevision));
    }

    public function approveManualSuggestionWithSources(
        int $id,
        array $evidence,
        int $expectedSuggestionRevision,
        ?callable $beforeCommit = null
    ): ?int {
        return $this->transaction(function () use ($id, $evidence, $expectedSuggestionRevision, $beforeCommit): ?int {
            $context = $this->currentJobContext();
            $suggestion = $this->getSuggestion($id);
            if ($suggestion === null || (int) ($suggestion['revision'] ?? 1) !== $expectedSuggestionRevision) {
                return null;
            }
            $this->assertCurrentEvidence($evidence, (array) ($suggestion['kb_articles'] ?? []));
            $target = $this->approveManualSuggestion($id, $expectedSuggestionRevision);
            if ($target !== null) {
                $this->replacePlaybookSources($target, $evidence);
            }
            $this->assertJobContext($context);
            if ($beforeCommit !== null) {
                $beforeCommit();
            }
            return $target;
        });
    }

    public function savePlaybookWithSources(
        array $payload,
        array $evidence,
        ?int $id = null,
        ?int $expectedRevision = null
    ): ?int {
        return $this->transaction(function () use ($payload, $evidence, $id, $expectedRevision): ?int {
            $context = $this->currentJobContext();
            $this->assertCurrentEvidence($evidence, (array) ($payload['kb_articles'] ?? []));
            if ($id === null) {
                $target = $this->createPlaybook($payload, !empty($payload['is_active']));
            } else {
                $existing = $this->getPlaybook($id);
                if (
                    $expectedRevision === null || $existing === null
                    || (int) ($existing['revision'] ?? 1) !== $expectedRevision
                ) {
                    return null;
                }
                if (!$this->updatePlaybook($id, array_merge($payload, ['expected_revision' => $expectedRevision]))) {
                    return null;
                }
                $target = $id;
            }
            $this->replacePlaybookSources($target, $evidence);
            $this->assertJobContext($context);
            return $target;
        });
    }

    private function approveManualSuggestion(int $id, ?int $expectedRevision = null): ?int
    {
        global $DB;

        $suggestion = $this->getSuggestion($id);
        if (
            $suggestion === null || (string) ($suggestion['status'] ?? '') !== 'pending'
            || !empty($suggestion['content']['import_requires_mapping'])
            || (string) ($suggestion['dedupe_key'] ?? '') !== ''
            || ($expectedRevision !== null && (int) ($suggestion['revision'] ?? 1) !== $expectedRevision)
        ) {
            return null;
        }

        $now = date('Y-m-d H:i:s');
        $claimed = (bool) $DB->update(self::TABLE_SUGGESTIONS, [
            'status' => 'approving',
            'updated_at' => $now,
        ], array_merge([
            'id' => $id,
            'status' => 'pending',
            'revision' => (int) ($suggestion['revision'] ?? 1),
        ], $this->entityCriteria()));
        if (!$claimed || (method_exists($DB, 'affectedRows') && (int) $DB->affectedRows() === 0)) {
            return null;
        }

        try {
            if (
                !$DB->insert(self::TABLE_PLAYBOOKS, [
                'entities_id' => (int) ($suggestion['entities_id'] ?? 0),
                'name' => (string) ($suggestion['title'] ?? ''),
                'intent' => (string) ($suggestion['intent'] ?? 'kb_recomendar_contextual'),
                'is_active' => 1,
                'source_suggestion_id' => $id,
                'keywords_json' => $this->toJson((array) ($suggestion['keywords'] ?? [])),
                'questions_json' => $this->toJson((array) ($suggestion['questions'] ?? [])),
                'kb_articles_json' => $this->toJson((array) ($suggestion['kb_articles'] ?? [])),
                'category_hint' => (string) ($suggestion['category_hint'] ?? ''),
                'group_hint' => (string) ($suggestion['group_hint'] ?? ''),
                'ticket_template_json' => $this->toJson((array) ($suggestion['ticket_template'] ?? [])),
                'content_json' => $this->toJson((array) ($suggestion['content'] ?? [])),
                'created_at' => $now,
                'updated_at' => $now,
                'revision' => 1,
                // This path is an explicit editorial decision, not legacy migration.
                'origin_type' => 'manual',
                'origin_proposal_id' => $id,
                ])
            ) {
                throw new \RuntimeException('editorial_manual_approval_insert_failed');
            }

            $playbookId = $this->lastInsertId();
            if ($playbookId <= 0) {
                throw new \RuntimeException('Falha ao registrar roteiro aprovado.');
            }

            if (
                !$DB->update(self::TABLE_SUGGESTIONS, [
                'status' => 'approved',
                'reviewed_by' => $this->currentUserId(),
                'reviewed_at' => $now,
                'updated_at' => $now,
                ], array_merge([
                'id' => $id,
                'status' => 'approving',
                ], $this->entityCriteria())) || (int) $DB->affectedRows() !== 1
            ) {
                throw new \RuntimeException('editorial_manual_decision_write_failed');
            }

            return $playbookId;
        } catch (\Throwable $e) {
            $DB->update(self::TABLE_SUGGESTIONS, [
                'status' => 'pending',
                'updated_at' => date('Y-m-d H:i:s'),
            ], array_merge([
                'id' => $id,
                'status' => 'approving',
            ], $this->entityCriteria()));
            throw $e;
        }
    }
    public function rejectSuggestion(int $id, ?int $expectedRevision = null, ?callable $beforeCommit = null): bool
    {
        return $this->transaction(function () use ($id, $expectedRevision, $beforeCommit): bool {
            global $DB;
            $existing = $this->getSuggestion($id);
            if (
                $existing === null || ($expectedRevision !== null
                && (int) ($existing['revision'] ?? 1) !== $expectedRevision)
            ) {
                return false;
            }

            $updated = (bool) $DB->update(self::TABLE_SUGGESTIONS, [
            'status' => 'rejected',
            'reviewed_by' => $this->currentUserId(),
            'reviewed_at' => date('Y-m-d H:i:s'),
            'updated_at' => date('Y-m-d H:i:s'),
            'revision' => (int) ($existing['revision'] ?? 1) + 1,
            ], array_merge([
            'id' => $id,
            'status' => 'pending',
            'revision' => (int) ($existing['revision'] ?? 1),
            ], $this->entityCriteria())) && (int) $DB->affectedRows() === 1;
            if ($beforeCommit !== null) {
                $beforeCommit();
            }
            return $updated;
        });
    }

    public function listActivePlaybooks(int $limit = 100): array
    {
        global $DB;

        return $this->decodeRows($DB->request([
            'FROM' => self::TABLE_PLAYBOOKS,
            'WHERE' => array_merge(['is_active' => 1], $this->entityCriteria()),
            'ORDER' => ['updated_at DESC', 'id DESC'],
            'LIMIT' => min(300, max(1, $limit)),
        ]));
    }

    public function listPlaybooks(int $limit = 100): array
    {
        global $DB;

        return $this->decodeRows($DB->request([
            'FROM' => self::TABLE_PLAYBOOKS,
            'WHERE' => $this->entityCriteria(),
            'ORDER' => ['updated_at DESC', 'id DESC'],
            'LIMIT' => min(300, max(1, $limit)),
        ]));
    }

    public function getPlaybook(int $id): ?array
    {
        global $DB;

        if ($id <= 0) {
            return null;
        }

        $row = $DB->request([
            'FROM' => self::TABLE_PLAYBOOKS,
            'WHERE' => array_merge(['id' => $id], $this->entityCriteria()),
            'LIMIT' => 1,
        ])->current();

        if (!$row) {
            return null;
        }

        $rows = $this->decodeRows([$row]);
        return $rows[0] ?? null;
    }

    public function updatePlaybook(int $id, array $payload): bool
    {
        global $DB;

        $existing = $this->getPlaybook($id);
        if ($id <= 0 || $existing === null) {
            return false;
        }
        if (
            isset($payload['expected_revision'])
            && (int) $payload['expected_revision'] !== (int) ($existing['revision'] ?? 1)
        ) {
            return false;
        }

        return (bool) $DB->update(self::TABLE_PLAYBOOKS, [
            'name' => mb_substr((string) ($payload['name'] ?? ''), 0, 250, 'UTF-8'),
            'intent' => (string) ($payload['intent'] ?? 'kb_recomendar_contextual'),
            'is_active' => (int) ($payload['is_active'] ?? 1),
            'keywords_json' => $this->toJson((array) ($payload['keywords'] ?? [])),
            'questions_json' => $this->toJson((array) ($payload['questions'] ?? [])),
            'kb_articles_json' => $this->toJson((array) ($payload['kb_articles'] ?? [])),
            'category_hint' => mb_substr((string) ($payload['category_hint'] ?? ''), 0, 250, 'UTF-8'),
            'group_hint' => mb_substr((string) ($payload['group_hint'] ?? ''), 0, 250, 'UTF-8'),
            'ticket_template_json' => $this->toJson((array) ($payload['ticket_template'] ?? [])),
            'content_json' => $this->toJson((array) ($payload['content'] ?? [])),
            'updated_at' => date('Y-m-d H:i:s'),
            'revision' => (int) ($existing['revision'] ?? 1) + 1,
            'origin_type' => isset($payload['origin_type'])
                ? $this->choice((string) $payload['origin_type'], ['manual', 'kb_derived', 'legacy'])
                : (string) ($existing['origin_type'] ?? 'legacy'),
        ], array_merge(['id' => $id, 'revision' => (int) ($existing['revision'] ?? 1)], $this->entityCriteria()))
            && (int) $DB->affectedRows() === 1;
    }

    public function createPlaybook(array $payload, bool $active = true): int
    {
        global $DB;

        $now = date('Y-m-d H:i:s');
        if (
            !$DB->insert(self::TABLE_PLAYBOOKS, [
            'entities_id' => $this->currentEntityId(),
            'name' => mb_substr((string) ($payload['name'] ?? ''), 0, 250, 'UTF-8'),
            'intent' => (string) ($payload['intent'] ?? 'kb_recomendar_contextual'),
            'is_active' => $active ? 1 : 0,
            'source_suggestion_id' => (int) ($payload['source_suggestion_id'] ?? 0),
            'keywords_json' => $this->toJson((array) ($payload['keywords'] ?? [])),
            'questions_json' => $this->toJson((array) ($payload['questions'] ?? [])),
            'kb_articles_json' => $this->toJson((array) ($payload['kb_articles'] ?? [])),
            'category_hint' => mb_substr((string) ($payload['category_hint'] ?? ''), 0, 250, 'UTF-8'),
            'group_hint' => mb_substr((string) ($payload['group_hint'] ?? ''), 0, 250, 'UTF-8'),
            'ticket_template_json' => $this->toJson((array) ($payload['ticket_template'] ?? [])),
            'content_json' => $this->toJson((array) ($payload['content'] ?? [])),
            'created_at' => $now,
            'updated_at' => $now,
            'revision' => 1,
            'origin_type' => (string) ($payload['origin_type'] ?? 'manual'),
            'topic_key' => mb_substr((string) ($payload['topic_key'] ?? ''), 0, 100, 'UTF-8'),
            'origin_proposal_id' => isset($payload['origin_proposal_id']) ? (int) $payload['origin_proposal_id'] : null,
            ])
        ) {
            throw new \RuntimeException('editorial_playbook_insert_failed');
        }

        return $this->lastInsertId();
    }

    public function deletePlaybook(int $id): bool
    {
        global $DB;

        if ($id <= 0) {
            return false;
        }

        return (bool) $DB->delete(self::TABLE_PLAYBOOKS, array_merge(['id' => $id], $this->entityCriteria()));
    }

    public function importApprovedPlaybooks(array $items): int
    {
        $result = $this->importPlaybooks($items, 'active');
        return (int) $result['active'] + (int) $result['inactive'];
    }

    public function importPlaybooks(array $items, string $defaultStatus = 'active'): array
    {
        global $DB;

        $result = [
            'active' => 0,
            'inactive' => 0,
            'pending' => 0,
            'skipped' => 0,
        ];
        $now = date('Y-m-d H:i:s');
        $defaultStatus = $this->normalizeStatus($defaultStatus);

        foreach ($items as $item) {
            if (!is_array($item)) {
                $result['skipped']++;
                continue;
            }
            $name = trim((string) ($item['name'] ?? $item['title'] ?? ''));
            if ($name === '') {
                $result['skipped']++;
                continue;
            }

            $status = $this->statusFromImportItem($item, $defaultStatus);
            // Native numeric IDs imported from another installation are not evidence.
            // Every source-dependent import waits for destination revalidation.
            if ((array) ($item['kb_articles'] ?? []) !== [] || (string) ($item['origin_type'] ?? '') === 'kb_derived') {
                $status = 'pending';
                $item['content'] = array_merge((array) ($item['content'] ?? []), ['import_requires_mapping' => true]);
            }
            // Foreign proposal targets, hashes and identities are never import authority.
            unset(
                $item['dedupe_key'],
                $item['action'],
                $item['target_playbook_id'],
                $item['expected_revision'],
                $item['evidence'],
                $item['origin_proposal_id']
            );
            if ($status === 'pending') {
                $this->createSuggestion(0, array_merge($item, [
                    'title' => $name,
                    'status' => 'pending',
                    'source_type' => 'manual_import',
                ]));
                $result['pending']++;
                continue;
            }

            $this->createPlaybook(array_merge($item, ['name' => $name]), $status === 'active');
            $result[$status === 'active' ? 'active' : 'inactive']++;
        }

        return $result;
    }

    public function exportApprovedPlaybooks(): array
    {
        return array_map(function (array $row): array {
            return [
                'name' => (string) ($row['name'] ?? ''),
                'intent' => (string) ($row['intent'] ?? ''),
                'status' => ((int) ($row['is_active'] ?? 0)) === 1 ? 'active' : 'inactive',
                'keywords' => (array) ($row['keywords'] ?? []),
                'questions' => (array) ($row['questions'] ?? []),
                'kb_articles' => (array) ($row['kb_articles'] ?? []),
                'category_hint' => (string) ($row['category_hint'] ?? ''),
                'group_hint' => (string) ($row['group_hint'] ?? ''),
                'ticket_template' => (array) ($row['ticket_template'] ?? []),
                'content' => (array) ($row['content'] ?? []),
                'origin_type' => (string) ($row['origin_type'] ?? 'legacy'),
                'topic_key' => (string) ($row['topic_key'] ?? ''),
                'source_evidence' => $this->getPlaybookSources((int) $row['id']),
            ];
        }, $this->listPlaybooks(300));
    }

    private function decodeRows(iterable $rows): array
    {
        $decoded = [];
        foreach ($rows as $row) {
            $item = (array) $row;
            $item['keywords'] = $this->fromJson((string) ($item['keywords_json'] ?? '[]'));
            $item['questions'] = $this->fromJson((string) ($item['questions_json'] ?? '[]'));
            $item['kb_articles'] = $this->fromJson((string) ($item['kb_articles_json'] ?? '[]'));
            $item['ticket_template'] = $this->fromJson((string) ($item['ticket_template_json'] ?? '[]'));
            $item['content'] = $this->fromJson((string) ($item['content_json'] ?? '[]'));
            $item['evidence'] = $this->fromJson((string) ($item['evidence_json'] ?? '[]'));
            $item['type'] = (string) ($item['action'] ?? 'create');
            $decoded[] = $item;
        }

        return $decoded;
    }

    private function toJson(array $data): string
    {
        $json = json_encode($data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
        return is_string($json) ? $json : '[]';
    }

    private function transaction(callable $callback): mixed
    {
        global $DB;
        if ($this->transactionDepth > 0) {
            return $callback();
        }
        foreach (['beginTransaction', 'commit', 'rollBack', 'affectedRows'] as $method) {
            if (!method_exists($DB, $method)) {
                throw new \RuntimeException('editorial_transactions_unavailable');
            }
        }
        if ($DB->beginTransaction() === false) {
            throw new \RuntimeException('editorial_transaction_start_failed');
        }
        $this->transactionDepth = 1;
        try {
            $result = $callback();
            if ($DB->commit() === false) {
                throw new \RuntimeException('editorial_commit_unknown');
            }
            return $result;
        } catch (\Throwable $error) {
            try {
                $DB->rollBack();
            } catch (\Throwable $rollbackError) {
                // A caller must reconcile an unknown outcome, never auto-replay it.
            }
            throw $error;
        } finally {
            $this->transactionDepth = 0;
        }
    }

    private function assertJobContext(array $context): void
    {
        if (
            $this->currentUserId() <= 0
            || $this->contextHash($context) !== $this->contextHash($this->currentJobContext())
        ) {
            throw new \RuntimeException('editorial_job_context_changed');
        }
    }

    private function contextHash(array $context): string
    {
        return hash('sha256', $this->toJson([
            'user_id' => (int) ($context['user_id'] ?? 0),
            'profile_id' => (int) ($context['profile_id'] ?? 0),
            'entity_id' => (int) ($context['entity_id'] ?? -1),
            'recursive' => (bool) ($context['recursive'] ?? false),
        ]));
    }

    private function jobMatchesContext(array $job, array $context): bool
    {
        return (string) ($job['context_hash'] ?? '') === $this->contextHash($context);
    }

    private function sourceIdentity(array $identity): array
    {
        $installation = trim((string) ($identity['installation_id'] ?? ''));
        $kind = (string) ($identity['source_type'] ?? $identity['source_kind'] ?? 'KnowbaseItem');
        $id = (int) ($identity['native_id'] ?? $identity['source_id'] ?? 0);
        if ($installation === '' || strlen($installation) > 64 || $kind !== 'KnowbaseItem' || $id <= 0) {
            throw new \InvalidArgumentException('invalid_knowledge_source_identity');
        }
        return ['installation_id' => $installation, 'source_kind' => $kind, 'native_id' => $id];
    }

    private function sourceRow(array $where): ?array
    {
        global $DB;
        $row = $DB->request(['FROM' => self::TABLE_SOURCES, 'WHERE' => $where, 'LIMIT' => 1])->current();
        return is_array($row) ? $row : null;
    }

    private function validatedHash(string $value): string
    {
        if (preg_match('/^[a-f0-9]{64}$/D', $value) !== 1) {
            throw new \InvalidArgumentException('invalid_editorial_hash');
        }
        return $value;
    }

    private function choice(string $value, array $allowed): string
    {
        if (!in_array($value, $allowed, true)) {
            throw new \InvalidArgumentException('invalid_editorial_choice');
        }
        return $value;
    }

    private function requiredInsertId(): int
    {
        $id = $this->lastInsertId();
        if ($id <= 0) {
            throw new \RuntimeException('editorial_insert_id_unavailable');
        }
        return $id;
    }

    private function dependencyRows(array $evidence): array
    {
        $rows = [];
        foreach ($this->normalizedEvidence($evidence) as $item) {
            $source = $this->sourceRow($this->sourceIdentity($item));
            if ($source === null) {
                throw new \RuntimeException('editorial_source_not_observed');
            }
            $key = (int) $source['id'] . ':' . $item['section'];
            $rows[$key] = [
                'source_id' => (int) $source['id'],
                'text_hash' => $item['text_hash'],
                'publication_hash' => $item['publication_hash'],
                'requirement' => $item['role'],
                'alternative_group' => $item['alternative_group'],
                'section' => $item['section'],
            ];
        }
        return array_values($rows);
    }

    private function normalizedEvidence(array $evidence): array
    {
        $result = [];
        foreach ($evidence as $item) {
            if (!is_array($item)) {
                throw new \InvalidArgumentException('invalid_editorial_evidence');
            }
            $identity = $this->sourceIdentity($item);
            $role = $this->choice(
                (string) ($item['role'] ?? $item['requirement'] ?? 'required'),
                ['required', 'alternative']
            );
            $group = mb_substr((string) ($item['alternative_group'] ?? ''), 0, 64, 'UTF-8');
            if ($role === 'alternative' && $group === '') {
                throw new \InvalidArgumentException('editorial_alternative_group_required');
            }
            $result[] = [
                'installation_id' => $identity['installation_id'],
                'source_type' => $identity['source_kind'],
                'source_id' => $identity['native_id'],
                'text_hash' => $this->validatedHash((string) ($item['text_hash'] ?? $item['content_hash'] ?? '')),
                'publication_hash' => $this->validatedHash((string) ($item['publication_hash'] ?? '')),
                'publication' => $this->choice(
                    (string) ($item['publication'] ?? 'unknown'),
                    ['published', 'unpublished', 'unknown']
                ),
                'validity' => $this->choice(
                    (string) ($item['validity'] ?? 'unknown'),
                    ['current', 'future', 'expired', 'unknown']
                ),
                'role' => $role,
                'alternative_group' => $group,
                'section' => mb_substr((string) ($item['section'] ?? ''), 0, 100, 'UTF-8'),
            ];
        }
        usort($result, static fn(array $a, array $b): int => strcmp(json_encode($a) ?: '', json_encode($b) ?: ''));
        return $result;
    }

    private function evidenceIsPublished(array $evidence): bool
    {
        $groups = [];
        foreach ($this->normalizedEvidence($evidence) as $item) {
            $eligible = $item['publication'] === 'published' && $item['validity'] === 'current';
            if ($item['role'] === 'required' && !$eligible) {
                return false;
            }
            if ($item['role'] === 'alternative') {
                $group = (string) $item['alternative_group'];
                $groups[$group] = ($groups[$group] ?? false) || $eligible;
            }
        }
        return !in_array(false, $groups, true);
    }

    private function assertCurrentEvidence(array $evidence, array $articles): void
    {
        if ($evidence === []) {
            if ($articles !== []) {
                throw new \RuntimeException('editorial_approved_dependencies_required');
            }
            return;
        }
        if (!$this->evidenceIsPublished($evidence)) {
            throw new \RuntimeException('editorial_dependency_not_eligible');
        }
        $sourceIds = [];
        foreach ($this->normalizedEvidence($evidence) as $item) {
            $source = $this->sourceRow($this->sourceIdentity($item));
            if (
                $source === null || $source['text_hash'] !== $item['text_hash']
                || $source['publication_hash'] !== $item['publication_hash']
                || $source['publication'] !== $item['publication']
                || $source['validity'] !== $item['validity']
            ) {
                throw new \RuntimeException('editorial_source_evidence_changed');
            }
            $sourceIds[(int) $item['source_id']] = true;
        }
        foreach ($articles as $article) {
            if (!is_array($article) || !isset($sourceIds[(int) ($article['id'] ?? 0)])) {
                throw new \RuntimeException('editorial_article_dependency_missing');
            }
        }
    }

    private function playbookContentData(array $payload): array
    {
        return [
            'name' => mb_substr((string) ($payload['title'] ?? $payload['name'] ?? ''), 0, 250, 'UTF-8'),
            'keywords_json' => $this->toJson((array) ($payload['keywords'] ?? [])),
            'questions_json' => $this->toJson((array) ($payload['questions'] ?? [])),
            'kb_articles_json' => $this->toJson((array) ($payload['kb_articles'] ?? [])),
            'content_json' => $this->toJson((array) ($payload['content'] ?? [])),
            'category_hint' => mb_substr((string) ($payload['category_hint'] ?? ''), 0, 250, 'UTF-8'),
        ];
    }

    private function fromJson(string $json): array
    {
        $decoded = json_decode($json, true);
        return is_array($decoded) ? $decoded : [];
    }

    private function statusFromImportItem(array $item, string $defaultStatus): string
    {
        if (array_key_exists('is_active', $item)) {
            $value = $item['is_active'];
            return ($value === true || $value === 1 || $value === '1' || $value === 'true') ? 'active' : 'inactive';
        }

        return $this->normalizeStatus((string) ($item['status'] ?? $defaultStatus));
    }

    private function normalizeStatus(string $status): string
    {
        $status = strtolower(trim($status));
        if (in_array($status, ['pending', 'pendente', 'review', 'analise', 'analysis'], true)) {
            return 'pending';
        }
        if (in_array($status, ['inactive', 'inativo', 'disabled', 'desativado', '0'], true)) {
            return 'inactive';
        }

        return 'active';
    }

    private function currentUserId(): int
    {
        return (int) ($_SESSION['glpiID'] ?? 0);
    }

    private function currentEntityId(): int
    {
        $active = $_SESSION['glpiactive_entity'] ?? null;
        if (!is_int($active) && !(is_string($active) && ctype_digit($active))) {
            throw new \RuntimeException('Selecione uma entidade especifica antes de alterar roteiros.');
        }

        return max(0, (int) $active);
    }

    /** @return int[] */
    private function currentEntityIds(): array
    {
        $activeEntities = null;
        if (class_exists('\Session') && method_exists('\Session', 'getActiveEntities')) {
            $activeEntities = \Session::getActiveEntities();
        }
        if (!is_array($activeEntities)) {
            $activeEntities = (array) ($_SESSION['glpiactiveentities'] ?? []);
        }

        $entities = [];
        foreach ($activeEntities as $key => $value) {
            $candidate = is_numeric($value) ? (int) $value : (is_numeric($key) ? (int) $key : -1);
            if ($candidate >= 0) {
                $entities[$candidate] = $candidate;
            }
        }

        if ($entities !== []) {
            return array_values($entities);
        }

        $active = $_SESSION['glpiactive_entity'] ?? null;
        if (is_int($active) || (is_string($active) && ctype_digit($active))) {
            return [max(0, (int) $active)];
        }

        return [-1];
    }

    /** @return array{entities_id:int|int[]} */
    private function entityCriteria(): array
    {
        $entities = $this->currentEntityIds();
        return ['entities_id' => count($entities) === 1 ? $entities[0] : $entities];
    }

    private function lastInsertId(): int
    {
        global $DB;

        if (method_exists($DB, 'insertId')) {
            return (int) $DB->insertId();
        }

        return 0;
    }
}
