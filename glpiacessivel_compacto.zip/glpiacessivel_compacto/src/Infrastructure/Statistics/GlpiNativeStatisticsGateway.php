<?php

declare(strict_types=1);

namespace GlpiPlugin\Glpiacessivel\Infrastructure\Statistics;

use GlpiPlugin\Glpiacessivel\Application\NativeTicketStatisticsException;
use GlpiPlugin\Glpiacessivel\Application\NativeTicketStatisticsGateway;
use GlpiPlugin\Glpiacessivel\Infrastructure\Http\NativeTicketReportLinks;

/** Public Stat APIs only, within the current authenticated native context. */
final class GlpiNativeStatisticsGateway implements NativeTicketStatisticsGateway
{
    private string $version;
    private \Closure $itemsCall;
    private \Closure $dataCall;
    private \Closure $available;
    private \Closure $authorized;

    public function __construct(
        ?string $version = null,
        ?callable $itemsCall = null,
        ?callable $dataCall = null,
        ?callable $available = null,
        ?callable $authorized = null
    ) {
        $this->version = $version ?? (defined('GLPI_VERSION') ? (string) GLPI_VERSION : '');
        $this->itemsCall = $itemsCall === null
            ? static fn(...$args) => \Stat::getItems(...$args) : \Closure::fromCallable($itemsCall);
        $this->dataCall = $dataCall === null
            ? static fn(...$args) => \Stat::getData(...$args) : \Closure::fromCallable($dataCall);
        $this->available = $available === null
            ? static fn(): bool => is_callable(['Stat', 'getItems']) && is_callable(['Stat', 'getData'])
            : \Closure::fromCallable($available);
        $this->authorized = $authorized === null
            ? static fn(): bool => defined('READ') && is_callable(['Session', 'getLoginUserID'])
                && is_callable(['Session', 'haveRight']) && (int) \Session::getLoginUserID() > 0
                && \Session::haveRight('statistic', READ)
            : \Closure::fromCallable($authorized);
    }

    public function capabilities(): array
    {
        $supported = preg_match('/\A(10|11)\.\d+\.\d+(?:[-+][a-zA-Z0-9.-]+)?\z/D', $this->version) === 1;
        try {
            $supported = $supported && (bool) ($this->available)();
        } catch (\Throwable) {
            $supported = false;
        }
        return ['assigned' => $supported, 'tasks' => false,
            'reason' => $supported ? '' : 'native_statistics_contract_unavailable',
            'tasks_reason' => 'native_statistics_tasks_not_homologated'];
    }

    public function pageSize(): int
    {
        $this->guard();
        $size = $_SESSION['glpilist_limit'] ?? null;
        if (is_string($size) && preg_match('/\A[1-9][0-9]{0,2}\z/D', $size) === 1) {
            $size = (int) $size;
        }
        // Refuse unsupported/special preferences; never replace or save them.
        if (!is_int($size) || $size < 1 || $size > 100) {
            throw new NativeTicketStatisticsException('native_statistics_limit_unsupported');
        }
        return $size;
    }

    public function context(): array
    {
        $this->guard();
        $snapshot = [];
        foreach (
            ['glpiID', 'glpiactive_entity', 'glpiactiveentities',
            'glpirecursive', 'glpiactive_entity_recursive', 'glpilist_limit'] as $key
        ) {
            $snapshot[$key] = $_SESSION[$key] ?? null;
        }
        // Native ACL checks may hydrate auxiliary profile caches. Those are not
        // context changes; rights themselves are rechecked by every guard().
        $snapshot['profile'] = ['id' => $_SESSION['glpiactiveprofile']['id'] ?? null,
            'interface' => $_SESSION['glpiactiveprofile']['interface'] ?? null];
        return $snapshot;
    }

    public function items(string $mode, string $date1, string $date2): array
    {
        $this->guard();
        return $this->invoke($this->itemsCall, ['Ticket', $date1, $date2, $this->nativeType($mode), 0]);
    }

    public function data(string $mode, string $date1, string $date2, array $nativeItem): array
    {
        $this->guard();
        $this->pageSize();
        // One original item per call avoids collisions in GLPI's label-keyed response.
        return $this->invoke($this->dataCall, ['Ticket', $this->nativeType($mode), $date1, $date2, 0,
            [$nativeItem], '']);
    }

    private function nativeType(string $mode): string
    {
        if ($mode !== 'assigned') {
            throw new NativeTicketStatisticsException('native_statistics_mode_unsupported', 'mode');
        }
        $type = (new NativeTicketReportLinks($this->version))->nativeTypeForMode($mode);
        if ($type === null) {
            throw new NativeTicketStatisticsException('native_statistics_mode_unsupported', 'mode');
        }
        return $type;
    }

    private function guard(): void
    {
        try {
            $authorized = (bool) ($this->authorized)();
        } catch (\Throwable) {
            $authorized = false;
        }
        if (!$authorized) {
            throw new NativeTicketStatisticsException('native_statistics_forbidden');
        }
        if (!$this->capabilities()['assigned']) {
            throw new NativeTicketStatisticsException('native_statistics_contract_unavailable');
        }
    }

    private function invoke(\Closure $call, array $arguments): array
    {
        try {
            $result = $call(...$arguments);
        } catch (\Throwable) {
            throw new NativeTicketStatisticsException('native_statistics_query_failed');
        }
        if (!is_array($result)) {
            throw new NativeTicketStatisticsException('native_statistics_response_invalid');
        }
        return $result;
    }
}
