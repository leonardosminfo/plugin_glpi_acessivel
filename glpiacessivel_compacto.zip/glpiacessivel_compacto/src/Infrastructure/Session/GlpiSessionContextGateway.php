<?php

declare(strict_types=1);

namespace GlpiPlugin\Glpiacessivel\Infrastructure\Session;

use GlpiPlugin\Glpiacessivel\Support\TextNormalizer;

/**
 * Narrow integration boundary for GLPI's native profile/entity session APIs.
 */
final class GlpiSessionContextGateway
{
    /** @var array<string,array<string,mixed>> */
    private array $entityCatalogMemo = [];

    public function changeProfile(int $profileId): bool
    {
        if ($profileId <= 0 || !method_exists('\Session', 'changeProfile')) {
            return false;
        }
        \Session::changeProfile($profileId);
        return (int) ($_SESSION['glpiactiveprofile']['id'] ?? 0) === $profileId;
    }

    /** @param int|string $entityId */
    public function changeEntity($entityId, bool $recursive): bool
    {
        if (!method_exists('\Session', 'changeActiveEntities')) {
            return false;
        }
        return \Session::changeActiveEntities($entityId, $recursive) === true;
    }

    /**
     * Read the entity choices from the same native tree builders used by GLPI.
     *
     * GLPI 10.0.18 and recent GLPI 11 releases expose
     * Entity::getEntitySelectorTree(), the exact source used by the native
     * entity selector. Older releases fall back to their native tree builder.
     * The returned contract deliberately contains text only: HTML rendered by
     * the native selector is never reused by the accessible interface.
     *
     * @return array{
     *   complete:bool,
     *   source:string,
     *   reason_code:string,
     *   nodes:array<int,array{
     *     id:int,name:string,path:array<int,string>,depth:int,has_children:bool
     *   }>
     * }
     */
    public function availableEntityCatalog(): array
    {
        try {
            $assignments = $this->profileEntityAssignments();
        } catch (\Throwable $e) {
            return $this->unavailableEntityCatalog('invalid_profile_entities');
        }

        if ($assignments === []) {
            return $this->unavailableEntityCatalog('empty_profile_entities');
        }

        $source = $this->nativeEntityTreeSource($assignments);
        $memoKey = hash('sha256', $source . '|' . serialize($assignments));
        if (isset($this->entityCatalogMemo[$memoKey])) {
            return $this->entityCatalogMemo[$memoKey];
        }

        try {
            if ($source === 'unavailable') {
                throw new \RuntimeException('native_entity_selector_unavailable');
            }
            if ($source === 'glpi_entity_selector_tree') {
                $nodes = $this->nativeEntitySelectorNodes($assignments);
            } else {
                $trees = [];
                $recursiveAssignments = array_values(array_filter(
                    $assignments,
                    static fn (array $assignment): bool => $assignment['recursive']
                ));
                $directAssignments = array_values(array_filter(
                    $assignments,
                    static fn (array $assignment): bool => !$assignment['recursive']
                ));
                foreach (array_merge($recursiveAssignments, $directAssignments) as $assignment) {
                    $entityId = $assignment['id'];
                    if ($assignment['recursive']) {
                        $tree = $this->nativeEntityTree($entityId, $source);
                    } else {
                        $tree = [
                            $entityId => [
                                'name' => $assignment['name'],
                                'tree' => [],
                            ],
                        ];
                    }

                    if (!array_key_exists($entityId, $tree)) {
                        throw new \UnexpectedValueException('native_entity_tree_missing_root');
                    }
                    $trees[] = $tree;
                }
                $nodes = $this->flattenNativeEntityTrees($trees);
            }
            if ($nodes === []) {
                throw new \UnexpectedValueException('native_entity_tree_empty');
            }

            $catalog = [
                'complete' => true,
                'source' => $source,
                'reason_code' => '',
                'nodes' => $nodes,
            ];
        } catch (\Throwable $e) {
            // Keep only our enumerated contract failures; native exception
            // messages may contain database details or sensitive context.
            $catalog = $this->unavailableEntityCatalog($this->catalogFailureReason($e));
        }

        $this->entityCatalogMemo[$memoKey] = $catalog;

        return $catalog;
    }

    /**
     * Determine whether the effective native session covers the full entity
     * catalog authorized by the active profile.
     *
     * GLPI 11 persists glpientity_fullstructure, including false when a
     * recursive root happens to cover every authorized entity. That native
     * marker is authoritative whenever it exists. GLPI 10 does not persist
     * it: it stores the first authorized entity as glpiactive_entity and the
     * complete effective union in glpiactiveentities. In that version, the
     * native "all" transition uses recursive=false, while a concrete tree
     * uses recursive=true. Exact set equality is therefore used only when the
     * GLPI 11 marker is absent and the active context is not recursive. A
     * one-node catalog is kept concrete, matching the option exposed by
     * ContextService.
     *
     * @param null|array<string,mixed> $catalog
     */
    public function isFullStructure(?array $catalog = null): bool
    {
        if (($_SESSION['glpiactive_entity'] ?? null) === 'all') {
            return true;
        }

        if (array_key_exists('glpientity_fullstructure', $_SESSION)) {
            return !empty($_SESSION['glpientity_fullstructure']);
        }

        if (!empty($_SESSION['glpiactive_entity_recursive'])) {
            return false;
        }

        $catalog = $catalog ?? $this->availableEntityCatalog();
        if (empty($catalog['complete'])) {
            return false;
        }

        $catalogEntityIds = $this->catalogEntityIds($catalog);
        if (count($catalogEntityIds) <= 1) {
            return false;
        }

        return $this->activeEntityIds() === $catalogEntityIds;
    }

    /**
     * @return array{
     *   profile_id:int,entity_id:int,entity_value:string,recursive:bool,
     *   active_entities_hash:string,context_fingerprint:string
     * }
     */
    public function snapshot(): array
    {
        $activeEntities = $this->activeEntityIds();
        $catalog = $this->availableEntityCatalog();
        $allEntities = $this->isFullStructure($catalog);
        $snapshot = [
            'profile_id' => max(0, (int) ($_SESSION['glpiactiveprofile']['id'] ?? 0)),
            'entity_id' => max(0, (int) ($_SESSION['glpiactive_entity'] ?? 0)),
            'entity_value' => $allEntities ? 'all' : (string) max(0, (int) ($_SESSION['glpiactive_entity'] ?? 0)),
            'recursive' => !empty($_SESSION['glpiactive_entity_recursive']),
            'active_entities_hash' => hash('sha256', implode(',', $activeEntities)),
        ];
        $snapshot['context_fingerprint'] = hash('sha256', implode('|', [
            (string) $snapshot['profile_id'],
            $snapshot['entity_value'],
            $snapshot['recursive'] ? '1' : '0',
            $snapshot['active_entities_hash'],
        ]));

        return $snapshot;
    }

    /** @return list<int> */
    private function activeEntityIds(): array
    {
        $activeEntities = [];
        foreach ((array) ($_SESSION['glpiactiveentities'] ?? []) as $key => $value) {
            $candidate = is_numeric($value) ? (int) $value : (is_numeric($key) ? (int) $key : -1);
            if ($candidate >= 0) {
                $activeEntities[] = $candidate;
            }
        }

        $activeEntities = array_values(array_unique($activeEntities));
        sort($activeEntities, SORT_NUMERIC);

        return $activeEntities;
    }

    /** @param array<string,mixed> $catalog @return list<int> */
    private function catalogEntityIds(array $catalog): array
    {
        $catalogEntityIds = [];
        foreach ((array) ($catalog['nodes'] ?? []) as $node) {
            if (!is_array($node)) {
                continue;
            }

            $rawId = $node['id'] ?? null;
            if (!(is_int($rawId) || (is_string($rawId) && preg_match('/^\d+$/D', $rawId) === 1))) {
                continue;
            }

            $entityId = (int) $rawId;
            if ($entityId >= 0) {
                $catalogEntityIds[] = $entityId;
            }
        }

        $catalogEntityIds = array_values(array_unique($catalogEntityIds));
        sort($catalogEntityIds, SORT_NUMERIC);

        return $catalogEntityIds;
    }

    /**
     * @return array<int,array{id:int,recursive:bool,name:string}>
     */
    private function profileEntityAssignments(): array
    {
        $assignments = [];
        $positions = [];
        foreach ((array) ($_SESSION['glpiactiveprofile']['entities'] ?? []) as $entity) {
            if (!is_array($entity) || !array_key_exists('id', $entity)) {
                throw new \UnexpectedValueException('invalid_profile_entity');
            }

            $rawId = $entity['id'];
            if (!(is_int($rawId) || (is_string($rawId) && preg_match('/^\d+$/D', $rawId) === 1))) {
                throw new \UnexpectedValueException('invalid_profile_entity_id');
            }
            $entityId = (int) $rawId;
            if ($entityId < 0) {
                throw new \UnexpectedValueException('invalid_profile_entity_id');
            }

            $name = TextNormalizer::fromGlpi((string) ($entity['name'] ?? $entity['completename'] ?? ''));
            if ($name === '') {
                $name = $this->entityFallbackName($entityId);
            }

            if (isset($positions[$entityId])) {
                $position = $positions[$entityId];
                $assignments[$position]['recursive'] = $assignments[$position]['recursive']
                    || !empty($entity['is_recursive']);
                continue;
            }

            $positions[$entityId] = count($assignments);
            $assignments[] = [
                'id' => $entityId,
                'recursive' => !empty($entity['is_recursive']),
                'name' => $name,
            ];
        }

        return $assignments;
    }

    /**
     * @param array<int,array{id:int,recursive:bool,name:string}> $assignments
     */
    private function nativeEntityTreeSource(array $assignments): string
    {
        if (method_exists('\Entity', 'getEntitySelectorTree')) {
            return is_callable(['\Entity', 'getEntitySelectorTree'])
                ? 'glpi_entity_selector_tree'
                : 'unavailable';
        }

        $requiresTree = false;
        foreach ($assignments as $assignment) {
            if ($assignment['recursive']) {
                $requiresTree = true;
                break;
            }
        }

        if (!$requiresTree) {
            return 'profile_entities';
        }
        if (function_exists('getTreeForItem')) {
            return 'glpi_tree_for_item';
        }
        if ($this->hasPublicDbUtilsTreeBuilder()) {
            return 'glpi_dbutils_tree_for_item';
        }

        return 'unavailable';
    }

    /**
     * Normalize the same structured tree returned by GLPI's native entity
     * selector. Only identifiers and child relationships are consumed. The
     * native `title` field contains presentation HTML and is intentionally
     * ignored; entity names are resolved as plain text through GLPI APIs.
     *
     * @param array<int,array{id:int,recursive:bool,name:string}> $assignments
     * @return array<int,array{id:int,name:string,path:array<int,string>,depth:int,has_children:bool}>
     */
    private function nativeEntitySelectorNodes(array $assignments): array
    {
        $rawTree = call_user_func(['\Entity', 'getEntitySelectorTree']);
        if (!is_array($rawTree)) {
            throw new \UnexpectedValueException('invalid_native_entity_selector_tree');
        }

        $assignmentsById = [];
        foreach ($assignments as $assignment) {
            $assignmentsById[$assignment['id']] = $assignment;
        }

        $nodes = [];
        $positions = [];
        $seenRoots = [];
        $visit = function (
            array $branch,
            array $ancestors,
            bool $rootLevel
        ) use (
            &$visit,
            &$nodes,
            &$positions,
            &$seenRoots,
            $assignmentsById
        ): void {
            foreach ($branch as $rawNode) {
                if (!is_array($rawNode) || !array_key_exists('key', $rawNode)) {
                    throw new \UnexpectedValueException('invalid_native_entity_selector_node');
                }

                $rawId = $rawNode['key'];
                if (!(is_int($rawId) || (is_string($rawId) && preg_match('/^\d+$/D', $rawId) === 1))) {
                    throw new \UnexpectedValueException('invalid_native_entity_selector_id');
                }
                $entityId = (int) $rawId;
                if ($entityId < 0 || isset($ancestors[$entityId])) {
                    throw new \UnexpectedValueException('invalid_native_entity_selector_node');
                }

                $children = $rawNode['children'] ?? [];
                if (!is_array($children)) {
                    throw new \UnexpectedValueException('invalid_native_entity_selector_children');
                }
                $folder = $rawNode['folder'] ?? false;
                if (!is_bool($folder) || $folder !== ($children !== [])) {
                    throw new \UnexpectedValueException('invalid_native_entity_selector_folder');
                }
                $hasChildren = $folder;

                if ($rootLevel) {
                    if (!isset($assignmentsById[$entityId])) {
                        throw new \UnexpectedValueException('unexpected_native_entity_selector_root');
                    }
                    if (!$assignmentsById[$entityId]['recursive'] && $hasChildren) {
                        throw new \UnexpectedValueException('non_recursive_entity_selector_children');
                    }
                    $seenRoots[$entityId] = true;
                }

                $name = $this->nativeSelectorEntityName($entityId);

                // GLPI 10 selector nodes omit `name`; Dropdown then supplies a
                // canonical complete name. Keep it as the complete path rather
                // than trying to parse a literal `>` from an entity name.
                $path = [$name];
                if (!isset($positions[$entityId])) {
                    $positions[$entityId] = count($nodes);
                    $nodes[] = [
                        'id' => $entityId,
                        'name' => $name,
                        'path' => $path,
                        'depth' => count($ancestors),
                        'has_children' => $hasChildren,
                    ];
                } elseif ($hasChildren) {
                    $nodes[$positions[$entityId]]['has_children'] = true;
                }

                if (!$hasChildren) {
                    continue;
                }
                $nextAncestors = $ancestors;
                $nextAncestors[$entityId] = true;
                $visit($children, $nextAncestors, false);
            }
        };
        $visit($rawTree, [], true);

        foreach ($assignmentsById as $entityId => $_assignment) {
            if (!isset($seenRoots[$entityId])) {
                throw new \UnexpectedValueException('native_entity_selector_missing_root');
            }
        }
        if ($nodes === []) {
            throw new \UnexpectedValueException('native_entity_selector_empty');
        }

        return $nodes;
    }

    /** @return array<int,array<string,mixed>> */
    private function nativeEntityTree(int $entityId, string $source): array
    {
        if ($source === 'glpi_tree_for_item') {
            $tree = getTreeForItem('glpi_entities', $entityId);
        } elseif ($source === 'glpi_dbutils_tree_for_item') {
            $dbUtils = (new \ReflectionClass('\DbUtils'))->newInstance();
            $tree = call_user_func([$dbUtils, 'getTreeForItem'], 'glpi_entities', $entityId);
        } else {
            throw new \RuntimeException('native_entity_tree_api_unavailable');
        }

        if (!is_array($tree)) {
            throw new \UnexpectedValueException('invalid_native_entity_tree');
        }

        return $tree;
    }

    private function nativeSelectorEntityName(int $entityId): string
    {
        if (!class_exists('\Dropdown') || !is_callable(['\Dropdown', 'getDropdownName'])) {
            throw new \RuntimeException('native_entity_name_api_unavailable');
        }

        $name = TextNormalizer::fromGlpi((string) \Dropdown::getDropdownName(
            'glpi_entities',
            $entityId,
            false,
            true,
            false,
            ''
        ));
        if ($name === '') {
            throw new \UnexpectedValueException('invalid_native_entity_selector_name');
        }

        return $name;
    }

    private function hasPublicDbUtilsTreeBuilder(): bool
    {
        if (!class_exists('\DbUtils') || !method_exists('\DbUtils', 'getTreeForItem')) {
            return false;
        }

        try {
            $method = new \ReflectionMethod('\DbUtils', 'getTreeForItem');
            return $method->isPublic() && !$method->isStatic();
        } catch (\ReflectionException $e) {
            return false;
        }
    }

    /**
     * @param array<int,array<int,array<string,mixed>>> $trees
     * @return array<int,array{
     *   id:int,name:string,path:array<int,string>,depth:int,has_children:bool
     * }>
     */
    private function flattenNativeEntityTrees(array $trees): array
    {
        $trees = $this->orderNativeEntityTreesByContainment($trees);
        $nodes = [];
        $positions = [];
        $expanded = [];

        $visit = function (
            array $tree,
            array $parentPath,
            array $ancestors
        ) use (
            &$visit,
            &$nodes,
            &$positions,
            &$expanded
        ): void {
            foreach ($tree as $rawId => $rawNode) {
                if (!(is_int($rawId) || (is_string($rawId) && preg_match('/^\d+$/D', $rawId) === 1))) {
                    throw new \UnexpectedValueException('invalid_native_entity_id');
                }
                $entityId = (int) $rawId;
                if ($entityId < 0 || !is_array($rawNode) || isset($ancestors[$entityId])) {
                    throw new \UnexpectedValueException('invalid_native_entity_node');
                }

                $name = TextNormalizer::fromGlpi((string) ($rawNode['name'] ?? ''));
                if ($name === '') {
                    throw new \UnexpectedValueException('invalid_native_entity_name');
                }
                $children = $rawNode['tree'] ?? [];
                if (!is_array($children)) {
                    throw new \UnexpectedValueException('invalid_native_entity_children');
                }

                $path = array_merge($parentPath, [$name]);
                $hasChildren = $children !== [];
                if (!isset($positions[$entityId])) {
                    $positions[$entityId] = count($nodes);
                    $nodes[] = [
                        'id' => $entityId,
                        'name' => $name,
                        'path' => $path,
                        'depth' => count($parentPath),
                        'has_children' => $hasChildren,
                    ];
                } elseif ($hasChildren) {
                    $nodes[$positions[$entityId]]['has_children'] = true;
                }

                if (!$hasChildren || isset($expanded[$entityId])) {
                    continue;
                }

                $expanded[$entityId] = true;
                $canonicalPath = $nodes[$positions[$entityId]]['path'];
                $nextAncestors = $ancestors;
                $nextAncestors[$entityId] = true;
                $visit($children, $canonicalPath, $nextAncestors);
            }
        };

        foreach ($trees as $tree) {
            $visit($tree, [], []);
        }

        return $nodes;
    }

    /**
     * Put broader native trees before any overlapping descendant tree.
     *
     * Profile assignments are not guaranteed to be stored in hierarchy order.
     * Visiting a descendant first would make the global de-duplication keep its
     * truncated path and place it before its authorized ancestor.
     *
     * @param array<int,array<int,array<string,mixed>>> $trees
     * @return array<int,array<int,array<string,mixed>>>
     */
    private function orderNativeEntityTreesByContainment(array $trees): array
    {
        if (count($trees) < 2) {
            return array_values($trees);
        }

        $indexedTrees = [];
        foreach (array_values($trees) as $position => $tree) {
            if (count($tree) !== 1) {
                throw new \UnexpectedValueException('invalid_native_entity_tree_roots');
            }

            $rawRootId = array_key_first($tree);
            $isValidRootId = is_int($rawRootId)
                || (is_string($rawRootId) && preg_match('/^\d+$/D', $rawRootId) === 1);
            if (!$isValidRootId) {
                throw new \UnexpectedValueException('invalid_native_entity_id');
            }
            $rootId = (int) $rawRootId;
            if ($rootId < 0) {
                throw new \UnexpectedValueException('invalid_native_entity_id');
            }

            $indexedTrees[] = [
                'tree' => $tree,
                'root_id' => $rootId,
                'member_ids' => $this->nativeEntityTreeIds($tree),
                'original_position' => $position,
                'container_count' => 0,
            ];
        }

        foreach ($indexedTrees as $candidatePosition => $candidate) {
            foreach ($indexedTrees as $containerPosition => $container) {
                if ($candidatePosition === $containerPosition) {
                    continue;
                }
                if (isset($container['member_ids'][$candidate['root_id']])) {
                    ++$indexedTrees[$candidatePosition]['container_count'];
                }
            }
        }

        usort(
            $indexedTrees,
            static function (array $left, array $right): int {
                $byContainment = $left['container_count'] <=> $right['container_count'];
                if ($byContainment !== 0) {
                    return $byContainment;
                }

                return $left['original_position'] <=> $right['original_position'];
            }
        );

        return array_values(array_map(
            static fn (array $indexedTree): array => $indexedTree['tree'],
            $indexedTrees
        ));
    }

    /**
     * @param array<int,array<string,mixed>> $tree
     * @return array<int,true>
     */
    private function nativeEntityTreeIds(array $tree): array
    {
        $ids = [];
        $collect = function (array $branch, array $ancestors) use (&$collect, &$ids): void {
            foreach ($branch as $rawId => $rawNode) {
                $isValidEntityId = is_int($rawId)
                    || (is_string($rawId) && preg_match('/^\d+$/D', $rawId) === 1);
                if (!$isValidEntityId) {
                    throw new \UnexpectedValueException('invalid_native_entity_id');
                }
                $entityId = (int) $rawId;
                if ($entityId < 0 || !is_array($rawNode) || isset($ancestors[$entityId])) {
                    throw new \UnexpectedValueException('invalid_native_entity_node');
                }

                $children = $rawNode['tree'] ?? [];
                if (!is_array($children)) {
                    throw new \UnexpectedValueException('invalid_native_entity_children');
                }

                $ids[$entityId] = true;
                if ($children === []) {
                    continue;
                }

                $nextAncestors = $ancestors;
                $nextAncestors[$entityId] = true;
                $collect($children, $nextAncestors);
            }
        };
        $collect($tree, []);

        return $ids;
    }

    private function entityFallbackName(int $entityId): string
    {
        $activeEntityId = (int) ($_SESSION['glpiactive_entity'] ?? -1);
        if ($activeEntityId === $entityId) {
            $activeName = TextNormalizer::fromGlpi((string) ($_SESSION['glpiactive_entity_name'] ?? ''));
            if ($activeName !== '') {
                return $activeName;
            }
        }

        if (class_exists('\Dropdown')) {
            $name = TextNormalizer::fromGlpi((string) \Dropdown::getDropdownName('glpi_entities', $entityId));
            if ($name !== '') {
                return $name;
            }
        }

        return $entityId === 0 ? 'Entidade raiz' : ('Entidade ' . $entityId);
    }

    /** @return array{complete:bool,source:string,reason_code:string,nodes:array<int,mixed>} */
    private function unavailableEntityCatalog(string $reasonCode): array
    {
        return [
            'complete' => false,
            'source' => 'unavailable',
            'reason_code' => $reasonCode,
            'nodes' => [],
        ];
    }

    private function catalogFailureReason(\Throwable $error): string
    {
        $knownReasons = [
            'native_entity_selector_unavailable',
            'native_entity_tree_missing_root',
            'native_entity_tree_empty',
            'invalid_native_entity_selector_tree',
            'invalid_native_entity_selector_node',
            'invalid_native_entity_selector_id',
            'invalid_native_entity_selector_children',
            'invalid_native_entity_selector_folder',
            'unexpected_native_entity_selector_root',
            'non_recursive_entity_selector_children',
            'native_entity_selector_missing_root',
            'native_entity_selector_empty',
            'native_entity_tree_api_unavailable',
            'invalid_native_entity_tree',
            'native_entity_name_api_unavailable',
            'invalid_native_entity_selector_name',
            'invalid_native_entity_id',
            'invalid_native_entity_node',
            'invalid_native_entity_name',
            'invalid_native_entity_children',
            'invalid_native_entity_tree_roots',
        ];
        $reason = $error->getMessage();

        return in_array($reason, $knownReasons, true) ? $reason : 'native_entity_tree_unavailable';
    }

    /**
     * Persist all pending writes before a redirect. No session data may be
     * changed by the caller after this method returns true.
     */
    public function commit(): bool
    {
        if (session_status() !== PHP_SESSION_ACTIVE) {
            return false;
        }
        return session_write_close();
    }
}
