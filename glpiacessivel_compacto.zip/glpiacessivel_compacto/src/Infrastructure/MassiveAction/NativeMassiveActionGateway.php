<?php

declare(strict_types=1);

namespace GlpiPlugin\Glpiacessivel\Infrastructure\MassiveAction;

/** Native stages only. Caller owns session/CSRF/context, single-use state and presentation. */
final class NativeMassiveActionGateway
{
    private NativeFormControls $forms;
    private \Closure $factory;

    public function __construct(?NativeFormControls $forms = null, ?callable $factory = null)
    {
        $this->forms = $forms ?? new NativeFormControls();
        $this->factory = $factory === null
            ? static fn(array $post, array $get, string $stage): object => new \MassiveAction($post, $get, $stage)
            : \Closure::fromCallable($factory);
    }

    /** @param int[] $ids @return array{input:array<string,mixed>,actions:array<string,string>} */
    public function prepare(array $ids): array
    {
        $items = [];
        foreach ($ids as $id) {
            if (!is_int($id) || $id < 1) {
                throw new \InvalidArgumentException('massive_selection_invalid');
            }
            $items[$id] = 1;
        }
        if ($items === [] || count($items) > 1000) {
            throw new \InvalidArgumentException('massive_selection_invalid');
        }
        $native = ($this->factory)(['item' => ['Ticket' => $items]], [], 'initial');
        $input = $native->getInput();
        $actions = [];
        foreach (['MassiveAction:update', 'Ticket:add_actor'] as $key) {
            if (isset($input['actions'][$key])) {
                $actions[$key] = html_entity_decode(strip_tags((string) $input['actions'][$key]), ENT_QUOTES | ENT_HTML5, 'UTF-8');
            }
        }

        return ['input' => $input, 'actions' => $actions];
    }

    /** @param array<string,mixed> $initial @return array<string,mixed> */
    public function specialize(array $initial, string $action): array
    {
        if (!in_array($action, ['MassiveAction:update', 'Ticket:add_actor'], true) || !isset($initial['actions'][$action])) {
            throw new \InvalidArgumentException('native_massive_action_not_offered');
        }
        $initial['action'] = $action;

        return ($this->factory)($initial, [], 'specialize')->getInput();
    }

    /**
     * Must be called on an isolated rendering request. GLPI10 can exit here.
     * Completion receives only native controls/hidden and the server-owned input.
     * @param array<string,mixed> $input
     * @param callable(array<string,mixed>):void $completion
     */
    public function renderWithCompletion(array $input, callable $completion): void
    {
        $native = ($this->factory)($input, [], 'specialize');
        $input = $native->getInput();
        $level = ob_get_level();
        $finished = false;
        ob_start();
        $finish = function () use (&$finished, $level, $input, $completion): void {
            if ($finished) {
                return;
            }
            $finished = true;
            $html = '';
            while (ob_get_level() > $level) {
                $html = (string) ob_get_clean() . $html;
            }
            try {
                $form = $this->forms->parse($html);
                if ($form['controls'] === []) {
                    throw new \RuntimeException('native_form_empty');
                }
                $payload = $form + ['input' => $input];
                if (($input['processor'] ?? '') === 'MassiveAction' && ($input['action'] ?? '') === 'update' && !isset($input['id_field'])) {
                    $payload['common_options'] = $this->forms->ajaxScalar($html, 'common_options');
                }
            } catch (\Throwable) {
                $payload = ['error' => 'native_form_unavailable', 'input' => $input, 'controls' => [], 'hidden' => []];
            }
            $completion($payload);
        };
        register_shutdown_function($finish);
        try {
            $native->showSubForm();
        } catch (\Throwable) {
            // The completion reports an unavailable form, never exception details.
            while (ob_get_level() > $level) {
                ob_end_clean();
            }
            ob_start();
        }
        $finish();
    }

    /** @param array<string,mixed> $form @return array{value:string,label:string} */
    public function statusField(array $form): array
    {
        $control = $this->forms->control($form, 'id_field');
        $nativeOptions = \Search::getCleanedOptions('Ticket', UPDATE);
        foreach ($control['options'] as $option) {
            if (!empty($option['disabled']) || preg_match('/\ATicket:([0-9]+)\z/D', $option['value'], $matches) !== 1) {
                continue;
            }
            $descriptor = $nativeOptions[(int) $matches[1]] ?? [];
            if (($descriptor['table'] ?? '') === 'glpi_tickets' && ($descriptor['field'] ?? '') === 'status') {
                return ['value' => $option['value'], 'label' => $option['label']];
            }
        }
        throw new \RuntimeException('native_status_field_not_offered');
    }

    /** @param array<string,mixed> $form @return array<string,mixed> */
    public function statusInput(array $form): array
    {
        $field = $this->statusField($form);
        if (($form['common_options'] ?? null) !== false) {
            throw new \RuntimeException('native_common_field_contract_unavailable');
        }
        $input = $form['input'];
        $input['id_field'] = $field['value'];
        // Native jQuery POST serialization turns its emitted false into this string.
        $input['common_options'] = 'false';

        return $input;
    }

    /** Caller supplies only server-owned hidden fields + validated offered controls. */
    public function process(array $submission): array
    {
        $this->assertAction($submission);
        $native = ($this->factory)($submission, [], 'process');

        $counters = $native->process();
        return ['counters' => $counters, 'input' => $native->getInput(), 'remaining' => $native->getRemainings()];
    }

    /** Completion also runs if native batching exits through Html::redirect(). */
    public function processWithCompletion(array $submission, callable $completion): void
    {
        $this->assertAction($submission);
        $native = ($this->factory)($submission, [], 'process');
        $this->runProcess($native, $completion);
    }

    public function resumeWithCompletion(int $identifier, array $expectedIds, string $processor, string $action, callable $completion): void
    {
        $this->validateContinuation($identifier, $expectedIds, $processor, $action);
        $native = ($this->factory)([], ['identifier' => $identifier], 'process');
        $this->runProcess($native, $completion);
    }

    private function runProcess(object $native, callable $completion): void
    {
        $level = ob_get_level();
        $finished = false;
        $counters = null;
        $nativeRedirect = null;
        $messagesBefore = $this->messages();
        ob_start();
        $finish = function () use (&$finished, &$counters, &$nativeRedirect, $messagesBefore, $native, $completion, $level): void {
            if ($finished) {
                return;
            }
            $finished = true;
            $output = '';
            while (ob_get_level() > $level) {
                $output = (string) ob_get_clean() . $output;
            }
            $identifier = null;
            if ($counters === null) {
                // GLPI11 transports native redirect through its own exception.
                // The version-guarded public response is a transport detail only.
                if (is_string($nativeRedirect) && preg_match('/\?identifier=([0-9]+)\z/D', $nativeRedirect, $match) === 1) {
                    $identifier = (int) $match[1];
                }
                // Only the actual native redirect conveys its identifier. No private access.
                foreach (headers_list() as $header) {
                    if (preg_match('/\ALocation: .*\?identifier=([0-9]+)\z/iD', $header, $match) === 1) {
                        $identifier = (int) $match[1];
                    }
                }
                if ($identifier === null && preg_match('/window\.location\s*=\s*[\x27\x22][^\x27\x22<>]*\?identifier=([0-9]+)[\x27\x22]/', $output, $match) === 1) {
                    $identifier = (int) $match[1];
                }
            }
            header_remove('Location');
            http_response_code(200);
            $completion([
                'counters' => $counters,
                'input' => $native->getInput(),
                'remaining' => $native->getRemainings(),
                'identifier' => $identifier,
                'uncertain' => $counters === null && $identifier === null,
                'messages' => $this->newMessages($messagesBefore),
            ]);
            // Native destructor persists its continuation at request teardown.
            // The callback must leave the session open until native teardown.
        };
        register_shutdown_function($finish);
        try {
            $counters = $native->process();
        } catch (\Throwable $error) {
            if (is_a($error, 'Glpi\\Exception\\RedirectException') && method_exists($error, 'getResponse')) {
                $response = $error->getResponse();
                if (is_object($response) && method_exists($response, 'getTargetUrl')) {
                    $nativeRedirect = $response->getTargetUrl();
                }
            }
            // A mutation could already have occurred: never imply failure is safe to replay.
        }
        $finish();
    }

    /** Only new native messages, projected as bounded plain text; no session dump. */
    private function newMessages(array $before): array
    {
        $counts = array_count_values($before);
        $new = [];
        foreach ($this->messages() as $message) {
            if (($counts[$message] ?? 0) > 0) {
                $counts[$message]--;
            } elseif (count($new) < 20) {
                $new[] = $message;
            }
        }
        return $new;
    }

    private function messages(): array
    {
        $messages = [];
        $visited = 0;
        $walk = static function (mixed $value, int $depth = 0) use (&$walk, &$messages, &$visited): void {
            if ($depth > 5 || ++$visited > 200) {
                return;
            }
            if (is_array($value)) {
                foreach ($value as $child) {
                    $walk($child, $depth + 1);
                }
            } elseif (is_string($value)) {
                $text = trim(preg_replace('/\s+/u', ' ', strip_tags(html_entity_decode(
                    mb_substr($value, 0, 4000, 'UTF-8'),
                    ENT_QUOTES | ENT_HTML5,
                    'UTF-8'
                ))) ?? '');
                if ($text !== '') {
                    $messages[] = mb_substr($text, 0, 2000, 'UTF-8');
                }
            }
        };
        $walk($_SESSION['MESSAGE_AFTER_REDIRECT'] ?? []);
        return $messages;
    }

    /** Resume the native continuation, never replay the initial POST. */
    public function resume(int $identifier, array $expectedIds, string $processor, string $action): array
    {
        $this->validateContinuation($identifier, $expectedIds, $processor, $action);
        $native = ($this->factory)([], ['identifier' => $identifier], 'process');
        $counters = $native->process();
        return ['counters' => $counters, 'input' => $native->getInput(), 'remaining' => $native->getRemainings()];
    }

    private function validateContinuation(int $identifier, array $expectedIds, string $processor, string $action): void
    {
        if ($identifier < 1 || !isset($_SESSION['current_massive_action'][$identifier])) {
            throw new \RuntimeException('native_massive_continuation_unavailable');
        }
        $saved = $_SESSION['current_massive_action'][$identifier];
        $actual = array_map('intval', array_values($saved['items']['Ticket'] ?? []));
        $expected = array_map('intval', $expectedIds);
        sort($actual);
        sort($expected);
        if (($saved['identifier'] ?? null) !== $identifier || ($saved['processor'] ?? '') !== $processor || ($saved['action'] ?? '') !== $action || $actual !== $expected || array_keys($saved['items'] ?? []) !== ['Ticket']) {
            throw new \RuntimeException('native_massive_continuation_mismatch');
        }
    }

    /** Native next-stage actor-type form, using the actual Ticket public renderer. */
    public function renderActorType(array $input, string $actorType, callable $completion): void
    {
        $native = ($this->factory)($input, [], 'specialize');
        $input = $native->getInput();
        if (($input['processor'] ?? '') !== 'Ticket' || ($input['action'] ?? '') !== 'add_actor') {
            throw new \InvalidArgumentException('native_actor_action_invalid');
        }
        // Re-read the offered roles rather than accepting numeric role constants from a client.
        ob_start();
        try {
            $native->showSubForm();
            $roleForm = $this->forms->parse((string) ob_get_contents());
        } finally {
            ob_end_clean();
        }
        $this->assertOffered($roleForm, 'actortype', $actorType);
        if ((int) $actorType < 1) {
            throw new \InvalidArgumentException('native_actor_role_invalid');
        }
        $input['actortype'] = $actorType;
        ob_start();
        try {
            (new \Ticket())->showActorAddForm((int) $actorType, mt_rand(), $_SESSION['glpiactive_entity'], [], true, true, false);
            $html = (string) ob_get_contents();
        } finally {
            ob_end_clean();
        }
        $form = $this->forms->parse($html) + ['input' => $input];
        $form['ajax'] = [];
        foreach (['actortype', 'itemtype', 'allow_email', 'entity_restrict', 'use_notif'] as $name) {
            $form['ajax'][$name] = $this->forms->ajaxScalar($html, $name);
        }
        $completion($form);
    }

    /** Render the actual core AJAX actor parameters, in an isolated authenticated request. */
    public function renderActorSelection(array $form, string $type, callable $completion): void
    {
        global $CFG_GLPI, $DB, $PLUGINS_INCLUDED, $PLUGINS_EXCLUDED;
        $role = (string) ($form['ajax']['actortype'] ?? '');
        $this->assertOffered($form, '_itil_' . $role . '[_type]', $type);
        $input = $form['input'];
        $input['_itil_' . $role]['_type'] = $type;
        $post = $_POST;
        $cwd = getcwd();
        $directory = GLPI_ROOT . '/ajax';
        $_POST = $form['ajax'] + ['type' => $type];
        // GLPI10's AJAX view re-enters includes.php and its native one-use CSRF
        // check. The external plugin request was already checked by its controller;
        // do not replay that consumed token for this internal read-only subform.
        $_POST['_glpi_csrf_token'] = \Session::getNewCSRFToken();
        $level = ob_get_level();
        $finished = false;
        ob_start();
        $finish = function () use (&$finished, $level, $post, $cwd, $input, $type, $completion): void {
            if ($finished) {
                return;
            }
            $finished = true;
            $html = '';
            while (ob_get_level() > $level) {
                $html = (string) ob_get_clean() . $html;
            }
            $_POST = $post;
            if ($cwd !== false) {
                chdir($cwd);
            }
            try {
                $projected = $this->forms->parse($html) + ['input' => $input];
                $params = $this->forms->dropdownParameters($html);
                $fields = array_values(array_filter($projected['controls'], static fn(array $control): bool => str_ends_with($control['name'], '_id]')));
                if (count($fields) !== 1 || !isset($params['_idor_token'])) {
                    throw new \RuntimeException('native_actor_selector_unavailable');
                }
                $projected['lookup'] = ['native' => $params, 'kind' => $type, 'field' => $fields[0]['name']];
            } catch (\Throwable) {
                $projected = ['error' => 'native_form_unavailable', 'input' => $input, 'controls' => [], 'hidden' => []];
            }
            $completion($projected);
        };
        register_shutdown_function($finish);
        try {
            chdir($directory);
            include $directory . '/dropdownItilActors.php';
        } catch (\Throwable) {
            while (ob_get_level() > $level) {
                ob_end_clean();
            }
            ob_start();
        }
        $finish();
    }

    /** Query using precisely the rights, entities, condition and IDOR emitted by the native form. */
    public function search(array $lookup, string $query = '', int $page = 1): array
    {
        if ($page < 1 || $page > 100 || mb_strlen($query) > 120 || preg_match('/[\x00-\x1f\x7f]/', $query)) {
            throw new \InvalidArgumentException('native_actor_search_invalid');
        }
        $params = $lookup['native'] ?? [];
        unset($params['_one_id'], $params['value'], $params['values']);
        $params['searchText'] = $query;
        $params['page'] = $page;
        $params['page_limit'] = 25;
        $native = ($lookup['kind'] ?? '') === 'user'
            ? \Dropdown::getDropdownUsers($params, false)
            : \Dropdown::getDropdownValue($params, false);
        $results = [];
        $flatten = function (array $rows) use (&$flatten, &$results): void {
            foreach ($rows as $row) {
                if (isset($row['children']) && is_array($row['children'])) {
                    $flatten($row['children']);
                } elseif (isset($row['id'], $row['text']) && (int) $row['id'] > 0) {
                    $results[] = ['id' => (int) $row['id'], 'label' => html_entity_decode(strip_tags((string) $row['text']), ENT_QUOTES | ENT_HTML5, 'UTF-8')];
                }
            }
        };
        $flatten((array) ($native['results'] ?? []));
        return ['results' => $results, 'more' => (int) ($native['count'] ?? 0) >= 25];
    }

    /** Exact ID hydration is NOT authorization. Re-query the native offered search page. */
    public function actorChoiceAllowed(array $lookup, string $query, int $page, int $id): bool
    {
        return in_array($id, array_column($this->search($lookup, $query, $page)['results'], 'id'), true);
    }

    private function assertOffered(array $form, string $name, string $value): void
    {
        $control = $this->forms->control($form, $name);
        foreach ($control['options'] as $option) {
            if ($option['value'] === $value && !$option['disabled'] && !$control['disabled']) {
                return;
            }
        }
        throw new \InvalidArgumentException('native_form_value_not_offered');
    }

    private function assertAction(array $submission): void
    {
        $key = ($submission['processor'] ?? '') . ':' . ($submission['action'] ?? '');
        if (!in_array($key, ['MassiveAction:update', 'Ticket:add_actor'], true)) {
            throw new \InvalidArgumentException('native_massive_action_not_offered');
        }
        if ($key === 'MassiveAction:update' && ($submission['field'] ?? '') !== 'status') {
            throw new \InvalidArgumentException('native_massive_field_not_supported');
        }
        if (array_keys($submission['items'] ?? []) !== ['Ticket']) {
            throw new \InvalidArgumentException('native_massive_itemtype_invalid');
        }
    }
}
