<?php

declare(strict_types=1);

namespace GlpiPlugin\Glpiacessivel\Infrastructure\MassiveAction;

/** Text-only projection of controls emitted by GLPI. No native scripts execute. */
final class NativeFormControls
{
    /** @return array{controls:array<int,array<string,mixed>>,hidden:array<string,mixed>} */
    public function parse(string $html): array
    {
        if (strlen($html) > 2097152) {
            throw new \RuntimeException('native_form_too_large');
        }
        $document = new \DOMDocument();
        $previous = libxml_use_internal_errors(true);
        try {
            $document->loadHTML('<?xml encoding="UTF-8"><div>' . $html . '</div>', LIBXML_NONET | LIBXML_NOERROR | LIBXML_NOWARNING);
        } finally {
            libxml_clear_errors();
            libxml_use_internal_errors($previous);
        }
        $xpath = new \DOMXPath($document);
        $controls = [];
        $hidden = [];
        $hiddenNames = [];
        foreach ($xpath->query('//input[@name] | //select[@name] | //textarea[@name]') as $element) {
            if (!$element instanceof \DOMElement) {
                continue;
            }
            $name = $element->getAttribute('name');
            if (preg_match('/\A[a-zA-Z_][a-zA-Z0-9_]*(?:\[[a-zA-Z0-9_]*\])*\z/D', $name) !== 1) {
                throw new \RuntimeException('native_form_invalid_name');
            }
            $type = strtolower($element->tagName === 'input' ? $element->getAttribute('type') : $element->tagName);
            $type = $type === '' ? 'text' : $type;
            if ($type === 'hidden') {
                if (isset($hiddenNames[$name]) || count($hiddenNames) >= 4000) {
                    throw new \RuntimeException('native_form_hidden_ambiguous_or_truncated');
                }
                $hiddenNames[$name] = true;
                // Do not use parse_str: native forms may exceed max_input_vars at
                // 1000 selected items. Exact named hidden fields are already parsed.
                preg_match_all('/\A([a-zA-Z_][a-zA-Z0-9_]*)|\[([a-zA-Z0-9_]*)\]/', $name, $parts, PREG_SET_ORDER);
                $target = &$hidden;
                foreach ($parts as $index => $part) {
                    $key = $index === 0 ? $part[1] : $part[2];
                    if ($key === '') {
                        throw new \RuntimeException('native_form_hidden_ambiguous');
                    }
                    if ($index === count($parts) - 1) {
                        if (array_key_exists($key, $target)) {
                            throw new \RuntimeException('native_form_hidden_ambiguous');
                        }
                        $target[$key] = $element->getAttribute('value');
                    } else {
                        if (isset($target[$key]) && !is_array($target[$key])) {
                            throw new \RuntimeException('native_form_hidden_ambiguous');
                        }
                        $target[$key] ??= [];
                        $target = &$target[$key];
                    }
                }
                unset($target);
                continue;
            }
            if (in_array($type, ['submit', 'button', 'reset', 'image'], true)) {
                continue;
            }
            if (!in_array($type, ['select', 'text', 'email', 'number', 'checkbox', 'radio', 'textarea'], true)) {
                throw new \RuntimeException('native_form_unsupported_control');
            }
            $control = [
                'name' => $name, 'type' => $type,
                'value' => $type === 'textarea' ? $element->textContent : $element->getAttribute('value'),
                'required' => $element->hasAttribute('required'),
                'disabled' => $element->hasAttribute('disabled'),
                'multiple' => $element->hasAttribute('multiple'),
                'checked' => $element->hasAttribute('checked'),
                'options' => [],
            ];
            foreach ($element->getElementsByTagName('option') as $option) {
                $control['options'][] = [
                    'value' => $option->hasAttribute('value') ? $option->getAttribute('value') : $option->textContent,
                    'label' => trim(preg_replace('/\s+/u', ' ', $option->textContent) ?? ''),
                    'disabled' => $option->hasAttribute('disabled')
                        || ($option->parentNode instanceof \DOMElement && $option->parentNode->hasAttribute('disabled')),
                    'selected' => $option->hasAttribute('selected'),
                ];
            }
            $controls[] = $control;
        }
        return ['controls' => $controls, 'hidden' => $hidden];
    }

    /** Decode the literal parameters produced by Html::jsAjaxDropdown; never JavaScript. */
    public function dropdownParameters(string $html): array
    {
        if (preg_match('/(?:var\s+params_[^\s=]+\s*=\s*|params\s*:\s*)(\{)/', $html, $match, PREG_OFFSET_CAPTURE) !== 1) {
            throw new \RuntimeException('native_dropdown_parameters_missing');
        }
        $offset = $match[1][1] + 1;
        $result = [];
        $length = strlen($html);
        while ($offset < $length) {
            while ($offset < $length && (ctype_space($html[$offset]) || $html[$offset] === ',')) {
                $offset++;
            }
            if (($html[$offset] ?? '') === '}') {
                return $result;
            }
            if (preg_match('/\G(?:"((?:\\\\.|[^"\\\\])*)"|([a-zA-Z_][a-zA-Z0-9_]*))\s*:\s*/', $html, $key, 0, $offset) !== 1) {
                throw new \RuntimeException('native_dropdown_parameters_invalid');
            }
            $name = ($key[2] ?? '') !== '' ? $key[2] : json_decode('"' . $key[1] . '"', true, 8, JSON_THROW_ON_ERROR);
            $offset += strlen($key[0]);
            $start = $offset;
            $depth = 0;
            $quoted = false;
            $escaped = false;
            for (; $offset < $length; $offset++) {
                $char = $html[$offset];
                if ($quoted) {
                    if ($escaped) {
                        $escaped = false;
                    } elseif ($char === '\\') {
                        $escaped = true;
                    } elseif ($char === '"') {
                        $quoted = false;
                    }
                    continue;
                }
                if ($char === '"') {
                    $quoted = true;
                } elseif ($char === '[' || $char === '{') {
                    $depth++;
                } elseif (($char === '}' && $depth === 0) || ($char === ',' && $depth === 0)) {
                    break;
                } elseif ($char === ']' || $char === '}') {
                    $depth--;
                }
            }
            if (isset($result[$name])) {
                throw new \RuntimeException('native_dropdown_parameters_ambiguous');
            }
            $result[$name] = json_decode(trim(substr($html, $start, $offset - $start)), true, 32, JSON_THROW_ON_ERROR);
        }
        throw new \RuntimeException('native_dropdown_parameters_invalid');
    }

    /** Extract only a JSON scalar emitted by Ajax::updateItemJsCode. Never eval JS. */
    public function ajaxScalar(string $html, string $name): mixed
    {
        if (preg_match('/\A[a-zA-Z_][a-zA-Z0-9_]*\z/D', $name) !== 1) {
            throw new \InvalidArgumentException('native_ajax_parameter_invalid');
        }
        $pattern = '/[,{]\s*' . preg_quote($name, '/') . '\s*:\s*("(?:\\\\.|[^"\\\\])*"|false|true|null|-?[0-9]+)(?=\s*[,}])/';
        if (preg_match($pattern, $html, $matches) !== 1) {
            throw new \RuntimeException('native_ajax_parameter_missing');
        }

        return json_decode($matches[1], true, 8, JSON_THROW_ON_ERROR);
    }

    /** @param array<string,mixed> $form @return array<string,mixed> */
    public function control(array $form, string $name): array
    {
        $matches = array_values(array_filter($form['controls'] ?? [], static fn(array $control): bool => $control['name'] === $name));
        if (count($matches) !== 1) {
            throw new \RuntimeException('native_form_control_missing_or_ambiguous');
        }

        return $matches[0];
    }
}
