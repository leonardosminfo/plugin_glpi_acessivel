<?php

declare(strict_types=1);

namespace GlpiPlugin\Glpiacessivel\Infrastructure\Ticket;

/** Authorizes the native editor fragment inside the plugin-owned creation form. */
final class NativeInteractionCreator
{
    private \Closure $factory;
    private \Closure $interface;

    public function __construct(?callable $factory = null, ?callable $interface = null)
    {
        $this->factory = $factory === null
            ? static fn(string $kind): object => match ($kind) {
                'ticket' => new \Ticket(),
                'followup' => new \ITILFollowup(),
                'task' => new \TicketTask(),
                default => throw new \InvalidArgumentException('interaction_create_request_invalid'),
            }
            : \Closure::fromCallable($factory);
        $this->interface = $interface === null
            ? static fn(): string => (string) \Session::getCurrentInterface()
            : \Closure::fromCallable($interface);
    }

    /** CREATE is independent of UPDATE and of either editing exposure flag. */
    public function canCreate(int $ticketId, string $kind): bool
    {
        try {
            $this->authorized($ticketId, $kind);
            return true;
        } catch (\Throwable) {
            return false;
        }
    }

    /** @return array{ticket_id:int,kind:string,native_ticket_url:string} */
    public function context(int $ticketId, string $kind): array
    {
        [$ticket, $item] = $this->authorized($ticketId, $kind);
        return [
            'ticket_id' => $ticketId,
            'kind' => $kind,
            'can_change_privacy' => ($this->interface)() === 'central',
            'default_is_private' => !empty($item->fields['is_private']) ? 1 : 0,
            'native_ticket_url' => is_callable([$ticket, 'getFormURLWithID'])
                ? (string) $ticket->getFormURLWithID($ticketId) : '',
        ];
    }

    /** Caller must freshly authorize tickets.interaction_rich_add before exposure. */
    public function nativeForm(int $ticketId, string $kind, ?string $editorId = null): ?string
    {
        $this->authorized($ticketId, $kind);
        $html = (new \GlpiPlugin\Glpiacessivel\UI\View\RichInteractionFields())
            ->render('', $editorId ?? $kind, true, true);
        return $html !== '' ? $html : null;
    }

    /** @return array{object,object} */
    private function authorized(int $ticketId, string $kind): array
    {
        if ($ticketId < 1 || !in_array($kind, ['followup', 'task'], true)) {
            throw new \InvalidArgumentException('interaction_create_request_invalid');
        }
        if ($kind === 'task' && ($this->interface)() !== 'central') {
            throw new \DomainException('interaction_create_not_available');
        }
        $ticket = ($this->factory)('ticket');
        if (!$ticket->getFromDB($ticketId) || !$ticket->can($ticketId, READ)) {
            throw new \DomainException('interaction_create_not_available');
        }
        if (!is_callable([$ticket, 'getTimelineItemtypes'])) {
            throw new \DomainException('interaction_create_not_available');
        }
        // The core owns status/parent/hook-dependent menu visibility and prepares
        // the new subitem, including task defaults. Do not recreate these rules.
        $menu = $ticket->getTimelineItemtypes();
        $entry = is_array($menu) ? ($menu[$kind === 'followup' ? 'answer' : 'task'] ?? null) : null;
        $expectedClass = $kind === 'followup' ? 'ITILFollowup' : 'TicketTask';
        $expectedType = $kind === 'followup' ? 'ITILFollowup' : 'ITILTask';
        if (
            !is_array($entry) || ($entry['hide_in_menu'] ?? null) !== false
            || ($entry['class'] ?? null) !== $expectedClass || ($entry['type'] ?? null) !== $expectedType
            || !is_object($entry['item'] ?? null)
        ) {
            throw new \DomainException('interaction_create_not_available');
        }
        $item = $entry['item'];
        $parent = $kind === 'followup'
            ? ['itemtype' => 'Ticket', 'items_id' => $ticketId]
            : ['tickets_id' => $ticketId];
        $input = $parent;
        // The native can() prepares parent fields and preserves native defaults.
        // Do not require parent UPDATE or an existing interaction to create one.
        if (!$item->can(-1, CREATE, $input)) {
            throw new \DomainException('interaction_create_not_available');
        }
        foreach ($parent as $key => $value) {
            if ((string) ($item->fields[$key] ?? '') !== (string) $value) {
                throw new \DomainException('interaction_create_not_available');
            }
        }
        return [$ticket, $item];
    }
}
