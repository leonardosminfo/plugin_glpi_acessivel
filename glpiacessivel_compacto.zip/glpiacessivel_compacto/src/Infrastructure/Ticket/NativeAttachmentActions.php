<?php

declare(strict_types=1);

namespace GlpiPlugin\Glpiacessivel\Infrastructure\Ticket;

/** Read-only presentation adapter. Forms and mutations remain owned by GLPI. */
final class NativeAttachmentActions
{
    private \Closure $factory;
    private \Closure $renderer;
    private \Closure $version;

    public function __construct(?callable $factory = null, ?callable $renderer = null, ?callable $version = null)
    {
        $this->factory = $factory === null ? static fn(string $kind): object => match ($kind) {
            'ticket' => new \Ticket(),
            'followup' => new \ITILFollowup(),
            'task' => new \TicketTask(),
            'document' => new \Document(),
            default => throw new \InvalidArgumentException('native_attachment_kind_invalid'),
        } : \Closure::fromCallable($factory);
        $this->renderer = $renderer === null ? static function (array $data): string {
            if (!class_exists('Glpi\\Application\\View\\TemplateRenderer')) {
                throw new \RuntimeException('native_attachment_renderer_unavailable');
            }
            return \Glpi\Application\View\TemplateRenderer::getInstance()->render(
                'components/itilobject/timeline/sub_documents.html.twig',
                $data
            );
        } : \Closure::fromCallable($renderer);
        $this->version = $version === null
            ? static fn(): string => defined('GLPI_VERSION') ? (string) GLPI_VERSION : ''
            : \Closure::fromCallable($version);
    }

    /**
     * $documents is the server-owned, READ-authorized document projection.
     * It is intersected with the exact native event, never a document-ID search
     * across other interactions. NO_TIMELINE documents keep their existing
     * read/download presentation; this adapter does not manufacture controls.
     *
     * @param array<array<string,mixed>> $documents
     * @return array{available:bool,documents:array<int,array{id:int,actions_html:string,has_actions:bool,effects_text:string}>,reason:string}
     */
    public function presentation(int $ticketId, string $kind, int $id, array $documents): array
    {
        $unavailable = ['available' => false, 'documents' => [], 'reason' => 'native_attachment_actions_unavailable'];
        try {
            $version = ($this->version)();
            if (
                $ticketId < 1 || $id < 1 || !in_array($kind, ['followup', 'task'], true)
                || $documents === [] || count($documents) > 200
                || version_compare($version, '10.0.0', '<') || version_compare($version, '12.0.0', '>=')
                || !class_exists(\DOMDocument::class)
            ) {
                return $unavailable;
            }
            $parentType = $kind === 'followup' ? 'ITILFollowup' : 'TicketTask';
            $ticket = ($this->factory)('ticket');
            $interaction = ($this->factory)($kind);
            if (
                !$ticket->getFromDB($ticketId) || !$ticket->can($ticketId, READ)
                || !$interaction->getFromDB($id) || !$interaction->can($id, READ)
                || ($kind === 'followup' && (($interaction->fields['itemtype'] ?? '') !== 'Ticket'
                    || (int) ($interaction->fields['items_id'] ?? 0) !== $ticketId))
                || ($kind === 'task' && (int) ($interaction->fields['tickets_id'] ?? 0) !== $ticketId)
            ) {
                return $unavailable;
            }

            // One public native timeline read; no replacement ACL or queries.
            $timeline = $ticket->getTimelineItems([
                'with_documents' => true,
                'with_logs' => false,
                'with_validations' => false,
                'check_view_rights' => true,
            ]);
            // Both installed cores sort with usort() before returning, so the
            // public result has numeric keys, not its intermediate event keys.
            $event = null;
            foreach ($timeline as $candidate) {
                if (
                    is_array($candidate) && ($candidate['type'] ?? '') === $parentType
                    && (int) ($candidate['item']['id'] ?? 0) === $id
                ) {
                    if ($event !== null) {
                        return $unavailable;
                    }
                    $event = $candidate;
                }
            }
            if (
                !is_array($event) || ($event['type'] ?? '') !== $parentType
                || (int) ($event['item']['id'] ?? 0) !== $id || !is_array($event['documents'] ?? null)
            ) {
                return $unavailable;
            }
            $nativeDocuments = [];
            foreach ($event['documents'] as $native) {
                if (
                    is_array($native) && ($native['type'] ?? '') === 'Document_Item'
                    && is_array($native['item'] ?? null) && (int) ($native['item']['id'] ?? 0) > 0
                ) {
                    $nativeDocuments[(int) $native['item']['id']] = $native;
                }
            }

            $result = [];
            foreach ($documents as $allowed) {
                if (!is_array($allowed)) {
                    continue;
                }
                $docId = (int) ($allowed['id'] ?? 0);
                if (
                    $docId < 1 || isset($result[$docId]) || !isset($nativeDocuments[$docId])
                    || ($allowed['parent_itemtype'] ?? '') !== $parentType
                    || (int) ($allowed['parent_id'] ?? 0) !== $id
                ) {
                    continue;
                }
                $document = ($this->factory)('document');
                if (
                    !$document->getFromDB($docId)
                    || !$document->canViewFile(['itemtype' => $parentType, 'items_id' => $id])
                ) {
                    continue;
                }
                $native = $nativeDocuments[$docId];
                // These values are consumed only by the installed native Twig.
                // Never derive flags from profile masks or client projections.
                $html = ($this->renderer)(['item' => $ticket, 'entry' => ['documents' => [$native]]]);
                $name = (string) ($allowed['display_name'] ?? $allowed['filename'] ?? __('Documento', 'glpiacessivel'));
                $actions = $this->extractActions($html, $ticketId, $docId, $name);
                if ($actions !== null) {
                    $result[$docId] = ['id' => $docId] + $actions;
                }
            }
            return ['available' => true, 'documents' => $result, 'reason' => ''];
        } catch (\Throwable) {
            // No partial controls or native exception/content disclosure.
            return $unavailable;
        }
    }

    /** @return array{actions_html:string,has_actions:bool,effects_text:string}|null */
    private function extractActions(string $html, int $ticketId, int $docId, string $name): ?array
    {
        if (strlen($html) > 131072) {
            return null;
        }
        $previous = libxml_use_internal_errors(true);
        try {
            $dom = new \DOMDocument('1.0', 'UTF-8');
            if (!$dom->loadHTML('<?xml encoding="UTF-8">' . $html, LIBXML_NONET | LIBXML_NOERROR | LIBXML_NOWARNING)) {
                return null;
            }
            $xpath = new \DOMXPath($dom);
            $groups = $xpath->query('//*[contains(concat(" ", normalize-space(@class), " "), " list-group-item-actions ")]');
            if ($groups === false || $groups->length !== 1 || !$groups->item(0) instanceof \DOMElement) {
                return null;
            }
            $group = $groups->item(0);
            $effects = [];
            $controls = $xpath->query('.//a | .//button', $group);
            if ($controls === false || $controls->length > 3) {
                return null;
            }
            $formsChecked = 0;
            $inputsChecked = 0;
            $linksChecked = 0;
            foreach ($group->getElementsByTagName('*') as $node) {
                if (in_array(strtolower($node->tagName), ['script', 'iframe', 'object', 'embed'], true)) {
                    return null;
                }
                foreach ($node->attributes as $attribute) {
                    if (
                        str_starts_with(strtolower($attribute->name), 'on')
                        || in_array(strtolower($attribute->name), ['formaction', 'formmethod', 'form'], true)
                    ) {
                        return null;
                    }
                }
            }
            foreach ($controls as $control) {
                if (!$control instanceof \DOMElement || trim($control->getAttribute('title')) === '') {
                    return null;
                }
                if ($control->tagName === 'a') {
                    if (++$linksChecked > 1) {
                        return null;
                    }
                    $url = parse_url($control->getAttribute('href'));
                    parse_str((string) ($url['query'] ?? ''), $query);
                    if (!$this->nativePath($url, '/front/document.form.php') || (string) ($query['id'] ?? '') !== (string) $docId) {
                        return null;
                    }
                } else {
                    ++$formsChecked;
                    $form = $control->parentNode;
                    if (
                        !$form instanceof \DOMElement || $form->tagName !== 'form'
                        || strtolower($form->getAttribute('method')) !== 'post'
                        || $control->getAttribute('type') !== 'submit'
                    ) {
                        return null;
                    }
                    $fields = [];
                    foreach ($form->getElementsByTagName('input') as $input) {
                        ++$inputsChecked;
                        $field = $input->getAttribute('name');
                        if ($field === '' || isset($fields[$field]) || strtolower($input->getAttribute('type')) !== 'hidden') {
                            return null;
                        }
                        $fields[$field] = $input->getAttribute('value');
                    }
                    if (trim($fields['_glpi_csrf_token'] ?? '') === '') {
                        return null;
                    }
                    $url = parse_url($form->getAttribute('action'));
                    if ($control->getAttribute('name') === 'delete_document') {
                        if (
                            !$this->nativePath($url, '/front/ticket.form.php')
                            || count($fields) !== 3 || ($fields['tickets_id'] ?? '') !== (string) $ticketId
                            || ($fields['documents_id'] ?? '') !== (string) $docId
                        ) {
                            return null;
                        }
                        $effects[] = __('A exclusão da timeline pode remover vínculos deste documento no chamado e em suas interações, limpar imagens da descrição e gerar histórico ou notificações. Esse controle não é a purga global do documento.', 'glpiacessivel');
                    } elseif ($control->getAttribute('name') === 'update') {
                        if (
                            !$this->nativePath($url, '/front/document.form.php')
                            || count($fields) !== 3 || ($fields['id'] ?? '') !== (string) $docId
                            || !in_array($fields['is_blacklisted'] ?? '', ['0', '1'], true)
                        ) {
                            return null;
                        }
                        $effects[] = __('A lista de exclusão de importação é uma propriedade do documento compartilhada entre seus vínculos. Ela não remove o arquivo nem altera quem pode lê-lo.', 'glpiacessivel');
                    } else {
                        return null;
                    }
                }
                $label = trim($control->getAttribute('title'));
                $control->appendChild($dom->createTextNode(' ' . $label));
                $control->setAttribute('aria-label', $label . ' — ' . $name);
            }
            if (
                $group->getElementsByTagName('form')->length !== $formsChecked
                || $group->getElementsByTagName('input')->length !== $inputsChecked
            ) {
                return null;
            }
            $group->setAttribute('role', 'group');
            $group->setAttribute('aria-label', sprintf(__('Ações do documento: %s', 'glpiacessivel'), $name));
            return ['actions_html' => (string) $dom->saveHTML($group), 'has_actions' => $controls->length > 0,
                'effects_text' => implode(' ', array_unique($effects))];
        } finally {
            libxml_clear_errors();
            libxml_use_internal_errors($previous);
        }
    }

    /** @param array<string,mixed>|false $url */
    private function nativePath(array|false $url, string $suffix): bool
    {
        return is_array($url) && !isset($url['scheme']) && !isset($url['host'])
            && str_ends_with((string) ($url['path'] ?? ''), $suffix);
    }
}
