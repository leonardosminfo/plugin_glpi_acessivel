<?php

declare(strict_types=1);

namespace GlpiPlugin\Glpiacessivel\Infrastructure\Ticket;

/** Public GLPI object APIs only. No SQL, schema inspection or replacement ACL. */
final class NativeInteractionEditor
{
    public const MAX_TEXT_BYTES = 16000;
    public const MAX_RICH_BYTES = 1048576;

    private \Closure $factory;
    private \Closure $interface;
    private \Closure $events;

    public function __construct(
        ?callable $factory = null,
        ?callable $interface = null,
        ?callable $events = null
    ) {
        $this->factory = $factory === null
            ? static fn(string $kind): object => match ($kind) {
                'ticket' => new \Ticket(),
                'followup' => new \ITILFollowup(),
                'task' => new \TicketTask(),
                default => throw new \InvalidArgumentException('interaction_request_invalid'),
            }
            : \Closure::fromCallable($factory);
        $this->interface = $interface === null
            ? static fn(): string => (string) \Session::getCurrentInterface()
            : \Closure::fromCallable($interface);
        $this->events = $events === null
            ? static function (int $id, string $type, int $level, string $service, string $message): void {
                if (!class_exists('Glpi\\Event')) {
                    throw new \RuntimeException('interaction_native_event_unavailable');
                }
                \Glpi\Event::log($id, $type, $level, $service, $message);
            }
            : \Closure::fromCallable($events);
    }

    /** READ and UPDATE are independent, including when offering a link. */
    public function canEdit(int $ticketId, string $kind, int $id): bool
    {
        try {
            $this->authorized($ticketId, $kind, $id);
            return true;
        } catch (\Throwable) {
            return false;
        }
    }

    /** No form rendering or mutation while preparing timeline actions. */
    public function editingMode(int $ticketId, string $kind, int $id, bool $completeReleased): string
    {
        try {
            return \GlpiPlugin\Glpiacessivel\Application\InteractionEditPresentation::mode(
                $this->context($ticketId, $kind, $id),
                $completeReleased
            );
        } catch (\Throwable) {
            return 'unavailable';
        }
    }

    /** GLPI 10 sanitizes/DB-escapes POST before loading plugin front scripts. */
    public function postText(string $value): string
    {
        if (!$this->legacy()) {
            return $value;
        }
        if (!class_exists('Glpi\\Toolbox\\Sanitizer')) {
            throw new \RuntimeException('interaction_native_codec_unavailable');
        }
        return (string) \Glpi\Toolbox\Sanitizer::unsanitize($value);
    }

    /** @return array<string,mixed> */
    public function context(int $ticketId, string $kind, int $id): array
    {
        [$ticket, $item] = $this->authorized($ticketId, $kind, $id);
        return $this->view($ticketId, $kind, $id, $ticket, $item);
    }

    /**
     * HTML is data for the native textarea helper, never trusted page markup.
     * Keep this context in server-owned intent state, not hidden POST fields.
     * Feature release checks belong to the controller on BOTH GET and POST.
     * @return array<string,mixed>
     */
    public function richContext(int $ticketId, string $kind, int $id): array
    {
        [$ticket, $item] = $this->authorized($ticketId, $kind, $id);
        return $this->richView($ticketId, $kind, $id, $ticket, $item);
    }

    /**
     * Plugin-owned form, native persistence. Input content is already decoded
     * once by postText(); only native uploader metadata may accompany it.
     * Removing an inline image does NOT purge its linked native Document.
     * @param array<string,mixed> $input
     * @param array<string,mixed> $baseline server-owned richContext()
     * @return array{status:string}
     */
    public function updateRich(int $ticketId, string $kind, int $id, array $input, array $baseline): array
    {
        foreach (array_keys($input) as $key) {
            if (!in_array($key, ['content', 'is_private', '_filename', '_tag_filename', '_prefix_filename'], true)) {
                throw new \InvalidArgumentException('interaction_field_not_allowed');
            }
        }
        [$ticket, $item] = $this->authorized($ticketId, $kind, $id);
        $current = $this->richView($ticketId, $kind, $id, $ticket, $item);
        if (
            ($baseline['ticket_id'] ?? null) !== $ticketId
            || ($baseline['kind'] ?? null) !== $kind
            || ($baseline['interaction_id'] ?? null) !== $id
            || !is_string($baseline['rich_revision'] ?? null)
        ) {
            throw new \InvalidArgumentException('interaction_request_invalid');
        }
        if (!hash_equals($baseline['rich_revision'], $current['rich_revision'])) {
            throw new \DomainException('interaction_concurrent_change');
        }
        if (empty($baseline['can_edit_rich_content']) || empty($current['can_edit_rich_content'])) {
            throw new \DomainException('interaction_not_available');
        }

        $uploads = self::nativeUploads($input);
        $hasUploads = !empty($uploads['_filename']);
        $payload = ['id' => $id];
        if (array_key_exists('content', $input)) {
            if (!is_string($input['content']) || strlen($input['content']) > self::MAX_RICH_BYTES) {
                throw new \InvalidArgumentException('interaction_text_invalid');
            }
            $content = str_replace(["\r\n", "\r"], "\n", $input['content']);
            if ($content !== $baseline['content_html'] || $hasUploads) {
                $payload['content'] = $content;
            }
        } elseif ($hasUploads) {
            // Needed by addFiles() to resolve inline upload tags without losing
            // the existing HTML. This value is freshly authorized server state.
            $payload['content'] = $current['content_html'];
        }
        if (array_key_exists('is_private', $input)) {
            if (!in_array($input['is_private'], [0, 1, '0', '1'], true)) {
                throw new \InvalidArgumentException('interaction_visibility_invalid');
            }
            $privacy = (int) $input['is_private'];
            if ($privacy !== $baseline['is_private']) {
                if (empty($baseline['can_change_privacy']) || empty($current['can_change_privacy'])) {
                    throw new \InvalidArgumentException('interaction_visibility_not_available');
                }
                $payload['is_private'] = $privacy;
            }
        }
        if (count($payload) === 1 && !$hasUploads) {
            return ['status' => 'unchanged'];
        }
        $attachmentRepository = null;
        $expectedUploads = [];
        if ($hasUploads) {
            try {
                $attachmentRepository = new \GlpiPlugin\Glpiacessivel\Infrastructure\Repository\TicketRepository();
                $expectedUploads = $attachmentRepository->captureDocumentUploadExpectations(
                    $uploads + ['_native_editor_uploads' => true]
                );
            } catch (\Throwable) {
                // No mutation has occurred yet. Never trust client document IDs
                // or hashes as a replacement for server-captured file identity.
                throw new \InvalidArgumentException('interaction_upload_invalid');
            }
            $payload += $uploads;
        }
        $payload['update'] = 1;
        $payload += $kind === 'task'
            ? ['tickets_id' => $ticketId]
            : ['itemtype' => 'Ticket', 'items_id' => $ticketId];
        if ($this->legacy() && array_key_exists('content', $payload)) {
            $payload['content'] = \Glpi\Toolbox\Sanitizer::sanitize($payload['content']);
        }
        try {
            $accepted = (bool) $item->update($payload);
            ($this->events)(
                $ticketId,
                'ticket',
                4,
                'tracking',
                sprintf(
                    $kind === 'task' ? __('%s updates a task') : __('%s updates a followup'),
                    (string) ($_SESSION['glpiname'] ?? '')
                )
            );
        } catch (\Throwable) {
            return ['status' => 'uncertain'];
        }
        if (!$accepted) {
            return ['status' => 'rejected'];
        }
        try {
            [$afterTicket, $afterItem] = $this->authorized($ticketId, $kind, $id);
            $after = $this->richView($ticketId, $kind, $id, $afterTicket, $afterItem);
            if (isset($payload['is_private']) && $after['is_private'] !== $payload['is_private']) {
                return ['status' => 'uncertain'];
            }
            if (array_key_exists('content', $payload)) {
                // addFiles() rewrites temporary tags/URLs and may reuse an
                // existing Document. Compare with the model's final native
                // content, not with unprocessed HTML received from the form.
                $expected = is_array($item->input ?? null) && array_key_exists('content', $item->input)
                    ? $this->postText((string) $item->input['content'])
                    : $this->postText((string) $payload['content']);
                $expected = str_replace(["\r\n", "\r"], "\n", $expected);
                if ($after['content_html'] !== $expected) {
                    return ['status' => 'uncertain'];
                }
            }
            if ($hasUploads) {
                // Core deduplication may legitimately leave the temporary file
                // in place. The server-captured content hash linked to THIS
                // interaction proves success; temporary-file deletion does not.
                $diagnostic = $attachmentRepository->documentItemLinkDiagnostics(
                    $kind === 'task' ? 'TicketTask' : 'ITILFollowup',
                    $id,
                    count($expectedUploads),
                    [],
                    $expectedUploads
                );
                if (empty($diagnostic['available']) || empty($diagnostic['complete'])) {
                    return ['status' => 'uncertain'];
                }
            }
        } catch (\Throwable) {
            return ['status' => 'uncertain'];
        }
        return ['status' => 'saved'];
    }

    /** @return array<string,mixed> */
    private function richView(int $ticketId, string $kind, int $id, object $ticket, object $item): array
    {
        $view = $this->view($ticketId, $kind, $id, $ticket, $item);
        $html = (string) ($item->fields['content'] ?? '');
        if ($this->legacy()) {
            $html = (string) \Glpi\Toolbox\Sanitizer::unsanitize($html, false);
        }
        $view['content_html'] = str_replace(["\r\n", "\r"], "\n", $html);
        $view['can_edit_rich_content'] = strlen($html) <= self::MAX_RICH_BYTES;
        $view['rich_revision'] = hash('sha256', serialize([
            $ticketId, $kind, $id, $html, $view['is_private'],
            $item->fields['date_mod'] ?? null,
            $item->fields['users_id_editor'] ?? null,
        ]));
        return $view;
    }

    /**
     * Preserve native parallel upload indexes; never accept paths or arbitrary
     * object/document IDs. The native helper supplies these three arrays. Core
     * Document APIs still own extension, size, duplicate and link handling.
     * $forCreation is a server-owned flag after the rich feature/context gates.
     * The marker is deliberately reconstructed, never read from client input.
     * @return array<string,mixed>
     */
    public static function nativeUploads(array $input, bool $forCreation = false): array
    {
        $keys = ['_filename', '_tag_filename', '_prefix_filename'];
        $present = array_filter($keys, static fn(string $key): bool => array_key_exists($key, $input));
        if ($present === []) {
            return array_fill_keys($keys, []) + ($forCreation ? ['_native_editor_uploads' => true] : []);
        }
        foreach ($keys as $key) {
            if (!isset($input[$key]) || !is_array($input[$key]) || count($input[$key]) > 20) {
                throw new \InvalidArgumentException('interaction_upload_invalid');
            }
        }
        if (array_keys($input['_filename']) !== array_keys($input['_tag_filename'])
            || array_keys($input['_filename']) !== array_keys($input['_prefix_filename'])) {
            throw new \InvalidArgumentException('interaction_upload_invalid');
        }
        $uploads = array_intersect_key($input, array_flip($keys));
        foreach ($uploads['_filename'] as $key => $filename) {
            $prefix = $uploads['_prefix_filename'][$key];
            $tag = $uploads['_tag_filename'][$key];
            if (!is_string($filename) || !is_string($prefix) || !is_string($tag)
                || $filename === '' || strlen($filename) > 255 || strlen($tag) > 255
                || $prefix === '' || strlen($prefix) > 128 || !str_starts_with($filename, $prefix)
                || strpbrk($filename, "/\\\0\r\n") !== false || $filename === '.' || $filename === '..'
                || !defined('GLPI_TMP_DIR')) {
                throw new \InvalidArgumentException('interaction_upload_invalid');
            }
            $base = realpath((string) GLPI_TMP_DIR);
            $candidate = rtrim((string) GLPI_TMP_DIR, '/\\') . DIRECTORY_SEPARATOR . $filename;
            $path = realpath($candidate);
            if ($base === false || $path === false || dirname($path) !== $base || !is_file($path) || is_link($candidate)) {
                throw new \InvalidArgumentException('interaction_upload_invalid');
            }
        }
        return $uploads + ($forCreation ? ['_native_editor_uploads' => true] : []);
    }

    /** Editor/uploader only; the plugin owns the surrounding form and POST. */
    public function nativeForm(int $ticketId, string $kind, int $id): ?string
    {
        $context = $this->richContext($ticketId, $kind, $id);
        return (new \GlpiPlugin\Glpiacessivel\UI\View\RichInteractionFields())
            ->render((string) $context['content_html'], 'interaction-content');
    }

    /**
     * $baseline is server-owned form state, never values copied from POST.
     * Only changed user fields enter the native payload. In particular a
     * privacy-only update never resubmits/normalizes the stored rich content.
     *
     * @param array<string,mixed> $input
     * @param array<string,mixed> $baseline
     * @return array{status:string}
     */
    public function update(int $ticketId, string $kind, int $id, array $input, array $baseline): array
    {
        foreach (array_keys($input) as $key) {
            if (!in_array($key, ['content', 'is_private'], true)) {
                throw new \InvalidArgumentException('interaction_field_not_allowed');
            }
        }
        [$ticket, $item] = $this->authorized($ticketId, $kind, $id);
        $current = $this->view($ticketId, $kind, $id, $ticket, $item);
        if (
            ($baseline['ticket_id'] ?? null) !== $ticketId
            || ($baseline['kind'] ?? null) !== $kind
            || ($baseline['interaction_id'] ?? null) !== $id
        ) {
            throw new \InvalidArgumentException('interaction_request_invalid');
        }

        $payload = ['id' => $id];
        $expectedText = null;
        if (array_key_exists('content', $input)) {
            if (!is_string($input['content']) || strlen($input['content']) > self::MAX_TEXT_BYTES) {
                throw new \InvalidArgumentException('interaction_text_invalid');
            }
            $text = str_replace(["\r\n", "\r"], "\n", $input['content']);
            if ($text !== ($baseline['content'] ?? '')) {
                if (
                    empty($baseline['can_edit_content']) || empty($current['can_edit_content'])
                    || $this->hasMarkup($text)
                ) {
                    throw new \InvalidArgumentException('interaction_rich_text_native_only');
                }
                $payload['content'] = $text;
                $expectedText = $text;
            }
        }
        if (array_key_exists('is_private', $input)) {
            if (!in_array($input['is_private'], [0, 1, '0', '1'], true)) {
                throw new \InvalidArgumentException('interaction_visibility_invalid');
            }
            $privacy = (int) $input['is_private'];
            if ($privacy !== ($baseline['is_private'] ?? null)) {
                if (empty($baseline['can_change_privacy']) || empty($current['can_change_privacy'])) {
                    throw new \InvalidArgumentException('interaction_visibility_not_available');
                }
                $payload['is_private'] = $privacy;
            }
        }
        if (count($payload) === 1) {
            return ['status' => 'unchanged'];
        }

        // This is the same public update entry point used by the native forms.
        // `update` lets CommonDBTM set its native _update/editor marker. Never
        // forward author, technician, planning, status, parent or upload fields.
        $payload['update'] = 1;
        if ($kind === 'task') {
            $payload['tickets_id'] = $ticketId;
        } else {
            $payload['itemtype'] = 'Ticket';
            $payload['items_id'] = $ticketId;
        }
        if ($this->legacy() && array_key_exists('content', $payload)) {
            // GLPI 10 CommonDBTM expects the same sanitized input as its form;
            // GLPI 11 objects accept raw values and must not be double encoded.
            if (!class_exists('Glpi\\Toolbox\\Sanitizer')) {
                throw new \RuntimeException('interaction_native_codec_unavailable');
            }
            $payload['content'] = \Glpi\Toolbox\Sanitizer::sanitize($payload['content']);
        }
        try {
            $accepted = (bool) $item->update($payload);
            // The native followup/task form controllers explicitly write this
            // event after update() returns (even a normal rejected attempt).
            // Object-level history/hooks remain owned by the native update.
            ($this->events)(
                $ticketId,
                'ticket',
                4,
                'tracking',
                sprintf(
                    $kind === 'task' ? __('%s updates a task') : __('%s updates a followup'),
                    (string) ($_SESSION['glpiname'] ?? '')
                )
            );
        } catch (\Throwable) {
            // This also covers event failure after a persisted update. Do not
            // repeat the mutation or pretend that its audit event succeeded.
            return ['status' => 'uncertain'];
        }
        if (!$accepted) {
            return ['status' => 'rejected'];
        }
        try {
            [$afterTicket, $afterItem] = $this->authorized($ticketId, $kind, $id);
            $after = $this->view($ticketId, $kind, $id, $afterTicket, $afterItem);
            if (isset($payload['is_private']) && $after['is_private'] !== $payload['is_private']) {
                return ['status' => 'uncertain'];
            }
            if (array_key_exists('content', $payload) && $after['content'] !== $expectedText) {
                return ['status' => 'uncertain'];
            }
        } catch (\Throwable) {
            return ['status' => 'uncertain'];
        }
        return ['status' => 'saved'];
    }

    /** @return array{object,object} */
    private function authorized(int $ticketId, string $kind, int $id): array
    {
        if ($ticketId < 1 || $id < 1 || !in_array($kind, ['followup', 'task'], true)) {
            throw new \InvalidArgumentException('interaction_request_invalid');
        }
        if ($kind === 'task' && ($this->interface)() !== 'central') {
            throw new \DomainException('interaction_not_available');
        }
        $ticket = ($this->factory)('ticket');
        if (!$ticket->getFromDB($ticketId) || !$ticket->can($ticketId, READ)) {
            throw new \DomainException('interaction_not_available');
        }
        $item = ($this->factory)($kind);
        if (!$item->getFromDB($id)) {
            throw new \DomainException('interaction_not_available');
        }
        $belongs = $kind === 'followup'
            ? (($item->fields['itemtype'] ?? '') === 'Ticket' && (int) ($item->fields['items_id'] ?? 0) === $ticketId)
            : (int) ($item->fields['tickets_id'] ?? 0) === $ticketId;
        if (!$belongs || !$item->can($id, READ) || !$item->can($id, UPDATE)) {
            throw new \DomainException('interaction_not_available');
        }
        return [$ticket, $item];
    }

    /** @return array<string,mixed> */
    private function view(int $ticketId, string $kind, int $id, object $ticket, object $item): array
    {
        $raw = (string) ($item->fields['content'] ?? '');
        $plain = $raw;
        if ($this->legacy()) {
            if (!class_exists('Glpi\\Toolbox\\Sanitizer')) {
                throw new \RuntimeException('interaction_native_codec_unavailable');
            }
            $plain = (string) \Glpi\Toolbox\Sanitizer::unsanitize($raw, false);
        }
        $plain = str_replace(["\r\n", "\r"], "\n", $plain);
        $editable = strlen($plain) <= self::MAX_TEXT_BYTES && !$this->hasMarkup($raw);
        $nativeUrl = '';
        if (method_exists($ticket, 'getFormURLWithID')) {
            $nativeUrl = (string) $ticket->getFormURLWithID($ticketId);
        }
        return [
            'ticket_id' => $ticketId,
            'kind' => $kind,
            'interaction_id' => $id,
            'content' => $editable ? $plain : '',
            'is_private' => !empty($item->fields['is_private']) ? 1 : 0,
            'can_edit_content' => $editable,
            'can_change_privacy' => ($this->interface)() === 'central',
            // Opens the parent ticket, not an unproven direct interaction editor.
            'native_ticket_url' => $nativeUrl,
        ];
    }

    private function hasMarkup(string $content): bool
    {
        // Detect tags even in GLPI 10 encoded/double-encoded projections.
        // Decoding here never replaces the original stored content.
        for ($pass = 0; $pass < 3; ++$pass) {
            if (preg_match('/<\/?[a-z][^>]*>|<!--|<!DOCTYPE/i', $content) === 1) {
                return true;
            }
            $decoded = html_entity_decode($content, ENT_QUOTES | ENT_HTML5, 'UTF-8');
            if ($decoded === $content) {
                break;
            }
            $content = $decoded;
        }
        return false;
    }

    private function legacy(): bool
    {
        return defined('GLPI_VERSION') && version_compare((string) GLPI_VERSION, '11.0.0', '<');
    }
}
