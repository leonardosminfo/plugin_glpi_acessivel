<?php

declare(strict_types=1);

namespace GlpiPlugin\Glpiacessivel\Infrastructure\Ticket;

use GlpiPlugin\Glpiacessivel\Application\FeatureReleasePolicy;

/** Authorized rich editor fragments for the existing plugin-owned forms. */
final class NativeInteractionCreationForms
{
    private \Closure $render;
    private \Closure $released;

    public function __construct(?callable $render = null, ?callable $released = null)
    {
        $this->render = $render === null
            ? static fn(int $ticketId, string $kind): ?string => (new NativeInteractionCreator())->nativeForm($ticketId, $kind)
            : \Closure::fromCallable($render);
        $this->released = $released === null
            ? static fn(): bool => FeatureReleasePolicy::allows('tickets.interaction_rich_add', true)
            : \Closure::fromCallable($released);
    }

    /**
     * @param array<string,mixed> $ticket Authorized detail projection, never request fields.
     * @param array<string,mixed> $uploadRecovery Existing request-local recovery draft.
     * @return array<string,string> Only nonempty authorized editor/uploader fragments.
     */
    public function forDetail(array $ticket, array $uploadRecovery = []): array
    {
        $ticketId = (int) ($ticket['id'] ?? 0);
        try {
            if ($ticketId < 1 || !($this->released)()) {
                return [];
            }
        } catch (\Throwable) {
            return [];
        }

        $forms = [];
        foreach (['followup', 'task'] as $kind) {
            if (
                empty($ticket['itil_actions']['can_add_' . $kind])
                || ($uploadRecovery !== [] && ($uploadRecovery['action'] ?? '') === $kind)
            ) {
                continue;
            }
            try {
                // Fresh native READ/CREATE checks precede editor helper exposure.
                $html = ($this->render)($ticketId, $kind);
                if (is_string($html) && trim($html) !== '') {
                    $forms[$kind] = $html;
                }
            } catch (\Throwable) {
                // Keep the existing simple form; never manufacture native fields.
            }
        }
        return $forms;
    }
}
