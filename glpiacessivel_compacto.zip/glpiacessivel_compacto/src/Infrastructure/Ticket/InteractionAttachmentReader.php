<?php

declare(strict_types=1);

namespace GlpiPlugin\Glpiacessivel\Infrastructure\Ticket;

/** Read-only context. Attachment ACL remains in TicketRepository/Document. */
final class InteractionAttachmentReader
{
    private \Closure $factory;

    public function __construct(?callable $factory = null)
    {
        $this->factory = $factory === null
            ? static fn(string $type): object => new $type()
            : \Closure::fromCallable($factory);
    }

    public function context(int $ticketId, string $kind, int $id): array
    {
        $type = match ($kind) {
            'followup' => 'ITILFollowup',
            'task' => 'TicketTask',
            default => throw new \InvalidArgumentException('attachment_context_invalid'),
        };
        if ($ticketId < 1 || $id < 1) {
            throw new \InvalidArgumentException('attachment_context_invalid');
        }
        $ticket = ($this->factory)('Ticket');
        $item = ($this->factory)($type);
        if (
            !$ticket->getFromDB($ticketId) || !$ticket->can($ticketId, READ)
            || !$item->getFromDB($id) || !$item->can($id, READ)
        ) {
            throw new \DomainException('attachment_not_available');
        }
        $belongs = $kind === 'task'
            ? (int) ($item->fields['tickets_id'] ?? 0) === $ticketId
            : ($item->fields['itemtype'] ?? '') === 'Ticket' && (int) ($item->fields['items_id'] ?? 0) === $ticketId;
        if (!$belongs) {
            throw new \DomainException('attachment_not_available');
        }
        return [
            'ticket_id' => $ticketId, 'kind' => $kind, 'interaction_id' => $id,
            'is_private' => empty($item->fields['is_private']) ? 0 : 1,
            // Never rendered. Only descriptions of exact authorized document occurrences are projected.
            'source_content' => (string) ($item->fields['content'] ?? ''),
        ];
    }

    /** No filename matching, cross-event search or automatic description. */
    public static function descriptions(string $content, array $documents): array
    {
        if ($documents === [] || strlen($content) > 1048576 || !class_exists('DOMDocument')) {
            return [];
        }
        $formatter = ['Glpi\\RichText\\RichText', 'getSafeHtml'];
        if (is_callable($formatter)) {
            try {
                $content = (string) $formatter($content);
            } catch (\Throwable) {
                return [];
            }
        }
        $allowed = array_fill_keys(array_map('intval', array_column($documents, 'id')), true);
        $result = [];
        for ($i = 0; $i < 3 && !str_contains($content, '<img'); ++$i) {
            $decoded = html_entity_decode($content, ENT_QUOTES | ENT_HTML5, 'UTF-8');
            if ($decoded === $content) {
                break;
            }
            $content = $decoded;
        }
        $dom = new \DOMDocument();
        $previous = libxml_use_internal_errors(true);
        try {
            $dom->loadHTML('<?xml encoding="UTF-8">' . $content, LIBXML_NONET | LIBXML_NOERROR | LIBXML_NOWARNING);
            foreach ($dom->getElementsByTagName('img') as $image) {
                $url = parse_url($image->getAttribute('src'));
                $path = (string) ($url['path'] ?? '');
                $expected = rtrim((string) ($GLOBALS['CFG_GLPI']['root_doc'] ?? ''), '/') . '/front/document.send.php';
                // Relative native URLs only: an external URL cannot claim a local occurrence.
                if (isset($url['host']) || $path !== $expected) {
                    continue;
                }
                parse_str((string) ($url['query'] ?? ''), $query);
                $docId = is_scalar($query['docid'] ?? null) ? (int) $query['docid'] : 0;
                $alt = trim($image->getAttribute('alt'));
                if (isset($allowed[$docId]) && $alt !== '') {
                    $result[$docId][] = mb_substr($alt, 0, 2000);
                }
            }
        } finally {
            libxml_clear_errors();
            libxml_use_internal_errors($previous);
        }
        return array_map(static fn(array $values): array => array_values(array_unique($values)), $result);
    }
}
