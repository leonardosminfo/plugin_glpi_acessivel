<?php

declare(strict_types=1);

namespace GlpiPlugin\Glpiacessivel\Infrastructure\Search;

/** Proven Search-only semantics; zero is never an actor or a remotely selectable user. */
final class GlpiTicketUnassignedSearchCapability
{
    private \Closure $versionReader;

    public function __construct(?callable $versionReader = null)
    {
        $this->versionReader = $versionReader === null
            ? static fn(): string => defined('GLPI_VERSION') ? (string) GLPI_VERSION : ''
            : \Closure::fromCallable($versionReader);
    }

    /** @param array<string,mixed> $option */
    public function isAssignedTechnician(string $itemtype, array $option): bool
    {
        $before = $option['joinparams']['beforejoin'] ?? null;
        return $itemtype === 'Ticket'
            && ($option['table'] ?? null) === 'glpi_users'
            && ($option['field'] ?? null) === 'name'
            && ($option['datatype'] ?? null) === 'dropdown'
            && ($option['right'] ?? null) === 'own_ticket'
            && in_array($option['linkfield'] ?? '', ['', 'users_id'], true)
            && !empty($option['use_subquery'])
            && empty($option['nosearch'])
            && is_array($before)
            && ($before['table'] ?? null) === 'glpi_tickets_users'
            && ($before['joinparams']['jointype'] ?? null) === 'child'
            && in_array($before['joinparams']['condition'] ?? null, [
                ['NEWTABLE.type' => 2], ['NEWTABLE.type' => '2'],
            ], true);
    }

    /** @param array<string,mixed> $option @param string[] $nativeOperators */
    public function mode(string $itemtype, array $option, array $nativeOperators): ?string
    {
        if (!$this->isAssignedTechnician($itemtype, $option)) {
            return null;
        }
        $version = ($this->versionReader)();
        if (
            preg_match('/\A10\.0\.\d+(?:[-+][\w.-]+)?\z/D', $version) === 1
            && in_array('equals', $nativeOperators, true)
            && !in_array('empty', $nativeOperators, true)
        ) {
            return 'legacy_zero';
        }
        if (
            preg_match('/\A11\.\d+\.\d+(?:[-+][\w.-]+)?\z/D', $version) === 1
            && in_array('empty', $nativeOperators, true)
        ) {
            return 'native_empty';
        }
        return null;
    }
}
