<?php

declare(strict_types=1);

namespace GlpiPlugin\Glpiacessivel\Infrastructure\Search;

use GlpiPlugin\Glpiacessivel\Domain\Ticket\NativeSearchValidationException;

/** Convert only the proven assigned-technician empty criterion at native boundaries. */
final class GlpiTicketUnassignedCriterionCodec
{
    private GlpiTicketUnassignedSearchCapability $capability;
    private \Closure $optionsReader;
    private \Closure $operatorsReader;

    public function __construct(
        ?GlpiTicketUnassignedSearchCapability $capability = null,
        ?callable $optionsReader = null,
        ?callable $operatorsReader = null
    ) {
        $this->capability = $capability ?? new GlpiTicketUnassignedSearchCapability();
        $this->optionsReader = $optionsReader === null
            ? static fn(): array => is_callable(['Search', 'getOptions']) ? (array) \Search::getOptions('Ticket') : []
            : \Closure::fromCallable($optionsReader);
        $this->operatorsReader = $operatorsReader === null
            ? static function (int $field): array {
                if (!is_callable(['Search', 'getActionsFor'])) {
                    return [];
                }
                $actions = call_user_func(['Search', 'getActionsFor'], 'Ticket', $field);
                return is_array($actions) ? array_values(array_filter(array_keys($actions), 'is_string')) : [];
            }
            : \Closure::fromCallable($operatorsReader);
    }

    /** @return array<int,mixed> */
    public function compileForGlpi(array $criteria, string $defaultItemtype = 'Ticket'): array
    {
        return $this->transform($criteria, $defaultItemtype, true);
    }

    /** @return array<int,mixed> */
    public function restorePortalSemantics(array $criteria, string $defaultItemtype = 'Ticket'): array
    {
        return $this->transform($criteria, $defaultItemtype, false);
    }

    /** @return array<int,mixed> */
    private function transform(array $criteria, string $defaultItemtype, bool $compile): array
    {
        if (!$this->hasCandidate($criteria, $compile)) {
            return $criteria;
        }
        // No native business records or SQL are read by this metadata adapter.
        try {
            $options = ($this->optionsReader)();
        } catch (\Throwable $exception) {
            if ($compile) {
                throw new NativeSearchValidationException('native_unassigned_contract_unavailable', 'criteria.searchtype');
            }
            return $criteria;
        }
        foreach ($criteria as $key => $criterion) {
            if (!is_array($criterion)) {
                continue;
            }
            $itemtype = (string) ($criterion['itemtype'] ?? $defaultItemtype);
            if (is_array($criterion['criteria'] ?? null)) {
                $criterion['criteria'] = $this->transform($criterion['criteria'], $itemtype, $compile);
                $criteria[$key] = $criterion;
                continue;
            }
            if ($itemtype !== 'Ticket' || !empty($criterion['meta']) || !is_numeric($criterion['field'] ?? null)) {
                continue;
            }
            $field = (int) $criterion['field'];
            $option = $options[$field] ?? null;
            $operator = (string) ($criterion['searchtype'] ?? '');
            $value = $criterion['value'] ?? '';
            $nativeOperators = ($this->operatorsReader)($field);
            $assigned = is_array($option) && $this->capability->isAssignedTechnician($itemtype, $option);
            $mode = $assigned ? $this->capability->mode($itemtype, $option, $nativeOperators) : null;
            if (!$compile && $operator === 'empty' && $mode === 'native_empty' && $value !== 'null') {
                // An older saved leaf with value '' was ignored by the core.
                // Do not silently activate that criterion when reopening it.
                throw new NativeSearchValidationException('native_unassigned_empty_value_invalid', 'criteria.value');
            }
            if ($compile && $operator === 'empty') {
                if (
                    ($value !== '' && !($mode === 'native_empty' && $value === 'null')) || !is_array($option)
                    || ($assigned && $mode === null)
                    || (!$assigned && !in_array('empty', $nativeOperators, true))
                ) {
                    throw new NativeSearchValidationException('native_unassigned_contract_unavailable', 'criteria.searchtype');
                }
                if ($mode === 'legacy_zero') {
                    $criterion['searchtype'] = 'equals';
                    $criterion['value'] = '0';
                } elseif ($mode === 'native_empty') {
                    // QueryBuilder uses a literal hidden "null" value. The
                    // core's constructCriteriaSQL skips a leaf with value ''.
                    $criterion['value'] = 'null';
                }
            } elseif (!$compile && $operator === 'equals' && in_array($value, ['0', 0], true) && $mode === 'legacy_zero') {
                $criterion['searchtype'] = 'empty';
                $criterion['value'] = '';
            } elseif (!$compile && $operator === 'empty' && $value === 'null' && $mode === 'native_empty') {
                $criterion['value'] = '';
            }
            $criteria[$key] = $criterion;
        }
        return $criteria;
    }

    private function hasCandidate(array $criteria, bool $compile): bool
    {
        foreach ($criteria as $criterion) {
            if (!is_array($criterion)) {
                continue;
            }
            if (is_array($criterion['criteria'] ?? null) && $this->hasCandidate($criterion['criteria'], $compile)) {
                return true;
            }
            if ($compile && ($criterion['searchtype'] ?? '') === 'empty') {
                return true;
            }
            if (!$compile && ($criterion['searchtype'] ?? '') === 'empty') {
                return true;
            }
            if (
                !$compile && ($criterion['searchtype'] ?? '') === 'equals'
                && in_array($criterion['value'] ?? null, ['0', 0], true)
            ) {
                return true;
            }
        }
        return false;
    }
}
