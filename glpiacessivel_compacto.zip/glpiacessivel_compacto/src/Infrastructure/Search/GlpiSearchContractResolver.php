<?php

declare(strict_types=1);

namespace GlpiPlugin\Glpiacessivel\Infrastructure\Search;

use GlpiPlugin\Glpiacessivel\Domain\Ticket\SearchFieldContract;
use GlpiPlugin\Glpiacessivel\Domain\Ticket\SearchOperatorValueContract;
use GlpiPlugin\Glpiacessivel\Domain\Ticket\SearchValueKind;
use GlpiPlugin\Glpiacessivel\Application\FeatureReleasePolicy;
use GlpiPlugin\Glpiacessivel\Infrastructure\Tags\TagSearchCapability;

/**
 * Resolves the intersection between native actions and value semantics proven
 * safe on the active GLPI generation.
 */
final class GlpiSearchContractResolver
{
    /** @var string[] */
    private const EMPTY_OPERATORS = ['empty', 'notempty'];

    /** @var string[] */
    private const TEXT_OPERATORS = ['contains', 'notcontains', 'equals', 'notequals'];

    /** @var string[] */
    private const ORDERED_OPERATORS = ['equals', 'notequals', 'lessthan', 'morethan'];

    /** @var string[] */
    private const SELECT_OPERATORS = ['contains', 'notcontains', 'equals', 'notequals'];

    /** @var string[] */
    private const HIERARCHICAL_TABLES = [
        'glpi_entities',
        'glpi_groups',
        'glpi_itilcategories',
        'glpi_locations',
    ];

    /**
     * Native dropdown targets whose ID semantics are stable on GLPI 10/11.
     * Search Options outside this evidence-based projection fail closed.
     *
     * @var array<string,string[]>
     */
    private const REMOTE_TARGETS = [
        'glpi_entities' => ['entities_id'],
        'glpi_groups' => ['groups_id', 'groups_id_requester', 'groups_id_tech'],
        'glpi_itilcategories' => ['itilcategories_id'],
        'glpi_locations' => ['locations_id'],
        'glpi_users' => ['users_id', 'users_id_lastupdater', 'users_id_recipient', 'users_id_tech'],
    ];

    private \Closure $tagCapability;
    private \Closure $release;
    private GlpiTicketUnassignedSearchCapability $unassigned;

    public function __construct(
        private ?GlpiTicketLocalValueCatalog $localValues = null,
        ?callable $tagCapability = null,
        ?callable $release = null,
        ?GlpiTicketUnassignedSearchCapability $unassigned = null
    ) {
        $this->localValues ??= new GlpiTicketLocalValueCatalog();
        $this->unassigned = $unassigned ?? new GlpiTicketUnassignedSearchCapability();
        $this->tagCapability = $tagCapability === null
            ? static fn(): array => (new TagSearchCapability())->inspect()
            : \Closure::fromCallable($tagCapability);
        $this->release = $release === null
            ? static fn(string $key): bool => FeatureReleasePolicy::allows($key)
            : \Closure::fromCallable($release);
    }

    /**
     * @param array<string,mixed> $option
     * @param string[] $nativeOperators
     */
    public function resolve(
        string $itemtype,
        int $fieldId,
        array $option,
        array $nativeOperators
    ): ?SearchFieldContract {
        if ($itemtype === '' || $fieldId < 1 || $nativeOperators === []) {
            return null;
        }

        $field = strtolower(trim((string) ($option['field'] ?? '')));
        $table = strtolower(trim((string) ($option['table'] ?? '')));
        $linkfield = strtolower(trim((string) ($option['linkfield'] ?? '')));
        $datatype = strtolower(trim((string) ($option['datatype'] ?? '')));
        if (str_starts_with($table, 'glpi_plugin_tag_')) {
            return $this->tagContract($itemtype, $fieldId, $option, $nativeOperators);
        }
        $linkfield = $this->normalizedLinkfield($field, $table, $linkfield, $datatype);
        $localValues = $this->localValues->valuesFor($itemtype, $option);
        $kind = $this->valueKind(
            $itemtype,
            $field,
            $table,
            $linkfield,
            $datatype,
            $localValues
        );

        $operators = [];
        if ($this->unassigned->mode($itemtype, $option, $nativeOperators) === 'legacy_zero') {
            // Internal no-value semantics only. The execution/storage codec
            // translates this to the core's equals-zero criterion on GLPI 10.
            $operators[] = SearchOperatorValueContract::none('empty');
        }
        foreach (array_values(array_unique($nativeOperators)) as $operator) {
            $operator = strtolower(trim($operator));
            if ($operator === '') {
                continue;
            }
            if (in_array($operator, self::EMPTY_OPERATORS, true)) {
                if ($kind !== null) {
                    $operators[] = SearchOperatorValueContract::none($operator);
                }
                continue;
            }
            if ($kind === null || !$this->supports($kind, $operator, $table, $datatype)) {
                continue;
            }
            $operators[] = $this->contract(
                $operator,
                $kind,
                $localValues,
                $table,
                $linkfield
            );
        }
        if ($operators === []) {
            return null;
        }

        return new SearchFieldContract(
            $itemtype,
            $fieldId,
            $field,
            $table,
            $linkfield,
            $datatype,
            $operators
        );
    }

    /**
     * Tag is the only additional plugin target admitted here. Its contextual
     * direct-Ticket descriptor must be proven before even textual operators
     * are considered; in particular the separate Entity relation stays closed.
     *
     * @param array<string,mixed> $option
     * @param string[] $nativeOperators
     */
    private function tagContract(
        string $itemtype,
        int $fieldId,
        array $option,
        array $nativeOperators
    ): ?SearchFieldContract {
        try {
            $capability = ($this->tagCapability)();
            if (
                $itemtype !== 'Ticket'
                || !($this->release)('tickets.tags_filter')
                || ($capability['state'] ?? '') !== 'ready'
                || (int) ($capability['option_id'] ?? 0) !== $fieldId
                || !is_array($capability['descriptor'] ?? null)
                || (string) ($capability['descriptor']['table'] ?? '') !== (string) ($option['table'] ?? '')
                || ($capability['descriptor']['joinparams'] ?? null) !== ($option['joinparams'] ?? null)
                || ($option['field'] ?? '') !== 'name'
                || ($option['datatype'] ?? '') !== 'dropdown'
                || !empty($option['nosearch'])
                || !in_array('equals', $nativeOperators, true)
            ) {
                return null;
            }
        } catch (\Throwable $e) {
            return null;
        }

        $table = (string) $option['table'];
        return new SearchFieldContract(
            'Ticket',
            $fieldId,
            'name',
            $table,
            'id',
            'dropdown',
            [new SearchOperatorValueContract(
                'equals',
                SearchValueKind::REMOTE_SELECT,
                true,
                null,
                [],
                4096,
                false,
                $table,
                'id',
                false
            )]
        );
    }

    /**
     * @param array<int,array{value:string,label:string}> $localValues
     */
    private function valueKind(
        string $itemtype,
        string $field,
        string $table,
        string $linkfield,
        string $datatype,
        array $localValues
    ): ?SearchValueKind {
        if ($localValues !== []) {
            return SearchValueKind::LOCAL_SELECT;
        }
        if (
            $itemtype === 'Ticket'
            && $table === 'glpi_tickets'
            && in_array($field, ['name', 'content'], true)
        ) {
            return SearchValueKind::TEXT;
        }
        if (in_array($datatype, ['text', 'string'], true)) {
            return SearchValueKind::TEXT;
        }
        if (in_array($datatype, ['bool', 'boolean'], true)) {
            return SearchValueKind::BOOLEAN;
        }
        if ($datatype === 'date') {
            return SearchValueKind::DATE;
        }
        if ($datatype === 'datetime') {
            return SearchValueKind::DATETIME;
        }
        if (in_array($datatype, ['integer', 'count'], true)) {
            return SearchValueKind::INTEGER;
        }
        if ($datatype === 'number') {
            return $field === 'id' || str_ends_with($field, '_id')
                ? SearchValueKind::INTEGER
                : SearchValueKind::DECIMAL;
        }
        if ($datatype === 'decimal') {
            return SearchValueKind::DECIMAL;
        }
        if ($this->isNativeRemoteTarget($table, $linkfield)) {
            return SearchValueKind::REMOTE_SELECT;
        }

        // date_delay and unknown/plugin datatypes stay unavailable until their
        // exact GLPI 10/11 value representation is proven.
        return null;
    }

    private function isNativeRemoteTarget(string $table, string $linkfield): bool
    {
        return isset(self::REMOTE_TARGETS[$table])
            && in_array($linkfield, self::REMOTE_TARGETS[$table], true);
    }

    private function supports(
        SearchValueKind $kind,
        string $operator,
        string $table,
        string $datatype
    ): bool {
        if ($kind === SearchValueKind::TEXT) {
            return in_array($operator, self::TEXT_OPERATORS, true);
        }
        if (
            $kind === SearchValueKind::INTEGER
            || $kind === SearchValueKind::DECIMAL
            || $kind === SearchValueKind::DATE
            || $kind === SearchValueKind::DATETIME
        ) {
            if (
                $datatype === 'count'
                && in_array($operator, ['contains', 'notcontains'], true)
            ) {
                return true;
            }
            return in_array($operator, self::ORDERED_OPERATORS, true);
        }
        if ($kind === SearchValueKind::LOCAL_SELECT) {
            return in_array($operator, self::SELECT_OPERATORS, true);
        }
        if ($kind === SearchValueKind::BOOLEAN) {
            return in_array($operator, ['equals', 'notequals'], true);
        }
        if ($kind === SearchValueKind::REMOTE_SELECT) {
            if (in_array($operator, ['equals', 'notequals'], true)) {
                return true;
            }
            return in_array($table, self::HIERARCHICAL_TABLES, true)
                && in_array($operator, ['under', 'notunder'], true);
        }
        return false;
    }

    private function normalizedLinkfield(
        string $field,
        string $table,
        string $linkfield,
        string $datatype
    ): string {
        if ($linkfield !== '') {
            return $linkfield;
        }
        if (
            !in_array($datatype, ['dropdown', 'itemlink'], true)
            || !in_array($field, ['name', 'completename'], true)
        ) {
            return '';
        }

        return [
            'glpi_entities' => 'entities_id',
            'glpi_groups' => 'groups_id',
            'glpi_itilcategories' => 'itilcategories_id',
            'glpi_locations' => 'locations_id',
            'glpi_users' => 'users_id',
        ][$table] ?? '';
    }

    /**
     * @param array<int,array{value:string,label:string}> $localValues
     */
    private function contract(
        string $operator,
        SearchValueKind $kind,
        array $localValues,
        string $table,
        string $linkfield
    ): SearchOperatorValueContract {
        if ($kind === SearchValueKind::LOCAL_SELECT) {
            return new SearchOperatorValueContract($operator, $kind, true, null, $localValues);
        }
        if ($kind === SearchValueKind::REMOTE_SELECT) {
            return new SearchOperatorValueContract(
                $operator,
                $kind,
                true,
                null,
                [],
                4096,
                false,
                $table,
                $linkfield,
                in_array($table, self::HIERARCHICAL_TABLES, true)
            );
        }
        return new SearchOperatorValueContract($operator, $kind);
    }
}
