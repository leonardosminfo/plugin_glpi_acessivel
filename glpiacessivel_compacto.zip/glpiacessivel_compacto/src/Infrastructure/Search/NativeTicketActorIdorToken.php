<?php

declare(strict_types=1);

namespace GlpiPlugin\Glpiacessivel\Infrastructure\Search;

/** Mirrors the token emitted by the core ITIL actor field, without retrying validation. */
final class NativeTicketActorIdorToken
{
    public static function create(): string
    {
        if (!defined('GLPI_VERSION')
            || preg_match('/\A(10|11)\.0\.(\d+)(?:[-+][\w.-]+)?\z/D', (string) GLPI_VERSION, $version) !== 1
            || !is_callable(['\\Session', 'getNewIDORToken'])) {
            throw new \RuntimeException('resource_selector_native_contract_unavailable');
        }

        // GLPI <= 10.0.12 passes one generic token through getDropdownActors
        // and its nested Group lookup (field.html.twig uses idor_token()).
        // From 10.0.13 the core actor field binds Ticket/users_right, while
        // Dropdown creates a separate bound token for the nested Group lookup.
        // Use exactly that runtime's public Session API; never retry with a
        // less-bound token after a failed call.
        return $version[1] === '10' && (int) $version[2] < 13
            ? \Session::getNewIDORToken()
            : \Session::getNewIDORToken('Ticket', ['users_right' => 'own_ticket']);
    }
}
