<?php

declare(strict_types=1);

namespace GlpiPlugin\Glpiacessivel\Infrastructure\Search;

/** Lossless bridge between one frequent-filter selection and the native AST. */
final class TicketTagFilterCriteria
{
    /**
     * Only one positive equals leaf joined at the root by AND can be projected.
     * Complex saved expressions remain expressions, never a simplified label.
     *
     * @param array<int,array<string,mixed>> $criteria
     * @return array{mode:string,id:?int}
     */
    public static function project(array $criteria, int $field): array
    {
        if ($field < 1) {
            return ['mode' => 'none', 'id' => null];
        }
        $count = self::count($criteria, $field);
        if ($count === 0) {
            return ['mode' => 'none', 'id' => null];
        }
        if ($count !== 1) {
            return ['mode' => 'advanced', 'id' => null];
        }
        foreach ($criteria as $criterion) {
            if (strtoupper((string) ($criterion['link'] ?? 'AND')) !== 'AND') {
                return ['mode' => 'advanced', 'id' => null];
            }
        }
        foreach ($criteria as $criterion) {
            if (!self::isTag($criterion, $field)) {
                continue;
            }
            $id = $criterion['value'] ?? null;
            if (
                ($criterion['searchtype'] ?? '') !== 'equals'
                || (!is_int($id) && !is_string($id))
                || preg_match('/\A[1-9][0-9]{0,9}\z/D', (string) $id) !== 1
                || (int) $id > 2147483647
            ) {
                break;
            }
            return ['mode' => 'simple', 'id' => (int) $id];
        }
        return ['mode' => 'advanced', 'id' => null];
    }

    /**
     * The existing whole expression is grouped before AND, preserving root OR.
     * Zero removes only a proven simple tag; complex expressions are immutable.
     *
     * @param array<int,array<string,mixed>> $criteria
     * @return array<int,array<string,mixed>>
     */
    public static function apply(array $criteria, int $field, int $selectedId): array
    {
        if ($field < 1 || $selectedId < 0 || $selectedId > 2147483647) {
            throw new \InvalidArgumentException('ticket_tag_filter_invalid');
        }
        $projection = self::project($criteria, $field);
        if ($projection['mode'] === 'advanced') {
            throw new \InvalidArgumentException('ticket_tag_filter_advanced');
        }
        if ($projection['mode'] === 'simple') {
            $criteria = array_values(array_filter(
                $criteria,
                static fn(array $criterion): bool => !self::isTag($criterion, $field)
            ));
            if (
                count($criteria) === 1
                && ($criteria[0]['link'] ?? '') === 'AND'
                && is_array($criteria[0]['criteria'] ?? null)
            ) {
                $criteria = $criteria[0]['criteria'];
            }
        }
        if ($selectedId === 0) {
            return $criteria;
        }
        $leaf = ['link' => 'AND', 'field' => $field, 'searchtype' => 'equals', 'value' => (string) $selectedId];
        return $criteria === []
            ? [$leaf]
            : [['link' => 'AND', 'criteria' => $criteria], $leaf];
    }

    /** @param array<int,array<string,mixed>> $criteria */
    private static function count(array $criteria, int $field): int
    {
        $count = 0;
        foreach ($criteria as $criterion) {
            if (is_array($criterion['criteria'] ?? null)) {
                $count += self::count($criterion['criteria'], $field);
            } elseif (self::isTag($criterion, $field)) {
                $count++;
            }
        }
        return $count;
    }

    /** @param array<string,mixed> $criterion */
    private static function isTag(array $criterion, int $field): bool
    {
        return !array_key_exists('meta', $criterion)
            && !array_key_exists('itemtype', $criterion)
            && !array_key_exists('criteria', $criterion)
            && (string) ($criterion['field'] ?? '') === (string) $field;
    }
}
