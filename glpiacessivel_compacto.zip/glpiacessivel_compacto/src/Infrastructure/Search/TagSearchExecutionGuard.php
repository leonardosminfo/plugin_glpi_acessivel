<?php

declare(strict_types=1);

namespace GlpiPlugin\Glpiacessivel\Infrastructure\Search;

/**
 * Final native-plan guard, also used for searches the accessible editor cannot
 * represent. It never removes a criterion or rewrites native parameters.
 */
final class TagSearchExecutionGuard
{
    private \Closure $options;
    private GlpiSearchOptionCatalog $catalog;

    public function __construct(?callable $options = null, ?GlpiSearchOptionCatalog $catalog = null)
    {
        $this->options = $options === null
            ? static function (): array {
                if (class_exists('\Glpi\Search\SearchOption')) {
                    return \Glpi\Search\SearchOption::getOptionsForItemtype('Ticket');
                }
                return is_callable(['Search', 'getOptions']) ? \Search::getOptions('Ticket') : [];
            }
            : \Closure::fromCallable($options);
        $this->catalog = $catalog ?? new GlpiSearchOptionCatalog();
    }

    /** @param array<string,mixed> $parameters Native parameters, not browser declarations. */
    public function assertAvailable(array $parameters, int $idOption): void
    {
        $options = ($this->options)();
        if (!is_array($options) || $options === []) {
            throw new \InvalidArgumentException('native_search_options_unavailable');
        }
        $id = $options[$idOption] ?? null;
        // The actual requested Ticket ID descriptor proves this is the full
        // native Ticket catalog, rather than a partial compatibility facade.
        // Only then can an absent numeric option be declared truly unavailable.
        $complete = is_array($id)
            && ($id['table'] ?? '') === 'glpi_tickets'
            && ($id['field'] ?? '') === 'id'
            && empty($id['joinparams']);
        $this->criteria((array) ($parameters['criteria'] ?? []), $options, $complete, 0);
        foreach ((array) ($parameters['metacriteria'] ?? []) as $criterion) {
            if (is_array($criterion) && ($criterion['itemtype'] ?? '') === 'Ticket') {
                $this->criteria([$criterion], $options, $complete, 0);
            }
        }
        foreach ((array) ($parameters['sort'] ?? []) as $field) {
            $number = $this->positiveNumber($field);
            if ($number === null) {
                throw new \InvalidArgumentException('native_search_sort_unavailable');
            }
            $option = $options[$number] ?? null;
            if (($complete && !is_array($option)) || (is_array($option) && $this->isTag($option))) {
                throw new \InvalidArgumentException('native_search_sort_unavailable');
            }
        }
    }

    /**
     * @param array<int,mixed> $criteria
     * @param array<int|string,mixed> $options
     */
    private function criteria(array $criteria, array $options, bool $complete, int $depth): void
    {
        if ($depth > 8 || count($criteria) > 100) {
            throw new \InvalidArgumentException('native_search_criteria_unavailable');
        }
        foreach ($criteria as $criterion) {
            if (!is_array($criterion)) {
                continue;
            }
            // Another itemtype owns its option namespace. Do not reinterpret
            // a Computer/Entity option number as a Ticket Tag relation.
            if (
                (isset($criterion['itemtype']) && $criterion['itemtype'] !== 'Ticket')
                || (!empty($criterion['meta']) && ($criterion['itemtype'] ?? '') !== 'Ticket')
            ) {
                continue;
            }
            if (is_array($criterion['criteria'] ?? null)) {
                $this->criteria($criterion['criteria'], $options, $complete, $depth + 1);
                continue;
            }
            $number = $this->positiveNumber($criterion['field'] ?? null);
            // Native all/view and their established handling remain untouched.
            if ($number === null) {
                if (in_array($criterion['field'] ?? null, ['all', 'view'], true)) {
                    continue;
                }
                throw new \InvalidArgumentException('native_search_field_unavailable');
            }
            $option = $options[$number] ?? null;
            if ($complete && !is_array($option)) {
                throw new \InvalidArgumentException('native_search_field_unavailable');
            }
            if (is_array($option) && $this->isTag($option)) {
                if (!$this->catalog->supportsOperator('Ticket', $number, (string) ($criterion['searchtype'] ?? ''))) {
                    throw new \InvalidArgumentException('ticket_tag_filter_unavailable');
                }
            }
        }
    }

    /** @param array<string,mixed> $option */
    private function isTag(array $option): bool
    {
        return str_starts_with(strtolower((string) ($option['table'] ?? '')), 'glpi_plugin_tag_');
    }

    private function positiveNumber(mixed $value): ?int
    {
        return (is_int($value) || is_string($value))
            && preg_match('/\A[0-9]{1,10}\z/D', (string) $value) === 1
            && (int) $value > 0
            && (int) $value <= 2147483647 ? (int) $value : null;
    }
}
