<?php

declare(strict_types=1);

namespace GlpiPlugin\Glpiacessivel\Infrastructure\Tags;

/** Contextual, uncached discovery of the optional official Tag Search contract. */
final class TagSearchCapability
{
    private string $glpiVersion;

    /** @var array<string,\Closure> */
    private array $native = [];

    /** @param array<string,callable> $native Public native API test seams. */
    public function __construct(?string $glpiVersion = null, array $native = [])
    {
        $this->glpiVersion = $glpiVersion ?? (defined('GLPI_VERSION') ? (string) GLPI_VERSION : '');
        $defaults = [
            'active' => static fn(): bool => is_callable(['Plugin', 'isPluginActive'])
                && (bool) call_user_func(['Plugin', 'isPluginActive'], 'tag'),
            'version' => static fn(): string => is_callable(['Plugin', 'getInfo'])
                && function_exists('plugin_version_tag')
                ? (string) call_user_func(['Plugin', 'getInfo'], 'tag', 'version') : '',
            'available' => static fn(): bool => class_exists('PluginTagTag') && class_exists('PluginTagTagItem')
                && class_exists('Ticket') && is_callable(['Search', 'getDatas']),
            'tag_view' => static fn(): bool => \PluginTagTag::canView(),
            'tag_itemtype' => static fn(): bool => is_callable(['PluginTagTag', 'canItemtype'])
                && (bool) call_user_func(['PluginTagTag', 'canItemtype'], 'Ticket'),
            'options' => static fn(): array => class_exists('Glpi\\Search\\SearchOption')
                ? \Glpi\Search\SearchOption::getOptionsForItemtype('Ticket') : \Search::getOptions('Ticket'),
            'tag_options' => static fn(): array => class_exists('Glpi\\Search\\SearchOption')
                ? \Glpi\Search\SearchOption::getOptionsForItemtype('PluginTagTag') : \Search::getOptions('PluginTagTag'),
            'tag_table' => static fn(): string => \PluginTagTag::getTable(),
            'relation_table' => static fn(): string => \PluginTagTagItem::getTable(),
            'ticket_table' => static fn(): string => \Ticket::getTable(),
            'context' => static fn(): array => [$_SESSION['glpiactiveprofile']['id'] ?? 0,
                $_SESSION['glpiactive_entity'] ?? 0, $_SESSION['glpiactive_entity_recursive'] ?? 0,
                $_SESSION['glpiactiveentities'] ?? []],
        ];
        foreach ($defaults as $key => $callback) {
            $this->native[$key] = \Closure::fromCallable($native[$key] ?? $callback);
        }
    }

    /** @return array<string,mixed> Server-internal descriptor; never project it into JSON. */
    public function inspect(): array
    {
        $result = ['state' => 'absent', 'option_id' => 0, 'id_option' => 0, 'column_ready' => false,
            'plugin_version' => '', 'revision' => '', 'descriptor' => []];
        try {
            if (!(bool) ($this->native['active'])()) {
                return $result;
            }
            $result['state'] = 'unsupported';
            $result['plugin_version'] = (string) ($this->native['version'])();
            if (!$this->supported($result['plugin_version']) || !($this->native['available'])()) {
                return $result;
            }
            if (!($this->native['tag_view'])() || !($this->native['tag_itemtype'])()) {
                $result['state'] = 'denied';
                return $result;
            }
            $tags = [];
            $ids = [];
            $options = ($this->native['options'])();
            $ticketTable = (string) ($this->native['ticket_table'])();
            foreach ($options as $key => $option) {
                if (!is_array($option) || !ctype_digit((string) $key) || (int) $key < 1) {
                    continue;
                }
                if (
                    ($option['table'] ?? '') === $ticketTable && ($option['field'] ?? '') === 'id'
                    && empty($option['joinparams'])
                ) {
                    $ids[] = (int) $key;
                }
                if (
                    self::validatedDirectOption(
                        $option,
                        (string) ($this->native['tag_table'])(),
                        (string) ($this->native['relation_table'])(),
                        $ticketTable
                    )
                ) {
                    $tags[(int) $key] = $option;
                }
            }
            if (count($tags) !== 1 || count($ids) !== 1) {
                return $result;
            }
            $result['state'] = 'ready';
            $result['id_option'] = $ids[0];
            $result['option_id'] = (int) array_key_first($tags);
            $result['descriptor'] = reset($tags);
            $result['column_ready'] = in_array('color', $result['descriptor']['additionalfields'] ?? [], true);
            if (!$result['column_ready']) {
                $fields = [];
                foreach (($this->native['tag_options'])() as $key => $option) {
                    if (
                        is_array($option) && ($option['table'] ?? '') === $result['descriptor']['table']
                        && in_array($option['field'] ?? '', ['id', 'name', 'color'], true)
                        && empty($option['joinparams']) && ctype_digit((string) $key) && (int) $key > 0
                    ) {
                        $fields[$option['field']][] = (int) $key;
                    }
                }
                $result['column_ready'] = count($fields['id'] ?? []) === 1
                    && count($fields['name'] ?? []) === 1 && count($fields['color'] ?? []) === 1;
            }
            // Tag 2.12.6 formats every Search association via getSingleTag(),
            // which loads a record per tag. The public Search API cannot disable
            // that native formatter. Keep filtering available, not a page column.
            $result['column_ready'] = $result['column_ready'] && $result['plugin_version'] === '2.14.8';
            $result['revision'] = hash('sha256', serialize([$this->glpiVersion, $result['plugin_version'],
                $result['option_id'], $result['id_option'], $result['descriptor'], $result['column_ready'],
                $this->normalizedContext(($this->native['context'])())]));
        } catch (\Throwable) {
            $result['state'] = 'unsupported';
            $result['descriptor'] = [];
        }
        return $result;
    }

    /** @param array<string,mixed> $option Native Search descriptor, never a client table declaration. */
    public static function validatedDirectOption(
        array $option,
        string $tagTable,
        string $relationTable,
        string $ticketTable
    ): bool {
        $before = $option['joinparams']['beforejoin'] ?? null;
        $join = is_array($before) ? ($before['joinparams'] ?? null) : null;
        if (
            ($option['table'] ?? '') !== $tagTable || ($option['field'] ?? '') !== 'name'
            || !empty($option['joinparams']['condition']) || !is_array($before)
            || array_diff(array_keys($option['joinparams']), ['beforejoin', 'condition']) !== []
            || array_diff(array_keys($before), ['table', 'joinparams']) !== []
            || ($before['table'] ?? '') !== $relationTable || !is_array($join)
            || ($join['jointype'] ?? '') !== 'itemtype_item'
            || array_diff(array_keys($join), ['jointype', 'field', 'specific_itemtype', 'beforejoin']) !== []
            || (isset($join['field']) && $join['field'] !== 'items_id')
        ) {
            return false;
        }
        return (!isset($join['specific_itemtype']) && !isset($join['beforejoin']))
            || (($join['specific_itemtype'] ?? '') === 'Ticket'
                && ($join['beforejoin'] ?? null) === ['table' => $ticketTable]);
    }

    private function supported(string $tagVersion): bool
    {
        return preg_match('/\A(?:10|11)\.[0-9]+\.[0-9]+\z/D', $this->glpiVersion) === 1
            && (($tagVersion === '2.12.6' && version_compare($this->glpiVersion, '10.0.11', '>=')
                && version_compare($this->glpiVersion, '10.0.99', '<'))
                || ($tagVersion === '2.14.8' && version_compare($this->glpiVersion, '11.0.1', '>=')
                    && version_compare($this->glpiVersion, '11.0.99', '<')));
    }

    private function normalizedContext(array $context): array
    {
        $entities = [];
        foreach ((array) ($context[3] ?? []) as $entity) {
            if ((is_int($entity) || is_string($entity)) && ctype_digit((string) $entity)) {
                $entities[(int) $entity] = (int) $entity;
            }
        }
        sort($entities, SORT_NUMERIC);
        return [(int) ($context[0] ?? 0), (int) ($context[1] ?? 0),
            (bool) ($context[2] ?? false), array_values($entities)];
    }
}
