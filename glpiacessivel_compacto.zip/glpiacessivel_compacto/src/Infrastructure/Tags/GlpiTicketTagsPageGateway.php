<?php

declare(strict_types=1);

namespace GlpiPlugin\Glpiacessivel\Infrastructure\Tags;

use GlpiPlugin\Glpiacessivel\Application\TicketTagsPageGateway;

/** Two bounded public Search batches, no record-by-record hydration or reconstructed SQL. */
final class GlpiTicketTagsPageGateway implements TicketTagsPageGateway
{
    private \Closure $capability;
    private \Closure $search;
    private \Closure $tagOptions;

    public function __construct(?callable $capability = null, ?callable $search = null, ?callable $tagOptions = null)
    {
        $this->capability = \Closure::fromCallable($capability ?? static fn(): array => (new TagSearchCapability())->inspect());
        $this->search = \Closure::fromCallable($search ?? static fn(string $type, array $params, array $columns): array =>
            class_exists('Glpi\\Search\\SearchEngine')
                ? \Glpi\Search\SearchEngine::getData($type, $params, $columns)
                : \Search::getDatas($type, $params, $columns));
        $this->tagOptions = \Closure::fromCallable($tagOptions ?? static fn(): array =>
            class_exists('Glpi\\Search\\SearchOption')
                ? \Glpi\Search\SearchOption::getOptionsForItemtype('PluginTagTag') : \Search::getOptions('PluginTagTag'));
    }

    public function read(array $ticketIds): array
    {
        if ($ticketIds === []) {
            return [];
        }
        if (count($ticketIds) > 50 || count(array_unique($ticketIds)) !== count($ticketIds)) {
            throw new \RuntimeException('tag_page_limit');
        }
        foreach ($ticketIds as $id) {
            if (!is_int($id) || $id < 1) {
                throw new \RuntimeException('tag_page_invalid');
            }
        }
        $capability = ($this->capability)();
        if (($capability['state'] ?? '') !== 'ready' || ($capability['column_ready'] ?? false) !== true) {
            throw new \RuntimeException('tag_page_unavailable');
        }
        $option = (int) $capability['option_id'];
        $idOption = (int) $capability['id_option'];
        $rows = $this->query('Ticket', $ticketIds, $idOption, [$idOption, $option]);
        $map = array_fill_keys($ticketIds, []);
        $allIds = [];
        $associationCount = 0;
        $bytes = 0;
        foreach ($rows as $row) {
            $ticketId = $this->id($row['id'] ?? null);
            $cell = $row['Ticket_' . $option] ?? null;
            $count = is_array($cell) ? $this->id($cell['count'] ?? null) : 0;
            if ($count < 1 || $count > 100) {
                throw new \RuntimeException('tag_page_invalid');
            }
            foreach (array_keys($cell) as $key) {
                if (is_int($key) && ($key < 0 || $key >= $count)) {
                    throw new \RuntimeException('tag_page_invalid');
                }
            }
            if (
                $count === 1 && is_array($cell[0] ?? null) && array_key_exists('name', $cell[0])
                && $cell[0]['name'] === null && !isset($cell[0]['id'])
            ) {
                continue;
            }
            $seen = [];
            for ($index = 0; $index < $count; $index++) {
                $value = $cell[$index] ?? null;
                $id = is_array($value) ? $this->id($value['id'] ?? null) : 0;
                if (
                    $id === 0 || isset($seen[$id]) || !is_string($value['name'] ?? null)
                    || trim($value['name']) === '' || strlen($value['name']) > 4096
                ) {
                    throw new \RuntimeException('tag_page_invalid');
                }
                $bytes += strlen($value['name']) + (is_string($value['color'] ?? null) ? strlen($value['color']) : 0);
                if (++$associationCount > 1000 || $bytes > 262144) {
                    throw new \RuntimeException('tag_page_limit');
                }
                $seen[$id] = true;
                $allIds[$id] = $id;
                $map[$ticketId][] = ['id' => $id, 'name' => $value['name'], 'color' => $value['color'] ?? null];
            }
        }
        if ($allIds !== []) {
            // PluginTagTag inherits CommonDBTM::canViewItem (checkEntity(true)).
            // Searching that itemtype applies the same native entity/recursive restriction,
            // unlike projecting a Ticket join alone. No activity criterion is invented here.
            $tagFields = [];
            $tagTable = (string) ($capability['descriptor']['table'] ?? '');
            foreach (($this->tagOptions)() as $key => $descriptor) {
                if (
                    is_array($descriptor) && ($descriptor['table'] ?? '') === $tagTable
                    && in_array($descriptor['field'] ?? '', ['id', 'name', 'color'], true)
                    && empty($descriptor['joinparams'])
                    && ($id = $this->id($key)) > 0
                ) {
                    $tagFields[$descriptor['field']][] = $id;
                }
            }
            if (count($tagFields['id'] ?? []) !== 1) {
                throw new \RuntimeException('tag_page_acl_unavailable');
            }
            $idField = $tagFields['id'][0];
            $canHydrate = count($tagFields['name'] ?? []) === 1 && count($tagFields['color'] ?? []) === 1;
            $columns = $canHydrate ? [$idField, $tagFields['name'][0], $tagFields['color'][0]] : [$idField];
            $authorizedRows = $this->query('PluginTagTag', array_values($allIds), $idField, $columns);
            $records = [];
            if ($canHydrate) {
                foreach ($authorizedRows as $row) {
                    $name = $this->scalar($row, $tagFields['name'][0]);
                    $color = $this->scalar($row, $tagFields['color'][0]);
                    if (
                        !is_string($name) || trim($name) === '' || strlen($name) > 4096
                        || (!is_string($color) && $color !== null)
                    ) {
                        throw new \RuntimeException('tag_page_invalid');
                    }
                    $records[$this->id($row['id'])] = ['name' => $name, 'color' => $color];
                }
                $bytes = 0;
                foreach ($map as &$tags) {
                    foreach ($tags as &$tag) {
                        $record = $records[$tag['id']];
                        $bytes += strlen($record['name']) + strlen((string) $record['color']);
                        if ($bytes > 262144) {
                            throw new \RuntimeException('tag_page_limit');
                        }
                        $tag['name'] = $record['name'];
                        $tag['color'] = $record['color'];
                    }
                    unset($tag);
                }
                unset($tags);
            } else {
                // The older Ticket descriptor has no additional color. Never claim
                // a complete colored column without the native second-batch fallback.
                foreach ($rows as $row) {
                    $cell = $row['Ticket_' . $option];
                    for ($index = 0; $index < (int) $cell['count']; $index++) {
                        if (isset($cell[$index]['id']) && !array_key_exists('color', $cell[$index])) {
                            throw new \RuntimeException('tag_page_color_unavailable');
                        }
                    }
                }
            }
        }
        return $map;
    }

    /** Read the native scalar value, never displayname or the raw SQL row. */
    private function scalar(array $row, int $option): mixed
    {
        $cell = $row['PluginTagTag_' . $option] ?? null;
        if (
            !is_array($cell) || $this->id($cell['count'] ?? null) !== 1
            || !is_array($cell[0] ?? null) || !array_key_exists('name', $cell[0])
            || array_filter(array_keys($cell), static fn($key): bool => is_int($key) && $key !== 0) !== []
        ) {
            throw new \RuntimeException('tag_page_invalid');
        }
        return $cell[0]['name'];
    }

    /** @param list<int> $ids @param list<int> $columns @return list<array<string,mixed>> */
    private function query(string $type, array $ids, int $option, array $columns): array
    {
        $criteria = [];
        foreach ($ids as $id) {
            $criteria[] = ['link' => 'OR', 'field' => $option, 'searchtype' => 'equals', 'value' => (string) $id];
        }
        $params = ['criteria' => $criteria, 'metacriteria' => [], 'start' => 0,
            'list_limit' => count($ids), 'is_deleted' => 0, 'export_all' => 0,
            'sort' => [$option], 'order' => ['ASC']];
        ob_start();
        try {
            $data = ($this->search)($type, $params, $columns);
        } finally {
            $output = ob_get_clean();
        }
        $rows = $data['data']['rows'] ?? null;
        if (
            $output !== '' || !is_array($rows) || count($rows) !== count($ids)
            || $this->id($data['data']['totalcount'] ?? null) !== count($ids)
        ) {
            throw new \RuntimeException('tag_page_incomplete');
        }
        $seen = [];
        foreach ($rows as $row) {
            $id = is_array($row) ? $this->id($row['id'] ?? null) : 0;
            if ($id === 0 || !in_array($id, $ids, true) || isset($seen[$id])) {
                throw new \RuntimeException('tag_page_invalid');
            }
            $seen[$id] = true;
        }
        return array_values($rows);
    }

    private function id(mixed $value): int
    {
        return (is_int($value) || is_string($value))
            && preg_match('/\A[1-9][0-9]*\z/D', (string) $value) === 1
            && strlen((string) $value) < 16 ? (int) $value : 0;
    }
}
