<?php

declare(strict_types=1);

namespace GlpiPlugin\Glpiacessivel\Infrastructure\Tags;

use GlpiPlugin\Glpiacessivel\Application\TicketTagsGateway;
use GlpiPlugin\Glpiacessivel\Support\Url;

/** Optional Tag bridge: public Search and item ACL APIs only; never writes. */
final class GlpiTicketTagsGateway implements TicketTagsGateway
{
    private string $glpiVersion;

    /** @var array<string,\Closure> */
    private array $native;

    /** @param array<string,callable> $native Test seams around public native APIs. */
    public function __construct(?string $glpiVersion = null, array $native = [])
    {
        $this->glpiVersion = $glpiVersion ?? (defined('GLPI_VERSION') ? (string) GLPI_VERSION : '');
        $defaults = [
            'active' => static fn(): bool => is_callable(['Plugin', 'isPluginActive'])
                && (bool) call_user_func(['Plugin', 'isPluginActive'], 'tag'),
            'version' => static fn(): string => is_callable(['Plugin', 'getInfo'])
                && function_exists('plugin_version_tag')
                ? (string) call_user_func(['Plugin', 'getInfo'], 'tag', 'version') : '',
            'available' => static fn(): bool => class_exists('PluginTagTag')
                && class_exists('PluginTagTagItem') && class_exists('Ticket')
                && is_callable(['Search', 'getDatas']) && is_callable(['Search', 'getOptions']),
            'ticket_read' => static fn(int $id): bool => defined('READ') && (new \Ticket())->can($id, READ),
            'tag_view' => static fn(): bool => \PluginTagTag::canView(),
            'ticket_update' => static fn(int $id): bool => defined('UPDATE') && (new \Ticket())->can($id, UPDATE),
            'tag_update' => static fn(): bool => \PluginTagTag::canUpdate(),
            'options' => static fn(): array => class_exists('Glpi\\Search\\SearchOption')
                ? \Glpi\Search\SearchOption::getOptionsForItemtype('Ticket') : \Search::getOptions('Ticket'),
            'tag_table' => static fn(): string => \PluginTagTag::getTable(),
            'relation_table' => static fn(): string => \PluginTagTagItem::getTable(),
            'ticket_table' => static fn(): string => \Ticket::getTable(),
            'search' => static fn(array $params, array $columns): array => class_exists('Glpi\\Search\\SearchEngine')
                ? \Glpi\Search\SearchEngine::getData('Ticket', $params, $columns)
                : \Search::getDatas('Ticket', $params, $columns),
            'tag_record' => static function (int $id): ?array {
                $tag = new \PluginTagTag();
                if (!defined('READ') || !$tag->can($id, READ) || !$tag->getFromDB($id)) {
                    return null;
                }
                return $tag->fields;
            },
            'url' => static fn(int $id): string => Url::core('front/ticket.form.php?id=' . $id),
        ];
        foreach ($defaults as $key => $callback) {
            $this->native[$key] = \Closure::fromCallable($native[$key] ?? $callback);
        }
    }

    public function inspect(int $ticketId): array
    {
        $result = ['state' => 'absent', 'reason' => 'tag_absent', 'native_url' => '',
            'can_edit' => false, 'plugin_version' => ''];
        try {
            // Inactive/absent Tag must not cause autoloading or API calls.
            if (!(bool) ($this->native['active'])()) {
                return $result;
            }
            $version = ($this->native['version'])();
            $result['plugin_version'] = is_string($version) ? $version : '';
            $result['state'] = 'unsupported';
            $result['reason'] = 'tag_version_unsupported';
            if (!$this->supported($result['plugin_version']) || !(bool) ($this->native['available'])()) {
                return $result;
            }
            if (
                $ticketId < 1 || !(bool) ($this->native['ticket_read'])($ticketId)
                || !(bool) ($this->native['tag_view'])()
            ) {
                $result['state'] = 'denied';
                $result['reason'] = 'tag_forbidden';
                return $result;
            }
            $this->options();
            $result['state'] = 'ready';
            $result['reason'] = '';
            $result['native_url'] = (string) ($this->native['url'])($ticketId);
            $result['can_edit'] = (bool) ($this->native['ticket_update'])($ticketId)
                && (bool) ($this->native['tag_update'])();
            return $result;
        } catch (\Throwable) {
            $result['state'] = 'unsupported';
            $result['reason'] = 'tag_contract_unavailable';
            $result['native_url'] = '';
            $result['can_edit'] = false;
            return $result;
        }
    }

    public function read(int $ticketId): array
    {
        $capability = $this->inspect($ticketId);
        if ($capability['state'] !== 'ready') {
            throw new \RuntimeException((string) $capability['reason']);
        }
        [$idOption, $tagOption] = $this->options();
        $params = ['criteria' => [['link' => 'AND', 'field' => $idOption,
            'searchtype' => 'equals', 'value' => (string) $ticketId]],
            'metacriteria' => [], 'start' => 0, 'list_limit' => 1, 'is_deleted' => 0,
            'export_all' => 0, 'sort' => [$idOption], 'order' => ['ASC']];
        // GLPI 10 may print native search errors; never leak partial output into the ticket.
        ob_start();
        try {
            $data = ($this->native['search'])($params, [$idOption, $tagOption]);
        } finally {
            $unexpectedOutput = ob_get_clean();
        }
        if ($unexpectedOutput !== '') {
            throw new \RuntimeException('tag_response_invalid');
        }
        if (
            !is_array($data) || !is_array($data['data'] ?? null)
            || $this->positiveId($data['data']['totalcount'] ?? null) !== 1
            || !is_array($data['data']['rows'] ?? null) || count($data['data']['rows']) !== 1
        ) {
            throw new \RuntimeException('tag_response_invalid');
        }
        $row = reset($data['data']['rows']);
        if (!is_array($row) || $this->positiveId($row['id'] ?? null) !== $ticketId) {
            throw new \RuntimeException('tag_response_invalid');
        }
        $cell = $row['Ticket_' . $tagOption] ?? null;
        if (!is_array($cell) || $this->positiveId($cell['count'] ?? null) === 0) {
            throw new \RuntimeException('tag_response_invalid');
        }
        $count = (int) $cell['count'];
        if ($count < 1 || $count > 100) {
            throw new \RuntimeException('tag_response_invalid');
        }
        foreach (array_keys($cell) as $key) {
            if (is_int($key) && ($key < 0 || $key >= $count)) {
                throw new \RuntimeException('tag_response_invalid');
            }
        }
        // A null grouped name is Search's native empty relation representation.
        if (
            $count === 1 && isset($cell[0]) && is_array($cell[0])
            && array_key_exists('name', $cell[0]) && $cell[0]['name'] === null
            && !isset($cell[0]['id'])
        ) {
            return [];
        }
        $tags = [];
        for ($index = 0; $index < $count; $index++) {
            $value = $cell[$index] ?? null;
            $id = is_array($value) ? $this->positiveId($value['id'] ?? null) : 0;
            if ($id === 0 || !is_string($value['name'] ?? null) || isset($tags[$id])) {
                throw new \RuntimeException('tag_response_invalid');
            }
            $record = ($this->native['tag_record'])($id);
            if (
                !is_array($record) || $this->positiveId($record['id'] ?? null) !== $id
                || !is_string($record['name'] ?? null) || trim($record['name']) === ''
            ) {
                throw new \RuntimeException('tag_item_unavailable');
            }
            // Names and color come from the authorized record, never displayname HTML.
            $tags[$id] = ['id' => $id, 'name' => $record['name'], 'color' => $record['color'] ?? null];
        }
        return array_values($tags);
    }

    private function supported(string $tagVersion): bool
    {
        if (preg_match('/\A(?:10|11)\.[0-9]+\.[0-9]+\z/D', $this->glpiVersion) !== 1) {
            return false;
        }
        return ($tagVersion === '2.12.6' && version_compare($this->glpiVersion, '10.0.11', '>=')
            && version_compare($this->glpiVersion, '10.0.99', '<'))
            || ($tagVersion === '2.14.8' && version_compare($this->glpiVersion, '11.0.1', '>=')
            && version_compare($this->glpiVersion, '11.0.99', '<'));
    }

    /** @return array{int,int} Discover only the direct Ticket relation, never Entity tags. */
    private function options(): array
    {
        $options = ($this->native['options'])();
        if (!is_array($options)) {
            throw new \RuntimeException('tag_search_option_unavailable');
        }
        $idOptions = [];
        $tagOptions = [];
        $tagTable = (string) ($this->native['tag_table'])();
        $relationTable = (string) ($this->native['relation_table'])();
        $ticketTable = (string) ($this->native['ticket_table'])();
        foreach ($options as $key => $option) {
            if (!is_array($option) || ($id = $this->positiveId($key)) === 0) {
                continue;
            }
            if (
                ($option['table'] ?? '') === $ticketTable && ($option['field'] ?? '') === 'id'
                && empty($option['joinparams'])
            ) {
                $idOptions[] = $id;
            }
            $before = $option['joinparams']['beforejoin'] ?? null;
            if (
                ($option['table'] ?? '') === $tagTable && ($option['field'] ?? '') === 'name'
                && is_array($before) && $this->directRelation($before, $relationTable, $ticketTable)
                && empty($option['joinparams']['condition'])
            ) {
                $tagOptions[] = $id;
            }
        }
        if (count($idOptions) !== 1 || count($tagOptions) !== 1) {
            throw new \RuntimeException('tag_search_option_unavailable');
        }
        return [$idOptions[0], $tagOptions[0]];
    }

    /** @param array<string,mixed> $before The two official direct-relation forms only. */
    private function directRelation(array $before, string $relationTable, string $ticketTable): bool
    {
        $join = $before['joinparams'] ?? null;
        if (
            ($before['table'] ?? '') !== $relationTable || !is_array($join)
            || ($join['jointype'] ?? '') !== 'itemtype_item'
            || array_diff(array_keys($join), ['jointype', 'field', 'specific_itemtype', 'beforejoin']) !== []
            || (isset($join['field']) && $join['field'] !== 'items_id')
        ) {
            return false;
        }
        // Tag 2.12.6 relies on the Search main itemtype (Ticket).
        if (!isset($join['specific_itemtype']) && !isset($join['beforejoin'])) {
            return true;
        }
        // Tag 2.14.8 makes that same Ticket relation explicit. Its Entity
        // counterpart has specific_itemtype=Entity and must never match.
        return ($join['specific_itemtype'] ?? '') === 'Ticket'
            && ($join['beforejoin'] ?? null) === ['table' => $ticketTable];
    }

    private function positiveId(mixed $value): int
    {
        if (is_int($value)) {
            return $value > 0 ? $value : 0;
        }
        if (
            !is_string($value) || preg_match('/\A[1-9][0-9]*\z/D', $value) !== 1
            || strlen($value) > strlen((string) PHP_INT_MAX)
            || (strlen($value) === strlen((string) PHP_INT_MAX) && strcmp($value, (string) PHP_INT_MAX) > 0)
        ) {
            return 0;
        }
        return (int) $value;
    }
}
