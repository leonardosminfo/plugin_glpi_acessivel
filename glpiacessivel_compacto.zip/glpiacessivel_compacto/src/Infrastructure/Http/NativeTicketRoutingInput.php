<?php

declare(strict_types=1);

namespace GlpiPlugin\Glpiacessivel\Infrastructure\Http;

/** Builds the actor-only input accepted by the conventional Ticket::update(). */
final class NativeTicketRoutingInput
{
    private const FIELDS = [
        '_users_id_requester' => ['requester', 'User'],
        '_groups_id_requester' => ['requester', 'Group'],
        '_users_id_observer' => ['observer', 'User'],
        '_groups_id_observer' => ['observer', 'Group'],
        '_users_id_assign' => ['assign', 'User'],
        '_groups_id_assign' => ['assign', 'Group'],
        '_suppliers_id_assign' => ['assign', 'Supplier'],
    ];

    public static function supportsCurrentCore(): bool
    {
        return defined('GLPI_VERSION')
            && preg_match('/\A(?:10|11)\.0\.\d+(?:[-+][\w.-]+)?\z/D', (string) GLPI_VERSION) === 1;
    }

    /**
     * Input IDs have already passed the repository's role-specific authorization.
     * Keep native metadata and anonymous actors which the ID editor cannot edit.
     * Never prepareInputForUpdate() here: update() owns preparation and hooks.
     *
     * @param array<string,int[]> $fields
     * @return array<string,mixed>
     */
    public static function prepare(\Ticket $ticket, array $fields): array
    {
        if (!self::supportsCurrentCore() || !is_callable([$ticket, 'getActorsForType'])
            || !is_callable([$ticket, 'loadActors'])) {
            throw new \RuntimeException('native_routing_contract_unavailable');
        }
        $ticketId = (int) ($ticket->fields['id'] ?? 0);
        if ($ticketId <= 0) {
            throw new \RuntimeException('native_routing_actor_snapshot_invalid');
        }
        $ticket->loadActors();
        $actors = self::readActors($ticket);
        foreach ($fields as $field => $ids) {
            if (!isset(self::FIELDS[$field]) || !is_array($ids)) {
                throw new \RuntimeException('native_routing_fields_invalid');
            }
            [$role, $itemtype] = self::FIELDS[$field];
            $existing = [];
            $preserved = [];
            foreach ($actors[$role] as $actor) {
                if ($actor['itemtype'] === $itemtype && $actor['items_id'] > 0) {
                    $existing[$actor['items_id']] = $actor;
                } else {
                    $preserved[] = $actor;
                }
            }
            foreach ($ids as $id) {
                if (!is_int($id) || $id <= 0) {
                    throw new \RuntimeException('native_routing_fields_invalid');
                }
                $actor = $existing[$id] ?? ['itemtype' => $itemtype, 'items_id' => $id];
                if ($itemtype !== 'Group' && !isset($existing[$id])) {
                    // Same new-selection defaults as the native actor field;
                    // existing notification settings are never overwritten.
                    $actor['use_notification'] = 1;
                    $actor['alternative_email'] = '';
                }
                $preserved[] = $actor;
            }
            $actors[$role] = $preserved;
        }
        $payload = ['id' => $ticketId, 'update' => 1, '_actors' => $actors];
        if (str_starts_with((string) GLPI_VERSION, '11.')) {
            if (!is_callable([$ticket, 'enforceReadonlyFields'])) {
                throw new \RuntimeException('native_routing_readonly_contract_unavailable');
            }
            $payload = $ticket->enforceReadonlyFields($payload);
            if (!is_array($payload) || (int) ($payload['id'] ?? 0) !== $ticketId
                || !is_array($payload['_actors'] ?? null)) {
                throw new \RuntimeException('native_routing_readonly_input_invalid');
            }
        }
        return $payload;
    }

    /** @return array<string,array<int,array<string,mixed>>> */
    public static function readActors(\Ticket $ticket): array
    {
        $result = [];
        foreach (['requester' => 1, 'observer' => 3, 'assign' => 2] as $role => $type) {
            $rows = $ticket->getActorsForType($type);
            if (!is_array($rows)) {
                throw new \RuntimeException('native_routing_actor_snapshot_invalid');
            }
            $result[$role] = [];
            foreach ($rows as $row) {
                if (!is_array($row) || !in_array($row['itemtype'] ?? null, ['User', 'Group', 'Supplier'], true)
                    || !isset($row['items_id']) || !is_numeric($row['items_id']) || (int) $row['items_id'] < 0) {
                    throw new \RuntimeException('native_routing_actor_snapshot_invalid');
                }
                $actor = ['itemtype' => $row['itemtype'], 'items_id' => (int) $row['items_id']];
                if ($row['itemtype'] !== 'Group') {
                    if (!array_key_exists('use_notification', $row) || !array_key_exists('alternative_email', $row)
                        || !in_array($row['use_notification'], [0, 1, '0', '1', false, true], true)
                        || ($row['alternative_email'] !== null && !is_string($row['alternative_email']))) {
                        throw new \RuntimeException('native_routing_actor_metadata_unavailable');
                    }
                    $actor['use_notification'] = (int) (bool) $row['use_notification'];
                    $actor['alternative_email'] = $row['alternative_email'];
                }
                if ($actor['items_id'] === 0 && ($actor['itemtype'] !== 'User'
                    || ($actor['alternative_email'] ?? '') === '')) {
                    throw new \RuntimeException('native_routing_actor_snapshot_invalid');
                }
                $result[$role][] = $actor;
            }
        }
        return $result;
    }

    /** Canonical comparison only; never use this order as an execution order. */
    public static function fingerprint(array $actors): string
    {
        $canonical = [];
        foreach (['requester', 'observer', 'assign'] as $role) {
            $rows = $actors[$role] ?? [];
            $encoded = [];
            foreach ($rows as $row) {
                $encoded[] = json_encode($row, JSON_UNESCAPED_SLASHES | JSON_THROW_ON_ERROR);
            }
            sort($encoded, SORT_STRING);
            $canonical[$role] = $encoded;
        }
        return hash('sha256', json_encode($canonical, JSON_UNESCAPED_SLASHES | JSON_THROW_ON_ERROR));
    }
}
