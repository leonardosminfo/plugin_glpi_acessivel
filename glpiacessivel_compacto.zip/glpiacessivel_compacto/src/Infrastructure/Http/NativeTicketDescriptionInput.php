<?php

declare(strict_types=1);

namespace GlpiPlugin\Glpiacessivel\Infrastructure\Http;

use GlpiPlugin\Glpiacessivel\Domain\Ticket\NativeTicketDescriptionContractException;
use GlpiPlugin\Glpiacessivel\Security\InputSanitizer;
use GlpiPlugin\Glpiacessivel\Support\TicketPlainTextReadback;
use GlpiPlugin\Glpiacessivel\Support\RichTextToPlainText;

/** Adapter for the legacy GLPI 10 POST/model representation, not a sanitizer replacement. */
final class NativeTicketDescriptionInput
{
    public static function isGlpi10(): bool
    {
        return defined('GLPI_VERSION') && str_starts_with((string) GLPI_VERSION, '10.');
    }

    /**
     * Recover only the description's intent from the native pre-sanitization
     * snapshot. Never invert a lossy/idempotent HTML or DB-escape transform.
     * CSRF, action, ticket, revision and all other fields stay in native POST.
     *
     * @param array<string,mixed> $post
     */
    public static function readGlpi10(array $post, mixed $unprocessedPost): string
    {
        self::requireLegacyContract();
        if (
            !is_array($unprocessedPost)
            || array_key_exists('_glpi_simple_form', $post)
            || array_key_exists('_glpi_simple_form', $unprocessedPost)
            || !is_string($post['content'] ?? null)
            || !is_string($unprocessedPost['content'] ?? null)
        ) {
            throw new NativeTicketDescriptionContractException('native_content_origin_unavailable');
        }

        $original = $unprocessedPost['content'];
        if (
            strlen($original) > TicketPlainTextReadback::MAX_INPUT_BYTES
            || preg_match('//u', $original) !== 1
            || preg_match('/[\x00-\x08\x0B\x0C\x0E-\x1F]/', $original) === 1
        ) {
            throw new NativeTicketDescriptionContractException('native_content_origin_invalid');
        }

        try {
            $processed = \Glpi\Toolbox\Sanitizer::sanitize($original);
        } catch (\Throwable $exception) {
            throw new NativeTicketDescriptionContractException('native_content_origin_unavailable', 0, $exception);
        }
        if (!is_string($processed) || $processed !== $post['content']) {
            // A missing/different snapshot or a later hook must not be bypassed.
            throw new NativeTicketDescriptionContractException('native_content_origin_mismatch');
        }
        if (strip_tags($original) !== $original) {
            throw new NativeTicketDescriptionContractException('native_content_not_plain_text');
        }

        if (mb_strlen(trim($original), 'UTF-8') > 16000) {
            throw new NativeTicketDescriptionContractException('native_content_text_budget_exceeded');
        }
        $intent = (new InputSanitizer())->text($original, 16000);
        if (strlen($intent) > RichTextToPlainText::MAX_OUTPUT_BYTES) {
            throw new NativeTicketDescriptionContractException('native_content_text_budget_exceeded');
        }
        return $intent;
    }

    /** Prepare already serialized, inert HTML for the public legacy Ticket model. */
    public static function forNativeUpdate(string $html): string
    {
        if (!self::isGlpi10()) {
            return $html;
        }
        self::requireLegacyContract();
        if (strlen($html) > TicketPlainTextReadback::MAX_INPUT_BYTES) {
            throw new NativeTicketDescriptionContractException('native_content_html_budget_exceeded');
        }
        try {
            // dbEscape is idempotent. Do not guess whether a literal backslash
            // sequence is already escaped, force an inverse, or add a sentinel.
            if (str_contains($html, '\\') && \Glpi\Toolbox\Sanitizer::isDbEscaped($html)) {
                throw new NativeTicketDescriptionContractException('native_content_escape_ambiguous');
            }
            $prepared = \Glpi\Toolbox\Sanitizer::dbEscape($html);
        } catch (NativeTicketDescriptionContractException $exception) {
            throw $exception;
        } catch (\Throwable $exception) {
            throw new NativeTicketDescriptionContractException('native_content_escape_unavailable', 0, $exception);
        }
        return $prepared;
    }

    private static function requireLegacyContract(): void
    {
        if (
            !defined('GLPI_VERSION')
            || preg_match('/\A10\.0\.\d+(?:[-+][\w.-]+)?\z/D', (string) GLPI_VERSION) !== 1
            || !is_callable(['Glpi\\Toolbox\\Sanitizer', 'sanitize'])
            || !is_callable(['Glpi\\Toolbox\\Sanitizer', 'dbEscape'])
            || !is_callable(['Glpi\\Toolbox\\Sanitizer', 'isDbEscaped'])
        ) {
            throw new NativeTicketDescriptionContractException('native_content_contract_unavailable');
        }
    }
}
