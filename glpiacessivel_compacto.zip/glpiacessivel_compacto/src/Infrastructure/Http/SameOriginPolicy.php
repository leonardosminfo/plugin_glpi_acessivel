<?php

declare(strict_types=1);

namespace GlpiPlugin\Glpiacessivel\Infrastructure\Http;

/**
 * Validates browser origins against the server's effective request origin.
 *
 * The web server must reliably normalize HTTP_HOST and HTTPS behind a proxy.
 * Forwarded headers are deliberately not trusted or interpreted here. This
 * policy has no dependency on a version-specific GLPI or Symfony request API.
 */
final class SameOriginPolicy
{
    /**
     * @param array<string,mixed> $server
     * @return array{allowed:bool,reason:string}
     */
    public function evaluate(array $server): array
    {
        $fetchSite = $this->header($server, 'HTTP_SEC_FETCH_SITE');
        if ($fetchSite === null) {
            return $this->decision(false, 'fetch_site_invalid');
        }
        $fetchSite = strtolower($fetchSite);
        if ($fetchSite !== '' && !in_array($fetchSite, ['same-origin', 'none'], true)) {
            return $this->decision(false, 'fetch_site_not_allowed');
        }

        $host = $this->header($server, 'HTTP_HOST');
        $https = $server['HTTPS'] ?? '';
        if ($host === null || !is_scalar($https)) {
            return $this->decision(false, 'request_origin_invalid');
        }
        $scheme = !empty($https) && strtolower((string) $https) !== 'off' ? 'https' : 'http';
        $request = $this->normalize($scheme . '://' . $host);
        if ($request === null) {
            return $this->decision(false, 'request_origin_invalid');
        }

        $origin = $this->header($server, 'HTTP_ORIGIN');
        if ($origin === null) {
            return $this->decision(false, 'origin_invalid');
        }
        if ($origin === '') {
            // Older clients can omit Origin and Fetch Metadata. The endpoints
            // still enforce session, CSRF, method and authorization separately.
            return $this->decision(true, 'origin_absent');
        }
        $normalizedOrigin = $this->normalize($origin);
        if ($normalizedOrigin === null) {
            return $this->decision(false, 'origin_invalid');
        }

        return $normalizedOrigin === $request
            ? $this->decision(true, 'same_origin')
            : $this->decision(false, 'origin_mismatch');
    }

    /** @param array<string,mixed> $server */
    private function header(array $server, string $key): ?string
    {
        $value = $server[$key] ?? '';
        if (!is_string($value) || preg_match('/[\x00-\x1F\x7F]/', $value) === 1) {
            return null;
        }
        return trim($value);
    }

    /** @return array{scheme:string,host:string,port:int}|null */
    private function normalize(string $origin): ?array
    {
        // An Origin is a single serialized scheme/host/port, not a full URL.
        if (
            preg_match(
                '/\A(https?):\/\/(\[[0-9a-f:.]+\]|[a-z0-9.-]+)(?::([0-9]{1,5}))?\z/iD',
                $origin,
                $matches
            ) !== 1
        ) {
            return null;
        }
        $scheme = strtolower($matches[1]);
        $host = strtolower($matches[2]);
        if ($host[0] === '[') {
            $address = substr($host, 1, -1);
            if (filter_var($address, FILTER_VALIDATE_IP, FILTER_FLAG_IPV6) === false) {
                return null;
            }
            $packed = inet_pton($address);
            if ($packed === false) {
                return null;
            }
            $host = '[' . inet_ntop($packed) . ']';
        } elseif (
            strlen($host) > 253
            || preg_match('/\A[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?(?:\.[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?)*\.?\z/D', $host) !== 1
        ) {
            return null;
        }
        $port = isset($matches[3]) ? (int) $matches[3] : ($scheme === 'https' ? 443 : 80);
        if ($port < 1 || $port > 65535) {
            return null;
        }
        return ['scheme' => $scheme, 'host' => $host, 'port' => $port];
    }

    /** @return array{allowed:bool,reason:string} */
    private function decision(bool $allowed, string $reason): array
    {
        return ['allowed' => $allowed, 'reason' => $reason];
    }
}
