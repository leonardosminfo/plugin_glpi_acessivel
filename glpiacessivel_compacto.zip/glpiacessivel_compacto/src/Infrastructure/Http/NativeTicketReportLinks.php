<?php

declare(strict_types=1);

namespace GlpiPlugin\Glpiacessivel\Infrastructure\Http;

/** Read-only access to existing native reports; never computes report data. */
final class NativeTicketReportLinks
{
    private string $runtimeVersion;

    public function __construct(?string $runtimeVersion = null)
    {
        $this->runtimeVersion = $runtimeVersion
            ?? (defined('GLPI_VERSION') ? (string) constant('GLPI_VERSION') : '');
    }

    /**
     * The public report.dynamic.php route does not accept the forced-display
     * argument used by Search::showList() on GLPI 10. It instead uses saved
     * display preferences, which may differ from the portal's applied columns.
     * Do not manufacture an export link, alter preferences or silently drop
     * columns. GLPI 11 alone is not proof of a shared supported contract.
     *
     * Formats describe the examined native generations, not an enabled export.
     * @return array{available:bool,reason:string,url:string,formats:string[]}
     */
    public function faithfulExportAvailability(): array
    {
        $major = $this->runtimeMajor();
        if ($major === 0) {
            return [
                'available' => false,
                'reason' => 'native_report_runtime_unsupported',
                'url' => '',
                'formats' => [],
            ];
        }

        return [
            'available' => false,
            'reason' => 'native_export_columns_contract_unavailable',
            'url' => '',
            'formats' => $major === 10 ? ['pdf', 'csv', 'sylk'] : ['pdf', 'csv', 'ods', 'xlsx'],
        ];
    }

    /**
     * Native reports use the profile/entity context at navigation time and
     * reauthorize statistic/READ themselves. No portal search, entity override
     * or new counter is added. Dates omitted together retain native defaults.
     * These are period statistics, not a claim about the current open queue.
     *
     * @return array{available:bool,reason:string,links:array<string,string>}
     */
    public function technicianStatisticsLinks(?string $dateFrom = null, ?string $dateTo = null): array
    {
        $major = $this->runtimeMajor();
        if ($major === 0) {
            return $this->unavailableStatistics('native_report_runtime_unsupported');
        }
        if (!$this->canReadStatistics()) {
            return $this->unavailableStatistics('native_statistics_forbidden');
        }
        if (
            ($dateFrom === null) !== ($dateTo === null)
            || ($dateFrom !== null && (
                !$this->validDate($dateFrom)
                || !$this->validDate((string) $dateTo)
                || $dateFrom > $dateTo
            ))
        ) {
            return $this->unavailableStatistics('native_statistics_period_invalid');
        }

        global $CFG_GLPI;
        $route = rtrim((string) ($CFG_GLPI['root_doc'] ?? ''), '/') . '/front/stat.tracking.php';
        $parameters = ['itemtype' => 'Ticket', 'showgraph' => 0, 'start' => 0];
        if ($dateFrom !== null) {
            $parameters['date1'] = $dateFrom;
            $parameters['date2'] = $dateTo;
        }
        $links = [];
        foreach (['assigned', 'tasks'] as $role) {
            $nativeType = $this->nativeTypeForMode($role);
            $links[$role] = $route . '?' . http_build_query(
                $parameters + ['type' => $nativeType],
                '',
                '&',
                PHP_QUERY_RFC3986
            );
        }

        return ['available' => true, 'reason' => '', 'links' => $links];
    }

    /** One allowlisted native dimension mapping shared by report links and the data adapter. */
    public function nativeTypeForMode(string $mode): ?string
    {
        $major = $this->runtimeMajor();
        if ($major === 0 || !in_array($mode, ['assigned', 'tasks'], true)) {
            return null;
        }
        $type = $major === 10 ? 'technicien' : 'technician';
        return $mode === 'tasks' ? $type . '_followup' : $type;
    }

    private function canReadStatistics(): bool
    {
        if (
            !class_exists('\\Session')
            || !is_callable(['\\Session', 'getLoginUserID'])
            || !is_callable(['\\Session', 'haveRight'])
            || !defined('READ')
        ) {
            return false;
        }
        try {
            return (int) \Session::getLoginUserID() > 0
                && (bool) \Session::haveRight('statistic', READ);
        } catch (\Throwable) {
            return false;
        }
    }

    private function runtimeMajor(): int
    {
        if (preg_match('/\A(10|11)\.\d+\.\d+(?:[-+][a-zA-Z0-9.-]+)?\z/D', $this->runtimeVersion, $matches) !== 1) {
            return 0;
        }
        return (int) $matches[1];
    }

    private function validDate(string $value): bool
    {
        if (preg_match('/\A\d{4}-\d{2}-\d{2}\z/D', $value) !== 1) {
            return false;
        }
        $date = \DateTimeImmutable::createFromFormat('!Y-m-d', $value);
        return $date !== false && $date->format('Y-m-d') === $value;
    }

    /** @return array{available:bool,reason:string,links:array<string,string>} */
    private function unavailableStatistics(string $reason): array
    {
        return ['available' => false, 'reason' => $reason, 'links' => []];
    }
}
