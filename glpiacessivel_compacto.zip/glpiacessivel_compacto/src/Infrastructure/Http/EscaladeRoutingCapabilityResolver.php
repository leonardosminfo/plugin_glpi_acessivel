<?php

declare(strict_types=1);

namespace GlpiPlugin\Glpiacessivel\Infrastructure\Http;

/** Read-only, versioned contract. It never implements an Escalade business rule. */
final class EscaladeRoutingCapabilityResolver
{
    /** @return array{mode:string,revision:string,reason:string,adjustment_possible:bool} */
    public static function resolve(int $ticketId): array
    {
        $context = [
            'contract' => 'native-ticket-actors-v1',
            'core' => defined('GLPI_VERSION') ? (string) GLPI_VERSION : '',
            'ticket' => $ticketId,
            'user' => (int) ($_SESSION['glpiID'] ?? 0),
            'profile' => (int) ($_SESSION['glpiactiveprofile']['id'] ?? 0),
            'entity' => $_SESSION['glpiactive_entity'] ?? null,
            'entities' => $_SESSION['glpiactiveentities'] ?? [],
            'recursive' => $_SESSION['glpiactive_entity_recursive'] ?? null,
        ];
        $result = static function (string $mode, string $reason, bool $adjustment, array $state = []) use ($context): array {
            return [
                'mode' => $mode,
                'revision' => hash('sha256', (string) json_encode([$context, $state, $mode, $reason], JSON_UNESCAPED_SLASHES)),
                'reason' => $reason,
                'adjustment_possible' => $adjustment,
            ];
        };
        if (!NativeTicketRoutingInput::supportsCurrentCore()) {
            return $result('continuation', 'core_contract_unavailable', false);
        }
        try {
            if (!is_callable(['Plugin', 'isPluginActive'])) {
                return $result('continuation', 'extension_activity_unavailable', false);
            }
            if (!\Plugin::isPluginActive('escalade')) {
                return $result('native', 'extension_inactive', false, ['active' => false]);
            }
            if (!is_callable(['Plugin', 'getInfo'])) {
                return $result('continuation', 'extension_version_unavailable', false);
            }
            $version = (string) \Plugin::getInfo('escalade', 'version');
            $supported = str_starts_with((string) GLPI_VERSION, '10.') ? '2.9.4' : '2.10.8';
            if ($version !== $supported || !class_exists('PluginEscaladeConfig')) {
                return $result('continuation', 'extension_contract_unavailable', false, ['version' => $version]);
            }
            $model = new \PluginEscaladeConfig();
            if (!$model->getFromDB(1) || !is_array($model->fields ?? null)) {
                return $result('continuation', 'extension_config_unavailable', false, ['version' => $version]);
            }
            $effective = $version === '2.9.4'
                ? ($_SESSION['plugins']['escalade']['config'] ?? null)
                : ($_SESSION['glpi_plugins']['escalade']['config'] ?? null);
            if (!is_array($effective)) {
                return $result('continuation', 'extension_effective_config_unavailable', false, ['version' => $version]);
            }
            $record = $model->fields;
            unset($record['id'], $effective['id']);
            foreach (['remove_group', 'remove_tech', 'remove_requester', 'show_history', 'task_history'] as $flag) {
                foreach ([$record, $effective] as $source) {
                    if (!array_key_exists($flag, $source)
                        || !in_array($source[$flag], [0, 1, '0', '1', false, true], true)) {
                        return $result('continuation', 'extension_config_invalid', false, ['version' => $version]);
                    }
                }
                if ((bool) $record[$flag] !== (bool) $effective[$flag]) {
                    return $result('continuation', 'extension_config_changed', false, ['version' => $version]);
                }
            }
            $statusDomain = self::nativeStatusDomain($version);
            if ($statusDomain === null) {
                return $result('continuation', 'extension_status_contract_unavailable', false, ['version' => $version]);
            }
            foreach ([$record, $effective] as $source) {
                $status = $source['ticket_last_status'] ?? null;
                if (!is_int($status) && !(is_string($status) && preg_match('/\A-?\d+\z/D', $status) === 1)) {
                    return $result('continuation', 'extension_config_invalid', false, ['version' => $version]);
                }
                if (!in_array((int) $status, $statusDomain, true)) {
                    return $result('continuation', 'extension_config_invalid', false, ['version' => $version]);
                }
            }
            if ((int) $record['ticket_last_status'] !== (int) $effective['ticket_last_status']) {
                return $result('continuation', 'extension_config_changed', false, ['version' => $version]);
            }
            $globalComparison = $record;
            $effectiveComparison = $effective;
            unset($globalComparison['use_filter_assign_group'], $effectiveComparison['use_filter_assign_group']);
            foreach (['remove_group', 'remove_tech', 'remove_requester', 'show_history', 'task_history'] as $flag) {
                $globalComparison[$flag] = (int) (bool) $globalComparison[$flag];
                $effectiveComparison[$flag] = (int) (bool) $effectiveComparison[$flag];
            }
            $globalComparison['ticket_last_status'] = (int) $globalComparison['ticket_last_status'];
            $effectiveComparison['ticket_last_status'] = (int) $effectiveComparison['ticket_last_status'];
            foreach ([$globalComparison, $effectiveComparison] as $source) {
                foreach ($source as $value) {
                    if ($value !== null && !is_scalar($value)) {
                        return $result('continuation', 'extension_config_invalid', false, ['version' => $version]);
                    }
                }
            }
            ksort($globalComparison);
            ksort($effectiveComparison);
            if (array_map('strval', $globalComparison) !== array_map('strval', $effectiveComparison)) {
                return $result('continuation', 'extension_config_changed', false, ['version' => $version]);
            }
            // The supplier can legitimately apply a user bypass to this filter.
            // Preserve it in the revision, but never reconstruct that decision.
            ksort($record);
            ksort($effective);
            $adjustmentPossible = (bool) $effective['remove_group'] || (bool) $effective['remove_tech']
                || (bool) $effective['remove_requester'];
            return $result('native', 'extension_native_hooks', $adjustmentPossible, [
                'version' => $version, 'record' => $record, 'effective' => $effective,
            ]);
        } catch (\Throwable) {
            return $result('continuation', 'extension_contract_unavailable', false);
        }
    }

    /**
     * Validate the supplier's actual configuration options, not a copied status
     * list. Escalade 2.10.8 reindexes its choices; never reinterpret those keys
     * as Ticket status IDs or change the value passed to its own hooks.
     *
     * @return int[]|null
     */
    private static function nativeStatusDomain(string $version): ?array
    {
        if ($version === '2.10.8') {
            if (!is_callable(['PluginEscaladeConfig', 'getGenericStatus'])) {
                return null;
            }
            $choices = \PluginEscaladeConfig::getGenericStatus('Ticket');
        } elseif ($version === '2.9.4') {
            // This version exposes only an HTML dropdown for the supplier
            // options. Its tested GLPI 10 contract uses the public native
            // status keys and the supplier's documented -1 sentinel.
            if (!is_callable(['Ticket', 'getAllStatusArray'])) {
                return null;
            }
            $choices = \Ticket::getAllStatusArray(false);
        } else {
            return null;
        }
        if (!is_array($choices) || $choices === []) {
            return null;
        }
        if ($version === '2.9.4' && array_keys($choices) !== range(1, count($choices))) {
            // The old supplier's display-only API numbers its options. Native
            // keys are equivalent only in the examined contiguous contract;
            // do not guess a remapping if another core/extension changes it.
            return null;
        }
        $domain = [];
        foreach (array_keys($choices) as $key) {
            if (!is_int($key) || ($key !== -1 && $key <= 0)) {
                return null;
            }
            $domain[] = $key;
        }
        if ($version === '2.9.4') {
            $domain[] = -1;
        }
        return array_values(array_unique($domain));
    }
}
