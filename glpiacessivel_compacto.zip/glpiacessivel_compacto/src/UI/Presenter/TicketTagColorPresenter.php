<?php

declare(strict_types=1);

namespace GlpiPlugin\Glpiacessivel\UI\Presenter;

/**
 * Projects a native Tag colour without changing its stored value or meaning.
 *
 * Only opaque CSS hexadecimal #RGB and #RRGGBB values are supported. Names,
 * alpha channels, CSS functions and surrounding whitespace are not accepted.
 * The returned colours are safe CSS values; templates must still escape them.
 */
final class TicketTagColorPresenter
{
    /**
     * @return array{
     *   state: 'native'|'neutral',
     *   reason: ''|'missing_color'|'invalid_color',
     *   native_color: ?string,
     *   background_color: string,
     *   text_color: string,
     *   contrast_ratio: float
     * }
     */
    public function present(mixed $nativeColor): array
    {
        if ($nativeColor === null || $nativeColor === '') {
            return $this->neutral('missing_color');
        }

        if (!is_string($nativeColor) || preg_match('/\A#(?:[0-9a-fA-F]{3}|[0-9a-fA-F]{6})\z/D', $nativeColor) !== 1) {
            return $this->neutral('invalid_color');
        }

        $background = strtoupper($nativeColor);
        if (strlen($background) === 4) {
            $background = '#' . $background[1] . $background[1]
                . $background[2] . $background[2] . $background[3] . $background[3];
        }

        $luminance = 0.2126 * $this->linearChannel(substr($background, 1, 2))
            + 0.7152 * $this->linearChannel(substr($background, 3, 2))
            + 0.0722 * $this->linearChannel(substr($background, 5, 2));
        $blackContrast = ($luminance + 0.05) / 0.05;
        $whiteContrast = 1.05 / ($luminance + 0.05);
        $useBlack = $blackContrast >= $whiteContrast;

        // With an opaque sRGB background, the better of black/white always
        // exceeds 4.5:1. No rounded ratio is used to make that choice.
        return [
            'state' => 'native',
            'reason' => '',
            'native_color' => $nativeColor,
            'background_color' => $background,
            'text_color' => $useBlack ? '#000000' : '#FFFFFF',
            'contrast_ratio' => $useBlack ? $blackContrast : $whiteContrast,
        ];
    }

    private function linearChannel(string $hex): float
    {
        $channel = hexdec($hex) / 255;

        return $channel <= 0.04045 ? $channel / 12.92 : (($channel + 0.055) / 1.055) ** 2.4;
    }

    /**
     * @param 'missing_color'|'invalid_color' $reason
     * @return array{
     *   state: 'neutral', reason: 'missing_color'|'invalid_color', native_color: null,
     *   background_color: string, text_color: string, contrast_ratio: float
     * }
     */
    private function neutral(string $reason): array
    {
        return [
            'state' => 'neutral',
            'reason' => $reason,
            'native_color' => null,
            'background_color' => '#FFFFFF',
            'text_color' => '#000000',
            'contrast_ratio' => 21.0,
        ];
    }
}
