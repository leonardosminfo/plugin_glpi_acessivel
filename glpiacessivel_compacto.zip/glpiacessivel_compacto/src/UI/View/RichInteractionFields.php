<?php

declare(strict_types=1);

namespace GlpiPlugin\Glpiacessivel\UI\View;

/**
 * The plugin owns the form. GLPI supplies only its editor and temporary uploader.
 * Authorization, CSRF, item identity and final document links belong to the caller.
 */
final class RichInteractionFields
{
    private \Closure $textarea;
    private string $version;
    private bool $injectedHelper;

    /** Public seam for tests; production always calls the installed public helper. */
    public function __construct(?callable $textarea = null, ?string $version = null)
    {
        $this->injectedHelper = $textarea !== null;
        $this->textarea = \Closure::fromCallable($textarea ?? static function (array $options): mixed {
            $helper = ['Html', 'textarea'];
            if (!is_callable($helper)) {
                throw new \RuntimeException('interaction_rich_editor_unavailable');
            }
            return $helper($options);
        });
        $this->version = $version ?? (defined('GLPI_VERSION') ? (string) GLPI_VERSION : '');
    }

    public function available(): bool
    {
        return version_compare($this->version, '10.0.0', '>=')
            && version_compare($this->version, '12.0.0', '<')
            && ($this->injectedHelper || (
                is_callable(['Html', 'textarea'])
                && is_callable(['Html', 'initEditorSystem'])
                && is_callable(['Html', 'file'])
            ));
    }

    /**
     * $content is canonical HTML, not HTML escaped for textarea or DB storage.
     * $editorId is a server-owned identifier; never pass an identifier from POST.
     * Disabling the visible uploader is not an ACL: the caller must authorize
     * all supplied temporary documents before the final native object update.
     * $uploads contains already-authorized native temporary metadata only.
     * This renderer checks its presentation shape, never filesystem access.
     * @param array<string,mixed> $uploads
     */
    public function render(
        string $content,
        string $editorId,
        bool $allowUploads = true,
        bool $required = false,
        array $uploads = []
    ): string {
        if (!$this->available()) {
            throw new \RuntimeException('interaction_rich_editor_unavailable');
        }
        if (preg_match('/\A[a-zA-Z][a-zA-Z0-9_-]{0,79}\z/D', $editorId) !== 1) {
            throw new \InvalidArgumentException('interaction_rich_editor_id_invalid');
        }
        $uploads = $this->restorationUploads($uploads);

        $rand = random_int(100000, 2147483647);
        // GLPI 10's Html::textarea concatenates value directly into its markup;
        // GLPI 11 escapes it internally. Escape once for each installed contract.
        $value = version_compare($this->version, '11.0.0', '<')
            ? htmlspecialchars($content, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8')
            : $content;
        $options = [
            'name' => 'content',
            'editor_id' => $editorId,
            'rand' => $rand,
            'filecontainer' => 'glpiacessivel-files-' . $editorId,
            'dropZone' => 'glpiacessivel-drop-' . $editorId,
            'value' => $value,
            'enable_richtext' => true,
            // Existing inline images must never become invalid elements merely
            // because the visible file picker is unavailable in this context.
            'enable_images' => true,
            'enable_fileupload' => $allowUploads,
            'multiple' => true,
            // Html::textarea passes this flag to Html::file as well. Requiring
            // content here would accidentally require an attachment, including
            // the hidden pasted-image input. The own-form label and native
            // object validation enforce content without requiring a document.
            'required' => false,
            'rows' => 8,
            'display' => false,
            'uploads' => $uploads,
        ];

        $level = ob_get_level();
        ob_start();
        try {
            $markup = ($this->textarea)($options);
            // Do not leak partially echoed helper output, fall back to another
            // complete form, or extract fields from native showForm() markup.
            if (!is_string($markup) || $markup === '' || (string) ob_get_contents() !== '') {
                throw new \RuntimeException('interaction_rich_editor_invalid_fragment');
            }
            if (preg_match('/<\s*\/?\s*(?:form|html|head|body)\b/i', $markup) === 1) {
                throw new \RuntimeException('interaction_rich_editor_invalid_fragment');
            }
            $escape = static fn(string $value): string => htmlspecialchars($value, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
            $controls = '<div hidden data-glpiacessivel-rich-size="' . $editorId . '" role="group" aria-label="'
                . $escape(__('Ajustar altura do campo', 'glpiacessivel')) . '"'
                . ' data-msg-expanded="' . $escape(__('Área de edição ampliada.', 'glpiacessivel')) . '"'
                . ' data-msg-restored="' . $escape(__('Altura padrão restaurada.', 'glpiacessivel')) . '"'
                . ' data-msg-limit="' . $escape(__('O campo já está na altura máxima para esta janela.', 'glpiacessivel')) . '">'
                . '<div class="glpiacessivel-rich-size-actions">'
                . '<button type="button" class="glpiacessivel-button glpiacessivel-button-secondary" data-rich-size-grow aria-controls="' . $editorId . '">'
                . $escape(__('Ampliar campo', 'glpiacessivel')) . '</button> '
                . '<button type="button" class="glpiacessivel-button glpiacessivel-button-secondary" data-rich-size-reset aria-controls="' . $editorId . '">'
                . $escape(__('Restaurar altura padrão', 'glpiacessivel')) . '</button></div>'
                . '<p class="glpiacessivel-help-text">' . $escape(__('Ajustar a altura não altera nem envia o texto.', 'glpiacessivel')) . '</p>'
                . '<p data-rich-size-status role="status" aria-live="polite" aria-atomic="true"></p></div>';
            return $controls . $markup;
        } finally {
            while (ob_get_level() > $level) {
                ob_end_clean();
            }
        }
    }

    /**
     * Whitelist the three parallel arrays, without copying draft content or
     * operation markers into native helper options. Authorization stays with
     * the caller. Unsafe legacy helper representations must be reselected,
     * not rewritten into a different temporary filename or image marker.
     * @param array<string,mixed> $input
     * @return array<string,array<int|string,string>>
     */
    private function restorationUploads(array $input): array
    {
        $keys = ['_filename', '_tag_filename', '_prefix_filename'];
        $uploads = array_intersect_key($input, array_flip($keys));
        if ($uploads === []) {
            return [];
        }
        foreach ($keys as $key) {
            if (!isset($uploads[$key]) || !is_array($uploads[$key]) || count($uploads[$key]) > 20) {
                throw new \InvalidArgumentException('interaction_upload_projection_invalid');
            }
        }
        $indexes = array_keys($uploads['_filename']);
        if ($indexes !== array_keys($uploads['_tag_filename']) || $indexes !== array_keys($uploads['_prefix_filename'])) {
            throw new \InvalidArgumentException('interaction_upload_projection_invalid');
        }
        foreach ($uploads['_filename'] as $index => $filename) {
            $prefix = $uploads['_prefix_filename'][$index];
            $tag = $uploads['_tag_filename'][$index];
            if (!is_string($filename) || !is_string($prefix) || !is_string($tag)
                || $filename === '' || strlen($filename) > 255 || $prefix === '' || strlen($prefix) > 128
                || strlen($tag) > 255 || !str_starts_with($filename, $prefix)
                || strpbrk($filename . $prefix . $tag, "/\\\0\r\n") !== false
                || (version_compare($this->version, '11.0.0', '<')
                    && strpbrk($filename . $prefix . $tag . (string) $index, "<>&\"'") !== false)) {
                throw new \InvalidArgumentException('interaction_upload_projection_invalid');
            }
        }
        return $uploads;
    }
}
