<?php

declare(strict_types=1);

namespace GlpiPlugin\Glpiacessivel\UI\View;

/** Native asset lifecycle without rendering GLPI menus or replacing portal markup. */
final class NativeInteractionAssets
{
    /**
     * $pluginHeadMarkup is trusted, server-built head markup, never request HTML.
     * The caller keeps its existing body/shell and closes it with Html::popFooter().
     */
    public static function header(string $title, string $pluginHeadMarkup): string
    {
        if (preg_match('/<\/?(?:html|head|body)\b/i', $pluginHeadMarkup) || str_contains($pluginHeadMarkup, "\0")) {
            throw new \RuntimeException('native_interaction_assets_invalid_plugin_head');
        }

        $head = self::captureHeader($title);
        // captureHeader validates this unique boundary; no native forms are parsed.
        return (string) preg_replace_callback(
            '/<\/head\s*>/i',
            static fn(array $match): string => $pluginHeadMarkup . "\n" . $match[0],
            $head,
            1
        );
    }

    public static function captureHeader(string $title): string
    {
        $version = defined('GLPI_VERSION') ? (string) GLPI_VERSION : '';
        if (
            version_compare($version, '10.0.0', '<') || version_compare($version, '12.0.0', '>=')
            || !is_callable(['Html', 'includeHeader']) || !is_callable(['Html', 'popFooter'])
        ) {
            throw new \RuntimeException('native_interaction_assets_unavailable');
        }

        $level = ob_get_level();
        // GLPI 10 includeHeader() calls glpi_flush()/ob_flush(). The outer buffer
        // retains that flush while the inner buffer remains owned by the core.
        ob_start();
        ob_start();
        try {
            // Preserve native SAMEORIGIN/no-cache headers and the normal ITIL
            // dependency registration. Never use zeroSecurityIframedHeader().
            \Html::includeHeader($title, 'helpdesk', 'ticket', '', false, false);
            $head = '';
            while (ob_get_level() > $level) {
                $head = (string) ob_get_clean() . $head;
            }

            if (
                strlen($head) > 2097152
                || preg_match_all('/<head\b[^>]*>/i', $head) !== 1
                || preg_match_all('/<\/head\s*>/i', $head) !== 1
                || preg_match('/<\/?body\b/i', $head)
            ) {
                throw new \RuntimeException('native_interaction_assets_invalid_header');
            }
            return $head;
        } finally {
            // Do not expose a partially generated head after a native exception.
            while (ob_get_level() > $level) {
                ob_end_clean();
            }
        }
    }
}
