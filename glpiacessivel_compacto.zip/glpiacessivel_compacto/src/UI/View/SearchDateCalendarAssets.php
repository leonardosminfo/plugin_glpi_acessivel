<?php

declare(strict_types=1);

namespace GlpiPlugin\Glpiacessivel\UI\View;

/** Selective core calendar assets, never the native page/form or its global CSS. */
final class SearchDateCalendarAssets
{
    /** Matches Html::requireJs('flatpickr') in each supported core generation. */
    public static function assetPrefix(): string
    {
        return defined('GLPI_VERSION') && version_compare((string) GLPI_VERSION, '11.0.0', '<') ? 'public/' : '';
    }
    /** @return array{format:string,locale:string} */
    public static function configuration(): array
    {
        global $CFG_GLPI;
        $format = is_callable(['Toolbox', 'getDateFormat']) ? (string) \Toolbox::getDateFormat('js') : 'Y-m-d';
        if (!in_array($format, ['Y-m-d', 'd-m-Y', 'm-d-Y', 'd/m/Y', 'm/d/Y', 'Y/m/d'], true)) {
            $format = 'Y-m-d';
        }
        $language = (string) ($_SESSION['glpilanguage'] ?? '');
        $locale = strtolower((string) ($CFG_GLPI['languages'][$language][3] ?? ''));
        if (preg_match('/\A[a-z]{2}(?:-[a-z]{2})?\z/D', $locale) !== 1) {
            $locale = '';
        }
        return ['format' => $format, 'locale' => $locale];
    }

    public static function markup(): string
    {
        if (!defined('GLPI_ROOT') || !defined('GLPI_VERSION')
            || version_compare((string) GLPI_VERSION, '10.0.0', '<')
            || version_compare((string) GLPI_VERSION, '12.0.0', '>=')
            || !is_callable(['Html', 'script']) || !is_callable(['Html', 'css'])) {
            return '';
        }
        $root = (string) GLPI_ROOT . '/public/';
        if (!is_file($root . 'lib/flatpickr.js') || !is_file($root . 'lib/flatpickr.css')) {
            return '';
        }
        $prefix = self::assetPrefix();
        $markup = \Html::css($prefix . 'lib/flatpickr.css') . "\n" . \Html::script($prefix . 'lib/flatpickr.js');
        $locale = self::configuration()['locale'];
        if ($locale !== '' && is_file($root . 'lib/flatpickr/l10n/' . $locale . '.js')) {
            $markup .= "\n" . \Html::script($prefix . 'lib/flatpickr/l10n/' . $locale . '.js');
        }
        return $markup;
    }
}
