<?php

declare(strict_types=1);

namespace GlpiPlugin\Glpiacessivel\UI\View;

final class View
{
    public static function render(string $template, array $data = []): void
    {
        $templatePath = __DIR__ . '/../../../templates/' . $template . '.php';
        if (!is_file($templatePath)) {
            throw new \RuntimeException('Template não encontrado: ' . $template);
        }

        self::sendNoStoreHeaders();

        extract($data, EXTR_SKIP);
        // A native interaction form needs the installed core's complete asset
        // lifecycle. This internal render value cannot be supplied by request.
        $nativeInteraction = self::usesNativeInteractionLayout($template, $data);
        $glpiacessivelStandaloneLayout = self::shouldUseStandaloneLayout($template);
        require __DIR__ . '/../../../templates/layout/header.php';
        require $templatePath;
        require __DIR__ . '/../../../templates/layout/footer.php';
    }

    /** Internal renderer outputs only, never an arbitrary template/request flag. */
    private static function usesNativeInteractionLayout(string $template, array $data): bool
    {
        if (
            ($template === 'tickets/interaction-edit' || $template === 'tickets/interaction-create')
            && is_string($data['native_interaction_form'] ?? null)
            && $data['native_interaction_form'] !== ''
        ) {
            return true;
        }
        if ($template === 'tickets/detail' && is_array($data['native_creation_forms'] ?? null)) {
            foreach (['followup', 'task'] as $kind) {
                $form = $data['native_creation_forms'][$kind] ?? null;
                if (is_string($form) && trim($form) !== '') {
                    return true;
                }
            }
        }
        if (!in_array($template, ['tickets/attachments', 'tickets/interaction-edit'], true)) {
            return false;
        }
        $actions = $data['native_attachment_actions'] ?? null;
        if (!is_array($actions) || ($actions['available'] ?? null) !== true || !is_array($actions['documents'] ?? null)) {
            return false;
        }
        foreach ($actions['documents'] as $document) {
            if (
                is_array($document) && ($document['has_actions'] ?? null) === true
                && is_string($document['actions_html'] ?? null) && $document['actions_html'] !== ''
            ) {
                return true;
            }
        }
        return false;
    }

    private static function shouldUseStandaloneLayout(string $template): bool
    {
        if (str_starts_with($template, 'config/')) {
            return false;
        }

        if (!function_exists('plugin_glpiacessivel_get_accessibility_mode')) {
            return false;
        }

        return plugin_glpiacessivel_get_accessibility_mode() !== 'embedded';
    }

    private static function sendNoStoreHeaders(): void
    {
        if (headers_sent()) {
            return;
        }

        header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
        header('Pragma: no-cache');
        header('Expires: 0');
    }
}
