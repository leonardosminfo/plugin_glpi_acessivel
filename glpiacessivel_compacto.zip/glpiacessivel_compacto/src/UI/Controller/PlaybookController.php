<?php

declare(strict_types=1);

namespace GlpiPlugin\Glpiacessivel\UI\Controller;

use GlpiPlugin\Glpiacessivel\Application\ConfigService;
use GlpiPlugin\Glpiacessivel\Application\FeatureReleasePolicy;
use GlpiPlugin\Glpiacessivel\Application\FeatureReleaseDenied;
use GlpiPlugin\Glpiacessivel\Support\I18n;
use GlpiPlugin\Glpiacessivel\Support\EditorialBatchState;
use GlpiPlugin\Glpiacessivel\Application\ChatbotPlaybookService;
use GlpiPlugin\Glpiacessivel\UI\View\View;

final class PlaybookController extends BaseController
{
    private const CRITICAL_CONFIRM_TTL_SECONDS = 300;
    private const CRITICAL_CONFIRM_SESSION_KEY = 'glpiacessivel_playbook_critical_confirmations';
    private const FLASH_SESSION_KEY = 'glpiacessivel_playbook_admin_flash';
    public static function index(): void
    {
        self::requireLogin();
        if (!self::requireModuleEnabled(ConfigService::MODULE_PLAYBOOKS)) {
            return;
        }

        $hasConfigRight = \Session::haveRight('config', UPDATE);
        if (method_exists('\\Session', 'checkRight')) {
            if (!$hasConfigRight) {
                self::logConfigRightDenied();
            }
            \Session::checkRight('config', UPDATE);
            if (!$hasConfigRight) {
                return;
            }
        } elseif (!$hasConfigRight) {
            self::displayConfigRightError();
            return;
        }

        $service = self::container()->chatbotPlaybookService();
        if (!$service->canReviewKnowledge()) {
            self::displayKnowledgeReviewRightError();
            return;
        }

        if ((string) ($_GET['export'] ?? '') === '1') {
            if (!headers_sent()) {
                header('Content-Type: application/json; charset=UTF-8');
                header('Content-Disposition: attachment; filename="glpiacessivel-chatbot-playbooks.json"');
            }

            echo json_encode(
                [
                    'version' => defined('PLUGIN_GLPIACESSIVEL_VERSION') ? PLUGIN_GLPIACESSIVEL_VERSION : 'dev',
                    'generated_at' => date('c'),
                    'playbooks' => $service->exportApprovedPlaybooks(),
                ],
                JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES
            );
            return;
        }

        $filters = self::queueFilters($_SERVER['REQUEST_METHOD'] === 'POST' ? $_POST : $_GET);
        $flash = self::consumeFlash();
        $message = $flash['message'] ?? null;
        $result = $flash['result'] ?? null;
        $messageType = (string) ($flash['type'] ?? 'info');
        $scanValues = (array) ($flash['scan_values'] ?? []);

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            if (
                !self::validateCsrfOrRedirect(
                    \GlpiPlugin\Glpiacessivel\Support\Url::plugin('front/playbooks.php'),
                    'playbook.csrf_rejected',
                    true
                )
            ) {
                return;
            }

            $action = (string) ($_POST['action'] ?? '');
            if (self::handleEditorialBatch($action, $service, $filters)) {
                return;
            }
            if (
                !in_array($action, [
                'run_kb_initial', 'continue_kb_scan', 'pause_kb_scan', 'cancel_kb_scan',
                'update_suggestion', 'approve', 'reject', 'create_playbook', 'update_playbook',
                'delete_playbook', 'import_json',
                ], true)
            ) {
                $action = 'invalid';
            }
            if (self::isCriticalPlaybookAction($action)) {
                try {
                    self::validatePlaybookCriticalConfirmation($action, $_POST);
                } catch (\Throwable $e) {
                    self::container()->auditLogger()->log('chatbot.playbook.critical_confirmation.blocked', [
                        'action' => $action,
                        'reason' => $e->getMessage(),
                    ]);
                    $message = __('Confirme a ação crítica na tela antes de executar.', 'glpiacessivel');
                    $messageType = 'error';
                    $action = '';
                }
            }
            try {
                if ($action === 'run_kb_initial') {
                    FeatureReleasePolicy::requireAllowed('playbooks.knowledge_scan', true);
                    $result = $service->runInitialKnowledgeScan(self::scanOptions($_POST));
                    $message = self::scanSummary($result);
                    $messageType = in_array((string) ($result['status'] ?? ''), ['failed', 'unknown'], true)
                        ? 'error' : 'info';
                } elseif (in_array($action, ['continue_kb_scan', 'pause_kb_scan', 'cancel_kb_scan'], true)) {
                    if ($action === 'continue_kb_scan') {
                        FeatureReleasePolicy::requireAllowed('playbooks.knowledge_scan', true);
                    }
                    $jobId = (int) ($_POST['job_id'] ?? 0);
                    if ($jobId <= 0) {
                        throw new \RuntimeException('invalid_job');
                    }
                    $methods = [
                        'continue_kb_scan' => 'continueKnowledgeScan',
                        'pause_kb_scan' => 'pauseKnowledgeScan',
                        'cancel_kb_scan' => 'cancelKnowledgeScan',
                    ];
                    $result = $service->{$methods[$action]}($jobId);
                    $message = self::scanSummary($result);
                    $messageType = in_array((string) ($result['status'] ?? ''), ['failed', 'unknown'], true)
                        ? 'error' : 'info';
                } elseif ($action === 'update_suggestion') {
                    $updated = $service->updateSuggestion((int) ($_POST['suggestion_id'] ?? 0), $_POST);
                    $message = $updated
                        ? __('Sugestão atualizada.', 'glpiacessivel')
                        : __('Sugestão pendente não encontrada para atualização.', 'glpiacessivel');
                } elseif ($action === 'approve') {
                    $applied = $service->approveSuggestion(
                        (int) ($_POST['suggestion_id'] ?? 0),
                        (int) ($_POST['proposal_revision'] ?? 0)
                    );
                    $message = $applied !== null
                        ? __('Decisão editorial aplicada. Confira o estado da orientação.', 'glpiacessivel')
                        : __(
                            'A proposta não foi aplicada. Recarregue a fila e confira seu estado e suas fontes.',
                            'glpiacessivel'
                        );
                    $messageType = $applied !== null ? 'info' : 'error';
                } elseif ($action === 'reject') {
                    $rejected = $service->rejectSuggestion(
                        (int) ($_POST['suggestion_id'] ?? 0),
                        (int) ($_POST['proposal_revision'] ?? 0)
                    );
                    $message = $rejected
                        ? __('Sugestão rejeitada.', 'glpiacessivel')
                        : __('A proposta não foi rejeitada. Recarregue a fila e confira seu estado.', 'glpiacessivel');
                    $messageType = $rejected ? 'info' : 'error';
                } elseif ($action === 'create_playbook') {
                    $created = $service->createPlaybook($_POST);
                    if (($created['status'] ?? '') === 'pending') {
                        $message = __('Roteiro cadastrado como pendente para análise.', 'glpiacessivel');
                    } elseif (($created['status'] ?? '') === 'invalid') {
                        $message = __('Informe ao menos o nome do roteiro.', 'glpiacessivel');
                    } else {
                        $message = __('Roteiro cadastrado.', 'glpiacessivel');
                    }
                } elseif ($action === 'update_playbook') {
                    $updated = $service->updatePlaybook((int) ($_POST['playbook_id'] ?? 0), $_POST);
                    $message = $updated && (string) ($_POST['status'] ?? '') === 'pending'
                        ? __('Roteiro retornou para sugestões pendentes.', 'glpiacessivel')
                        : ($updated
                            ? __('Roteiro atualizado.', 'glpiacessivel')
                            : __('Roteiro não encontrado para atualização.', 'glpiacessivel'));
                } elseif ($action === 'delete_playbook') {
                    $deleted = $service->deletePlaybook((int) ($_POST['playbook_id'] ?? 0));
                    $message = $deleted
                        ? __('Roteiro excluído.', 'glpiacessivel')
                        : __('Roteiro não encontrado para exclusão.', 'glpiacessivel');
                } elseif ($action === 'import_json') {
                    $rawJson = self::readPlaybookImportJson();
                    $payload = self::decodePlaybookImportJson($rawJson);
                    $items = self::playbookImportItems($payload);
                    if ($items === []) {
                        throw new \RuntimeException('JSON válido, mas nenhum roteiro foi encontrado para importação.');
                    }
                    $import = $service->importPlaybooks($items, (string) ($_POST['import_status'] ?? 'active'));
                    $message = self::playbookImportSummary($import);
                } elseif ($action !== '') {
                    throw new \RuntimeException('invalid_action');
                }
            } catch (FeatureReleaseDenied $e) {
                self::logReleaseDenied($e, $action);
                $message = self::releaseDeniedMessage($e, $action, true);
                $messageType = 'error';
            } catch (\Throwable $e) {
                self::container()->auditLogger()->log('chatbot.playbook.admin.error', [
                    'action' => $action,
                    'error' => get_class($e),
                ]);
                $message = $action === 'run_kb_initial' && $e instanceof \InvalidArgumentException
                    ? __(
                        'Confira os filtros: publicação válida, lote de 25 ou 50 e limite total entre 1 e 5000.',
                        'glpiacessivel'
                    )
                    : ($action === 'import_json'
                        ? __(
                            'Não foi possível importar os roteiros. Verifique o arquivo e tente novamente.',
                            'glpiacessivel'
                        )
                        : __(
                            'Não foi possível concluir a ação solicitada. Verifique o registro de eventos do GLPI.',
                            'glpiacessivel'
                        ));
                $messageType = 'error';
            }
            self::redirectWithFlash((string) $message, $messageType, $result, $filters);
            return;
        }

        if (!empty($_GET['batch'])) {
            try {
                self::renderEditorialBatch((string) $_GET['batch'], $service);
                return;
            } catch (FeatureReleaseDenied $error) {
                self::logReleaseDenied($error, 'batch_review');
                $message = self::releaseDeniedMessage($error, 'batch_review', true);
                $messageType = 'error';
            } catch (\Throwable $error) {
                $message = __('A revisão do lote não está disponível neste contexto. Selecione novamente as propostas.', 'glpiacessivel');
                $messageType = 'error';
            }
        }
        $queue = $service->listKnowledgeSuggestions($filters);
        $filters['page'] = (int) ($queue['page'] ?? $filters['page']);
        $selectedIds = [];
        if (!empty($_GET['batch_selection'])) {
            try {
                $saved = EditorialBatchState::get((string) $_GET['batch_selection']);
                if ($saved['kind'] === 'page' && !$saved['expired'] && $saved['filters'] === $filters) {
                    $selectedIds = array_column($saved['rows'], 'id');
                }
            } catch (\Throwable $error) {
                $message = __('A seleção anterior não está disponível. Nenhuma decisão foi aplicada.', 'glpiacessivel');
            }
        }
        $batchReport = null;
        if (!empty($_GET['batch_result'])) {
            try {
                $batchReport = self::editorialBatchReport((string) $_GET['batch_result'], $service);
            } catch (\Throwable $error) {
                $message = __('O resultado do lote não está disponível neste contexto. Confira a fila antes de tentar novamente.', 'glpiacessivel');
                $messageType = 'error';
            }
        }
        $jobs = array_map(static fn(array $job): array => self::jobPresentation($job), $service->listKnowledgeJobs(10));
        $playbooks = $service->listApprovedPlaybooks(80);
        $knowledgeScanAllowed = FeatureReleasePolicy::allows('playbooks.knowledge_scan');
        $batchReviewAllowed = FeatureReleasePolicy::allows('playbooks.batch_review');
        View::render('playbooks/index', [
            'title' => $batchReport !== null
                ? __('Resultado da decisão editorial em lote', 'glpiacessivel')
                : __('Roteiros do chatbot', 'glpiacessivel'),
            'chatbot_name' => self::container()->configService()->getChatbotDisplayName(),
            'csrf_token' => self::csrf()->token(true),
            'critical_confirmations' => self::playbookCriticalConfirmationTokens(
                (array) ($queue['items'] ?? []),
                $playbooks,
                $jobs
            ),
            'message' => $message,
            'message_type' => $messageType,
            'scan_values' => $scanValues,
            'scan_error' => (bool) ($flash['scan_error'] ?? false),
            'result' => $result,
            'queue' => $queue,
            'queue_filters' => $filters,
            'jobs' => $jobs,
            'playbooks' => $playbooks,
            'knowledge_scan_allowed' => $knowledgeScanAllowed,
            'batch_review_allowed' => $batchReviewAllowed,
            'suggestions' => (array) ($queue['items'] ?? []),
            'batch_page_token' => $batchReviewAllowed && empty($queue['access_incomplete'])
                ? EditorialBatchState::page((array) ($queue['items'] ?? []), $filters) : '',
            'batch_selected_ids' => array_values(array_intersect(
                $selectedIds,
                array_column((array) ($queue['items'] ?? []), 'id')
            )),
            'batch_report' => $batchReport,
        ]);
    }

    private static function handleEditorialBatch(string $action, ChatbotPlaybookService $service, array $filters): bool
    {
        if (
            !in_array($action, ['batch_select_page', 'batch_review_approve', 'batch_review_reject',
            'batch_confirm', 'batch_back', 'batch_cancel', 'batch_refresh'], true)
        ) {
            return false;
        }
        try {
            if (!in_array($action, ['batch_back', 'batch_cancel'], true)) {
                FeatureReleasePolicy::requireAllowed('playbooks.batch_review', true);
            }
            if (in_array($action, ['batch_select_page', 'batch_review_approve', 'batch_review_reject'], true)) {
                $ids = $_POST['selected_proposals'] ?? [];
                if (!is_array($ids)) {
                    throw new \InvalidArgumentException('batch_selection_invalid');
                }
                $selection = EditorialBatchState::selection(
                    (string) ($_POST['batch_page_token'] ?? ''),
                    $ids,
                    $action === 'batch_select_page'
                );
                $filters = $selection['filters'];
                if ($action === 'batch_select_page') {
                    $token = EditorialBatchState::page(array_map(static fn(array $row): array =>
                        $row + ['status' => 'pending'], $selection['rows']), $filters);
                    self::batchRedirect($filters, ['batch_selection' => $token]);
                } else {
                    $decision = $action === 'batch_review_approve' ? 'approve' : 'reject';
                    $prepared = $service->prepareEditorialBatch($selection['rows'], $decision);
                    $token = EditorialBatchState::review($selection, $decision, $prepared);
                    self::batchRedirect($filters, ['batch' => $token]);
                }
                return true;
            }
            $token = (string) ($_POST['batch_token'] ?? '');
            $record = EditorialBatchState::get($token);
            $filters = $record['filters'];
            if ($action === 'batch_confirm') {
                $record = EditorialBatchState::claim($token);
                $report = $service->executeEditorialBatch(
                    ['items' => $record['manifest'], 'operation_id' => $token],
                    $record['action']
                );
                EditorialBatchState::finish($token, $report);
                self::batchRedirect($filters, ['batch_result' => $token]);
            } elseif ($action === 'batch_cancel' || $action === 'batch_back') {
                EditorialBatchState::discard($token);
                $query = [];
                if ($action === 'batch_back' && FeatureReleasePolicy::allows('playbooks.batch_review', true)) {
                    $page = EditorialBatchState::page(array_map(static fn(array $row): array =>
                        $row + ['status' => 'pending'], $record['rows']), $filters);
                    $query['batch_selection'] = $page;
                }
                self::batchRedirect($filters, $query);
            } elseif ($action === 'batch_refresh') {
                if ($record['kind'] !== 'review' || $record['phase'] !== 'review') {
                    throw new \RuntimeException('batch_refresh_invalid');
                }
                $rows = [];
                foreach ($record['rows'] as $row) {
                    $current = $service->visibleEditorialDecision((int) $row['id']);
                    $rows[] = $current === null ? $row : EditorialBatchState::row($current);
                }
                $selection = ['rows' => $rows, 'filters' => $filters];
                $prepared = $service->prepareEditorialBatch($rows, $record['action']);
                $replacement = EditorialBatchState::review($selection, $record['action'], $prepared);
                EditorialBatchState::discard($token);
                self::batchRedirect($filters, ['batch' => $replacement]);
            }
        } catch (FeatureReleaseDenied $error) {
            self::logReleaseDenied($error, $action);
            $notStarted = $action !== 'batch_confirm';
            if ($action === 'batch_confirm') {
                try {
                    // A repeated request may refer to an already consumed confirmation.
                    // Inspect the authorized record without claiming, discarding or reopening it.
                    $existingToken = (string) ($_POST['batch_token'] ?? '');
                    $existing = EditorialBatchState::get($existingToken);
                    if ($existing['kind'] === 'review' && in_array($existing['phase'], ['processing', 'result'], true)) {
                        self::batchRedirect($existing['filters'], ['batch_result' => $existingToken]);
                        return true;
                    }
                    $notStarted = $existing['kind'] === 'review' && $existing['phase'] === 'review';
                } catch (\Throwable $unavailable) {
                    // Unknown/lost context is not evidence that no previous decision occurred.
                }
            }
            self::redirectWithFlash(self::releaseDeniedMessage($error, $action, $notStarted), 'error', null, $filters);
        } catch (\Throwable $error) {
            self::container()->auditLogger()->log('chatbot.playbook.batch.blocked', [
                'action' => $action, 'reason' => get_class($error),
            ]);
            if ($action === 'batch_confirm' && isset($token)) {
                try {
                    $record = EditorialBatchState::get($token);
                    if ($record['kind'] === 'review' && in_array($record['phase'], ['processing', 'result'], true)) {
                        self::batchRedirect($record['filters'], ['batch_result' => $token]);
                        return true;
                    }
                } catch (\Throwable $unavailable) {
                    // Lost context cannot be used to disclose the operation report.
                }
            }
            // A consumed confirmation is never returned to the review phase for replay.
            self::redirectWithFlash(
                __('O lote não foi concluído. Confira a seleção, o contexto e o estado das propostas antes de tentar novamente.', 'glpiacessivel'),
                'error',
                null,
                $filters
            );
        }
        return true;
    }

    private static function logReleaseDenied(FeatureReleaseDenied $error, string $action): void
    {
        self::container()->auditLogger()->log('chatbot.playbook.release.blocked', [
            'action' => $action, 'feature' => $error->feature, 'reason' => $error->reason,
        ]);
    }

    /** Only callers which proved the gate preceded execution may assert no new work. */
    private static function releaseDeniedMessage(FeatureReleaseDenied $error, string $action, bool $notStarted): string
    {
        $scan = $error->feature === 'playbooks.knowledge_scan';
        if ($error->reason === 'feature_disabled') {
            $message = $scan
                ? __('A varredura da base de conhecimento está desativada nesta instalação.', 'glpiacessivel')
                : __('A revisão em lote está desativada nesta instalação.', 'glpiacessivel');
        } elseif ($error->reason === 'profile_excluded') {
            $message = $scan
                ? __('A varredura não está liberada para seu perfil ativo.', 'glpiacessivel')
                : __('A revisão em lote não está liberada para seu perfil ativo.', 'glpiacessivel');
        } elseif ($error->reason === 'module_disabled') {
            $message = __('O módulo necessário para esta funcionalidade está desativado nesta instalação.', 'glpiacessivel');
        } elseif (in_array($error->reason, ['session_unavailable', 'profile_unavailable'], true)) {
            $message = __('Não foi possível confirmar sua sessão e seu perfil ativo. Acesse novamente o GLPI.', 'glpiacessivel');
        } else {
            $message = __('Não foi possível verificar a disponibilidade desta funcionalidade. Recarregue a página antes de tentar novamente.', 'glpiacessivel');
        }
        if ($notStarted) {
            if ($scan) {
                $message .= ' ' . ($action === 'continue_kb_scan'
                    ? __('Não foi iniciado um novo lote por esta tentativa. As etapas anteriores foram preservadas.', 'glpiacessivel')
                    : __('Nenhuma nova varredura foi iniciada por esta tentativa.', 'glpiacessivel'));
            } else {
                $message .= ' ' . __('Nenhuma decisão foi aplicada por esta tentativa.', 'glpiacessivel');
            }
        } else {
            $message .= ' ' . __('Confira o estado das propostas e os resultados anteriores antes de tentar novamente.', 'glpiacessivel');
        }
        return $message;
    }

    private static function batchRedirect(array $filters, array $extra): void
    {
        $query = http_build_query($extra + ['queue_state' => $filters['state'],
            'queue_action' => $filters['action'], 'queue_page' => $filters['page']], '', '&', PHP_QUERY_RFC3986);
        if (!headers_sent()) {
            $fragment = isset($extra['batch_result']) ? '#editorial-batch-result' : '#suggestions-title';
            if (isset($extra['batch'])) {
                $fragment = '#editorial-batch-title';
            }
            header('Location: ' . \GlpiPlugin\Glpiacessivel\Support\Url::plugin('front/playbooks.php?' . $query)
                . $fragment, true, 303);
        }
    }

    private static function renderEditorialBatch(string $token, ChatbotPlaybookService $service): void
    {
        $record = EditorialBatchState::get($token);
        if ($record['kind'] !== 'review') {
            throw new \RuntimeException('batch_review_invalid');
        }
        if ($record['phase'] !== 'review') {
            self::batchRedirect($record['filters'], ['batch_result' => $token]);
            return;
        }
        FeatureReleasePolicy::requireAllowed('playbooks.batch_review', true);
        $prepared = $service->prepareEditorialBatch($record['rows'], $record['action']);
        $sameManifest = ($prepared['manifest'] ?? $record['rows']) === $record['manifest'];
        View::render('playbooks/batch', [
            'title' => __('Revisar decisões em lote', 'glpiacessivel'),
            'csrf_token' => self::csrf()->token(true),
            'batch_review_allowed' => true,
            'batch' => ['action' => $record['action'], 'items' => $prepared['items'],
                'ready' => !empty($prepared['eligible']) && $sameManifest && !$record['expired'],
                'expired' => $record['expired'], 'changed' => !$sameManifest,
                'token' => $token, 'filters' => $record['filters']],
        ]);
    }

    private static function editorialBatchReport(string $token, ChatbotPlaybookService $service): array
    {
        $record = EditorialBatchState::get($token);
        if ($record['kind'] !== 'review' || !in_array($record['phase'], ['result', 'processing'], true)) {
            throw new \RuntimeException('batch_report_invalid');
        }
        $result = $record['result'] ?? ['status' => 'interrupted', 'action' => $record['action'],
            'items' => array_map(static fn(array $row): array => ['id' => $row['id'],
                'status' => 'unknown', 'reason' => 'reconciliation_required'], $record['rows'])];
        foreach ($result['items'] as &$item) {
            $visible = $service->visibleEditorialDecision((int) $item['id']);
            if ($visible !== null) {
                $item['title'] = (string) ($visible['title'] ?? '');
                $item['action'] = (string) ($visible['action'] ?? 'create');
            } else {
                // Outcomes survive; identifying details require current native access.
                $item['reason'] = 'access_unavailable';
                unset($item['id']);
            }
        }
        unset($item);
        return $result;
    }

    /**
     * @param array<string, mixed> $input
     * @return array<string, int|string>
     */
    private static function queueFilters(array $input): array
    {
        $state = (string) ($input['queue_state'] ?? 'pending');
        $action = (string) ($input['queue_action'] ?? 'all');
        return [
            'state' => in_array(
                $state,
                ['pending', 'approved', 'rejected', 'superseded', 'conflict', 'failed', 'all'],
                true
            )
                ? $state : 'pending',
            'action' => in_array($action, ['all', 'create', 'update', 'inactivate', 'reactivate', 'review'], true)
                ? $action : 'all',
            'page' => max(1, min(100000, (int) ($input['queue_page'] ?? 1))),
            'page_size' => 20,
        ];
    }

    /**
     * @param array<string, mixed> $input
     * @return array<string, int|string|bool>
     */
    private static function scanOptions(array $input): array
    {
        $publication = (string) ($input['publication'] ?? 'all');
        $batch = (int) ($input['batch_size'] ?? 25);
        $limit = (int) ($input['limit'] ?? 500);
        if (
            !in_array($publication, ['all', 'published', 'unpublished'], true)
            || !in_array($batch, [25, 50], true) || $limit < 1 || $limit > 5000
        ) {
            throw new \InvalidArgumentException('invalid_scan_options');
        }
        return [
            'publication' => $publication,
            'batch_size' => $batch,
            'limit' => $limit,
            'faq_only' => (string) ($input['faq_only'] ?? $input['public_only'] ?? '0') === '1',
        ];
    }

    /** @param array<string, mixed> $result */
    private static function scanSummary(array $result): string
    {
        $status = (string) ($result['status'] ?? 'unknown');
        $labels = [
            'completed' => __('Varredura concluída para o escopo definido.', 'glpiacessivel'),
            'partial' => __('Resultado parcial preservado. A varredura ainda não foi concluída.', 'glpiacessivel'),
            'running' => __('Etapa registrada. Consulte o progresso antes de continuar.', 'glpiacessivel'),
            'paused' => __('Varredura pausada. Os resultados já registrados foram preservados.', 'glpiacessivel'),
            'cancelled' => __('Varredura cancelada. As propostas anteriores foram preservadas.', 'glpiacessivel'),
            'failed' => __(
                'A varredura falhou. Confira o diagnóstico; não houve conclusão do escopo.',
                'glpiacessivel'
            ),
            'unknown' => __(
                'O resultado da etapa não foi confirmado. Confira o estado antes de tentar novamente.',
                'glpiacessivel'
            ),
        ];
        return (string) ($labels[$status] ?? $labels['unknown']);
    }

    /**
     * @param array<string, int|string> $filters
     * @param array<string, mixed>|null $result
     */
    private static function redirectWithFlash(string $message, string $type, ?array $result, array $filters): void
    {
        $nonce = bin2hex(random_bytes(12));
        $safeResult = $result === null ? null : array_intersect_key($result, array_flip([
            'job_id', 'id', 'status', 'processed', 'examined', 'suggestions', 'skipped', 'failed', 'cursor',
        ]));
        $flashes = is_array($_SESSION[self::FLASH_SESSION_KEY] ?? null) ? $_SESSION[self::FLASH_SESSION_KEY] : [];
        $flashes[$nonce] = [
            'nonce' => $nonce, 'message' => $message, 'type' => $type, 'result' => $safeResult,
            'context' => self::contextKey(), 'expires_at' => time() + 600,
            'scan_values' => self::scanFormValues($_POST),
            'scan_error' => (string) ($_POST['action'] ?? '') === 'run_kb_initial' && $type === 'error',
        ];
        $_SESSION[self::FLASH_SESSION_KEY] = array_slice($flashes, -10, null, true);
        $query = http_build_query([
            'queue_state' => $filters['state'], 'queue_action' => $filters['action'],
            'queue_page' => $filters['page'], 'notice' => $nonce,
        ], '', '&', PHP_QUERY_RFC3986);
        if (!headers_sent()) {
            $returnUrl = \GlpiPlugin\Glpiacessivel\Support\Url::plugin('front/playbooks.php?' . $query);
            header('Location: ' . $returnUrl, true, 303);
        }
    }

    /** @return array<string, mixed> */
    private static function consumeFlash(): array
    {
        $nonce = (string) ($_GET['notice'] ?? '');
        $flashes = is_array($_SESSION[self::FLASH_SESSION_KEY] ?? null) ? $_SESSION[self::FLASH_SESSION_KEY] : [];
        foreach ($flashes as $key => $item) {
            if (!is_array($item) || (int) ($item['expires_at'] ?? 0) < time()) {
                unset($flashes[$key]);
            }
        }
        $flash = $flashes[$nonce] ?? null;
        unset($flashes[$nonce]);
        $_SESSION[self::FLASH_SESSION_KEY] = $flashes;
        if (
            !is_array($flash) || (int) ($flash['expires_at'] ?? 0) < time()
            || (string) ($flash['context'] ?? '') !== self::contextKey()
            || !hash_equals((string) ($flash['nonce'] ?? ''), (string) ($_GET['notice'] ?? ''))
        ) {
            return [];
        }
        return $flash;
    }

    private static function contextKey(): string
    {
        return hash('sha256', json_encode([
            (int) ($_SESSION['glpiID'] ?? 0), (int) ($_SESSION['glpiactiveprofile']['id'] ?? 0),
            (int) ($_SESSION['glpiactive_entity'] ?? 0), (bool) ($_SESSION['glpiactive_entity_recursive'] ?? false),
        ]) ?: '');
    }

    /**
     * @param array<string, mixed> $input
     * @return array<string, int|string>
     */
    private static function scanFormValues(array $input): array
    {
        return [
            'publication' => in_array((string) ($input['publication'] ?? ''), ['all', 'published', 'unpublished'], true)
                ? (string) $input['publication'] : 'all',
            'batch_size' => (int) ($input['batch_size'] ?? 25) === 50 ? 50 : 25,
            'limit' => max(1, min(5000, (int) ($input['limit'] ?? 500))),
            'faq_only' => (string) ($input['faq_only'] ?? $input['public_only'] ?? '0') === '1' ? '1' : '0',
        ];
    }

    private static function logConfigRightDenied(): void
    {
        self::container()->auditLogger()->log('playbook.permission_denied', [
            'required_right' => 'config_update',
            'profile_id' => (int) ($_SESSION['glpiactiveprofile']['id'] ?? 0),
            'entity_id' => (int) ($_SESSION['glpiactive_entity'] ?? 0),
        ]);
    }

    /**
     * @param array<string, mixed> $job
     * @return array<string, mixed>
     */
    private static function jobPresentation(array $job): array
    {
        $cursor = $job['cursor'] ?? json_decode((string) ($job['cursor_json'] ?? '{}'), true);
        $counts = is_array($cursor) && is_array($cursor['counts'] ?? null) ? $cursor['counts'] : [];
        foreach (['examined', 'processed', 'suggestions', 'skipped', 'failed'] as $counter) {
            $job[$counter] = max(0, (int) ($job[$counter] ?? $counts[$counter] ?? $job[$counter . '_count'] ?? 0));
        }
        return $job;
    }

    private static function displayKnowledgeReviewRightError(): void
    {
        self::container()->auditLogger()->log('playbook.permission_denied', [
            'required_right' => 'knowledge_editorial_review',
        ]);
        if (!headers_sent()) {
            http_response_code(403);
        }
        View::render('errors/permission', [
            'title' => __('Sem permissão para curadoria da base', 'glpiacessivel'),
            'message' => __(
                'Seu contexto atual não permite a revisão administrativa da base de conhecimento.',
                'glpiacessivel'
            ),
            'alert_title' => __('Acesso bloqueado pelo GLPI', 'glpiacessivel'),
            'alert_message' => __('Entre com um perfil autorizado para curadoria da base.', 'glpiacessivel'),
            'return_url' => \GlpiPlugin\Glpiacessivel\Support\Url::plugin('front/acessivel.php'),
        ]);
    }

    private static function displayConfigRightError(): void
    {
        self::logConfigRightDenied();

        if (class_exists('\Html') && method_exists('\Html', 'displayRightError')) {
            \Html::displayRightError();
            return;
        }

        if (!headers_sent()) {
            http_response_code(403);
        }

        View::render('errors/permission', [
            'title' => __('Sem permissão para roteiros do chatbot', 'glpiacessivel'),
            'message' => __(
                'Seu perfil atual não possui permissão para gerenciar roteiros do chatbot.',
                'glpiacessivel'
            ),
            'alert_title' => __('Acesso bloqueado pelo GLPI', 'glpiacessivel'),
            'alert_message' => __(
                'Entre com um perfil autorizado ou solicite acesso ao administrador do GLPI.',
                'glpiacessivel'
            ),
            'return_url' => \GlpiPlugin\Glpiacessivel\Support\Url::plugin('front/acessivel.php'),
        ]);
    }
    private static function readPlaybookImportJson(): string
    {
        $raw = (string) ($_POST['playbooks_json'] ?? '');
        $file = $_FILES['playbooks_json_file'] ?? null;
        if (is_array($file) && (int) ($file['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_NO_FILE) {
            if ((int) ($file['error'] ?? UPLOAD_ERR_OK) !== UPLOAD_ERR_OK) {
                throw new \RuntimeException('Falha no upload do arquivo JSON.');
            }
            $tmpName = (string) ($file['tmp_name'] ?? '');
            if ($tmpName === '' || !is_uploaded_file($tmpName)) {
                throw new \RuntimeException('Arquivo JSON de importação inválido.');
            }
            $content = file_get_contents($tmpName);
            if (!is_string($content)) {
                throw new \RuntimeException('Não foi possível ler o arquivo JSON enviado.');
            }
            $raw = $content;
        }

        $raw = preg_replace('/^\xEF\xBB\xBF/', '', trim($raw)) ?? '';
        if ($raw === '') {
            throw new \RuntimeException('Informe ou envie um JSON de roteiros.');
        }

        return $raw;
    }

    /**
     * @return array<string|int, mixed>
     */
    private static function decodePlaybookImportJson(string $raw): array
    {
        $payload = json_decode($raw, true);
        if (!is_array($payload)) {
            $detail = function_exists('json_last_error_msg') ? json_last_error_msg() : 'JSON inválido';
            throw new \RuntimeException('JSON inválido para importação: ' . $detail . '.');
        }

        return $payload;
    }

    /**
     * @param array<string|int, mixed> $payload
     * @return array<int, array<string, mixed>>
     */
    private static function playbookImportItems(array $payload): array
    {
        foreach (['playbooks', 'items', 'data'] as $key) {
            if (isset($payload[$key]) && is_array($payload[$key])) {
                return self::sequentialPlaybookItems($payload[$key]);
            }
        }

        if (self::isAssociativePlaybook($payload)) {
            return [$payload];
        }

        return self::sequentialPlaybookItems($payload);
    }

    /**
     * @param array<string|int, mixed> $items
     * @return array<int, array<string, mixed>>
     */
    private static function sequentialPlaybookItems(array $items): array
    {
        $normalized = [];
        foreach ($items as $item) {
            if (is_array($item)) {
                $normalized[] = $item;
            }
        }

        return $normalized;
    }

    /**
     * @param array<string|int, mixed> $payload
     */
    private static function isAssociativePlaybook(array $payload): bool
    {
        return isset($payload['name']) || isset($payload['title'])
            || isset($payload['keywords']) || isset($payload['content']);
    }

    /**
     * @param array<int, array<string, mixed>> $suggestions
     * @param array<int, array<string, mixed>> $playbooks
     * @param array<int, array<string, mixed>> $jobs
     * @return array<string, string>
     */
    private static function playbookCriticalConfirmationTokens(
        array $suggestions = [],
        array $playbooks = [],
        array $jobs = []
    ): array {
        self::purgeExpiredPlaybookCriticalConfirmations();
        $scopes = [];
        foreach ($suggestions as $suggestion) {
            if (!is_array($suggestion) || (string) ($suggestion['status'] ?? 'pending') !== 'pending') {
                continue;
            }
            foreach (['approve', 'reject'] as $action) {
                $scopes[] = [
                    $action, (int) ($suggestion['id'] ?? 0), (int) ($suggestion['expected_revision'] ?? 0),
                    (int) ($suggestion['revision'] ?? 1),
                ];
            }
        }
        foreach ($playbooks as $playbook) {
            if (is_array($playbook)) {
                $scopes[] = ['delete_playbook', (int) ($playbook['id'] ?? 0), (int) ($playbook['revision'] ?? 0), 0];
            }
        }
        foreach ($jobs as $job) {
            if (is_array($job)) {
                $scopes[] = ['cancel_kb_scan', (int) ($job['id'] ?? $job['job_id'] ?? 0), 0, 0];
            }
        }
        $tokens = [];
        foreach ($scopes as [$action, $target, $revision, $proposalRevision]) {
            if ($target <= 0) {
                continue;
            }
            $token = bin2hex(random_bytes(16));
            $tokens[$action . ':' . $target] = $token;
            $_SESSION[self::CRITICAL_CONFIRM_SESSION_KEY][$token] = [
                'action' => $action,
                'target' => $target,
                'revision' => $revision,
                'proposal_revision' => $proposalRevision,
                'context' => self::contextKey(),
                'user_id' => (int) ($_SESSION['glpiID'] ?? 0),
                'expires_at' => time() + self::CRITICAL_CONFIRM_TTL_SECONDS,
            ];
        }

        return $tokens;
    }

    private static function isCriticalPlaybookAction(string $action): bool
    {
        return in_array($action, ['approve', 'reject', 'delete_playbook', 'cancel_kb_scan'], true);
    }

    /**
     * @param array<string, mixed> $post
     */
    private static function validatePlaybookCriticalConfirmation(string $action, array $post): void
    {
        if ((string) ($post['critical_confirmed'] ?? '') !== '1') {
            throw new \RuntimeException('missing_confirmation_flag');
        }

        $token = (string) ($post['critical_confirmation_token'] ?? '');
        $state = is_array($_SESSION[self::CRITICAL_CONFIRM_SESSION_KEY] ?? null)
            ? $_SESSION[self::CRITICAL_CONFIRM_SESSION_KEY]
            : [];
        $confirmation = is_array($state[$token] ?? null) ? $state[$token] : null;
        unset($_SESSION[self::CRITICAL_CONFIRM_SESSION_KEY][$token]);

        if ($token === '' || $confirmation === null) {
            throw new \RuntimeException('invalid_confirmation_token');
        }
        if ((int) ($confirmation['expires_at'] ?? 0) < time()) {
            throw new \RuntimeException('expired_confirmation_token');
        }
        if ((string) ($confirmation['action'] ?? '') !== $action) {
            throw new \RuntimeException('confirmation_scope_mismatch');
        }
        if ((int) ($confirmation['user_id'] ?? 0) !== (int) ($_SESSION['glpiID'] ?? 0)) {
            throw new \RuntimeException('confirmation_user_mismatch');
        }
        if ((string) ($confirmation['context'] ?? '') !== self::contextKey()) {
            throw new \RuntimeException('confirmation_context_mismatch');
        }
        $target = (int) ($post['suggestion_id'] ?? $post['playbook_id'] ?? $post['job_id'] ?? 0);
        if ($target <= 0 || (int) ($confirmation['target'] ?? 0) !== $target) {
            throw new \RuntimeException('confirmation_target_mismatch');
        }
        if ((int) ($confirmation['revision'] ?? 0) !== (int) ($post['expected_revision'] ?? 0)) {
            throw new \RuntimeException('confirmation_revision_mismatch');
        }
        if ((int) ($confirmation['proposal_revision'] ?? 0) !== (int) ($post['proposal_revision'] ?? 0)) {
            throw new \RuntimeException('confirmation_proposal_revision_mismatch');
        }
    }

    private static function purgeExpiredPlaybookCriticalConfirmations(): void
    {
        $state = is_array($_SESSION[self::CRITICAL_CONFIRM_SESSION_KEY] ?? null)
            ? $_SESSION[self::CRITICAL_CONFIRM_SESSION_KEY]
            : [];
        $now = time();
        foreach ($state as $token => $confirmation) {
            if (!is_array($confirmation) || (int) ($confirmation['expires_at'] ?? 0) < $now) {
                unset($state[$token]);
            }
        }
        if (count($state) > 250) {
            $state = array_slice($state, -250, null, true);
        }
        $_SESSION[self::CRITICAL_CONFIRM_SESSION_KEY] = $state;
    }

    /** @param array<string, int> $import */
    private static function playbookImportSummary(array $import): string
    {
        $active = (int) ($import['active'] ?? 0);
        $inactive = (int) ($import['inactive'] ?? 0);
        $pending = (int) ($import['pending'] ?? 0);
        $skipped = (int) ($import['skipped'] ?? 0);

        return sprintf(
            __('Importação concluída: %s, %s, %s e %s.', 'glpiacessivel'),
            sprintf(I18n::plural('%d roteiro ativo', '%d roteiros ativos', $active), $active),
            sprintf(I18n::plural('%d roteiro inativo', '%d roteiros inativos', $inactive), $inactive),
            sprintf(I18n::plural('%d roteiro pendente', '%d roteiros pendentes', $pending), $pending),
            sprintf(I18n::plural('%d item ignorado', '%d itens ignorados', $skipped), $skipped)
        );
    }
}
