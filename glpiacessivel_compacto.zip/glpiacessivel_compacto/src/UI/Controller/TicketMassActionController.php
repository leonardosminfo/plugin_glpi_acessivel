<?php

declare(strict_types=1);

namespace GlpiPlugin\Glpiacessivel\UI\Controller;

use GlpiPlugin\Glpiacessivel\Application\ConfigService;
use GlpiPlugin\Glpiacessivel\Application\FeatureReleasePolicy;
use GlpiPlugin\Glpiacessivel\Application\TicketMassActionForm;
use GlpiPlugin\Glpiacessivel\Application\TicketMassActionStateStore;
use GlpiPlugin\Glpiacessivel\Application\TicketMassActionVerification;
use GlpiPlugin\Glpiacessivel\Infrastructure\Http\SameOriginPolicy;
use GlpiPlugin\Glpiacessivel\Infrastructure\MassiveAction\NativeMassiveActionGateway;
use GlpiPlugin\Glpiacessivel\Infrastructure\Security\GlpiSessionContextSnapshot;
use GlpiPlugin\Glpiacessivel\UI\View\View;
use GlpiPlugin\Glpiacessivel\Support\Url;

/** Accessible presentation of native massive actions; no replacement business rules. */
final class TicketMassActionController extends BaseController
{
    public static function handle(): void
    {
        self::requireLogin();
        if (!self::requireModuleEnabled(ConfigService::MODULE_TICKETS)) {
            return;
        }
        $store = new TicketMassActionStateStore();
        $gateway = new NativeMassiveActionGateway();
        $token = '';
        $flow = ['stage' => 'unknown', 'ids' => []];
        try {
            $revision = (new GlpiSessionContextSnapshot())->snapshot()['revision'];
            if (($_SERVER['REQUEST_METHOD'] ?? '') === 'GET') {
                // GET only presents session-owned state. It never prepares, verifies links or executes.
                $candidate = $_GET['flow_token'] ?? '';
                if (!is_string($candidate)) {
                    throw new \RuntimeException('mass_request_invalid');
                }
                $token = $candidate;
                $flow = $store->resolve($token, $revision);
                self::visible($flow['ids']);
                self::render($token, $flow, $flow['view_error'] ?? '');
                return;
            }
            if (
                ($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST'
                || !(new SameOriginPolicy())->evaluate($_SERVER)['allowed']
            ) {
                throw new \RuntimeException('mass_request_invalid');
            }
            self::csrf()->validateRequest(true);
            $store->observeContext($revision);
            $stage = self::scalar('stage');
            if ($stage === 'start') {
                self::requireAnyReleasedAction();
                $ids = $store->verifyPage(self::scalar('selection_token'), (array) ($_POST['ids'] ?? []), $revision);
                self::visible($ids);
                $native = self::releasedCatalog($gateway->prepare($ids));
                $token = $store->create($ids, $revision, $native);
                $flow = $store->resolve($token, $revision);
                self::redirect($token);
                return;
            }
            $token = self::scalar('flow_token');
            $flow = $store->resolve($token, $revision);
            if (in_array($flow['status'], ['running', 'done', 'unknown', 'cancelled'], true)) {
                self::redirect($token);
                return;
            }
            if ($stage === 'cancel' && $flow['status'] === 'ready') {
                $store->cancel($token);
                self::redirect($token);
                return;
            }
            // A continuation belongs to an already-started native operation.
            // Disabling a rollout must not strand its remaining native batches.
            if ($flow['status'] !== 'waiting') {
                if ($stage === 'action') {
                    self::requireReleasedAction(self::scalar('actionkey'));
                } elseif (isset($flow['actionkey'])) {
                    self::requireReleasedAction((string) $flow['actionkey']);
                } else {
                    self::requireAnyReleasedAction();
                }
            }
            self::visible($flow['ids']);
            if ($stage === 'extend' && in_array($flow['status'], ['ready', 'waiting'], true)) {
                $fresh = $gateway->prepare($flow['ids']);
                if (isset($flow['actionkey']) && !isset($fresh['actions'][$flow['actionkey']])) {
                    throw new \RuntimeException('mass_action_unavailable');
                }
                if (isset($flow['submission'])) {
                    self::actorAllowed($gateway, $flow, $flow['submission']);
                }
                $store->extend($token, $revision);
                self::redirect($token);
                return;
            }
            if ($stage === 'revise' && $flow['stage'] === 'review') {
                $flow['stage'] = 'form';
                $store->save($token, $flow);
                self::redirect($token);
                return;
            }
            if ($stage === 'action' && $flow['stage'] === 'catalog') {
                $action = self::scalar('actionkey');
                $fresh = $gateway->prepare($flow['ids']);
                if (!isset($fresh['actions'][$action])) {
                    throw new \RuntimeException('mass_action_unavailable');
                }
                $flow['actionkey'] = $action;
                $flow['actionlabel'] = $fresh['actions'][$action];
                $gateway->renderWithCompletion(
                    $gateway->specialize($fresh['input'], $action),
                    static function (array $form) use ($store, $gateway, $token, $flow): void {
                        if (isset($form['error'])) {
                            self::formUnavailable($store, $token, $flow);
                            return;
                        }
                        $next = $flow;
                        $next['mode'] = $flow['actionkey'] === 'MassiveAction:update' ? 'status_field' : 'actor_role';
                        if ($next['mode'] === 'status_field') {
                            $field = $gateway->statusField($form);
                            $form['controls'] = [['name' => 'id_field', 'type' => 'select', 'value' => $field['value'],
                                'required' => true, 'disabled' => false, 'multiple' => false,
                                'options' => [['value' => $field['value'], 'label' => $field['label'],
                                    'disabled' => false, 'selected' => true]]]];
                        }
                        self::saveForm($store, $token, $next, $form);
                    }
                );
                return;
            }
            if ($stage === 'search' && $flow['stage'] === 'form' && isset($flow['form']['lookup'])) {
                $flow['query'] = self::scalar('query');
                $flow['lookup_page'] = max(1, (int) self::scalar('page', '1'));
                $form = self::choices($gateway, $flow['form'], $flow['query'], $flow['lookup_page']);
                self::saveForm($store, $token, $flow, $form);
                return;
            }
            if ($stage === 'params' && $flow['stage'] === 'form') {
                $validated = (new TicketMassActionForm())->values($flow['form'], (array) ($_POST['values'] ?? []));
                $values = $validated['values'];
                if ($flow['mode'] === 'status_field') {
                    $flow['mode'] = 'parameters';
                    $gateway->renderWithCompletion(
                        $gateway->statusInput($flow['form']),
                        static fn(array $form) => self::saveForm($store, $token, $flow, $form)
                    );
                } elseif ($flow['mode'] === 'actor_role') {
                    $flow['mode'] = 'actor_type';
                    $flow['review'] = $validated['review'];
                    $gateway->renderActorType(
                        $flow['form']['input'],
                        (string) ($values['actortype'] ?? ''),
                        static fn(array $form) => self::saveForm($store, $token, $flow, $form)
                    );
                } elseif ($flow['mode'] === 'actor_type') {
                    $flow['mode'] = 'parameters';
                    $flow['review'] = array_merge($flow['review'] ?? [], $validated['review']);
                    $role = (string) ($flow['form']['ajax']['actortype'] ?? '');
                    $gateway->renderActorSelection(
                        $flow['form'],
                        (string) ($values['_itil_' . $role]['_type'] ?? ''),
                        static function (array $form) use ($store, $gateway, $token, $flow): void {
                            self::saveForm($store, $token, $flow, self::choices($gateway, $form, '', 1));
                        }
                    );
                } else {
                    self::actorAllowed($gateway, $flow, $values);
                    $flow['submission'] = array_replace_recursive(
                        $flow['form']['input'],
                        $flow['form']['hidden'],
                        $values
                    );
                    $flow['base_review'] = $flow['base_review'] ?? ($flow['review'] ?? []);
                    $flow['review'] = array_merge($flow['base_review'], $validated['review']);
                    $flow['values'] = [];
                    foreach ($flow['form']['controls'] as $index => $control) {
                        $flow['values'][$index] = $_POST['values'][$index] ?? '';
                    }
                    $flow['stage'] = 'review';
                    $store->save($token, $flow);
                    self::redirect($token);
                }
                return;
            }
            if (
                ($stage === 'confirm' && $flow['stage'] === 'review' && self::scalar('confirmed') === '1')
                || ($stage === 'continue' && $flow['stage'] === 'waiting')
            ) {
                $fresh = $gateway->prepare($flow['ids']);
                if (!isset($fresh['actions'][$flow['actionkey']])) {
                    throw new \RuntimeException('mass_action_unavailable');
                }
                self::actorAllowed($gateway, $flow, $flow['submission']);
                $flow['status'] = 'running';
                $flow['stage'] = 'unknown';
                $store->save($token, $flow);
                // Commit single-use state before mutation. Native batching then needs an OPEN session.
                session_write_close();
                if (!session_start()) {
                    throw new \RuntimeException('mass_session_unavailable');
                }
                $lockedRevision = (new GlpiSessionContextSnapshot())->snapshot()['revision'];
                $lockedFlow = $store->resolve($token, $lockedRevision);
                if (
                    $lockedRevision !== $revision || $lockedFlow['status'] !== 'running'
                    || $lockedFlow['submission'] !== $flow['submission']
                ) {
                    throw new \RuntimeException('mass_context_changed');
                }
                self::visible($flow['ids']);
                self::actorAllowed($gateway, $flow, $flow['submission']);
                if ($stage === 'confirm') {
                    // Re-read after reacquiring the session, immediately before
                    // the first native execution. A resume is deliberately exempt.
                    if (!self::actionReleased((string) $flow['actionkey'])) {
                        // The mutation has not started: preserve a ready intent,
                        // rather than incorrectly reporting an uncertain result.
                        $flow['status'] = 'ready';
                        $flow['stage'] = 'review';
                        $store->save($token, $flow);
                        throw new \RuntimeException('feature_release_not_allowed');
                    }
                    $flow['verification_before'] = (new TicketMassActionVerification())->capture(
                        $flow['submission'],
                        $flow['ids']
                    );
                    $store->save($token, $flow);
                }
                $completion = static function (array $result) use ($store, $token, $flow): void {
                    $next = $flow;
                    $next['result'] = $result;
                    $next['messages'] = array_slice(
                        array_merge($flow['messages'] ?? [], $result['messages'] ?? []),
                        -20
                    );
                    $next['stage'] = !empty($result['uncertain']) ? 'unknown'
                        : (($result['identifier'] ?? null) !== null ? 'waiting' : 'done');
                    $next['status'] = $next['stage'] === 'waiting' ? 'waiting' : $next['stage'];
                    if ($next['stage'] !== 'waiting') {
                        $next['verification'] = (new TicketMassActionVerification())->verify(
                            $flow['submission'],
                            $flow['ids'],
                            $flow['verification_before'] ?? []
                        );
                    }
                    $store->save($token, $next);
                    self::redirect($token);
                };
                if ($stage === 'continue') {
                    $gateway->resumeWithCompletion(
                        (int) $flow['result']['identifier'],
                        array_map('intval', array_values($flow['submission']['items']['Ticket'] ?? [])),
                        $flow['submission']['processor'],
                        $flow['submission']['action'],
                        $completion
                    );
                } else {
                    $gateway->processWithCompletion($flow['submission'], $completion);
                }
                return;
            }
            throw new \RuntimeException('mass_stage_invalid');
        } catch (\Throwable $exception) {
            // Never expose internals or allow an uncertain mutation to be replayed.
            if (($flow['status'] ?? '') === 'running') {
                $flow['stage'] = 'unknown';
                $flow['status'] = 'unknown';
                try {
                    $store->save($token, $flow);
                    self::redirect($token);
                    return;
                } catch (\Throwable) {
                    // Context can have invalidated preparation while the lock was released.
                }
                self::render($token, $flow);
            } else {
                http_response_code(409);
                self::render(
                    '',
                    ['stage' => 'unavailable', 'ids' => []],
                    $exception->getMessage() === 'feature_release_not_allowed'
                        ? __('Esta funcionalidade não está liberada para seu perfil atual.', 'glpiacessivel')
                        : __(
                            'Não foi possível validar esta etapa. Volte à lista e prepare uma nova seleção;'
                            . ' nenhuma nova execução foi iniciada.',
                            'glpiacessivel'
                        )
                );
            }
        }
    }

    private static function saveForm(TicketMassActionStateStore $store, string $token, array $flow, array $form): void
    {
        if (isset($form['error']) || empty($form['controls'])) {
            self::formUnavailable($store, $token, $flow);
            return;
        }
        $names = array_column($form['controls'], 'name');
        if (
            count($names) !== count(array_unique($names))
            || array_filter($form['controls'], static fn(array $control): bool => !empty($control['multiple'])) !== []
        ) {
            self::formUnavailable($store, $token, $flow);
            return;
        }
        foreach ($form['controls'] as &$control) {
            if (
                $control['name'] === 'status' || $control['name'] === 'actortype'
                || preg_match('/\A_itil_[^\[]+\[_type\]\z/D', $control['name']) === 1
                || $control['name'] === ($form['lookup']['field'] ?? null)
            ) {
                $control['explicit_choice'] = true;
                $control['required'] = true;
                $control['value'] = '';
                foreach ($control['options'] as &$option) {
                    $option['selected'] = false;
                }
                unset($option);
            }
        }
        unset($control);
        $flow['form'] = $form;
        $flow['stage'] = 'form';
        unset($flow['view_error']);
        $store->save($token, $flow);
        self::redirect($token);
    }

    private static function formUnavailable(TicketMassActionStateStore $store, string $token, array $flow): void
    {
        $flow['view_error'] = __(
            'O formulário nativo não pôde ser carregado. Nenhuma ação foi executada.',
            'glpiacessivel'
        );
        $store->save($token, $flow);
        self::redirect($token);
    }

    private static function redirect(string $token): void
    {
        // Relative to the native GLPI root, with no browser-provided return URL.
        header('Location: ' . Url::plugin('front/ticket.massaction.php?flow_token=' . rawurlencode($token)), true, 303);
    }

    private static function choices(NativeMassiveActionGateway $gateway, array $form, string $query, int $page): array
    {
        $found = $gateway->search($form['lookup'], $query, $page);
        foreach ($form['controls'] as &$control) {
            if ($control['name'] === $form['lookup']['field']) {
                $control['options'] = array_map(static fn(array $row): array => ['value' => (string) $row['id'],
                    'label' => $row['label'], 'disabled' => false, 'selected' => false], $found['results']);
                $control['required'] = true;
                $control['value'] = '';
            }
        }
        unset($control);
        $form['more'] = $found['more'];
        return $form;
    }

    private static function actorAllowed(NativeMassiveActionGateway $gateway, array $flow, array $values): void
    {
        if (!isset($flow['form']['lookup'])) {
            return;
        }
        $field = $flow['form']['lookup']['field'];
        if (
            preg_match('/\A([^\[]+)\[([^\]]+)\]\z/D', $field, $m) !== 1
            || (int) ($values[$m[1]][$m[2]] ?? 0) < 1
            || !$gateway->actorChoiceAllowed(
                $flow['form']['lookup'],
                $flow['query'] ?? '',
                $flow['lookup_page'] ?? 1,
                (int) ($values[$m[1]][$m[2]] ?? 0)
            )
        ) {
            throw new \RuntimeException('mass_actor_unavailable');
        }
    }

    private static function visible(array $ids): void
    {
        foreach ($ids as $id) {
            if (!(new \Ticket())->can((int) $id, READ)) {
                throw new \RuntimeException('mass_ticket_unavailable');
            }
        }
    }

    private static function scalar(string $name, string $default = ''): string
    {
        $value = $_POST[$name] ?? $default;
        if (!is_string($value) || strlen($value) > 32768) {
            throw new \InvalidArgumentException('mass_request_invalid');
        }
        return $value;
    }

    private static function render(string $token, array $flow, string $error = ''): void
    {
        // Re-evaluate presentation too: an old preparation may outlive its rollout.
        // Keep completed results and native continuation/cancellation accessible.
        if (($flow['stage'] ?? '') === 'catalog') {
            $flow['native'] = self::releasedCatalog((array) ($flow['native'] ?? []));
            if (!self::actionReleased('MassiveAction:update') && !self::actionReleased('Ticket:add_actor')) {
                $flow['stage'] = 'unavailable';
                $error = __('Esta funcionalidade não está liberada para seu perfil atual.', 'glpiacessivel');
            }
        } elseif (
            ($flow['status'] ?? '') === 'ready'
            && isset($flow['actionkey'])
            && !self::actionReleased((string) $flow['actionkey'])
        ) {
            $flow['stage'] = 'unavailable';
            $error = __('Esta funcionalidade não está liberada para seu perfil atual.', 'glpiacessivel');
        }
        View::render('tickets/mass-action', ['title' => __('Ações em massa', 'glpiacessivel'),
            'flowToken' => $token, 'csrfToken' => self::csrf()->token(), 'flow' => $flow, 'error' => $error]);
    }

    private static function actionReleased(string $action): bool
    {
        return match ($action) {
            'MassiveAction:update' => FeatureReleasePolicy::allows('tickets.mass_status', true),
            'Ticket:add_actor' => FeatureReleasePolicy::allows('tickets.mass_participants', true),
            default => false,
        };
    }

    private static function requireReleasedAction(string $action): void
    {
        if (!self::actionReleased($action)) {
            throw new \RuntimeException('feature_release_not_allowed');
        }
    }

    private static function requireAnyReleasedAction(): void
    {
        if (!self::actionReleased('MassiveAction:update') && !self::actionReleased('Ticket:add_actor')) {
            throw new \RuntimeException('feature_release_not_allowed');
        }
    }

    private static function releasedCatalog(array $native): array
    {
        $native['actions'] = array_filter(
            (array) ($native['actions'] ?? []),
            static fn(string $action): bool => self::actionReleased($action),
            ARRAY_FILTER_USE_KEY
        );
        return $native;
    }
}
