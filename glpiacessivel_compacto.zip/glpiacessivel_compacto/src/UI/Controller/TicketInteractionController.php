<?php

declare(strict_types=1);

namespace GlpiPlugin\Glpiacessivel\UI\Controller;

use GlpiPlugin\Glpiacessivel\Application\ConfigService;
use GlpiPlugin\Glpiacessivel\Application\FeatureReleasePolicy;
use GlpiPlugin\Glpiacessivel\Application\InteractionEditState;
use GlpiPlugin\Glpiacessivel\Application\InteractionEditPresentation;
use GlpiPlugin\Glpiacessivel\Infrastructure\Http\SameOriginPolicy;
use GlpiPlugin\Glpiacessivel\Infrastructure\Security\GlpiSessionContextSnapshot;
use GlpiPlugin\Glpiacessivel\Infrastructure\Ticket\NativeInteractionEditor;
use GlpiPlugin\Glpiacessivel\Infrastructure\Ticket\InteractionAttachmentReader;
use GlpiPlugin\Glpiacessivel\Support\Url;
use GlpiPlugin\Glpiacessivel\UI\View\View;
use GlpiPlugin\Glpiacessivel\UI\View\RichInteractionFields;

final class TicketInteractionController extends BaseController
{
    public static function handle(): void
    {
        self::requireLogin();
        if (!self::requireModuleEnabled(ConfigService::MODULE_TICKETS)) {
            return;
        }
        $method = (string) ($_SERVER['REQUEST_METHOD'] ?? 'GET');
        if (!in_array($method, ['GET', 'POST'], true)) {
            http_response_code(405);
            header('Allow: GET, POST');
            return;
        }
        $gateway = new NativeInteractionEditor();
        $store = new InteractionEditState();
        $view = null;
        $token = '';
        $error = '';
        $draft = [];
        $outcome = '';
        $nativeForm = '';
        $mode = '';
        $documents = [];
        $attachmentActions = [];
        try {
            FeatureReleasePolicy::requireAllowed('tickets.interaction_edit');
            $revision = (new GlpiSessionContextSnapshot())->snapshot()['revision'];
            if ($method === 'GET') {
                $ticketId = self::positiveId($_GET['ticket_id'] ?? null);
                $id = self::positiveId($_GET['interaction_id'] ?? null);
                $kind = self::scalar($_GET, 'kind');
                $view = $gateway->context($ticketId, $kind, $id);
                $mode = InteractionEditPresentation::mode($view, FeatureReleasePolicy::allows('tickets.interaction_rich_edit', true));
                if ($mode === 'native') {
                    FeatureReleasePolicy::requireAllowed('tickets.interaction_edit', true);
                    $view = $gateway->richContext($ticketId, $kind, $id);
                    $view['editor_mode'] = 'rich';
                    $nativeForm = (new RichInteractionFields())->render((string) $view['content_html'], 'interaction-content');
                    if ($nativeForm === '') {
                        // An unavailable complete editor must not silently become a simple editor.
                        $mode = 'recovery';
                    }
                }
                if (in_array($mode, ['native', 'simple', 'text', 'visibility'], true)) {
                    $token = $store->issue($view, $revision);
                }
                try {
                    $documents = self::container()->ticketRepository()->getInteractionDocuments(
                        $ticketId,
                        $kind,
                        $id,
                        (int) $view['is_private']
                    );
                    $readContext = (new InteractionAttachmentReader())->context($ticketId, $kind, $id);
                    $descriptions = InteractionAttachmentReader::descriptions((string) $readContext['source_content'], $documents);
                    foreach ($documents as &$document) {
                        $document['descriptions'] = $descriptions[(int) $document['id']] ?? [];
                    }
                    unset($document);
                } catch (\Throwable) {
                    // Document discovery cannot replace or disable the authorized native editor.
                    $documents = [];
                }
            } else {
                if (!(new SameOriginPolicy())->evaluate($_SERVER)['allowed']) {
                    throw new \DomainException('interaction_not_available');
                }
                self::csrf()->validateRequest();
                $token = self::scalar($_POST, 'edit_token');
                $baseline = $store->resolve($token, $revision);
                $ticketId = (int) $baseline['ticket_id'];
                $kind = (string) $baseline['kind'];
                $id = (int) $baseline['interaction_id'];
                $rich = ($baseline['editor_mode'] ?? '') === 'rich';
                if ($rich) {
                    FeatureReleasePolicy::requireAllowed('tickets.interaction_rich_edit', true);
                }
                $view = $rich ? $gateway->richContext($ticketId, $kind, $id) : $gateway->context($ticketId, $kind, $id);
                $mode = $rich ? 'native' : '';
                self::validateFields($_POST, $rich);
                foreach (['content', 'is_private'] as $field) {
                    if (array_key_exists($field, $_POST)) {
                        $draft[$field] = $field === 'content'
                            ? $gateway->postText(self::scalar($_POST, $field))
                            : self::scalar($_POST, $field);
                    }
                }
                // Consume before native execution, while the GLPI session is
                // still open. Refresh/back cannot replay this form intent.
                FeatureReleasePolicy::requireAllowed('tickets.interaction_edit', true);
                $store->consume($token);
                try {
                    if ($rich) {
                        $draft += NativeInteractionEditor::nativeUploads($_POST);
                    }
                    $result = $rich
                        ? $gateway->updateRich($ticketId, $kind, $id, $draft, $baseline)
                        : $gateway->update($ticketId, $kind, $id, $draft, $baseline);
                } catch (\InvalidArgumentException $exception) {
                    // Validation above the mutation boundary: safe to correct.
                    $token = $store->issue($baseline, $revision);
                    $error = $rich
                        ? __('Revise o texto, a visibilidade e os arquivos antes de salvar novamente.', 'glpiacessivel')
                        : self::validationMessage($exception->getMessage());
                    http_response_code(422);
                    if ($rich) {
                        $fields = new RichInteractionFields();
                        $html = (string) ($draft['content'] ?? $view['content_html']);
                        try {
                            $nativeForm = $fields->render($html, 'interaction-content', true, false, $draft);
                        } catch (\InvalidArgumentException) {
                            // Keep the authorized text even when a legacy helper
                            // cannot safely redisplay the pending upload metadata.
                            $nativeForm = $fields->render($html, 'interaction-content');
                            $error .= ' ' . __('Os anexos não puderam ser conferidos com segurança. Selecione os arquivos novamente.', 'glpiacessivel');
                        }
                    }
                    self::render($view, $token, $draft, $error, '', $nativeForm, $mode);
                    return;
                }
                $outcome = $result['status'];
                $token = '';
                if (in_array($outcome, ['saved', 'unchanged'], true)) {
                    self::setMessage('success', $outcome === 'saved'
                        ? __('Interação atualizada pelo GLPI.', 'glpiacessivel')
                        : __('Nenhuma alteração foi enviada.', 'glpiacessivel'));
                    header('Location: ' . self::returnUrl($view), true, 303);
                    return;
                }
                http_response_code(409);
            }
        } catch (\Throwable $exception) {
            // Do not echo the former baseline/draft after context or ACL loss.
            $view = null;
            $draft = [];
            $token = '';
            $nativeForm = '';
            $documents = [];
            $attachmentActions = [];
            $notReleasedMessage = __('Esta funcionalidade não está liberada para seu perfil atual.', 'glpiacessivel');
            $error = in_array($exception->getMessage(), ['feature_release_not_allowed', $notReleasedMessage], true)
                ? __('Esta funcionalidade não está liberada para seu perfil atual.', 'glpiacessivel')
                : __(
                    'O acesso ou o formulário não são mais válidos. Volte ao chamado e abra a edição novamente.',
                    'glpiacessivel'
                );
            http_response_code(403);
        }
        self::render($view, $token, $draft, $error, $outcome, $nativeForm, $mode, $documents, $attachmentActions);
    }

    /** @param array<string,mixed>|null $view @param array<string,mixed> $draft */
    private static function render(?array $view, string $token, array $draft, string $error, string $outcome, string $nativeForm = '', string $mode = '', array $documents = [], array $attachmentActions = []): void
    {
        $mode = $view === null ? 'unavailable' : ($mode !== '' ? $mode : InteractionEditPresentation::mode($view, false));
        View::render('tickets/interaction-edit', [
            'title' => InteractionEditPresentation::title($mode, (string) ($view['kind'] ?? '')),
            'editor_mode' => $mode,
            'interaction_documents' => $documents,
            'native_attachment_actions' => $attachmentActions,
            'interaction' => $view,
            'edit_token' => $token,
            'csrf_token' => $token !== '' ? self::csrf()->token(true) : '',
            'draft' => $draft,
            'error' => $error,
            'outcome' => $outcome,
            'native_interaction_form' => $nativeForm,
            'return_url' => $view === null ? Url::plugin('front/tickets.php') : self::returnUrl($view),
        ]);
    }

    /** Return to the exact interaction link/heading supplied by the detail integration. */
    public static function returnUrl(array $view): string
    {
        return Url::plugin('front/tickets.php?id=' . (int) $view['ticket_id'])
            . '#interaction-' . (string) $view['kind'] . '-' . (int) $view['interaction_id'];
    }

    private static function positiveId(mixed $value): int
    {
        if (!is_scalar($value) || preg_match('/\A[1-9][0-9]*\z/D', (string) $value) !== 1) {
            throw new \InvalidArgumentException('interaction_request_invalid');
        }
        $id = filter_var($value, FILTER_VALIDATE_INT);
        if (!is_int($id) || $id < 1) {
            throw new \InvalidArgumentException('interaction_request_invalid');
        }
        return $id;
    }

    private static function scalar(array $input, string $key): string
    {
        if (!is_string($input[$key] ?? null)) {
            throw new \InvalidArgumentException('interaction_request_invalid');
        }
        return $input[$key];
    }

    private static function validateFields(array $post, bool $rich = false): void
    {
        $allowed = ['_glpi_csrf_token', 'edit_token', 'content', 'is_private'];
        if ($rich) {
            $allowed = array_merge($allowed, ['rich_mode', '_filename', '_tag_filename', '_prefix_filename', '_uploader_filename']);
        }
        foreach (array_keys($post) as $field) {
            if (!in_array($field, $allowed, true)) {
                throw new \InvalidArgumentException('interaction_field_not_allowed');
            }
        }
    }

    private static function validationMessage(string $code): string
    {
        return match ($code) {
            'interaction_rich_text_native_only' => __(
                'Este texto exige o editor convencional para preservar a formatação.',
                'glpiacessivel'
            ),
            'interaction_visibility_invalid', 'interaction_visibility_not_available' => __(
                'A visibilidade solicitada não está disponível nesta interface.',
                'glpiacessivel'
            ),
            default => __(
                'Revise os campos. O texto deve ter até 16.000 bytes. Outros atributos não podem ser alterados aqui.',
                'glpiacessivel'
            ),
        };
    }
}
