<?php

declare(strict_types=1);

namespace GlpiPlugin\Glpiacessivel\UI\Controller;

use GlpiPlugin\Glpiacessivel\Application\ConfigService;
use GlpiPlugin\Glpiacessivel\Application\FeatureReleasePolicy;
use GlpiPlugin\Glpiacessivel\Infrastructure\Ticket\InteractionAttachmentReader;
use GlpiPlugin\Glpiacessivel\Infrastructure\Ticket\NativeAttachmentActions;
use GlpiPlugin\Glpiacessivel\Support\Url;
use GlpiPlugin\Glpiacessivel\UI\View\View;

final class TicketAttachmentsController extends BaseController
{
    public static function handle(): void
    {
        self::requireLogin();
        if (!self::requireModuleEnabled(ConfigService::MODULE_TICKETS)) {
            return;
        }
        if (($_SERVER['REQUEST_METHOD'] ?? 'GET') !== 'GET') {
            http_response_code(405);
            header('Allow: GET');
            return;
        }
        $context = null;
        $documents = [];
        $actions = [];
        try {
            $ticketId = filter_var($_GET['ticket_id'] ?? null, FILTER_VALIDATE_INT);
            $id = filter_var($_GET['interaction_id'] ?? null, FILTER_VALIDATE_INT);
            $kind = is_string($_GET['kind'] ?? null) ? $_GET['kind'] : '';
            $context = (new InteractionAttachmentReader())->context((int) $ticketId, $kind, (int) $id);
            $documents = self::container()->ticketRepository()->getInteractionDocuments(
                (int) $ticketId,
                $kind,
                (int) $id,
                (int) $context['is_private']
            );
            $descriptions = InteractionAttachmentReader::descriptions((string) $context['source_content'], $documents);
            unset($context['source_content']);
            foreach ($documents as &$document) {
                $document['descriptions'] = $descriptions[(int) $document['id']] ?? [];
            }
            unset($document);
            if (FeatureReleasePolicy::allows('tickets.interaction_edit', true)) {
                try {
                    $actions = (new NativeAttachmentActions())->presentation((int) $ticketId, $kind, (int) $id, $documents);
                } catch (\Throwable) {
                    $actions = [];
                }
            }
        } catch (\Throwable) {
            $context = null;
            $documents = [];
            http_response_code(403);
        }
        View::render('tickets/attachments', [
            'title' => __('Anexos da interação', 'glpiacessivel'),
            'attachment_context' => $context,
            'interaction_documents' => $documents,
            'native_attachment_actions' => $actions,
            'return_url' => $context === null ? Url::plugin('front/tickets.php') : TicketInteractionController::returnUrl($context),
        ]);
    }
}
