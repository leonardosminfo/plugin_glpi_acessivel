<?php

declare(strict_types=1);

namespace GlpiPlugin\Glpiacessivel\UI\Controller;

use GlpiPlugin\Glpiacessivel\Application\ConfigService;
use GlpiPlugin\Glpiacessivel\Application\FeatureReleasePolicy;
use GlpiPlugin\Glpiacessivel\Application\NativeStatisticsRequest;
use GlpiPlugin\Glpiacessivel\Application\NativeTicketStatisticsException;
use GlpiPlugin\Glpiacessivel\Infrastructure\Http\NativeTicketReportLinks;
use GlpiPlugin\Glpiacessivel\Infrastructure\Security\GlpiSessionContextSnapshot;
use GlpiPlugin\Glpiacessivel\Support\Url;
use GlpiPlugin\Glpiacessivel\UI\View\View;

/** Accessible presentation only. Native Stat owns all counts and their semantics. */
final class NativeStatisticsController extends BaseController
{
    public static function index(): void
    {
        self::requireLogin();
        if (!self::requireModuleEnabled(ConfigService::MODULE_COCKPIT)) {
            return;
        }
        if (!self::container()->authorization()->canViewCockpit() || !\Session::haveRight('statistic', READ)) {
            self::denyAccess(
                __('Estatísticas indisponíveis para este perfil', 'glpiacessivel'),
                __('O perfil ativo precisa de acesso ao Cockpit e às estatísticas nativas do GLPI.', 'glpiacessivel'),
                'statistics.permission_denied'
            );
            return;
        }

        $url = Url::plugin('front/statistics.php');
        $model = [
            'state' => 'idle', 'filters' => [], 'modes' => [], 'errors' => [], 'message' => '',
            'context' => [], 'rows' => [], 'pagination' => [], 'conventional_url' => '',
            'return_url' => Url::plugin('front/cockpit.php#cockpit-statistics'),
            'form_url' => $url, 'context_revision' => '',
        ];
        if (!FeatureReleasePolicy::allows('reports.cockpit_statistics', true)) {
            $model['state'] = 'denied';
            $model['message'] = __('As estatísticas acessíveis no Cockpit não estão disponíveis para seu perfil ativo.', 'glpiacessivel');
            if (!headers_sent()) {
                http_response_code(403);
            }
            self::render($model);
            return;
        }
        if (($_SERVER['REQUEST_METHOD'] ?? 'GET') !== 'GET') {
            if (!headers_sent()) {
                http_response_code(405);
                header('Allow: GET');
            }
            $model['state'] = 'denied';
            $model['message'] = __('Abra o formulário para consultar as estatísticas.', 'glpiacessivel');
            self::render($model);
            return;
        }

        try {
            $service = self::container()->nativeTicketStatisticsService();
            $capabilities = $service->capabilities();
            if (empty($capabilities['assigned'])) {
                $model['state'] = 'denied';
                $model['message'] = self::message('native_statistics_contract_unavailable');
                self::render($model);
                return;
            }
            $model['modes'] = [['value' => 'assigned', 'label' => __('Por técnico atribuído', 'glpiacessivel')]];
            $snapshot = (new GlpiSessionContextSnapshot())->snapshot();
            $model['context_revision'] = $snapshot['revision'];
            $context = self::container()->contextService()->getContext();
            $model['context'] = [
                'entity' => $context['current_entity_name'],
                'recursive' => $snapshot['recursive'],
                'profile' => $context['current_profile_name'],
            ];
            $request = NativeStatisticsRequest::parse($_GET, $service->defaults(), $snapshot['revision']);
            $model['filters'] = $request['filters'];
            foreach ($request['errors'] as $field => $reason) {
                $model['errors'][$field] = self::message($reason);
            }
            if ($request['consult'] && $model['errors'] === []) {
                $result = $service->query($request['filters'], $snapshot['revision']);
                // Do not render a result if context changed within this request.
                if (!hash_equals($snapshot['revision'], (new GlpiSessionContextSnapshot())->snapshot()['revision'])) {
                    throw new \RuntimeException('statistics_context_changed');
                }
                $model['rows'] = $result['rows'];
                $model['filters'] = array_intersect_key($result, array_flip(['mode', 'date1', 'date2', 'start']));
                $model['state'] = $result['rows'] === [] ? 'empty' : 'success';
                $parameters = $model['filters'] + ['consult' => '1', 'context_revision' => $snapshot['revision']];
                $model['pagination'] = [
                    'offset' => $result['start'], 'page_size' => $result['page_size'], 'total' => $result['total_rows'],
                    'previous_url' => $result['start'] > 0
                        ? self::pageUrl($url, $parameters, max(0, $result['start'] - $result['page_size'])) : '',
                    'next_url' => $result['start'] + $result['page_size'] < $result['total_rows']
                        ? self::pageUrl($url, $parameters, $result['start'] + $result['page_size']) : '',
                ];
            }
            if ($model['errors'] !== []) {
                $model['state'] = 'error';
            }
        } catch (NativeTicketStatisticsException $error) {
            $model['state'] = 'error';
            $model['rows'] = [];
            $model['errors'][$error->field ?? 'request'] = self::message($error->reason);
        } catch (\Throwable $error) {
            $model['state'] = 'error';
            $model['rows'] = [];
            $model['pagination'] = [];
            $model['message'] = __('Não foi possível obter um resultado estatístico completo. Seus filtros foram preservados; nenhuma contagem parcial será exibida.', 'glpiacessivel');
            self::container()->auditLogger()->log('statistics.query_failed', ['error' => get_class($error)]);
        }
        if (FeatureReleasePolicy::allows('reports.native_links')) {
            $links = (new NativeTicketReportLinks())->technicianStatisticsLinks(
                is_string($model['filters']['date1'] ?? null) ? $model['filters']['date1'] : null,
                is_string($model['filters']['date2'] ?? null) ? $model['filters']['date2'] : null
            );
            $model['conventional_url'] = !empty($links['available']) ? ($links['links']['assigned'] ?? '') : '';
        }
        self::render($model);
    }

    private static function pageUrl(string $url, array $parameters, int $start): string
    {
        $parameters['start'] = $start;
        return $url . '?' . http_build_query($parameters, '', '&', PHP_QUERY_RFC3986) . '#statistics-results';
    }

    private static function render(array $model): void
    {
        View::render('statistics/index', [
            'title' => __('Estatísticas nativas acessíveis', 'glpiacessivel'), 'statistics' => $model,
        ]);
    }

    private static function message(string $reason): string
    {
        return match ($reason) {
            'context_changed', 'native_statistics_context_changed' => __('Seu perfil ou entidade mudou. Confira o contexto atual e consulte novamente.', 'glpiacessivel'),
            'native_statistics_date_invalid', 'native_statistics_period_invalid' => __('Informe datas válidas, com a data inicial igual ou anterior à data final.', 'glpiacessivel'),
            'native_statistics_mode_unsupported' => __('Esta modalidade ainda não possui adaptação homologada. Use uma modalidade disponível.', 'glpiacessivel'),
            'native_statistics_offset_invalid' => __('A página solicitada não é válida. Consulte novamente a partir da primeira página.', 'glpiacessivel'),
            'native_statistics_limit_unsupported' => __('O limite nativo de linhas não é compatível com esta consulta. Confira sua preferência no GLPI.', 'glpiacessivel'),
            'native_statistics_forbidden' => __('O GLPI não autorizou a consulta estatística no contexto atual.', 'glpiacessivel'),
            'native_statistics_contract_unavailable' => __('O contrato nativo necessário às estatísticas acessíveis não está disponível nesta versão do GLPI.', 'glpiacessivel'),
            'native_statistics_query_failed', 'native_statistics_response_invalid' => __('Não foi possível obter um resultado estatístico completo. Seus filtros foram preservados; nenhuma contagem parcial será exibida.', 'glpiacessivel'),
            default => __('Não foi possível validar a consulta ou o resultado nativo. Confira os campos e consulte novamente.', 'glpiacessivel'),
        };
    }
}
