<?php

declare(strict_types=1);

namespace GlpiPlugin\Glpiacessivel\UI\Controller;

use GlpiPlugin\Glpiacessivel\Application\ManualAvailabilitySnapshot;
use GlpiPlugin\Glpiacessivel\Application\ManualCatalog;
use GlpiPlugin\Glpiacessivel\Support\Url;

/** Documentation does not initialize operational profile/entity context. */
final class ManualController
{
    private \Closure $authenticate;
    private \Closure $active;
    private \Closure $catalog;
    private \Closure $renderer;
    private \Closure $snapshot;

    public function __construct(
        ?callable $authenticate = null,
        ?callable $active = null,
        ?callable $catalog = null,
        ?callable $renderer = null,
        ?callable $snapshot = null
    ) {
        $this->authenticate = \Closure::fromCallable($authenticate ?? static function (): void {
            \Session::checkLoginUser();
        });
        $this->active = \Closure::fromCallable($active ?? static fn(): bool => is_callable(['Plugin', 'isPluginActive'])
            && (bool) call_user_func(['Plugin', 'isPluginActive'], 'glpiacessivel'));
        $this->catalog = \Closure::fromCallable($catalog ?? static fn(): array => (new ManualCatalog())->load());
        $this->renderer = \Closure::fromCallable($renderer ?? static function (array $model): void {
            extract($model, EXTR_SKIP);
            require dirname(__DIR__, 3) . '/templates/manual/index.php';
        });
        $this->snapshot = \Closure::fromCallable($snapshot ?? static fn(): ManualAvailabilitySnapshot => new ManualAvailabilitySnapshot());
    }

    public static function index(): void
    {
        (new self())->handle();
    }

    public static function requestedView(mixed $value): string
    {
        return $value === 'full' ? 'full' : 'context';
    }

    public function handle(): void
    {
        ($this->authenticate)();
        if (!headers_sent()) {
            header('Content-Type: text/html; charset=UTF-8');
            header('Cache-Control: private, no-store, max-age=0');
            header('X-Content-Type-Options: nosniff');
        }
        $method = $_SERVER['REQUEST_METHOD'] ?? 'GET';
        if (!in_array($method, ['GET', 'HEAD'], true)) {
            http_response_code(405);
            if (!headers_sent()) {
                header('Allow: GET, HEAD');
            }
            return;
        }
        try {
            $active = ($this->active)() === true;
        } catch (\Throwable) {
            $active = false;
        }
        if (!$active) {
            http_response_code(403);
            return;
        }
        if ($method === 'HEAD') {
            return;
        }
        try {
            $manual = ManualCatalog::validate(($this->catalog)());
        } catch (\Throwable) {
            http_response_code(503);
            $manual = ['title' => 'Manual do GLPI Acessível',
                'lead' => 'Não foi possível carregar o conteúdo do manual. Os dados e as configurações do GLPI não foram alterados.',
                'manual_version' => '', 'covered_plugin_version' => '', 'revision' => '', 'credit' => '',
                'sections' => [['id' => 'manual-indisponivel', 'title' => 'Conteúdo indisponível', 'rule' => 'always',
                    'level' => 2, 'html' => '<p>Tente abrir o manual novamente mais tarde ou solicite apoio à equipe responsável.</p>']]];
        }
        $availability = ($this->snapshot)();
        ($this->renderer)([
            'manual' => $manual,
            'manualView' => self::requestedView($_GET['view'] ?? null),
            'manualAvailability' => $availability,
            'manualReadingContext' => $availability->readingContext(),
            'manualUrl' => Url::plugin('front/manual.php'),
            'manualCssUrl' => Url::asset('public/assets/css/manual.css?v=' . rawurlencode(
                defined('PLUGIN_GLPIACESSIVEL_VERSION') ? (string) PLUGIN_GLPIACESSIVEL_VERSION : 'dev'
            )),
            'manualHomeUrl' => Url::plugin('front/acessivel.php'),
            'manualImageBaseUrl' => Url::asset('public/assets/manual/images/'),
        ]);
    }
}
