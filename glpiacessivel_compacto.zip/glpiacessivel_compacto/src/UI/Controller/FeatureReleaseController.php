<?php

declare(strict_types=1);

namespace GlpiPlugin\Glpiacessivel\UI\Controller;

use GlpiPlugin\Glpiacessivel\Application\FeatureReleaseCatalog;
use GlpiPlugin\Glpiacessivel\Support\Url;
use GlpiPlugin\Glpiacessivel\UI\View\View;

/** Two-step, session-bound administration; never receives release decisions from JavaScript. */
final class FeatureReleaseController extends BaseController
{
    private const SESSION_KEY = 'glpiacessivel_feature_release_reviews';
    private const REVIEW_TTL = 600;

    public static function index(): void
    {
        self::requireLogin();
        if (!\Session::haveRight('config', UPDATE)) {
            self::denyAccess(
                __('Sem permissão', 'glpiacessivel'),
                __('Seu perfil atual não possui permissão para acessar esta funcionalidade.', 'glpiacessivel'),
                'features.permission_denied'
            );
            return;
        }

        $url = Url::plugin('front/features.php');
        $policy = self::container()->featureReleasePolicy();
        $current = $policy->configuration();
        $values = $current['features'];
        $catalog = FeatureReleaseCatalog::all();
        $profiles = $policy->profileCatalog();
        $errors = [];
        $fieldErrors = [];
        $changes = [];
        $reviewToken = '';
        self::cleanReviews();

        if (($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'POST') {
            if (!self::validateCsrfOrRedirect($url, 'features.csrf_rejected')) {
                return;
            }
            $action = is_string($_POST['feature_action'] ?? null) ? $_POST['feature_action'] : '';
            if ($action === 'review') {
                $posted = is_array($_POST['features'] ?? null) ? $_POST['features'] : [];
                $values = self::draftValues($posted, $current['features'], $catalog);
                try {
                    if (
                        ($_POST['_feature_release_complete'] ?? null) !== 'complete'
                        || count($posted) !== count($catalog)
                        || array_diff(array_keys($catalog), array_keys($posted)) !== []
                    ) {
                        throw new \InvalidArgumentException('incomplete_review');
                    }
                    if (!is_string($_POST['revision'] ?? null) || !hash_equals($current['revision'], $_POST['revision'])) {
                        throw new \RuntimeException('stale_review');
                    }
                    $proposal = $policy->review($posted);
                    $values = $proposal['features'];
                    $changes = self::changes($current['features'], $values, $catalog);
                    if ($changes === [] && empty($current['review_required'])) {
                        $errors[] = __('Nenhuma alteração foi identificada. As configurações atuais foram mantidas.', 'glpiacessivel');
                    } else {
                        $reviewToken = bin2hex(random_bytes(24));
                        $_SESSION[self::SESSION_KEY][$reviewToken] = [
                            'expires' => time() + self::REVIEW_TTL,
                            'context' => self::context(),
                            'revision' => $current['revision'],
                            'features' => $values,
                        ];
                    }
                } catch (\Throwable $error) {
                    $fieldErrors = self::fieldErrors($values, $profiles, $catalog);
                    $errors[] = $error->getMessage() === 'stale_review'
                        ? __('A configuração foi alterada enquanto esta página estava aberta. Confira os valores e revise novamente antes de confirmar.', 'glpiacessivel')
                        : __('Não foi possível revisar. Escolha um estado para cada funcionalidade e, no modo por perfis, selecione pelo menos um perfil válido e disponível.', 'glpiacessivel');
                }
            } elseif ($action === 'confirm' || $action === 'edit') {
                $token = is_string($_POST['review_token'] ?? null) ? $_POST['review_token'] : '';
                $record = $_SESSION[self::SESSION_KEY][$token] ?? null;
                // Consume before revalidation or persistence: reloads cannot repeat a confirmation.
                unset($_SESSION[self::SESSION_KEY][$token]);
                if (
                    !is_array($record) || ($record['context'] ?? null) !== self::context()
                    || (int) ($record['expires'] ?? 0) < time()
                ) {
                    $errors[] = __('A revisão expirou ou seu perfil ou entidade mudou. Prepare uma nova revisão; nada foi confirmado.', 'glpiacessivel');
                } else {
                    $values = $record['features'];
                    if ($action === 'confirm') {
                        $confirmed = false;
                        try {
                            $validated = $policy->review($values);
                            if (!hash_equals($record['revision'], $validated['revision'])) {
                                throw new \RuntimeException('stale_review');
                            }
                            $policy->save($validated['features'], $record['revision']);
                            self::container()->auditLogger()->log('features.updated', [
                                'previous_revision' => $record['revision'],
                                'revision' => $policy->configuration(true)['revision'],
                                'modes' => array_map(static fn(array $entry): string => $entry['mode'], $validated['features']),
                            ]);
                            self::setMessage('success', __('Liberação de funcionalidades salva e conferida com sucesso.', 'glpiacessivel'));
                            $confirmed = true;
                        } catch (\Throwable $error) {
                            self::container()->auditLogger()->log('features.save_rejected', ['error' => get_class($error)]);
                            $errors[] = __('Não foi possível confirmar esta revisão. Confira a configuração vigente antes de revisar novamente; em caso de falha de gravação, não presuma que os valores foram salvos.', 'glpiacessivel');
                            $current = $policy->configuration();
                        }
                        // GLPI 11 may implement redirects by throwing a native HTTP exception.
                        // Navigation belongs outside the persistence failure boundary.
                        if ($confirmed) {
                            \Html::redirect($url);
                            return;
                        }
                    } elseif (!hash_equals($record['revision'], $current['revision'])) {
                        $errors[] = __('A configuração vigente mudou. Seu rascunho foi mantido para conferência e nova revisão.', 'glpiacessivel');
                    }
                }
            } else {
                $errors[] = __('Operação não reconhecida. Prepare uma nova revisão.', 'glpiacessivel');
            }
        }

        View::render('config/features', [
            'title' => __('Liberação de funcionalidades', 'glpiacessivel'),
            'feature_catalog' => $catalog,
            'feature_values' => $values,
            'interaction_coverage' => $policy->interactionCoverage($values, (array) ($profiles['profiles'] ?? [])),
            'feature_effective' => array_map(
                static fn(string $id): bool => $policy->allows($id),
                array_combine(array_keys($catalog), array_keys($catalog))
            ),
            'feature_field_errors' => $fieldErrors,
            'profile_catalog' => $profiles,
            'revision' => $current['revision'],
            'review_token' => $reviewToken,
            'changes' => $changes,
            'errors' => $errors,
            'review_required' => !empty($current['review_required']),
            'csrf_token' => self::csrf()->token(),
        ]);
    }

    /** @return array<string, int> */
    private static function context(): array
    {
        return [
            'user' => (int) ($_SESSION['glpiID'] ?? 0),
            'profile' => (int) ($_SESSION['glpiactiveprofile']['id'] ?? 0),
            'entity' => (int) ($_SESSION['glpiactive_entity'] ?? 0),
            'recursive' => (int) ($_SESSION['glpiactive_entity_recursive'] ?? 0),
        ];
    }

    private static function cleanReviews(): void
    {
        $reviews = is_array($_SESSION[self::SESSION_KEY] ?? null) ? $_SESSION[self::SESSION_KEY] : [];
        foreach ($reviews as $key => $record) {
            if (!is_array($record) || (int) ($record['expires'] ?? 0) < time()) {
                unset($reviews[$key]);
            }
        }
        $_SESSION[self::SESSION_KEY] = array_slice($reviews, -2, null, true);
    }

    /** Keep only bounded displayable drafts; policy is the sole authority for saving. */
    private static function draftValues(array $posted, array $fallback, array $catalog): array
    {
        foreach ($catalog as $id => $_definition) {
            if (!is_array($posted[$id] ?? null)) {
                continue;
            }
            $mode = $posted[$id]['mode'] ?? '';
            $ids = is_array($posted[$id]['profile_ids'] ?? null) ? $posted[$id]['profile_ids'] : [];
            $fallback[$id] = [
                'mode' => is_string($mode) && in_array($mode, ['off', 'profiles', 'all'], true) ? $mode : '',
                'profile_ids' => array_values(array_unique(array_map('intval', array_slice(array_filter($ids, 'is_scalar'), 0, 10000)))),
            ];
        }
        return $fallback;
    }

    /** @return array<string, array<string, mixed>> */
    private static function changes(array $before, array $after, array $catalog): array
    {
        $changes = [];
        foreach ($catalog as $id => $definition) {
            if (($before[$id] ?? null) !== ($after[$id] ?? null)) {
                $changes[$id] = ['label' => $definition['label'], 'before' => $before[$id], 'after' => $after[$id]];
            }
        }
        return $changes;
    }

    /** Presentation hints only: review/save still perform the authoritative validation. */
    private static function fieldErrors(array $values, array $profiles, array $catalog): array
    {
        $errors = [];
        $validIds = array_column($profiles['profiles'] ?? [], 'id');
        foreach ($catalog as $id => $_definition) {
            $entry = $values[$id] ?? [];
            if (!in_array($entry['mode'] ?? null, ['off', 'profiles', 'all'], true)) {
                $errors[$id] = __('Escolha um estado válido para esta funcionalidade.', 'glpiacessivel');
            } elseif ($entry['mode'] === 'profiles') {
                if (empty($profiles['available'])) {
                    $errors[$id] = __('O catálogo de perfis está indisponível. Recarregue a página antes de confirmar esta seleção.', 'glpiacessivel');
                } elseif (empty($entry['profile_ids']) || array_diff($entry['profile_ids'], $validIds) !== []) {
                    $errors[$id] = __('Selecione pelo menos um perfil válido do catálogo para esta funcionalidade.', 'glpiacessivel');
                }
            }
        }
        return $errors;
    }
}
