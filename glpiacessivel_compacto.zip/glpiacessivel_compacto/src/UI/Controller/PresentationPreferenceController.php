<?php

declare(strict_types=1);

namespace GlpiPlugin\Glpiacessivel\UI\Controller;

use GlpiPlugin\Glpiacessivel\Application\ConfigService;
use GlpiPlugin\Glpiacessivel\Application\PresentationPreferenceRequest;
use GlpiPlugin\Glpiacessivel\Application\PresentationPreferenceService;
use GlpiPlugin\Glpiacessivel\Infrastructure\Http\SameOriginPolicy;
use GlpiPlugin\Glpiacessivel\Security\SessionContextGuard;

final class PresentationPreferenceController extends BaseController
{
    public static function save(): void
    {
        if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST') {
            if (!headers_sent()) {
                header('Allow: POST');
            }
            self::respond(405, 'method_not_allowed');
            return;
        }
        if (preg_match('/\Aapplication\/json(?:\s*;\s*charset=utf-8)?\z/D', strtolower(trim((string) ($_SERVER['CONTENT_TYPE'] ?? '')))) !== 1) {
            self::respond(415, 'unsupported_media_type');
            return;
        }
        if (!(new SameOriginPolicy())->evaluate($_SERVER)['allowed']) {
            self::respond(403, 'origin_not_allowed');
            return;
        }
        $session = (new SessionContextGuard())->ensureReady();
        if (empty($session['is_authenticated'])) {
            self::respond(401, 'session_expired');
            return;
        }
        if (empty($session['session_ready'])) {
            self::respond(409, 'context_stale');
            return;
        }
        if (
            !self::container()->portalModulePolicy()->isEnabled(ConfigService::MODULE_TICKETS)
            || !self::container()->authorization()->canViewTickets()
        ) {
            self::respond(403, 'forbidden');
            return;
        }
        try {
            self::csrf()->validateRequest(true);
        } catch (\Throwable) {
            self::respond(403, 'invalid_security_token');
            return;
        }
        try {
            $raw = file_get_contents('php://input', false, null, 0, PresentationPreferenceRequest::MAX_BODY_BYTES + 1);
            $mode = PresentationPreferenceRequest::mode(is_string($raw) ? $raw : '', (int) ($_SERVER['CONTENT_LENGTH'] ?? 0));
        } catch (\Throwable) {
            self::respond(422, 'invalid_request');
            return;
        }
        try {
            $mode = (new PresentationPreferenceService())->save($mode);
            self::respond(200, '', $mode);
        } catch (\DomainException) {
            self::respond(403, 'presentation_not_available');
        } catch (\Throwable) {
            self::respond(503, 'preference_not_confirmed');
        }
    }

    private static function respond(int $status, string $error = '', ?string $mode = null): void
    {
        if (!headers_sent()) {
            http_response_code($status);
            header('Content-Type: application/json; charset=UTF-8');
            header('Cache-Control: private, no-store');
            header('Pragma: no-cache');
            header('X-Content-Type-Options: nosniff');
        }
        $token = null;
        if ($status === 200) {
            try {
                $token = self::csrf()->token(true);
            } catch (\Throwable) {
                // The saved preference remains valid; the client may retain its
                // existing preserved token or reload before another request.
            }
        }
        echo json_encode([
            'contract' => PresentationPreferenceRequest::CONTRACT,
            'version' => PresentationPreferenceRequest::VERSION,
            'success' => $status === 200,
            'result' => $mode === null ? null : ['mode' => $mode],
            'csrf_token' => $token,
            'error' => $error === '' ? null : ['code' => $error],
        ], JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
    }
}
