<?php

declare(strict_types=1);

namespace GlpiPlugin\Glpiacessivel\UI\Controller;

use GlpiPlugin\Glpiacessivel\Application\ConfigService;
use GlpiPlugin\Glpiacessivel\Application\FeatureReleasePolicy;
use GlpiPlugin\Glpiacessivel\Infrastructure\Ticket\NativeInteractionCreator;
use GlpiPlugin\Glpiacessivel\Support\Url;
use GlpiPlugin\Glpiacessivel\UI\View\View;

/** GET-only exposure; never accepts or forwards a creation payload. */
final class TicketInteractionCreateController extends BaseController
{
    public static function handle(): void
    {
        if (($_SERVER['REQUEST_METHOD'] ?? 'GET') !== 'GET') {
            http_response_code(405);
            if (!headers_sent()) {
                header('Allow: GET');
            }
            return;
        }
        self::requireLogin();
        if (!self::requireModuleEnabled(ConfigService::MODULE_TICKETS)) {
            return;
        }

        $context = null;
        $nativeForm = '';
        $error = '';
        try {
            FeatureReleasePolicy::requireAllowed('tickets.interaction_rich_add', true);
            [$ticketId, $kind] = self::requestContext($_GET);
            $creator = new NativeInteractionCreator();
            $context = $creator->context($ticketId, $kind);
            FeatureReleasePolicy::requireAllowed('tickets.interaction_rich_add', true);
            // Keep a single creation form: its existing plugin fields carry
            // the authorized task defaults and optional scheduling values.
            // Legacy links remain valid without importing or duplicating forms.
            header('Location: ' . Url::plugin('front/tickets.php?id=' . $ticketId)
                . '#itil-panel-' . $kind, true, 303);
            return;
        } catch (\Throwable $exception) {
            $context = null;
            $nativeForm = '';
            $notReleased = __('Esta funcionalidade não está liberada para seu perfil atual.', 'glpiacessivel');
            $error = in_array($exception->getMessage(), ['feature_release_not_allowed', $notReleased], true)
                ? $notReleased
                : __('Não foi possível confirmar o acesso à inclusão neste chamado. Volte ao chamado e confira seu perfil e entidade.', 'glpiacessivel');
            http_response_code(403);
        }

        $title = ($context['kind'] ?? '') === 'task'
            ? __('Adicionar tarefa com formatação', 'glpiacessivel')
            : __('Adicionar acompanhamento com formatação', 'glpiacessivel');
        $returnUrl = $context === null ? Url::plugin('front/tickets.php')
            : Url::plugin('front/tickets.php?id=' . (int) $context['ticket_id']) . '#itil-panel-' . $context['kind'];
        View::render('tickets/interaction-create', [
            'title' => $title,
            'creation_context' => $context,
            'native_interaction_form' => $nativeForm,
            'csrf_token' => $context !== null ? self::csrf()->token(true) : '',
            'error' => $error,
            'return_url' => $returnUrl,
        ]);
    }

    /** @return array{int,string} */
    private static function requestContext(array $query): array
    {
        $raw = $query['ticket_id'] ?? null;
        $kind = $query['kind'] ?? null;
        if (
            !is_scalar($raw) || preg_match('/\A[1-9][0-9]*\z/D', (string) $raw) !== 1
            || !is_string($kind) || !in_array($kind, ['followup', 'task'], true)
        ) {
            throw new \InvalidArgumentException('interaction_create_request_invalid');
        }
        $ticketId = filter_var($raw, FILTER_VALIDATE_INT);
        if (!is_int($ticketId) || $ticketId < 1) {
            throw new \InvalidArgumentException('interaction_create_request_invalid');
        }
        return [$ticketId, $kind];
    }
}
