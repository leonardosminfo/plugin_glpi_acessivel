<?php

declare(strict_types=1);

namespace GlpiPlugin\Glpiacessivel\Domain\Ticket;

/** The native text representation cannot be established before an update. */
final class NativeTicketDescriptionContractException extends \RuntimeException
{
}
