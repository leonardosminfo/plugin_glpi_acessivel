<?php

declare(strict_types=1);

namespace GlpiPlugin\Glpiacessivel\Domain\Knowledge;

interface KnowledgeSourceReader
{
    public function canReview(): bool;
    public function highWaterMark(): int;
    public function readForEditorialReview(int $id): array;
    public function readForAnswer(int $id): array;
    public function nextEditorialPage(int $after, int $highWater, int $limit, bool $faqOnly, string $publication = 'all'): array;
}
