<?php

declare(strict_types=1);

$cockpitStatistics = is_array($cockpitStatistics ?? null) ? $cockpitStatistics : [];
$statisticsEntrySafeUrl = static function ($url): string {
    if (!is_string($url) || preg_match('/[\x00-\x20\x7f\\\\]/', $url) === 1) {
        return '';
    }
    return str_starts_with($url, '/') && !str_starts_with($url, '//') ? $url : '';
};
$statisticsEntryUrl = !empty($cockpitStatistics['available'])
    ? $statisticsEntrySafeUrl($cockpitStatistics['url'] ?? '')
    : '';
$statisticsEntryConventional = [];
foreach (['assigned', 'tasks'] as $statisticsEntryMode) {
    $statisticsEntryCandidate = $statisticsEntrySafeUrl($cockpitStatistics['conventional_links'][$statisticsEntryMode] ?? '');
    if ($statisticsEntryCandidate !== '') {
        $statisticsEntryConventional[$statisticsEntryMode] = $statisticsEntryCandidate;
    }
}
?>
<?php if ($statisticsEntryUrl !== '' || $statisticsEntryConventional !== []): ?>
<section class="glpiacessivel-card glpiacessivel-native-statistics" aria-labelledby="cockpit-statistics">
  <h2 id="cockpit-statistics" tabindex="-1"><?= glpiacessivel_e(glpiacessivel_t('Estatísticas de chamados')) ?></h2>
  <p><?= glpiacessivel_e(glpiacessivel_t('Os indicadores acima mostram a situação atual. As estatísticas abaixo consultam um período e seguem os critérios do relatório nativo do GLPI.')) ?></p>
  <?php if ($statisticsEntryUrl !== ''): ?>
    <p><a id="cockpit-statistics-access" class="glpiacessivel-button" href="<?= glpiacessivel_e($statisticsEntryUrl) ?>"><?= glpiacessivel_e(glpiacessivel_t('Consultar estatísticas de chamados')) ?></a></p>
    <p><?= glpiacessivel_e(glpiacessivel_t('A consulta é feita somente após informar o período e selecionar Consultar estatísticas. A apresentação acessível contém quatro contagens, não todas as colunas do relatório convencional.')) ?></p>
  <?php endif; ?>
  <?php if ($statisticsEntryConventional !== []): ?>
    <h3><?= glpiacessivel_e(glpiacessivel_t('Alternativas na interface convencional')) ?></h3>
    <p id="cockpit-statistics-conventional-help"><?= glpiacessivel_e(glpiacessivel_t('Os relatórios abrem nesta mesma aba, respeitando seu contexto e suas permissões no GLPI. Para retornar, use Voltar no navegador. A acessibilidade da interface convencional pode ser diferente da apresentação do plugin.')) ?></p>
    <ul>
      <?php foreach ($statisticsEntryConventional as $statisticsEntryMode => $statisticsEntryCandidate): ?>
        <li><a id="cockpit-statistics-conventional-<?= glpiacessivel_e($statisticsEntryMode) ?>" href="<?= glpiacessivel_e($statisticsEntryCandidate) ?>" aria-describedby="cockpit-statistics-conventional-help" data-glpiacessivel-native-statistics-link><?= glpiacessivel_e($statisticsEntryMode === 'assigned' ? glpiacessivel_t('Estatísticas por técnico atribuído — interface convencional') : glpiacessivel_t('Estatísticas por técnico de tarefas — interface convencional')) ?></a></li>
      <?php endforeach; ?>
    </ul>
  <?php endif; ?>
</section>
<?php endif; ?>
