<?php
$featureCatalog = is_array($feature_catalog ?? null) ? $feature_catalog : [];
$featureValues = is_array($feature_values ?? null) ? $feature_values : [];
$featureEffective = is_array($feature_effective ?? null) ? $feature_effective : [];
$featureFieldErrors = is_array($feature_field_errors ?? null) ? $feature_field_errors : [];
$profileCatalog = is_array($profile_catalog ?? null) ? $profile_catalog : ['available' => false, 'profiles' => [], 'reason' => ''];
$modeLabels = [
    'off' => glpiacessivel_t('Desativada'),
    'profiles' => glpiacessivel_t('Liberada para perfis selecionados'),
    'all' => glpiacessivel_t('Liberada para todos os usuários autorizados'),
];
$profileNames = [];
foreach (($profileCatalog['profiles'] ?? []) as $profile) {
    $profileNames[(int) $profile['id']] = (string) $profile['name'];
}
$profileLabel = static function (int $id) use ($profileNames): string {
    return ($profileNames[$id] ?? glpiacessivel_t('Perfil não disponível no catálogo')) . ' (ID ' . $id . ')';
};
$formUrl = glpiacessivel_url('front/features.php');
$featureAssetPath = 'public/assets/js/feature-release.js';
$featureAssetVersion = function_exists('plugin_glpiacessivel_asset_version')
    ? plugin_glpiacessivel_asset_version($featureAssetPath)
    : (string) (@filemtime(__DIR__ . '/../../' . $featureAssetPath) ?: '1');
$featureAssetUrl = \GlpiPlugin\Glpiacessivel\Support\Url::asset($featureAssetPath . '?v=' . rawurlencode($featureAssetVersion));
$moduleLabels = [
    '' => glpiacessivel_t('Módulo do formulário em uso'),
    'tickets' => glpiacessivel_t('Chamados'),
    'playbooks' => glpiacessivel_t('Roteiros'),
    'cockpit' => glpiacessivel_t('Cockpit'),
    'chatbot' => glpiacessivel_t('Chatbot e roteiros'),
];
$lastGroup = '';
?>
<section class="glpiacessivel-card" aria-labelledby="feature-release-title">
  <h2 id="feature-release-title"><?= glpiacessivel_e(glpiacessivel_t('Liberação de funcionalidades')) ?></h2>
  <p><?= glpiacessivel_e(glpiacessivel_t('Controle quando as novidades ficam disponíveis. Estas escolhas não ampliam permissões: continuam valendo o perfil ativo, a entidade e as regras nativas do GLPI.')) ?></p>
  <p><?= glpiacessivel_e(glpiacessivel_t('Correções de segurança, integridade e acessibilidade permanecem aplicadas. Desativar não desfaz operações concluídas nem interrompe imediatamente uma operação já iniciada pelo GLPI.')) ?></p>
  <p><a href="<?= glpiacessivel_e(glpiacessivel_url('front/config.php')) ?>"><?= glpiacessivel_e(glpiacessivel_t('Voltar às configurações gerais')) ?></a></p>

  <?php if (!empty($review_required)) : ?>
    <p class="glpiacessivel-alert glpiacessivel-alert-warning"><?= glpiacessivel_e(glpiacessivel_t('A liberação precisa de revisão administrativa. Confira os estados efetivos abaixo: uma origem de atualização não confirmada mantém as novidades desativadas por segurança. Confirme uma revisão mesmo se desejar manter esses estados.')) ?></p>
  <?php endif; ?>

  <details class="glpiacessivel-card" id="interaction-release-coverage">
    <summary><?= glpiacessivel_e(glpiacessivel_t('Conferir a liberação da edição por perfil')) ?></summary>
    <p><?= glpiacessivel_e(glpiacessivel_t('A edição completa exige as duas opções de edição liberadas para o mesmo perfil. Esta prévia considera as escolhas em revisão; sem revisão, considera a configuração vigente. Não inclui a verificação dos direitos nativos de cada interação.')) ?></p>
    <p><?= glpiacessivel_e(glpiacessivel_t('Liberar a edição completa abre o formulário nativo também para texto simples. Não liberar mantém somente as ações simples permitidas. Nenhuma seleção será ativada ou ampliada automaticamente.')) ?></p>
    <?php if (empty($profileCatalog['available'])): ?>
      <p><?= glpiacessivel_e(glpiacessivel_t('Não foi possível conferir os perfis. Recarregue o catálogo antes de confirmar a liberação da edição.')) ?></p>
    <?php elseif (empty($interaction_coverage)): ?>
      <p><?= glpiacessivel_e(glpiacessivel_t('Nenhum perfil do catálogo está selecionado para edição.')) ?></p>
    <?php else: ?>
      <ul>
        <?php foreach ($interaction_coverage as $coverage): ?>
          <li><?= glpiacessivel_e($profileLabel((int) $coverage['id'])) ?>:
            <?= glpiacessivel_e($coverage['complete'] ? glpiacessivel_t('Edição completa selecionada')
                : ($coverage['incomplete'] ? glpiacessivel_t('Combinação incompleta: falta liberar a edição básica para este perfil')
                : glpiacessivel_t('Somente texto simples e visibilidade, conforme a interação'))) ?>.
          </li>
        <?php endforeach; ?>
      </ul>
    <?php endif; ?>
  </details>

  <?php if (!empty($errors) || $featureFieldErrors !== []) : ?>
    <div id="feature-release-result" class="glpiacessivel-alert glpiacessivel-alert-danger" role="alert" tabindex="-1" data-glpiacessivel-focus-alert>
      <h3><?= glpiacessivel_e(glpiacessivel_t('Confira a configuração antes de continuar')) ?></h3>
      <ul><?php foreach ($errors as $error) :
            ?><li><?= glpiacessivel_e($error) ?></li><?php
          endforeach; ?></ul>
        <?php if ($featureFieldErrors !== []) : ?>
        <ul>
            <?php foreach ($featureFieldErrors as $id => $fieldError) : ?>
            <li><a href="#feature-<?= glpiacessivel_e(str_replace('.', '-', $id)) ?>"><?= glpiacessivel_e(glpiacessivel_t($featureCatalog[$id]['label'])) ?>: <?= glpiacessivel_e($fieldError) ?></a></li>
            <?php endforeach; ?>
        </ul>
        <?php endif; ?>
      <a href="#feature-release-fields"><?= glpiacessivel_e(glpiacessivel_t('Conferir os estados e os perfis selecionados')) ?></a>
    </div>
  <?php endif; ?>

  <?php if (!empty($review_token)) : ?>
    <section id="feature-release-review" aria-labelledby="feature-release-review-title">
      <h3 id="feature-release-review-title" tabindex="-1" data-glpiacessivel-focus-alert><?= glpiacessivel_e(glpiacessivel_t('Revisar alterações de liberação')) ?></h3>
      <p><?= glpiacessivel_e(glpiacessivel_t('Nada foi salvo ainda. Confira as mudanças abaixo. Esta revisão vale por 10 minutos e será invalidada se o perfil, a entidade ou a configuração vigente mudar.')) ?></p>
      <p><?= glpiacessivel_e(glpiacessivel_t('A liberação só terá efeito quando o módulo correspondente estiver habilitado, a funcionalidade for suportada e a operação estiver autorizada pelo GLPI. Liberar não habilita módulos automaticamente.')) ?></p>
        <?php if (empty($changes)) : ?>
        <p><?= glpiacessivel_e(glpiacessivel_t('Nenhum estado será alterado. Ao confirmar, você registra a revisão administrativa e mantém as escolhas conferidas na etapa anterior.')) ?></p>
        <?php endif; ?>
        <?php foreach (($changes ?? []) as $id => $change) : ?>
        <section class="glpiacessivel-card" aria-labelledby="review-<?= glpiacessivel_e(str_replace('.', '-', $id)) ?>">
          <h4 id="review-<?= glpiacessivel_e(str_replace('.', '-', $id)) ?>"><?= glpiacessivel_e(glpiacessivel_t($change['label'])) ?></h4>
          <dl>
            <?php foreach (['before' => glpiacessivel_t('Antes'), 'after' => glpiacessivel_t('Depois')] as $side => $sideLabel) : ?>
              <dt><?= glpiacessivel_e($sideLabel) ?></dt>
              <dd><?= glpiacessivel_e($modeLabels[$change[$side]['mode']] ?? glpiacessivel_t('Configuração inválida')) ?>
                <?php if ($change[$side]['mode'] === 'profiles') : ?>
                  <ul><?php foreach ($change[$side]['profile_ids'] as $profileId) :
                        ?><li><?= glpiacessivel_e($profileLabel((int) $profileId)) ?></li><?php
                      endforeach; ?></ul>
                <?php endif; ?>
              </dd>
            <?php endforeach; ?>
          </dl>
            <?php if (($featureCatalog[$id]['module'] ?? '') === 'tickets' || str_starts_with($id, 'playbooks.')) : ?>
            <p><?= glpiacessivel_e(glpiacessivel_t('Confira especialmente o público das ações que gravam dados. Desativar impede novas operações específicas pelo plugin, mas não desfaz alterações concluídas.')) ?></p>
            <?php endif; ?>
        </section>
        <?php endforeach; ?>
      <form method="post" action="<?= glpiacessivel_e($formUrl) ?>">
        <input type="hidden" name="_glpi_csrf_token" value="<?= glpiacessivel_e($csrf_token) ?>">
        <input type="hidden" name="review_token" value="<?= glpiacessivel_e($review_token) ?>">
        <button class="glpiacessivel-button" type="submit" name="feature_action" value="confirm"><?= glpiacessivel_e(glpiacessivel_t('Confirmar liberação')) ?></button>
        <button class="glpiacessivel-button glpiacessivel-button-secondary" type="submit" name="feature_action" value="edit"><?= glpiacessivel_e(glpiacessivel_t('Voltar para editar')) ?></button>
      </form>
    </section>
  <?php else : ?>
      <?php if (empty($profileCatalog['available'])) : ?>
      <p class="glpiacessivel-alert glpiacessivel-alert-warning"><?= glpiacessivel_e(glpiacessivel_t('O catálogo de perfis está indisponível. Não é possível confirmar liberação por perfis enquanto o catálogo não puder ser validado. As seleções existentes não serão convertidas para todos.')) ?></p>
      <?php endif; ?>
    <form id="feature-release-fields" method="post" action="<?= glpiacessivel_e($formUrl) ?>" aria-describedby="feature-release-help" tabindex="-1">
      <input type="hidden" name="_glpi_csrf_token" value="<?= glpiacessivel_e($csrf_token) ?>">
      <input type="hidden" name="revision" value="<?= glpiacessivel_e($revision) ?>">
      <input type="hidden" name="feature_action" value="review">
      <p id="feature-release-help"><?= glpiacessivel_e(glpiacessivel_t('Escolha um estado para cada funcionalidade. A lista de perfis só se aplica à opção por perfis selecionados e exige ao menos um perfil válido. As opções não são salvas automaticamente.')) ?></p>
      <?php foreach ($featureCatalog as $id => $definition) : ?>
            <?php $fieldId = 'feature-' . str_replace('.', '-', $id);
            $value = $featureValues[$id] ?? ['mode' => 'off', 'profile_ids' => []];
            $group = str_starts_with($id, 'reports.') ? glpiacessivel_t('Relatórios')
                : (str_starts_with($id, 'playbooks.') ? glpiacessivel_t('Roteiros') : glpiacessivel_t('Chamados'));
            ?>
            <?php if ($lastGroup !== $group) : ?>
          <h3><?= glpiacessivel_e($group) ?></h3>
            <?php endif; ?>
            <?php $lastGroup = $group; ?>
        <fieldset id="<?= glpiacessivel_e($fieldId) ?>" class="glpiacessivel-module-card" aria-describedby="<?= glpiacessivel_e($fieldId) ?>-help<?= isset($featureFieldErrors[$id]) ? ' ' . glpiacessivel_e($fieldId) . '-error' : '' ?>" <?= isset($featureFieldErrors[$id]) ? 'aria-invalid="true"' : '' ?> tabindex="-1" data-feature-release>
          <legend><?= glpiacessivel_e(glpiacessivel_t($definition['label'])) ?></legend>
          <p id="<?= glpiacessivel_e($fieldId) ?>-help"><?= glpiacessivel_e(glpiacessivel_t($definition['description'])) ?></p>
          <p><?= glpiacessivel_e(glpiacessivel_t('Situação vigente, antes de salvar este formulário:')) ?>
            <strong><?= glpiacessivel_e(!empty($featureEffective[$id])
                ? glpiacessivel_t('Liberada pela política para seu perfil ativo')
                : glpiacessivel_t('Não liberada pela política para seu perfil ativo')) ?></strong>.
            <?= glpiacessivel_e(glpiacessivel_t('As permissões nativas e a autorização da operação continuam obrigatórias.')) ?>
          </p>
            <?php if (isset($featureFieldErrors[$id])) : ?>
            <p id="<?= glpiacessivel_e($fieldId) ?>-error" class="glpiacessivel-alert glpiacessivel-alert-danger"><?= glpiacessivel_e($featureFieldErrors[$id]) ?></p>
            <?php endif; ?>
          <p><?= glpiacessivel_e(glpiacessivel_t('Dependência: módulo habilitado e permissões nativas correspondentes.')) ?> <?= glpiacessivel_e($moduleLabels[$definition['module']] ?? $definition['module']) ?></p>
            <?php foreach ($modeLabels as $mode => $label) : ?>
            <div>
              <input id="<?= glpiacessivel_e($fieldId . '-' . $mode) ?>" type="radio" name="features[<?= glpiacessivel_e($id) ?>][mode]" value="<?= glpiacessivel_e($mode) ?>" <?= $value['mode'] === $mode ? 'checked' : '' ?> required>
              <label for="<?= glpiacessivel_e($fieldId . '-' . $mode) ?>"><?= glpiacessivel_e($label) ?></label>
            </div>
            <?php endforeach; ?>
          <fieldset data-feature-release-profiles>
            <legend><?= glpiacessivel_e(glpiacessivel_t('Perfis selecionados para esta funcionalidade')) ?></legend>
            <p><?= glpiacessivel_e(glpiacessivel_t('A seleção vale somente quando o modo por perfis estiver escolhido. Ao salvar Desativada ou Todos, esta lista não será mantida como seleção efetiva.')) ?></p>
            <?php foreach ($profileNames as $profileId => $profileName) : ?>
              <div>
                <input id="<?= glpiacessivel_e($fieldId . '-profile-' . $profileId) ?>" type="checkbox" name="features[<?= glpiacessivel_e($id) ?>][profile_ids][]" value="<?= (int) $profileId ?>" <?= in_array($profileId, $value['profile_ids'], true) ? 'checked' : '' ?> <?= empty($profileCatalog['available']) ? 'disabled' : '' ?>>
                <label for="<?= glpiacessivel_e($fieldId . '-profile-' . $profileId) ?>"><?= glpiacessivel_e($profileLabel($profileId)) ?></label>
              </div>
            <?php endforeach; ?>
            <?php foreach ($value['profile_ids'] as $profileId) : ?>
                <?php if (!isset($profileNames[(int) $profileId])) : ?>
                <p class="glpiacessivel-help-text"><?= glpiacessivel_e($profileLabel((int) $profileId)) ?> — <?= glpiacessivel_e(glpiacessivel_t('Seleção anterior inválida ou indisponível; confira antes de confirmar.')) ?></p>
                <?php endif; ?>
            <?php endforeach; ?>
          </fieldset>
        </fieldset>
      <?php endforeach; ?>
      <p><?= glpiacessivel_e(glpiacessivel_t('Na próxima etapa serão mostradas somente as alterações, antes de qualquer gravação.')) ?></p>
      <button class="glpiacessivel-button" type="submit"><?= glpiacessivel_e(glpiacessivel_t('Revisar alterações')) ?></button>
      <input type="hidden" name="_feature_release_complete" value="complete">
    </form>
  <?php endif; ?>
</section>
<script src="<?= glpiacessivel_e($featureAssetUrl) ?>" defer></script>
