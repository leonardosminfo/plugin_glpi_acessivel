<?php
$attachmentDocuments = is_array($interaction_documents ?? null) ? $interaction_documents : [];
$nativeAttachmentActions = is_array($native_attachment_actions ?? null) ? $native_attachment_actions : [];
$actionDocuments = [];
foreach ((array) ($nativeAttachmentActions['documents'] ?? []) as $entry) {
    $actionDocuments[(int) ($entry['id'] ?? 0)] = $entry;
}
?>
<section aria-labelledby="interaction-attachments-heading" class="glpiacessivel-attachment-reader">
  <h3 id="interaction-attachments-heading"><?= glpiacessivel_e(__('Arquivos anexados a esta interação', 'glpiacessivel')) ?></h3>
  <p><?= glpiacessivel_e(__('Estes arquivos já estão vinculados à interação. Abrir um arquivo não o insere no texto nem altera seu conteúdo.', 'glpiacessivel')) ?></p>
  <?php if ($attachmentDocuments === []): ?>
    <p><?= glpiacessivel_e(__('Nenhum arquivo disponível para leitura nesta interação.', 'glpiacessivel')) ?></p>
  <?php endif; ?>
  <ul class="glpiacessivel-list glpiacessivel-document-list">
    <?php foreach ($attachmentDocuments as $document): ?>
      <?php $docId = (int) ($document['id'] ?? 0); $name = (string) ($document['display_name'] ?? ''); $entry = $actionDocuments[$docId] ?? []; ?>
      <li>
        <h4 id="attachment-<?= $docId ?>"><?= glpiacessivel_e($name) ?></h4>
        <dl class="glpiacessivel-document-meta">
          <div><dt><?= glpiacessivel_e(__('Formato', 'glpiacessivel')) ?></dt><dd><?= glpiacessivel_e((string) ($document['mime'] ?? '') ?: __('Tipo não informado', 'glpiacessivel')) ?></dd></div>
          <div><dt><?= glpiacessivel_e(__('Tamanho', 'glpiacessivel')) ?></dt><dd><?= glpiacessivel_e((int) ($document['size'] ?? 0) > 0 ? number_format((int) $document['size'], 0, ',', '.') . ' B' : __('Tamanho não informado', 'glpiacessivel')) ?></dd></div>
        </dl>
        <?php if (!empty($document['descriptions'])): ?>
          <p><strong><?= glpiacessivel_e(__('Descrição da imagem nesta interação', 'glpiacessivel')) ?>:</strong></p>
          <ul><?php foreach ((array) $document['descriptions'] as $description): ?><li><?= glpiacessivel_e((string) $description) ?></li><?php endforeach; ?></ul>
        <?php elseif (!empty($document['is_image'])): ?>
          <p><?= glpiacessivel_e(__('Descrição do conteúdo não informada.', 'glpiacessivel')) ?></p>
        <?php endif; ?>
        <?php if (trim((string) ($document['comment'] ?? '')) !== ''): ?>
          <p><strong><?= glpiacessivel_e(__('Comentário cadastrado no documento', 'glpiacessivel')) ?>:</strong><br><?= nl2br(glpiacessivel_e(trim((string) $document['comment']))) ?></p>
        <?php endif; ?>
        <p><a href="<?= glpiacessivel_e((string) ($document['download_url'] ?? '')) ?>" target="_blank" rel="noopener noreferrer"><?= glpiacessivel_e(sprintf(__('Abrir %s (abre em nova aba)', 'glpiacessivel'), $name)) ?></a></p>
        <?php if (!empty($document['is_image'])): ?>
          <details>
            <summary><?= glpiacessivel_e(sprintf(__('Mostrar prévia de %s', 'glpiacessivel'), $name)) ?></summary>
            <img class="glpiacessivel-attachment-preview" loading="lazy" src="<?= glpiacessivel_e((string) $document['download_url']) ?>" alt="<?= glpiacessivel_e(implode(' — ', (array) ($document['descriptions'] ?? []))) ?>">
            <p><?= glpiacessivel_e(__('A prévia é um apoio visual. O nome do arquivo não descreve o conteúdo da imagem.', 'glpiacessivel')) ?></p>
          </details>
        <?php endif; ?>
        <?php if (!empty($entry['has_actions']) && (string) ($entry['actions_html'] ?? '') !== ''): ?>
          <details class="glpiacessivel-card" aria-labelledby="attachment-actions-<?= $docId ?>">
            <summary id="attachment-actions-<?= $docId ?>"<?= (string) ($entry['effects_text'] ?? '') !== '' ? ' aria-describedby="attachment-effects-' . $docId . '"' : '' ?>><?= glpiacessivel_e(sprintf(__('Opções do GLPI para %s', 'glpiacessivel'), $name)) ?></summary>
            <p id="attachment-effects-<?= $docId ?>"><?= glpiacessivel_e((string) ($entry['effects_text'] ?? '')) ?></p>
            <?php // Trusted controls produced by the authorized native renderer only. ?>
            <?= $entry['actions_html'] ?>
          </details>
        <?php endif; ?>
      </li>
    <?php endforeach; ?>
  </ul>
</section>
