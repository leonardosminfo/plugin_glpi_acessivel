<?php
$interaction = is_array($interaction ?? null) ? $interaction : null;
$draft = (array) ($draft ?? []);
$error = (string) ($error ?? '');
$outcome = (string) ($outcome ?? '');
$formAvailable = $interaction !== null && (string) ($edit_token ?? '') !== '';
$content = (string) ($draft['content'] ?? $interaction['content'] ?? '');
$privacy = (int) ($draft['is_private'] ?? $interaction['is_private'] ?? 0);
$nativeInteractionForm = (string) ($native_interaction_form ?? '');
$hasRichFields = $nativeInteractionForm !== '' && preg_match('/<\/?form\b/i', $nativeInteractionForm) !== 1;
$editorMode = (string) ($editor_mode ?? 'unavailable');
$editorTitle = \GlpiPlugin\Glpiacessivel\Application\InteractionEditPresentation::title($editorMode, (string) ($interaction['kind'] ?? ''));
$interactionDocuments = is_array($interaction_documents ?? null) ? $interaction_documents : [];
?>
<section class="glpiacessivel-card" aria-labelledby="interaction-editor-heading">
  <h2 id="interaction-editor-heading" tabindex="-1"><?= glpiacessivel_e($editorTitle) ?></h2>
  <?php if ($error !== ''): ?>
    <div id="interaction-edit-error" class="glpiacessivel-alert glpiacessivel-alert-warning" role="alert" tabindex="-1" data-glpiacessivel-focus-alert>
      <p><?= glpiacessivel_e($error) ?></p>
    </div>
  <?php endif; ?>
  <?php if ($interaction !== null): ?>
    <p><?= glpiacessivel_e(sprintf(
        __('Chamado #%1$d — %2$s #%3$d', 'glpiacessivel'),
        (int) $interaction['ticket_id'],
        $interaction['kind'] === 'task' ? __('Tarefa', 'glpiacessivel') : __('Acompanhamento', 'glpiacessivel'),
        (int) $interaction['interaction_id']
    )) ?></p>
    <?php if ($editorMode === 'visibility'): ?>
      <p><?= glpiacessivel_e(__('Nesta ação, altere apenas quem pode visualizar a interação. O texto, as imagens e os anexos serão mantidos.', 'glpiacessivel')) ?></p>
    <?php elseif (in_array($editorMode, ['recovery', 'unavailable'], true)): ?>
      <p role="status"><?= glpiacessivel_e($editorMode === 'recovery'
          ? __('Não foi possível abrir a edição. Volte ao chamado e tente novamente. Nenhuma alteração foi enviada.', 'glpiacessivel')
          : __('A edição desta interação não está disponível neste portal para seu perfil atual.', 'glpiacessivel')) ?></p>
      <?php if ((string) $interaction['native_ticket_url'] !== ''): ?>
        <p><a href="<?= glpiacessivel_e((string) $interaction['native_ticket_url']) ?>"><?= glpiacessivel_e(__('Abrir chamado na interface convencional', 'glpiacessivel')) ?></a></p>
      <?php endif; ?>
    <?php endif; ?>
  <?php endif; ?>

  <?php if ($formAvailable && ($hasRichFields || in_array($editorMode, ['simple', 'text', 'visibility'], true))): ?>
    <form method="post" action="<?= glpiacessivel_e(glpiacessivel_url('front/ticket.interaction.php')) ?>" enctype="multipart/form-data" class="glpiacessivel-form" data-submit-once>
      <input type="hidden" name="_glpi_csrf_token" value="<?= glpiacessivel_e((string) $csrf_token) ?>" />
      <input type="hidden" name="edit_token" value="<?= glpiacessivel_e((string) $edit_token) ?>" />
      <?php if ($hasRichFields): ?>
        <input type="hidden" name="rich_mode" value="1" />
        <div class="glpiacessivel-field">
          <label for="interaction-content"><?= glpiacessivel_e(__('Texto da interação', 'glpiacessivel')) ?></label>
          <p id="interaction-native-help" class="glpiacessivel-help-text"><?= glpiacessivel_e(__('Edite o texto e as imagens. Para acessar a barra de ferramentas pelo teclado, use Alt+F10. Ao terminar, selecione Salvar alterações.', 'glpiacessivel')) ?></p>
          <div class="glpiacessivel-native-interaction-editor" aria-describedby="interaction-native-help<?= $error !== '' ? ' interaction-edit-error' : '' ?>" data-glpiacessivel-rich-fields data-glpiacessivel-native-interaction-editor data-glpiacessivel-content-label="<?= glpiacessivel_e(__('Texto da interação', 'glpiacessivel')) ?>">
            <?php // Authorized editor/uploader fragment only; the plugin owns the surrounding form. ?>
            <?= $nativeInteractionForm ?>
          </div>
          <p class="glpiacessivel-help-text"><?= glpiacessivel_e(__('Retirar uma imagem do texto não exclui o arquivo anexado. Os arquivos existentes continuam disponíveis abaixo.', 'glpiacessivel')) ?></p>
        </div>
      <?php elseif (!empty($interaction['can_edit_content'])): ?>
        <label for="interaction-content"><?= glpiacessivel_e(__('Texto da interação', 'glpiacessivel')) ?></label>
        <textarea id="interaction-content" name="content" rows="10" aria-describedby="interaction-content-help<?= $error !== '' ? ' interaction-edit-error' : '' ?>"<?= $error !== '' ? ' aria-invalid="true"' : '' ?>><?= glpiacessivel_e($content) ?></textarea>
        <p id="interaction-content-help" class="glpiacessivel-help-text"><?= glpiacessivel_e(__('Altere o texto e salve para registrar a atualização. Os arquivos já anexados serão mantidos.', 'glpiacessivel')) ?></p>
      <?php endif; ?>
      <?php if (!empty($interaction['can_change_privacy'])): ?>
        <fieldset aria-describedby="interaction-privacy-help<?= $error !== '' ? ' interaction-edit-error' : '' ?>">
          <legend><?= glpiacessivel_e(__('Visibilidade', 'glpiacessivel')) ?></legend>
          <label><input type="radio" name="is_private" value="0" required<?= $privacy === 0 ? ' checked' : '' ?> /> <?= glpiacessivel_e(__('Público', 'glpiacessivel')) ?></label>
          <label><input type="radio" name="is_private" value="1" required<?= $privacy === 1 ? ' checked' : '' ?> /> <?= glpiacessivel_e(__('Privado', 'glpiacessivel')) ?></label>
          <p id="interaction-privacy-help"><?= glpiacessivel_e(__('Tornar público pode expor esta interação aos participantes autorizados. Tornar privado não recolhe notificações anteriores. Os documentos permanecem vinculados ao objeto nativo.', 'glpiacessivel')) ?></p>
        </fieldset>
      <?php else: ?>
        <p><?= glpiacessivel_e(__('A visibilidade atual será preservada. Esse controle não está disponível nesta interface convencional.', 'glpiacessivel')) ?></p>
      <?php endif; ?>
      <?php if ($hasRichFields || !empty($interaction['can_edit_content']) || !empty($interaction['can_change_privacy'])): ?>
        <button class="glpiacessivel-button" type="submit"><?= glpiacessivel_e($editorMode === 'visibility' ? __('Salvar visibilidade', 'glpiacessivel') : __('Salvar alterações', 'glpiacessivel')) ?></button>
      <?php endif; ?>
    </form>
  <?php elseif ($interaction !== null && in_array($outcome, ['rejected', 'uncertain'], true)): ?>
    <div class="glpiacessivel-alert glpiacessivel-alert-warning" role="alert" tabindex="-1" data-glpiacessivel-focus-alert>
      <p><?= glpiacessivel_e(__('O salvamento não foi confirmado. Confira a interação no chamado antes de abrir uma nova edição. Não reenvie o formulário anterior.', 'glpiacessivel')) ?></p>
    </div>
    <?php if (array_key_exists('content', $draft)): ?>
      <label for="interaction-rejected-draft"><?= glpiacessivel_e(__('Rascunho não confirmado — copie se necessário', 'glpiacessivel')) ?></label>
      <textarea id="interaction-rejected-draft" rows="10" readonly><?= glpiacessivel_e($content) ?></textarea>
    <?php endif; ?>
  <?php endif; ?>
  <?php if ($interaction !== null && $interactionDocuments !== []): ?>
    <?php require __DIR__ . '/attachment-list.php'; ?>
    <p><a href="<?= glpiacessivel_e(glpiacessivel_url('front/ticket.attachments.php?' . http_build_query(['ticket_id' => (int) $interaction['ticket_id'], 'kind' => (string) $interaction['kind'], 'interaction_id' => (int) $interaction['interaction_id']]))) ?>"><?= glpiacessivel_e(__('Consultar anexos e opções disponíveis', 'glpiacessivel')) ?></a></p>
  <?php endif; ?>
  <p><a class="glpiacessivel-button glpiacessivel-button-secondary" href="<?= glpiacessivel_e((string) $return_url) ?>"><?= glpiacessivel_e($formAvailable ? __('Cancelar e voltar sem enviar alterações', 'glpiacessivel') : __('Voltar ao chamado', 'glpiacessivel')) ?></a></p>
</section>
