<?php
// Include once per authorized document, OUTSIDE the interaction's edit form.
$nativeAttachmentActions = is_array($nativeAttachmentActions ?? null) ? $nativeAttachmentActions : [];
?>
<?php if (!empty($nativeAttachmentActions['has_actions']) && is_string($nativeAttachmentActions['actions_html'] ?? null)): ?>
  <div data-glpiacessivel-native-attachment-actions>
    <?php // Trusted, scope-checked controls rendered by the installed native Twig; not user HTML. ?>
    <?= $nativeAttachmentActions['actions_html'] ?>
    <?php if ((string) ($nativeAttachmentActions['effects_text'] ?? '') !== ''): ?>
      <p><?= glpiacessivel_e((string) $nativeAttachmentActions['effects_text']) ?></p>
    <?php endif; ?>
  </div>
<?php endif; ?>
