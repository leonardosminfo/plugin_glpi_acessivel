<?php
$attachmentContext = is_array($attachment_context ?? null) ? $attachment_context : null;
?>
<section class="glpiacessivel-card" aria-labelledby="attachments-title">
  <h2 id="attachments-title" tabindex="-1"><?= glpiacessivel_e(__('Anexos da interação', 'glpiacessivel')) ?></h2>
  <?php if ($attachmentContext === null): ?>
    <p><?= glpiacessivel_e(__('Os anexos não estão disponíveis neste contexto. Volte ao chamado e confira seu acesso.', 'glpiacessivel')) ?></p>
  <?php else: ?>
    <p><?= glpiacessivel_e(sprintf(__('Chamado #%1$d — %2$s #%3$d', 'glpiacessivel'), (int) $attachmentContext['ticket_id'], $attachmentContext['kind'] === 'task' ? __('Tarefa', 'glpiacessivel') : __('Acompanhamento', 'glpiacessivel'), (int) $attachmentContext['interaction_id'])) ?></p>
    <?php require __DIR__ . '/attachment-list.php'; ?>
  <?php endif; ?>
  <p><a href="<?= glpiacessivel_e((string) $return_url) ?>"><?= glpiacessivel_e(__('Voltar ao chamado', 'glpiacessivel')) ?></a></p>
</section>
