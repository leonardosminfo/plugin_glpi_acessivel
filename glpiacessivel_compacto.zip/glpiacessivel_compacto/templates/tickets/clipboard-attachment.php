<?php
/** Presentation-only enhancement: uses the existing multipart file control. */
if (!\GlpiPlugin\Glpiacessivel\Application\FeatureReleasePolicy::allows('tickets.clipboard_images')) {
    // The regular multipart file selector and native upload validation remain available.
    return;
}
$clipboardInputId = (string) ($clipboardInputId ?? '');
$clipboardEditorId = (string) ($clipboardEditorId ?? '');
$clipboardPrefix = $clipboardInputId . '-clipboard';
?>
<div data-glpiacessivel-clipboard-attachments
     data-file-input="<?= glpiacessivel_e($clipboardInputId) ?>"
     data-editor="<?= glpiacessivel_e($clipboardEditorId) ?>"
     data-remove-label="<?= glpiacessivel_e(__('Remover', 'glpiacessivel')) ?>"
     data-removed-label="<?= glpiacessivel_e(__('Anexo removido da seleção.', 'glpiacessivel')) ?>"
     data-added-label="<?= glpiacessivel_e(__('Imagem adicionada aos anexos pendentes. Revise antes de enviar.', 'glpiacessivel')) ?>"
     data-unsupported-label="<?= glpiacessivel_e(__('Use Selecionar arquivos para anexar a imagem neste navegador.', 'glpiacessivel')) ?>">
  <noscript><p><?= glpiacessivel_e(__('A colagem requer JavaScript. Use o seletor de arquivos acima para anexar a imagem.', 'glpiacessivel')) ?></p></noscript>
  <label for="<?= glpiacessivel_e($clipboardPrefix) ?>"><?= glpiacessivel_e(__('Colar imagem como anexo', 'glpiacessivel')) ?></label>
  <textarea id="<?= glpiacessivel_e($clipboardPrefix) ?>" rows="2" data-clipboard-zone
            aria-describedby="<?= glpiacessivel_e($clipboardPrefix) ?>-help"></textarea>
  <small id="<?= glpiacessivel_e($clipboardPrefix) ?>-help" class="glpiacessivel-help-text"><?= glpiacessivel_e(__('Copie o print e use Colar nesta área ou na descrição. A imagem será anexada ao enviar o formulário, com os mesmos limites e validações do GLPI. Você também pode selecionar um arquivo. Esta área não envia texto.', 'glpiacessivel')) ?></small>
  <p role="status" aria-live="polite" aria-atomic="true" data-clipboard-status></p>
  <ul class="glpiacessivel-file-list" data-clipboard-files></ul>
</div>
