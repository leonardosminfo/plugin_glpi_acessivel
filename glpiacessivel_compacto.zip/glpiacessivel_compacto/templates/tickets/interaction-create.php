<?php
$creationContext = is_array($creation_context ?? null) ? $creation_context : null;
$nativeInteractionForm = (string) ($native_interaction_form ?? '');
$hasRichFields = $nativeInteractionForm !== '' && preg_match('/<\/?form\b/i', $nativeInteractionForm) !== 1;
$kind = (string) ($creationContext['kind'] ?? 'followup');
$privacyName = $kind === 'task' ? 'task_is_private' : 'followup_is_private';
$privacy = (int) ($creationContext['default_is_private'] ?? 0);
$error = (string) ($error ?? '');
?>
<section class="glpiacessivel-card" aria-labelledby="interaction-create-heading">
  <h2 id="interaction-create-heading" tabindex="-1"><?= glpiacessivel_e((string) $title) ?></h2>
  <?php if ($error !== ''): ?>
    <p class="glpiacessivel-alert glpiacessivel-alert-warning" role="alert" tabindex="-1" data-glpiacessivel-focus-alert><?= glpiacessivel_e($error) ?></p>
  <?php elseif ($creationContext !== null && $hasRichFields): ?>
    <p><?= glpiacessivel_e(sprintf(__('Chamado #%d', 'glpiacessivel'), (int) $creationContext['ticket_id'])) ?></p>
    <form method="post" action="<?= glpiacessivel_e(glpiacessivel_url('front/ticket.action.php')) ?>" enctype="multipart/form-data" class="glpiacessivel-form glpiacessivel-itil-action-form" data-submit-once>
      <input type="hidden" name="_glpi_csrf_token" value="<?= glpiacessivel_e((string) ($csrf_token ?? '')) ?>" />
      <input type="hidden" name="ticket_id" value="<?= (int) $creationContext['ticket_id'] ?>" />
      <input type="hidden" name="action" value="<?= glpiacessivel_e($kind) ?>" />
      <input type="hidden" name="rich_mode" value="1" />
      <div class="glpiacessivel-field">
        <label for="interaction-create-content"><?= glpiacessivel_e($kind === 'task' ? __('Descrição da tarefa', 'glpiacessivel') : __('Descrição do acompanhamento', 'glpiacessivel')) ?> *</label>
        <p id="interaction-create-help" class="glpiacessivel-help-text"><?= glpiacessivel_e(__('Descreva o atendimento. Você também pode inserir imagens e anexar arquivos. Para acessar a barra de ferramentas pelo teclado, use Alt+F10.', 'glpiacessivel')) ?></p>
        <div class="glpiacessivel-native-interaction-editor" aria-describedby="interaction-create-help" data-glpiacessivel-rich-fields data-glpiacessivel-native-interaction-creator data-glpiacessivel-content-label="<?= glpiacessivel_e($kind === 'task' ? __('Descrição da tarefa', 'glpiacessivel') : __('Descrição do acompanhamento', 'glpiacessivel')) ?>">
          <?php // Authorized editor/uploader fragment only; no complete native form. ?>
          <?= $nativeInteractionForm ?>
        </div>
      </div>
      <?php if (!empty($creationContext['can_change_privacy'])): ?>
        <fieldset aria-describedby="interaction-create-privacy-help">
          <legend><?= glpiacessivel_e(__('Visibilidade', 'glpiacessivel')) ?></legend>
          <label><input type="radio" name="<?= glpiacessivel_e($privacyName) ?>" value="0" required<?= $privacy === 0 ? ' checked' : '' ?> /> <?= glpiacessivel_e(__('Público', 'glpiacessivel')) ?></label>
          <label><input type="radio" name="<?= glpiacessivel_e($privacyName) ?>" value="1" required<?= $privacy === 1 ? ' checked' : '' ?> /> <?= glpiacessivel_e(__('Privado', 'glpiacessivel')) ?></label>
          <p id="interaction-create-privacy-help" class="glpiacessivel-help-text"><?= glpiacessivel_e(__('Público fica disponível aos participantes autorizados do chamado. Privado fica restrito aos perfis autorizados pelo GLPI.', 'glpiacessivel')) ?></p>
        </fieldset>
      <?php else: ?>
        <input type="hidden" name="<?= glpiacessivel_e($privacyName) ?>" value="<?= $privacy === 1 ? 1 : 0 ?>" />
      <?php endif; ?>
      <button class="glpiacessivel-button" type="submit"><?= glpiacessivel_e($kind === 'task' ? __('Adicionar tarefa', 'glpiacessivel') : __('Adicionar acompanhamento', 'glpiacessivel')) ?></button>
    </form>
  <?php elseif ($creationContext !== null): ?>
    <p role="status"><?= glpiacessivel_e(__('Não foi possível abrir o editor. Nenhuma interação foi enviada. Volte ao chamado e tente novamente.', 'glpiacessivel')) ?></p>
  <?php endif; ?>
  <?php if ($creationContext !== null && (string) $creationContext['native_ticket_url'] !== ''): ?>
    <p><a href="<?= glpiacessivel_e((string) $creationContext['native_ticket_url']) ?>"><?= glpiacessivel_e(__('Abrir chamado na interface convencional', 'glpiacessivel')) ?></a></p>
  <?php endif; ?>
  <p><a class="glpiacessivel-button glpiacessivel-button-secondary" href="<?= glpiacessivel_e((string) $return_url) ?>"><?= glpiacessivel_e(__('Cancelar e voltar sem adicionar', 'glpiacessivel')) ?></a></p>
</section>
