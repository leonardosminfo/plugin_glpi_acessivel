<?php

$flow = is_array($flow ?? null) ? $flow : [];
$stage = (string) ($flow['stage'] ?? 'unknown');
$mode = (string) ($flow['mode'] ?? 'parameters');
$ids = is_array($flow['ids'] ?? null) ? $flow['ids'] : [];
$native = is_array($flow['native'] ?? null) ? $flow['native'] : [];
$actions = is_array($native['actions'] ?? null) ? $native['actions'] : [];
$form = is_array($flow['form'] ?? null) ? $flow['form'] : [];
$controls = is_array($form['controls'] ?? null) ? $form['controls'] : [];
$values = is_array($flow['values'] ?? null) ? $flow['values'] : [];
$lookup = is_array($form['lookup'] ?? null) ? $form['lookup'] : [];
$result = is_array($flow['result'] ?? null) ? $flow['result'] : [];
$counters = is_array($result['counters'] ?? null) ? $result['counters'] : [];
$verification = is_array($flow['verification'] ?? null) ? $flow['verification'] : [];
$verificationCounts = is_array($verification['counts'] ?? null) ? $verification['counts'] : [];
$verificationLabels = [
  'preexisting' => glpiacessivel_t('Vínculo já existente e mantido'),
  'confirmed' => glpiacessivel_t('Vínculo observado após a execução'),
  'not_confirmed' => glpiacessivel_t('Vínculo não confirmado'),
  'unavailable' => glpiacessivel_t('Conferência indisponível'),
];
$actionKey = (string) ($flow['actionkey'] ?? $native['action'] ?? '');
$actionLabel = static function (string $key, string $nativeLabel): string {
  return match ($key) {
    'MassiveAction:update' => glpiacessivel_t('Alterar status'),
    'Ticket:add_actor' => glpiacessivel_t('Adicionar participante'),
    default => $nativeLabel,
  };
};
$chosenActionLabel = $actionLabel($actionKey, (string) ($flow['actionlabel'] ?? ''));
$error = (string) ($error ?? '');
$flowToken = (string) ($flowToken ?? '');
$csrfToken = (string) ($csrfToken ?? '');
$remainingSeconds = max(0, (int) ($flow['expires'] ?? 0) - time());
$renewalsRemaining = max(0, 10 - (int) ($flow['renewals'] ?? 0));
$showDeadline = ((($flow['status'] ?? '') === 'ready' && in_array($stage, ['catalog', 'form', 'review'], true))
  || (($flow['status'] ?? '') === 'waiting' && $stage === 'waiting'))
  && $remainingSeconds > 0;
$canExtend = $showDeadline && $renewalsRemaining > 0;
$postUrl = glpiacessivel_url('front/ticket.massaction.php');
$assetPath = 'public/assets/js/ticket-mass-actions.js';
$assetVersion = function_exists('plugin_glpiacessivel_asset_version')
  ? plugin_glpiacessivel_asset_version($assetPath)
  : (string) (@filemtime(__DIR__ . '/../../' . $assetPath) ?: '1');
$assetUrl = \GlpiPlugin\Glpiacessivel\Support\Url::asset($assetPath . '?v=' . rawurlencode($assetVersion));
$stageTitles = [
  'catalog' => glpiacessivel_t('Escolher ação em massa'),
  'form' => glpiacessivel_t('Informar parâmetros da ação'),
  'review' => glpiacessivel_t('Revisar e confirmar a ação'),
  'waiting' => glpiacessivel_t('Continuar processamento nativo'),
  'done' => glpiacessivel_t('Resultado da ação em massa'),
  'unknown' => glpiacessivel_t('Resultado não confirmado'),
  'cancelled' => glpiacessivel_t('Ação cancelada'),
  'unavailable' => glpiacessivel_t('Etapa indisponível'),
];
$controlLabel = static function (string $name): string {
  if ($name === 'id_field') {
    return glpiacessivel_t('Campo do chamado');
  }
  if ($name === 'status') {
    return glpiacessivel_t('Status do chamado');
  }
  if ($name === 'actortype') {
    return glpiacessivel_t('Papel no chamado');
  }
  if (str_ends_with($name, '[_type]')) {
    return glpiacessivel_t('Tipo de participante');
  }
  if (str_ends_with($name, '_id]')) {
    return glpiacessivel_t('Participante');
  }
  if (str_contains($name, 'use_notification') || str_contains($name, 'use_notif')) {
    return glpiacessivel_t('Receber notificações');
  }
  if (str_contains($name, 'email')) {
    return glpiacessivel_t('Endereço de e-mail');
  }
  return sprintf(glpiacessivel_t('Parâmetro da ação: %s'), $name);
};
$renderSecurity = static function (string $nextStage) use ($flowToken, $csrfToken): void {
  ?>
  <input type="hidden" name="stage" value="<?= glpiacessivel_e($nextStage) ?>" />
  <input type="hidden" name="flow_token" value="<?= glpiacessivel_e((string) $flowToken) ?>" />
  <input type="hidden" name="_glpi_csrf_token" value="<?= glpiacessivel_e((string) $csrfToken) ?>" />
  <?php
};
?>
<section class="glpiacessivel-card" aria-labelledby="mass-action-heading" data-glpiacessivel-mass-flow data-flow-token="<?= glpiacessivel_e($flowToken) ?>" data-flow-stage="<?= glpiacessivel_e($stage) ?>">
  <h2 id="mass-action-heading" tabindex="-1" data-glpiacessivel-mass-flow-heading><?= glpiacessivel_e($stageTitles[$stage] ?? $stageTitles['unknown']) ?></h2>
  <?php if ($error !== ''): ?>
    <div class="glpiacessivel-alert glpiacessivel-alert-error" role="alert" tabindex="-1" data-glpiacessivel-mass-flow-error>
      <p><?= glpiacessivel_e($error) ?></p>
    </div>
  <?php endif; ?>
  <p data-glpiacessivel-mass-flow-status role="status" aria-live="polite" aria-atomic="true" data-pending-message="<?= glpiacessivel_e(glpiacessivel_t('Processando a etapa solicitada. Aguarde o resultado antes de continuar.')) ?>"></p>
  <?php if ($showDeadline): ?>
    <aside aria-labelledby="mass-preparation-deadline-heading" data-glpiacessivel-mass-deadline data-remaining-seconds="<?= glpiacessivel_e((string) $remainingSeconds) ?>">
      <h3 id="mass-preparation-deadline-heading"><?= glpiacessivel_e(glpiacessivel_t('Prazo desta etapa')) ?></h3>
      <p><?= glpiacessivel_e(sprintf(glpiacessivel_t('Tempo restante aproximado ao carregar esta página: %d minutos. Renovações disponíveis: %d.'), (int) ceil($remainingSeconds / 60), $renewalsRemaining)) ?></p>
      <p id="mass-extend-help"><?= glpiacessivel_e(glpiacessivel_t('O prazo desta etapa pode ser renovado até dez vezes ao longo do fluxo. Renovar não executa nem continua a ação, não prorroga a sessão do GLPI e não recupera um processamento nativo expirado.')) ?></p>
      <p data-glpiacessivel-mass-deadline-status role="status" aria-live="polite" aria-atomic="true" data-warning-message="<?= glpiacessivel_e($canExtend ? glpiacessivel_t('O prazo desta etapa está terminando. Renove o prazo agora se precisar de mais tempo. Nenhuma ação será executada ou continuada pela renovação.') : glpiacessivel_t('O prazo desta etapa está terminando. O limite de renovações foi atingido. Consulte os chamados antes de preparar outra ação.')) ?>" data-expired-message="<?= glpiacessivel_e($stage === 'waiting' ? glpiacessivel_t('O prazo desta etapa expirou. Alguns chamados podem já ter sido alterados. Consulte os chamados no GLPI antes de realizar outra ação. Não repita a execução inicial.') : glpiacessivel_t('O prazo desta etapa expirou. Volte à lista e prepare uma nova seleção. Nenhuma ação será repetida automaticamente.')) ?>"></p>
      <?php if ($canExtend): ?>
        <p data-glpiacessivel-mass-extend-storage-help><?= glpiacessivel_e(glpiacessivel_t('Se o navegador não puder preservar as edições pendentes, a renovação mantém somente os parâmetros já enviados. Envie as escolhas que deseja preservar antes de renovar.')) ?></p>
        <form method="post" action="<?= glpiacessivel_e($postUrl) ?>">
          <?php $renderSecurity('extend'); ?>
          <button type="submit" class="glpiacessivel-button glpiacessivel-button-secondary" aria-describedby="mass-extend-help" data-glpiacessivel-mass-extend><?= glpiacessivel_e(glpiacessivel_t('Renovar prazo desta etapa')) ?></button>
        </form>
      <?php endif; ?>
    </aside>
  <?php endif; ?>
  <p><?= glpiacessivel_e(sprintf(glpiacessivel_t('Chamados selecionados nesta página: %d.'), count($ids))) ?></p>
  <?php if ($ids !== []): ?>
    <details>
      <summary><?= glpiacessivel_e(glpiacessivel_t('Consultar IDs dos chamados selecionados')) ?></summary>
      <ul>
        <?php foreach ($ids as $id): ?>
          <li><?= glpiacessivel_e(sprintf(glpiacessivel_t('Chamado #%d'), (int) $id)) ?></li>
        <?php endforeach; ?>
      </ul>
    </details>
  <?php endif; ?>

  <?php if ($stage === 'catalog'): ?>
    <p><?= glpiacessivel_e(glpiacessivel_t('As ações disponíveis respeitam seu perfil, a entidade e as permissões do GLPI.')) ?></p>
    <?php if ($actions !== []): ?>
      <form method="post" action="<?= glpiacessivel_e($postUrl) ?>">
        <?php $renderSecurity('action'); ?>
        <div class="glpiacessivel-form-field">
          <label for="mass-action-key"><?= glpiacessivel_e(glpiacessivel_t('Ação em massa')) ?></label>
          <select id="mass-action-key" name="actionkey" required>
            <option value=""><?= glpiacessivel_e(glpiacessivel_t('Selecione uma ação')) ?></option>
            <?php foreach ($actions as $key => $label): ?>
              <option value="<?= glpiacessivel_e((string) $key) ?>"><?= glpiacessivel_e($actionLabel((string) $key, (string) $label)) ?></option>
            <?php endforeach; ?>
          </select>
        </div>
        <button type="submit" class="glpiacessivel-button"><?= glpiacessivel_e(glpiacessivel_t('Continuar')) ?></button>
      </form>
    <?php else: ?>
      <p><?= glpiacessivel_e(glpiacessivel_t('Não há ações disponíveis para esta seleção no perfil atual.')) ?></p>
    <?php endif; ?>
    <p><?= glpiacessivel_e(glpiacessivel_t('Outras ações estão disponíveis no GLPI convencional. Selecione novamente os chamados nessa interface.')) ?></p>
    <p><a href="<?= glpiacessivel_e(\GlpiPlugin\Glpiacessivel\Support\Url::core('front/ticket.php')) ?>"><?= glpiacessivel_e(glpiacessivel_t('Abrir ações na lista convencional do GLPI')) ?></a></p>
  <?php elseif ($stage === 'form'): ?>
    <h3><?= glpiacessivel_e(glpiacessivel_t('Ação escolhida')) ?></h3>
    <p><?= glpiacessivel_e($chosenActionLabel) ?></p>
    <p><?= glpiacessivel_e(glpiacessivel_t('Nenhuma alteração foi executada. Os campos abaixo correspondem aos parâmetros oferecidos pelo GLPI.')) ?></p>
    <?php if ($actionKey === 'Ticket:add_actor'): ?>
      <p id="mass-participant-help"><?= glpiacessivel_e(glpiacessivel_t('Adicionar participante mantém os participantes existentes. Esta ação não substitui nem remove responsáveis. Restrições do GLPI e dos plugins instalados continuam sendo aplicadas.')) ?></p>
    <?php endif; ?>
    <?php if ($lookup !== []): ?>
      <form method="post" action="<?= glpiacessivel_e($postUrl) ?>" role="search" aria-label="<?= glpiacessivel_e(glpiacessivel_t('Pesquisar participantes disponíveis')) ?>">
        <?php $renderSecurity('search'); ?>
        <input type="hidden" name="page" value="1" />
        <label for="mass-participant-query"><?= glpiacessivel_e(glpiacessivel_t('Nome do participante')) ?></label>
        <input type="text" id="mass-participant-query" name="query" value="<?= glpiacessivel_e((string) ($flow['query'] ?? '')) ?>" maxlength="120" />
        <button type="submit" class="glpiacessivel-button glpiacessivel-button-secondary"><?= glpiacessivel_e(glpiacessivel_t('Pesquisar')) ?></button>
      </form>
      <p><?= glpiacessivel_e(sprintf(glpiacessivel_t('Página de participantes: %d.'), max(1, (int) ($flow['lookup_page'] ?? 1)))) ?></p>
      <?php if ((int) ($flow['lookup_page'] ?? 1) > 1 || !empty($form['more'])): ?>
        <div class="glpiacessivel-form-actions" role="group" aria-label="<?= glpiacessivel_e(glpiacessivel_t('Paginação de participantes')) ?>">
          <?php foreach (['previous' => (int) ($flow['lookup_page'] ?? 1) - 1, 'next' => (int) ($flow['lookup_page'] ?? 1) + 1] as $direction => $lookupPage): ?>
            <?php if (($direction === 'previous' && $lookupPage > 0) || ($direction === 'next' && !empty($form['more']))): ?>
              <form method="post" action="<?= glpiacessivel_e($postUrl) ?>">
                <?php $renderSecurity('search'); ?>
                <input type="hidden" name="query" value="<?= glpiacessivel_e((string) ($flow['query'] ?? '')) ?>" />
                <input type="hidden" name="page" value="<?= glpiacessivel_e((string) $lookupPage) ?>" />
                <button type="submit" class="glpiacessivel-button glpiacessivel-button-secondary"><?= glpiacessivel_e($direction === 'previous' ? glpiacessivel_t('Participantes: página anterior') : glpiacessivel_t('Participantes: próxima página')) ?></button>
              </form>
            <?php endif; ?>
          <?php endforeach; ?>
        </div>
      <?php endif; ?>
    <?php endif; ?>
    <form method="post" action="<?= glpiacessivel_e($postUrl) ?>">
      <?php $renderSecurity('params'); ?>
      <?php foreach ($controls as $index => $control): ?>
        <?php
        $control = (array) $control;
        $name = (string) ($control['name'] ?? '');
        $type = (string) ($control['type'] ?? 'text');
        $controlId = 'mass-parameter-' . (int) $index;
        $multiple = !empty($control['multiple']);
        $fieldName = 'values[' . (int) $index . ']' . ($multiple ? '[]' : '');
        $explicitChoice = $type === 'select' && !empty($control['explicit_choice']);
        $value = $values[$index] ?? ($explicitChoice ? '' : ($control['value'] ?? ''));
        $selectedValues = is_array($value) ? array_map('strval', $value) : [(string) $value];
        $required = !empty($control['required']) || $explicitChoice;
        $disabled = !empty($control['disabled']);
        $checkable = in_array($type, ['checkbox', 'radio'], true);
        $checked = $checkable && (array_key_exists($index, $values)
          ? (string) $value !== ''
          : !empty($control['checked']));
        $inputValue = $checkable ? (string) ($control['value'] ?? '') : (string) $value;
        ?>
        <div class="glpiacessivel-form-field">
          <label for="<?= glpiacessivel_e($controlId) ?>"><?= glpiacessivel_e($controlLabel($name)) ?><?php if ($required): ?> <?= glpiacessivel_e(glpiacessivel_t('(obrigatório)')) ?><?php endif; ?></label>
          <?php if ($type === 'select'): ?>
            <select id="<?= glpiacessivel_e($controlId) ?>" name="<?= glpiacessivel_e($fieldName) ?>" <?= $required ? 'required' : '' ?> <?= $disabled ? 'disabled' : '' ?> <?= $multiple ? 'multiple' : '' ?> <?= $actionKey === 'Ticket:add_actor' ? 'aria-describedby="mass-participant-help"' : '' ?>>
              <?php if ($explicitChoice): ?>
                <option value="" <?= in_array('', $selectedValues, true) ? 'selected' : '' ?>><?= glpiacessivel_e(glpiacessivel_t('Selecione uma opção')) ?></option>
              <?php endif; ?>
              <?php foreach ((array) ($control['options'] ?? []) as $option): ?>
                <?php $option = (array) $option; ?>
                <option value="<?= glpiacessivel_e((string) ($option['value'] ?? '')) ?>" <?= !empty($option['disabled']) ? 'disabled' : '' ?> <?= (in_array((string) ($option['value'] ?? ''), $selectedValues, true) || (!$explicitChoice && !array_key_exists($index, $values) && !empty($option['selected']))) ? 'selected' : '' ?>><?= glpiacessivel_e((string) ($option['label'] ?? '')) ?></option>
              <?php endforeach; ?>
            </select>
          <?php elseif ($type === 'textarea'): ?>
            <textarea id="<?= glpiacessivel_e($controlId) ?>" name="<?= glpiacessivel_e($fieldName) ?>" rows="4" <?= $required ? 'required' : '' ?> <?= $disabled ? 'disabled' : '' ?>><?= glpiacessivel_e((string) $value) ?></textarea>
          <?php else: ?>
            <input type="<?= glpiacessivel_e($type) ?>" id="<?= glpiacessivel_e($controlId) ?>" name="<?= glpiacessivel_e($fieldName) ?>" value="<?= glpiacessivel_e($inputValue) ?>" <?= $required ? 'required' : '' ?> <?= $disabled ? 'disabled' : '' ?> <?= $checked ? 'checked' : '' ?> />
          <?php endif; ?>
        </div>
      <?php endforeach; ?>
      <button type="submit" class="glpiacessivel-button"><?= glpiacessivel_e($mode === 'parameters' ? glpiacessivel_t('Revisar ação') : glpiacessivel_t('Continuar')) ?></button>
    </form>
  <?php elseif ($stage === 'review'): ?>
    <h3><?= glpiacessivel_e(glpiacessivel_t('Ação escolhida')) ?></h3>
    <p><?= glpiacessivel_e($chosenActionLabel) ?></p>
    <?php if ($actionKey === 'Ticket:add_actor'): ?>
      <p><?= glpiacessivel_e(glpiacessivel_t('Adicionar participante mantém os participantes existentes. Esta ação não substitui nem remove responsáveis. Restrições do GLPI e dos plugins instalados continuam sendo aplicadas.')) ?></p>
    <?php endif; ?>
    <h3><?= glpiacessivel_e(glpiacessivel_t('Dados da ação')) ?></h3>
    <ul>
      <?php foreach ((array) ($flow['review'] ?? []) as $reviewLabel): ?>
        <li><?= glpiacessivel_e((string) $reviewLabel) ?></li>
      <?php endforeach; ?>
    </ul>
    <p id="mass-confirm-help"><?= glpiacessivel_e(glpiacessivel_t('Ao confirmar, o GLPI executará a ação nos chamados selecionados, respeitando suas regras e permissões. Alguns chamados podem não ser alterados.')) ?></p>
    <form method="post" action="<?= glpiacessivel_e($postUrl) ?>">
      <?php $renderSecurity('confirm'); ?>
      <label for="mass-action-confirmed"><input type="checkbox" id="mass-action-confirmed" name="confirmed" value="1" required aria-describedby="mass-confirm-help" /> <?= glpiacessivel_e(glpiacessivel_t('Revisei os dados e confirmo a execução desta ação.')) ?></label>
      <button type="submit" class="glpiacessivel-button"><?= glpiacessivel_e(glpiacessivel_t('Confirmar e executar')) ?></button>
    </form>
    <form method="post" action="<?= glpiacessivel_e($postUrl) ?>">
      <?php $renderSecurity('revise'); ?>
      <button type="submit" class="glpiacessivel-button glpiacessivel-button-secondary"><?= glpiacessivel_e(glpiacessivel_t('Revisar parâmetros')) ?></button>
    </form>
  <?php elseif ($stage === 'waiting'): ?>
    <p><?= glpiacessivel_e(glpiacessivel_t('O GLPI iniciou o processamento e deixou uma continuação nativa pendente. Continue somente os itens restantes; a ação inicial não será repetida.')) ?></p>
    <form method="post" action="<?= glpiacessivel_e($postUrl) ?>">
      <?php $renderSecurity('continue'); ?>
      <button type="submit" class="glpiacessivel-button"><?= glpiacessivel_e(glpiacessivel_t('Continuar itens restantes')) ?></button>
    </form>
  <?php elseif ($stage === 'done'): ?>
    <p><?= glpiacessivel_e(glpiacessivel_t('O processamento terminou. Confira os resultados informados pelo GLPI.')) ?></p>
    <h3><?= glpiacessivel_e(glpiacessivel_t('Resultados informados pelo GLPI')) ?></h3>
    <dl>
      <dt><?= glpiacessivel_e(glpiacessivel_t('Informados como sucesso pelo GLPI')) ?></dt><dd><?= glpiacessivel_e((string) ($counters['ok'] ?? 0)) ?></dd>
      <dt><?= glpiacessivel_e(glpiacessivel_t('Com falha')) ?></dt><dd><?= glpiacessivel_e((string) ($counters['ko'] ?? 0)) ?></dd>
      <dt><?= glpiacessivel_e(glpiacessivel_t('Sem permissão')) ?></dt><dd><?= glpiacessivel_e((string) ($counters['noright'] ?? 0)) ?></dd>
      <dt><?= glpiacessivel_e(glpiacessivel_t('Sem alteração')) ?></dt><dd><?= glpiacessivel_e((string) ($counters['noaction'] ?? 0)) ?></dd>
    </dl>
  <?php elseif ($stage === 'cancelled'): ?>
    <p><?= glpiacessivel_e(glpiacessivel_t('A preparação foi cancelada. Nenhuma ação foi executada.')) ?></p>
  <?php elseif ($stage === 'unavailable'): ?>
    <p><?= glpiacessivel_e(glpiacessivel_t('Volte à lista para atualizar a seleção e suas permissões antes de preparar outra ação.')) ?></p>
  <?php else: ?>
    <div class="glpiacessivel-alert glpiacessivel-alert-warning">
      <p><?= glpiacessivel_e(glpiacessivel_t('Não foi possível confirmar o resultado. Uma alteração pode já ter ocorrido. Consulte os chamados no GLPI antes de realizar outra ação. Não repita esta execução.')) ?></p>
    </div>
  <?php endif; ?>

  <?php if (!empty($verification['applicable']) && in_array($stage, ['done', 'unknown'], true)): ?>
    <section aria-labelledby="mass-verification-heading" data-glpiacessivel-mass-verification>
      <h3 id="mass-verification-heading"><?= glpiacessivel_e(glpiacessivel_t('Conferência dos vínculos de participantes')) ?></h3>
      <p><?= glpiacessivel_e(glpiacessivel_t('Esta conferência apenas consulta os vínculos e não altera chamados. Os contadores do GLPI não comprovam, sozinhos, que o participante foi incluído. Um vínculo observado após a execução não comprova qual operação o criou.')) ?></p>
      <dl>
        <?php foreach ($verificationLabels as $category => $categoryLabel): ?>
          <dt><?= glpiacessivel_e($categoryLabel) ?></dt>
          <dd><?= glpiacessivel_e((string) max(0, (int) ($verificationCounts[$category] ?? 0))) ?></dd>
        <?php endforeach; ?>
      </dl>
      <?php if (!empty($verificationCounts['not_confirmed']) || !empty($verificationCounts['unavailable'])): ?>
        <p><?= glpiacessivel_e(glpiacessivel_t('Consulte as mensagens do GLPI e os chamados antes de realizar outra ação. Um vínculo não confirmado ou uma conferência indisponível não identifica, por si só, a causa e não autoriza repetir a execução.')) ?></p>
      <?php endif; ?>
      <?php if (is_array($verification['items'] ?? null) && $verification['items'] !== []): ?>
        <details>
          <summary><?= glpiacessivel_e(glpiacessivel_t('Consultar conferência por chamado')) ?></summary>
          <ul>
            <?php foreach ($verification['items'] as $verifiedItem): ?>
              <?php $verifiedItem = (array) $verifiedItem; ?>
              <li><?= glpiacessivel_e(sprintf(glpiacessivel_t('Chamado #%d: %s.'), (int) ($verifiedItem['id'] ?? 0), $verificationLabels[(string) ($verifiedItem['category'] ?? '')] ?? $verificationLabels['unavailable'])) ?></li>
            <?php endforeach; ?>
          </ul>
        </details>
      <?php endif; ?>
    </section>
  <?php endif; ?>

  <?php if (is_array($flow['messages'] ?? null) && $flow['messages'] !== []): ?>
    <h3><?= glpiacessivel_e(glpiacessivel_t('Mensagens do GLPI')) ?></h3>
    <ul data-glpiacessivel-mass-native-messages>
      <?php foreach ($flow['messages'] as $nativeMessage): ?>
        <li><?= glpiacessivel_e((string) $nativeMessage) ?></li>
      <?php endforeach; ?>
    </ul>
  <?php endif; ?>

  <?php if (in_array($stage, ['catalog', 'form', 'review'], true)): ?>
    <form method="post" action="<?= glpiacessivel_e($postUrl) ?>">
      <?php $renderSecurity('cancel'); ?>
      <button type="submit" class="glpiacessivel-button glpiacessivel-button-secondary"><?= glpiacessivel_e(glpiacessivel_t('Cancelar sem executar')) ?></button>
    </form>
  <?php endif; ?>
  <p><a href="<?= glpiacessivel_e(glpiacessivel_url('front/tickets.php')) ?>"><?= glpiacessivel_e(glpiacessivel_t('Voltar à lista de chamados')) ?></a></p>
</section>
<script src="<?= glpiacessivel_e($assetUrl) ?>" defer></script>
