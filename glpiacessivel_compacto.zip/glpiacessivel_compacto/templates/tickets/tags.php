<?php

declare(strict_types=1);

// Presentation only: the service determines availability, rights and native data.
$ticketTags = is_array($ticketTags ?? null) ? $ticketTags : [];
$ticketTagsState = (string) ($ticketTags['state'] ?? 'absent');
if (!in_array($ticketTagsState, ['ready', 'unavailable', 'native_only'], true)) {
    return;
}
$ticketTagsNativeUrl = $ticketTags['native_url'] ?? '';
if (!is_string($ticketTagsNativeUrl)
    || !str_starts_with($ticketTagsNativeUrl, '/')
    || str_starts_with($ticketTagsNativeUrl, '//')
    || preg_match('/[\x00-\x20\x7f\\\\]/', $ticketTagsNativeUrl) === 1
) {
    $ticketTagsNativeUrl = '';
}
$ticketTagsItems = is_array($ticketTags['items'] ?? null) ? $ticketTags['items'] : [];
$ticketTagsRenderedItems = [];
foreach ($ticketTagsItems as $ticketTagsItem) {
    if (!is_array($ticketTagsItem) || !is_string($ticketTagsItem['name'] ?? null) || trim($ticketTagsItem['name']) === '') {
        continue;
    }
    $ticketTagsColor = $ticketTagsItem['color'] ?? null;
    $ticketTagsForeground = $ticketTagsItem['foreground'] ?? null;
    $ticketTagsHasColor = ($ticketTagsItem['color_available'] ?? false) === true
        && is_string($ticketTagsColor)
        && preg_match('/\A#[0-9a-fA-F]{6}\z/', $ticketTagsColor) === 1
        && is_string($ticketTagsForeground)
        && in_array(strtoupper($ticketTagsForeground), ['#000000', '#FFFFFF'], true);
    $ticketTagsRenderedItems[] = [
        'name' => $ticketTagsItem['name'],
        'style' => $ticketTagsHasColor
            ? '--ticket-tag-background:' . $ticketTagsColor . ';--ticket-tag-foreground:' . $ticketTagsForeground
            : '',
    ];
}
$ticketTagsMessage = is_string($ticketTags['message'] ?? null) ? $ticketTags['message'] : '';
?>
<section class="glpiacessivel-card glpiacessivel-ticket-tags" aria-labelledby="ticket-tags-heading">
  <h2 id="ticket-tags-heading" tabindex="-1"><?= glpiacessivel_e(glpiacessivel_t('Etiquetas do chamado')) ?></h2>
  <?php if ($ticketTagsState === 'ready' && $ticketTagsRenderedItems !== []): ?>
    <ul class="glpiacessivel-ticket-tags-list" role="list">
      <?php foreach ($ticketTagsRenderedItems as $ticketTagsRenderedItem): ?>
        <li><span class="glpiacessivel-ticket-tag"<?php if ($ticketTagsRenderedItem['style'] !== ''): ?> style="<?= glpiacessivel_e($ticketTagsRenderedItem['style']) ?>"<?php endif; ?>><?= glpiacessivel_e($ticketTagsRenderedItem['name']) ?></span></li>
      <?php endforeach; ?>
    </ul>
  <?php elseif ($ticketTagsState === 'ready'): ?>
    <p><?= glpiacessivel_e(glpiacessivel_t('Nenhuma etiqueta vinculada a este chamado.')) ?></p>
  <?php endif; ?>
  <?php if ($ticketTagsMessage !== ''): ?>
    <p><?= glpiacessivel_e($ticketTagsMessage) ?></p>
  <?php endif; ?>
  <?php if ($ticketTagsNativeUrl !== ''): ?>
    <p><a href="<?= glpiacessivel_e($ticketTagsNativeUrl) ?>" aria-describedby="ticket-tags-native-help"><?= glpiacessivel_e(!empty($ticketTags['native_edit_available']) ? glpiacessivel_t('Gerenciar etiquetas na interface convencional do GLPI') : glpiacessivel_t('Abrir chamado na interface convencional para consultar etiquetas')) ?></a></p>
    <p id="ticket-tags-native-help"><?= glpiacessivel_e(glpiacessivel_t('Abre nesta mesma aba, mantendo as permissões do GLPI. A apresentação e os recursos disponíveis dependem do plugin de etiquetas instalado. Para retornar, use Voltar no navegador.')) ?></p>
  <?php endif; ?>
</section>
