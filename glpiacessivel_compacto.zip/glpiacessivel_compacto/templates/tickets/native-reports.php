<?php if (!empty($nativeStatistics['available']) && !empty($nativeStatistics['links'])): ?>
<details id="ticket-native-statistics" class="glpiacessivel-card" data-glpiacessivel-native-list-actions>
  <summary><?= glpiacessivel_e(glpiacessivel_t('Estatísticas na interface convencional')) ?></summary>
  <p id="ticket-native-statistics-help"><?= glpiacessivel_e(glpiacessivel_t('Os relatórios abrem na interface convencional do GLPI, nesta mesma aba, em formato de tabela. Usam suas permissões, entidade e o período definido no GLPI, não os filtros atuais desta lista nem o contador Meus chamados abertos.')) ?></p>
  <p id="ticket-native-statistics-return"><?= glpiacessivel_e(glpiacessivel_t('Para retornar à lista, use Voltar no navegador. A consulta será revalidada pelo GLPI se a página precisar ser carregada novamente.')) ?></p>
  <ul>
    <li><a id="ticket-native-statistics-assigned" href="<?= glpiacessivel_e($nativeStatistics['links']['assigned']) ?>" aria-describedby="ticket-native-statistics-help ticket-native-statistics-return" data-glpiacessivel-native-statistics-link><?= glpiacessivel_e(glpiacessivel_t('Estatísticas por técnico atribuído — interface convencional')) ?></a></li>
    <li><a id="ticket-native-statistics-tasks" href="<?= glpiacessivel_e($nativeStatistics['links']['tasks']) ?>" aria-describedby="ticket-native-statistics-help ticket-native-statistics-return" data-glpiacessivel-native-statistics-link><?= glpiacessivel_e(glpiacessivel_t('Estatísticas por técnico de tarefas — interface convencional')) ?></a></li>
  </ul>
</details>
<?php endif; ?>
