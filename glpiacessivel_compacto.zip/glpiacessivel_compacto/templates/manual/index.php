<?php

declare(strict_types=1);

// Dedicated read-only document. Do not load the operational header, forms or scripts.
// Section HTML and optional inline CSS come only from reviewed, packaged resources.
$manual = is_array($manual ?? null) ? $manual : [];
$manualStandalone = ($manualStandalone ?? false) === true;
$manualView = $manualStandalone || ($manualView ?? '') === 'full' ? 'full' : 'context';
$manualReadingContext = is_array($manualReadingContext ?? null) ? $manualReadingContext : [];
$manualEscape = static fn($value): string => htmlspecialchars((string) $value, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
$manualLocalUrl = static function ($value): string {
    return is_string($value) && str_starts_with($value, '/') && !str_starts_with($value, '//')
        && preg_match('/[\x00-\x20\x7f\\\\]/', $value) !== 1 ? $value : '';
};
$manualUrl = $manualStandalone ? '' : $manualLocalUrl($manualUrl ?? '');
$manualCssUrl = $manualStandalone ? '' : $manualLocalUrl($manualCssUrl ?? '');
$manualHomeUrl = $manualStandalone ? '' : $manualLocalUrl($manualHomeUrl ?? '');
$manualImageBaseUrl = $manualLocalUrl($manualImageBaseUrl ?? '');
if (
    preg_match('~\A/(?:[^/?#\x22\x27<>]+/)*plugins/glpiacessivel/public/assets/manual/images/\z~uD', $manualImageBaseUrl) !== 1
    || preg_match('~(?:^|/)\.{1,2}(?:/|$)|%(?:2e|2f|5c)~i', $manualImageBaseUrl) === 1
) {
    $manualImageBaseUrl = '';
}
$manualRenderHtml = static function (string $html) use ($manualImageBaseUrl, $manualEscape): string {
    if ($manualImageBaseUrl === '') {
        return $html;
    }
    // Only the reviewed image prefix is mapped to the public asset location.
    // Data URIs in the offline edition and all other document URLs stay untouched.
    return preg_replace_callback(
        '~\bsrc=([\x22\x27])\.\./resources/manual/images/([a-z0-9][a-z0-9._-]{0,100}\.(?:jpg|jpeg|png|webp))\1~i',
        static fn(array $match): string => 'src=' . $match[1]
            . $manualEscape($manualImageBaseUrl . $match[2]) . $match[1],
        $html
    ) ?? $html;
};
$manualModeUrl = static fn(string $mode): string => $manualUrl === '' ? ''
    : $manualUrl . (str_contains($manualUrl, '?') ? '&' : '?') . 'view=' . $mode;
$manualStateLabels = [
    'available' => 'Orientação para este contexto',
    'disabled' => 'Funcionalidade desativada',
    'excluded' => 'Fora do público de liberação atual',
    'denied' => 'Permissão geral não disponível no contexto verificado',
    'hidden' => 'Oculto na navegação',
    'unsupported' => 'Recurso não suportado neste ambiente',
    'unknown' => 'Disponibilidade não verificada',
];
$manualSections = [];
$manualIds = ['manual-title' => true, 'manual-summary' => true, 'manual-content' => true, 'manual-context-title' => true,
    'manual-reading-context-title' => true];
foreach ((array) ($manual['sections'] ?? []) as $manualSection) {
    if (
        !is_array($manualSection) || !is_string($manualSection['id'] ?? null)
        || preg_match('/\A[a-z][a-z0-9-]{0,90}\z/D', $manualSection['id']) !== 1
        || isset($manualIds[$manualSection['id']])
    ) {
        continue;
    }
    $manualIds[$manualSection['id']] = true;
    $manualRule = (string) ($manualSection['rule'] ?? 'always');
    $manualDecision = ['state' => 'unknown', 'message' => 'Não foi possível verificar a disponibilidade neste momento. Consulte as condições no manual completo.'];
    if ($manualRule === 'always') {
        $manualDecision = ['state' => 'available', 'message' => ''];
    } else {
        try {
            if (isset($manualAvailability) && is_object($manualAvailability) && is_callable([$manualAvailability, 'evaluate'])) {
                $manualCandidate = $manualAvailability->evaluate($manualRule);
                if (is_array($manualCandidate) && isset($manualStateLabels[$manualCandidate['state'] ?? ''])) {
                    $manualDecision = [
                        'state' => $manualCandidate['state'],
                        'message' => is_string($manualCandidate['message'] ?? null) ? $manualCandidate['message'] : '',
                    ];
                }
            }
        } catch (\Throwable) {
            // An unavailable capability probe never prevents reading the basic manual.
        }
    }
    $manualSection['level'] = ($manualSection['level'] ?? 2) === 3 ? 3 : 2;
    $manualSection['rule'] = $manualRule;
    $manualSection['availability'] = $manualDecision;
    $manualSections[] = $manualSection;
}
$manualTitle = (string) ($manual['title'] ?? 'Manual do GLPI Acessível');
?>
<!doctype html>
<html lang="pt-BR">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <meta name="author" content="<?= $manualEscape($manual['credit'] ?? '') ?>" />
  <title><?= $manualEscape($manualTitle) ?> — <?= $manualView === 'full' ? 'Manual completo' : 'Contexto atual' ?></title>
  <?php if ($manualCssUrl !== '') :
        ?><link rel="stylesheet" href="<?= $manualEscape($manualCssUrl) ?>" /><?php
  endif; ?>
  <?php if (is_string($manualInlineCss ?? null) && $manualInlineCss !== '') :
        ?><style><?= $manualInlineCss ?></style><?php
  endif; ?>
</head>
<body class="glpiacessivel-manual">
  <a class="manual-skip" href="#manual-content">Ir para o conteúdo do manual</a>
  <header class="manual-header">
    <p class="manual-brand">GLPI Acessível</p>
    <h1 id="manual-title" tabindex="-1"><?= $manualEscape($manualTitle) ?></h1>
    <p><?= $manualEscape($manual['lead'] ?? '') ?></p>
    <nav class="manual-start-links" aria-label="Acessos rápidos do manual">
      <a href="#manual-summary">Ir para o sumário</a>
      <?php if (isset($manualIds['primeiro-percurso'])) : ?>
      <a href="#primeiro-percurso">Começar pelo primeiro percurso</a>
      <?php endif; ?>
    </nav>
    <dl class="manual-metadata">
      <div><dt>Versão do manual</dt><dd><?= $manualEscape($manual['manual_version'] ?? '') ?></dd></div>
      <div><dt>Versão do plugin abordada</dt><dd><?= $manualEscape($manual['covered_plugin_version'] ?? '') ?></dd></div>
      <div><dt>Revisão</dt><dd><?= $manualEscape($manual['revision'] ?? '') ?></dd></div>
    </dl>
    <p><?= $manualEscape($manual['credit'] ?? '') ?></p>
    <?php if ($manualHomeUrl !== '' || $manualUrl !== '') : ?>
    <nav class="manual-actions" aria-label="Acessos do manual">
        <?php if ($manualHomeUrl !== '') :
            ?><a href="<?= $manualEscape($manualHomeUrl) ?>">Ir para a entrada do portal acessível</a><?php
        endif; ?>
        <?php if ($manualUrl !== '') : ?>
      <a href="<?= $manualEscape($manualModeUrl($manualView === 'full' ? 'context' : 'full')) ?>#manual-title"><?= $manualView === 'full' ? 'Voltar ao manual do contexto atual' : 'Consultar manual completo' ?></a>
        <?php endif; ?>
    </nav>
    <?php endif; ?>
  </header>
  <main id="manual-content" tabindex="-1">
    <?php if ($manualStandalone) : ?>
    <section class="manual-context" aria-labelledby="manual-context-title">
      <h2 id="manual-context-title" tabindex="-1">Sobre este manual</h2>
      <p>As opções disponíveis podem variar conforme seu perfil de acesso, entidade, configuração da instituição e componentes instalados. Utilize os procedimentos correspondentes aos recursos apresentados na sua sessão do GLPI.</p>
      <p>Este é o manual completo. Sua consulta não altera permissões nem habilita funcionalidades.</p>
    </section>
    <?php else : ?>
    <section class="manual-context" aria-labelledby="manual-context-title">
      <h2 id="manual-context-title" tabindex="-1"><?= $manualView === 'full' ? 'Manual completo' : 'Manual para o contexto atual' ?></h2>
      <?php if ($manualView === 'full') : ?>
      <p>Esta apresentação reúne todos os assuntos. Ler as orientações não habilita funcionalidades nem concede permissões. As condições de uso estão indicadas em cada assunto.</p>
      <?php else : ?>
      <p>O sumário prioriza as orientações básicas e os recursos disponíveis no contexto verificado nesta abertura. Os demais assuntos continuam identificados abaixo e podem ser consultados no manual completo.</p>
      <p>Ao navegar por títulos, você também pode encontrar avisos sobre outros assuntos. Use “Voltar ao sumário” para retomar os assuntos priorizados.
          <?php if ($manualUrl !== '') : ?>
        Para ler todos os procedimentos, escolha <a href="<?= $manualEscape($manualModeUrl('full')) ?>#manual-title">Consultar manual completo</a>.
          <?php endif; ?>
      </p>
      <?php endif; ?>
      <p>As opções podem variar conforme perfil, entidade, módulos, liberação de funcionalidades e versão dos plugins. A ausência de uma opção não significa, por si só, falta de permissão.</p>
      <p>Trocar perfil ou entidade em outra aba pode alterar a sessão compartilhada do GLPI. Esta página não acompanha essas alterações automaticamente; recarregue ou reabra o manual para atualizar o contexto.</p>
    </section>
    <section class="manual-reading-context" aria-labelledby="manual-reading-context-title">
      <h2 id="manual-reading-context-title" tabindex="-1">Contexto desta leitura</h2>
      <?php if ($manualUrl !== '') : ?>
          <?php if (($manualReadingContext['confirmed'] ?? false) === true) : ?>
      <p>Estas orientações foram organizadas para o contexto confirmado nesta abertura. Perfil é o conjunto de permissões de uso; entidade é a unidade ou área de trabalho selecionada no GLPI.</p>
          <?php else : ?>
      <p>Não foi possível confirmar os dados do contexto nesta leitura. Você pode continuar lendo as orientações básicas ou consultar o manual completo. Perfil é o conjunto de permissões de uso; entidade é a unidade ou área de trabalho selecionada no GLPI.</p>
          <?php endif; ?>
      <dl class="manual-metadata">
          <?php foreach (['profile' => 'Perfil ativo', 'entity' => 'Entidade', 'scope' => 'Escopo', 'glpi_version' => 'Versão do GLPI'] as $manualContextKey => $manualContextLabel) :
              $manualContextValue = is_string($manualReadingContext[$manualContextKey] ?? null)
                  ? trim($manualReadingContext[$manualContextKey]) : '';
              ?>
        <div><dt><?= $manualEscape($manualContextLabel) ?></dt><dd><?= $manualEscape($manualContextValue !== '' ? $manualContextValue : 'Não confirmado nesta leitura') ?></dd></div>
          <?php endforeach; ?>
      </dl>
      <p>O nome do perfil orienta a leitura, mas não autoriza uma ação. No manual completo, há também procedimentos que podem não estar disponíveis para esse contexto. Confira os controles oferecidos na tela da tarefa.</p>
      <?php else : ?>
      <p>Referência geral, sem perfil ou entidade de uma instalação. Esta edição autônoma reúne o manual completo e não confirma quais funções estão liberadas para você. Ao usar o portal, confira o contexto apresentado no GLPI.</p>
      <?php endif; ?>
    </section>
    <?php endif; ?>
    <nav class="manual-summary" aria-labelledby="manual-summary">
      <h2 id="manual-summary" tabindex="-1">Sumário</h2>
      <ol>
      <?php foreach ($manualSections as $manualSection) : ?>
            <?php if ($manualView !== 'full' && $manualSection['availability']['state'] !== 'available') :
                continue;
            endif; ?>
        <li class="manual-summary-level-<?= $manualSection['level'] ?>"><a href="#<?= $manualEscape($manualSection['id']) ?>"><?= $manualEscape($manualSection['title'] ?? '') ?></a></li>
      <?php endforeach; ?>
      </ol>
    </nav>
    <?php foreach ($manualSections as $manualSection) : ?>
        <?php
        $manualState = $manualSection['availability']['state'];
        $manualShowProcedure = $manualView === 'full' || $manualState === 'available';
        $manualFullSectionUrl = $manualModeUrl('full');
        $manualAvailabilityText = $manualState === 'available'
            ? 'Poder consultar esta orientação não autoriza todas as ações. Use somente os controles oferecidos para seu perfil e autorizados no chamado ou na funcionalidade correspondente.'
            : $manualSection['availability']['message'];
        ?>
    <section class="manual-section<?= $manualShowProcedure ? '' : ' manual-section-summary' ?>" aria-labelledby="<?= $manualEscape($manualSection['id']) ?>" data-manual-state="<?= $manualEscape($manualState) ?>">
      <h<?= $manualSection['level'] ?> id="<?= $manualEscape($manualSection['id']) ?>" tabindex="-1"><?= $manualEscape($manualSection['title'] ?? '') ?></h<?= $manualSection['level'] ?>>
        <?php if (!$manualStandalone && $manualSection['rule'] !== 'always') : ?>
      <p class="manual-availability"><strong><?= $manualEscape($manualStateLabels[$manualState]) ?>.</strong><?php if ($manualAvailabilityText !== '') :
            ?> <?= $manualEscape($manualAvailabilityText) ?><?php
                                             endif; ?></p>
        <?php endif; ?>
        <?php if ($manualShowProcedure) : ?>
      <div class="manual-procedure"><?= $manualRenderHtml((string) ($manualSection['html'] ?? '')) ?></div>
        <?php elseif ($manualFullSectionUrl !== '') : ?>
      <p><a href="<?= $manualEscape($manualFullSectionUrl) ?>#<?= $manualEscape($manualSection['id']) ?>">Consultar este assunto no manual completo</a></p>
        <?php else : ?>
      <p>Consulte as condições de uso antes de realizar a operação na instalação do GLPI.</p>
        <?php endif; ?>
      <p class="manual-back"><a href="#manual-summary">Voltar ao sumário</a></p>
    </section>
    <?php endforeach; ?>
  </main>
  <footer class="manual-footer"><p>Manual <?= $manualEscape($manual['manual_version'] ?? '') ?>. Orientação de uso; não representa certificação formal de acessibilidade.</p></footer>
  <?php if ($manualUrl !== '') :
        ?><script>
    // Read visual preferences only. No operational handlers or preference writes.
    (function () {
      try {
        var raw = window.localStorage.getItem('glpiacessivel-login-preferences-v2');
        if (!raw) return;
        var prefs = JSON.parse(raw);
        document.body.dataset.glpiacessivelTheme = prefs.theme === 'night' ? 'night' : 'light';
        document.body.dataset.glpiacessivelContrast = prefs.contrast === true ? 'high' : 'default';
        if ([0.9, 1, 1.1, 1.2].indexOf(prefs.fontScale) !== -1) document.body.style.fontSize = prefs.fontScale + 'rem';
      } catch (error) { /* Reading remains available without browser storage or JavaScript. */ }
    })();
  </script>
  <?php endif; ?>
</body>
</html>
