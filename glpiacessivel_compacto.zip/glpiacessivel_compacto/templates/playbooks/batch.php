<?php
$t = static function (string $text): string {
    return __($text, 'glpiacessivel');
};
$batchData = is_array($batch ?? null) ? $batch : [];
$batchItems = array_values((array) ($batchData['items'] ?? []));
$batchAction = (string) ($batchData['action'] ?? '');
$batchToken = (string) ($batchData['token'] ?? '');
$batchReviewAllowed = !empty($batch_review_allowed);
$batchReady = $batchReviewAllowed && !empty($batchData['ready']) && $batchToken !== '' && $batchItems !== []
    && in_array($batchAction, ['approve', 'reject'], true) && empty($batchData['expired']);
$batchLabels = [
    'create' => $t('Criar orientação'), 'update' => $t('Atualizar orientação'),
    'inactivate' => $t('Inativar orientação'), 'reactivate' => $t('Reativar orientação'),
    'review' => $t('Revisão individual'),
];
$batchReasons = [
    'source_unavailable' => $t('Não foi possível confirmar o acesso às fontes no contexto atual.'),
    'context_changed' => $t('O contexto mudou. Retorne à fila no perfil e entidade corretos e faça uma nova revisão.'),
    'already_decided' => $t('A proposta já foi decidida. Retire-a da seleção antes de confirmar.'),
    'proposal_changed' => $t('A proposta mudou desde a seleção. Renove a revisão e confira o novo conteúdo.'),
    'target_changed' => $t('A orientação alvo mudou. Renove a revisão antes de decidir.'),
    'source_changed' => $t('Uma fonte mudou. Renove a revisão e confira as evidências atuais.'),
    'mapping_required' => $t('Os vínculos da importação precisam de mapeamento. Trate esta proposta individualmente.'),
    'individual_review_required' => $t('Esta proposta exige revisão individual. Retire-a da seleção para aprovação.'),
    'entity_mismatch' => $t('A entidade da proposta não corresponde ao contexto de decisão. Revise-a na entidade adequada.'),
    'manual_reactivation_forbidden' => $t('A inativação manual exige uma decisão editorial individual antes de reativar.'),
    'source_ineligible' => $t('Uma fonte não está apta para esta decisão. Confira publicação, vigência e dependências.'),
    'shared_target' => $t('Duas propostas alteram a mesma orientação. Volte e selecione somente uma delas para aprovação.'),
    'decision_precondition_changed' => $t('As condições da decisão mudaram. Faça uma nova revisão antes de confirmar.'),
    'result_unconfirmed' => $t('O resultado exige reconciliação. Não repita automaticamente a decisão.'),
];
$batchCounts = array_fill_keys(array_keys($batchLabels), 0);
foreach ($batchItems as $batchItem) {
    $batchEffect = (string) ($batchItem['action'] ?? 'review');
    ++$batchCounts[array_key_exists($batchEffect, $batchCounts) ? $batchEffect : 'review'];
    if (empty($batchItem['eligible']) || ($batchAction === 'approve' && $batchEffect === 'review')) {
        $batchReady = false;
    }
}
$batchContent = static function (array $content) use ($t): void {
    $labels = [
        'answer_summary' => $t('Resposta resumida'), 'first_steps' => $t('Primeiros passos'),
        'when_open_ticket' => $t('Quando abrir chamado'), 'required_data' => $t('Dados a coletar'),
        'keywords' => $t('Palavras-chave'), 'questions' => $t('Perguntas de validação'),
        'kb_articles' => $t('Artigos da base associados'),
        'name' => $t('Nome da orientação'), 'intent' => $t('Intenção'),
        'category_hint' => $t('Categoria sugerida'), 'group_hint' => $t('Grupo sugerido'),
        'ticket_template' => $t('Modelo de chamado'),
    ];
    if ($content === []) {
        echo '<p>' . glpiacessivel_e($t('Conteúdo não disponível nesta revisão.')) . '</p>';
        return;
    }
    echo '<dl>';
    foreach ($content as $key => $value) {
        if ($key === 'kb_articles' && is_array($value)) {
            echo '<div><dt>' . glpiacessivel_e($labels[$key]) . '</dt><dd><ul>';
            foreach ($value as $article) {
                if (!is_array($article)) {
                    continue;
                }
                $id = (int) ($article['id'] ?? $article['native_id'] ?? 0);
                $name = trim((string) ($article['name'] ?? $article['title'] ?? ''));
                echo '<li>' . glpiacessivel_e($id > 0
                    ? sprintf($t('Artigo #%d: %s'), $id, $name)
                    : ($name !== '' ? $name : $t('Fonte associada'))) . '</li>';
            }
            echo '</ul></dd></div>';
            continue;
        }
        if (in_array($key, ['questions', 'keywords'], true) && is_array($value)) {
            echo '<div><dt>' . glpiacessivel_e($labels[$key]) . '</dt><dd><ul>';
            foreach ($value as $textValue) {
                echo '<li>' . glpiacessivel_e((string) $textValue) . '</li>';
            }
            echo '</ul></dd></div>';
            continue;
        }
        $text = is_array($value)
            ? (string) json_encode($value, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT)
            : (string) $value;
        echo '<div><dt>' . glpiacessivel_e($labels[$key] ?? (string) $key) . '</dt>'
            . '<dd style="white-space:pre-wrap;overflow-wrap:anywhere;">'
            . glpiacessivel_e($text) . '</dd></div>';
    }
    echo '</dl>';
};
$batchPayload = static function (array $item): array {
    $content = is_array($item['content'] ?? null) ? $item['content'] : [];
    foreach (['name', 'intent', 'category_hint', 'group_hint', 'keywords', 'questions', 'kb_articles', 'ticket_template'] as $key) {
        if (array_key_exists($key, $item)) {
            $content[$key] = $item[$key];
        }
    }
    return $content;
};
$batchForm = static function (string $action, string $label, string $class) use ($batchToken, $csrf_token): void {
    echo '<form method="post" action="' . glpiacessivel_e(glpiacessivel_url('front/playbooks.php')) . '">'
        . '<input type="hidden" name="_glpi_csrf_token" value="' . glpiacessivel_e($csrf_token ?? '') . '" />'
        . '<input type="hidden" name="batch_token" value="' . glpiacessivel_e($batchToken) . '" />'
        . '<input type="hidden" name="action" value="' . glpiacessivel_e($action) . '" />'
        . '<button type="submit" class="glpiacessivel-button ' . glpiacessivel_e($class) . '">'
        . glpiacessivel_e($label) . '</button></form>';
};
$batchAssetPath = 'public/assets/js/editorial-batch.js';
$batchAssetVersion = function_exists('plugin_glpiacessivel_asset_version')
    ? plugin_glpiacessivel_asset_version($batchAssetPath)
    : (string) (@filemtime(__DIR__ . '/../../' . $batchAssetPath) ?: '1');
$batchAssetUrl = \GlpiPlugin\Glpiacessivel\Support\Url::asset($batchAssetPath . '?v=' . rawurlencode($batchAssetVersion));
?>
<div class="glpiacessivel-playbook-admin" style="overflow-wrap:anywhere;">
<section class="glpiacessivel-card" aria-labelledby="editorial-batch-title" data-editorial-review>
  <h2 id="editorial-batch-title" tabindex="-1" data-editorial-focus><?= glpiacessivel_e($batchAction === 'reject' ? $t('Revisar rejeição em lote') : $t('Revisar aprovação em lote')) ?></h2>
  <p><?= glpiacessivel_e($t('Esta revisão ainda não aplica decisões. Confira todas as propostas e suas consequências antes de confirmar. O lote não altera artigos nativos do GLPI.')) ?></p>
  <?php if (!$batchReviewAllowed) : ?>
    <p tabindex="-1" data-editorial-error><?= glpiacessivel_e($t('A revisão em lote não está liberada para o perfil ativo. Nenhuma nova decisão pode ser confirmada. Você pode cancelar ou retornar à fila.')) ?></p>
  <?php endif; ?>
  <?php if (!empty($batchData['expired'])) : ?>
    <p tabindex="-1" data-editorial-error><?= glpiacessivel_e($t('A confirmação expirou. Nenhuma decisão foi aplicada. Renove a revisão para conferir as evidências atuais e confirmar novamente.')) ?></p>
  <?php elseif (!empty($batchData['changed'])) : ?>
    <p tabindex="-1" data-editorial-error><?= glpiacessivel_e($t('A seleção ou as evidências mudaram. Confira novamente todos os itens e consequências desta revisão antes de confirmar.')) ?></p>
  <?php endif; ?>
  <p><?= glpiacessivel_e(sprintf($t('Seleção exata: %d propostas da página original.'), count($batchItems))) ?></p>
  <?php if (!empty($batchData['context_label'])) : ?>
    <p><?= glpiacessivel_e((string) $batchData['context_label']) ?></p>
  <?php endif; ?>
  <p><?= glpiacessivel_e($t('A decisão permanece vinculada ao usuário, perfil, entidade e inclusão de subentidades da seleção. Esses direitos serão conferidos novamente na confirmação.')) ?></p>
  <?php if (!empty($batch_notice)) : ?>
    <p id="editorial-batch-error" tabindex="-1" data-editorial-error><?= glpiacessivel_e((string) $batch_notice) ?></p>
  <?php endif; ?>
  <dl class="glpiacessivel-kpi-grid" aria-label="<?= glpiacessivel_e($t('Propostas por efeito')) ?>">
    <?php foreach ($batchCounts as $effect => $count) : ?>
      <?php if ($count > 0) : ?><div><dt><?= glpiacessivel_e($batchLabels[$effect]) ?></dt><dd><?= $count ?></dd></div><?php endif; ?>
    <?php endforeach; ?>
  </dl>
  <?php if ($batchAction === 'reject') : ?>
    <p><?= glpiacessivel_e($t('Rejeitar retira as propostas da fila de pendentes sem alterar os roteiros. Rejeitar uma inativação não libera conteúdo cuja fonte continua não publicada.')) ?></p>
  <?php endif; ?>
  <?php if (!$batchReady) : ?>
    <div id="editorial-batch-blocked" tabindex="-1" data-editorial-error>
      <p><?= glpiacessivel_e($t('Este lote não pode ser confirmado. Nenhuma proposta foi aplicada, e um subconjunto menor não será confirmado silenciosamente.')) ?></p>
      <p><?= glpiacessivel_e($t('Volte e ajuste a seleção ou renove a revisão. Trate individualmente os impedimentos indicados abaixo.')) ?></p>
      <ul>
        <?php foreach ($batchItems as $index => $item) : ?>
          <?php if (empty($item['eligible']) || ($batchAction === 'approve' && ($item['action'] ?? '') === 'review')) : ?>
            <li><a href="#editorial-review-item-<?= (int) $index ?>"><?= glpiacessivel_e(sprintf($t('Conferir impedimento da proposta %d da seleção'), $index + 1)) ?></a></li>
          <?php endif; ?>
        <?php endforeach; ?>
      </ul>
    </div>
  <?php endif; ?>
  <p><a href="#editorial-batch-confirmation"><?= glpiacessivel_e($t('Ir aos comandos da revisão')) ?></a></p>
  <ol>
    <?php foreach ($batchItems as $index => $item) : ?>
      <?php
      $effect = (string) ($item['action'] ?? 'review');
      $itemEligible = !empty($item['eligible']) && !($batchAction === 'approve' && $effect === 'review');
      $itemReason = !$itemEligible && $batchAction === 'approve' && $effect === 'review'
          ? 'individual_review_required' : (string) ($item['reason'] ?? '');
      $current = is_array($item['current_playbook'] ?? null) ? $item['current_playbook'] : [];
      ?>
      <li>
        <article aria-labelledby="editorial-review-item-<?= (int) $index ?>">
          <h3 id="editorial-review-item-<?= (int) $index ?>" tabindex="-1"><?= glpiacessivel_e(trim((string) ($item['title'] ?? '')) !== ''
              ? sprintf($t('Proposta #%d: %s'), (int) ($item['id'] ?? 0), (string) $item['title'])
              : $t('Proposta indisponível no contexto atual')) ?></h3>
          <p><?= glpiacessivel_e($batchLabels[$effect] ?? $batchLabels['review']) ?> — <?= glpiacessivel_e($itemEligible ? $t('Pronta para a decisão escolhida') : $t('Impedimento à confirmação')) ?></p>
          <?php if (!$itemEligible) : ?>
            <p><?= glpiacessivel_e($batchReasons[$itemReason] ?? $t('Não foi possível validar esta proposta. Retorne à fila e confira o contexto e as evidências antes de decidir.')) ?></p>
          <?php endif; ?>
          <?php if (!empty($item['title'])) : ?>
            <dl>
              <div><dt><?= glpiacessivel_e($t('Orientação alvo')) ?></dt><dd><?= (int) ($item['target_playbook_id'] ?? 0) > 0 ? '#' . (int) $item['target_playbook_id'] : glpiacessivel_e($t('Nova orientação')) ?></dd></div>
              <div><dt><?= glpiacessivel_e($t('Revisão da proposta')) ?></dt><dd><?= (int) ($item['revision'] ?? 0) ?></dd></div>
              <div><dt><?= glpiacessivel_e($t('Revisão esperada do alvo')) ?></dt><dd><?= (int) ($item['expected_revision'] ?? 0) ?></dd></div>
            </dl>
            <?php if (!empty($item['editorial_reason'])) : ?><p><?= glpiacessivel_e((string) $item['editorial_reason']) ?></p><?php endif; ?>
            <?php if ($batchAction === 'approve') : ?>
              <?php if ($effect === 'create') : ?>
                <p><?= glpiacessivel_e($t('Será criado um roteiro aprovado e ativo.')) ?></p>
              <?php elseif ($effect === 'update') : ?>
                <p><?= glpiacessivel_e($t('O conteúdo atual será substituído pelo proposto. O estado ativo ou inativo do roteiro será preservado.')) ?></p>
                <?php if (array_key_exists('is_active', $current)) : ?>
                  <p><?= glpiacessivel_e(!empty($current['is_active']) ? $t('Estado resultante: ativo.') : $t('Estado resultante: inativo.')) ?></p>
                <?php elseif (in_array($current['status'] ?? '', ['active', 'inactive'], true)) : ?>
                  <p><?= glpiacessivel_e($current['status'] === 'active' ? $t('Estado resultante: ativo.') : $t('Estado resultante: inativo.')) ?></p>
                <?php endif; ?>
                <h4><?= glpiacessivel_e($t('Conteúdo atual')) ?></h4>
                <?php $batchContent($batchPayload($current)); ?>
              <?php elseif ($effect === 'inactivate') : ?>
                <p><?= glpiacessivel_e($t('Esta orientação deixará de estar ativa no chatbot. Os artigos e a consulta geral à base de conhecimento não serão alterados.')) ?></p>
              <?php elseif ($effect === 'reactivate') : ?>
                <p><?= glpiacessivel_e($t('Esta orientação voltará ao estado ativo, sujeita à elegibilidade atual de suas fontes.')) ?></p>
                <p><?= glpiacessivel_e($t('O conteúdo também será atualizado para a versão proposta abaixo.')) ?></p>
                <h4><?= glpiacessivel_e($t('Conteúdo atual')) ?></h4>
                <?php $batchContent($batchPayload($current)); ?>
              <?php endif; ?>
            <?php endif; ?>
            <h4><?= glpiacessivel_e($t('Conteúdo proposto para revisão')) ?></h4>
            <?php $batchContent($batchPayload($item)); ?>
          <?php endif; ?>
        </article>
      </li>
    <?php endforeach; ?>
  </ol>
  <p><?= glpiacessivel_e($t('Ativo não significa resposta garantida: publicação, vigência e acesso às fontes continuam sendo revalidados para cada usuário.')) ?></p>
  <div id="editorial-batch-confirmation" tabindex="-1">
    <?php if ($batchReady) : ?>
      <?php $batchForm('batch_confirm', sprintf($batchAction === 'reject' ? $t('Confirmar rejeição de %d propostas') : $t('Confirmar aprovação de %d propostas'), count($batchItems)), $batchAction === 'reject' ? 'glpiacessivel-button-danger' : 'glpiacessivel-button-primary'); ?>
    <?php endif; ?>
    <?php if ($batchToken !== '') : ?>
      <?php if ($batchReviewAllowed) : ?>
        <?php $batchForm('batch_refresh', $t('Renovar a revisão sem aplicar decisões'), 'glpiacessivel-button-secondary'); ?>
      <?php endif; ?>
      <?php $batchForm('batch_back', $t('Voltar e ajustar seleção'), 'glpiacessivel-button-secondary'); ?>
      <?php $batchForm('batch_cancel', $t('Cancelar sem aplicar decisões'), 'glpiacessivel-button-secondary'); ?>
    <?php else : ?>
      <a href="<?= glpiacessivel_e(glpiacessivel_url('front/playbooks.php#suggestions-title')) ?>"><?= glpiacessivel_e($t('Voltar à fila')) ?></a>
    <?php endif; ?>
  </div>
</section>
</div>
<script src="<?= glpiacessivel_e($batchAssetUrl) ?>" defer></script>
