<?php
$criticalConfirmations = is_array($critical_confirmations ?? null) ? $critical_confirmations : [];
$chatbotDisplayName = trim((string) ($chatbot_name ?? 'Assistente'));
if ($chatbotDisplayName === '') {
    $chatbotDisplayName = 'Assistente';
}
$t = static function (string $text): string {
    return __($text, 'glpiacessivel');
};
$playbookLines = static function ($values): string {
    return implode("\n", array_map('strval', (array) $values));
};
$playbookSummary = static function (array $playbook): string {
    $content = is_array($playbook['content'] ?? null) ? $playbook['content'] : [];
    return (string) ($content['answer_summary'] ?? '');
};
$playbookKbArticles = static function (array $playbook): string {
    $lines = [];
    foreach ((array) ($playbook['kb_articles'] ?? []) as $article) {
        if (!is_array($article)) {
            continue;
        }
        $id = (int) ($article['id'] ?? 0);
        $name = trim((string) ($article['name'] ?? ''));
        if ($id > 0 && $name !== '') {
            $lines[] = $id . ' | ' . $name;
        } elseif ($id > 0) {
            $lines[] = (string) $id;
        } elseif ($name !== '') {
            $lines[] = $name;
        }
    }

    return implode("\n", $lines);
};
$playbookKbArticleLinks = static function (array $playbook) use ($t): array {
    $links = [];
    foreach ((array) ($playbook['kb_articles'] ?? []) as $article) {
        if (!is_array($article)) {
            continue;
        }

        $id = (int) ($article['id'] ?? 0);
        $name = trim((string) ($article['name'] ?? ''));
        if ($id <= 0 && $name === '') {
            continue;
        }

        $links[] = [
            'id' => $id,
            'name' => $name !== '' ? $name : sprintf($t('Artigo #%d'), $id),
        ];
    }

    return $links;
};
$playbookContentValue = static function (array $playbook, string $key): string {
    $content = is_array($playbook['content'] ?? null) ? $playbook['content'] : [];
    $value = $content[$key] ?? '';
    if (is_array($value)) {
        $value = implode('; ', array_map('strval', array_slice($value, 0, 4)));
    }

    return trim((string) $value);
};
$playbookSuggestionSummary = static function (array $suggestion) use ($playbookContentValue, $t): string {
    foreach (['answer_summary', 'first_steps', 'when_open_ticket'] as $field) {
        $value = $playbookContentValue($suggestion, $field);
        if ($value !== '') {
            return $value;
        }
    }

    $questions = array_values(array_filter(array_map('strval', (array) ($suggestion['questions'] ?? []))));
    if ($questions !== []) {
        return $questions[0];
    }

    return $t('Sem resumo informado.');
};
$playbookShortText = static function (string $text, int $limit = 220): string {
    $text = trim(preg_replace('/\s+/', ' ', $text) ?? $text);
    if (mb_strlen($text, 'UTF-8') <= $limit) {
        return $text;
    }

    return rtrim(mb_substr($text, 0, $limit - 1, 'UTF-8')) . '...';
};
$queueFilters = is_array($queue_filters ?? null) ? $queue_filters : ['state' => 'pending', 'action' => 'all', 'page' => 1];
$queueData = is_array($queue ?? null) ? $queue : ['total' => count((array) ($suggestions ?? [])), 'page' => 1, 'page_size' => 20];
$scanValues = is_array($scan_values ?? null) ? $scan_values : [];
$knowledgeScanAllowed = !empty($knowledge_scan_allowed);
$batchReviewAllowed = !empty($batch_review_allowed);
$batchPageToken = $batchReviewAllowed ? (string) ($batch_page_token ?? '') : '';
$batchSelectedIds = array_map('intval', (array) ($batch_selected_ids ?? []));
$batchReport = is_array($batch_report ?? null) ? $batch_report : [];
$batchSelectableCount = count(array_filter((array) ($suggestions ?? []), static function ($proposal): bool {
    return is_array($proposal) && (int) ($proposal['id'] ?? 0) > 0 && ($proposal['status'] ?? 'pending') === 'pending';
}));
$batchAssetPath = 'public/assets/js/editorial-batch.js';
$batchAssetVersion = function_exists('plugin_glpiacessivel_asset_version')
    ? plugin_glpiacessivel_asset_version($batchAssetPath)
    : (string) (@filemtime(__DIR__ . '/../../' . $batchAssetPath) ?: '1');
$batchAssetUrl = \GlpiPlugin\Glpiacessivel\Support\Url::asset($batchAssetPath . '?v=' . rawurlencode($batchAssetVersion));
$actionLabels = [
    'create' => $t('Criar orientação'), 'update' => $t('Atualizar orientação'),
    'inactivate' => $t('Inativar orientação'), 'reactivate' => $t('Reativar orientação'), 'review' => $t('Revisar orientação'),
];
$stateLabels = [
    'pending' => $t('Pendente'), 'approved' => $t('Aprovada'), 'rejected' => $t('Rejeitada'),
    'superseded' => $t('Substituída'), 'conflict' => $t('Conflitante'), 'failed' => $t('Falhou'),
    'obsolete' => $t('Desatualizada'), 'blocked' => $t('Bloqueada'), 'unknown' => $t('Não confirmado'),
];
$jobLabels = [
    'prepared' => $t('Preparada'), 'queued' => $t('Preparada'), 'running' => $t('Em andamento'), 'partial' => $t('Parcial'),
    'paused' => $t('Pausada'), 'completed' => $t('Concluída'), 'failed' => $t('Falhou'),
    'cancelled' => $t('Cancelada'), 'unknown' => $t('Não confirmado'),
];
$returnFields = static function () use ($queueFilters): void {
    foreach (['queue_state' => 'state', 'queue_action' => 'action', 'queue_page' => 'page'] as $name => $key) {
        echo '<input type="hidden" name="' . glpiacessivel_e($name) . '" value="'
            . glpiacessivel_e((string) ($queueFilters[$key] ?? '')) . '" />';
    }
};
$noJsConfirmation = static function (string $id) use ($t): void {
    echo '<noscript><p><label for="' . glpiacessivel_e($id) . '"><input id="' . glpiacessivel_e($id)
        . '" type="checkbox" name="critical_confirmed" value="1" required /> '
        . glpiacessivel_e($t('Li as consequências e confirmo esta decisão.')) . '</label></p></noscript>';
};

?>

<div class="glpiacessivel-playbook-admin">
<section class="glpiacessivel-card" aria-labelledby="playbooks-title">
  <p class="glpiacessivel-eyebrow"><?= glpiacessivel_e($t('Chatbot operacional')) ?></p>
  <h2 id="playbooks-title"><?= glpiacessivel_e($t('Roteiros do chatbot')) ?></h2>
  <p>
      <?= glpiacessivel_e(sprintf($t('Revisão de conteúdos para %s. A varredura cria sugestões a partir da base de conhecimento, mas apenas roteiros aprovados entram nas respostas do chatbot.'), $chatbotDisplayName)) ?>
  </p>

  <?php if (!empty($message)) : ?>
    <p id="playbook-action-result" tabindex="-1" <?= $batchReport === [] && empty($batch_notice) ? 'data-glpiacessivel-focus-alert' : '' ?>
       role="<?= ($message_type ?? 'info') === 'error' ? 'alert' : 'status' ?>"
       class="glpiacessivel-alert <?= ($message_type ?? 'info') === 'error' ? 'glpiacessivel-alert-danger' : 'glpiacessivel-alert-info' ?>">
        <?= glpiacessivel_e($message) ?>
    </p>
  <?php endif; ?>
  <?php if (!empty($scan_error) && $knowledgeScanAllowed) : ?>
    <p><?= glpiacessivel_e($t('Confira os filtros ou consulte o diagnóstico da execução.')) ?>
      <a href="#playbook-publication"><?= glpiacessivel_e($t('Publicação da fonte')) ?></a>;
      <a href="#playbook-batch-size"><?= glpiacessivel_e($t('Candidatos por lote')) ?></a>;
      <a href="#playbook-limit"><?= glpiacessivel_e($t('Limite total desta execução')) ?></a>.
    </p>
  <?php endif; ?>
</section>

<section class="glpiacessivel-card" aria-labelledby="scan-title">
  <h2 id="scan-title"><?= glpiacessivel_e($t('Varredura da base de conhecimento')) ?></h2>
  <?php if (!$knowledgeScanAllowed) : ?>
    <p><?= glpiacessivel_e($t('A varredura não está liberada para o perfil ativo. A consulta das execuções e propostas anteriores, a pausa e o cancelamento continuam disponíveis conforme suas permissões.')) ?></p>
  <?php else : ?>
  <p>
    <?= glpiacessivel_e($t('A varredura gera propostas para revisão; não efetua publicação automática. Cada envio processa um lote finito no contexto autorizado atual.')) ?>
  </p>
  <p id="scan-scope-help"><?= glpiacessivel_e($t('Publicado, vigência e permissão são avaliações diferentes. FAQ não significa acesso público. Esta etapa lê texto de artigos, não imagens nem anexos por OCR.')) ?></p>
  <p><?= glpiacessivel_e($t('Os filtros de publicação e FAQ selecionam a geração de propostas novas. As fontes já vinculadas também são reconciliadas no escopo autorizado, para detectar orientações que deixaram de estar publicadas.')) ?></p>

  <form method="post" action="<?= glpiacessivel_e(glpiacessivel_url('front/playbooks.php')) ?>" class="glpiacessivel-form-grid">
    <input type="hidden" name="_glpi_csrf_token" value="<?= glpiacessivel_e($csrf_token ?? '') ?>" />
    <input type="hidden" name="action" value="run_kb_initial" />
    <?php $returnFields(); ?>

    <label for="playbook-publication"><?= glpiacessivel_e($t('Publicação da fonte')) ?></label>
    <select id="playbook-publication" name="publication" aria-describedby="scan-scope-help">
      <option value="all" <?= ($scanValues['publication'] ?? 'all') === 'all' ? 'selected' : '' ?>><?= glpiacessivel_e($t('Publicados e não publicados')) ?></option>
      <option value="published" <?= ($scanValues['publication'] ?? '') === 'published' ? 'selected' : '' ?>><?= glpiacessivel_e($t('Publicados')) ?></option>
      <option value="unpublished" <?= ($scanValues['publication'] ?? '') === 'unpublished' ? 'selected' : '' ?>><?= glpiacessivel_e($t('Não publicados, para revisão')) ?></option>
    </select>

    <label for="playbook-faq-only"><?= glpiacessivel_e($t('Tipo de artigo')) ?></label>
    <select id="playbook-faq-only" name="faq_only">
      <option value="0" <?= ($scanValues['faq_only'] ?? '0') === '0' ? 'selected' : '' ?>><?= glpiacessivel_e($t('Todos os artigos autorizados')) ?></option>
      <option value="1" <?= ($scanValues['faq_only'] ?? '') === '1' ? 'selected' : '' ?>><?= glpiacessivel_e($t('Artigos marcados como FAQ')) ?></option>
    </select>
    <label for="playbook-batch-size"><?= glpiacessivel_e($t('Candidatos por lote')) ?></label>
    <select id="playbook-batch-size" name="batch_size"><option value="25" <?= (int) ($scanValues['batch_size'] ?? 25) === 25 ? 'selected' : '' ?>>25</option><option value="50" <?= (int) ($scanValues['batch_size'] ?? 0) === 50 ? 'selected' : '' ?>>50</option></select>
    <label for="playbook-limit"><?= glpiacessivel_e($t('Limite total desta execução')) ?></label>
    <input id="playbook-limit" name="limit" type="number" min="1" max="5000" step="1" value="<?= max(1, min(5000, (int) ($scanValues['limit'] ?? 500))) ?>" required aria-describedby="scan-limit-help" />
    <p id="scan-limit-help"><?= glpiacessivel_e($t('O limite total não é o tamanho do lote. Continue as etapas para percorrer o escopo até esse limite, sem afirmar cobertura de toda a instalação.')) ?></p>
    <p><?= glpiacessivel_e($t('Perfil, entidade e inclusão de subentidades são os do contexto atual do GLPI. Inventário amplo exige os direitos administrativos nativos da base.')) ?></p>

    <div class="glpiacessivel-field" style="grid-column:1 / -1;">
        <button type="submit" class="glpiacessivel-button glpiacessivel-button-primary glpiacessivel-primary-action"><?= glpiacessivel_e($t('Gerar sugestões')) ?></button>
    </div>
  </form>
  <?php endif; ?>
  <p><a class="glpiacessivel-button glpiacessivel-button-secondary glpiacessivel-secondary-action" href="<?= glpiacessivel_e(glpiacessivel_url('front/playbooks.php?export=1')) ?>">
    <?= glpiacessivel_e($t('Exportar roteiros aprovados')) ?>
  </a></p>

  <?php if (is_array($result ?? null)) : ?>
      <dl class="glpiacessivel-kpi-grid" aria-label="<?= glpiacessivel_e($t('Resultado da última varredura')) ?>">
      <div>
        <dt><?= glpiacessivel_e($t('Artigos analisados')) ?></dt>
        <dd><?= (int) ($result['processed'] ?? 0) ?></dd>
      </div>
      <div>
          <dt><?= glpiacessivel_e($t('Sugestões geradas')) ?></dt>
        <dd><?= (int) ($result['suggestions'] ?? 0) ?></dd>
      </div>
      <div>
        <dt><?= glpiacessivel_e($t('Execução')) ?></dt>
        <?php
          $scanStatus = (string) ($result['status'] ?? '');
          $scanStatusLabels = $jobLabels;
        ?>
        <dd><?= glpiacessivel_e((string) ($scanStatusLabels[$scanStatus] ?? $scanStatus)) ?></dd>
      </div>
    </dl>
  <?php endif; ?>
</section>

<section class="glpiacessivel-card" aria-labelledby="scan-jobs-title">
  <h2 id="scan-jobs-title"><?= glpiacessivel_e($t('Execuções no contexto autorizado')) ?></h2>
  <p><?= glpiacessivel_e($t('Atualizar a página consulta o estado; não executa outro lote. Pausar ou cancelar preserva as propostas anteriores. A continuação revalida os direitos e o contexto.')) ?></p>
  <?php if (empty($jobs)) : ?>
    <p><?= glpiacessivel_e($t('Nenhuma execução disponível neste contexto.')) ?></p>
  <?php else : ?>
    <ul>
      <?php foreach ((array) $jobs as $job) : ?>
            <?php
            $jobId = (int) ($job['id'] ?? $job['job_id'] ?? 0);
            $jobStatus = (string) ($job['status'] ?? 'unknown');
            if ($jobId <= 0) {
                continue;
            }
            $continuable = in_array($jobStatus, ['prepared', 'queued', 'paused'], true);
            ?>
        <li>
          <article aria-labelledby="scan-job-<?= $jobId ?>">
            <h3 id="scan-job-<?= $jobId ?>"><?= glpiacessivel_e(sprintf($t('Execução #%d'), $jobId)) ?> — <?= glpiacessivel_e($jobLabels[$jobStatus] ?? $jobLabels['unknown']) ?></h3>
            <dl class="glpiacessivel-kpi-grid">
              <?php foreach (['examined' => $t('Candidatos examinados'), 'processed' => $t('Artigos analisados'), 'suggestions' => $t('Propostas registradas'), 'skipped' => $t('Sem proposta nesta etapa'), 'failed' => $t('Falhas registradas')] as $counter => $label) : ?>
                <div><dt><?= glpiacessivel_e($label) ?></dt><dd><?= max(0, (int) ($job[$counter] ?? 0)) ?></dd></div>
              <?php endforeach; ?>
            </dl>
            <?php if ($jobStatus === 'unknown' || $jobStatus === 'failed') : ?>
              <p><?= glpiacessivel_e($t('Não repita automaticamente uma etapa com resultado não confirmado. Confira o diagnóstico antes de iniciar nova execução.')) ?></p>
            <?php endif; ?>
            <?php if ($continuable) : ?>
              <form method="post" action="<?= glpiacessivel_e(glpiacessivel_url('front/playbooks.php')) ?>">
                <input type="hidden" name="_glpi_csrf_token" value="<?= glpiacessivel_e($csrf_token ?? '') ?>" />
                <input type="hidden" name="job_id" value="<?= $jobId ?>" /><?php $returnFields(); ?>
                <?php if ($knowledgeScanAllowed) : ?>
                  <button type="submit" name="action" value="continue_kb_scan" class="glpiacessivel-button glpiacessivel-button-primary" aria-label="<?= glpiacessivel_e(sprintf($t('Processar próximo lote da execução %d'), $jobId)) ?>"><?= glpiacessivel_e($t('Processar próximo lote')) ?></button>
                <?php endif; ?>
                <?php if ($jobStatus !== 'paused') : ?>
                  <button type="submit" name="action" value="pause_kb_scan" class="glpiacessivel-button glpiacessivel-button-secondary" aria-label="<?= glpiacessivel_e(sprintf($t('Pausar execução %d'), $jobId)) ?>"><?= glpiacessivel_e($t('Pausar')) ?></button>
                <?php endif; ?>
              </form>
              <form method="post" action="<?= glpiacessivel_e(glpiacessivel_url('front/playbooks.php')) ?>" data-glpiacessivel-critical-form data-critical-title="<?= glpiacessivel_e($t('Confirmar cancelamento da varredura')) ?>" data-critical-message="<?= glpiacessivel_e($t('Este job não será retomado. As propostas já registradas serão preservadas.')) ?>">
                <input type="hidden" name="_glpi_csrf_token" value="<?= glpiacessivel_e($csrf_token ?? '') ?>" />
                <input type="hidden" name="action" value="cancel_kb_scan" /><input type="hidden" name="job_id" value="<?= $jobId ?>" />
                <input type="hidden" name="critical_confirmed" value="0" /><input type="hidden" name="critical_confirmation_token" value="<?= glpiacessivel_e((string) ($criticalConfirmations['cancel_kb_scan:' . $jobId] ?? '')) ?>" />
                <?php $returnFields();
                $noJsConfirmation('confirm-cancel-job-' . $jobId); ?>
                <button type="submit" class="glpiacessivel-button glpiacessivel-button-danger" aria-label="<?= glpiacessivel_e(sprintf($t('Cancelar execução %d, preservando propostas'), $jobId)) ?>"><?= glpiacessivel_e($t('Cancelar execução')) ?></button>
              </form>
            <?php endif; ?>
          </article>
        </li>
      <?php endforeach; ?>
    </ul>
  <?php endif; ?>
</section>

<section class="glpiacessivel-card" aria-labelledby="manual-playbook-title">
  <h2 id="manual-playbook-title"><?= glpiacessivel_e($t('Cadastrar roteiro manualmente')) ?></h2>
  <p>
    <?= glpiacessivel_e($t('Use esta área para cadastrar um roteiro sem varredura. O roteiro pode ser criado como ativo, pendente para análise ou inativo. Associe um artigo da base por linha no formato ID | Título do artigo.')) ?>
  </p>

  <form method="post" action="<?= glpiacessivel_e(glpiacessivel_url('front/playbooks.php')) ?>" class="glpiacessivel-playbook-manual-form">
    <input type="hidden" name="_glpi_csrf_token" value="<?= glpiacessivel_e($csrf_token ?? '') ?>" />
    <input type="hidden" name="action" value="create_playbook" />
    <?php $returnFields(); ?>

    <fieldset class="glpiacessivel-playbook-form-section">
      <legend><?= glpiacessivel_e($t('Identificação e ativação')) ?></legend>
      <p><?= glpiacessivel_e(sprintf($t('Defina como o roteiro será reconhecido e se ele já pode ser usado por %s.'), $chatbotDisplayName)) ?></p>
      <div class="glpiacessivel-playbook-form-grid">
        <div class="glpiacessivel-field">
          <label for="manual-playbook-name"><?= glpiacessivel_e($t('Nome do roteiro')) ?></label>
          <input id="manual-playbook-name" name="name" type="text" />
        </div>

        <div class="glpiacessivel-field">
          <label for="manual-playbook-status"><?= glpiacessivel_e($t('Estado inicial')) ?></label>
          <select id="manual-playbook-status" name="status">
            <option value="active"><?= glpiacessivel_e($t('Ativo no chatbot')) ?></option>
            <option value="pending"><?= glpiacessivel_e($t('Pendente para análise')) ?></option>
            <option value="inactive"><?= glpiacessivel_e($t('Inativo')) ?></option>
          </select>
        </div>

        <div class="glpiacessivel-field">
          <label for="manual-playbook-intent"><?= glpiacessivel_e($t('Intenção')) ?></label>
          <input id="manual-playbook-intent" name="intent" type="text" value="kb_recomendar_contextual" />
        </div>
      </div>
    </fieldset>

    <fieldset class="glpiacessivel-playbook-form-section">
      <legend><?= glpiacessivel_e($t('Contexto de busca e encaminhamento')) ?></legend>
      <p><?= glpiacessivel_e($t('Cadastre palavras e perguntas que ajudem o chatbot a reconhecer a situação do usuário.')) ?></p>
      <div class="glpiacessivel-playbook-form-grid">
        <div class="glpiacessivel-field">
          <label for="manual-playbook-category"><?= glpiacessivel_e($t('Categoria sugerida')) ?></label>
          <input id="manual-playbook-category" name="category_hint" type="text" />
        </div>

        <div class="glpiacessivel-field">
          <label for="manual-playbook-group"><?= glpiacessivel_e($t('Grupo sugerido')) ?></label>
          <input id="manual-playbook-group" name="group_hint" type="text" />
        </div>

        <div class="glpiacessivel-field span-3">
          <label for="manual-playbook-keywords"><?= glpiacessivel_e($t('Palavras-chave')) ?></label>
          <textarea id="manual-playbook-keywords" name="keywords" rows="5"></textarea>
          <p class="glpiacessivel-field-hint"><?= glpiacessivel_e($t('Use uma palavra ou expressão por linha. Exemplo: VPN, acesso remoto, Forticlient.')) ?></p>
        </div>

        <div class="glpiacessivel-field span-3">
          <label for="manual-playbook-questions"><?= glpiacessivel_e($t('Perguntas de validação')) ?></label>
          <textarea id="manual-playbook-questions" name="questions" rows="5"></textarea>
          <p class="glpiacessivel-field-hint"><?= glpiacessivel_e($t('Perguntas usadas para confirmar o contexto antes de abrir um chamado.')) ?></p>
        </div>
      </div>
    </fieldset>

    <fieldset class="glpiacessivel-playbook-form-section">
      <legend><?= glpiacessivel_e($t('Resposta e base de conhecimento')) ?></legend>
        <p><?= glpiacessivel_e(sprintf($t('Associe artigos do GLPI para que %s apresente orientação e link direto ao usuário.'), $chatbotDisplayName)) ?></p>
      <div class="glpiacessivel-playbook-form-grid">
        <div class="glpiacessivel-field span-2">
          <label for="manual-playbook-summary"><?= glpiacessivel_e($t('Resposta resumida')) ?></label>
          <textarea id="manual-playbook-summary" name="answer_summary" rows="5"></textarea>
        </div>

        <div class="glpiacessivel-field">
          <label for="manual-playbook-kb"><?= glpiacessivel_e($t('Artigos da base associados')) ?></label>
          <textarea id="manual-playbook-kb" name="kb_articles" rows="5" aria-describedby="manual-playbook-kb-help"></textarea>
          <p id="manual-playbook-kb-help" class="glpiacessivel-field-hint">
            <?= glpiacessivel_e($t('Informe um artigo por linha. Exemplo: 123 | VPN - acesso remoto.')) ?>
          </p>
        </div>
      </div>
    </fieldset>

    <div class="glpiacessivel-playbook-actions">
      <button type="submit" class="glpiacessivel-button glpiacessivel-button-primary glpiacessivel-primary-action"><?= glpiacessivel_e($t('Cadastrar roteiro')) ?></button>
    </div>
  </form>
</section>

<?php if ($batchReport !== []) : ?>
<section class="glpiacessivel-card" aria-labelledby="editorial-batch-result">
  <h2 id="editorial-batch-result" tabindex="-1" data-editorial-focus><?= glpiacessivel_e($t('Resultado da decisão editorial em lote')) ?></h2>
  <?php $batchResultLabels = [
      'applied' => $t('Aplicada'), 'already_decided' => $t('Já decidida, sem nova alteração'),
      'conflict' => $t('Conflito'), 'not_applied' => $t('Não aplicada'),
      'not_processed' => $t('Não processada'), 'unknown' => $t('Resultado a confirmar'),
  ];
  $batchResultReasons = [
      'source_unavailable' => $t('Não foi possível confirmar o acesso às fontes no contexto atual.'),
      'access_unavailable' => $t('Não foi possível confirmar o acesso às fontes no contexto atual.'),
      'context_changed' => $t('O contexto mudou. Retorne à fila no perfil e entidade corretos e faça uma nova revisão.'),
      'already_decided' => $t('A proposta já havia sido decidida; nenhuma nova alteração foi aplicada.'),
      'proposal_changed' => $t('A proposta mudou desde a revisão.'),
      'target_changed' => $t('A orientação alvo mudou desde a revisão.'),
      'source_changed' => $t('Uma fonte mudou desde a revisão.'),
      'mapping_required' => $t('Os vínculos da importação precisam de mapeamento.'),
      'individual_review_required' => $t('Esta proposta exige revisão individual.'),
      'entity_mismatch' => $t('A entidade da proposta não corresponde ao contexto de decisão.'),
      'manual_reactivation_forbidden' => $t('A inativação manual exige uma decisão editorial individual antes de reativar.'),
      'source_ineligible' => $t('Uma fonte não está apta para esta decisão.'),
      'shared_target' => $t('Duas propostas alteram a mesma orientação.'),
      'decision_precondition_changed' => $t('As condições da decisão mudaram.'),
      'result_unconfirmed' => $t('O resultado exige reconciliação. Não repita automaticamente a decisão.'),
      'reconciliation_required' => $t('O resultado exige reconciliação. Não repita automaticamente a decisão.'),
  ];
  $batchResultCounts = array_fill_keys(array_keys($batchResultLabels), 0);
  foreach ((array) ($batchReport['items'] ?? []) as $batchResultItem) {
      $batchResultState = (string) ($batchResultItem['status'] ?? 'unknown');
      ++$batchResultCounts[array_key_exists($batchResultState, $batchResultCounts) ? $batchResultState : 'unknown'];
  }
  ?>
  <p><?= glpiacessivel_e(($batchReport['status'] ?? '') === 'completed'
      ? $t('Operação concluída. Confira o resultado de cada proposta abaixo.')
      : $t('Operação incompleta. Os resultados conhecidos foram preservados; nem todas as propostas foram aplicadas.')) ?></p>
  <p><?= glpiacessivel_e(($batchReport['action'] ?? '') === 'reject' ? $t('Decisão solicitada: rejeição das propostas.') : $t('Decisão solicitada: aprovação das propostas.')) ?></p>
  <dl class="glpiacessivel-kpi-grid">
    <?php foreach ($batchResultCounts as $batchResultState => $batchResultCount) : ?>
      <div><dt><?= glpiacessivel_e($batchResultLabels[$batchResultState]) ?></dt><dd><?= $batchResultCount ?></dd></div>
    <?php endforeach; ?>
  </dl>
  <ul>
    <?php foreach ((array) ($batchReport['items'] ?? []) as $batchResultItem) : ?>
      <li>
        <p><?= glpiacessivel_e(trim((string) ($batchResultItem['title'] ?? '')) !== ''
            ? sprintf($t('Proposta #%d: %s'), (int) ($batchResultItem['id'] ?? 0), (string) $batchResultItem['title'])
            : $t('Proposta indisponível no contexto atual')) ?> —
          <?= glpiacessivel_e($batchResultLabels[$batchResultItem['status'] ?? 'unknown'] ?? $batchResultLabels['unknown']) ?>.</p>
        <?php if (!empty($batchResultItem['reason'])) : ?>
          <p><?= glpiacessivel_e($batchResultReasons[$batchResultItem['reason']] ?? $t('Confira o estado atual da proposta antes de uma nova decisão.')) ?></p>
        <?php endif; ?>
        <?php if (($batchResultItem['status'] ?? '') === 'unknown') : ?>
          <p><?= glpiacessivel_e($t('Confira e reconcilie o estado antes de uma nova decisão. Não repita automaticamente esta operação.')) ?></p>
        <?php elseif (in_array($batchResultItem['status'] ?? '', ['conflict', 'not_applied', 'not_processed'], true)) : ?>
          <p><?= glpiacessivel_e($t('Consulte a proposta na fila e faça uma nova revisão antes de decidir novamente.')) ?></p>
        <?php endif; ?>
      </li>
    <?php endforeach; ?>
  </ul>
  <a href="#suggestions-title"><?= glpiacessivel_e($t('Voltar à fila')) ?></a>
</section>
<?php endif; ?>

<section class="glpiacessivel-card" aria-labelledby="suggestions-title" data-editorial-selection
  data-selection-message="<?= glpiacessivel_e($t('{count} propostas selecionadas nesta página.')) ?>"
  data-selection-empty="<?= glpiacessivel_e($t('Selecione ao menos uma proposta para iniciar a revisão.')) ?>"
  data-selection-cleared="<?= glpiacessivel_e($t('Seleção limpa. Nenhuma proposta foi alterada.')) ?>"
  data-selection-navigation="<?= glpiacessivel_e($t('Ao trocar filtros, página, perfil ou entidade, a seleção desta página será limpa. Deseja continuar?')) ?>">
  <h2 id="suggestions-title"><?= glpiacessivel_e($t('Fila de revisão editorial')) ?></h2>
  <?php if (!$batchReviewAllowed) : ?>
    <p><?= glpiacessivel_e($t('A revisão em lote não está liberada para o perfil ativo. As propostas, os resultados anteriores e as decisões individuais continuam disponíveis conforme suas permissões.')) ?></p>
  <?php endif; ?>
  <?php if (!empty($batch_notice)) : ?>
    <p tabindex="-1" data-editorial-focus><?= glpiacessivel_e((string) $batch_notice) ?></p>
  <?php endif; ?>
  <form method="get" action="<?= glpiacessivel_e(glpiacessivel_url('front/playbooks.php')) ?>" class="glpiacessivel-form-grid" data-editorial-filter>
    <label for="queue-state"><?= glpiacessivel_e($t('Estado da proposta')) ?></label>
    <select id="queue-state" name="queue_state">
      <?php foreach (['pending' => $t('Pendentes'), 'approved' => $t('Aprovadas'), 'rejected' => $t('Rejeitadas'), 'superseded' => $t('Substituídas'), 'conflict' => $t('Conflitantes'), 'failed' => $t('Falharam'), 'all' => $t('Todos os estados')] as $value => $label) : ?>
        <option value="<?= glpiacessivel_e($value) ?>" <?= ($queueFilters['state'] ?? '') === $value ? 'selected' : '' ?>><?= glpiacessivel_e($label) ?></option>
      <?php endforeach; ?>
    </select>
    <label for="queue-action"><?= glpiacessivel_e($t('Decisão proposta')) ?></label>
    <select id="queue-action" name="queue_action">
      <option value="all"><?= glpiacessivel_e($t('Todas as ações')) ?></option>
      <?php foreach ($actionLabels as $value => $label) : ?>
        <option value="<?= glpiacessivel_e($value) ?>" <?= ($queueFilters['action'] ?? '') === $value ? 'selected' : '' ?>><?= glpiacessivel_e($label) ?></option>
      <?php endforeach; ?>
    </select>
    <button type="submit" class="glpiacessivel-button glpiacessivel-button-primary"><?= glpiacessivel_e($t('Filtrar propostas')) ?></button>
  </form>
  <?php if (isset($queueData['total'])) : ?>
    <p><?= glpiacessivel_e(sprintf($t('Propostas neste filtro: %d. Página %d.'), (int) $queueData['total'], (int) ($queueData['page'] ?? 1))) ?></p>
  <?php endif; ?>

  <?php if (!empty($queueData['access_incomplete'])) : ?>
    <p role="alert"><?= glpiacessivel_e($t('Não foi possível apresentar a fila com as permissões atuais. Revise seu perfil ou os filtros. Nenhuma proposta foi alterada.')) ?></p>
  <?php elseif (empty($suggestions)) : ?>
    <p><?= glpiacessivel_e($t('Nenhuma proposta encontrada neste filtro.')) ?></p>
    <a href="<?= glpiacessivel_e(glpiacessivel_url('front/playbooks.php?queue_state=pending&queue_action=all#suggestions-title')) ?>"><?= glpiacessivel_e($t('Limpar filtros')) ?></a>
  <?php else : ?>
    <p role="status" aria-live="polite">
      <?php $pendingSuggestionCount = count((array) $suggestions); ?>
      <?= glpiacessivel_e(sprintf(
          _n(
              'Esta página apresenta %d proposta.',
              'Esta página apresenta %d propostas.',
              $pendingSuggestionCount,
              'glpiacessivel'
          ),
          $pendingSuggestionCount
      )) ?>
    </p>
    <?php if ($batchPageToken !== '' && $batchSelectableCount > 0) : ?>
      <p id="editorial-selection-help"><?= glpiacessivel_e($t('Selecione propostas pendentes desta página. Os comandos em lote abrem uma revisão antes de qualquer alteração. Trocar filtros, página, perfil ou entidade limpa a seleção.')) ?></p>
      <p><a href="#editorial-batch-commands"><?= glpiacessivel_e($t('Ir aos comandos de revisão em lote')) ?></a></p>
      <form id="editorial-batch-selection" method="post" action="<?= glpiacessivel_e(glpiacessivel_url('front/playbooks.php')) ?>" data-editorial-form>
        <input type="hidden" name="_glpi_csrf_token" value="<?= glpiacessivel_e($csrf_token ?? '') ?>" />
        <input type="hidden" name="batch_page_token" value="<?= glpiacessivel_e($batchPageToken) ?>" />
        <?php $returnFields(); ?>
      </form>
      <fieldset aria-describedby="editorial-selection-help">
        <legend><?= glpiacessivel_e($t('Seleção de propostas desta página')) ?></legend>
        <div hidden data-editorial-enhancement>
          <label for="editorial-select-page" style="display:flex;align-items:center;gap:.5rem;min-height:24px;"><input id="editorial-select-page" type="checkbox" data-editorial-all /> <?= glpiacessivel_e($t('Selecionar propostas pendentes desta página')) ?></label>
          <button type="button" class="glpiacessivel-button glpiacessivel-button-secondary" data-editorial-clear><?= glpiacessivel_e($t('Limpar seleção')) ?></button>
          <p id="editorial-selection-count" role="status" aria-atomic="true" data-editorial-count></p>
        </div>
        <noscript><p><?= glpiacessivel_e($t('A quantidade exata será apresentada na revisão. Para limpar a seleção, desmarque as propostas.')) ?></p>
          <button type="submit" form="editorial-batch-selection" name="action" value="batch_select_page" class="glpiacessivel-button glpiacessivel-button-secondary"><?= glpiacessivel_e($t('Selecionar propostas pendentes desta página')) ?></button>
        </noscript>
    <?php elseif ($batchSelectableCount === 0) : ?>
      <p><?= glpiacessivel_e($t('Nenhuma proposta pendente nesta página. As decisões anteriores continuam disponíveis para consulta.')) ?></p>
    <?php endif; ?>
    <ul class="glpiacessivel-playbook-suggestion-list glpiacessivel-playbook-suggestion-list-compact" aria-label="<?= glpiacessivel_e($t('Propostas de revisão editorial')) ?>">
      <?php foreach ((array) $suggestions as $suggestionIndex => $suggestion) : ?>
            <?php
            $suggestionId = (int) ($suggestion['id'] ?? 0);
            $suggestionKey = $suggestionId > 0 ? (string) $suggestionId : ('tmp-' . (int) $suggestionIndex);
            $suggestionDisplayId = $suggestionId > 0 ? (string) $suggestionId : $t('sem ID');
            $suggestionTitle = trim((string) ($suggestion['title'] ?? $t('Sugestão')));
            $suggestionTitle = $suggestionTitle !== '' ? $suggestionTitle : $t('Sugestão');
            $sourceType = (string) ($suggestion['source_type'] ?? '');
            $sourceTypeLabels = [
              'kb' => $t('Base de conhecimento'),
              'knowledge_base' => $t('Base de conhecimento'),
              'manual' => $t('Cadastro manual'),
              'manual_review' => $t('Revisão manual'),
              'manual_import' => $t('Importação manual'),
            ];
            $summary = $playbookSuggestionSummary($suggestion);
            $compactSummary = $playbookShortText($summary, 220);
            $firstSteps = $playbookContentValue($suggestion, 'first_steps');
            $whenOpenTicket = $playbookContentValue($suggestion, 'when_open_ticket');
            $requiredData = $playbookContentValue($suggestion, 'required_data');
            $ticketTemplate = is_array($suggestion['ticket_template'] ?? null) ? $suggestion['ticket_template'] : [];
            $questionsAll = array_values(array_filter(array_map('strval', (array) ($suggestion['questions'] ?? []))));
            $keywordsAll = array_values(array_filter(array_map('strval', (array) ($suggestion['keywords'] ?? []))));
            $kbLinks = $playbookKbArticleLinks($suggestion);
            $titleId = 'suggestion-title-' . $suggestionKey;
            $summaryId = 'suggestion-summary-' . $suggestionKey;
            $metaId = 'suggestion-meta-' . $suggestionKey;
            $editId = 'suggestion-edit-' . $suggestionKey;
            $proposalAction = (string) ($suggestion['action'] ?? $suggestion['type'] ?? 'create');
            $proposalState = (string) ($suggestion['status'] ?? 'pending');
            $isPending = $proposalState === 'pending';
            $proposalRevision = (int) ($suggestion['expected_revision'] ?? 0);
            $suggestionRevision = (int) ($suggestion['revision'] ?? 1);
            $proposalTarget = (int) ($suggestion['target_playbook_id'] ?? 0);
            $proposalReason = trim((string) ($suggestion['reason'] ?? ''));
            $evidence = is_array($suggestion['evidence'] ?? null) ? $suggestion['evidence'] : [];
            $sourcePublicationLabels = ['published' => $t('Publicado'), 'unpublished' => $t('Não publicado'), 'unknown' => $t('Desconhecida')];
            ?>
        <li>
          <article class="glpiacessivel-playbook-suggestion-card glpiacessivel-playbook-suggestion-card-compact" aria-labelledby="<?= glpiacessivel_e($titleId) ?>" aria-describedby="<?= glpiacessivel_e($summaryId . ' ' . $metaId) ?>">
            <div class="glpiacessivel-playbook-suggestion-header">
              <div>
                <p class="glpiacessivel-eyebrow">
              <?= glpiacessivel_e(sprintf($t('Sugestão #%s'), $suggestionDisplayId)) ?>
              | <?= glpiacessivel_e((string) ($sourceTypeLabels[$sourceType] ?? $t('Fonte não informada'))) ?>
                </p>
                <h3 id="<?= glpiacessivel_e($titleId) ?>" class="glpiacessivel-playbook-suggestion-title"><?= glpiacessivel_e($suggestionTitle) ?></h3>
              </div>
              <span class="glpiacessivel-badge glpiacessivel-badge-status-neutral">
                <?= glpiacessivel_e($actionLabels[$proposalAction] ?? $actionLabels['review']) ?> — <?= glpiacessivel_e($stateLabels[$proposalState] ?? $stateLabels['unknown']) ?>
              </span>
            </div>

            <?php if ($isPending && $suggestionId > 0 && $batchPageToken !== '') : ?>
              <label for="editorial-select-<?= $suggestionId ?>" style="display:flex;align-items:center;gap:.5rem;min-height:24px;">
                <input id="editorial-select-<?= $suggestionId ?>" type="checkbox" name="selected_proposals[]" value="<?= $suggestionId ?>" form="editorial-batch-selection" data-editorial-checkbox
                  <?= in_array($suggestionId, $batchSelectedIds, true) ? 'checked' : '' ?> />
                <?= glpiacessivel_e(sprintf($t('Selecionar proposta #%d: %s — %s'), $suggestionId, $suggestionTitle, $actionLabels[$proposalAction] ?? $actionLabels['review'])) ?>
              </label>
            <?php endif; ?>

            <p id="<?= glpiacessivel_e($summaryId) ?>" class="glpiacessivel-playbook-suggestion-summary glpiacessivel-playbook-suggestion-summary-compact">
              <?= glpiacessivel_e($compactSummary) ?>
            </p>
            <?php if ($proposalAction === 'review') : ?>
              <p><?= glpiacessivel_e($t('Esta proposta exige revisão individual das fontes e vínculos. Ela não pode ser aprovada diretamente como orientação publicada.')) ?></p>
            <?php endif; ?>

            <dl id="<?= glpiacessivel_e($metaId) ?>" class="glpiacessivel-playbook-suggestion-meta glpiacessivel-playbook-suggestion-meta-compact">
              <div><dt><?= glpiacessivel_e($t('Orientação alvo')) ?></dt><dd><?= $proposalTarget > 0 ? '#' . $proposalTarget : glpiacessivel_e($t('Nova orientação')) ?></dd></div>
              <div><dt><?= glpiacessivel_e($t('Revisão esperada do alvo')) ?></dt><dd><?= $proposalRevision ?></dd></div>
              <div><dt><?= glpiacessivel_e($t('Revisão da proposta')) ?></dt><dd><?= $suggestionRevision ?></dd></div>
              <div><dt><?= glpiacessivel_e($t('Motivo editorial')) ?></dt><dd><?= glpiacessivel_e($proposalReason !== '' ? $proposalReason : $t('Revisão manual')) ?></dd></div>
              <div>
                <dt><?= glpiacessivel_e($t('Categoria')) ?></dt>
            <dd><?= glpiacessivel_e((string) ($suggestion['category_hint'] ?? $t('Não informada'))) ?></dd>
              </div>
              <div>
                <dt><?= glpiacessivel_e($t('Grupo')) ?></dt>
            <dd><?= glpiacessivel_e((string) ($suggestion['group_hint'] ?? $t('Não informado'))) ?></dd>
              </div>
              <div>
                <dt><?= glpiacessivel_e($t('Termos')) ?></dt>
                <dd><?= count($keywordsAll) ?></dd>
              </div>
              <div>
                <dt><?= glpiacessivel_e($t('Perguntas')) ?></dt>
                <dd><?= count($questionsAll) ?></dd>
              </div>
              <div>
                <dt><?= glpiacessivel_e($t('Artigos KB')) ?></dt>
                <dd><?= count($kbLinks) ?></dd>
              </div>
            </dl>

            <div class="glpiacessivel-playbook-suggestion-panels" aria-label="<?= glpiacessivel_e($t('Revisão da sugestão')) ?>">
              <details class="glpiacessivel-playbook-suggestion-details">
                <summary><?= glpiacessivel_e($t('Ver detalhes')) ?></summary>
                <dl class="glpiacessivel-playbook-suggestion-meta">
                  <div>
                    <dt><?= glpiacessivel_e($t('Intenção')) ?></dt>
                <dd><?= glpiacessivel_e((string) ($suggestion['intent'] ?? $t('Não informada'))) ?></dd>
                  </div>
                  <div>
                    <dt><?= glpiacessivel_e($t('Resposta completa')) ?></dt>
                <dd><?= glpiacessivel_e($summary !== '' ? $summary : $t('Não informada')) ?></dd>
                  </div>
                  <div>
                    <dt><?= glpiacessivel_e($t('Primeiros passos')) ?></dt>
                <dd><?= glpiacessivel_e($firstSteps !== '' ? $firstSteps : $t('Não informado')) ?></dd>
                  </div>
                  <div>
                    <dt><?= glpiacessivel_e($t('Quando abrir chamado')) ?></dt>
                <dd><?= glpiacessivel_e($whenOpenTicket !== '' ? $whenOpenTicket : $t('Não informado')) ?></dd>
                  </div>
                  <div>
                    <dt><?= glpiacessivel_e($t('Dados a coletar')) ?></dt>
                <dd><?= glpiacessivel_e($requiredData !== '' ? $requiredData : $t('Não informado')) ?></dd>
                  </div>
                  <div>
                    <dt><?= glpiacessivel_e($t('Modelo ITIL')) ?></dt>
                <dd><?= glpiacessivel_e($ticketTemplate !== [] ? (string) json_encode($ticketTemplate, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) : $t('Não informado')) ?></dd>
                  </div>
                </dl>

                <?php if ($keywordsAll !== []) : ?>
                  <h4><?= glpiacessivel_e($t('Termos de acionamento')) ?></h4>
                  <ul class="glpiacessivel-playbook-chip-list">
                    <?php foreach ($keywordsAll as $keyword) : ?>
                      <li><span class="glpiacessivel-playbook-chip"><?= glpiacessivel_e($keyword) ?></span></li>
                    <?php endforeach; ?>
                  </ul>
                <?php endif; ?>

                <?php if ($questionsAll !== []) : ?>
                  <h4><?= glpiacessivel_e($t('Perguntas de triagem')) ?></h4>
                  <ol>
                    <?php foreach ($questionsAll as $question) : ?>
                      <li><?= glpiacessivel_e($question) ?></li>
                    <?php endforeach; ?>
                  </ol>
                <?php endif; ?>

                <?php if ($kbLinks !== []) : ?>
                  <h4><?= glpiacessivel_e($t('Artigos vinculados')) ?></h4>
                  <ul class="glpiacessivel-kb-link-list">
                    <?php foreach ($kbLinks as $kbLink) : ?>
                      <li>
                        <?php if ((int) ($kbLink['id'] ?? 0) > 0) : ?>
                          <a href="<?= glpiacessivel_e(glpiacessivel_url('front/knowledge.php?article=' . (int) $kbLink['id'])) ?>">
                            #<?= (int) $kbLink['id'] ?> - <?= glpiacessivel_e((string) $kbLink['name']) ?>
                          </a>
                        <?php else : ?>
                            <?= glpiacessivel_e((string) $kbLink['name']) ?>
                        <?php endif; ?>
                      </li>
                    <?php endforeach; ?>
                  </ul>
                <?php endif; ?>
                <?php if ($evidence !== []) : ?>
                  <h4><?= glpiacessivel_e($t('Evidências da proposta')) ?></h4>
                  <ul>
                    <?php foreach ($evidence as $sourceEvidence) : ?>
                        <?php if (!is_array($sourceEvidence)) {
                            continue;
                        } ?>
                      <li><?= glpiacessivel_e(sprintf($t('Fonte #%d; publicação: %s; revisão textual: %s.'), (int) ($sourceEvidence['native_id'] ?? $sourceEvidence['source_id'] ?? 0), $sourcePublicationLabels[(string) ($sourceEvidence['publication'] ?? 'unknown')] ?? $sourcePublicationLabels['unknown'], mb_substr((string) ($sourceEvidence['text_hash'] ?? $t('Não informada')), 0, 16, 'UTF-8'))) ?></li>
                    <?php endforeach; ?>
                  </ul>
                <?php endif; ?>
              </details>

              <?php if ($isPending && in_array($proposalAction, ['create', 'update', 'review'], true)) : ?>
              <details id="<?= glpiacessivel_e($editId) ?>" class="glpiacessivel-playbook-suggestion-details glpiacessivel-playbook-suggestion-edit">
              <summary><?= glpiacessivel_e($t('Editar sugestão')) ?></summary>
                <form method="post" action="<?= glpiacessivel_e(glpiacessivel_url('front/playbooks.php')) ?>" class="glpiacessivel-playbook-form-grid">
                  <input type="hidden" name="_glpi_csrf_token" value="<?= glpiacessivel_e($csrf_token ?? '') ?>" />
                  <input type="hidden" name="action" value="update_suggestion" />
                  <input type="hidden" name="suggestion_id" value="<?= $suggestionId ?>" />
                  <input type="hidden" name="proposal_revision" value="<?= $suggestionRevision ?>" />
                    <?php $returnFields(); ?>

                  <div class="glpiacessivel-field span-2">
                    <label for="suggestion-name-<?= glpiacessivel_e($suggestionKey) ?>"><?= glpiacessivel_e($t('Nome do roteiro')) ?></label>
                    <input id="suggestion-name-<?= glpiacessivel_e($suggestionKey) ?>" name="name" type="text" value="<?= glpiacessivel_e($suggestionTitle) ?>" />
                  </div>

                  <div class="glpiacessivel-field">
                    <label for="suggestion-intent-<?= glpiacessivel_e($suggestionKey) ?>"><?= glpiacessivel_e($t('Intenção')) ?></label>
                    <input id="suggestion-intent-<?= glpiacessivel_e($suggestionKey) ?>" name="intent" type="text" value="<?= glpiacessivel_e((string) ($suggestion['intent'] ?? 'kb_recomendar_contextual')) ?>" />
                  </div>

                  <div class="glpiacessivel-field">
                    <label for="suggestion-category-<?= glpiacessivel_e($suggestionKey) ?>"><?= glpiacessivel_e($t('Categoria sugerida')) ?></label>
                    <input id="suggestion-category-<?= glpiacessivel_e($suggestionKey) ?>" name="category_hint" type="text" value="<?= glpiacessivel_e((string) ($suggestion['category_hint'] ?? '')) ?>" />
                  </div>

                  <div class="glpiacessivel-field">
                    <label for="suggestion-group-<?= glpiacessivel_e($suggestionKey) ?>"><?= glpiacessivel_e($t('Grupo sugerido')) ?></label>
                    <input id="suggestion-group-<?= glpiacessivel_e($suggestionKey) ?>" name="group_hint" type="text" value="<?= glpiacessivel_e((string) ($suggestion['group_hint'] ?? '')) ?>" />
                  </div>

                  <div class="glpiacessivel-field span-3">
                    <label for="suggestion-summary-field-<?= glpiacessivel_e($suggestionKey) ?>"><?= glpiacessivel_e($t('Resposta resumida')) ?></label>
                    <textarea id="suggestion-summary-field-<?= glpiacessivel_e($suggestionKey) ?>" name="answer_summary" rows="4"><?= glpiacessivel_e($playbookContentValue($suggestion, 'answer_summary')) ?></textarea>
                  </div>

                  <div class="glpiacessivel-field span-3">
                    <label for="suggestion-first-steps-<?= glpiacessivel_e($suggestionKey) ?>"><?= glpiacessivel_e($t('Primeiros passos')) ?></label>
                    <textarea id="suggestion-first-steps-<?= glpiacessivel_e($suggestionKey) ?>" name="first_steps" rows="3"><?= glpiacessivel_e($firstSteps) ?></textarea>
                  </div>

                  <div class="glpiacessivel-field span-3">
                    <label for="suggestion-when-ticket-<?= glpiacessivel_e($suggestionKey) ?>"><?= glpiacessivel_e($t('Quando abrir chamado')) ?></label>
                    <textarea id="suggestion-when-ticket-<?= glpiacessivel_e($suggestionKey) ?>" name="when_open_ticket" rows="3"><?= glpiacessivel_e($whenOpenTicket) ?></textarea>
                  </div>

                  <div class="glpiacessivel-field span-3">
                    <label for="suggestion-required-data-<?= glpiacessivel_e($suggestionKey) ?>"><?= glpiacessivel_e($t('Dados a coletar')) ?></label>
                    <textarea id="suggestion-required-data-<?= glpiacessivel_e($suggestionKey) ?>" name="required_data" rows="3"><?= glpiacessivel_e($requiredData) ?></textarea>
                  </div>

                  <div class="glpiacessivel-field span-3">
                    <label for="suggestion-keywords-<?= glpiacessivel_e($suggestionKey) ?>"><?= glpiacessivel_e($t('Palavras-chave')) ?></label>
                    <textarea id="suggestion-keywords-<?= glpiacessivel_e($suggestionKey) ?>" name="keywords" rows="4"><?= glpiacessivel_e($playbookLines($keywordsAll)) ?></textarea>
                  </div>

                  <div class="glpiacessivel-field span-3">
                    <label for="suggestion-questions-<?= glpiacessivel_e($suggestionKey) ?>"><?= glpiacessivel_e($t('Perguntas de validação')) ?></label>
                    <textarea id="suggestion-questions-<?= glpiacessivel_e($suggestionKey) ?>" name="questions" rows="4"><?= glpiacessivel_e($playbookLines($questionsAll)) ?></textarea>
                  </div>

                  <div class="glpiacessivel-field span-3">
                    <label for="suggestion-kb-<?= glpiacessivel_e($suggestionKey) ?>"><?= glpiacessivel_e($t('Artigos da base associados')) ?></label>
                    <textarea id="suggestion-kb-<?= glpiacessivel_e($suggestionKey) ?>" name="kb_articles" rows="4"><?= glpiacessivel_e($playbookKbArticles($suggestion)) ?></textarea>
                    <p class="glpiacessivel-field-hint"><?= glpiacessivel_e($t('Informe um artigo por linha. Exemplo: 123 | VPN - acesso remoto.')) ?></p>
                  </div>

                  <div class="glpiacessivel-playbook-actions span-3">
                  <button type="submit" class="glpiacessivel-button glpiacessivel-button-primary glpiacessivel-primary-action" aria-label="<?= glpiacessivel_e(sprintf($t('Salvar edição da sugestão %s: %s'), $suggestionDisplayId, $suggestionTitle)) ?>"><?= glpiacessivel_e($t('Salvar edição')) ?></button>
                  </div>
                </form>
              </details>
              <?php endif; ?>
            </div>

            <?php if ($isPending) : ?>
            <div class="glpiacessivel-playbook-suggestion-actions">
                <?php if ($proposalAction !== 'review') : ?>
              <form method="post" action="<?= glpiacessivel_e(glpiacessivel_url('front/playbooks.php')) ?>" data-glpiacessivel-critical-form data-critical-title="<?= glpiacessivel_e($t('Confirmar decisão editorial')) ?>" data-critical-message="<?= glpiacessivel_e(sprintf($t('Decisão proposta: %s. Orientação: %s. Confira as fontes e consequências antes de aprovar.'), $actionLabels[$proposalAction] ?? $actionLabels['review'], $suggestionTitle)) ?>" data-critical-consequence="<?= glpiacessivel_e($t('A decisão pode criar, atualizar, inativar ou reativar esta orientação; não altera os artigos do GLPI.')) ?>">
                <input type="hidden" name="_glpi_csrf_token" value="<?= glpiacessivel_e($csrf_token ?? '') ?>" />
                <input type="hidden" name="action" value="approve" />
                <input type="hidden" name="critical_confirmed" value="0" />
                <input type="hidden" name="critical_confirmation_token" value="<?= glpiacessivel_e((string) ($criticalConfirmations['approve:' . $suggestionId] ?? '')) ?>" />
                <input type="hidden" name="suggestion_id" value="<?= $suggestionId ?>" />
                <input type="hidden" name="expected_revision" value="<?= $proposalRevision ?>" />
                <input type="hidden" name="proposal_revision" value="<?= $suggestionRevision ?>" />
                    <?php $returnFields();
                    $noJsConfirmation('confirm-approve-' . $suggestionKey); ?>
                <button type="submit" class="glpiacessivel-button glpiacessivel-button-primary glpiacessivel-primary-action" aria-label="<?= glpiacessivel_e(sprintf($t('Aprovar decisão %s para %s'), $actionLabels[$proposalAction] ?? $actionLabels['review'], $suggestionTitle)) ?>"><?= glpiacessivel_e($t('Aprovar decisão')) ?></button>
              </form>
                <?php endif; ?>
              <form method="post" action="<?= glpiacessivel_e(glpiacessivel_url('front/playbooks.php')) ?>" data-glpiacessivel-critical-form data-critical-title="<?= glpiacessivel_e($t('Confirmar rejeição de sugestão')) ?>" data-critical-message="<?= glpiacessivel_e(sprintf($t('Revise antes de rejeitar a sugestão "%s".'), $suggestionTitle)) ?>" data-critical-consequence="<?= glpiacessivel_e($t('A sugestão deixa a fila de revisão.')) ?>">
                <input type="hidden" name="_glpi_csrf_token" value="<?= glpiacessivel_e($csrf_token ?? '') ?>" />
                <input type="hidden" name="action" value="reject" />
                <input type="hidden" name="critical_confirmed" value="0" />
                <input type="hidden" name="critical_confirmation_token" value="<?= glpiacessivel_e((string) ($criticalConfirmations['reject:' . $suggestionId] ?? '')) ?>" />
                <input type="hidden" name="suggestion_id" value="<?= $suggestionId ?>" />
                <input type="hidden" name="expected_revision" value="<?= $proposalRevision ?>" />
                <input type="hidden" name="proposal_revision" value="<?= $suggestionRevision ?>" />
                <?php $returnFields();
                $noJsConfirmation('confirm-reject-' . $suggestionKey); ?>
                <button type="submit" class="glpiacessivel-button glpiacessivel-button-danger glpiacessivel-danger-action" aria-label="<?= glpiacessivel_e(sprintf($t('Rejeitar sugestão %s: %s'), $suggestionDisplayId, $suggestionTitle)) ?>"><?= glpiacessivel_e($t('Rejeitar')) ?></button>
              </form>
            </div>
            <?php endif; ?>
          </article>
        </li>
      <?php endforeach; ?>
    </ul>
    <?php if ($batchPageToken !== '' && $batchSelectableCount > 0) : ?>
      </fieldset>
      <div id="editorial-batch-commands" tabindex="-1">
        <p><?= glpiacessivel_e($t('Selecione ao menos uma proposta para iniciar a revisão. Nenhuma decisão é aplicada nesta etapa.')) ?></p>
        <button type="submit" form="editorial-batch-selection" name="action" value="batch_review_approve" class="glpiacessivel-button glpiacessivel-button-primary"><?= glpiacessivel_e($t('Aprovar propostas selecionadas')) ?></button>
        <button type="submit" form="editorial-batch-selection" name="action" value="batch_review_reject" class="glpiacessivel-button glpiacessivel-button-danger"><?= glpiacessivel_e($t('Rejeitar propostas selecionadas')) ?></button>
      </div>
    <?php endif; ?>
  <?php endif; ?>
  <?php
    $queuePage = max(1, (int) ($queueData['page'] ?? 1));
    $queuePageSize = max(1, (int) ($queueData['page_size'] ?? 20));
    $queuePages = isset($queueData['total']) ? max(1, (int) ceil((int) $queueData['total'] / $queuePageSize))
      : ($queuePage + (!empty($queueData['has_more']) ? 1 : 0));
    $queueUrl = static function (int $page) use ($queueFilters): string {
        return glpiacessivel_url('front/playbooks.php?' . http_build_query([
          'queue_state' => $queueFilters['state'] ?? 'pending', 'queue_action' => $queueFilters['action'] ?? 'all',
          'queue_page' => $page,
        ], '', '&', PHP_QUERY_RFC3986) . '#suggestions-title');
    };
    ?>
  <?php if ($queuePages > 1) : ?>
    <nav aria-label="<?= glpiacessivel_e($t('Páginas da fila editorial')) ?>" data-editorial-pagination>
        <?php if ($queuePage > 1) :
            ?><a href="<?= glpiacessivel_e($queueUrl($queuePage - 1)) ?>"><?= glpiacessivel_e($t('Página anterior')) ?></a><?php
        endif; ?>
      <span><?= glpiacessivel_e(isset($queueData['total']) ? sprintf($t('Página %d de %d'), $queuePage, $queuePages) : sprintf($t('Página %d'), $queuePage)) ?></span>
        <?php if ($queuePage < $queuePages) :
            ?><a href="<?= glpiacessivel_e($queueUrl($queuePage + 1)) ?>"><?= glpiacessivel_e($t('Próxima página')) ?></a><?php
        endif; ?>
    </nav>
  <?php endif; ?>
</section>

<section class="glpiacessivel-card" aria-labelledby="approved-title">
  <h2 id="approved-title"><?= glpiacessivel_e($t('Roteiros aprovados')) ?></h2>
  <p>
      <?= glpiacessivel_e(sprintf($t('Somente roteiros ativos entram nas respostas de %s. Roteiros inativos ficam preservados para referência, mas não são usados pelo chatbot.'), $chatbotDisplayName)) ?>
  </p>

  <?php if (empty($playbooks)) : ?>
    <p><?= glpiacessivel_e($t('Nenhum roteiro aprovado ainda.')) ?></p>
  <?php else : ?>
    <div class="glpiacessivel-table-wrap glpiacessivel-table-wrapper">
      <table class="glpiacessivel-table">
        <thead>
          <tr>
            <th scope="col"><?= glpiacessivel_e($t('Nome')) ?></th>
            <th scope="col"><?= glpiacessivel_e($t('Estado')) ?></th>
            <th scope="col"><?= glpiacessivel_e($t('Intenção')) ?></th>
            <th scope="col"><?= glpiacessivel_e($t('Categoria')) ?></th>
            <th scope="col"><?= glpiacessivel_e($t('Artigos da base')) ?></th>
            <th scope="col"><?= glpiacessivel_e($t('Palavras-chave')) ?></th>
            <th scope="col"><?= glpiacessivel_e($t('Ações')) ?></th>
          </tr>
        </thead>
        <tbody>
          <?php foreach ((array) $playbooks as $playbook) : ?>
                <?php
                $playbookId = (int) ($playbook['id'] ?? 0);
                $isActive = !empty($playbook['is_active']);
                $kbLinks = $playbookKbArticleLinks($playbook);
                ?>
            <tr>
              <td><?= glpiacessivel_e((string) ($playbook['name'] ?? '')) ?></td>
              <td>
                <span class="glpiacessivel-badge <?= $isActive ? 'glpiacessivel-badge-state-active' : 'glpiacessivel-badge-state-inactive' ?>">
                  <?= glpiacessivel_e($isActive ? $t('Ativo') : $t('Inativo')) ?>
                </span>
              </td>
              <td><?= glpiacessivel_e((string) ($playbook['intent'] ?? '')) ?></td>
              <td><?= glpiacessivel_e((string) ($playbook['category_hint'] ?? '')) ?></td>
              <td>
                <?php if ($kbLinks === []) : ?>
                  <span class="glpiacessivel-help-text"><?= glpiacessivel_e($t('Sem artigo vinculado')) ?></span>
                <?php else : ?>
                  <ul class="glpiacessivel-kb-link-list">
                    <?php foreach (array_slice($kbLinks, 0, 3) as $kbLink) : ?>
                      <li>
                        <?php if ((int) ($kbLink['id'] ?? 0) > 0) : ?>
                          <a href="<?= glpiacessivel_e(glpiacessivel_url('front/knowledge.php?article=' . (int) $kbLink['id'])) ?>">
                            #<?= (int) $kbLink['id'] ?> - <?= glpiacessivel_e((string) $kbLink['name']) ?>
                          </a>
                        <?php else : ?>
                            <?= glpiacessivel_e((string) $kbLink['name']) ?>
                        <?php endif; ?>
                      </li>
                    <?php endforeach; ?>
                  </ul>
                    <?php if (count($kbLinks) > 3) : ?>
                        <?php $additionalArticleCount = count($kbLinks) - 3; ?>
                    <span class="glpiacessivel-help-text"><?= glpiacessivel_e(sprintf(
                        _n('+%d artigo', '+%d artigos', $additionalArticleCount, 'glpiacessivel'),
                        $additionalArticleCount
                    )) ?></span>
                    <?php endif; ?>
                <?php endif; ?>
              </td>
              <td><?= glpiacessivel_e(implode(', ', array_slice((array) ($playbook['keywords'] ?? []), 0, 8))) ?></td>
              <td>
                <details class="glpiacessivel-playbook-edit">
                  <summary><?= glpiacessivel_e($t('Editar roteiro')) ?></summary>
                  <form method="post" action="<?= glpiacessivel_e(glpiacessivel_url('front/playbooks.php')) ?>" class="glpiacessivel-form-grid">
                    <input type="hidden" name="_glpi_csrf_token" value="<?= glpiacessivel_e($csrf_token ?? '') ?>" />
                    <input type="hidden" name="action" value="update_playbook" />
                    <input type="hidden" name="playbook_id" value="<?= $playbookId ?>" />
                    <input type="hidden" name="revision" value="<?= (int) ($playbook['revision'] ?? 1) ?>" />
                    <?php $returnFields(); ?>

                    <label for="playbook-name-<?= $playbookId ?>"><?= glpiacessivel_e($t('Nome')) ?></label>
                    <input id="playbook-name-<?= $playbookId ?>" name="name" type="text" value="<?= glpiacessivel_e((string) ($playbook['name'] ?? '')) ?>" />

                    <label for="playbook-status-<?= $playbookId ?>"><?= glpiacessivel_e($t('Estado')) ?></label>
                    <select id="playbook-status-<?= $playbookId ?>" name="status">
                      <option value="active" <?= $isActive ? 'selected' : '' ?>><?= glpiacessivel_e($t('Ativo no chatbot')) ?></option>
                      <option value="inactive" <?= !$isActive ? 'selected' : '' ?>><?= glpiacessivel_e($t('Inativo')) ?></option>
                    </select>

                    <label for="playbook-intent-<?= $playbookId ?>"><?= glpiacessivel_e($t('Intenção')) ?></label>
                    <input id="playbook-intent-<?= $playbookId ?>" name="intent" type="text" value="<?= glpiacessivel_e((string) ($playbook['intent'] ?? '')) ?>" />

                    <label for="playbook-category-<?= $playbookId ?>"><?= glpiacessivel_e($t('Categoria sugerida')) ?></label>
                    <input id="playbook-category-<?= $playbookId ?>" name="category_hint" type="text" value="<?= glpiacessivel_e((string) ($playbook['category_hint'] ?? '')) ?>" />

                    <label for="playbook-group-<?= $playbookId ?>"><?= glpiacessivel_e($t('Grupo sugerido')) ?></label>
                    <input id="playbook-group-<?= $playbookId ?>" name="group_hint" type="text" value="<?= glpiacessivel_e((string) ($playbook['group_hint'] ?? '')) ?>" />

                    <label for="playbook-keywords-<?= $playbookId ?>"><?= glpiacessivel_e($t('Palavras-chave')) ?></label>
                    <textarea id="playbook-keywords-<?= $playbookId ?>" name="keywords" rows="5"><?= glpiacessivel_e($playbookLines($playbook['keywords'] ?? [])) ?></textarea>

                    <label for="playbook-questions-<?= $playbookId ?>"><?= glpiacessivel_e($t('Perguntas de validação')) ?></label>
                    <textarea id="playbook-questions-<?= $playbookId ?>" name="questions" rows="5"><?= glpiacessivel_e($playbookLines($playbook['questions'] ?? [])) ?></textarea>

                    <label for="playbook-kb-<?= $playbookId ?>"><?= glpiacessivel_e($t('Artigos da base associados')) ?></label>
                    <textarea id="playbook-kb-<?= $playbookId ?>" name="kb_articles" rows="5" aria-describedby="playbook-kb-help-<?= $playbookId ?>"><?= glpiacessivel_e($playbookKbArticles($playbook)) ?></textarea>
                    <p id="playbook-kb-help-<?= $playbookId ?>" class="glpiacessivel-field-hint">
                      <?= glpiacessivel_e($t('Informe um artigo por linha no formato ID | Título. Esses artigos podem ser apresentados como referência na resposta.')) ?>
                    </p>

                    <label for="playbook-summary-<?= $playbookId ?>"><?= glpiacessivel_e($t('Resposta resumida')) ?></label>
                    <textarea id="playbook-summary-<?= $playbookId ?>" name="answer_summary" rows="5"><?= glpiacessivel_e($playbookSummary($playbook)) ?></textarea>

                    <div class="glpiacessivel-field" style="grid-column:1 / -1;">
                      <button type="submit" class="glpiacessivel-button glpiacessivel-button-primary glpiacessivel-primary-action"><?= glpiacessivel_e($t('Salvar alterações')) ?></button>
                    </div>
                  </form>

                  <form method="post" action="<?= glpiacessivel_e(glpiacessivel_url('front/playbooks.php')) ?>" class="glpiacessivel-playbook-delete" data-glpiacessivel-critical-form data-critical-title="<?= glpiacessivel_e($t('Confirmar exclusão de roteiro')) ?>" data-critical-message="<?= glpiacessivel_e(sprintf($t('Revise antes de excluir este roteiro aprovado de %s.'), $chatbotDisplayName)) ?>" data-critical-consequence="<?= glpiacessivel_e($t('A exclusão remove o roteiro da base operacional do chatbot.')) ?>">
                    <input type="hidden" name="_glpi_csrf_token" value="<?= glpiacessivel_e($csrf_token ?? '') ?>" />
                    <input type="hidden" name="action" value="delete_playbook" />
                    <input type="hidden" name="playbook_id" value="<?= $playbookId ?>" />
                    <input type="hidden" name="critical_confirmed" value="0" />
                    <input type="hidden" name="critical_confirmation_token" value="<?= glpiacessivel_e((string) ($criticalConfirmations['delete_playbook:' . $playbookId] ?? '')) ?>" />
                    <input type="hidden" name="expected_revision" value="<?= (int) ($playbook['revision'] ?? 0) ?>" />
                    <?php $returnFields();
                    $noJsConfirmation('confirm-delete-' . $playbookId); ?>
                    <button type="submit" class="glpiacessivel-button glpiacessivel-button-danger glpiacessivel-danger-action"><?= glpiacessivel_e($t('Excluir roteiro')) ?></button>
                  </form>
                </details>
              </td>
            </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  <?php endif; ?>
</section>

<section class="glpiacessivel-card" aria-labelledby="import-title">
  <h2 id="import-title"><?= glpiacessivel_e($t('Importar roteiros em JSON')) ?></h2>
  <p>
    <?= glpiacessivel_e($t('Use esta opção para transportar roteiros entre ambientes sem varrer novamente a base. Cada item pode informar o estado active, pending ou inactive. Se não informar, será usado o estado padrão abaixo.')) ?>
  </p>

  <form method="post" action="<?= glpiacessivel_e(glpiacessivel_url('front/playbooks.php')) ?>" enctype="multipart/form-data">
    <input type="hidden" name="_glpi_csrf_token" value="<?= glpiacessivel_e($csrf_token ?? '') ?>" />
    <input type="hidden" name="action" value="import_json" />
    <?php $returnFields(); ?>

    <label for="playbooks-import-status"><?= glpiacessivel_e($t('Estado padrão dos itens importados')) ?></label>
    <select id="playbooks-import-status" name="import_status">
      <option value="active"><?= glpiacessivel_e($t('Ativo no chatbot')) ?></option>
      <option value="pending"><?= glpiacessivel_e($t('Pendente para análise')) ?></option>
      <option value="inactive"><?= glpiacessivel_e($t('Inativo')) ?></option>
    </select>

    <label for="playbooks-json-file"><?= glpiacessivel_e($t('Arquivo JSON de roteiros')) ?></label>
    <input id="playbooks-json-file" name="playbooks_json_file" type="file" accept="application/json,.json" aria-describedby="playbooks-json-help" />

    <label for="playbooks-json"><?= glpiacessivel_e($t('Ou cole o JSON de roteiros')) ?></label>
    <textarea id="playbooks-json" name="playbooks_json" rows="8" aria-describedby="playbooks-json-help"></textarea>
    <p id="playbooks-json-help" class="glpiacessivel-field-hint"><?= glpiacessivel_e($t('Aceita a exportação do próprio plugin ou um objeto com a chave playbooks, items ou data. Se o arquivo e o texto forem informados, o arquivo terá prioridade.')) ?></p>
    <button type="submit" class="glpiacessivel-button glpiacessivel-button-primary glpiacessivel-primary-action"><?= glpiacessivel_e($t('Importar roteiros')) ?></button>
  </form>
</section>
</div>
<script src="<?= glpiacessivel_e($batchAssetUrl) ?>" defer></script>
