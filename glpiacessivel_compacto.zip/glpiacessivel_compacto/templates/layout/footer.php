<?php if (($nativeInteraction ?? false) === true && !($glpiacessivelStandaloneLayout ?? false)): ?>
</div>
<?php else: ?>
</main>
<?php endif; ?>
<?php if (isset($advanced_search_catalog)): ?>
<?= \GlpiPlugin\Glpiacessivel\UI\View\SearchDateCalendarAssets::markup() ?>
<script type="application/json" data-glpiacessivel-date-calendar-config><?= json_encode(\GlpiPlugin\Glpiacessivel\UI\View\SearchDateCalendarAssets::configuration(), JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT) ?></script>
<link rel="stylesheet" href="<?= htmlspecialchars(\GlpiPlugin\Glpiacessivel\Support\Url::asset('public/assets/css/search-date-calendar.css?v=' . rawurlencode($assetVersionFor('public/assets/css/search-date-calendar.css'))), ENT_QUOTES, 'UTF-8') ?>" />
<script src="<?= htmlspecialchars(\GlpiPlugin\Glpiacessivel\Support\Url::asset('public/assets/js/search-date-calendar.js?v=' . rawurlencode($assetVersionFor('public/assets/js/search-date-calendar.js'))), ENT_QUOTES, 'UTF-8') ?>"></script>
<?php endif; ?>
<?php if (in_array((string) ($active_nav ?? ''), ['tickets', 'ticket_create'], true) || isset($ticket) || isset($context['opening_date_preview'])): ?>
<script src="<?= htmlspecialchars(\GlpiPlugin\Glpiacessivel\Support\Url::asset('public/assets/js/ticket-clipboard-attachments.js?v=' . rawurlencode(\GlpiPlugin\Glpiacessivel\Support\Bootstrap::RUNTIME_EPOCH)), ENT_QUOTES, 'UTF-8') ?>"></script>
<?php endif; ?>
<?php if (($nativeInteraction ?? false) === true): ?>
<script src="<?= htmlspecialchars(\GlpiPlugin\Glpiacessivel\Support\Url::asset('public/assets/js/native-interaction-a11y.js?v=' . rawurlencode(\GlpiPlugin\Glpiacessivel\Support\Bootstrap::RUNTIME_EPOCH)), ENT_QUOTES, 'UTF-8') ?>"></script>
<script src="<?= htmlspecialchars(\GlpiPlugin\Glpiacessivel\Support\Url::asset('public/assets/js/native-editor-presentation.js?v=' . rawurlencode(\GlpiPlugin\Glpiacessivel\Support\Bootstrap::RUNTIME_EPOCH)), ENT_QUOTES, 'UTF-8') ?>"></script>
<?php endif; ?>
<?php if (!empty($ticket_presentation['enabled'])): ?>
<link rel="stylesheet" href="<?= htmlspecialchars(\GlpiPlugin\Glpiacessivel\Support\Url::asset('public/assets/css/ticket-presentation.css?v=' . rawurlencode($assetVersionFor('public/assets/css/ticket-presentation.css'))), ENT_QUOTES, 'UTF-8') ?>" />
<script src="<?= htmlspecialchars(\GlpiPlugin\Glpiacessivel\Support\Url::asset('public/assets/js/ticket-presentation.js?v=' . rawurlencode($assetVersionFor('public/assets/js/ticket-presentation.js'))), ENT_QUOTES, 'UTF-8') ?>"></script>
<?php endif; ?>
<?php if (($glpiacessivelStandaloneLayout ?? false) === true): ?>
<?php if (($nativeInteraction ?? false) === true): ?>
<?php Html::popFooter(); ?>
<?php else: ?>
  <script src="<?= htmlspecialchars((string) ($standaloneJs ?? ''), ENT_QUOTES, 'UTF-8') ?>"></script>
  <script src="<?= htmlspecialchars((string) ($standaloneAuditJs ?? ''), ENT_QUOTES, 'UTF-8') ?>"></script>
</body>
</html>
<?php endif; ?>
<?php else: ?>
<?php Html::footer(); ?>
<?php endif; ?>

