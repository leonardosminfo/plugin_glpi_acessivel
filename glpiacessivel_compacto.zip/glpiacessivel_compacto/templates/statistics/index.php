<?php

declare(strict_types=1);

// The controller validates permissions, context, dates and native count contracts.
// This view never calls the native statistics API or calculates aggregate values.
$statistics = is_array($statistics ?? null) ? $statistics : [];
$statisticsState = (string) ($statistics['state'] ?? 'idle');
$statisticsFilters = is_array($statistics['filters'] ?? null) ? $statistics['filters'] : [];
$statisticsErrors = is_array($statistics['errors'] ?? null) ? $statistics['errors'] : [];
$statisticsRows = is_array($statistics['rows'] ?? null) ? $statistics['rows'] : [];
$statisticsContext = is_array($statistics['context'] ?? null) ? $statistics['context'] : [];
$statisticsPagination = is_array($statistics['pagination'] ?? null) ? $statistics['pagination'] : [];
$statisticsModes = is_array($statistics['modes'] ?? null) ? $statistics['modes'] : [];
$statisticsMessage = (string) ($statistics['message'] ?? '');
$statisticsSafeUrl = static function ($url): string {
    if (!is_string($url) || preg_match('/[\x00-\x20\x7f\\\\]/', $url) === 1) {
        return '';
    }
    return str_starts_with($url, '/') && !str_starts_with($url, '//') ? $url : '';
};
$statisticsFormUrl = $statisticsSafeUrl($statistics['form_url'] ?? glpiacessivel_url('front/statistics.php'));
$statisticsReturnUrl = $statisticsSafeUrl($statistics['return_url'] ?? glpiacessivel_url('front/cockpit.php'));
$statisticsConventionalUrl = $statisticsSafeUrl($statistics['conventional_url'] ?? '');
$statisticsFieldLabels = [
    'mode' => glpiacessivel_t('Modalidade'),
    'date1' => glpiacessivel_t('Data inicial'),
    'date2' => glpiacessivel_t('Data final'),
];
$statisticsModeLabel = '';
foreach ($statisticsModes as $statisticsMode) {
    if (is_array($statisticsMode) && ($statisticsMode['value'] ?? '') === ($statisticsFilters['mode'] ?? 'assigned')) {
        $statisticsModeLabel = (string) ($statisticsMode['label'] ?? '');
    }
}
$statisticsFormatDate = static function ($date): string {
    $value = is_string($date) ? $date : '';
    return class_exists(\GlpiPlugin\Glpiacessivel\Support\DisplayDate::class)
        ? \GlpiPlugin\Glpiacessivel\Support\DisplayDate::format($value)
        : $value;
};
$statisticsOffset = max(0, (int) ($statisticsPagination['offset'] ?? 0));
$statisticsTotal = max(0, (int) ($statisticsPagination['total'] ?? count($statisticsRows)));
?>
<div class="glpiacessivel-native-statistics" data-glpiacessivel-statistics-state="<?= glpiacessivel_e($statisticsState) ?>">
  <section class="glpiacessivel-card" aria-labelledby="statistics-purpose">
    <h2 id="statistics-purpose"><?= glpiacessivel_e(glpiacessivel_t('Contagens do relatório nativo')) ?></h2>
    <p><?= glpiacessivel_e(glpiacessivel_t('Esta apresentação acessível utiliza contagens calculadas pelo GLPI. Não reproduz todas as colunas do relatório convencional e não representa a pesquisa salva nem os filtros da lista de chamados.')) ?></p>
    <p><?= glpiacessivel_e(glpiacessivel_t('Abertos no período não significa chamados que continuam abertos. Um chamado pode participar de mais de uma coluna ou técnico; por isso, não são apresentados totais somados.')) ?></p>
  </section>

  <?php if ($statisticsState !== 'idle'): ?>
    <section aria-labelledby="statistics-results" class="glpiacessivel-card<?= in_array($statisticsState, ['error', 'denied'], true) ? ' glpiacessivel-alert glpiacessivel-alert-error' : '' ?>">
      <h2 id="statistics-results" tabindex="-1"><?= glpiacessivel_e(match ($statisticsState) {
          'success' => glpiacessivel_t('Resultado da consulta estatística'),
          'empty' => glpiacessivel_t('Nenhuma linha encontrada'),
          'denied' => glpiacessivel_t('Consulta estatística indisponível'),
          default => glpiacessivel_t('Não foi possível consultar as estatísticas'),
      }) ?></h2>
      <?php if ($statisticsMessage !== ''): ?>
        <p><?= glpiacessivel_e($statisticsMessage) ?></p>
      <?php endif; ?>
      <?php if ($statisticsErrors !== []): ?>
        <p><?= glpiacessivel_e(glpiacessivel_t('Corrija os campos indicados e envie a consulta novamente.')) ?></p>
        <ul class="glpiacessivel-error-list">
          <?php foreach ($statisticsErrors as $statisticsField => $statisticsError): ?>
            <?php if (isset($statisticsFieldLabels[$statisticsField])): ?>
              <li><a href="#statistics-<?= glpiacessivel_e((string) $statisticsField) ?>"><?= glpiacessivel_e($statisticsFieldLabels[$statisticsField] . ': ' . (string) $statisticsError) ?></a></li>
            <?php else: ?>
              <li><?= glpiacessivel_e((string) $statisticsError) ?></li>
            <?php endif; ?>
          <?php endforeach; ?>
        </ul>
      <?php endif; ?>
      <?php if (in_array($statisticsState, ['success', 'empty'], true)): ?>
        <dl class="glpiacessivel-statistics-context">
          <div><dt><?= glpiacessivel_e(glpiacessivel_t('Modalidade')) ?></dt><dd><?= glpiacessivel_e($statisticsModeLabel) ?></dd></div>
          <div><dt><?= glpiacessivel_e(glpiacessivel_t('Período consultado')) ?></dt><dd><?= glpiacessivel_e(sprintf(glpiacessivel_t('De %s a %s'), $statisticsFormatDate($statisticsFilters['date1'] ?? ''), $statisticsFormatDate($statisticsFilters['date2'] ?? ''))) ?></dd></div>
          <div><dt><?= glpiacessivel_e(glpiacessivel_t('Perfil ativo')) ?></dt><dd><?= glpiacessivel_e((string) ($statisticsContext['profile'] ?? glpiacessivel_t('Perfil da sessão atual'))) ?></dd></div>
          <div><dt><?= glpiacessivel_e(glpiacessivel_t('Entidade ativa')) ?></dt><dd><?= glpiacessivel_e((string) ($statisticsContext['entity'] ?? glpiacessivel_t('Entidade da sessão atual'))) ?></dd></div>
          <div><dt><?= glpiacessivel_e(glpiacessivel_t('Subentidades')) ?></dt><dd><?= glpiacessivel_e(!empty($statisticsContext['recursive']) ? glpiacessivel_t('Incluídas conforme a sessão do GLPI') : glpiacessivel_t('Não incluídas')) ?></dd></div>
        </dl>
      <?php endif; ?>
      <?php if ($statisticsState === 'success' && $statisticsRows !== []): ?>
        <p id="statistics-counts-help"><?= glpiacessivel_e(glpiacessivel_t('As colunas seguem os critérios nativos de abertura, solução, atraso na solução e fechamento no período. Zero é uma contagem válida; falhas de consulta não são apresentadas como zero.')) ?></p>
        <p id="statistics-table-scroll-help"><?= glpiacessivel_e(glpiacessivel_t('Se a tabela não couber na tela, use a rolagem horizontal desta região. Com o teclado, alcance a região com Tab e use as setas para a esquerda e para a direita.')) ?></p>
        <div class="glpiacessivel-table-wrap" role="region" tabindex="0" aria-labelledby="statistics-table-caption" aria-describedby="statistics-table-scroll-help">
          <table aria-describedby="statistics-counts-help">
            <caption id="statistics-table-caption"><?= glpiacessivel_e(glpiacessivel_t('Contagens nativas por técnico no período consultado')) ?></caption>
            <thead><tr>
              <th scope="col"><?= glpiacessivel_e(glpiacessivel_t('Técnico')) ?></th>
              <th scope="col"><?= glpiacessivel_e(glpiacessivel_t('Abertos no período')) ?></th>
              <th scope="col"><?= glpiacessivel_e(glpiacessivel_t('Solucionados no período')) ?></th>
              <th scope="col"><?= glpiacessivel_e(glpiacessivel_t('Solucionados fora do prazo')) ?></th>
              <th scope="col"><?= glpiacessivel_e(glpiacessivel_t('Fechados no período')) ?></th>
            </tr></thead>
            <tbody>
              <?php foreach ($statisticsRows as $statisticsRow): ?>
                <tr>
                  <th scope="row"><?= glpiacessivel_e((string) ($statisticsRow['label'] ?? '')) ?></th>
                  <?php foreach (['opened', 'solved', 'late', 'closed'] as $statisticsColumn): ?>
                    <td><?= glpiacessivel_e((string) $statisticsRow[$statisticsColumn]) ?></td>
                  <?php endforeach; ?>
                </tr>
              <?php endforeach; ?>
            </tbody>
          </table>
        </div>
        <p><?= glpiacessivel_e(sprintf(glpiacessivel_t('Linhas de técnicos: %d a %d de %d. Esse número não é o total de chamados.'), $statisticsOffset + 1, $statisticsOffset + count($statisticsRows), $statisticsTotal)) ?></p>
        <?php
        $statisticsPrevious = $statisticsSafeUrl($statisticsPagination['previous_url'] ?? '');
        $statisticsNext = $statisticsSafeUrl($statisticsPagination['next_url'] ?? '');
        ?>
        <?php if ($statisticsPrevious !== '' || $statisticsNext !== ''): ?>
          <nav aria-label="<?= glpiacessivel_e(glpiacessivel_t('Paginação das estatísticas')) ?>" class="glpiacessivel-statistics-pagination">
            <?php if ($statisticsPrevious !== ''): ?>
              <a rel="prev" href="<?= glpiacessivel_e(explode('#', $statisticsPrevious, 2)[0] . '#statistics-results') ?>"><?= glpiacessivel_e(glpiacessivel_t('Estatísticas: página anterior')) ?></a>
            <?php endif; ?>
            <?php if ($statisticsNext !== ''): ?>
              <a rel="next" href="<?= glpiacessivel_e(explode('#', $statisticsNext, 2)[0] . '#statistics-results') ?>"><?= glpiacessivel_e(glpiacessivel_t('Estatísticas: próxima página')) ?></a>
            <?php endif; ?>
          </nav>
        <?php endif; ?>
      <?php elseif ($statisticsState === 'empty'): ?>
        <p><?= glpiacessivel_e(glpiacessivel_t('O relatório nativo não retornou linhas de técnicos para este período e contexto. Isso não representa uma falha nem um total de zero chamados.')) ?></p>
      <?php endif; ?>
    </section>
  <?php endif; ?>

  <?php if ($statisticsState !== 'denied' && $statisticsModes !== [] && $statisticsFormUrl !== ''): ?>
    <section class="glpiacessivel-card" aria-labelledby="statistics-form-heading">
      <h2 id="statistics-form-heading"><?= glpiacessivel_e(glpiacessivel_t('Definir consulta estatística')) ?></h2>
      <p id="statistics-period-help"><?= glpiacessivel_e(glpiacessivel_t('Informe as datas inicial e final. A data final não pode ser anterior à inicial. O formato de preenchimento segue o controle de data do seu navegador. Alterar um campo não executa a consulta.')) ?></p>
      <form method="get" action="<?= glpiacessivel_e(explode('#', $statisticsFormUrl, 2)[0] . '#statistics-results') ?>" class="glpiacessivel-statistics-form">
        <input type="hidden" name="context_revision" value="<?= glpiacessivel_e((string) ($statistics['context_revision'] ?? '')) ?>">
        <div class="glpiacessivel-form-grid">
          <div class="glpiacessivel-field">
            <label for="statistics-mode"><?= glpiacessivel_e(glpiacessivel_t('Modalidade (obrigatório)')) ?></label>
            <select id="statistics-mode" name="mode" required<?= isset($statisticsErrors['mode']) ? ' aria-invalid="true" aria-describedby="statistics-mode-error"' : '' ?>>
              <?php foreach ($statisticsModes as $statisticsMode): ?>
                <option value="<?= glpiacessivel_e((string) $statisticsMode['value']) ?>"<?= ($statisticsMode['value'] ?? '') === ($statisticsFilters['mode'] ?? 'assigned') ? ' selected' : '' ?>><?= glpiacessivel_e((string) $statisticsMode['label']) ?></option>
              <?php endforeach; ?>
            </select>
            <?php if (isset($statisticsErrors['mode'])): ?><p id="statistics-mode-error" class="glpiacessivel-field-error"><?= glpiacessivel_e((string) $statisticsErrors['mode']) ?></p><?php endif; ?>
          </div>
          <?php foreach (['date1', 'date2'] as $statisticsDateField): ?>
            <div class="glpiacessivel-field">
              <label for="statistics-<?= glpiacessivel_e($statisticsDateField) ?>"><?= glpiacessivel_e($statisticsFieldLabels[$statisticsDateField] . ' ' . glpiacessivel_t('(obrigatório)')) ?></label>
              <input type="date" id="statistics-<?= glpiacessivel_e($statisticsDateField) ?>" name="<?= glpiacessivel_e($statisticsDateField) ?>" value="<?= glpiacessivel_e((string) ($statisticsFilters[$statisticsDateField] ?? '')) ?>" required aria-describedby="statistics-period-help<?= isset($statisticsErrors[$statisticsDateField]) ? ' statistics-' . glpiacessivel_e($statisticsDateField) . '-error' : '' ?>"<?= isset($statisticsErrors[$statisticsDateField]) ? ' aria-invalid="true"' : '' ?>>
              <?php if (isset($statisticsErrors[$statisticsDateField])): ?><p id="statistics-<?= glpiacessivel_e($statisticsDateField) ?>-error" class="glpiacessivel-field-error"><?= glpiacessivel_e((string) $statisticsErrors[$statisticsDateField]) ?></p><?php endif; ?>
            </div>
          <?php endforeach; ?>
        </div>
        <p><button type="submit" class="glpiacessivel-button" name="consult" value="1"><?= glpiacessivel_e(glpiacessivel_t('Consultar estatísticas')) ?></button></p>
      </form>
    </section>
  <?php endif; ?>

  <nav aria-label="<?= glpiacessivel_e(glpiacessivel_t('Navegação das estatísticas')) ?>" class="glpiacessivel-card">
    <?php if ($statisticsConventionalUrl !== ''): ?>
      <p><a href="<?= glpiacessivel_e($statisticsConventionalUrl) ?>" aria-describedby="statistics-conventional-help"><?= glpiacessivel_e(glpiacessivel_t('Abrir este relatório na interface convencional')) ?></a></p>
      <p id="statistics-conventional-help"><?= glpiacessivel_e(glpiacessivel_t('Abre nesta mesma aba com a modalidade e o período informados. Para retornar, use Voltar no navegador. A interface convencional possui outras colunas e pode ter acessibilidade diferente.')) ?></p>
    <?php endif; ?>
    <?php if ($statisticsReturnUrl !== ''): ?><p><a href="<?= glpiacessivel_e($statisticsReturnUrl) ?>"><?= glpiacessivel_e(glpiacessivel_t('Voltar ao cockpit')) ?></a></p><?php endif; ?>
  </nav>
</div>
