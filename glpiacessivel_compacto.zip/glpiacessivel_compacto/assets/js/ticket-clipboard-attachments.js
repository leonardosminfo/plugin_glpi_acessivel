(function () {
  'use strict';

  // Clipboard images become ordinary multipart files. The existing upload
  // mapper and native GLPI document processing remain the only server path.
  function init() {
    document.querySelectorAll('[data-glpiacessivel-clipboard-attachments]').forEach(function (box) {
      if (box.dataset.clipboardReady === '1') return;
      var input = document.getElementById(box.dataset.fileInput || '');
      var editor = document.getElementById(box.dataset.editor || '');
      var zone = box.querySelector('[data-clipboard-zone]');
      var status = box.querySelector('[data-clipboard-status]');
      var list = box.querySelector('[data-clipboard-files]');
      if (!input || input.type !== 'file' || !zone || !status || !list) return;
      box.dataset.clipboardReady = '1';
      var legacyList = input.parentElement.querySelector('[data-glpiacessivel-file-list]');
      if (legacyList && !box.contains(legacyList)) legacyList.hidden = true;
      function message(key, fallback) { return box.dataset[key] || fallback; }
      function announce(value) { status.textContent = value; }
      function supported() {
        try { return typeof DataTransfer === 'function' && new DataTransfer().items !== undefined; }
        catch (_) { return false; }
      }
      function replaceFiles(files) {
        var transfer = new DataTransfer();
        files.forEach(function (file) { transfer.items.add(file); });
        input.files = transfer.files;
        input.dispatchEvent(new Event('change', { bubbles: true }));
      }
      function render() {
        list.replaceChildren();
        Array.from(input.files || []).forEach(function (file, index) {
          var item = document.createElement('li');
          var name = document.createElement('span');
          name.textContent = file.name + ' (' + Math.max(1, Math.ceil(file.size / 1024)) + ' KB) ';
          item.appendChild(name);
          if (supported()) {
            var remove = document.createElement('button');
            remove.type = 'button';
            remove.className = 'glpiacessivel-button glpiacessivel-button-secondary';
            remove.textContent = message('removeLabel', 'Remover') + ' ' + file.name;
            remove.addEventListener('click', function () {
              var remaining = Array.from(input.files || []);
              remaining.splice(index, 1);
              replaceFiles(remaining);
              announce(message('removedLabel', 'Anexo removido da seleção.'));
              zone.focus();
            });
            item.appendChild(remove);
          }
          list.appendChild(item);
        });
      }
      function paste(event) {
        var clipboard = event.clipboardData;
        var images = clipboard && clipboard.items ? Array.from(clipboard.items).filter(function (item) {
          return item.kind === 'file' && /^image\//i.test(item.type);
        }).map(function (item) { return item.getAsFile(); }).filter(Boolean) : [];
        if (images.length === 0) return; // Ordinary text keeps its normal behavior.
        event.preventDefault();
        if (input.disabled || !supported()) {
          announce(message('unsupportedLabel', 'Use Selecionar arquivos para anexar a imagem neste navegador.'));
          return;
        }
        try {
          var files = Array.from(input.files || []);
          images.forEach(function (file) { files.push(file); });
          replaceFiles(files);
          zone.value = '';
          announce(message('addedLabel', 'Imagem adicionada aos anexos pendentes. Revise antes de enviar.'));
        } catch (_) {
          announce(message('unsupportedLabel', 'Use Selecionar arquivos para anexar a imagem neste navegador.'));
        }
      }
      input.addEventListener('change', render);
      zone.addEventListener('paste', paste);
      if (editor) editor.addEventListener('paste', paste);
      render();
      if (!supported()) announce(message('unsupportedLabel', 'Use Selecionar arquivos para anexar a imagem neste navegador.'));
    });
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init);
  else init();
})();
