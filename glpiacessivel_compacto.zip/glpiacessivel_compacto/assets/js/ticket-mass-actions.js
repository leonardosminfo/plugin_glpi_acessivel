(function () {
  'use strict';

  function initialize(section) {
    if (!(section instanceof HTMLElement) || section.dataset.glpiacessivelSelectionBound === '1') {
      return;
    }
    const content = section.querySelector('[data-glpiacessivel-ticket-results-content]');
    const count = section.querySelector('[data-glpiacessivel-selected-count]');
    const status = section.querySelector('[data-glpiacessivel-selection-status]');
    const all = section.querySelector('[data-glpiacessivel-select-page]');
    const copy = section.querySelector('[data-glpiacessivel-copy-selected]');
    const form = section.querySelector('[data-glpiacessivel-mass-form]');
    const button = section.querySelector('[data-glpiacessivel-mass-start]');
    const unavailable = section.querySelector('[data-glpiacessivel-mass-unavailable]');
    const token = form instanceof HTMLFormElement ? form.elements.namedItem('selection_token') : null;
    if (!(content instanceof HTMLElement) || !(all instanceof HTMLInputElement)
      || !(count instanceof HTMLElement) || !(status instanceof HTMLElement)) {
      return;
    }
    section.dataset.glpiacessivelSelectionBound = '1';
    let pending = false;
    let lastCount = 0;
    let announcementTimer = 0;

    function message(key, values) {
      const catalog = window.__glpiacessivelI18n && window.__glpiacessivelI18n.messages;
      let text = String(catalog && catalog[key] || '');
      Object.keys(values || {}).forEach(function (name) {
        text = text.split('{' + name + '}').join(String(values[name]));
      });
      return text;
    }
    function boxes() {
      return Array.from(content.querySelectorAll('.glpiacessivel-ticket-select'))
        .filter(function (node) { return node instanceof HTMLInputElement; });
    }
    function ids() {
      return Array.from(new Set(boxes().filter(function (node) { return node.checked; })
        .map(function (node) { return String(node.value || ''); })
        .filter(function (id) { return /^[1-9][0-9]*$/.test(id); })));
    }
    function announce(key, values) {
      window.clearTimeout(announcementTimer);
      status.textContent = '';
      announcementTimer = window.setTimeout(function () {
        status.textContent = message(key, values);
      }, 0);
    }
    function refresh(shouldAnnounce) {
      const rows = boxes();
      const selected = ids().length;
      const loading = section.hasAttribute('aria-busy');
      const copyPending = section.dataset.glpiacessivelCopyPending === '1';
      count.textContent = String(selected);
      all.checked = rows.length > 0 && rows.every(function (node) { return node.checked; });
      all.indeterminate = rows.some(function (node) { return node.checked; }) && !all.checked;
      all.disabled = pending || loading || rows.length === 0;
      if (copy instanceof HTMLButtonElement) {
        copy.disabled = pending || loading || selected === 0;
      }
      if (button instanceof HTMLButtonElement) {
        button.disabled = pending || copyPending || loading || selected === 0
          || !(token instanceof HTMLInputElement) || !token.value;
      }
      if (unavailable instanceof HTMLElement) {
        unavailable.hidden = loading || rows.length === 0
          || (token instanceof HTMLInputElement && token.value !== '');
      }
      if (shouldAnnounce && selected !== lastCount) {
        announce('ticket.selection.count', { count: selected });
      }
      lastCount = selected;
    }
    function reset() {
      const hadSelection = ids().length > 0;
      boxes().forEach(function (node) { node.checked = false; });
      if (token instanceof HTMLInputElement) {
        token.value = '';
      }
      if (form instanceof HTMLFormElement) {
        form.querySelectorAll('[data-glpiacessivel-mass-id]').forEach(function (node) { node.remove(); });
      }
      refresh(false);
      if (hadSelection) {
        announce('ticket.selection.cleared');
      }
    }
    all.addEventListener('change', function () {
      if (pending) {
        refresh(false);
        return;
      }
      const checked = all.checked;
      boxes().forEach(function (node) { node.checked = checked; });
      // Copy feedback/late promises also belong to the previous selection.
      section.dispatchEvent(new CustomEvent('glpiacessivel:ticket-selection-changed'));
      refresh(true);
    });
    content.addEventListener('change', function (event) {
      if (event.target instanceof HTMLInputElement
        && event.target.classList.contains('glpiacessivel-ticket-select')) {
        refresh(true);
      }
    });
    section.addEventListener('glpiacessivel:ticket-selection-reset', reset);
    section.addEventListener('glpiacessivel:ticket-selection-ready', function (event) {
      if (token instanceof HTMLInputElement) {
        token.value = typeof event.detail === 'string' ? event.detail : '';
      }
      refresh(false);
    });
    section.addEventListener('glpiacessivel:ticket-copy-pending', function () { refresh(false); });
    function invalidate() {
      section.dispatchEvent(new CustomEvent('glpiacessivel:ticket-selection-reset'));
    }
    document.querySelectorAll('.glpiacessivel-context-switch-form').forEach(function (contextForm) {
      contextForm.addEventListener('change', invalidate);
      contextForm.addEventListener('submit', invalidate);
    });
    document.querySelectorAll('[data-glpiacessivel-advanced-search-form], .glpiacessivel-native-search-catalog-form')
      .forEach(function (searchForm) { searchForm.addEventListener('submit', invalidate); });
    if (form instanceof HTMLFormElement && button instanceof HTMLButtonElement) {
      form.addEventListener('submit', function (event) {
        const selected = ids();
        if (pending || section.dataset.glpiacessivelCopyPending === '1'
          || section.hasAttribute('aria-busy') || selected.length === 0
          || !(token instanceof HTMLInputElement) || !token.value) {
          event.preventDefault();
          if (!pending) {
            announce(selected.length === 0 ? 'status.no_ticket_selected' : 'ticket.mass.selection_unavailable');
          }
          return;
        }
        form.querySelectorAll('[data-glpiacessivel-mass-id]').forEach(function (node) { node.remove(); });
        selected.forEach(function (id) {
          const field = document.createElement('input');
          field.type = 'hidden';
          field.name = 'ids[]';
          field.value = id;
          field.dataset.glpiacessivelMassId = '1';
          form.appendChild(field);
        });
        pending = true;
        section.dataset.glpiacessivelMassPending = '1';
        form.setAttribute('aria-busy', 'true');
        boxes().forEach(function (node) { node.disabled = true; });
        refresh(false);
        announce('ticket.mass.preparing');
        // Native POST navigates once; no timed automatic retry or custom executor.
      });
    }
    window.addEventListener('pageshow', function (event) {
      if (!event.persisted) {
        return;
      }
      pending = false;
      delete section.dataset.glpiacessivelMassPending;
      if (form instanceof HTMLFormElement) {
        form.removeAttribute('aria-busy');
      }
      boxes().forEach(function (node) { node.disabled = false; });
      reset();
      section.dispatchEvent(new CustomEvent('glpiacessivel:ticket-selection-changed'));
    });
    refresh(false);
  }

  window.__glpiacessivelInitializeTicketSelection = initialize;
  function start() {
    initialize(document.querySelector('[data-glpiacessivel-ticket-results]'));
    const heading = document.querySelector('[data-glpiacessivel-mass-flow-heading]');
    const error = document.querySelector('[data-glpiacessivel-mass-flow-error]');
    if (heading instanceof HTMLElement) {
      (error instanceof HTMLElement ? error : heading).focus();
    }
    const flow = document.querySelector('[data-glpiacessivel-mass-flow]');
    if (flow instanceof HTMLElement && flow.dataset.glpiacessivelFlowBound !== '1') {
      flow.dataset.glpiacessivelFlowBound = '1';
      let submitting = false;
      let refreshDeadline = function () {};
      const draftKey = 'glpiacessivel.mass-draft.' + String(flow.dataset.flowToken || '');
      function parameterControls(params) {
        return Array.from(params.elements).filter(function (control) {
          return (control instanceof HTMLInputElement || control instanceof HTMLSelectElement
            || control instanceof HTMLTextAreaElement)
            && /^values\[[0-9]+\]$/.test(control.name) && !control.disabled
            && control.type !== 'hidden';
        });
      }
      function compatibleText(control, value) {
        return typeof value === 'string' && new Blob([value]).size <= 4096
          && (!(control instanceof HTMLInputElement || control instanceof HTMLTextAreaElement)
            || control.maxLength < 0 || value.length <= control.maxLength);
      }
      const storageHelp = flow.querySelector('[data-glpiacessivel-mass-extend-storage-help]');
      let draftStorageAvailable = false;
      try {
        window.sessionStorage.setItem(draftKey + '.probe', '1');
        window.sessionStorage.removeItem(draftKey + '.probe');
        draftStorageAvailable = true;
        if (flow.dataset.flowStage === 'unavailable') {
          Object.keys(window.sessionStorage).filter(function (key) {
            return key.startsWith('glpiacessivel.mass-draft.');
          }).forEach(function (key) { window.sessionStorage.removeItem(key); });
        }
        const saved = window.sessionStorage.getItem(draftKey);
        window.sessionStorage.removeItem(draftKey);
        if (flow.dataset.flowStage === 'form' && saved) {
          const draft = JSON.parse(saved);
          const paramsStage = flow.querySelector('input[name="stage"][value="params"]');
          const params = paramsStage instanceof HTMLInputElement ? paramsStage.form : null;
          if (params instanceof HTMLFormElement && draft && typeof draft.selects === 'object') {
            params.querySelectorAll('select[name]').forEach(function (select) {
              const value = draft.selects[select.name];
              if (/^values\[[0-9]+\]$/.test(select.name) && !select.disabled
                && compatibleText(select, value) && Array.from(select.options).some(function (option) {
                return option.value === value && !option.disabled;
              })) {
                select.value = value;
              }
            });
          }
          if (params instanceof HTMLFormElement && Array.isArray(draft.controls)) {
            parameterControls(params).forEach(function (control) {
              if (control instanceof HTMLSelectElement) {
                return;
              }
              const type = control instanceof HTMLTextAreaElement ? 'textarea' : control.type;
              const restored = draft.controls.find(function (candidate) {
                return candidate && candidate.name === control.name && candidate.type === type
                  && (!['checkbox', 'radio'].includes(type) || candidate.value === control.value);
              });
              if (!restored || !compatibleText(control, restored.value)) {
                return;
              }
              if (['checkbox', 'radio'].includes(type)) {
                if (typeof restored.checked === 'boolean') {
                  control.checked = restored.checked;
                }
              } else if (['text', 'email', 'number', 'textarea'].includes(type)) {
                control.value = restored.value;
              }
            });
          }
          const query = flow.querySelector('#mass-participant-query');
          if (query instanceof HTMLInputElement && typeof draft.query === 'string') {
            query.value = draft.query.slice(0, 120);
          }
        }
      } catch (storageError) {
        draftStorageAvailable = false;
      }
      if (storageHelp instanceof HTMLElement) {
        storageHelp.hidden = draftStorageAvailable;
      }
      const deadline = flow.querySelector('[data-glpiacessivel-mass-deadline]');
      if (deadline instanceof HTMLElement) {
        const remaining = Number(deadline.dataset.remainingSeconds);
        const deadlineStatus = deadline.querySelector('[data-glpiacessivel-mass-deadline-status]');
        const extendButton = deadline.querySelector('[data-glpiacessivel-mass-extend]');
        if (Number.isFinite(remaining) && remaining > 0 && deadlineStatus instanceof HTMLElement) {
          const expiresAt = Date.now() + remaining * 1000;
          let warned = false;
          let warningTimer = 0;
          let expirationTimer = 0;
          refreshDeadline = function () {
            window.clearTimeout(warningTimer);
            window.clearTimeout(expirationTimer);
            if (submitting) {
              return;
            }
            const milliseconds = expiresAt - Date.now();
            if (milliseconds <= 0) {
              try { window.sessionStorage.removeItem(draftKey); } catch (storageError) { /* No persistent fallback. */ }
              deadlineStatus.textContent = String(deadlineStatus.dataset.expiredMessage || '');
              if (extendButton instanceof HTMLButtonElement) {
                extendButton.disabled = true;
              }
              return;
            }
            // One advance warning, not a distracting second-by-second countdown.
            if (milliseconds <= 30000 && !warned) {
              warned = true;
              deadlineStatus.textContent = String(deadlineStatus.dataset.warningMessage || '');
            } else if (milliseconds > 30000) {
              warningTimer = window.setTimeout(refreshDeadline, milliseconds - 30000);
            }
            expirationTimer = window.setTimeout(refreshDeadline, milliseconds);
          };
          refreshDeadline();
        }
      }
      flow.addEventListener('submit', function (event) {
        if (event.defaultPrevented || !(event.target instanceof HTMLFormElement)) {
          return;
        }
        if (submitting) {
          event.preventDefault();
          return;
        }
        const stage = event.target.elements.namedItem('stage');
        if (stage instanceof HTMLInputElement && stage.value === 'extend' && draftStorageAvailable) {
          try {
            const draft = { selects: {} };
            const paramsStage = flow.querySelector('input[name="stage"][value="params"]');
            const params = paramsStage instanceof HTMLInputElement ? paramsStage.form : null;
            if (params instanceof HTMLFormElement) {
              parameterControls(params).forEach(function (control) {
                if (!compatibleText(control, control.value)) {
                  throw new Error('draft_value_unsupported');
                }
                if (control instanceof HTMLSelectElement) {
                  draft.selects[control.name] = control.value;
                } else {
                  const type = control instanceof HTMLTextAreaElement ? 'textarea' : control.type;
                  if (!['text', 'email', 'number', 'textarea', 'checkbox', 'radio'].includes(type)) {
                    throw new Error('draft_control_unsupported');
                  }
                  const savedControl = { name: control.name, type, value: control.value };
                  if (['checkbox', 'radio'].includes(type)) {
                    savedControl.checked = control.checked;
                  }
                  if (!draft.controls) {
                    draft.controls = [];
                  }
                  draft.controls.push(savedControl);
                }
              });
            }
            const query = flow.querySelector('#mass-participant-query');
            if (query instanceof HTMLInputElement) {
              draft.query = query.value.slice(0, 120);
            }
            window.sessionStorage.setItem(draftKey, JSON.stringify(draft));
          } catch (storageError) {
            // Show the fallback before navigating, never silently lose edits.
            draftStorageAvailable = false;
            if (storageHelp instanceof HTMLElement) {
              storageHelp.hidden = false;
              storageHelp.setAttribute('role', 'alert');
              storageHelp.setAttribute('tabindex', '-1');
              storageHelp.focus();
            }
            event.preventDefault();
            return;
          }
        }
        submitting = true;
        event.target.setAttribute('aria-busy', 'true');
        // Do not disable successful fields: the browser must still send the
        // reviewed values and explicit confirmation in this native POST.
        flow.querySelectorAll('button[type="submit"]').forEach(function (button) { button.disabled = true; });
        const status = flow.querySelector('[data-glpiacessivel-mass-flow-status]');
        if (status instanceof HTMLElement) {
          status.textContent = String(status.dataset.pendingMessage || '');
        }
      });
      window.addEventListener('pageshow', function (event) {
        if (!event.persisted) {
          return;
        }
        submitting = false;
        flow.querySelectorAll('form[aria-busy]').forEach(function (form) { form.removeAttribute('aria-busy'); });
        flow.querySelectorAll('button[type="submit"]').forEach(function (button) { button.disabled = false; });
        refreshDeadline();
        const status = flow.querySelector('[data-glpiacessivel-mass-flow-status]');
        if (status instanceof HTMLElement) {
          status.textContent = '';
        }
        // Returning to a cached screen must not announce that an earlier
        // request is still running. The server remains authoritative for stage.
        const focusTarget = error instanceof HTMLElement ? error : heading;
        if (focusTarget instanceof HTMLElement) {
          focusTarget.focus();
        }
      });
    }
  }
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', start, { once: true });
  } else {
    start();
  }
})();
