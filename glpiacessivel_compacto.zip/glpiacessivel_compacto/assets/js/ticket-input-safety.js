(function () {
  'use strict';

  // Presentation safety only: never changes files, form values, native rules or submission.
  var source = document.currentScript;
  var dropMessage = source && source.getAttribute('data-drop-message')
    || 'O arquivo não foi anexado. Para anexar, use um formulário com seletor de arquivos e confira a seleção antes de enviar.';

  function init() {
    document.querySelectorAll('#glpiacessivel-open-ticket-form, form.glpiacessivel-itil-action-form, form[data-glpiacessivel-general-edit]').forEach(function (form) {
      if (form.dataset.glpiacessivelInputSafetyReady === '1') return;
      form.dataset.glpiacessivelInputSafetyReady = '1';
      var status = null;
      function unsupportedFileDrop(event) {
        if (event.defaultPrevented) return;
        var target = event.target instanceof Element ? event.target : null;
        if (!target || target.closest('input[type="file"]')) return;
        // GLPI's public uploader owns drops in this exact native drop zone.
        // Other form areas still reject file drops instead of losing the draft.
        if (target.closest('[data-glpiacessivel-rich-fields] .fileupload.draghoverable[id^="glpiacessivel-drop-"]')) return;
        var transfer = event.dataTransfer;
        if (!transfer) return;
        var isFile = Array.from(transfer.types || []).includes('Files')
          || Array.from(transfer.items || []).some(function (item) { return item.kind === 'file'; });
        if (!isFile) return;
        event.preventDefault();
        if (event.type !== 'drop') return;
        if (!status) {
          status = document.createElement('p');
          status.className = 'glpiacessivel-help-text';
          status.setAttribute('role', 'status');
          status.setAttribute('aria-live', 'polite');
          status.setAttribute('aria-atomic', 'true');
          status.setAttribute('data-glpiacessivel-file-drop-status', '');
        }
        var host = target.closest('.glpiacessivel-field, .glpiacessivel-field-block') || form;
        if (status.parentElement !== host) host.appendChild(status);
        status.textContent = '';
        window.setTimeout(function () { status.textContent = dropMessage; }, 0);
      }
      form.addEventListener('dragover', unsupportedFileDrop);
      form.addEventListener('drop', unsupportedFileDrop);
      form.addEventListener('change', function (event) {
        if (status && event.target instanceof HTMLInputElement && event.target.type === 'file') status.textContent = '';
      });
    });

    document.querySelectorAll('[data-glpiacessivel-scrollable-content]').forEach(function (content) {
      if (content.dataset.glpiacessivelScrollSafetyReady === '1') return;
      content.dataset.glpiacessivelScrollSafetyReady = '1';
      var ownsTabIndex = false;
      function updateScrollStop() {
        var overflow = content.scrollWidth > content.clientWidth + 1;
        if (overflow && !content.hasAttribute('tabindex')) {
          content.setAttribute('tabindex', '0');
          ownsTabIndex = true;
        } else if (!overflow && ownsTabIndex) {
          content.removeAttribute('tabindex');
          ownsTabIndex = false;
        }
      }
      content.addEventListener('load', updateScrollStop, true);
      content.addEventListener('keydown', function (event) {
        if (event.defaultPrevented || event.target !== content || event.altKey || event.ctrlKey || event.metaKey || event.shiftKey
          || content.scrollWidth <= content.clientWidth + 1) return;
        var delta = event.key === 'ArrowRight' ? 40 : event.key === 'ArrowLeft' ? -40 : 0;
        if (!delta) return;
        var previous = content.scrollLeft;
        content.scrollLeft += delta;
        if (content.scrollLeft !== previous) event.preventDefault();
      });
      window.addEventListener('resize', updateScrollStop);
      if (typeof ResizeObserver === 'function') new ResizeObserver(updateScrollStop).observe(content);
      updateScrollStop();
    });
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init, {once: true});
  else init();
})();
