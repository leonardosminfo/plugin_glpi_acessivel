(function () {
  'use strict';

  function initialize() {
    const section = document.querySelector('[data-editorial-selection]');
    if (section instanceof HTMLElement && section.dataset.editorialBound !== '1') {
      section.dataset.editorialBound = '1';
      const form = section.querySelector('[data-editorial-form]');
      const all = section.querySelector('[data-editorial-all]');
      const count = section.querySelector('[data-editorial-count]');
      const clear = section.querySelector('[data-editorial-clear]');
      const boxes = Array.from(section.querySelectorAll('[data-editorial-checkbox]'))
        .filter(function (box) { return box instanceof HTMLInputElement && !box.disabled; });
      const buttons = Array.from(section.querySelectorAll('button[form="editorial-batch-selection"]'))
        .filter(function (button) { return button.name === 'action' && /^batch_review_/.test(button.value); });
      const message = function (key) { return String(section.dataset[key] || ''); };
      function selected() { return boxes.filter(function (box) { return box.checked; }).length; }
      function refresh(announce) {
        const size = selected();
        if (all instanceof HTMLInputElement) {
          all.checked = boxes.length > 0 && size === boxes.length;
          all.indeterminate = size > 0 && size < boxes.length;
          all.disabled = boxes.length === 0;
        }
        buttons.forEach(function (button) { button.disabled = size === 0; });
        if (count instanceof HTMLElement && announce) {
          count.textContent = message('selectionMessage').replace('{count}', String(size));
        }
      }
      function reset(announce) {
        boxes.forEach(function (box) { box.checked = false; });
        refresh(false);
        if (count instanceof HTMLElement && announce) {
          count.textContent = message('selectionCleared');
        }
      }
      if (form instanceof HTMLFormElement && all instanceof HTMLInputElement && count instanceof HTMLElement) {
        section.querySelectorAll('[data-editorial-enhancement]').forEach(function (node) { node.hidden = false; });
        all.addEventListener('change', function () {
          boxes.forEach(function (box) { box.checked = all.checked; });
          refresh(true);
        });
        boxes.forEach(function (box) { box.addEventListener('change', function () { refresh(true); }); });
        if (clear instanceof HTMLButtonElement) {
          clear.addEventListener('click', function () { reset(true); });
        }
        form.addEventListener('submit', function (event) {
          if (selected() === 0 && (!event.submitter || event.submitter.value !== 'batch_select_page')) {
            event.preventDefault();
            count.textContent = message('selectionEmpty');
          }
          // Native form association transports every checked ID. Never disable
          // successful controls or insert hidden copies before the native POST.
        });
        const navigate = function (event) {
          if (selected() > 0) {
            if (!window.confirm(message('selectionNavigation'))) {
              event.preventDefault();
              return;
            }
            reset(true);
          }
        };
        section.querySelectorAll('[data-editorial-filter]').forEach(function (filter) {
          filter.addEventListener('submit', navigate);
        });
        section.querySelectorAll('[data-editorial-pagination] a').forEach(function (link) {
          link.addEventListener('click', navigate);
        });
        document.querySelectorAll('.glpiacessivel-context-switch-form').forEach(function (contextForm) {
          contextForm.addEventListener('submit', navigate);
        });
        window.addEventListener('pageshow', function (event) {
          if (event.persisted) { reset(true); }
        });
        refresh(true);
      }
    }
    const focus = document.querySelector('[data-editorial-error]') || document.querySelector('[data-editorial-focus]');
    if (focus instanceof HTMLElement && focus.dataset.editorialFocused !== '1') {
      focus.dataset.editorialFocused = '1';
      focus.focus();
    }
  }
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initialize, { once: true });
  } else {
    initialize();
  }
})();
