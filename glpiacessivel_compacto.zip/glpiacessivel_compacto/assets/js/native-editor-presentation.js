(function () {
  'use strict';

  // Presentation only: the installed GLPI owns TinyMCE, its content, events,
  // selection, undo history, validation, uploads and submission lifecycle.
  if (window.__glpiacessivelNativeEditorPresentation) { return; }
  window.__glpiacessivelNativeEditorPresentation = true;

  var frames = new WeakSet();
  var selector = '[data-glpiacessivel-native-interaction-editor] .tox-edit-area iframe, '
    + '[data-glpiacessivel-native-interaction-creator] .tox-edit-area iframe';
  var styleId = 'glpiacessivel-native-editor-presentation';
  var sized = new WeakSet();

  function bindSize() {
    document.querySelectorAll('[data-glpiacessivel-rich-size]').forEach(function (controls) {
      if (sized.has(controls)) { return; }
      var scope = controls.closest('[data-glpiacessivel-native-interaction-editor], [data-glpiacessivel-native-interaction-creator]');
      var textarea = document.getElementById(controls.getAttribute('data-glpiacessivel-rich-size'));
      if (!scope || !textarea || textarea.tagName !== 'TEXTAREA' || !scope.contains(textarea)) { return; }
      var frame = document.getElementById(textarea.id + '_ifr');
      var root = frame && frame.closest('.tox-tinymce');
      var grow = controls.querySelector('[data-rich-size-grow]');
      var reset = controls.querySelector('[data-rich-size-reset]');
      var status = controls.querySelector('[data-rich-size-status]');
      if (!root || !scope.contains(root) || !grow || !reset || !status) { return; }
      var baseline = Math.max(320, parseFloat(getComputedStyle(root).minHeight) || 0);
      grow.setAttribute('aria-controls', frame.id);
      reset.setAttribute('aria-controls', frame.id);
      sized.add(controls);
      controls.hidden = false;
      function resize(restore) {
        // Do not alter native fullscreen geometry, content, undo or uploads.
        if (root.classList.contains('tox-fullscreen')) { return; }
        var current = root.getBoundingClientRect().height;
        var maximum = Math.max(baseline, Math.min(960, Math.round(window.innerHeight * 0.8)));
        var height = restore ? baseline : Math.max(current, Math.min(maximum, current + 120));
        if (!restore && height <= current + 1) {
          status.textContent = controls.getAttribute('data-msg-limit');
          return;
        }
        root.style.minHeight = height + 'px';
        root.style.height = height + 'px';
        status.textContent = controls.getAttribute(restore ? 'data-msg-restored' : 'data-msg-expanded');
      }
      grow.addEventListener('click', function () { resize(false); });
      reset.addEventListener('click', function () { resize(true); });
    });
  }

  function apply(frame) {
    try {
      var doc = frame.contentDocument;
      if (!doc || !doc.head || !doc.body || !frame.matches(selector)) { return; }
      var preferences = getComputedStyle(document.body);
      var high = document.body.getAttribute('data-glpiacessivel-contrast') === 'high';
      var night = document.body.getAttribute('data-glpiacessivel-theme') === 'night';
      var style = doc.getElementById(styleId);
      if (!style) {
        style = doc.createElement('style');
        style.id = styleId;
        style.textContent = 'body{} body a:not([style]){}';
        doc.head.appendChild(style);
      }
      if (style.tagName !== 'STYLE' || !style.sheet || style.sheet.cssRules.length !== 2) { return; }
      var bodyRule = style.sheet.cssRules[0].style;
      // Body defaults do not overwrite explicitly formatted descendants.
      bodyRule.setProperty('font-family', preferences.fontFamily, 'important');
      bodyRule.setProperty('font-size', preferences.fontSize, 'important');
      bodyRule.setProperty('line-height', '1.5', 'important');
      bodyRule.setProperty('color', high ? '#ffffff' : preferences.getPropertyValue('--ga-native-ink').trim()
        || preferences.getPropertyValue('--ga-ink').trim() || (night ? '#edf5ff' : '#102033'), 'important');
      bodyRule.setProperty('background-color', high ? '#000000' : preferences.getPropertyValue('--ga-native-surface').trim()
        || preferences.getPropertyValue('--ga-surface').trim() || (night ? '#142338' : '#ffffff'), 'important');
      // The native primary token is a button background, not a safe link ink
      // on dark surfaces. Prefer a dedicated link token in night presentation.
      style.sheet.cssRules[1].style.setProperty('color', high ? '#ffff00'
        : preferences.getPropertyValue('--ga-native-link').trim() || preferences.getPropertyValue('--ga-blue').trim()
        || (night ? '#93c5fd' : preferences.getPropertyValue('--ga-native-primary').trim() || '#005a9c'));
    } catch (error) {
      // Cross-origin, sandboxed or unavailable documents retain native styling.
      // Never weaken iframe security or recreate the native editor to recover.
    }
  }

  function refresh() {
    bindSize();
    document.querySelectorAll(selector).forEach(function (frame) {
      if (!frames.has(frame)) {
        frames.add(frame);
        frame.addEventListener('load', function () { apply(frame); });
      }
      apply(frame);
    });
  }

  function initialize() {
    if (!document.body) { return; }
    refresh();
    // TinyMCE may mount after DOMContentLoaded; no polling or reinitialization.
    new MutationObserver(refresh).observe(document.body, {childList: true, subtree: true});
    new MutationObserver(refresh).observe(document.body, {
      attributes: true,
      attributeFilter: ['style', 'class', 'data-glpiacessivel-theme', 'data-glpiacessivel-contrast']
    });
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initialize, {once: true});
  } else {
    initialize();
  }
}());
