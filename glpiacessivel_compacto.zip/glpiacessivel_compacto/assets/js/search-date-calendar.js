(function () {
  'use strict';
  if (window.GlpiacessivelSearchDateCalendar) { return; }
  const defaults = {
    'search.date.label': 'Data', 'search.date.datetime_label': 'Data e hora',
    'search.date.open': 'Escolher data', 'search.date.open_datetime': 'Escolher data e hora',
    'search.date.close': 'Fechar calendário', 'search.date.confirm': 'Confirmar data e hora',
    'search.date.clear': 'Limpar data', 'search.date.previous': 'Mês anterior',
    'search.date.next': 'Mês seguinte', 'search.date.month': 'Mês', 'search.date.year': 'Ano',
    'search.date.hour': 'Hora', 'search.date.minute': 'Minuto', 'search.date.second': 'Segundo',
    'search.date.help': 'Digite no formato {format} ou escolha pelo calendário. Escolher a data não executa a pesquisa.',
    'search.date.fallback_help': 'Digite ou selecione pelo controle do navegador. Escolher a data não executa a pesquisa.',
    'search.date.invalid': 'Informe uma data válida. Confira o dia, o mês e o ano.',
    'search.date.datetime_invalid': 'Informe uma data e hora válidas. Confira a data e o horário.',
    'search.date.keyboard': 'Use as setas para percorrer os dias. Esc fecha o calendário. Você também pode digitar diretamente no campo.'
  };
  function message(key, values) {
    const catalog = window.__glpiacessivelI18n || {};
    let value = (catalog.messages || catalog)[key] || defaults[key] || key;
    Object.keys(values || {}).forEach(function (name) { value = value.replace('{' + name + '}', values[name]); });
    return value;
  }
  function configuration() {
    const node = document.querySelector('[data-glpiacessivel-date-calendar-config]');
    try { return node ? JSON.parse(node.textContent) : {}; } catch (_) { return {}; }
  }
  function validParts(year, month, day, hour, minute, second) {
    const leap = year % 4 === 0 && (year % 100 !== 0 || year % 400 === 0);
    const days = [31, leap ? 29 : 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
    return year >= 1 && year <= 9999 && month >= 1 && month <= 12 && day >= 1
      && day <= days[month - 1] && hour >= 0 && hour <= 23 && minute >= 0 && minute <= 59
      && second >= 0 && second <= 59;
  }
  function canonical(value, kind) {
    const expression = kind === 'date' ? /^(\d{4})-(\d{2})-(\d{2})$/
      : /^(\d{4})-(\d{2})-(\d{2})[ T](\d{2}):(\d{2})(?::(\d{2}))?$/;
    const match = expression.exec(value);
    if (!match || !validParts(+match[1], +match[2], +match[3], +(match[4] || 0), +(match[5] || 0), +(match[6] || 0))) { return null; }
    return match[1] + '-' + match[2] + '-' + match[3]
      + (kind === 'datetime' ? ' ' + match[4] + ':' + match[5] + ':' + (match[6] || '00') : '');
  }
  function display(value, format) {
    const pieces = value.slice(0, 10).split('-');
    return format.replace(/[Ymd]/g, function (token) { return pieces[{ Y: 0, m: 1, d: 2 }[token]]; }) + value.slice(10);
  }
  function parseVisible(value, kind, format) {
    // Never infer day/month order or use Date/UTC conversion for civil timestamps.
    const direct = canonical(value, kind);
    if (direct !== null) { return direct; }
    const tokens = [];
    const expression = format.replace(/[.*+?^${}()|[\]\\]/g, '\\$&').replace(/[Ymd]/g, function (token) {
      tokens.push(token); return token === 'Y' ? '(\\d{4})' : '(\\d{2})';
    });
    const date = new RegExp('^' + expression + (kind === 'datetime' ? '[ T](\\d{2}):(\\d{2})(?::(\\d{2}))?' : '') + '$').exec(value);
    if (!date) { return null; }
    const parts = {}; tokens.forEach(function (token, index) { parts[token] = date[index + 1]; });
    return canonical(parts.Y + '-' + parts.m + '-' + parts.d
      + (kind === 'datetime' ? ' ' + date[4] + ':' + date[5] + ':' + (date[6] || '00') : ''), kind);
  }
  function mount(host, submitted, options) {
    options = options || {};
    const kind = options.kind;
    if (!host || !submitted || !['date', 'datetime'].includes(kind)) { return null; }
    if (host._glpiacessivelDateCalendar) { host._glpiacessivelDateCalendar.destroy(); }
    const settings = Object.assign({}, configuration(), options);
    const format = ['Y-m-d', 'd-m-Y', 'm-d-Y', 'd/m/Y', 'm/d/Y', 'Y/m/d'].includes(settings.format) ? settings.format : 'Y-m-d';
    const original = submitted.value;
    const initial = canonical(original, kind);
    const label = host.querySelector('label[for="' + submitted.id + '"]');
    const labelText = message(kind === 'date' ? 'search.date.label' : 'search.date.datetime_label');
    if (label) { label.textContent = labelText + (options.fieldLabel ? ' — ' + options.fieldLabel : ''); }
    const visible = document.createElement('input');
    visible.type = 'text'; visible.id = submitted.id + '-display'; visible.autocomplete = 'off';
    visible.dataset.advancedDateInput = ''; visible.maxLength = 64;
    visible.setAttribute('aria-required', options.required ? 'true' : 'false');
    if (label) { label.htmlFor = visible.id; }
    submitted.type = 'hidden';
    const controls = document.createElement('div'); controls.className = 'glpiacessivel-date-controls';
    controls.appendChild(visible); host.appendChild(controls);
    const help = document.createElement('p'); help.id = visible.id + '-help'; help.className = 'glpiacessivel-help-text';
    visible.setAttribute('aria-describedby', help.id); host.appendChild(help);
    const nativeAvailable = typeof window.flatpickr === 'function';
    const fallbackType = kind === 'date' ? 'date' : 'datetime-local';
    if (!nativeAvailable && (original === '' || initial !== null)) {
      visible.type = fallbackType;
      if (kind === 'datetime') { visible.step = '1'; }
    }
    const nativeInput = visible.type === 'date' || visible.type === 'datetime-local';
    visible.value = initial === null ? original : nativeInput ? initial.replace(' ', 'T') : display(initial, format);
    const example = format.replace('Y', 'AAAA').replace('m', 'MM').replace('d', 'DD') + (kind === 'datetime' ? ' HH:MM:SS' : '');
    help.textContent = message(nativeInput ? 'search.date.fallback_help' : 'search.date.help', { format: example });
    let instance = null; let button = null; let proxy = null; let closingToButton = false; let destroyed = false;
    function sync() {
      const text = visible.value;
      const normalized = text === '' ? '' : nativeInput ? canonical(text, kind) : parseVisible(text, kind, format);
      const bad = visible.validity && visible.validity.badInput;
      submitted.value = normalized === null || bad ? text : normalized;
      return { valid: normalized !== null && !bad, empty: text === '' && !bad };
    }
    function notify() {
      sync(); submitted.dispatchEvent(new Event('change', { bubbles: true }));
    }
    visible.addEventListener('input', notify); visible.addEventListener('change', notify);
    const api = { visibleInput: visible, sync: sync, destroy: function () {
      destroyed = true;
      window.removeEventListener('resize', placeCalendar);
      window.removeEventListener('scroll', placeCalendar, true);
      if (instance) { instance.destroy(); }
      if (proxy) { proxy.remove(); }
      controls.remove(); help.remove(); submitted.type = 'text';
      if (label) { label.htmlFor = submitted.id; }
      delete host._glpiacessivelDateCalendar;
    } };
    host._glpiacessivelDateCalendar = api;
    if (!nativeAvailable) { return api; }
    function action(text, callback, attribute) {
      const node = document.createElement('button'); node.type = 'button'; node.textContent = message(text);
      if (attribute) { node.setAttribute(attribute, ''); }
      node.className = 'glpiacessivel-button glpiacessivel-button-secondary'; node.addEventListener('click', callback); return node;
    }
    button = action(kind === 'date' ? 'search.date.open' : 'search.date.open_datetime', function () {
      const selected = sync();
      instance.setDate(selected.valid && !selected.empty ? submitted.value : null, false);
      instance.open();
    }, 'data-advanced-date-open');
    button.setAttribute('aria-expanded', 'false'); controls.appendChild(button);
    proxy = document.createElement('input'); proxy.type = 'hidden'; proxy.hidden = true; proxy.dataset.advancedDateProxy = '';
    proxy.setAttribute('aria-hidden', 'true'); proxy.tabIndex = -1; host.appendChild(proxy);
    function names() {
      const calendar = instance.calendarContainer;
      calendar.querySelectorAll('.flatpickr-day').forEach(function (day) { day.setAttribute('role', 'button'); });
      [[instance.monthsDropdownContainer, 'search.date.month'], [instance.currentYearElement, 'search.date.year'],
        [instance.hourElement, 'search.date.hour'], [instance.minuteElement, 'search.date.minute'], [instance.secondElement, 'search.date.second']].forEach(function (pair) {
        if (pair[0]) { pair[0].setAttribute('aria-label', message(pair[1])); }
      });
    }
    function placeCalendar() {
      if (!instance || !instance.isOpen || destroyed) { return; }
      const calendar = instance.calendarContainer;
      const field = visible.getBoundingClientRect();
      const box = calendar.getBoundingClientRect();
      let top = field.bottom + 4;
      if (top + box.height > window.innerHeight - 8) { top = field.top - box.height - 4; }
      top = Math.max(8, Math.min(top, window.innerHeight - box.height - 8));
      const left = Math.max(8, Math.min(field.left, window.innerWidth - box.width - 8));
      calendar.style.setProperty('position', 'fixed', 'important');
      calendar.style.setProperty('top', top + 'px', 'important');
      calendar.style.setProperty('left', left + 'px', 'important');
      calendar.style.setProperty('right', 'auto', 'important');
    }
    try {
      const locale = (window.flatpickr.l10ns || {})[settings.locale] || (window.flatpickr.l10ns || {}).default;
      instance = window.flatpickr(proxy, {
        dateFormat: kind === 'date' ? 'Y-m-d' : 'Y-m-d H:i:S', locale: locale,
        enableTime: kind === 'datetime', enableSeconds: kind === 'datetime', time_24hr: true,
        minuteIncrement: 1, clickOpens: false, allowInput: false, disableMobile: true,
        positionElement: visible, ariaDateFormat: 'l, j F Y',
        position: function (picker) { instance = picker; placeCalendar(); },
        onOpen: function (_, __, picker) {
          instance = picker; button.setAttribute('aria-expanded', 'true'); names();
          const day = picker.calendarContainer.querySelector('.selected:not(.hidden)')
            || picker.calendarContainer.querySelector('.today:not(.hidden)')
            || picker.calendarContainer.querySelector('.flatpickr-day:not(.prevMonthDay):not(.nextMonthDay)');
          if (day) {
            day.tabIndex = 0;
            // Core fires onOpen before final placement. Never scroll to its
            // temporary body-end position while focusing the selected day.
            try { day.focus({ preventScroll: true }); } catch (_) { day.focus(); }
          }
          window.requestAnimationFrame(placeCalendar);
        },
        onClose: function () {
          button.setAttribute('aria-expanded', 'false');
          if (!destroyed && (closingToButton || instance.calendarContainer.contains(document.activeElement))) { button.focus(); }
          closingToButton = false;
        },
        onChange: function (_, value) {
          if (kind === 'datetime') { return; }
          const valid = canonical(value, kind);
          if (valid !== null) { submitted.value = valid; visible.value = display(valid, format); notify(); }
        },
        onMonthChange: names, onYearChange: names
      });
      if (!instance || !instance.calendarContainer) { throw new Error('calendar_unavailable'); }
      const calendar = instance.calendarContainer; calendar.classList.add('glpiacessivel-search-date-calendar');
      calendar.id = visible.id + '-calendar'; button.setAttribute('aria-controls', calendar.id);
      calendar.setAttribute('role', 'dialog'); calendar.setAttribute('aria-label', button.textContent);
      const instructions = document.createElement('p'); instructions.className = 'glpiacessivel-date-keyboard';
      instructions.id = calendar.id + '-help'; calendar.setAttribute('aria-describedby', instructions.id);
      instructions.textContent = message('search.date.keyboard'); calendar.appendChild(instructions);
      const footer = document.createElement('div'); footer.className = 'glpiacessivel-date-calendar-actions';
      function close() { closingToButton = true; instance.close(); }
      if (kind === 'datetime') { footer.appendChild(action('search.date.confirm', function () {
        if (instance.selectedDates.length === 1) {
          const value = instance.formatDate(instance.selectedDates[0], 'Y-m-d H:i:S');
          if (canonical(value, kind) !== null) { visible.value = display(value, format); notify(); }
        }
        close();
      })); }
      footer.appendChild(action('search.date.close', close)); calendar.appendChild(footer);
      [[instance.prevMonthNav, -1, 'search.date.previous'], [instance.nextMonthNav, 1, 'search.date.next']].forEach(function (entry) {
        entry[0].setAttribute('role', 'button'); entry[0].tabIndex = 0; entry[0].setAttribute('aria-label', message(entry[2]));
        entry[0].addEventListener('keydown', function (event) {
          if (event.key === 'Enter' || event.key === ' ') { event.preventDefault(); event.stopImmediatePropagation(); instance.changeMonth(entry[1]); }
        });
      });
      calendar.addEventListener('keydown', function (event) {
        if (event.key === 'Escape') { event.preventDefault(); event.stopImmediatePropagation(); close(); }
        if ((event.key === 'Enter' || event.key === ' ') && event.target instanceof HTMLButtonElement
          && event.target.closest('.glpiacessivel-date-calendar-actions')) {
          // Flatpickr's document key handler consumes Enter inside its popup.
          // Preserve native keyboard activation of our real action buttons.
          event.preventDefault(); event.stopImmediatePropagation(); event.target.click(); return;
        }
        if (event.key === ' ' && event.target instanceof Element && event.target.classList.contains('flatpickr-day')) {
          event.preventDefault(); event.stopImmediatePropagation(); event.target.click();
        }
      }, true);
      calendar.addEventListener('focusout', function (event) {
        if (event.relatedTarget && !calendar.contains(event.relatedTarget) && event.relatedTarget !== button) { instance.close(); }
      });
      names();
      window.addEventListener('resize', placeCalendar);
      window.addEventListener('scroll', placeCalendar, true);
    } catch (_) {
      if (instance && typeof instance.destroy === 'function') { instance.destroy(); }
      button.remove(); proxy.remove(); instance = null; proxy = null;
      // Keep the independent text field usable even when core assets/API fail.
    }
    return api;
  }
  window.GlpiacessivelSearchDateCalendar = { mount: mount };
}());
