(function () {
  'use strict';
  // Presentation only. Never replace/reparent a form, iframe, editor or upload.
  function bind(root) {
    if (root.dataset.ready === 'true') { return; }
    var controls = root.querySelector('[data-presentation-controls]');
    var choices = Array.from(root.querySelectorAll('[data-presentation-mode]'));
    var status = root.querySelector('[data-presentation-status]');
    if (!controls || choices.length !== 2 || !status) { return; }
    var disclosures = Array.from(root.querySelectorAll('details[data-presentation-disclosure]'));
    var toggles = Array.from(root.querySelectorAll('[data-presentation-toggle]'));
    var dirty = new WeakSet();
    var initialValues = new WeakMap();
    var saveChain = Promise.resolve();
    var sequence = 0;
    function valueOf(field) {
      if (field.tagName === 'SELECT') { return Array.from(field.options).map(function (option) { return option.selected; }).join(','); }
      if (field.type === 'checkbox' || field.type === 'radio') { return field.checked; }
      return field.value;
    }
    root.querySelectorAll('input,textarea,select').forEach(function (field) { initialValues.set(field, valueOf(field)); });

    function targetFromHash(hash) {
      try { return hash && hash !== '#' ? document.getElementById(decodeURIComponent(hash.slice(1))) : null; }
      catch (error) { return null; }
    }
    function parts(button) {
      return String(button.getAttribute('aria-controls') || '').split(/\s+/)
        .map(function (id) { return document.getElementById(id); })
        .filter(function (node) { return node && root.contains(node); });
    }
    function expand(button, open) {
      parts(button).forEach(function (node) { node.hidden = !open; });
      button.setAttribute('aria-expanded', open ? 'true' : 'false');
    }
    function reveal(target) {
      if (!(target instanceof Element) || !root.contains(target)) { return; }
      disclosures.forEach(function (details) {
        var summary = details.querySelector('[data-presentation-summary]');
        if (details.contains(target) && (!summary || !summary.contains(target))) { details.open = true; }
      });
      toggles.forEach(function (button) {
        if (parts(button).some(function (node) { return node.contains(target); })) { expand(button, true); }
      });
    }
    function hasDraft(details) {
      if (dirty.has(details)) { return true; }
      return Array.from(details.querySelectorAll('input,textarea,select')).some(function (field) {
        if (field.type === 'file') { return !!(field.files && field.files.length); }
        return field.type !== 'hidden' && initialValues.has(field) && valueOf(field) !== initialValues.get(field);
      });
    }
    function protectedRegion(details) {
      var fragment = targetFromHash(window.location.hash);
      if (details.contains(document.activeElement) || (fragment && details.contains(fragment)) || hasDraft(details)) {
        return true;
      }
      return Array.from(details.querySelectorAll('[aria-invalid="true"],[data-glpiacessivel-focus-alert],[role="alert"],dialog[open],[aria-modal="true"]'))
        .some(function (node) { return !node.closest('[hidden]') && (node.textContent.trim() || node.matches('[aria-invalid="true"]')); });
    }
    function apply(mode) {
      root.dataset.mode = mode;
      disclosures.forEach(function (details) {
        var summary = details.querySelector('[data-presentation-summary]');
        if (summary) { summary.hidden = mode === 'complete'; }
        details.open = mode === 'complete' || protectedRegion(details);
      });
      toggles.forEach(function (button) {
        var fragment = targetFromHash(window.location.hash);
        var keep = parts(button).some(function (node) {
          return node.contains(document.activeElement) || (fragment && node.contains(fragment));
        });
        button.hidden = mode === 'complete';
        expand(button, mode === 'complete' || keep);
      });
      root.querySelectorAll('[data-presentation-requester]').forEach(function (node) { node.hidden = mode !== 'simple'; });
      choices.forEach(function (button) { button.setAttribute('aria-pressed', button.dataset.presentationMode === mode ? 'true' : 'false'); });
    }
    function save(mode, requestNumber) {
      var url;
      try { url = new URL(root.dataset.saveUrl || '', window.location.href); }
      catch (error) { return Promise.reject(error); }
      if (!root.dataset.saveUrl || url.origin !== window.location.origin || !root.dataset.csrfToken) {
        return Promise.reject(new Error('preference_unavailable'));
      }
      var controller = new AbortController();
      var timeout = window.setTimeout(function () { controller.abort(); }, 10000);
      return fetch(url.href, {
        method: 'POST', credentials: 'same-origin', redirect: 'error', cache: 'no-store',
        signal: controller.signal,
        headers: { 'Content-Type': 'application/json', 'Accept': 'application/json', 'X-Requested-With': 'XMLHttpRequest', 'X-GLPI-CSRF-Token': root.dataset.csrfToken },
        body: JSON.stringify({ contract: 'presentation_preference', version: 1, mode: mode })
      }).then(function (response) {
        root.dataset.preferenceHttpStatus = String(response.status);
        return response.json().then(function (data) {
          if (!response.ok) {
            var code = data && data.error && data.error.code;
            throw new Error(typeof code === 'string' && /^[a-z_]{1,60}$/.test(code) ? code : 'preference_failed');
          }
          return data;
        });
      }).then(function (data) {
        if (!data || data.success !== true || !data.result || data.result.mode !== mode) { throw new Error('preference_failed'); }
        if (typeof data.csrf_token === 'string' && data.csrf_token) { root.dataset.csrfToken = data.csrf_token; }
        if (sequence === requestNumber) {
          delete root.dataset.preferenceError;
          status.textContent = (root.dataset[mode === 'simple' ? 'simpleMessage' : 'completeMessage'] || '') + ' ' + (root.dataset.savedMessage || '');
        }
      }).finally(function () { window.clearTimeout(timeout); });
    }
    choices.forEach(function (button) {
      button.addEventListener('click', function () {
        var mode = button.dataset.presentationMode;
        if (mode !== 'simple' && mode !== 'complete') { return; }
        if (root.dataset.mode !== mode) { apply(mode); }
        status.textContent = root.dataset[mode === 'simple' ? 'simpleMessage' : 'completeMessage'] || '';
        var requestNumber = ++sequence;
        // Serialize preference writes only; changing presentation stays immediate.
        saveChain = saveChain.catch(function () {}).then(function () { return save(mode, requestNumber); })
          .catch(function (error) {
            if (sequence === requestNumber) {
              root.dataset.preferenceError = /^[a-z_]{1,60}$/.test(error.message) ? error.message : 'preference_failed';
              status.textContent = root.dataset.unsavedMessage || '';
            }
          });
      });
    });
    toggles.forEach(function (button) {
      button.addEventListener('click', function () { expand(button, button.getAttribute('aria-expanded') !== 'true'); });
    });
    ['input', 'change'].forEach(function (type) {
      root.addEventListener(type, function (event) {
        var details = event.target instanceof Element ? event.target.closest('details[data-presentation-disclosure]') : null;
        if (details) { dirty.add(details); }
      });
    });
    root.addEventListener('invalid', function (event) { reveal(event.target); }, true);
    root.addEventListener('focusin', function (event) { reveal(event.target); });
    root.addEventListener('click', function (event) {
      var link = event.target instanceof Element ? event.target.closest('a[href]') : null;
      if (!link || link.target === '_blank' || event.ctrlKey || event.metaKey || event.altKey || event.shiftKey) { return; }
      if (link.origin === location.origin && link.pathname === location.pathname && link.search === location.search) { reveal(targetFromHash(link.hash)); }
    }, true);
    window.addEventListener('hashchange', function () { reveal(targetFromHash(window.location.hash)); });
    // Errors added later must remain reachable even when their section is closed.
    new MutationObserver(function (records) {
      records.forEach(function (record) {
        if (record.type === 'attributes' && record.attributeName === 'aria-invalid' && record.target.getAttribute('aria-invalid') === 'true') { reveal(record.target); }
        Array.from(record.addedNodes || []).forEach(function (node) {
          if (!(node instanceof Element)) { return; }
          if (node.matches('[role="alert"],[aria-invalid="true"]')) { reveal(node); }
          node.querySelectorAll('[role="alert"],[aria-invalid="true"]').forEach(reveal);
        });
      });
    }).observe(root, { subtree: true, childList: true, attributes: true, attributeFilter: ['aria-invalid'] });
    root.dataset.ready = 'true';
    apply(root.dataset.preferredMode === 'simple' ? 'simple' : 'complete');
    controls.hidden = false;
    reveal(targetFromHash(window.location.hash));
    root.querySelectorAll('[aria-invalid="true"],[data-glpiacessivel-focus-alert]').forEach(reveal);
  }
  function initialize() { document.querySelectorAll('[data-ticket-presentation]').forEach(bind); }
  if (document.readyState === 'loading') { document.addEventListener('DOMContentLoaded', initialize, { once: true }); }
  else { initialize(); }
})();
