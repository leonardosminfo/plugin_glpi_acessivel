(function () {
  'use strict';

  // Complete presentation only. Native controls, values, handlers, uploads and
  // editor initialization remain owned by the installed GLPI.
  var scopeSelector = '[data-glpiacessivel-native-interaction-editor], [data-glpiacessivel-native-interaction-creator]';
  var generatedId = 0;
  function readableText(value) {
    return String(value || '').replace(/[\uE000-\uF8FF]/g, '').replace(/\s+/g, ' ').trim();
  }

  function associatedLabels(control, scope) {
    return Array.prototype.filter.call(control.labels || [], function (label) {
      // In the own form, the label precedes the editor/uploader fragment.
      // Reuse that explicit association instead of creating a second label.
      return scope.contains(label) || (scope.hasAttribute('data-glpiacessivel-rich-fields')
        && control.form && control.form === scope.closest('form') && control.form.contains(label));
    });
  }

  function alreadyNamed(control, labels) {
    if (readableText(control.getAttribute('aria-label')) || readableText(control.getAttribute('title'))) {
      return true;
    }
    var references = String(control.getAttribute('aria-labelledby') || '').trim().split(/\s+/);
    if (references.some(function (id) {
      var label = id && document.getElementById(id);
      return label && readableText(label.textContent);
    })) {
      return true;
    }
    return labels.some(function (label) {
      return readableText(label.textContent);
    }) || (control.tagName === 'BUTTON' && readableText(control.textContent));
  }

  function nativeLabel(control, labels, scope) {
    var titles = [];
    labels.forEach(function (label) {
      var nodes = [label].concat(Array.prototype.slice.call(label.querySelectorAll('[title]')));
      nodes.forEach(function (node) {
        var title = readableText(node.getAttribute('title') || node.getAttribute('data-bs-original-title'));
        if (title && titles.indexOf(title) === -1) {
          titles.push(title);
        }
      });
    });
    if (titles.length === 1) {
      return titles[0];
    }
    // This native switch has an empty wrapping label and its translated hint
    // on the adjacent enclosing control, not on the input or its label.
    if (control.tagName === 'INPUT' && control.name === 'pending') {
      var group = control.closest('[id^="pending-reasons-control-"]');
      var hint = control.closest('[title], [data-bs-original-title]');
      if (group && hint && scope.contains(group) && group.contains(hint)) {
        return readableText(hint.getAttribute('title') || hint.getAttribute('data-bs-original-title'));
      }
    }
    if (control.tagName === 'INPUT' && control.type === 'file') {
      var uploader = control.closest('.fileupload');
      if (uploader && scope.contains(uploader)) {
        var heading = Array.prototype.find.call(uploader.children, function (node) {
          return node.tagName === 'B';
        });
        if (heading) {
          // Native uploader headings also contain help/modal/script nodes.
          // Only their direct text is the translated file label and limit.
          return readableText(Array.prototype.filter.call(heading.childNodes, function (node) {
            return node.nodeType === 3;
          }).map(function (node) {
            return node.nodeValue;
          }).join(' '));
        }
      }
    }
    return '';
  }

  function labelId(label) {
    if (!label.id) {
      var id;
      do {
        generatedId += 1;
        id = 'glpiacessivel-native-label-' + generatedId;
      } while (document.getElementById(id));
      label.id = id;
      label.setAttribute('data-glpiacessivel-generated-label-id', '1');
    }
    return label.id;
  }

  function translatedIconLabel(label) {
    var titles = [];
    [label].concat(Array.prototype.slice.call(label.querySelectorAll('[title], [data-bs-original-title]'))).forEach(function (node) {
      var text = readableText(node.getAttribute('title') || node.getAttribute('data-bs-original-title'));
      if (text && titles.indexOf(text) === -1) {
        titles.push(text);
      }
    });
    return titles.length === 1 ? titles[0] : '';
  }

  function exposeLabel(label, text) {
    if (!text || label.querySelector('[data-glpiacessivel-native-label-text]') || readableText(label.textContent)) {
      return;
    }
    var span = document.createElement('span');
    span.setAttribute('data-glpiacessivel-native-label-text', '1');
    span.textContent = text;
    label.appendChild(span);
    label.querySelectorAll('i, svg').forEach(function (icon) {
      if (!icon.hasAttribute('aria-hidden')) {
        icon.setAttribute('aria-hidden', 'true');
        icon.setAttribute('data-glpiacessivel-native-decorative-icon', '1');
      }
    });
  }

  function associate(control, label) {
    // Keep existing explicit native names; an icon title alone is not enough
    // for the visible Select2 widget when its selected value says only -----.
    if (readableText(control.getAttribute('aria-label'))) {
      return;
    }
    var references = String(control.getAttribute('aria-labelledby') || '').trim().split(/\s+/).filter(Boolean);
    var id = labelId(label);
    if (references.indexOf(id) === -1) {
      control.setAttribute('aria-labelledby', [id].concat(references).join(' '));
    }
  }

  function nativeFields(scope) {
    scope.querySelectorAll('form .form-field').forEach(function (field) {
      var label = Array.prototype.find.call(field.children, function (node) {
        return node.tagName === 'LABEL';
      });
      if (!label) {
        return;
      }
      var translated = translatedIconLabel(label);
      if (!translated && !readableText(label.textContent)) {
        // In the installed GLPI 10 pending-reason template these three
        // translated titles belong to the immediate column, not the icon.
        // Do not infer labels from distant cards or arbitrary plugin fields.
        var pendingField = field.querySelector('select[name="pendingreasons_id"], select[name="followup_frequency"], select[name="followups_before_resolution"]');
        var column = field.parentElement;
        if (pendingField && pendingField.closest('.form-field') === field && column && scope.contains(column)) {
          translated = readableText(column.getAttribute('title') || column.getAttribute('data-bs-original-title'));
        }
      }
      exposeLabel(label, translated);
      if (!readableText(label.textContent)) {
        return;
      }
      field.setAttribute('data-glpiacessivel-native-field', '1');
      field.querySelectorAll('input:not([type="hidden"]):not([type="file"]), select, textarea, .select2-selection[role="combobox"]').forEach(function (control) {
        // Do not label nested fields or the Select2 popup's search box as if
        // they were this field's value. Its own native search name is retained.
        if (control.closest('.form-field') === field && !control.closest('.select2-search')) {
          associate(control, label);
        }
      });
      var fieldName = readableText(label.textContent);
      [
        ['.flatpickr [data-toggle][role="button"]', 'data-glpiacessivel-date-button-label'],
        ['a.dropdown_tooltip', 'data-glpiacessivel-field-info-label']
      ].forEach(function (entry) {
        var format = readableText(scope.getAttribute(entry[1]));
        if (!format || format.indexOf('%s') === -1) {
          return;
        }
        field.querySelectorAll(entry[0]).forEach(function (control) {
          if (control.closest('.form-field') === field && !alreadyNamed(control, [])) {
            control.setAttribute('aria-label', format.replace('%s', fieldName));
          }
        });
      });
    });
  }

  function nativeContent(scope) {
    var text = readableText(scope.getAttribute('data-glpiacessivel-content-label'));
    if (!text) {
      return;
    }
    scope.querySelectorAll('textarea[name="content"]').forEach(function (control) {
      var labels = associatedLabels(control, scope);
      var label = labels.find(function (node) { return readableText(node.textContent); });
      if (!label && control.id) {
        var target = control.closest('.tox-tinymce') || control.parentElement;
        var editor = control.parentElement.querySelector('.tox-tinymce');
        label = document.createElement('label');
        label.htmlFor = control.id;
        label.setAttribute('data-glpiacessivel-native-content-label', '1');
        label.textContent = text;
        (editor || target).insertAdjacentElement('beforebegin', label);
      }
      if (!label) {
        return;
      }
      associate(control, label);
      // The native iframe keeps its existing title, role, events and document.
      // Add the field context without replacing native editor instructions.
      var host = control.parentElement;
      host.querySelectorAll('iframe.tox-edit-area__iframe').forEach(function (frame) {
        associate(frame, label);
        // Help/error references on the own fragment must also reach the focus
        // destination: readers enter the native iframe, not its outer div.
        var descriptions = String(frame.getAttribute('aria-describedby') || '').trim().split(/\s+/).filter(Boolean);
        [control, scope].forEach(function (source) {
          String(source.getAttribute('aria-describedby') || '').trim().split(/\s+/).filter(Boolean).forEach(function (id) {
            if (document.getElementById(id) && descriptions.indexOf(id) === -1) {
              descriptions.push(id);
            }
          });
        });
        if (descriptions.length) {
          frame.setAttribute('aria-describedby', descriptions.join(' '));
        }
      });
    });
  }

  function initialize() {
    document.querySelectorAll(scopeSelector).forEach(function (scope) {
      scope.querySelectorAll('form input:not([type="hidden"]), form select, form textarea, form button').forEach(function (control) {
        var labels = associatedLabels(control, scope);
        if (!alreadyNamed(control, labels)) {
          var label = nativeLabel(control, labels, scope);
          if (label) {
            control.setAttribute('aria-label', label);
          }
        }
        if (control.name === 'pending' && labels.length) {
          var pendingLabel = nativeLabel(control, labels, scope) || readableText(control.getAttribute('aria-label'));
          exposeLabel(labels[0], pendingLabel);
          // GLPI 10 exposes a titled button around a switch which is itself a
          // button. Keep both native controls and handlers, but give the outer
          // trigger its own native name so its descendant label is not doubled.
          var pendingTrigger = control.parentElement.closest('[role="button"]');
          if (pendingTrigger && scope.contains(pendingTrigger) && pendingLabel && !readableText(pendingTrigger.getAttribute('aria-label'))) {
            pendingTrigger.setAttribute('aria-label', pendingLabel);
          }
        }
      });
      // The first pass preserves the previous names for native switches and
      // upload controls before their icon-only labels become visible text.
      nativeFields(scope);
      nativeContent(scope);
    });
  }

  function start() {
    initialize();
    if (!window.MutationObserver || !document.body) {
      return;
    }
    var scheduled = false;
    new MutationObserver(function (mutations) {
      var relevant = mutations.some(function (mutation) {
        var element = mutation.target.nodeType === 1 ? mutation.target : mutation.target.parentElement;
        return (element && element.closest(scopeSelector)) || Array.prototype.some.call(mutation.addedNodes, function (node) {
          return node.nodeType === 1 && (node.matches(scopeSelector) || node.querySelector(scopeSelector));
        });
      });
      if (relevant && !scheduled) {
        scheduled = true;
        Promise.resolve().then(function () {
          scheduled = false;
          initialize();
        });
      }
    }).observe(document.body, {subtree: true, childList: true});
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', start, {once: true});
  } else {
    start();
  }
}());
