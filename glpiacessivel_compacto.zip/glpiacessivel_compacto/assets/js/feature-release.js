(function () {
  'use strict';

  function initialise() {
    document.querySelectorAll('[data-feature-release]').forEach(function (feature) {
      if (feature.dataset.featureReleaseBound === '1') return;
      const profiles = feature.querySelector('[data-feature-release-profiles]');
      if (!(profiles instanceof HTMLFieldSetElement)) return;
      const radios = feature.querySelectorAll('input[type="radio"]');
      function update() {
        const selected = feature.querySelector('input[type="radio"]:checked');
        const visible = selected instanceof HTMLInputElement && selected.value === 'profiles';
        // Keep checked values in the draft; disabling only affects submission and keyboard access.
        profiles.hidden = !visible;
        profiles.disabled = !visible;
      }
      radios.forEach(function (radio) { radio.addEventListener('change', update); });
      feature.dataset.featureReleaseBound = '1';
      update();
    });
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initialise, {once: true});
  } else {
    initialise();
  }
}());
