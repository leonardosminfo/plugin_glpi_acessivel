(function () {
  'use strict';

  const LABEL_KEYS = {
    id: 'ticket.column.id', name: 'ticket.column.title', status: 'ticket.column.status',
    priority: 'ticket.column.priority', group: 'ticket.column.group',
    requester: 'ticket.column.requester', assignee: 'ticket.column.assignee',
    category: 'ticket.column.category', entity: 'ticket.column.entity',
    location: 'ticket.column.location', date: 'ticket.column.opened_at',
    date_mod: 'ticket.column.updated_at', time_to_resolve: 'ticket.column.resolve_by',
    tags: 'ticket.column.tags'
  };

  const i18n = window.__glpiacessivelI18n && window.__glpiacessivelI18n.messages
    ? window.__glpiacessivelI18n.messages
    : null;
  let listToolsConfig = null;
  let previewSequence = 0;


  function toolMessage(key, replacements) {
    let value = String(listToolsConfig && listToolsConfig.labels && listToolsConfig.labels[key] || '');
    Object.keys(replacements || {}).forEach(function (name) {
      value = value.split('{' + name + '}').join(String(replacements[name]));
    });
    return value;
  }

  function localUrl(value, requiredSuffix) {
    try {
      const url = new URL(String(value || ''), window.location.href);
      return url.origin === window.location.origin && /^https?:$/.test(url.protocol)
        && (!requiredSuffix || url.pathname.endsWith(requiredSuffix)) ? url : null;
    } catch (error) {
      return null;
    }
  }

  // The native endpoint returns rich text. Keep useful semantics, but never
  // execute markup, styles or embedded documents in a list disclosure.
  function safePreviewContent(html) {
    const source = new DOMParser().parseFromString(html, 'text/html');
    const output = document.createDocumentFragment();
    const allowed = new Set(['P', 'BR', 'STRONG', 'B', 'EM', 'I', 'U', 'S', 'UL', 'OL', 'LI',
      'BLOCKQUOTE', 'PRE', 'CODE', 'A', 'SPAN', 'DIV', 'TABLE', 'THEAD', 'TBODY', 'TR', 'TH', 'TD',
      'CAPTION', 'H1', 'H2', 'H3', 'H4', 'H5', 'H6', 'IMG', 'FIGURE', 'FIGCAPTION', 'HR']);
    const discard = new Set(['SCRIPT', 'STYLE', 'IFRAME', 'OBJECT', 'EMBED', 'SVG', 'MATH', 'FORM',
      'INPUT', 'BUTTON', 'SELECT', 'TEXTAREA', 'LINK', 'META', 'BASE', 'AUDIO', 'VIDEO']);
    function append(node, parent) {
      if (node.nodeType === Node.TEXT_NODE) {
        parent.appendChild(document.createTextNode(node.textContent || ''));
        return;
      }
      if (!(node instanceof Element) || discard.has(node.tagName)) {
        return;
      }
      let target = parent;
      if (allowed.has(node.tagName)) {
        // Article headings must not replace the page's heading hierarchy.
        const tag = /^H[1-6]$/.test(node.tagName) ? 'strong' : node.tagName.toLowerCase();
        target = document.createElement(tag);
        if (node.tagName === 'A') {
          try {
            const href = new URL(node.getAttribute('href') || '', window.location.href);
            if (/^https?:$/.test(href.protocol)) {
              target.href = href.href;
              target.rel = 'noopener noreferrer';
            }
          } catch (error) { /* Invalid links remain readable text. */ }
        } else if (node.tagName === 'IMG') {
          const rawSource = (node.getAttribute('src') || '').trim();
          const imageUrl = rawSource ? localUrl(rawSource) : null;
          if (!imageUrl) {
            parent.appendChild(document.createTextNode(node.getAttribute('alt') || ''));
            return;
          }
          target.src = imageUrl.href;
          target.alt = node.getAttribute('alt') || '';
          target.loading = 'lazy';
          target.style.maxWidth = '100%';
          target.style.height = 'auto';
        }
        if (node.hasAttribute('title')) {
          target.title = node.getAttribute('title');
        }
        parent.appendChild(target);
      }
      Array.from(node.childNodes).forEach(function (child) { append(child, target); });
    }
    Array.from(source.body.childNodes).forEach(function (node) { append(node, output); });
    return output;
  }

  function previewButton(item) {
    if (!listToolsConfig || !localUrl(listToolsConfig.preview_url, '/ajax/get_item_content.php')) {
      return null;
    }
    const button = document.createElement('button');
    button.type = 'button';
    button.className = 'glpiacessivel-button glpiacessivel-button-secondary';
    button.dataset.glpiacessivelTicketPreview = String(item.id || '');
    button.dataset.ticketTitle = String(item.name || '');
    button.textContent = toolMessage('preview');
    button.setAttribute('aria-expanded', 'false');
    return button;
  }

  function initializeListTools(section, content) {
    const node = document.querySelector('[data-glpiacessivel-ticket-list-tools]');
    if (!(node instanceof HTMLScriptElement)) {
      return null;
    }
    try {
      listToolsConfig = JSON.parse(node.textContent || '{}');
    } catch (error) {
      return null;
    }
    if (!listToolsConfig || typeof listToolsConfig !== 'object' || !listToolsConfig.labels) {
      listToolsConfig = null;
      return null;
    }
    const previewUrl = localUrl(listToolsConfig.preview_url, '/ajax/get_item_content.php');
    const controls = section.querySelector('[data-glpiacessivel-refresh-controls]');
    const status = section.querySelector('[data-glpiacessivel-refresh-status]');
    const pause = section.querySelector('[data-glpiacessivel-refresh-pause]');
    const refreshLinks = document.querySelectorAll('[data-glpiacessivel-refresh-link]');
    const resultPagination = document.querySelector('[data-glpiacessivel-ticket-results-pagination]');
    const rawMinutes = Number(section.dataset.nativeRefreshMinutes || 0);
    const minutes = Number.isInteger(rawMinutes) && rawMinutes >= 1 && rawMinutes <= 30 ? rawMinutes : 0;
    let paused = false;
    let failed = false;
    let draft = false;
    let timer = 0;
    let runner = null;
    let pendingSortColumn = '';
    const previews = new Map();
    const sortFocusKey = 'glpiacessivel-ticket-sort-focus';

    function notice(key) {
      const value = key ? toolMessage(key) : '';
      if (status instanceof HTMLElement && status.textContent !== value) {
        status.textContent = value;
      }
    }
    function blocked() {
      const active = document.activeElement;
      return draft || document.visibilityState === 'hidden'
        || (section.contains(active) && !(controls instanceof HTMLElement && controls.contains(active)))
        || (resultPagination instanceof HTMLElement && resultPagination.contains(active))
        || (active instanceof Element && !!active.closest('form, [contenteditable="true"], dialog[open]'))
        || !!document.querySelector('dialog[open]')
        || !!content.querySelector('.glpiacessivel-ticket-select:checked, [data-glpiacessivel-ticket-preview][aria-expanded="true"]');
    }
    function clearTimer() {
      window.clearTimeout(timer);
      timer = 0;
    }
    function schedule() {
      clearTimer();
      if (minutes === 0 || paused || failed || !runner) {
        return;
      }
      timer = window.setTimeout(function () {
        timer = 0;
        if (blocked()) {
          notice('refresh_waiting');
          schedule();
          return;
        }
        if (runner(true) === false) {
          schedule();
        }
      }, minutes * 60000);
    }
    function preparePreview(button) {
      if (!previewUrl || !/^[1-9]\d*$/.test(button.dataset.glpiacessivelTicketPreview || '')) {
        return null;
      }
      button.hidden = false;
      button.setAttribute('aria-label', toolMessage('preview_named', {
        id: button.dataset.glpiacessivelTicketPreview, title: button.dataset.ticketTitle || ''
      }));
      if (previews.has(button)) {
        return previews.get(button);
      }
      const panel = document.createElement('div');
      panel.id = 'ticket-preview-' + (++previewSequence);
      panel.hidden = true;
      panel.className = 'glpiacessivel-ticket-preview';
      panel.setAttribute('role', 'region');
      panel.setAttribute('aria-label', button.getAttribute('aria-label'));
      panel.style.overflowWrap = 'anywhere';
      panel.style.maxWidth = '70ch';
      const close = document.createElement('button');
      close.type = 'button';
      close.className = 'glpiacessivel-button glpiacessivel-button-secondary';
      close.textContent = toolMessage('preview_close');
      const body = document.createElement('div');
      body.setAttribute('role', 'status');
      body.setAttribute('aria-live', 'polite');
      panel.append(close, body);
      button.after(panel);
      button.setAttribute('aria-controls', panel.id);
      const state = { panel: panel, body: body, controller: null, revision: 0 };
      function closePreview(restore) {
        state.revision += 1;
        if (state.controller) {
          state.controller.abort();
        }
        panel.hidden = true;
        body.replaceChildren();
        button.setAttribute('aria-expanded', 'false');
        if (restore) {
          button.focus();
        }
      }
      close.addEventListener('click', function () { closePreview(true); });
      button.addEventListener('keydown', function (event) {
        if (event.key === 'Escape' && !panel.hidden) {
          event.preventDefault();
          closePreview(true);
        }
      });
      panel.addEventListener('keydown', function (event) {
        if (event.key === 'Escape') {
          event.preventDefault();
          closePreview(true);
        }
      });
      state.close = closePreview;
      previews.set(button, state);
      return state;
    }
    function enhancePreviews() {
      previews.forEach(function (state, button) {
        if (!button.isConnected) {
          state.close(false);
          previews.delete(button);
        }
      });
      content.querySelectorAll('[data-glpiacessivel-ticket-preview]').forEach(preparePreview);
    }
    content.addEventListener('click', function (event) {
      const button = event.target instanceof Element
        ? event.target.closest('button[data-glpiacessivel-ticket-preview]') : null;
      if (!button) {
        return;
      }
      const state = preparePreview(button);
      if (!state) {
        return;
      }
      if (!state.panel.hidden) {
        state.close(false);
        return;
      }
      state.revision += 1;
      const revision = state.revision;
      state.panel.hidden = false;
      button.setAttribute('aria-expanded', 'true');
      state.body.textContent = toolMessage('preview_loading');
      state.controller = new AbortController();
      const url = new URL(previewUrl.href);
      url.searchParams.set('itemtype', 'Ticket');
      url.searchParams.set('items_id', button.dataset.glpiacessivelTicketPreview);
      const timeout = window.setTimeout(function () { state.controller.abort(); }, 10000);
      fetch(url.href, {
        credentials: 'same-origin', cache: 'no-store', signal: state.controller.signal,
        headers: { 'Accept': 'text/html', 'X-Requested-With': 'XMLHttpRequest' }
      }).then(function (response) {
        if (!response.ok || response.redirected
          || !/^text\/(html|plain)\b/i.test(response.headers.get('content-type') || '')) {
          throw new Error('preview_unavailable');
        }
        return response.text();
      }).then(function (html) {
        if (state.revision !== revision || !button.isConnected) {
          return;
        }
        if (!html.trim() || html.length > 1048576 || /<!doctype|<html\b|<body\b/i.test(html)) {
          throw new Error('preview_unavailable');
        }
        state.body.replaceChildren(safePreviewContent(html));
      }).catch(function () {
        if (state.revision === revision && button.isConnected) {
          state.body.textContent = toolMessage('preview_error');
        }
      }).finally(function () { window.clearTimeout(timeout); });
    });
    document.addEventListener('input', function (event) {
      const target = event.target;
      if (target instanceof Element && target.closest('form, [contenteditable="true"]')) {
        draft = true;
      }
    }, true);
    document.addEventListener('change', function (event) {
      const target = event.target;
      if (target instanceof Element && target.closest('form')
        && !target.matches('.glpiacessivel-ticket-select, [data-glpiacessivel-select-page]')) {
        draft = true;
      }
    }, true);
    refreshLinks.forEach(function (link) {
      link.addEventListener('click', function (event) {
        if (event.ctrlKey || event.metaKey || event.shiftKey || event.altKey || event.button > 0 || !runner) {
          return;
        }
        event.preventDefault();
        if (blocked()) {
          notice('refresh_waiting');
          return;
        }
        failed = false;
        runner(false);
      });
    });
    if (controls instanceof HTMLElement) {
      controls.hidden = false;
      const preferenceUrl = localUrl(listToolsConfig.preferences_url, '/front/preference.php');
      if (preferenceUrl) {
        const link = document.createElement('a');
        link.href = preferenceUrl.href;
        link.textContent = toolMessage('refresh_preferences');
        controls.appendChild(link);
      }
    }
    if (pause instanceof HTMLButtonElement) {
      pause.addEventListener('click', function () {
        paused = !paused;
        pause.setAttribute('aria-pressed', paused ? 'true' : 'false');
        pause.textContent = toolMessage(paused ? 'refresh_resume' : 'refresh_pause');
        notice(paused ? 'refresh_paused' : '');
        schedule();
      });
    }
    try {
      const stored = window.sessionStorage.getItem(sortFocusKey) || '';
      window.sessionStorage.removeItem(sortFocusKey);
      const prefix = window.location.pathname + '|';
      if (stored.startsWith(prefix)) {
        pendingSortColumn = stored.slice(prefix.length);
      }
    } catch (error) { /* Focus restoration is optional when storage is blocked. */ }
    content.addEventListener('click', function (event) {
      const link = event.target instanceof Element
        ? event.target.closest('a[data-glpiacessivel-sort-column]') : null;
      if (!link || event.ctrlKey || event.metaKey || event.shiftKey || event.altKey || event.button > 0) {
        return;
      }
      try {
        window.sessionStorage.setItem(sortFocusKey,
          window.location.pathname + '|' + link.dataset.glpiacessivelSortColumn);
      } catch (error) { /* Standard navigation still works without storage. */ }
    });
    enhancePreviews();
    window.addEventListener('pagehide', function () {
      paused = true;
      clearTimer();
      previews.forEach(function (state) { state.close(false); });
    });
    return {
      blocked: blocked,
      waiting: function () { notice('refresh_waiting'); },
      updated: function () { notice('refresh_updated'); },
      failed: function (announce) { failed = true; clearTimer(); if (announce) { notice('refresh_error'); } },
      paused: function () { return paused; },
      completed: schedule,
      setRunner: function (callback) { runner = callback; schedule(); },
      enhance: enhancePreviews,
      restoreSortFocus: function () {
        if (!pendingSortColumn) { return; }
        const target = Array.from(content.querySelectorAll('[data-glpiacessivel-sort-column]')).find(function (link) {
          return link.dataset.glpiacessivelSortColumn === pendingSortColumn;
        });
        if (target instanceof HTMLElement) {
          target.focus();
          const state = listToolsConfig.headers && listToolsConfig.headers[pendingSortColumn];
          if (state && state.state_label && status instanceof HTMLElement) {
            status.textContent = state.state_label;
          }
          pendingSortColumn = '';
        }
      }
    };
  }

  function message(key, replacements) {
    if (!i18n || typeof i18n[key] !== 'string' || i18n[key] === '') {
      return '';
    }
    let value = i18n[key];
    Object.keys(replacements || {}).forEach(function (name) {
      value = value.split('{' + name + '}').join(String(replacements[name]));
    });
    return value;
  }

  function readConfig() {
    const node = document.querySelector('[data-glpiacessivel-ticket-results-config]');
    if (!(node instanceof HTMLScriptElement)) {
      return { config: null, error: 'config_missing' };
    }
    try {
      const config = JSON.parse(node.textContent || '{}');
      return config && config.enabled === true
        ? { config: config, error: '' }
        : { config: null, error: 'config_disabled' };
    } catch (error) {
      return { config: null, error: 'config_invalid' };
    }
  }

  function textCell(value) {
    const cell = document.createElement('td');
    cell.textContent = String(value == null ? '' : value);
    return cell;
  }

  function detailLink(item, button) {
    const link = document.createElement('a');
    link.href = String(item.detail_url || '#');
    link.className = button
      ? 'glpiacessivel-button glpiacessivel-button-secondary'
      : 'glpiacessivel-ticket-title-link';
    link.textContent = button ? message('ticket.action.open') : String(item.name || '');
    if (button) {
      link.setAttribute('aria-label', message('ticket.action.open_named', {
        id: String(item.id || ''),
        title: String(item.name || '')
      }));
    }
    return link;
  }

  function badgeCell(item, field) {
    const cell = document.createElement('td');
    const badge = document.createElement('span');
    const kind = field === 'status' ? 'status' : 'priority';
    badge.className = 'glpiacessivel-badge glpiacessivel-badge-' + kind + '-' + String(item[field + '_class'] || 'neutral');
    badge.textContent = String(item[field + '_label'] || item[field] || '');
    cell.appendChild(badge);
    return cell;
  }

  function nativeTagColor(tag) {
    return tag && tag.color_available === true && /^#[0-9a-f]{6}$/i.test(String(tag.color || ''))
      && /^#(?:000000|ffffff)$/i.test(String(tag.foreground || ''));
  }

  function tagCellState(item) {
    const tags = item.tags && typeof item.tags === 'object' ? item.tags : {};
    if (tags.state === 'empty') { return 'empty'; }
    return tags.state === 'ready' && Array.isArray(tags.items) && tags.items.length > 0
      && tags.items.every(function (tag) {
        return tag && typeof tag === 'object' && Number.isInteger(tag.id) && tag.id > 0
          && typeof tag.name === 'string' && tag.name.trim() !== '';
      }) ? 'ready' : 'unavailable';
  }

  function tagsCell(item) {
    const state = tagCellState(item);
    const cell = textCell(state === 'empty' ? message('ticket.tags.empty') : message('ticket.tags.unavailable'));
    cell.className = 'glpiacessivel-ticket-tags-cell';
    if (state !== 'ready') { return cell; }
    cell.replaceChildren();
    const list = document.createElement('ul');
    list.className = 'glpiacessivel-ticket-tags-list glpiacessivel-ticket-tags-list-cell';
    list.setAttribute('role', 'list');
    item.tags.items.forEach(function (tag) {
      const entry = document.createElement('li');
      const badge = document.createElement('span');
      badge.className = 'glpiacessivel-ticket-tag';
      badge.textContent = tag.name;
      if (nativeTagColor(tag)) {
        badge.style.setProperty('--ticket-tag-background', tag.color);
        badge.style.setProperty('--ticket-tag-foreground', tag.foreground);
      }
      entry.appendChild(badge);
      list.appendChild(entry);
    });
    cell.appendChild(list);
    return cell;
  }

  function tagsPageWarning(items) {
    const unavailable = items.some(function (item) { return tagCellState(item) === 'unavailable'; });
    const neutral = items.some(function (item) {
      return tagCellState(item) === 'ready' && item.tags.items.some(function (tag) { return !nativeTagColor(tag); });
    });
    if (!unavailable && !neutral) { return null; }
    const warning = document.createElement('p');
    warning.className = 'glpiacessivel-help-text';
    warning.dataset.glpiacessivelTagsPageWarning = '';
    warning.textContent = [unavailable ? message('ticket.tags.page_warning') : '',
      neutral ? message('ticket.tags.neutral_warning') : ''].filter(Boolean).join(' ');
    return warning;
  }

  function ticketRow(item, columns, showGroup, onSelection) {
    const row = document.createElement('tr');
    const selectCell = document.createElement('td');
    const checkbox = document.createElement('input');
    checkbox.type = 'checkbox';
    checkbox.className = 'glpiacessivel-ticket-select';
    checkbox.value = String(item.id || '');
    checkbox.setAttribute('aria-label', message('ticket.action.select', { id: String(item.id || '') }));
    checkbox.addEventListener('change', onSelection);
    selectCell.appendChild(checkbox);
    row.appendChild(selectCell);

    columns.forEach(function (column) {
      if (!showGroup && column === 'group') {
        return;
      }
      if (column === 'name') {
        const cell = document.createElement('td');
        cell.appendChild(detailLink(item, false));
        row.appendChild(cell);
      } else if (column === 'status' || column === 'priority') {
        row.appendChild(badgeCell(item, column));
      } else if (column === 'tags') {
        row.appendChild(tagsCell(item));
      } else {
        const values = {
          id: item.id,
          group: item.primary_group_name || message('ticket.value.no_group'),
          requester: item.requester_name,
          assignee: item.assignee_name,
          category: item.category_name,
          entity: item.entity_name,
          location: item.location_name,
          date: item.date,
          date_mod: item.date_mod,
          time_to_resolve: item.time_to_resolve
        };
        row.appendChild(textCell(values[column]));
      }
    });

    const actionCell = document.createElement('td');
    actionCell.appendChild(detailLink(item, true));
    const preview = previewButton(item);
    if (preview) {
      actionCell.appendChild(preview);
    }
    row.appendChild(actionCell);
    return row;
  }

  function ticketTable(items, columns, showGroup, labelledBy, onSelection) {
    const wrap = document.createElement('div');
    wrap.className = 'glpiacessivel-table-wrap';
    wrap.setAttribute('role', 'region');
    wrap.setAttribute('tabindex', '0');
    if (labelledBy) {
      wrap.setAttribute('aria-labelledby', labelledBy);
    } else {
      wrap.setAttribute('aria-label', message('ticket.table.label'));
    }
    const table = document.createElement('table');
    table.className = 'tab_cadre_fixehov glpiacessivel-ticket-table';
    const caption = document.createElement('caption');
    caption.className = 'glpiacessivel-sr-only';
    caption.textContent = message('ticket.table.caption');
    table.appendChild(caption);
    const head = document.createElement('thead');
    const headRow = document.createElement('tr');
    const selectionHead = document.createElement('th');
    selectionHead.scope = 'col';
    const selectionLabel = document.createElement('span');
    selectionLabel.className = 'glpiacessivel-sr-only';
    selectionLabel.textContent = message('ticket.action.select_short');
    selectionHead.appendChild(selectionLabel);
    headRow.appendChild(selectionHead);
    columns.forEach(function (column) {
      if (!showGroup && column === 'group') {
        return;
      }
      const cell = document.createElement('th');
      cell.scope = 'col';
      const label = message(LABEL_KEYS[column]) || column;
      const sorting = column !== 'tags' && listToolsConfig && listToolsConfig.headers && listToolsConfig.headers[column];
      const sortUrl = sorting && localUrl(sorting.url);
      if (sorting && sortUrl && (sorting.direct === true
        || sorting.url === '#ticket-search-tool-result-options')) {
        const link = document.createElement('a');
        link.className = 'glpiacessivel-sort-link';
        link.href = sorting.url;
        link.textContent = label;
        link.setAttribute('aria-label', String(sorting.action_label || label));
        if (sorting.direct === true) {
          link.dataset.glpiacessivelSortColumn = column;
          if (sorting.direction === 'ASC' || sorting.direction === 'DESC') {
            cell.setAttribute('aria-sort', sorting.direction === 'ASC' ? 'ascending' : 'descending');
            const arrow = document.createElement('span');
            arrow.setAttribute('aria-hidden', 'true');
            arrow.textContent = sorting.direction === 'ASC' ? ' ↑' : ' ↓';
            link.appendChild(arrow);
          }
        }
        cell.appendChild(link);
      } else {
        cell.textContent = label;
      }
      headRow.appendChild(cell);
    });
    const actionHead = document.createElement('th');
    actionHead.scope = 'col';
    actionHead.textContent = message('ticket.column.action');
    headRow.appendChild(actionHead);
    head.appendChild(headRow);
    table.appendChild(head);
    const body = document.createElement('tbody');
    items.forEach(function (item) {
      body.appendChild(ticketRow(item, columns, showGroup, onSelection));
    });
    table.appendChild(body);
    wrap.appendChild(table);
    return wrap;
  }

  function renderItems(container, result, config, onSelection) {
    const items = Array.isArray(result.items) ? result.items : [];
    const backendReason = String(result.backend_reason || '');
    container.replaceChildren();
    if (items.length === 0) {
      if (backendReason === 'group_scope_without_current_groups') {
        return;
      }
      const empty = document.createElement('div');
      empty.className = 'glpiacessivel-empty';
      const messageNode = document.createElement('p');
      messageNode.textContent = message('ticket.results.empty');
      empty.appendChild(messageNode);
      container.appendChild(empty);
      return;
    }

    const columns = Array.isArray(config.columns) ? config.columns.map(String) : ['id', 'name', 'status', 'priority', 'group', 'date_mod'];
    if (columns.includes('tags')) {
      const warning = tagsPageWarning(items);
      if (warning) { container.appendChild(warning); }
    }
    if (config.group_by === 'group') {
      const groups = new Map();
      items.forEach(function (item) {
        const label = String(item.primary_group_name || message('ticket.value.no_group'));
        if (!groups.has(label)) {
          groups.set(label, []);
        }
        groups.get(label).push(item);
      });
      const grouped = document.createElement('div');
      grouped.className = 'glpiacessivel-ticket-grouped';
      Array.from(groups.keys()).sort(function (a, b) { return a.localeCompare(b, 'pt-BR'); }).forEach(function (label, index) {
        const section = document.createElement('section');
        section.className = 'glpiacessivel-ticket-group';
        const heading = document.createElement('h3');
        heading.id = 'tickets-grupo-async-' + String(index);
        heading.textContent = label + ' (' + message('ticket.group.count_on_page', {
          count: groups.get(label).length
        }) + ')';
        section.setAttribute('aria-labelledby', heading.id);
        section.appendChild(heading);
        section.appendChild(ticketTable(groups.get(label), columns, false, heading.id, onSelection));
        grouped.appendChild(section);
      });
      container.appendChild(grouped);
      return;
    }
    container.appendChild(ticketTable(items, columns, true, '', onSelection));
  }

  function pageUrl(page) {
    const url = new URL(window.location.href);
    url.searchParams.set('page', String(page));
    url.searchParams.set('focus', 'results');
    return url.pathname + '?' + url.searchParams.toString();
  }

  function paginationEntry(labelText, targetPage, enabled) {
    if (enabled) {
      const link = document.createElement('a');
      link.href = pageUrl(targetPage);
      link.textContent = labelText;
      return link;
    }
    const disabled = document.createElement('span');
    disabled.setAttribute('aria-disabled', 'true');
    disabled.textContent = labelText;
    return disabled;
  }

  function renderPagination(node, result, contractVersion) {
    const page = result.page;
    node.replaceChildren();
    node.hidden = false;
    const label = document.createElement('span');
    label.textContent = contractVersion === 1
      ? message('pagination.page_of', { page: page, pages: result.pages })
      : message('pagination.page', { page: page });
    node.appendChild(label);
    node.appendChild(paginationEntry(message('pagination.first'), 1, result.has_previous));
    node.appendChild(paginationEntry(message('pagination.previous'), page - 1, result.has_previous));
    const current = document.createElement('span');
    current.setAttribute('aria-current', 'page');
    current.textContent = message('pagination.current', { page: page });
    node.appendChild(current);
    node.appendChild(paginationEntry(message('pagination.next'), page + 1, result.has_more));
    if (contractVersion === 1) {
      node.appendChild(paginationEntry(message('pagination.last'), result.pages, page < result.pages));
    }
  }

  function isNonNegativeInteger(value) {
    return Number.isInteger(value) && value >= 0;
  }

  function normalizeResult(result, contractVersion) {
    if (!result || typeof result !== 'object' || Array.isArray(result)) {
      throw new Error('invalid_response');
    }
    if (!Array.isArray(result.items) || !Number.isInteger(result.page) || result.page < 1
      || !Number.isInteger(result.page_size) || result.page_size < 1 || result.items.length > result.page_size) {
      throw new Error('invalid_response');
    }
    if (contractVersion === 1) {
      if (!isNonNegativeInteger(result.total) || !Number.isInteger(result.pages) || result.pages < 1) {
        throw new Error('invalid_response');
      }
      return Object.assign({}, result, {
        total_state: 'exact',
        has_previous: result.page > 1,
        has_more: result.page < result.pages
      });
    }
    if (result.page_size > 50 || result.items.some(function (item) {
      return !item || typeof item !== 'object' || Array.isArray(item);
    })) {
      throw new Error('invalid_response');
    }
    const totalStates = ['deferred', 'pending', 'exact', 'unavailable', 'lower_bound'];
    if (typeof result.has_previous !== 'boolean' || typeof result.has_more !== 'boolean'
      || !totalStates.includes(result.total_state)) {
      throw new Error('invalid_response');
    }
    if (result.has_previous !== (result.page > 1) || (result.items.length === 0 && result.has_more)) {
      throw new Error('invalid_response');
    }
    if (result.total_state === 'exact' || result.total_state === 'lower_bound') {
      if (!isNonNegativeInteger(result.total)) {
        throw new Error('invalid_response');
      }
      const lastItem = result.items.length > 0
        ? ((result.page - 1) * result.page_size) + result.items.length
        : 0;
      if (result.total < lastItem) {
        throw new Error('invalid_response');
      }
    } else if (result.total !== null) {
      throw new Error('invalid_response');
    }
    return result;
  }

  function initializeSynchronousRetry() {
    const retry = document.querySelector('[data-glpiacessivel-sync-retry]');
    if (!(retry instanceof HTMLButtonElement)) {
      return false;
    }
    if (retry.dataset.glpiacessivelInitialized === '1') {
      return true;
    }
    retry.dataset.glpiacessivelInitialized = '1';
    const countdown = document.getElementById('tickets-sync-retry-countdown');
    const readyStatus = document.getElementById('tickets-sync-retry-ready');
    const retryUrl = String(retry.dataset.retryUrl || '');
    const singular = String(retry.dataset.waitSingular || '');
    const plural = String(retry.dataset.waitPlural || '');
    const readyMessage = String(retry.dataset.readyMessage || '');
    let remaining = Math.min(3600, Math.max(0, Number(retry.dataset.retryAfter || 0)));

    const markReady = function () {
      retry.disabled = false;
      if (countdown instanceof HTMLElement) {
        countdown.textContent = '';
      }
      if (readyStatus instanceof HTMLElement) {
        readyStatus.textContent = readyMessage;
      }
    };
    const updateCountdown = function () {
      if (remaining <= 0) {
        markReady();
        return false;
      }
      if (countdown instanceof HTMLElement) {
        const template = remaining === 1 ? singular : plural;
        countdown.textContent = template.replace('%d', String(remaining));
      }
      return true;
    };

    retry.addEventListener('click', function () {
      if (!retry.disabled && retryUrl) {
        window.location.assign(retryUrl);
      }
    });
    if (!updateCountdown()) {
      return true;
    }
    const timer = window.setInterval(function () {
      remaining -= 1;
      if (!updateCountdown()) {
        window.clearInterval(timer);
      }
    }, 1000);
    return true;
  }

  function start() {
    const synchronousRetry = initializeSynchronousRetry();
    const section = document.querySelector('[data-glpiacessivel-ticket-results]');
    const content = document.querySelector('[data-glpiacessivel-ticket-results-content]');
    const summary = document.querySelector('[data-glpiacessivel-ticket-results-summary]');
    const totalStatus = document.querySelector('[data-glpiacessivel-ticket-results-total]');
    const pagination = document.querySelector('[data-glpiacessivel-ticket-results-pagination]');
    const appliedSearchHeading = document.getElementById('tickets-filter-summary-heading');
    const appliedSearchStatic = document.querySelector('[data-glpiacessivel-applied-search-summary-static]');
    const effectiveSearch = document.querySelector('[data-glpiacessivel-effective-search-summary]');
    const effectiveSearchSections = document.querySelector('[data-glpiacessivel-effective-search-sections]');
    const effectiveSearchWarnings = document.querySelector('[data-glpiacessivel-effective-search-warnings]');
    const effectiveSearchWarningItems = document.querySelector('[data-glpiacessivel-effective-search-warning-items]');
    const effectiveSearchNote = document.querySelector('[data-glpiacessivel-effective-search-note]');
    const selectionSummary = document.querySelector('[data-glpiacessivel-selection-summary]');
    const selectedCount = document.querySelector('[data-glpiacessivel-selected-count]');
    const selectionStatus = document.querySelector('[data-glpiacessivel-selection-status]');
    const copyButton = document.querySelector('[data-glpiacessivel-copy-selected]');

    function updateEffectiveSearchSummary(dto) {
      const allowedSources = ['native_effective_search', 'native_effective_saved_search'];
      if (!dto || typeof dto !== 'object' || Array.isArray(dto)
        || dto.active !== true || !allowedSources.includes(dto.source)
        || typeof dto.heading !== 'string' || typeof dto.note !== 'string'
        || typeof dto.saved_search_name !== 'string'
        || !Array.isArray(dto.warnings) || dto.warnings.some(function (warning) {
          return typeof warning !== 'string';
        })
        || !Array.isArray(dto.sections) || dto.sections.length === 0) {
        return;
      }
      if (dto.source === 'native_effective_saved_search'
        && dto.saved_search_name.trim() === '') {
        return;
      }
      const validSections = dto.sections.every(function (section) {
        return section && typeof section === 'object' && !Array.isArray(section)
          && typeof section.key === 'string' && typeof section.label === 'string'
          && Array.isArray(section.items) && section.items.length > 0
          && !section.items.some(function (item) { return typeof item !== 'string'; });
      });
      if (!validSections) {
        return;
      }
      if (!(appliedSearchHeading instanceof HTMLElement)
        || !(appliedSearchStatic instanceof HTMLElement)
        || !(effectiveSearch instanceof HTMLElement)
        || !(effectiveSearchSections instanceof HTMLElement)
        || !(effectiveSearchWarnings instanceof HTMLElement)
        || !(effectiveSearchWarningItems instanceof HTMLElement)
        || !(effectiveSearchNote instanceof HTMLElement)) {
        return;
      }
      appliedSearchHeading.textContent = dto.heading;
      const sectionNodes = dto.sections.map(function (section) {
        const sectionNode = document.createElement('section');
        sectionNode.className = 'glpiacessivel-applied-search-summary-section';
        const heading = document.createElement('h4');
        heading.textContent = section.label;
        const list = document.createElement('ul');
        section.items.forEach(function (item) {
          const listItem = document.createElement('li');
          listItem.textContent = item;
          list.appendChild(listItem);
        });
        sectionNode.append(heading, list);
        return sectionNode;
      });
      effectiveSearchSections.replaceChildren.apply(effectiveSearchSections, sectionNodes);
      const warningNodes = dto.warnings.map(function (warning) {
        const listItem = document.createElement('li');
        listItem.textContent = warning;
        return listItem;
      });
      effectiveSearchWarningItems.replaceChildren.apply(effectiveSearchWarningItems, warningNodes);
      effectiveSearchWarnings.hidden = warningNodes.length === 0;
      effectiveSearchNote.textContent = dto.note;
      appliedSearchStatic.hidden = true;
      effectiveSearch.hidden = false;
    }
    if (!(section instanceof HTMLElement) || !(content instanceof HTMLElement)) {
      return;
    }
    if (section.dataset.glpiacessivelListToolsStarted === '1') {
      return;
    }
    section.dataset.glpiacessivelListToolsStarted = '1';
    const tools = initializeListTools(section, content);
    if (!document.querySelector('[data-glpiacessivel-ticket-results-config]')) {
      if (tools) {
        tools.setRunner(function () {
          if (synchronousRetry || tools.blocked()) {
            tools.waiting();
            return false;
          }
          window.location.reload();
          return true;
        });
        tools.restoreSortFocus();
      }
      return;
    }
    if (!i18n || !message('ticket.table.caption')) {
      return;
    }
    if (section.dataset.glpiacessivelAsyncStarted === '1') {
      return;
    }
    section.dataset.glpiacessivelAsyncStarted = '1';
    section.removeAttribute('aria-busy');

    const parsed = readConfig();
    const config = parsed.config;
    const nativeFallbackUrl = String(
      (config && config.native_fallback_url)
      || section.dataset.nativeFallbackUrl
      || ''
    );
    const savedSearchResetUrl = String(
      (config && config.saved_search_reset_url)
      || (window.location.pathname + '?saved_search=&manage_saved_search=1#ticket-search-tool-saved-searches')
    );
    const configuredPage = Number(config && config.page);
    const queryPage = Number(new URL(window.location.href).searchParams.get('page'));
    const currentPage = Number.isInteger(configuredPage) && configuredPage > 0
      ? configuredPage
      : (Number.isInteger(queryPage) && queryPage > 0 ? queryPage : 1);
    if (summary instanceof HTMLElement && !summary.id) {
      summary.id = 'tickets-results-status';
    }

    function failureMessage(code) {
      const messages = {
        session_expired: 'ticket.error.session_expired',
        forbidden: 'ticket.error.forbidden',
        context_stale: 'ticket.error.context_stale',
        state_expired: 'ticket.error.state_expired',
        invalid_request: 'ticket.error.invalid_request',
        invalid_security_token: 'ticket.error.invalid_security_token',
        saved_search_unavailable: 'ticket.error.saved_search_unavailable',
        native_resolved_semantics_changed: 'ticket.error.saved_search_semantics_changed',
        native_saved_search_unavailable: 'ticket.error.saved_search_unavailable',
        saved_search_revalidation_unavailable: 'ticket.error.saved_search_revalidation_unavailable',
        saved_search_revalidation_failed: 'ticket.error.saved_search_revalidation_failed',
        rate_limited: 'ticket.error.rate_limited',
        capacity_limited: 'ticket.error.capacity_limited',
        user_context_in_flight: 'ticket.error.user_context_in_flight',
        capacity_unavailable: 'ticket.error.capacity_unavailable',
        bounded_search_statement_timeout: 'ticket.error.statement_timeout',
        bounded_search_execution_unavailable: 'ticket.error.unavailable',
        bounded_search_execution_failed: 'ticket.error.unavailable',
        bounded_search_plan_failed: 'ticket.error.unavailable',
        unavailable: 'ticket.error.unavailable',
        temporarily_unavailable: 'ticket.error.unavailable',
        origin_not_allowed: 'ticket.error.origin_not_allowed',
        timed_out: 'ticket.error.timed_out',
        config_invalid: 'ticket.error.config_invalid',
        config_missing: 'ticket.error.config_missing',
        contract_upgrade_required: 'ticket.error.contract_upgrade_required',
        bounded_search_offset_limit_exceeded: 'ticket.error.bounded_offset_exceeded',
        unexpected_content_type: 'ticket.error.unexpected_content_type',
        invalid_response: 'ticket.error.invalid_response'
      };
      return message(messages[code] || 'ticket.error.generic', { page: currentPage });
    }

    let generation = 0;
    let retryTimer = 0;
    function setSummary(value, accessibleDetail) {
      if (!summary) {
        return;
      }
      const detail = String(accessibleDetail || '');
      const announcement = detail ? value + ' ' + detail : value;
      if (summary.dataset.glpiacessivelAnnouncement === announcement) {
        return;
      }
      const nodes = [document.createTextNode(value)];
      if (detail) {
        const detailNode = document.createElement('span');
        detailNode.className = 'glpiacessivel-sr-only';
        detailNode.textContent = ' ' + detail;
        nodes.push(detailNode);
      }
      summary.replaceChildren.apply(summary, nodes);
      summary.dataset.glpiacessivelAnnouncement = announcement;
    }

    function clearRetryTimer() {
      if (retryTimer) {
        window.clearInterval(retryTimer);
        retryTimer = 0;
      }
    }

    function retryAfterSeconds(response) {
      const raw = String(response.headers.get('retry-after') || '').trim();
      if (/^\d+$/.test(raw)) {
        return Math.min(3600, Number(raw));
      }
      const timestamp = Date.parse(raw);
      if (raw && Number.isFinite(timestamp)) {
        return Math.min(3600, Math.max(0, Math.ceil((timestamp - Date.now()) / 1000)));
      }
      return 0;
    }

    function requestError(code, retryAfter) {
      const error = new Error(code);
      error.retryAfter = retryAfter;
      return error;
    }

    function finishBusy() {
      section.removeAttribute('aria-busy');
      if (totalStatus instanceof HTMLElement) {
        totalStatus.removeAttribute('aria-busy');
      }
    }

    function hidePagination() {
      if (pagination instanceof HTMLElement) {
        pagination.replaceChildren();
        pagination.hidden = true;
      }
    }

    function focusResultsHeading() {
      const heading = document.getElementById('tickets-lista');
      if (heading instanceof HTMLElement) {
        heading.focus();
      }
    }

    function actionButton(labelKey, callback) {
      const button = document.createElement('button');
      button.type = 'button';
      button.className = 'glpiacessivel-button';
      button.textContent = message(labelKey);
      button.addEventListener('click', callback);
      return button;
    }

    function setSelectionVisible(visible) {
      if (!visible) {
        section.dispatchEvent(new CustomEvent('glpiacessivel:ticket-selection-reset'));
      }
      if (selectionSummary instanceof HTMLElement) {
        selectionSummary.hidden = !visible;
      }
      if (!visible) {
        if (selectedCount && selectedCount.textContent !== '0') {
          selectedCount.textContent = '0';
        }
        if (copyButton instanceof HTMLButtonElement) {
          copyButton.disabled = true;
        }
        if (selectionStatus instanceof HTMLElement && section.dataset.glpiacessivelSelectionBound !== '1') {
          selectionStatus.textContent = '';
        }
      }
    }

    function renderFailure(code, retryAfter) {
      clearRetryTimer();
      setSelectionVisible(false);
      const savedSearchUnavailable = [
        'saved_search_unavailable',
        'native_saved_search_unavailable',
        'native_resolved_semantics_changed'
      ].includes(code);
      const alert = document.createElement('section');
      const savedSearchRevalidationFailure = [
        'saved_search_revalidation_unavailable', 'saved_search_revalidation_failed'
      ].includes(code);
      alert.className = 'glpiacessivel-alert glpiacessivel-alert-error';
      alert.setAttribute('role', 'region');
      alert.setAttribute('aria-labelledby', 'tickets-results-error-heading');
      if (summary instanceof HTMLElement && !savedSearchUnavailable) {
        alert.setAttribute('aria-describedby', summary.id);
      }
      const heading = document.createElement('h3');
      heading.id = 'tickets-results-error-heading';
      heading.textContent = message(savedSearchUnavailable
        ? 'ticket.error.saved_search_heading'
        : (savedSearchRevalidationFailure ? 'ticket.error.saved_search_revalidation_heading' : 'ticket.error.heading'));
      const actions = document.createElement('p');
      const retryable = ['timed_out', 'unavailable', 'temporarily_unavailable', 'rate_limited',
        'capacity_limited', 'user_context_in_flight', 'capacity_unavailable', 'bounded_search_execution_unavailable',
        'bounded_search_execution_failed', 'bounded_search_statement_timeout', 'bounded_search_plan_failed',
        'unexpected_content_type', 'invalid_response', 'saved_search_revalidation_unavailable'];
      const reloadable = ['context_stale', 'state_expired', 'config_invalid', 'config_missing',
        'contract_upgrade_required', 'invalid_security_token', 'saved_search_revalidation_failed'];
      if (savedSearchUnavailable) {
        const description = document.createElement('p');
        description.id = 'tickets-saved-search-error-description';
        description.textContent = failureMessage(code);
        alert.setAttribute('aria-describedby', description.id);
        alert.appendChild(description);
        const backToSavedSearches = document.createElement('a');
        backToSavedSearches.className = 'glpiacessivel-button';
        backToSavedSearches.href = savedSearchResetUrl;
        backToSavedSearches.textContent = message('ticket.action.back_to_saved_searches');
        actions.appendChild(backToSavedSearches);
      } else if (code === 'bounded_search_offset_limit_exceeded') {
        const firstPage = document.createElement('a');
        firstPage.className = 'glpiacessivel-button';
        firstPage.href = pageUrl(1);
        firstPage.textContent = message('ticket.action.back_to_first_page');
        actions.appendChild(firstPage);
      } else if (config && config.bootstrap_error && code !== 'saved_search_revalidation_unavailable') {
        actions.appendChild(actionButton('ticket.action.reload_page', function () {
          window.location.reload();
        }));
      } else if (retryable.includes(code)) {
        const retryButton = actionButton('button.retry', function () {
          if (savedSearchRevalidationFailure && !config.state_token) {
            // Initial resolution failed before a server-side list token existed.
            // Retry the same page explicitly, never submit an empty query/token.
            window.location.reload();
          } else {
            runRequest(true);
          }
        });
        let remaining = Math.max(0, Number.isFinite(Number(retryAfter)) ? Math.ceil(Number(retryAfter)) : 0);
        if (remaining > 0) {
          const countdown = document.createElement('p');
          countdown.id = 'tickets-results-retry-countdown';
          countdown.setAttribute('aria-live', 'off');
          retryButton.setAttribute('aria-describedby', countdown.id);
          retryButton.disabled = true;
          const updateCountdown = function () {
            countdown.textContent = message(
              remaining === 1 ? 'ticket.error.retry_wait' : 'ticket.error.retry_wait_plural',
              { seconds: remaining }
            );
          };
          updateCountdown();
          alert.appendChild(countdown);
          retryTimer = window.setInterval(function () {
            remaining -= 1;
            if (remaining <= 0) {
              clearRetryTimer();
              retryButton.disabled = false;
              countdown.textContent = '';
              setSummary(message('ticket.error.retry_ready', { page: currentPage }));
              return;
            }
            updateCountdown();
          }, 1000);
        }
        actions.appendChild(retryButton);
      } else if (reloadable.includes(code)) {
        actions.appendChild(actionButton('ticket.action.reload_page', function () {
          window.location.reload();
        }));
      }
      if (!savedSearchUnavailable && code !== 'invalid_security_token' && !savedSearchRevalidationFailure && nativeFallbackUrl !== '') {
        if (retryable.includes(code)) {
          const fallbackWarning = document.createElement('p');
          fallbackWarning.textContent = message('ticket.error.native_fallback_filter_warning');
          alert.appendChild(fallbackWarning);
        }
        const link = document.createElement('a');
        link.className = 'glpiacessivel-button glpiacessivel-button-secondary';
        link.href = nativeFallbackUrl;
        link.textContent = code === 'session_expired'
          ? message('ticket.action.sign_in_again')
          : message('ticket.action.open_native_general_list');
        actions.appendChild(link);
      }
      alert.prepend(heading);
      alert.appendChild(actions);
      content.replaceChildren(alert);
      setSummary(failureMessage(code));
      if (totalStatus instanceof HTMLElement) {
        totalStatus.textContent = '';
      }
      hidePagination();
      finishBusy();
    }

    if (!config) {
      renderFailure(parsed.error || 'config_invalid');
      return;
    }
    if (config.bootstrap_error) {
      renderFailure(String(config.bootstrap_error), Math.max(0, Number(config.retry_after) || 0));
      return;
    }
    const contractVersion = Number(config.contract_version);
    if (contractVersion !== 1 && contractVersion !== 2) {
      renderFailure('config_invalid');
      return;
    }

    let lastSelectedCount = 0;
    let requestInFlight = false;
    let previousItems = null;
    let activeController = null;
    window.addEventListener('pagehide', function () {
      generation += 1;
      if (activeController) { activeController.abort(); }
    });
    function selectedIds() {
      return Array.from(content.querySelectorAll('.glpiacessivel-ticket-select:checked')).map(function (checkbox) {
        return String(checkbox.value || '');
      }).filter(Boolean);
    }
    function refreshSelection() {
      if (section.dataset.glpiacessivelSelectionBound === '1') {
        return;
      }
      const ids = selectedIds();
      const countText = String(ids.length);
      if (selectedCount && selectedCount.textContent !== countText) {
        selectedCount.textContent = countText;
      }
      if (ids.length !== lastSelectedCount && selectionStatus instanceof HTMLElement) {
        selectionStatus.textContent = message('ticket.selection.count', { count: ids.length });
      }
      lastSelectedCount = ids.length;
      if (copyButton instanceof HTMLButtonElement) {
        copyButton.disabled = ids.length === 0;
      }
    }
    function runRequest(userInitiated, background, automatic) {
      if (requestInFlight) {
        return false;
      }
      if (background && tools && tools.blocked()) {
        tools.waiting();
        return false;
      }
      requestInFlight = true;
      clearRetryTimer();
      generation += 1;
      const currentGeneration = generation;
      const requestId = 'tickets_' + Date.now().toString(36) + '_' + Math.random().toString(36).slice(2, 10);
      const controller = new AbortController();
      activeController = controller;
      // Only the server-rendered administrative opt-out disables our deadline.
      // Missing/malformed legacy configuration retains the existing behavior.
      const deadline = config.performance_limits_enabled === false && config.request_timeout_ms === 0
        ? 0
        : Math.min(13000, Math.max(5000, Number(config.request_timeout_ms || 7000)));
      let terminal = false;
      function requestFailure(code, retryAfter) {
        if (tools) { tools.failed(background); }
        if (tools && background) {
          // Security/context failures must not leave stale restricted data visible.
          const securityFailure = /session_expired|forbidden|context_stale|state_expired|invalid_security_token|saved_search|native_resolved_semantics_changed|origin_not_allowed|http_401|http_403|unexpected_content_type/.test(code);
          if (!securityFailure) {
            finishBusy();
            return;
          }
        }
        renderFailure(code, retryAfter);
      }

      section.setAttribute('aria-busy', 'true');
      if (!background) {
        setSelectionVisible(false);
        lastSelectedCount = 0;
        if (totalStatus instanceof HTMLElement) {
          totalStatus.textContent = '';
          totalStatus.setAttribute('aria-busy', 'true');
        }
        hidePagination();
        const loading = document.createElement('div');
        loading.className = 'glpiacessivel-empty';
        loading.textContent = message('ticket.results.loading');
        content.replaceChildren(loading);
        if (userInitiated === true) {
          focusResultsHeading();
        }
        setSummary(message('ticket.results.loading_summary'));
      }

      const timeout = deadline > 0 ? window.setTimeout(function () {
        if (terminal || currentGeneration !== generation) {
          return;
        }
        terminal = true;
        controller.abort();
        requestFailure('timed_out');
      }, deadline) : 0;

      fetch(String(config.url || ''), {
        method: 'POST',
        credentials: 'same-origin',
        cache: 'no-store',
        signal: controller.signal,
        headers: {
          'Accept': 'application/json',
          'Content-Type': 'application/json',
          'X-Requested-With': 'XMLHttpRequest',
          'X-GLPI-CSRF-TOKEN': String(config.csrf_token || '')
        },
        body: JSON.stringify({
          contract: 'ticket_results', version: contractVersion,
          state_token: String(config.state_token || ''),
          context_revision: String(config.context_revision || ''),
          request_id: requestId
        })
      }).then(function (response) {
        const retryAfter = retryAfterSeconds(response);
        if (!String(response.headers.get('content-type') || '').toLowerCase().includes('application/json')) {
          throw requestError('unexpected_content_type', retryAfter);
        }
        return response.json().then(function (payload) {
          const nativeGlpiCsrfFailure = response.status === 403
            && payload && typeof payload === 'object'
            && payload.error === true
            && Object.keys(payload).length === 1;
          if (nativeGlpiCsrfFailure) {
            throw requestError('invalid_security_token', retryAfter);
          }
          if (payload.contract !== 'ticket_results' || payload.version !== contractVersion
            || typeof payload.success !== 'boolean') {
            throw requestError('invalid_response', retryAfter);
          }
          if (!response.ok) {
            throw requestError(String(payload.error || 'http_' + response.status), retryAfter);
          }
          if (payload.context_revision !== config.context_revision) {
            throw requestError('context_stale', retryAfter);
          }
          if (payload.success !== true || payload.request_id !== requestId) {
            throw requestError(String(payload.error || 'invalid_response'), retryAfter);
          }
          return normalizeResult(payload.result, contractVersion);
        });
      }).then(function (result) {
        if (terminal || currentGeneration !== generation) {
          return;
        }
        if (result.items.length === 0 && String(result.backend || '') === 'native_saved_search_blocked') {
          throw new Error(String(result.backend_reason || 'unavailable'));
        }
        if (background && tools && (tools.blocked() || (automatic && tools.paused()))) {
          if (!automatic || !tools.paused()) { tools.waiting(); }
          terminal = true;
          finishBusy();
          return;
        }
        const signature = JSON.stringify(result.items);
        const changed = signature !== previousItems;
        if (!background || changed) {
          renderItems(content, result, config, refreshSelection);
        }
        previousItems = signature;
        if (tools) {
          tools.enhance();
          tools.restoreSortFocus();
          if (background && changed) { tools.updated(); }
        }
        updateEffectiveSearchSummary(result.effective_search_summary);
        const itemCount = result.items.length;
        setSelectionVisible(itemCount > 0);
        const first = itemCount > 0 ? ((result.page - 1) * result.page_size) + 1 : 0;
        const last = itemCount > 0 ? first + itemCount - 1 : 0;
        let summaryText;
        if (String(result.backend_reason || '') === 'group_scope_without_current_groups') {
          summaryText = message('ticket.results.group_scope_without_current_groups');
        } else if (itemCount === 0 && result.page > 1) {
          summaryText = message('ticket.results.page_empty_after_first', { page: result.page });
        } else if (itemCount === 0) {
          summaryText = message('ticket.results.none_visible');
        } else if (result.total_state === 'exact') {
          summaryText = message('ticket.results.range', { first: first, last: last, total: result.total });
        } else if (result.total_state === 'lower_bound') {
          summaryText = message('ticket.results.range_lower_bound', { first: first, last: last, total: result.total });
        } else {
          summaryText = message(result.has_more
            ? 'ticket.results.page_range_more'
            : 'ticket.results.page_range_end', { first: first, last: last });
        }
        const totalMessages = {
          deferred: 'ticket.results.total_deferred',
          pending: 'ticket.results.total_pending',
          unavailable: 'ticket.results.total_unavailable'
        };
        const totalMessage = totalMessages[result.total_state]
          ? message(totalMessages[result.total_state])
          : '';
        setSummary(summaryText, totalMessage);
        if (totalStatus instanceof HTMLElement) {
          totalStatus.textContent = totalMessage;
        }
        if (pagination instanceof HTMLElement) {
          renderPagination(pagination, result, contractVersion);
        }
        refreshSelection();
        terminal = true;
        finishBusy();
        section.dispatchEvent(new CustomEvent('glpiacessivel:ticket-selection-ready', {
          detail: typeof result.mass_selection_token === 'string' ? result.mass_selection_token : ''
        }));
      }).catch(function (error) {
        if (terminal || currentGeneration !== generation) {
          return;
        }
        terminal = true;
        requestFailure(
          String(error && error.message ? error.message : 'unavailable'),
          Number(error && error.retryAfter ? error.retryAfter : 0)
        );
      }).finally(function () {
        window.clearTimeout(timeout);
        requestInFlight = false;
        if (activeController === controller) { activeController = null; }
        if (tools) { tools.completed(); }
      });
      return true;
    }

    if (tools) {
      tools.setRunner(function (automatic) { return runRequest(false, true, automatic); });
    }
    runRequest();
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', start, { once: true });
  } else {
    start();
  }
})();
